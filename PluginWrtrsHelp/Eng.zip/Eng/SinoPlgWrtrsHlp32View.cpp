// SinoSHlp32View.cpp : implementation of the CSinoSHlp32View class
//

#include "stdafx.h"
#include "SinoPlgWrtrsHlp32.h"

#include "SinoPlgWrtrsHlp32Doc.h"
#include "SinoPlgWrtrsHlp32View.h"
#include "LeftView.h"
#include "MainFrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


CSinoSHlp32View *htmlView=NULL;

// CSinoSHlp32View

IMPLEMENT_DYNCREATE(CSinoSHlp32View, CHtmlView)

BEGIN_MESSAGE_MAP(CSinoSHlp32View, CHtmlView)
END_MESSAGE_MAP()

// CSinoSHlp32View construction/destruction

CSinoSHlp32View::CSinoSHlp32View():iPage(0),beforeNavigateType(undefined),uiCrntRes(0),findTxtDlg(NULL)//iStep(0),
{
	// TODO: add construction code here
//	for(int i=0; i<MAX_STEPS-1; i++)
//		steps[i] = -1;
	tchCrntRes[0]=0;
}

CSinoSHlp32View::~CSinoSHlp32View()
{
}

/*BOOL CSinoSHlp32View::PushStep(int page)
{
	if(iStep<MAX_STEPS-2)
	{	steps[iStep]=page;
		++iStep;
	}
	else
	{	for(int i=0; i<MAX_STEPS-2; i++)
			steps[i]=steps[i+1];
		steps[iStep]=page;
	}
	return TRUE;
}

BOOL CSinoSHlp32View::PopStep(int page)
{
	if(iStep>0)
	{	steps[iStep]=page;
		--iStep;
	}
	else
	{	steps[iStep]=page;
	}
	return TRUE;
}*/

void CSinoSHlp32View::DocumentComplete(LPDISPATCH pDisp,VARIANT *URL)
{
	CHtmlView::DocumentComplete(pDisp,URL);
	if(1==mainFrame->iSearchProcessBegin)
	{	mainFrame->ContinueFindTextInAllHTMLs();
	}
	else if(2==mainFrame->iSearchProcessBegin)
	{	mainFrame->iSearchProcessBegin = 0;
		mainFrame->SelectAllFindStrInCrntPage();
	}
	else if(0==mainFrame->iSearchProcessBegin && listType==search)
		mainFrame->SelectAllFindStrInCrntPage();
}

BOOL CSinoSHlp32View::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs
	return CHtmlView::PreCreateWindow(cs);
}

void CSinoSHlp32View::OnBeforeNavigate2(LPCTSTR lpszURL,
										DWORD nFlags,
										LPCTSTR lpszTargetFrameName,
										CByteArray& baPostedData,
										LPCTSTR lpszHeaders,
										BOOL* pbCancel)
{
LPCTSTR lpszURLP=lpszURL,lpszURLPP;
LPCTSTR lpszTargetFrameNameP=lpszTargetFrameName,lpszTargetFrameNamePP;
BOOL myCancel=TRUE;
int p=iPage;
 iList=p;
 for(lpszURLPP=lpszURL; *lpszURLPP; lpszURLPP++)
 {	if(*lpszURLPP == '\\' || *lpszURLPP == '/')
 		lpszURLP = lpszURLPP+1;
 }
 for(lpszTargetFrameNamePP=lpszTargetFrameName; *lpszTargetFrameNamePP; lpszTargetFrameNamePP++)
 {	if(*lpszTargetFrameNamePP == '\\' || *lpszTargetFrameNamePP == '/')
 		lpszTargetFrameNameP = lpszTargetFrameNamePP+1;
 }

 int htmNameAsInt = atoi(lpszURLP);
	
 if(beforeNavigateType==fromHtmlElement)
 {	if(htmNameAsInt>0)
		goto Sl;//return;//This is inside html call
	if(!strcmp(lpszTargetFrameNameP,"����������%20�������.htm") ||
	        !strcmp(lpszURLP,"����������%20�������.htm"))
	{	if(0!=iPage)
		{	LoadFromResource(IDR_HTML_SODERJANIYE);
			pbCancel = &myCancel;
			iPage = 0;
			iList = 0;
	}	}
	else if(!strcmp(lpszTargetFrameNameP,"�%20���������%20Sino.htm") ||
	   !strcmp(lpszURLP,"�%20���������%20Sino.htm"))
	{	if(1!=iPage)
		{	LoadFromResource(IDR_HTML_O_PROGRAMME);
			pbCancel = &myCancel;
			iPage = 1;
			iList = 1;
	}	}
	else if(!strcmp(lpszTargetFrameNameP,"�����������%20��%20��������%20��������%20���%20���������%20%20SINO.htm") ||
	        !strcmp(lpszURLP,"�����������%20��%20��������%20��������%20���%20���������%20%20SINO.htm"))
	{	if(2!=iPage)
		{	LoadFromResource(IDR_HTML_PLAGINY);
			pbCancel = &myCancel;
			iPage = 2;
			iList = 2;
	}	}
	else if(!strcmp(lpszTargetFrameNameP,"�����������%20��%20��������%20��������%20��������%20���%20���������%20%20SINO.htm") ||
			!strcmp(lpszURLP,"�����������%20��%20��������%20��������%20��������%20���%20���������%20%20SINO.htm"))
	{	if(3!=iPage)
		{	LoadFromResource(IDR_HTML_ARXIVNIYE_PLAGINY);
			pbCancel = &myCancel;
			iPage = 3;
			iList = 4;
	}	}	
	else if(!strcmp(lpszTargetFrameNameP,"��������%20������%20GetPluginType.htm") ||
			!strcmp(lpszURLP,"��������%20������%20GetPluginType.htm"))
	{	if(4!=iPage)
		{	LoadFromResource(IDR_HTML_ARJPLGN_GetPluginType);
			pbCancel = &myCancel;
			iPage = 4;
			iList = 5;
	}	}
	else if(!strcmp(lpszTargetFrameNameP,"��������%20������%20Open$12.htm") ||
			!strcmp(lpszURLP,"��������%20������%20Open$12.htm"))
	{	if(5!=iPage)
		{	LoadFromResource(IDR_HTML_ARJPLGN_OpenS12);
			pbCancel = &myCancel;
			iPage = 5;
			iList = 6;
	}	}
	else if(!strcmp(lpszTargetFrameNameP,"��������%20������%20Close$4.htm") ||
			!strcmp(lpszURLP,"��������%20������%20Close$4.htm"))
	{	if(6!=iPage)
		{	LoadFromResource(IDR_HTML_ARJPLGN_CloseS4);
			pbCancel = &myCancel;
			iPage = 6;
			iList = 7;
	}	}
	else if(!strcmp(lpszTargetFrameNameP,"��������%20������%20Add$24.htm") ||
			!strcmp(lpszURLP,"��������%20������%20Add$24.htm"))
	{	if(7!=iPage)
		{	LoadFromResource(IDR_HTML_ARJPLGN_AddS24);
			pbCancel = &myCancel;
			iPage = 7;
			iList = 8;
	}	}
	else if(!strcmp(lpszTargetFrameNameP,"��������%20������%20CreateDir$24.htm") ||
			!strcmp(lpszURLP,"��������%20������%20CreateDir$24.htm"))
	{	if(8!=iPage)
		{	LoadFromResource(IDR_HTML_ARJPLGN_CreateDirS24);
			pbCancel = &myCancel;
			iPage = 8;
			iList = 9;
	}	}
	else if(!strcmp(lpszTargetFrameNameP,"��������%20������%20RebuildCheckExistings$8.htm") ||
			!strcmp(lpszURLP,"��������%20������%20RebuildCheckExistings$8.htm"))
	{	if(9!=iPage)
		{	LoadFromResource(IDR_HTML_ARJPLGN_RebuildCheckExistingsS8);
			pbCancel = &myCancel;
			iPage = 9;
			iList = 10;
	}	}
	else if(!strcmp(lpszTargetFrameNameP,"��������%20������%20RenameFile$12.htm") ||
			!strcmp(lpszURLP,"��������%20������%20RenameFile$12.htm"))
	{	if(11!=iPage)
		{	LoadFromResource(IDR_HTML_ARJPLGN_RenameFileS12);
			pbCancel = &myCancel;
			iPage = 11;
			iList = 11;
 	}	}
	else if(!strcmp(lpszTargetFrameNameP,"��������%20������%20RenameDir$12.htm") ||
			!strcmp(lpszURLP,"��������%20������%20RenameDir$12.htm"))
	{	if(12!=iPage)
		{	LoadFromResource(IDR_HTML_ARJPLGN_RenameDirS12);
			pbCancel = &myCancel;
			iPage = 12;
			iList = 12;
 	}	}
	else if(!strcmp(lpszTargetFrameNameP,"��������%20������%20DeleteFile$8.htm") ||
			!strcmp(lpszURLP,"��������%20������%20DeleteFile$8.htm"))
	{	if(13!=iPage)
		{	LoadFromResource(IDR_HTML_ARJPLGN_DeleteFileS8);
			pbCancel = &myCancel;
			iPage = 13;
			iList = 13;
 	}	}
	else if(!strcmp(lpszTargetFrameNameP,"��������%20������%20DeleteDir$8.htm") ||
			!strcmp(lpszURLP,"��������%20������%20DeleteDir$8.htm"))
	{	if(14!=iPage)
		{	LoadFromResource(IDR_HTML_ARJPLGN_DeleteDirS8);
			pbCancel = &myCancel;
			iPage = 14;
			iList = 14;
 	}	}
	else if(!strcmp(lpszTargetFrameNameP,"��������%20������%20SetCallbacks$4xxx.htm") ||
			!strcmp(lpszURLP,"��������%20������%20SetCallbacks$4xxx.htm"))
	{	if(15!=iPage)
		{	LoadFromResource(IDR_HTML_ARJPLGN_SetCallbacksS4xxx);
			pbCancel = &myCancel;
			iPage = 15;
			iList = 15;
	}	}
	else if(!strcmp(lpszTargetFrameNameP,"��������%20������%20callback%20checkFileInSelctn.htm") ||
			!strcmp(lpszURLP,"��������%20������%20callback%20checkFileInSelctn.htm"))
	{	if(16!=iPage)
		{	LoadFromResource(IDR_HTML_ARJPLGNCLBK_checkFileInSelctn);
			pbCancel = &myCancel;
			iPage = 16;
			iList = 17;
	}	}
	else if(!strcmp(lpszTargetFrameNameP,"��������%20������%20callback%20excldFileFrSelctn.htm") ||
			!strcmp(lpszURLP,"��������%20������%20callback%20excldFileFrSelctn.htm"))
	{	if(17!=iPage)
		{	LoadFromResource(IDR_HTML_ARJPLGNCLBK_excldFileFrSelctn);
			pbCancel = &myCancel;
			iPage = 17;
			iList = 18;
	}	}
	else if(!strcmp(lpszTargetFrameNameP,"��������%20������%20callback%20getFileInfoFromSelection.htm") ||
			!strcmp(lpszURLP,"��������%20������%20callback%20getFileInfoFromSelection.htm"))
	{	if(18!=iPage)
		{	LoadFromResource(IDR_HTML_ARJPLGNCLBK_getFileInfoFromSelection);
			pbCancel = &myCancel;
			iPage = 18;
			iList = 19;
	}	}
	else if(!strcmp(lpszTargetFrameNameP,"��������%20������%20callback%20prgrssRout.htm") ||
			!strcmp(lpszURLP,"��������%20������%20callback%20prgrssRout.htm"))
	{	if(19!=iPage)
		{	LoadFromResource(IDR_HTML_ARJPLGNCLBK_prgrssRout);
			pbCancel = &myCancel;
			iPage = 19;
			iList = 20;
	}	}
	else if(!strcmp(lpszTargetFrameNameP,"��������%20������%20callback%20showDlgOverwriteExistFile.htm") ||
			!strcmp(lpszURLP,"��������%20������%20callback%20showDlgOverwriteExistFile.htm"))
	{	if(20!=iPage)
		{	LoadFromResource(IDR_HTML_ARJPLGNCLBK_showDlgOverwriteExistFile);
			pbCancel = &myCancel;
			iPage = 20;
			iList = 21;
	}	}
	else if(!strcmp(lpszTargetFrameNameP,"��������%20������%20callback%20saveOptions.htm") ||
			!strcmp(lpszURLP,"��������%20������%20callback%20saveOptions.htm"))
	{	if(21!=iPage)
		{	LoadFromResource(IDR_HTML_ARJPLGNCLBK_saveOptions);
			pbCancel = &myCancel;
			iPage = 21;
			iList = 22;
	}	}
	else if(!strcmp(lpszTargetFrameNameP,"��������%20������%20callback%20readOptions.htm") ||
			!strcmp(lpszURLP,"��������%20������%20callback%20readOptions.htm"))
	{	if(17!=iPage)
		{	LoadFromResource(IDR_HTML_ARJPLGNCLBK_readOptions);
			pbCancel = &myCancel;
			iPage = 17;
			iList = 18;
 	}	}
	//Unpack arj:
	else if(!strcmp(lpszTargetFrameNameP,"�����������%20��%20��������%20��������%20�������������%20��������%20���%20���������%20%20SINO.htm") ||
			!strcmp(lpszURLP,"�����������%20��%20��������%20��������%20�������������%20��������%20���%20���������%20%20SINO.htm"))
	{	if(18!=iPage)
		{	LoadFromResource(IDR_HTML_RASP_ARXIVNIYE_PLAGINY);
			pbCancel = &myCancel;
			iPage = 18;
			iList = 19;
 	}	}
	else if(!strcmp(lpszTargetFrameNameP,"�������������%20��������%20������%20OpenForUnpacking$8.htm") ||
			!strcmp(lpszURLP,"�������������%20��������%20������%20OpenForUnpacking$8.htm"))
	{	if(19!=iPage)
		{	LoadFromResource(IDR_HTML_UNPARJPLGN_OpenForUnpackingS8);
			pbCancel = &myCancel;
			iPage = 19;
			iList = 20;
 	}	}
	else if(!strcmp(lpszTargetFrameNameP,"�������������%20��������%20������%20EnumDirectory$8.htm") ||
			!strcmp(lpszURLP,"�������������%20��������%20������%20EnumDirectory$8.htm"))
	{	if(20!=iPage)
		{	LoadFromResource(IDR_HTML_UNPARJPLGN_EnumDirectoryS8);
			pbCancel = &myCancel;
			iPage = 20;
			iList = 21;
 	}	}
	else if(!strcmp(lpszTargetFrameNameP,"�������������%20��������%20������%20Unpack$28.htm") ||
			!strcmp(lpszURLP,"�������������%20��������%20������%20Unpack$28.htm"))
	{	if(21!=iPage)
		{	LoadFromResource(IDR_HTML_UNPARJPLGN_UnpackS28);
			pbCancel = &myCancel;
			iPage = 21;
			iList = 22;
 	}	}
	else if(!strcmp(lpszTargetFrameNameP,"�������������%20��������%20������%20callback%20addItemToPanelList.htm") ||
			!strcmp(lpszURLP,"�������������%20��������%20������%20callback%20addItemToPanelList.htm"))
	{	if(22!=iPage)
		{	LoadFromResource(IDR_HTML_UNPARJPLGNCLBK_addItemToPanelList);
			pbCancel = &myCancel;
			iPage = 22;
			iList = 23;
 	}	}
	else if(!strcmp(lpszTargetFrameNameP,"�����%20��%20�������.htm") ||
			!strcmp(lpszURLP,"�����%20��%20�������.htm"))
	{	if(23!=iPage)
		{	LoadFromResource(IDR_HTML_SEARCHPLGNS);
			pbCancel = &myCancel;
			iPage = 23;
			iList = 24;
 	}	}
	else if(!strcmp(lpszTargetFrameNameP,"���������%20������%20GetPluginType.htm") ||
			!strcmp(lpszURLP,"���������%20������%20GetPluginType.htm"))
	{	if(24!=iPage)
		{	LoadFromResource(IDR_HTML_SEARCHPLGN_GetPluginType);
			pbCancel = &myCancel;
			iPage = 24;
			iList = 25;
 	}	}
	else if(!strcmp(lpszTargetFrameNameP,"���������%20������%20SearchForContainText$12.htm") ||
			!strcmp(lpszURLP,"���������%20������%20SearchForContainText$12.htm"))
	{	if(25!=iPage)
		{	LoadFromResource(IDR_HTML_SEARCHPLGN_SearchForContainTextS12);
			pbCancel = &myCancel;
			iPage = 25;
			iList = 26;
 	}	}
	else if(!strcmp(lpszTargetFrameNameP,"���������%20������%20SetId$4.htm") ||
			!strcmp(lpszURLP,"���������%20������%20SetId$4.htm"))
	{	if(26!=iPage)
		{	LoadFromResource(IDR_HTML_SEARCHPLGN_SetIdS4);
			pbCancel = &myCancel;
			iPage = 26;
			iList = 27;
 	}	}
	else if(!strcmp(lpszTargetFrameNameP,"���������%20������%20SearchForNotContainText$12.htm") ||
			!strcmp(lpszURLP,"���������%20������%20SearchForNotContainText$12.htm"))
	{	if(27!=iPage)
		{	LoadFromResource(IDR_HTML_SEARCHPLGN_SearchForNotContainTextS12);
			pbCancel = &myCancel;
			iPage = 27;
			iList = 28;
 	}	}
	else if(!strcmp(lpszTargetFrameNameP,"���������%20������%20SearchForContainTextW$12.htm") ||
			!strcmp(lpszURLP,"���������%20������%20SearchForContainTextW$12.htm"))
	{	if(28!=iPage)
		{	LoadFromResource(IDR_HTML_SEARCHPLGN_SearchForContainTextWS12);
			pbCancel = &myCancel;
			iPage = 28;
			iList = 29;
 	}	}
	else if(!strcmp(lpszTargetFrameNameP,"���������%20������%20SearchForNotContainTextW$12.htm") ||
			!strcmp(lpszURLP,"���������%20������%20SearchForNotContainTextW$12.htm"))
	{	if(29!=iPage)
		{	LoadFromResource(IDR_HTML_SEARCHPLGN_SearchForNotContainTextWS12);
			pbCancel = &myCancel;
			iPage = 29;
			iList = 30;
 	}	}
	else if(!strcmp(lpszTargetFrameNameP,"���������%20������%20SetCallbacks$4xxx.htm") ||
			!strcmp(lpszURLP,"���������%20������%20SetCallbacks$4xxx.htm"))
	{	if(30!=iPage)
		{	LoadFromResource(IDR_HTML_SEARCHPLGN_SetCallbacksS4xxx);
			pbCancel = &myCancel;
			iPage = 30;
			iList = 31;
 	}	}
	else if(!strcmp(lpszTargetFrameNameP,"���������%20������%20QSearchFrList$8.htm") ||
			!strcmp(lpszURLP,"���������%20������%20QSearchFrList$8.htm"))
	{	if(31!=iPage)
		{	LoadFromResource(IDR_HTML_SEARCHPLGN_QSearchFrListS8);
			pbCancel = &myCancel;
			iPage = 31;
			iList = 32;
 	}	}
	else if(!strcmp(lpszTargetFrameNameP,"���������%20������%20ShowSearchDlg$8.htm") ||
			!strcmp(lpszURLP,"���������%20������%20ShowSearchDlg$8.htm"))
	{	if(32!=iPage)
		{	LoadFromResource(IDR_HTML_SEARCHPLGN_ShowSearchFrPathDlgS8);
			pbCancel = &myCancel;
			iPage = 32;
			iList = 33;
 	}	}
	else if(!strcmp(lpszTargetFrameNameP,"�������������%20��������%20������%20ShowSearchDlg$12.htm") ||
			!strcmp(lpszURLP,"�������������%20��������%20������%20ShowSearchDlg$12.htm"))
	{	if(33!=iPage)
		{	LoadFromResource(IDR_HTML_UNPARJPLGN_ShowSearchFrPathDlgS12);
			pbCancel = &myCancel;
			iPage = 33;
			iList = 34;
 	}	}
	else if(!strcmp(lpszTargetFrameNameP,"�������%20����%20callback%20getCrntPanelNum.htm") ||
			!strcmp(lpszURLP,"�������%20����%20callback%20getCrntPanelNum.htm"))
	{	if(38!=iPage)
		{	LoadFromResource(IDR_HTML_MENU_UTIL_CALLBACK_getCrntPanelNum);
			pbCancel = &myCancel;
			iPage = 38;
			iList = 39;
 	}	}
	else if(!strcmp(lpszTargetFrameNameP,"�������%20����%20callback%20getPanelCrntItem.htm") ||
			!strcmp(lpszURLP,"�������%20����%20callback%20getPanelCrntItem.htm"))
	{	if(39!=iPage)
		{	LoadFromResource(IDR_HTML_MENU_UTIL_CALLBACK_getPanelCrntItem);
			pbCancel = &myCancel;
			iPage = 39;
			iList = 40;
 	}	}
	else if(!strcmp(lpszTargetFrameNameP,"�������%20����%20callback%20getPanelPath.htm") ||
			!strcmp(lpszURLP,"�������%20����%20callback%20getPanelPath.htm"))
	{	if(40!=iPage)
		{	LoadFromResource(IDR_HTML_MENU_UTIL_CALLBACK_getPanelPath);
			pbCancel = &myCancel;
			iPage = 40;
			iList = 41;
 	}	}
	else if(!strcmp(lpszTargetFrameNameP,"�������%20����%20callback%20getPanelSelectedItems.htm") ||
			!strcmp(lpszURLP,"�������%20����%20callback%20getPanelSelectedItems.htm"))
	{	if(41!=iPage)
		{	LoadFromResource(IDR_HTML_MENU_UTIL_CALLBACK_getPanelSelectedItems);
			pbCancel = &myCancel;
			iPage = 41;
			iList = 42;
 	}	}
	else if(!strcmp(lpszTargetFrameNameP,"�������%20����%20callback%20readOptions.htm") ||
			!strcmp(lpszURLP,"�������%20����%20callback%20readOptions.htm"))
	{	if(42!=iPage)
		{	LoadFromResource(IDR_HTML_MENU_UTIL_CALLBACK_readOptions);
			pbCancel = &myCancel;
			iPage = 42;
			iList = 43;
 	}	}
	else if(!strcmp(lpszTargetFrameNameP,"�������%20����%20callback%20saveOptions.htm") ||
			!strcmp(lpszURLP,"�������%20����%20callback%20saveOptions.htm"))
	{	if(43!=iPage)
		{	LoadFromResource(IDR_HTML_MENU_UTIL_CALLBACK_saveOptions);
			pbCancel = &myCancel;
			iPage = 43;
			iList = 44;
 	}	}
	else if(!strcmp(lpszTargetFrameNameP,"�������%20����%20GetMenuItemText.htm") ||
			!strcmp(lpszURLP,"�������%20����%20GetMenuItemText.htm"))
	{	if(44!=iPage)
		{	LoadFromResource(IDR_HTML_MENU_UTIL_GetMenuItemText);
			pbCancel = &myCancel;
			iPage = 44;
			iList = 45;
 	}	}
	else if(!strcmp(lpszTargetFrameNameP,"�������%20����%20GetMenuNum.htm") ||
			!strcmp(lpszURLP,"�������%20����%20GetMenuNum.htm"))
	{	if(45!=iPage)
		{	LoadFromResource(IDR_HTML_MENU_UTIL_GetMenuNum);
			pbCancel = &myCancel;
			iPage = 45;
			iList = 46;
 	}	}
	else if(!strcmp(lpszTargetFrameNameP,"�������%20����%20GetMenuPos.htm") ||
			!strcmp(lpszURLP,"�������%20����%20GetMenuPos.htm"))
	{	if(46!=iPage)
		{	LoadFromResource(IDR_HTML_MENU_UTIL_GetMenuPos);
			pbCancel = &myCancel;
			iPage = 46;
			iList = 47;
 	}	}
	else if(!strcmp(lpszTargetFrameNameP,"�������%20����%20GetMenuText.htm") ||
			!strcmp(lpszURLP,"�������%20����%20GetMenuText.htm"))
	{	if(47!=iPage)
		{	LoadFromResource(IDR_HTML_MENU_UTIL_GetMenuText);
			pbCancel = &myCancel;
			iPage = 47;
			iList = 48;
 	}	}
	else if(!strcmp(lpszTargetFrameNameP,"�������%20����%20GetPluginName.htm") ||
			!strcmp(lpszURLP,"�������%20����%20GetPluginName.htm"))
	{	if(48!=iPage)
		{	LoadFromResource(IDR_HTML_MENU_UTIL_GetPluginName);
			pbCancel = &myCancel;
			iPage = 48;
			iList = 49;
 	}	}
	else if(!strcmp(lpszTargetFrameNameP,"�������%20����%20GetPluginType.htm") ||
			!strcmp(lpszURLP,"�������%20����%20GetPluginType.htm"))
	{	if(49!=iPage)
		{	LoadFromResource(IDR_HTML_MENU_UTIL_GetPluginType);
			pbCancel = &myCancel;
			iPage = 49;
			iList = 50;
 	}	}
	else if(!strcmp(lpszTargetFrameNameP,"�������%20����%20RunS4.htm") ||
			!strcmp(lpszURLP,"�������%20����%20RunS4.htm"))
	{	if(50!=iPage)
		{	LoadFromResource(IDR_HTML_MENU_UTIL_RunS4);
			pbCancel = &myCancel;
			iPage = 50;
			iList = 51;
 	}	}
	else if(!strcmp(lpszTargetFrameNameP,"�������%20����%20SetCallbacks$4xxx.htm") ||
			!strcmp(lpszURLP,"�������%20����%20SetCallbacks$4xxx.htm"))
	{	if(51!=iPage)
		{	LoadFromResource(IDR_HTML_MENU_UTIL_IDR_SetCallbacksS4xxx);
			pbCancel = &myCancel;
			iPage = 51;
			iList = 52;
 	}	}
	else if(!strcmp(lpszTargetFrameNameP,"�������%20����%20SetId$4.htm") ||
			!strcmp(lpszURLP,"�������%20����%20SetId$4.htm"))
	{	if(52!=iPage)
		{	LoadFromResource(IDR_HTML_MENU_UTIL_SetIdS4);
			pbCancel = &myCancel;
			iPage = 52;
			iList = 53;
 	}	}
	else if(!strcmp(lpszTargetFrameNameP,"�������%20����.htm") ||
			!strcmp(lpszURLP,"�������%20����.htm"))
	{	if(53!=iPage)
		{	LoadFromResource(IDR_HTML_MENU_UTIL);
			pbCancel = &myCancel;
			iPage = 53;
			iList = 54;
 	}	}
	else if(!strcmp(lpszTargetFrameNameP,"�������%20����%20callback%20getTotalPanels.htm") ||
			!strcmp(lpszURLP,"�������%20����%20callback%20getTotalPanels.htm"))
	{	if(54!=iPage)
		{	LoadFromResource(IDR_HTML_MENU_UTIL_CALLBACK_getTotalPanels);
			pbCancel = &myCancel;
			iPage = 54;
			iList = 55;
 	}	}
	else if(!strcmp(lpszTargetFrameNameP,"��������%20������%20AddEmptyDir$20.htm") ||
			!strcmp(lpszURLP,"��������%20������%20AddEmptyDir$20.htm"))
	{	if(55!=iPage)
		{	LoadFromResource(IDR_HTML_ARJPLGN_AddEmptyDirS20);
			pbCancel = &myCancel;
			iPage = 55;
			iList = 56;
 	}	}
	else if(!strcmp(lpszTargetFrameNameP,"Image plugins.htm") ||
			!strcmp(lpszURLP,"Image plugins.htm"))
	{	if(57!=iPage)
		{	LoadFromResource(IDR_HTML_IMAGE_PLGNS);
			pbCancel = &myCancel;
			iPage = 57;
			iList = 58;
 	}	}
	else if(!strcmp(lpszTargetFrameNameP,"Virtual panel plugins.htm") ||
			!strcmp(lpszURLP,"Virtual panel plugins.htm"))
	{	if(58!=iPage)
		{	LoadFromResource(IDR_HTML_VIRT_PANEL_PLGNS);
			pbCancel = &myCancel;
			iPage = 58;
			iList = 59;
 	}	}
	else if(!strcmp(lpszTargetFrameNameP,"Executable view(edit) plugins.htm") ||
			!strcmp(lpszURLP,"Executable view(edit) plugins.htm"))
	{	if(59!=iPage)
		{	LoadFromResource(IDR_HTML_EXEC_VIEW_EDIT_PLGNS);
			pbCancel = &myCancel;
			iPage = 59;
			iList = 60;
 	}	}
	else if(!strcmp(lpszTargetFrameNameP,"Quick view plugins.htm") ||
			!strcmp(lpszURLP,"Quick view plugins.htm"))
	{	if(60!=iPage)
		{	LoadFromResource(IDR_HTML_QUICK_VIEW_PLGNS);
			pbCancel = &myCancel;
			iPage = 60;
			iList = 61;
 	}	}
	else if(!strcmp(lpszTargetFrameNameP,"Executable utilities.htm") ||
			!strcmp(lpszURLP,"Executable utilities.htm"))
	{	if(61!=iPage)
		{	LoadFromResource(IDR_HTML_EXEC_UTILS_PLGNS);
			pbCancel = &myCancel;
			iPage = 61;
			iList = 62;
 }	}	}
 else
 {	
Sl:
	if(htmNameAsInt>0)
	{	switch(htmNameAsInt)
		{	case IDR_HTML_SODERJANIYE:
				iPage = 0; iList = 0; break;
			case IDR_HTML_O_PROGRAMME:
				iPage = 1; iList = 1; break;
			case IDR_HTML_PLAGINY:
				iPage = 2; iList = 2; break;
			case IDR_HTML_ARXIVNIYE_PLAGINY:
				iPage = 3; iList = 4; break;
			case IDR_HTML_ARJPLGN_GetPluginType:
				iPage = 4; iList = 5; break;
			case IDR_HTML_ARJPLGN_OpenS12:
				iPage = 5; iList = 6; break;
			case IDR_HTML_ARJPLGN_CloseS4:
				iPage = 6; iList = 7; break;
			case IDR_HTML_ARJPLGN_AddS24:
				iPage = 7; iList = 8; break;
			case IDR_HTML_ARJPLGN_CreateDirS24:
				iPage = 8; iList = 9; break;
			case IDR_HTML_ARJPLGN_RebuildCheckExistingsS8:
				iPage = 9; iList = 10; break;
			case IDR_HTML_ARJPLGN_RenameFileS12:
				iPage = 11; iList = 11; break;
			case IDR_HTML_ARJPLGN_RenameDirS12:
				iPage = 12; iList = 12; break;
			case IDR_HTML_ARJPLGN_DeleteFileS8:
				iPage = 13; iList = 13; break;
			case IDR_HTML_ARJPLGN_DeleteDirS8:
				iPage = 14; iList = 14; break;
			case IDR_HTML_ARJPLGN_SetCallbacksS4xxx:
				iPage = 15; iList = 15; break;
			case IDR_HTML_ARJPLGNCLBK_checkFileInSelctn:
				iPage = 16; iList = 16; break;
			case IDR_HTML_ARJPLGNCLBK_excldFileFrSelctn:
				iPage = 17; iList = 17; break;
			case IDR_HTML_ARJPLGNCLBK_getFileInfoFromSelection:
				iPage = 18; iList = 18; break;
			case IDR_HTML_ARJPLGNCLBK_prgrssRout:
				iPage = 19; iList = 19; break;
			case IDR_HTML_ARJPLGNCLBK_showDlgOverwriteExistFile:
				iPage = 20; iList = 20; break;
			case IDR_HTML_ARJPLGNCLBK_saveOptions:
				iPage = 22; iList = 21; break;
			case IDR_HTML_ARJPLGNCLBK_readOptions:
				iPage = 23; iList = 22; break;
			case IDR_HTML_ARJPLGN_AddEmptyDirS20:
				iPage = 24; iList = 23; break;
			//Unpack arj:
			case IDR_HTML_RASP_ARXIVNIYE_PLAGINY:
				iPage = 25; iList = 24; break;
			case IDR_HTML_UNPARJPLGN_OpenForUnpackingS8:
				iPage = 26; iList = 25; break;
			case IDR_HTML_UNPARJPLGN_EnumDirectoryS8:
				iPage = 27; iList = 26; break;
			case IDR_HTML_UNPARJPLGN_UnpackS28:
				iPage = 28; iList = 27; break;
			case IDR_HTML_UNPARJPLGNCLBK_addItemToPanelList:
				iPage = 29; iList = 28; break;
			case IDR_HTML_UNPARJPLGN_ShowSearchFrPathDlgS12:
				iPage = 30; iList = 29; break;
			//Auxilary plugins:
			//Search plugin:
			case IDR_HTML_SEARCHPLGNS:
				iPage = 32; iList = 31; break;
			case IDR_HTML_SEARCHPLGN_GetPluginType:
				iPage = 33; iList = 32; break;
			case IDR_HTML_SEARCHPLGN_SearchForContainTextS12:
				iPage = 34; iList = 33; break;
			case IDR_HTML_SEARCHPLGN_SetIdS4:
				iPage = 35; iList = 34; break;
			case IDR_HTML_SEARCHPLGN_SearchForNotContainTextS12:
				iPage = 36; iList = 35; break;
			case IDR_HTML_SEARCHPLGN_SearchForContainTextWS12:
				iPage = 37; iList = 36; break;
			case IDR_HTML_SEARCHPLGN_SearchForNotContainTextWS12:
				iPage = 38; iList = 37; break;
			case IDR_HTML_SEARCHPLGN_SetCallbacksS4xxx:
				iPage = 39; iList = 38; break;
			case IDR_HTML_SEARCHPLGN_QSearchFrListS8:
				iPage = 40; iList = 39; break;
			case IDR_HTML_SEARCHPLGN_ShowSearchFrPathDlgS8:
				iPage = 41; iList = 40; break;
			//menu utils:
			case IDR_HTML_MENU_UTIL:
				iPage = 42; iList = 41; break;
			case IDR_HTML_MENU_UTIL_CALLBACK_getCrntPanelNum:
				iPage = 43; iList = 42; break;
			case IDR_HTML_MENU_UTIL_CALLBACK_getPanelCrntItem:
				iPage = 44; iList = 43; break;
			case IDR_HTML_MENU_UTIL_CALLBACK_getPanelPath:
				iPage = 45; iList = 44; break;
			case IDR_HTML_MENU_UTIL_CALLBACK_getPanelSelectedItems:
				iPage = 46; iList = 45; break;
			case IDR_HTML_MENU_UTIL_CALLBACK_readOptions:
				iPage = 47; iList = 46; break;
			case IDR_HTML_MENU_UTIL_CALLBACK_saveOptions:
				iPage = 48; iList = 47; break;
			case IDR_HTML_MENU_UTIL_GetMenuItemText:
				iPage = 49; iList = 48; break;
			case IDR_HTML_MENU_UTIL_GetMenuNum:
				iPage = 50; iList = 49; break;
			case IDR_HTML_MENU_UTIL_GetMenuPos:
				iPage = 51; iList = 50; break;
			case IDR_HTML_MENU_UTIL_GetMenuText:
				iPage = 52; iList = 51; break;
			case IDR_HTML_MENU_UTIL_GetPluginName:
				iPage = 53; iList = 52; break;
			case IDR_HTML_MENU_UTIL_GetPluginType:
				iPage = 54; iList = 53; break;
			case IDR_HTML_MENU_UTIL_RunS4:
				iPage = 55; iList = 54; break;
			case IDR_HTML_MENU_UTIL_IDR_SetCallbacksS4xxx:
				iPage = 56; iList = 55; break;
			case IDR_HTML_MENU_UTIL_SetIdS4:
				iPage = 57; iList = 56; break;
			case IDR_HTML_MENU_UTIL_CALLBACK_getTotalPanels:
				iPage = 58; iList = 57; break;
			case IDR_HTML_IMAGE_PLGNS:
				iPage = 59; iList = 57; break;
			case IDR_HTML_VIRT_PANEL_PLGNS:
				iPage = 60; iList = 58; break;
			case IDR_HTML_EXEC_VIEW_EDIT_PLGNS:
				iPage = 61; iList = 59; break;
			case IDR_HTML_QUICK_VIEW_PLGNS:
				iPage = 62; iList = 60; break;
			case IDR_HTML_EXEC_UTILS_PLGNS:
				iPage = 63; iList = 61; break;
}	}	}

 if(listType==contents)//Qaytib otasini bossa Navigate ishlashi uhun;
 {	if(htmNameAsInt==0)
	{	if(beforeNavigateType==fromHtmlElement || beforeNavigateType==fromContentsButton)
			listView->SelectItem(iList);
 }	}

//if(p!=iPage)
//if(!(beforeNavigateType==fromContentsButton || beforeNavigateType==fromIndexButton || beforeNavigateType==fromSearchButton))
//	PushStep(p);

 beforeNavigateType = fromHtmlElement;
}

void CSinoSHlp32View::OnInitialUpdate()
{
	htmlView = this;
	CHtmlView::OnInitialUpdate();
	//LoadFromResource(IDR_HTML_SODERJANIYE);//Navigate2(_T("http://www.msdn.microsoft.com/visualc/"),NULL,NULL);
}

BOOL CSinoSHlp32View::OnPrevBtnPressed()
{
	if(11==iPage)
		NavigatePage(9);
	else if(12==iPage)
		NavigatePage(10);
	else if(22==iPage)
		NavigatePage(20);
	else if(23==iPage)
		NavigatePage(21);
	else if(32==iPage)
		NavigatePage(30);
	else if(33==iPage)
		NavigatePage(31);
	else if(59==iPage)
		NavigatePage(57);
	else if(60==iPage)
		NavigatePage(58);
	else if(iPage>0)
		NavigatePage(iPage-1);;
	return TRUE;
/*	switch(listType)
	{	case contents:
			if(iPage>0)
			{	NavigatePage(iPage-1,TRUE,contents);
				return TRUE;
			}
			break;
		case index:
			if(iPage>0)
			{	NavigatePage(iPageIndex-1,TRUE,index);
				return TRUE;
			}
			break;
		case search:
			if(iPageSearch>0)
			{	NavigatePage(iPageSearch-1,TRUE,search);
				return TRUE;
			}
			break;
	}*/
	return FALSE;
}

BOOL CSinoSHlp32View::OnNextBtnPressed()
{
	if(iPage<MAX_HTMLS+2)
	{	NavigatePage(iPage+1);//,TRUE);
		return TRUE;
	}
/*	switch(listType)
	{	case contents:
			if(iPage<MAX_HTMPLS)
			{	NavigatePage(iPage+1,TRUE,contents);
				return TRUE;
			}
			break;
		case index:
			if(iPageIndex<MAX_HTMPLS)
			{	NavigatePage(iPageIndex+1,TRUE,index);
				return TRUE;
			}
			break;
		case search:
			if(iPageSearch<MAX_HTMPLS)
			{	NavigatePage(iPageSearch+1,TRUE,search);
				return TRUE;
			}
			break;
	}*/
	return FALSE;
}

BOOL CSinoSHlp32View::OnPrevStepBtnPressed()
{
/*	if(iStep>0)
	{	PopStep(iPage);
		//switch(listType)
		//{	case contents:
		//		PopStep(iPage);
		//		break;
		//	case index:
		//		PopStep(index,iPageIndex);
		//		break;
		//	case search:
		//		PopStep(search,iPageSearch);
		//		break;
		//}
		NavigatePage(steps[iStep],FALSE);
		//listView->SetPage(steps[iStep].listType,steps[iStep].i); nav gapening o'zida bor;
		return TRUE;
	}
	*/
	GoBack();
	/*CString s = GetLocationName();
	const char *p=strrchr(s,'/');
	if(p)
	{	int ip = atoi(p+1);
		if(ip>0 && ip<200)
			GoBack();//htmlView->LoadFromResource(ip);
	}*/
	listView->SelectItem(iList);
	return TRUE;//FALSE;
}

BOOL CSinoSHlp32View::OnNextStepBtnPressed()
{
/*	if(iStep<MAX_STEPS && steps[iStep+1]>-1)
	{	++iStep;
		NavigatePage(steps[iStep],FALSE);
		//listView->SetPage(steps[iStep].listType,steps[iStep]);
	}*/
	GoForward();
	/*CString s = GetLocationName();
	const char *p=strrchr(s,'/');
	if(p)
	{	int ip = atoi(p+1);
		if(ip>0 && ip<200)
			;//GoForward();//htmlView->LoadFromResource(ip);
	}*/
	listView->SelectItem(iList);
	return TRUE;//FALSE;
}

INT_PTR CALLBACK FindTextDlgProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
RECT rc,rcPrnt;
//char s[260];
int width,left,height,top;

	UNREFERENCED_PARAMETER(lParam);
	switch (message)
	{
	case WM_INITDIALOG:
		GetWindowRect(hDlg, &rc);
		HWND prnt;prnt = GetParent(hDlg);
		if(!prnt)prnt=GetDesktopWindow();
		GetWindowRect(prnt, &rcPrnt);
		width = rc.right - rc.left;		
		left = rcPrnt.right- width;
		height = rc.bottom - rc.top;
		top = rcPrnt.top;
		MoveWindow(hDlg, left, top+20, width, height, TRUE);

		SetDlgItemText(hDlg,IDC_EDIT_FIND_TEXT,mainFrame->schText);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_FIND_TEXT),EM_SETSEL,0,-1);
		return (INT_PTR)TRUE;
	case WM_DESTROY:
		htmlView->findTxtDlg = NULL;
		break;
	case WM_COMMAND:
		switch(LOWORD(wParam))
		{	case IDCANCEL:
				DestroyWindow(hDlg);
				return (INT_PTR)FALSE;
			case IDOK://Find next
				char s[128];if(GetDlgItemText(hDlg,IDC_EDIT_FIND_TEXT,s,128))
				{	CString c(s);
					int fr=mainFrame->FindText(c,4,FALSE);
					if(-1==fr) DestroyWindow(hDlg);
					else if(0==fr)
					{	if(IDYES!=MessageBox(hDlg,"Want you to continue find process?","Search rich to end mark.",MB_YESNO))
							DestroyWindow(hDlg);
				}	}
				return (INT_PTR)FALSE;
		}
		break;
	}
	return (INT_PTR)FALSE;
}

INT_PTR CALLBACK FindTextInAllHTMLsDlgProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
RECT rc;
//char s[260];
int width,left,height,top;

	UNREFERENCED_PARAMETER(lParam);
	switch (message)
	{
	case WM_INITDIALOG:
		GetWindowRect(hDlg, &rc);
		width = rc.right - rc.left;		
		left = (GetSystemMetrics(SM_CXFULLSCREEN) - width)/2;
		height = rc.bottom - rc.top;
		top = (GetSystemMetrics(SM_CYFULLSCREEN) - height)/2;
		MoveWindow(hDlg, left, top+20, width, height, TRUE);

		SetDlgItemText(hDlg,IDOK,"Find all");
		SetDlgItemText(hDlg,IDC_EDIT_FIND_TEXT,mainFrame->schText);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_FIND_TEXT),EM_SETSEL,0,-1);
		return (INT_PTR)TRUE;
	case WM_DESTROY:
		htmlView->findTxtDlg = NULL;
		break;
	case WM_COMMAND:
		switch(LOWORD(wParam))
		{	case IDCANCEL:
				DestroyWindow(hDlg);
				return (INT_PTR)FALSE;
			case IDOK://Find next
				char s[128];if(GetDlgItemText(hDlg,IDC_EDIT_FIND_TEXT,s,128))
				{	CString c(s);
					DestroyWindow(hDlg);
					mainFrame->BeginFindTextInAllHTMLs(c,4,FALSE);
				}
				return (INT_PTR)FALSE;
		}
		break;
	}
	return (INT_PTR)FALSE;
}

BOOL CSinoSHlp32View::OnFindTextBtnPressed()
{
	findTxtDlg=CreateDialog(AfxGetInstanceHandle(),MAKEINTRESOURCE(IDD_DIALOG_FIND_TEXT),
							m_hWnd,FindTextDlgProc);
	::ShowWindow(findTxtDlg,SW_SHOW);
	//GoSearch(); internetdan;
	//TCHAR vinp[] = _T("");
	//ExecWB(OLECMDID_FIND,OLECMDEXECOPT_PROMPTUSER,(VARIANT*)&vinp,NULL);
	return TRUE;
}

BOOL CSinoSHlp32View::OnSearchTextBtnPressed()
{
	findTxtDlg=CreateDialog(AfxGetInstanceHandle(),MAKEINTRESOURCE(IDD_DIALOG_FIND_TEXT),
							m_hWnd,FindTextInAllHTMLsDlgProc);
	::ShowWindow(findTxtDlg,SW_SHOW);
	return TRUE;
}

LPCTSTR CSinoSHlp32View::GetHTMLName(UINT uiRes,int t)
{
	if(uiRes!=0)
	{	switch(uiRes)
		{	case IDR_HTML_SODERJANIYE:
				return "Contents";
			case IDR_HTML_O_PROGRAMME:
				return "About program 'Sino'";
			case IDR_HTML_PLAGINY:
				return "How to create plugins...";
			case IDR_HTML_ARXIVNIYE_PLAGINY:
				return "Packing archives...";//�������� �������";
			case IDR_HTML_ARJPLGN_GetPluginType:
				return "Procedure GetPluginType";
			case IDR_HTML_ARJPLGN_OpenS12:
				return "Procedure Open$12";
			case IDR_HTML_ARJPLGN_CloseS4:
				return "Procedure Close$4";
			case IDR_HTML_ARJPLGN_AddS24:
				return "Procedure Add$24";
			case IDR_HTML_ARJPLGN_CreateDirS24:
				return "Procedure CreateDir$24";
			case IDR_HTML_ARJPLGN_RebuildCheckExistingsS8:
				return "Procedure RebuildCheckExistings$8";
			case IDR_HTML_ARJPLGN_RenameFileS12:
				return "Procedure RenameFile$12";
			case IDR_HTML_ARJPLGN_RenameDirS12:
				return "Procedure RenameDir$12";
			case IDR_HTML_ARJPLGN_DeleteFileS8:
				return "Procedure DeleteFile$8";
			case IDR_HTML_ARJPLGN_DeleteDirS8:
				return "Procedure DeleteDir$8";
			case IDR_HTML_ARJPLGN_SetCallbacksS4xxx:
				return "Procedure SetCallbacks$4xxx";
			case IDR_HTML_ARJPLGNCLBK_checkFileInSelctn:
				return "Callback checkFileInSelctn";
			case IDR_HTML_ARJPLGNCLBK_excldFileFrSelctn:
				return "Callback excldFileFrSelctn";
			case IDR_HTML_ARJPLGNCLBK_getFileInfoFromSelection:
				return "Callback getFileInfoFromSelection";
			case IDR_HTML_ARJPLGNCLBK_prgrssRout:
				return "Callback prgrssRout";
			case IDR_HTML_ARJPLGNCLBK_showDlgOverwriteExistFile:
				return "Callback showDlgOverwriteExistFile";
			case IDR_HTML_ARJPLGNCLBK_saveOptions:
				return "Callback saveOptions";
			case IDR_HTML_ARJPLGNCLBK_readOptions:
				return "Callback readOptions";
			case IDR_HTML_ARJPLGN_AddEmptyDirS20:
				return "Procedure AddEmptyDir$20";
			//Unpack arj:
			case IDR_HTML_RASP_ARXIVNIYE_PLAGINY:
				return "Unpacking archive...";
			case IDR_HTML_UNPARJPLGN_OpenForUnpackingS8:
				return "Procedure OpenForUnpacking$8";
			case IDR_HTML_UNPARJPLGN_EnumDirectoryS8:
				return "Procedure EnumDirectory$8";
			case IDR_HTML_UNPARJPLGN_UnpackS28:
				return "Procedure Unpack$28";
			case IDR_HTML_UNPARJPLGNCLBK_addItemToPanelList:
				return "Callback addItemToPanelList";
			case IDR_HTML_UNPARJPLGN_ShowSearchFrPathDlgS12:
				return "Procedure ShowSearchDlg$12";
			case IDR_HTML_SEARCHPLGNS:
				return "Search plugin...";
			case IDR_HTML_SEARCHPLGN_GetPluginType:
				return "Search plugin:Procedure GetPluginType";
			case IDR_HTML_SEARCHPLGN_SearchForContainTextS12:
				return "Procedure SearchForContainText$12";
			case IDR_HTML_SEARCHPLGN_SetIdS4:
				return "Procedure SetId$4";
			case IDR_HTML_SEARCHPLGN_SearchForNotContainTextS12:
				return "Procedure SearchForNotContainText$12";
			case IDR_HTML_SEARCHPLGN_SearchForContainTextWS12:
				return "Procedure SearchForContainTextW$12";
			case IDR_HTML_SEARCHPLGN_SearchForNotContainTextWS12:
				return "Procedure SearchForNotContainTextW$12";
			case IDR_HTML_SEARCHPLGN_SetCallbacksS4xxx:
				return "Search plugin:Procedure SetCallbacks$4xxx";
			case IDR_HTML_SEARCHPLGN_QSearchFrListS8:
				return "Procedure QSearchFrList$8";
			case IDR_HTML_SEARCHPLGN_ShowSearchFrPathDlgS8:
				return "Procedure ShowSearchDlg$8";
			case IDR_HTML_MENU_UTIL_CALLBACK_getCrntPanelNum:
				return "Callback getCrntPanelNum";
			case IDR_HTML_MENU_UTIL_CALLBACK_getPanelCrntItem:
				return "Callback getPanelCrntItem";
			case IDR_HTML_MENU_UTIL_CALLBACK_getPanelPath:
				return "Callback getPanelPath";
			case IDR_HTML_MENU_UTIL_CALLBACK_getPanelSelectedItems:
				return "Callback getPanelSelectedItems";
			case IDR_HTML_MENU_UTIL_CALLBACK_readOptions:
				return "Menu utility: callback readOptions";
			case IDR_HTML_MENU_UTIL_CALLBACK_saveOptions:
				return "Menu utility: callback saveOptions";
			case IDR_HTML_MENU_UTIL_GetMenuItemText:
				return "Procedure GetMenuItemText";
			case IDR_HTML_MENU_UTIL_GetMenuNum:
				return "Procedure GetMenuNum";
			case IDR_HTML_MENU_UTIL_GetMenuPos:
				return "Procedure GetMenuPos";
			case IDR_HTML_MENU_UTIL_GetMenuText:
				return "Procedure GetMenuText";
			case IDR_HTML_MENU_UTIL_GetPluginName:
				return "Procedure GetPluginName";
			case IDR_HTML_MENU_UTIL_GetPluginType:
				return "Menu utility: Procedure GetPluginType";
			case IDR_HTML_MENU_UTIL_RunS4:
				return "Procedure Run$4";
			case IDR_HTML_MENU_UTIL_IDR_SetCallbacksS4xxx:
				return "Menu utility: Procedure SetCallbacks$4xxx";
			case IDR_HTML_MENU_UTIL_SetIdS4:
				return "Menu utility: Procedure SetId$4";
			case IDR_HTML_MENU_UTIL:
				return "Menu utility plugins";
			case IDR_HTML_ENVIRONMENT_VARS:
				return "Environment variables";
			case IDR_HTML_IMAGE_PLGNS:
				return "Image view plugins";
			case IDR_HTML_VIRT_PANEL_PLGNS:
				return "Virtual panel plugins";
			case IDR_HTML_EXEC_VIEW_EDIT_PLGNS:
				return "Executable view/edit plugins";
			case IDR_HTML_QUICK_VIEW_PLGNS:
				return "Quick view plugins";
			case IDR_HTML_EXEC_UTILS_PLGNS:
				return "Executable utilities";
	}	}
	else
	{	switch(t)
		{	case 0:
				return "Contents";
			case 1:
				return "About program 'Sino'";
			case 2:
				return "How to create plugins...";
			case 3:
				return "Packing archives...";//�������� �������";
			case 4:
				return "Procedure GetPluginType";
			case 5:
				return "Procedure Open$12";
			case 6:
				return "Procedure Close$4";
			case 7:
				return "Procedure Add$24";
			case 8:
				return "Procedure CreateDir$24";
			case 9:
				return "Procedure RebuildCheckExistings$8";
			case 10:
				return "Procedure SetCallbacks$4xxx";
			case 11:
				return "Callback checkFileInSelctn";
			case 12:
				return "Callback excldFileFrSelctn";
			case 13:
				return "Callback getFileInfoFromSelection";
			case 14:
				return "Callback prgrssRout";
			case 15:
				return "Callback showDlgOverwriteExistFile";
			case 16:
				return "Callback saveOptions";
			case 17:
				return "Callback readOptions";
			//Unpack arj:
			case 18:
				return "Unpacking archive...";
			case 19:
				return "Procedure OpenForUnpacking$8";
			case 20:
				return "Procedure EnumDirectory$8";
			case 21:
				return "Procedure Unpack$28";
			case 22:
				return "Callback addItemToPanelList";
			case 23:
				return "Search plugin...";
			case 24:
				return "Search plugin:Procedure GetPluginType";
			case 25:
				return "Procedure SearchForContainText$12";
			case 26:
				return "Procedure SetId$4";
			case 27:
				return "Procedure SearchForNotContainText$12";
			case 28:
				return "Procedure SearchForContainTextW$12";
			case 29:
				return "Procedure SearchForNotContainTextW$12";
			case 30:
				return "Search plugin:Procedure SetCallbacks$4xxx";
			case 31:
				return "Procedure QSearchFrList$8";
			case 32:
				return "Procedure ShowSearchDlg$8";
			case 33:
				return "Procedure ShowSearchDlg$12";
			case 34:
				return "Procedure RenameFile$12";
			case 35:
				return "Procedure RenameDir$12";
			case 36:
				return "Procedure DeleteFile$8";
			case 37:
				return "Procedure DeleteDir$8";
			case 38:
				return "Callback getCrntPanelNum";
			case 39:
				return "Callback getPanelCrntItem";
			case 40:
				return "Callback getPanelPath";
			case 41:
				return "Callback getPanelSelectedItems";
			case 42:
				return "Menu utility: callback readOptions";
			case 43:
				return "Menu utility: callback saveOptions";
			case 44:
				return "Procedure GetMenuItemText";
			case 45:
				return "Procedure GetMenuNum";
			case 46:
				return "Procedure GetMenuPos";
			case 47:
				return "Procedure GetMenuText";
			case 48:
				return "Procedure GetPluginName";
			case 49:
				return "Menu utility:Procedure GetPluginType";
			case 50:
				return "Procedure Run$4";
			case 51:
				return "Menu utility:Procedure SetCallbacks$4xxx";
			case 52:
				return "Menu utility:Procedure SetId$4";
			case 53:
				return "Menu utility plugins";
			case 54:
				return "Procedure AddEmptyDir$20";
			case 55:
				return "Environment variables";
			case 56:
				return "Image view plugins";
			case 57:
				return "Virtual panel plugins";
			case 58:
				return "Executable view/edit plugins";
			case 59:
				return "Quick view plugins";
			case 60:
				return "Executable utilities";
	}	}
	return NULL;
}

BOOL CSinoSHlp32View::LoadFromResource(LPCTSTR lpszResource)
{
	lstrcpy(tchCrntRes,lpszResource);
	uiCrntRes=0;
	return CHtmlView::LoadFromResource(lpszResource);
}

BOOL CSinoSHlp32View::LoadFromResource(UINT nRes)
{
	uiCrntRes=nRes;
	tchCrntRes[0]=0;
	return CHtmlView::LoadFromResource(nRes);
}

void CSinoSHlp32View::NavigateComplete2(LPDISPATCH pDisp,VARIANT *URL)
{
	return CHtmlView::NavigateComplete2(pDisp,URL);
}

/*void CSinoSHlp32View::MyNavigateComplete2(UINT uiRes)
{
	CHtmlView::NavigateComplete2(GetIDispatch(FALSE),(VARIANT*)GetHTMLName(uiRes,0));
}*/

/*void CSinoSHlp32View::Invalidate(BOOL bErase=1)
{
	return CHtmlView::Invalidate(bErase);
}*/

/*void CSinoSHlp32View::DoDataExchange(CDataExchange *pDX)
{
	return CHtmlView::DoDataExchange(pDX);
}*/

/*void CSinoSHlp32View::NotifyWinEvent(DWORD event,LONG idObjectType,LONG idObject)
{
	return CHtmlView::NotifyWinEvent(event,idObjectType,idObject);
}*/

/*BOOL CSinoSHlp32View::OnCmdMsg(UINT nID,int nCode,void *pExtra,AFX_CMDHANDLERINFO *pHandlerInfo)
{
	return CHtmlView::OnCmdMsg(nID,nCode,pExtra,pHandlerInfo);
}*/

void CSinoSHlp32View::NavigatePage(int p)//,BOOL bRegisterStep)
{
	switch(p)
	{	case 0:
			listView->SelectItem(0);
			LoadFromResource(IDR_HTML_SODERJANIYE);			
			break;
		case 1:
			listView->SelectItem(1);
			LoadFromResource(IDR_HTML_O_PROGRAMME);
			break;
		case 2:
			listView->SelectItem(2);
			LoadFromResource(IDR_HTML_PLAGINY);
			break;
		case 3:
			listView->SelectItem(4);
			LoadFromResource(IDR_HTML_ARXIVNIYE_PLAGINY);
			break;
		case 4:
			listView->SelectItem(5);
			LoadFromResource(IDR_HTML_ARJPLGN_GetPluginType);
			break;
		case 5:
			listView->SelectItem(6);
			LoadFromResource(IDR_HTML_ARJPLGN_OpenS12);
			break;
		case 6:
			listView->SelectItem(7);
			LoadFromResource(IDR_HTML_ARJPLGN_CloseS4);
			break;
		case 7:
			listView->SelectItem(8);
			LoadFromResource(IDR_HTML_ARJPLGN_AddS24);
			break;
		case 8:
			listView->SelectItem(9);
			LoadFromResource(IDR_HTML_ARJPLGN_CreateDirS24);
			break;
		case 9:
			listView->SelectItem(10);
			LoadFromResource(IDR_HTML_ARJPLGN_RebuildCheckExistingsS8);
			break;
		case 10:
			listView->SelectItem(11);
			LoadFromResource(IDR_HTML_ARJPLGN_RenameFileS12);
			break;
		case 12:
			listView->SelectItem(12);
			LoadFromResource(IDR_HTML_ARJPLGN_RenameDirS12);
			break;
		case 13:
			listView->SelectItem(13);
			LoadFromResource(IDR_HTML_ARJPLGN_DeleteFileS8);
			break;
		case 14:
			listView->SelectItem(14);
			LoadFromResource(IDR_HTML_ARJPLGN_DeleteDirS8);
			break;
		case 15:
			listView->SelectItem(15);
			LoadFromResource(IDR_HTML_ARJPLGN_SetCallbacksS4xxx);
			break;
		case 16:
			listView->SelectItem(16);
			LoadFromResource(IDR_HTML_ARJPLGNCLBK_checkFileInSelctn);
			break;
		case 17:
			listView->SelectItem(17);
			LoadFromResource(IDR_HTML_ARJPLGNCLBK_excldFileFrSelctn);
			break;
		case 18:
			listView->SelectItem(18);
			LoadFromResource(IDR_HTML_ARJPLGNCLBK_getFileInfoFromSelection);//IDR_HTML_RASP_ARXIVNIYE_PLAGINY);
			break;
		case 19:
			listView->SelectItem(19);
			LoadFromResource(IDR_HTML_ARJPLGNCLBK_prgrssRout);//IDR_HTML_UNPARJPLGN_OpenForUnpackingS8);
			break;
		case 20:
			listView->SelectItem(20);
			LoadFromResource(IDR_HTML_ARJPLGNCLBK_showDlgOverwriteExistFile);
			break;
		case 21:
			listView->SelectItem(21);
			LoadFromResource(IDR_HTML_ARJPLGNCLBK_saveOptions);
			break;
		case 22:
			listView->SelectItem(22);
			break;
		case 23:
			listView->SelectItem(22);
			LoadFromResource(IDR_HTML_ARJPLGNCLBK_readOptions);
			break;
		case 24:
			listView->SelectItem(23);
			LoadFromResource(IDR_HTML_ARJPLGN_AddEmptyDirS20);
			break;
		case 25:
			listView->SelectItem(24);
			LoadFromResource(IDR_HTML_RASP_ARXIVNIYE_PLAGINY);
			break;
		case 26:
			listView->SelectItem(25);
			LoadFromResource(IDR_HTML_UNPARJPLGN_OpenForUnpackingS8);
			break;
		case 27:
			listView->SelectItem(26);
			LoadFromResource(IDR_HTML_UNPARJPLGN_EnumDirectoryS8);
			break;
		case 28:
			listView->SelectItem(27);
			LoadFromResource(IDR_HTML_UNPARJPLGN_UnpackS28);
			break;
		case 29:
			listView->SelectItem(28);
			LoadFromResource(IDR_HTML_UNPARJPLGNCLBK_addItemToPanelList);
			break;
		case 30:
			listView->SelectItem(29);
			LoadFromResource(IDR_HTML_UNPARJPLGN_ShowSearchFrPathDlgS12);
			break;
		case 31:
			listView->SelectItem(31);
			LoadFromResource(IDR_HTML_SEARCHPLGNS);
			break;
		case 33:
			listView->SelectItem(32);
			LoadFromResource(IDR_HTML_SEARCHPLGN_GetPluginType);
			break;
		case 34:
			listView->SelectItem(33);
			LoadFromResource(IDR_HTML_SEARCHPLGN_SearchForContainTextS12);
			break;
		case 35:
			listView->SelectItem(34);
			LoadFromResource(IDR_HTML_SEARCHPLGN_SetIdS4);
			break;
		case 36:
			listView->SelectItem(35);
			LoadFromResource(IDR_HTML_SEARCHPLGN_SearchForNotContainTextS12);
			break;
		case 37:
			listView->SelectItem(36);
			LoadFromResource(IDR_HTML_SEARCHPLGN_SearchForContainTextWS12);
			break;
		case 38:
			listView->SelectItem(37);
			LoadFromResource(IDR_HTML_SEARCHPLGN_SearchForNotContainTextWS12);
			break;
		case 39:
			listView->SelectItem(38);
			LoadFromResource(IDR_HTML_SEARCHPLGN_SetCallbacksS4xxx);
			break;
		case 40:
			listView->SelectItem(39);
			LoadFromResource(IDR_HTML_SEARCHPLGN_QSearchFrListS8);
			break;
		case 41:
			listView->SelectItem(40);
			LoadFromResource(IDR_HTML_SEARCHPLGN_ShowSearchFrPathDlgS8);
			break;
		case 42:
			listView->SelectItem(41);
			LoadFromResource(IDR_HTML_MENU_UTIL);
			break;
		case 43:
			listView->SelectItem(42);
			LoadFromResource(IDR_HTML_MENU_UTIL_CALLBACK_getCrntPanelNum);
			break;
		case 44:
			listView->SelectItem(43);
			LoadFromResource(IDR_HTML_MENU_UTIL_CALLBACK_getPanelCrntItem);
			break;
		case 45:
			listView->SelectItem(44);
			LoadFromResource(IDR_HTML_MENU_UTIL_CALLBACK_getPanelPath);
			break;
		case 46:
			listView->SelectItem(45);
			LoadFromResource(IDR_HTML_MENU_UTIL_CALLBACK_getPanelSelectedItems);
			break;
		case 47:
			listView->SelectItem(46);
			LoadFromResource(IDR_HTML_MENU_UTIL_CALLBACK_readOptions);
			break;
		case 48:
			listView->SelectItem(47);
			LoadFromResource(IDR_HTML_MENU_UTIL_CALLBACK_saveOptions);
			break;
		case 49:
			listView->SelectItem(48);
			LoadFromResource(IDR_HTML_MENU_UTIL_GetMenuItemText);
			break;
		case 50:
			listView->SelectItem(49);
			LoadFromResource(IDR_HTML_MENU_UTIL_GetMenuNum);
			break;
		case 51:
			listView->SelectItem(50);
			LoadFromResource(IDR_HTML_MENU_UTIL_GetMenuPos);
			break;
		case 52:
			listView->SelectItem(51);
			LoadFromResource(IDR_HTML_MENU_UTIL_GetMenuText);
			break;
		case 53:
			listView->SelectItem(52);
			LoadFromResource(IDR_HTML_MENU_UTIL_GetPluginName);
			break;
		case 54:
			listView->SelectItem(53);
			LoadFromResource(IDR_HTML_MENU_UTIL_GetPluginType);
			break;
		case 55:
			listView->SelectItem(54);
			LoadFromResource(IDR_HTML_MENU_UTIL_RunS4);
			break;
		case 56:
			listView->SelectItem(55);
			LoadFromResource(IDR_HTML_MENU_UTIL_IDR_SetCallbacksS4xxx);
			break;
		case 57:
			listView->SelectItem(56);
			LoadFromResource(IDR_HTML_MENU_UTIL_SetIdS4);
			break;
		case 58:
			listView->SelectItem(57);
			LoadFromResource(IDR_HTML_IMAGE_PLGNS);
			break;
		case 59:
			listView->SelectItem(59);
			LoadFromResource(IDR_HTML_EXEC_VIEW_EDIT_PLGNS);
			break;
		case 60:
			listView->SelectItem(58);
			LoadFromResource(IDR_HTML_VIRT_PANEL_PLGNS);
			break;
		case 61:
			listView->SelectItem(59);
			LoadFromResource(IDR_HTML_EXEC_VIEW_EDIT_PLGNS);
			break;
		case 62:
			listView->SelectItem(60);
			LoadFromResource(IDR_HTML_QUICK_VIEW_PLGNS);
			break;
		case 63:
			listView->SelectItem(61);
			LoadFromResource(IDR_HTML_EXEC_UTILS_PLGNS);
			break;
		case 64:
			listView->SelectItem(62);
			LoadFromResource(IDR_HTML_ENVIRONMENT_VARS);
			break;
	}
	//if(bRegisterStep)
	//	PushStep(iPage);
	iPage = p;
}

void CSinoSHlp32View::ChangeFont(int fontSize)
{
/*HRESULT hr;
LPDISPATCH pDisp = NULL;
LPOLECOMMANDTARGET pCmdTarg = NULL;

	if(!m_hWnd)
		return;

	pDisp = GetHtmlDocument();

	if(!pDisp)
	{	TRACE("Unable to get document from Web Browser.\n");
		return;
	}

	// The document controls the availability of commands items,
	// so get the OLE command target interface from the document
	hr = pDisp->QueryInterface(IID_IOleCommandTarget,(LPVOID*)&pCmdTarg);
	if(pCmdTarg)
	{	// Now use the command target to do something useful
		// like (un-)zoom the page
		OLECMD rgCmd[1] = {{OLECMDID_ZOOM, 0}};
		// Is the command available for execution?
		hr = pCmdTarg->QueryStatus(NULL, 1, rgCmd, NULL);
		if(SUCCEEDED(hr))// && OLECMDF_ENABLED == rgCmd[0].cmdf)
		{	TRACE("Zoom enabled.\n");
			VARIANT vaZoomFactor;   // Input arguments
			VariantInit(&vaZoomFactor);
			V_VT(&vaZoomFactor) = VT_I4;
			V_I4(&vaZoomFactor) = fontSize;
			hr = pCmdTarg->Exec(NULL,OLECMDID_ZOOM,OLECMDEXECOPT_DONTPROMPTUSER,&vaZoomFactor, NULL);
			VariantClear(&vaZoomFactor);
		}
		else
			TRACE("Unable to query for status of command ; (OLECMDID_ZOOM).\n");
	}
	else
		TRACE("Unable to get command target from Web Browser ; document.\n");

	if(pCmdTarg) pCmdTarg->Release(); // release document's command target
	if(pDisp) pDisp->Release(); // release document's dispatch interface
	*/




	/*LPDISPATCH pDisp = GetHtmlDocument();
	if(pDisp)
	{	LPOLECOMMANDTARGET pCmdTarg = NULL;
		pDisp->QueryInterface(IID_IOleCommandTarget, (void**)&pCmdTarg);
		if(pCmdTarg)
		{	COleVariant vaZoomFactor;   // input argument
			V_VT(&vaZoomFactor) = VT_I4;
			V_I4(&vaZoomFactor) = fontSize;   // 0 - 4
			// Change the text size.
			pCmdTarg->Exec(	NULL,
							OLECMDID_ZOOM,
							OLECMDEXECOPT_DONTPROMPTUSER,
							&vaZoomFactor,
							NULL);
			pCmdTarg->Release();
		}
		pDisp->Release();
}	}*/


	ENSURE(m_pBrowserApp != NULL);
	HRESULT hr = E_FAIL;
	CComPtr<IDispatch> spDispDocument;
	spDispDocument=GetHtmlDocument();
	CComQIPtr<IHTMLDocument2> spDoc = spDispDocument;
	if(spDoc != NULL)
	{
		CComQIPtr<IOleCommandTarget> spCmdTarget = spDoc;
		if(spCmdTarget != NULL)
		{	COleVariant vaZoomFactor;   // input argument
			V_VT(&vaZoomFactor) = VT_I4;
			V_I4(&vaZoomFactor) = fontSize;   // 0 - 4			
			hr = spCmdTarget->Exec(NULL, OLECMDID_ZOOM,
				OLECMDEXECOPT_DONTPROMPTUSER, &vaZoomFactor, NULL);
	}	}	}


// CSinoSHlp32View diagnostics

#ifdef _DEBUG
void CSinoSHlp32View::AssertValid() const
{
	CHtmlView::AssertValid();
}

void CSinoSHlp32View::Dump(CDumpContext& dc) const
{
	CHtmlView::Dump(dc);
}

CSinoSHlp32Doc* CSinoSHlp32View::GetDocument() const // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CSinoSHlp32Doc)));
	return (CSinoSHlp32Doc*)m_pDocument;
}
#endif //_DEBUG


// CSinoSHlp32View message handlers
