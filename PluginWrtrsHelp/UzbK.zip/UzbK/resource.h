//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by SinoPlgWrtrsHlp32.rc
//
#define ID_FIND                         2
#define ID_CONTENTS                     3
#define ID_INDEX                        4
#define ID_SEARCH                       5
#define ID_PREV                         6
#define ID_NEXT                         7
#define ID_PREV_STEP                    8
#define ID_NEXT_STEP                    9
#define IDS_STRING_CONTENTS             10
#define IDS_STRING_INDEX                11
#define IDS_STRING_SEARCH               12
#define IDS_STRING_PREV                 13
#define IDS_STRING_NEXT                 14
#define IDS_STRING_PREV_STEP            15
#define IDS_STRING_NEXT_STEP            16
#define IDS_STRING_FIND                 17
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             101
#define IDR_MAINFRAME                   102
#define IDR_SinoSHlp32TYPE              106
#define IDR_HTML_SODERJANIYE            135
#define IDR_HTML_O_PROGRAMME            136
#define IDR_HTML_PLAGINY                137
#define IDR_HTML_ARXIVNIYE_PLAGINY      138
#define IDR_HTML_ARJPLGN_GetPluginType  139
#define IDR_HTML_ARJPLGN_OpenS12        140
#define IDR_HTML_ARJPLGN_CloseS4        141
#define IDR_HTML_ARJPLGN_AddS24         142
#define IDR_HTML_ARJPLGN_CreateDirS24   143
#define IDR_HTML_ARJPLGN_RebuildCheckExistingsS8 144
#define IDR_HTML_ARJPLGN_SetCallbacksS4xxx 145
#define IDR_HTML_ARJPLGNCLBK_checkFileInSelctn 146
#define IDR_HTML_ARJPLGNCLBK_excldFileFrSelctn 147
#define IDR_HTML_ARJPLGNCLBK_getFileInfoFromSelection 148
#define IDR_HTML_ARJPLGNCLBK_prgrssRout 149
#define IDR_HTML_ARJPLGNCLBK_showDlgOverwriteExistFile 150
#define IDR_HTML_ARJPLGNCLBK_readOptions 151
#define IDR_HTML_ARJPLGNCLBK_saveOptions 152
#define IDR_HTML_RASP_ARXIVNIYE_PLAGINY 153
#define IDR_HTML_UNPARJPLGN_OpenForUnpackingS8 154
#define IDR_HTML_UNPARJPLGN_EnumDirectoryS8 155
#define IDR_HTML_UNPARJPLGN_UnpackS28   156
#define IDR_HTML_UNPARJPLGNCLBK_addItemToPanelList 157
#define IDR_HTML_SEARCHPLGNS            158
#define IDR_HTML_SEARCHPLGN_GetPluginType 159
#define IDR_HTML_SEARCHPLGN_SearchForContainTextS12 160
#define IDR_HTML_SEARCHPLGN_SearchForContainTextWS12 161
#define IDR_HTML_SEARCHPLGN_SearchForNotContainTextS12 162
#define IDR_HTML_SEARCHPLGN_SearchForNotContainTextWS12 163
#define IDR_HTML_SEARCHPLGN_SetIdS4     164
#define IDR_HTML_SEARCHPLGN_QSearchFrListS8 165
#define IDR_HTML_SEARCHPLGN_SetCallbacksS4xxx 166
#define IDR_HTML_SEARCHPLGN_ShowSearchFrPathDlgS8 167
#define IDR_HTML_UNPARJPLGN_ShowSearchFrPathDlgS12 168
#define IDR_HTML_ARJPLGN_RenameFileS12  169
#define IDR_HTML_ARJPLGN_RenameDirS12   170
#define IDR_HTML_ARJPLGN_DeleteFileS8   171
#define IDR_HTML_ARJPLGN_DeleteDirS8    172
#define IDR_HTML_MENU_UTIL_CALLBACK_getCrntPanelNum 173
#define IDR_HTML_MENU_UTIL_CALLBACK_getPanelCrntItem 174
#define IDR_HTML_MENU_UTIL_CALLBACK_getPanelPath 175
#define IDR_HTML_MENU_UTIL_CALLBACK_getPanelSelectedItems 176
#define IDR_HTML_MENU_UTIL_CALLBACK_readOptions 177
#define IDR_HTML_MENU_UTIL_CALLBACK_saveOptions 178
#define IDR_HTML_MENU_UTIL_CALLBACK_getTotalPanels 179
#define IDR_HTML_MENU_UTIL_GetMenuItemText 180
#define IDR_HTML_MENU_UTIL_GetMenuNum   181
#define IDR_HTML_MENU_UTIL_GetMenuPos   182
#define IDR_HTML_MENU_UTIL_GetMenuText  183
#define IDR_HTML_MENU_UTIL_GetPluginName 184
#define IDR_HTML_MENU_UTIL_GetPluginType 185
#define IDR_HTML_MENU_UTIL_RunS4        186
#define IDR_HTML_MENU_UTIL_IDR_SetCallbacksS4xxx 187
#define IDR_HTML_MENU_UTIL_SetIdS4      188
#define IDR_HTML_MENU_UTIL              189
#define IDR_HTML_ARJPLGN_AddEmptyDirS20 190
#define IDR_HTML_EXEC_UTILS_PLGNS	191
#define IDR_HTML_EXEC_VIEW_EDIT_PLGNS	192
#define IDR_HTML_IMAGE_PLGNS	193
#define IDR_HTML_QUICK_VIEW_PLGNS	194
#define IDR_HTML_VIRT_PANEL_PLGNS	195
#define IDR_HTML_ENVIRONMENT_VARS       196
#define IDB_BITMAP1                     217
#define IDB_SINO                        252
#define IDI_ICON_BOOK                   253
#define IDI_ICON_QUEST                  254
#define IDI_ICON_PAPER                  255
#define IDI_ICON_OPEN_BOOK              256
#define IDD_DIALOG_FIND_TEXT            257
#define IDD_DIALOG_PROGRESS             258
#define IDI_STATIC                      1001
#define IDC_EDIT_FIND_TEXT              1002
#define IDC_PROGRESS                    1003
#define IDC_EDIT_PROGRESS               1004
#define ID_EDIT_SELECTALL               32774
#define ID_FONTS_SMALL                  32777
#define ID_FONTS_MEDIUM                 32778
#define ID_FONTS_BIG                    32779
#define ID_EDIT_CLEARSELECTION          32780
#define ID_FONTS_LARGEST                32782
#define ID_FONTS_LARGE                  32783
#define IDM_EDIT_COPY                   32788

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        218
#define _APS_NEXT_COMMAND_VALUE         32798
#define _APS_NEXT_CONTROL_VALUE         1005
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
