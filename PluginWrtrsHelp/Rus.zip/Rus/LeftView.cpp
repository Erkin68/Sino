// LeftView.cpp : implementation of the CLeftView class
//

#include "stdafx.h"
#include "SinoPlgWrtrsHlp32.h"

#include "SinoPlgWrtrsHlp32Doc.h"
#include "LeftView.h"
#include "MainFrm.h"
#include "SinoPlgWrtrsHlp32View.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#endif

CLeftView *listView=NULL;
ListType listType=contents;


// CLeftView

IMPLEMENT_DYNCREATE(CLeftView, CTreeView)

BEGIN_MESSAGE_MAP(CLeftView, CTreeView)
	ON_NOTIFY_REFLECT(TVN_SELCHANGED, OnSelChanged)
	ON_NOTIFY_REFLECT(TVN_ITEMEXPANDING, OnItemExpanding)
END_MESSAGE_MAP()


// CLeftView construction/destruction

CLeftView::CLeftView()
{
	// TODO: add construction code here
}

CLeftView::~CLeftView()
{
}

BOOL CLeftView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying the CREATESTRUCT cs
	cs.style |= TVS_HASLINES | TVS_HASBUTTONS | TVS_LINESATROOT;
	BOOL r = CTreeView::PreCreateWindow(cs);
	return r;
}

/*BOOL CLeftView::OnNotify(WPARAM wParam,LPARAM lParam,LRESULT *pResult)
{
	NMHDR *pnmh = (LPNMHDR)lParam;
/*	if(TVN_KEYDOWN==pnmh->code)
	{	NMTREEVIEW *pnmtv = (NMTREEVIEW*)pResult;
		TVITEM tvi;ZeroMemory(&tvi,sizeof(tvi));
		tvi.hItem = pnmtv->itemOld.hItem;
		tvi.mask = TVIF_TEXT;
		char s[128]="";
		LPSTR ps = &s[0];
		tvi.pszText=ps;
		tvi.cchTextMax=128;
		GetTreeCtrl().GetItem(&tvi);
	}
	if(lParam==0x21f684)
	{	static int i=0;char s[260];sprintf(s,"\n%d %x %x",i++,pnmh->code,wParam);
		OutputDebugString(s);
	}
	return TRUE;
}*/

/*BOOL CLeftView::OnCmdMsg(UINT nID,int nCode,void* pExtra,AFX_CMDHANDLERINFO *pHandlerInfo)
{
static int i=0;char s[260];sprintf(s,"\n%d %x %x %x %x",i++,nID,nCode,pExtra,pHandlerInfo);
	OutputDebugString(s);
	if(nID==0xe140)
		nID=nID;
	if(nID==0xe900)
		nID=nID;
	if(nID==0xe701)
		nID=nID;
	if(nID==0xe702)
		nID=nID;
	if(nID==0xe703)
		nID=nID;
	if(nID==0x3)
		nID=nID;
	if(nID==0x4)
		nID=nID;
	if(nID==0x5)
		nID=nID;
	if(nID==0xe100)
		nID=nID;
	if(nID==0xe101)
		nID=nID;
	if(nID==0xe103)
		nID=nID;
	if(nID==0xe123)
		nID=nID;
	if(nID==0xe122)
		nID=nID;
	if(nID==0xe125)
		nID=nID;
	if(nID==0xe107)
		nID=nID;
	return TRUE;
}*/

void CLeftView::OnSelChanged(NMHDR *pNMHDR,LRESULT *plResult)
{
	if(!htmlView)return;
	if(htmlView->beforeNavigateType == htmlView->selectListItem)return;
	switch(listType)
	{	case contents:
			OnContentsSelChanged(pNMHDR,plResult);
			break;
		case index:
			OnIndexSelChanged(pNMHDR,plResult);
			break;
		case search:
			OnSearchSelChanged(pNMHDR,plResult);
			break;
}	}

void CLeftView::OnContentsSelChanged(NMHDR *pNMHDR,LRESULT *plResult)
{
	htmlView->beforeNavigateType = htmlView->fromContentsList;
	if(pNMHDR->code==TVN_SELCHANGED)
	{	TVITEMA tvi;ZeroMemory(&tvi,sizeof(tvi));
		tvi.mask = TVIF_TEXT;
		TCHAR s[128]="";
		tvi.pszText=&s[0];
		tvi.cchTextMax=128;
		HWND h = pNMHDR->hwndFrom;
		tvi.hItem = TreeView_GetSelection(pNMHDR->hwndFrom);
		TreeView_GetItem(h,&tvi);
		if(!strcmp(s,htmlView->GetHTMLName(0,0)))//"����������"))
			htmlView->LoadFromResource(IDR_HTML_SODERJANIYE);
		else if(!strcmp(s,htmlView->GetHTMLName(0,1)))//"� ���������"))
			htmlView->LoadFromResource(IDR_HTML_O_PROGRAMME);
		else if(!strcmp(s,htmlView->GetHTMLName(0,2)))//"��� ������� �������..."))
			htmlView->LoadFromResource(IDR_HTML_PLAGINY);
		else if(!strcmp(s,htmlView->GetHTMLName(0,3)))//"�������� ������� ..."))
			htmlView->LoadFromResource(IDR_HTML_ARXIVNIYE_PLAGINY);
		else if(!strcmp(s,htmlView->GetHTMLName(0,4)))//"Procedure GetPluginType"))
			htmlView->LoadFromResource(IDR_HTML_ARJPLGN_GetPluginType);
		else if(!strcmp(s,htmlView->GetHTMLName(0,5)))//"Procedure Open$12"))
			htmlView->LoadFromResource(IDR_HTML_ARJPLGN_OpenS12);
		else if(!strcmp(s,htmlView->GetHTMLName(0,6)))//"Procedure Close$4"))
			htmlView->LoadFromResource(IDR_HTML_ARJPLGN_CloseS4);
		else if(!strcmp(s,htmlView->GetHTMLName(0,7)))//"Procedure Add$24"))
			htmlView->LoadFromResource(IDR_HTML_ARJPLGN_AddS24);
		else if(!strcmp(s,htmlView->GetHTMLName(0,8)))//"Procedure CreateDir$24"))
			htmlView->LoadFromResource(IDR_HTML_ARJPLGN_CreateDirS24);
		else if(!strcmp(s,htmlView->GetHTMLName(0,9)))//"Procedure RebuildCheckExistings$8"))
			htmlView->LoadFromResource(IDR_HTML_ARJPLGN_RebuildCheckExistingsS8);
		else if(!strcmp(s,htmlView->GetHTMLName(0,34)))//"Procedure RenameFile$12"))
			htmlView->LoadFromResource(IDR_HTML_ARJPLGN_RenameFileS12);
		else if(!strcmp(s,htmlView->GetHTMLName(0,35)))//"Procedure RenameDir$12"))
			htmlView->LoadFromResource(IDR_HTML_ARJPLGN_RenameDirS12);
		else if(!strcmp(s,htmlView->GetHTMLName(0,36)))//"Procedure DeleteFile$8"))
			htmlView->LoadFromResource(IDR_HTML_ARJPLGN_DeleteFileS8);
		else if(!strcmp(s,htmlView->GetHTMLName(0,37)))//"Procedure DeleteDir$8"))
			htmlView->LoadFromResource(IDR_HTML_ARJPLGN_DeleteDirS8);
		else if(!strcmp(s,htmlView->GetHTMLName(0,10)))//"Procedure SetCallbacks$4xxx"))
			htmlView->LoadFromResource(IDR_HTML_ARJPLGN_SetCallbacksS4xxx);
		else if(!strcmp(s,htmlView->GetHTMLName(0,11)))//"Callback checkFileInSelctn"))
			htmlView->LoadFromResource(IDR_HTML_ARJPLGNCLBK_checkFileInSelctn);
		else if(!strcmp(s,htmlView->GetHTMLName(0,12)))//"Callback excldFileFrSelctn"))
			htmlView->LoadFromResource(IDR_HTML_ARJPLGNCLBK_excldFileFrSelctn);
		else if(!strcmp(s,htmlView->GetHTMLName(0,13)))//"Callback getFileInfoFromSelection"))
			htmlView->LoadFromResource(IDR_HTML_ARJPLGNCLBK_getFileInfoFromSelection);
		else if(!strcmp(s,htmlView->GetHTMLName(0,14)))//"Callback prgrssRout"))
			htmlView->LoadFromResource(IDR_HTML_ARJPLGNCLBK_prgrssRout);
		else if(!strcmp(s,htmlView->GetHTMLName(0,15)))//"Callback showDlgOverwriteExistFile"))
			htmlView->LoadFromResource(IDR_HTML_ARJPLGNCLBK_showDlgOverwriteExistFile);
		else if(!strcmp(s,htmlView->GetHTMLName(0,16)))//"Callback saveOptions"))
			htmlView->LoadFromResource(IDR_HTML_ARJPLGNCLBK_saveOptions);
		else if(!strcmp(s,htmlView->GetHTMLName(0,17)))//"Callback readOptions"))
			htmlView->LoadFromResource(IDR_HTML_ARJPLGNCLBK_readOptions);
		else if(!strcmp(s,htmlView->GetHTMLName(0,54)))//"Procedure AddEmptyDirS20"))
			htmlView->LoadFromResource(IDR_HTML_ARJPLGN_AddEmptyDirS20);
		//Unpack arj:
		else if(!strcmp(s,htmlView->GetHTMLName(0,18)))
			htmlView->LoadFromResource(IDR_HTML_RASP_ARXIVNIYE_PLAGINY);
		else if(!strcmp(s,htmlView->GetHTMLName(0,19)))
			htmlView->LoadFromResource(IDR_HTML_UNPARJPLGN_OpenForUnpackingS8);
		else if(!strcmp(s,htmlView->GetHTMLName(0,20)))
			htmlView->LoadFromResource(IDR_HTML_UNPARJPLGN_EnumDirectoryS8);
		else if(!strcmp(s,htmlView->GetHTMLName(0,21)))
			htmlView->LoadFromResource(IDR_HTML_UNPARJPLGN_UnpackS28);
		else if(!strcmp(s,htmlView->GetHTMLName(0,22)))
			htmlView->LoadFromResource(IDR_HTML_UNPARJPLGNCLBK_addItemToPanelList);
		else if(!strcmp(s,htmlView->GetHTMLName(0,33)))
			htmlView->LoadFromResource(IDR_HTML_UNPARJPLGN_ShowSearchFrPathDlgS12);
		//Search plugin:
		else if(!strcmp(s,htmlView->GetHTMLName(0,23)))
			htmlView->LoadFromResource(IDR_HTML_SEARCHPLGNS);
		else if(!strcmp(s,htmlView->GetHTMLName(0,24)))
			htmlView->LoadFromResource(IDR_HTML_SEARCHPLGN_GetPluginType);		
		else if(!strcmp(s,htmlView->GetHTMLName(0,25)))
			htmlView->LoadFromResource(IDR_HTML_SEARCHPLGN_SearchForContainTextS12);
		else if(!strcmp(s,htmlView->GetHTMLName(0,26)))
			htmlView->LoadFromResource(IDR_HTML_SEARCHPLGN_SetIdS4);		
		else if(!strcmp(s,htmlView->GetHTMLName(0,27)))
			htmlView->LoadFromResource(IDR_HTML_SEARCHPLGN_SearchForNotContainTextS12);
		else if(!strcmp(s,htmlView->GetHTMLName(0,28)))
			htmlView->LoadFromResource(IDR_HTML_SEARCHPLGN_SearchForContainTextWS12);
		else if(!strcmp(s,htmlView->GetHTMLName(0,29)))
			htmlView->LoadFromResource(IDR_HTML_SEARCHPLGN_SearchForNotContainTextWS12);
		else if(!strcmp(s,htmlView->GetHTMLName(0,30)))
			htmlView->LoadFromResource(IDR_HTML_SEARCHPLGN_SetCallbacksS4xxx);
		else if(!strcmp(s,htmlView->GetHTMLName(0,31)))
			htmlView->LoadFromResource(IDR_HTML_SEARCHPLGN_QSearchFrListS8);
		else if(!strcmp(s,htmlView->GetHTMLName(0,32)))
			htmlView->LoadFromResource(IDR_HTML_SEARCHPLGN_ShowSearchFrPathDlgS8);
		//Menu utils:
		else if(!strcmp(s,htmlView->GetHTMLName(0,38)))
			htmlView->LoadFromResource(IDR_HTML_MENU_UTIL_CALLBACK_getCrntPanelNum);
		else if(!strcmp(s,htmlView->GetHTMLName(0,39)))
			htmlView->LoadFromResource(IDR_HTML_MENU_UTIL_CALLBACK_getPanelCrntItem);
		else if(!strcmp(s,htmlView->GetHTMLName(0,40)))
			htmlView->LoadFromResource(IDR_HTML_MENU_UTIL_CALLBACK_getPanelPath);
		else if(!strcmp(s,htmlView->GetHTMLName(0,41)))
			htmlView->LoadFromResource(IDR_HTML_MENU_UTIL_CALLBACK_getPanelSelectedItems);
		else if(!strcmp(s,htmlView->GetHTMLName(0,42)))
			htmlView->LoadFromResource(IDR_HTML_MENU_UTIL_CALLBACK_readOptions);
		else if(!strcmp(s,htmlView->GetHTMLName(0,43)))
			htmlView->LoadFromResource(IDR_HTML_MENU_UTIL_CALLBACK_saveOptions);
		else if(!strcmp(s,htmlView->GetHTMLName(0,44)))
			htmlView->LoadFromResource(IDR_HTML_MENU_UTIL_GetMenuItemText);
		else if(!strcmp(s,htmlView->GetHTMLName(0,45)))
			htmlView->LoadFromResource(IDR_HTML_MENU_UTIL_GetMenuNum);
		else if(!strcmp(s,htmlView->GetHTMLName(0,46)))
			htmlView->LoadFromResource(IDR_HTML_MENU_UTIL_GetMenuPos);
		else if(!strcmp(s,htmlView->GetHTMLName(0,47)))
			htmlView->LoadFromResource(IDR_HTML_MENU_UTIL_GetMenuText);
		else if(!strcmp(s,htmlView->GetHTMLName(0,48)))
			htmlView->LoadFromResource(IDR_HTML_MENU_UTIL_GetPluginName);
		else if(!strcmp(s,htmlView->GetHTMLName(0,49)))
			htmlView->LoadFromResource(IDR_HTML_MENU_UTIL_GetPluginType);
		else if(!strcmp(s,htmlView->GetHTMLName(0,50)))
			htmlView->LoadFromResource(IDR_HTML_MENU_UTIL_RunS4);
		else if(!strcmp(s,htmlView->GetHTMLName(0,51)))
			htmlView->LoadFromResource(IDR_HTML_MENU_UTIL_IDR_SetCallbacksS4xxx);
		else if(!strcmp(s,htmlView->GetHTMLName(0,52)))
			htmlView->LoadFromResource(IDR_HTML_MENU_UTIL_SetIdS4);
		else if(!strcmp(s,htmlView->GetHTMLName(0,53)))
			htmlView->LoadFromResource(IDR_HTML_MENU_UTIL);
		else if(!strcmp(s,htmlView->GetHTMLName(0,55)))
			htmlView->LoadFromResource(IDR_HTML_ENVIRONMENT_VARS);
		else if(!strcmp(s,htmlView->GetHTMLName(0,56)))
			htmlView->LoadFromResource(IDR_HTML_IMAGE_PLGNS);
		else if(!strcmp(s,htmlView->GetHTMLName(0,57)))
			htmlView->LoadFromResource(IDR_HTML_VIRT_PANEL_PLGNS);
		else if(!strcmp(s,htmlView->GetHTMLName(0,58)))
			htmlView->LoadFromResource(IDR_HTML_EXEC_VIEW_EDIT_PLGNS);
		else if(!strcmp(s,htmlView->GetHTMLName(0,59)))
			htmlView->LoadFromResource(IDR_HTML_QUICK_VIEW_PLGNS);
		else if(!strcmp(s,htmlView->GetHTMLName(0,60)))
			htmlView->LoadFromResource(IDR_HTML_EXEC_UTILS_PLGNS);
}	}

void CLeftView::OnIndexSelChanged(NMHDR *pNMHDR,LRESULT *plResult)
{
	htmlView->beforeNavigateType = htmlView->fromIndexList;
	if(pNMHDR->code==TVN_SELCHANGED)
	{	TVITEMA tvi;ZeroMemory(&tvi,sizeof(tvi));
		tvi.mask = TVIF_TEXT;
		TCHAR s[128]="";
		tvi.pszText=&s[0];
		tvi.cchTextMax=128;
		HWND h = pNMHDR->hwndFrom;
		tvi.hItem = TreeView_GetSelection(pNMHDR->hwndFrom);
		TreeView_GetItem(h,&tvi);
		if(!strcmp(s,"����������"))
			htmlView->LoadFromResource(IDR_HTML_SODERJANIYE);
		else if(!strcmp(s,"� ��������� 'Sino'"))
			htmlView->LoadFromResource(IDR_HTML_O_PROGRAMME);
		else if(!strcmp(s,"plugins..."))
			htmlView->LoadFromResource(IDR_HTML_PLAGINY);
		else if(!strcmp(s,"����������� ������..."))//�������� �������"))
			htmlView->LoadFromResource(IDR_HTML_ARXIVNIYE_PLAGINY);
		else if(!strcmp(s,"��������� GetPluginType"))
			htmlView->LoadFromResource(IDR_HTML_ARJPLGN_GetPluginType);
		else if(!strcmp(s,"��������� Open$12"))
			htmlView->LoadFromResource(IDR_HTML_ARJPLGN_OpenS12);
		else if(!strcmp(s,"��������� EnumDirectory$8"))
			htmlView->LoadFromResource(IDR_HTML_UNPARJPLGN_EnumDirectoryS8);
		else if(!strcmp(s,"��������� OpenForUnpacking$8"))
			htmlView->LoadFromResource(IDR_HTML_UNPARJPLGN_OpenForUnpackingS8);
		else if(!strcmp(s,"��������� Close$4"))
			htmlView->LoadFromResource(IDR_HTML_ARJPLGN_CloseS4);
		else if(!strcmp(s,"��������� Add$24"))
			htmlView->LoadFromResource(IDR_HTML_ARJPLGN_AddS24);
		else if(!strcmp(s,"��������� CreateDir$24"))
			htmlView->LoadFromResource(IDR_HTML_ARJPLGN_CreateDirS24);
		else if(!strcmp(s,"��������� RebuildCheckExistings$8"))
			htmlView->LoadFromResource(IDR_HTML_ARJPLGN_RebuildCheckExistingsS8);
		else if(!strcmp(s,"��������� RenameFile$12"))
			htmlView->LoadFromResource(IDR_HTML_ARJPLGN_RenameFileS12);
		else if(!strcmp(s,"��������� RenameDir$12"))
			htmlView->LoadFromResource(IDR_HTML_ARJPLGN_RenameDirS12);
		else if(!strcmp(s,"��������� DeleteFile$8"))
			htmlView->LoadFromResource(IDR_HTML_ARJPLGN_DeleteFileS8);
		else if(!strcmp(s,"��������� DeleteDir$8"))
			htmlView->LoadFromResource(IDR_HTML_ARJPLGN_DeleteDirS8);
		else if(!strcmp(s,"��������� SetCallbacks$4xxx"))
			htmlView->LoadFromResource(IDR_HTML_ARJPLGN_SetCallbacksS4xxx);
		else if(!strcmp(s,"Callback checkFileInSelctn"))
			htmlView->LoadFromResource(IDR_HTML_ARJPLGNCLBK_checkFileInSelctn);
		else if(!strcmp(s,"Callback excldFileFrSelctn"))
			htmlView->LoadFromResource(IDR_HTML_ARJPLGNCLBK_excldFileFrSelctn);
		else if(!strcmp(s,"Callback getFileInfoFromSelection"))
			htmlView->LoadFromResource(IDR_HTML_ARJPLGNCLBK_getFileInfoFromSelection);
		else if(!strcmp(s,"Callback prgrssRout"))
			htmlView->LoadFromResource(IDR_HTML_ARJPLGNCLBK_prgrssRout);
		else if(!strcmp(s,"Callback showDlgOverwriteExistFile"))
			htmlView->LoadFromResource(IDR_HTML_ARJPLGNCLBK_showDlgOverwriteExistFile);
		else if(!strcmp(s,"Callback saveOptions"))
			htmlView->LoadFromResource(IDR_HTML_ARJPLGNCLBK_saveOptions);
		else if(!strcmp(s,"Callback readOptions"))
			htmlView->LoadFromResource(IDR_HTML_ARJPLGNCLBK_readOptions);
		else if(!strcmp(s,"��������� AddEmptyDir$20"))
			htmlView->LoadFromResource(IDR_HTML_ARJPLGN_AddEmptyDirS20);
		//Unpack arj:
		else if(!strcmp(s,"���������� ������� ..."))
			htmlView->LoadFromResource(IDR_HTML_RASP_ARXIVNIYE_PLAGINY);
		else if(!strcmp(s,"��������� OpenForUnpacking$8"))
			htmlView->LoadFromResource(IDR_HTML_UNPARJPLGN_OpenForUnpackingS8);
		else if(!strcmp(s,"��������� Unpack$28"))
			htmlView->LoadFromResource(IDR_HTML_UNPARJPLGN_UnpackS28);
		else if(!strcmp(s,"Callback addItemToPanelList"))
			htmlView->LoadFromResource(IDR_HTML_UNPARJPLGNCLBK_addItemToPanelList);
		else if(!strcmp(s,"��������� ShowSearchDlg$12"))
			htmlView->LoadFromResource(IDR_HTML_UNPARJPLGN_ShowSearchFrPathDlgS12);
		//search plg:
		else if(!strcmp(s,"������� ������..."))
			htmlView->LoadFromResource(IDR_HTML_SEARCHPLGNS);
		else if(!strcmp(s,"������� ������ - GetPluginType"))
			htmlView->LoadFromResource(IDR_HTML_SEARCHPLGN_GetPluginType);
		else if(!strcmp(s,"������� ������ - SearchForContainText$12"))
			htmlView->LoadFromResource(IDR_HTML_SEARCHPLGN_SearchForContainTextS12);
		else if(!strcmp(s,"������� ������ - SetId$4"))
			htmlView->LoadFromResource(IDR_HTML_SEARCHPLGN_SetIdS4);		
		else if(!strcmp(s,"������� ������ - SearchForNotContainText$12"))
			htmlView->LoadFromResource(IDR_HTML_SEARCHPLGN_SearchForNotContainTextS12);
		else if(!strcmp(s,"������� ������ - SearchForContainTextW$12"))
			htmlView->LoadFromResource(IDR_HTML_SEARCHPLGN_SearchForContainTextWS12);
		else if(!strcmp(s,"������� ������ - SearchForNotContainTextW$12"))
			htmlView->LoadFromResource(IDR_HTML_SEARCHPLGN_SearchForNotContainTextWS12);
		else if(!strcmp(s,"������� ������ - SetCallbacks$4xxx"))
			htmlView->LoadFromResource(IDR_HTML_SEARCHPLGN_SetCallbacksS4xxx);
		else if(!strcmp(s,"������� ������ - QSearchFrList$8"))
			htmlView->LoadFromResource(IDR_HTML_SEARCHPLGN_QSearchFrListS8);
		else if(!strcmp(s,"������� ������ - ShowSearchDlg$8"))
			htmlView->LoadFromResource(IDR_HTML_SEARCHPLGN_ShowSearchFrPathDlgS8);
		//menu utils:
		else if(!strcmp(s,"Callback getCrntPanelNum"))
			htmlView->LoadFromResource(IDR_HTML_MENU_UTIL_CALLBACK_getCrntPanelNum);
		else if(!strcmp(s,"Callback getPanelCrntItem"))
			htmlView->LoadFromResource(IDR_HTML_MENU_UTIL_CALLBACK_getPanelCrntItem);
		else if(!strcmp(s,"Callback getPanelSelectedItems"))
			htmlView->LoadFromResource(IDR_HTML_MENU_UTIL_CALLBACK_getPanelSelectedItems);
		else if(!strcmp(s,"Menu utility: callback readOptions"))
			htmlView->LoadFromResource(IDR_HTML_MENU_UTIL_CALLBACK_readOptions);
		else if(!strcmp(s,"Menu utility: callback saveOptions"))
			htmlView->LoadFromResource(IDR_HTML_MENU_UTIL_CALLBACK_saveOptions);
		else if(!strcmp(s,"��������� GetMenuItemText"))
			htmlView->LoadFromResource(IDR_HTML_MENU_UTIL_GetMenuItemText);
		else if(!strcmp(s,"��������� GetMenuNum"))
			htmlView->LoadFromResource(IDR_HTML_MENU_UTIL_GetMenuNum);
		else if(!strcmp(s,"��������� GetMenuPos"))
			htmlView->LoadFromResource(IDR_HTML_MENU_UTIL_GetMenuPos);
		else if(!strcmp(s,"��������� GetMenuText"))
			htmlView->LoadFromResource(IDR_HTML_MENU_UTIL_GetMenuText);
		else if(!strcmp(s,"��������� GetPluginName"))
			htmlView->LoadFromResource(IDR_HTML_MENU_UTIL_GetPluginName);
		else if(!strcmp(s,"Menu utility: Procedure GetPluginType"))
			htmlView->LoadFromResource(IDR_HTML_MENU_UTIL_GetPluginType);
		else if(!strcmp(s,"��������� Run$4"))
			htmlView->LoadFromResource(IDR_HTML_MENU_UTIL_RunS4);
		else if(!strcmp(s,"Menu utility: Procedure SetCallbacks$4xxx"))
			htmlView->LoadFromResource(IDR_HTML_MENU_UTIL_IDR_SetCallbacksS4xxx);
		else if(!strcmp(s,"Menu utility: Procedure SetId$4"))
			htmlView->LoadFromResource(IDR_HTML_MENU_UTIL_SetIdS4);
		else if(!strcmp(s,"�������-������� ����"))
			htmlView->LoadFromResource(IDR_HTML_MENU_UTIL);
		else if(!strcmp(s,"Callback getTotalPanels"))
			htmlView->LoadFromResource(IDR_HTML_MENU_UTIL_CALLBACK_getTotalPanels);
		else if(!strcmp(s,"AddEmptyDir$20"))
			htmlView->LoadFromResource(IDR_HTML_ARJPLGN_AddEmptyDirS20);
		else if(!strcmp(s,"���������� �����"))
			htmlView->LoadFromResource(IDR_HTML_ENVIRONMENT_VARS);
		else if(!strcmp(s,"������� ��������� ��������"))
			htmlView->LoadFromResource(IDR_HTML_IMAGE_PLGNS);
		else if(!strcmp(s,"������� ����������� ������"))
			htmlView->LoadFromResource(IDR_HTML_VIRT_PANEL_PLGNS);
		else if(!strcmp(s,"������������ ������� ���������/�������������� �������"))
			htmlView->LoadFromResource(IDR_HTML_EXEC_VIEW_EDIT_PLGNS);
		else if(!strcmp(s,"������� �������� ���������"))
			htmlView->LoadFromResource(IDR_HTML_QUICK_VIEW_PLGNS);
		else if(!strcmp(s,"������������ �������"))
			htmlView->LoadFromResource(IDR_HTML_EXEC_UTILS_PLGNS);
}	}

void CLeftView::OnSearchSelChanged(NMHDR *pNMHDR,LRESULT *plResult)
{
	htmlView->beforeNavigateType = htmlView->fromSearchList;
	if(pNMHDR->code==TVN_SELCHANGED)
	{	TVITEMA tvi;ZeroMemory(&tvi,sizeof(tvi));
		tvi.mask = TVIF_PARAM;
		HWND h = pNMHDR->hwndFrom;
		tvi.hItem = TreeView_GetSelection(pNMHDR->hwndFrom);
		TreeView_GetItem(h,&tvi);
		htmlView->LoadFromResource(tvi.lParam);
		//mainFrame->SelectAllFindStrInCrntPage();
}	}

void CLeftView::AddSearchPage(int foundedPages,UINT uiRes)//NMHDR *pNMHDR,LRESULT *plResult)
{
	CTreeCtrl &t = GetTreeCtrl();
	if(0==foundedPages)
	{	if(htmlView->beforeNavigateType != htmlView->fromSearchList)//First entranse in list initing mode:
		{	htmlView->beforeNavigateType = htmlView->fromSearchList;
			listType=search;
			t.DeleteAllItems();
	}	}
	HTREEITEM item=t.InsertItem(TVIF_TEXT|TVIF_PARAM,htmlView->GetHTMLName(uiRes,0), 2, 2, 0, 0, uiRes, NULL, NULL);//child
	t.SetItemImage(item,2,2);
}

void CLeftView::OnInitialUpdate()
{
static BOOL bContetntsInited=FALSE;
	CTreeView::OnInitialUpdate();
	LOGFONT lf;
	memset(&lf, 0, sizeof(LOGFONT));// clear out structure
	GetFont()->GetLogFont(&lf);
	lf.lfHeight = 12;               // request a 12-pixel-height font
	CFont font;
	font.CreateFontIndirect(&lf);  // create the font
	SetFont(&font,1);
	font.DeleteObject();  

	// TODO: You may populate your TreeView with items by directly accessing
	//  its tree control through a call to GetTreeCtrl().
	if(!bContetntsInited)
	{	listView = this;
		CImageList *myImageList = new CImageList();
		myImageList->Create(16,16,ILC_COLOR16,3,3);
		myImageList->SetBkColor(RGB(200,206,223));//255,255,255));//CLR_NONE);
		HICON icb = LoadIcon(AfxGetInstanceHandle(),MAKEINTRESOURCE(IDI_ICON_BOOK));
		myImageList->Add(icb);
		HICON icob = LoadIcon(AfxGetInstanceHandle(),MAKEINTRESOURCE(IDI_ICON_OPEN_BOOK));
		myImageList->Add(icob);
		HICON icp = LoadIcon(AfxGetInstanceHandle(),MAKEINTRESOURCE(IDI_ICON_PAPER));
		myImageList->Add(icp);

		CTreeCtrl &t = GetTreeCtrl();
		CImageList *pim=t.SetImageList(myImageList,TVSIL_NORMAL);

		t.SetItemHeight(20);
		t.SetBkColor(RGB(200,206,223));//255,255,255
		t.SetTextColor(RGB(65,10,167));
		//t.SetInsertMarkColor(RGB(10,255,10));
		SetPage(contents,0);
		bContetntsInited = TRUE;
		/*RECT rc; GetClientRect(&rc);
		HWND hwndButton = CreateWindow( 
			"BUTTON",   // Predefined class; Unicode assumed. 
			"Contents",       // Button text. 
			WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_DEFPUSHBUTTON,  // Styles. 
			rc.left+2,   // x position. 
			rc.bottom-76,// y position. 
			70,			// Button width.
			22,         // Button height.
			m_hWnd,     // Parent window.
			NULL,       // No menu.
			(HINSTANCE)GetWindowLong(m_hWnd, GWL_HINSTANCE), 
			NULL);      // Pointer not needed.*/
		//SetForegroundColor(
}	}

void CLeftView::SetPage(ListType contType,int sel)
{
	switch(contType)
	{	case contents:
			SetContentsPage(sel);
			break;
		case index:
			SetIndexPage(sel);
			break;
		case search:
			SetSearchPage(sel);
			break;
}	}

void CLeftView::SetContentsPage(int sel)
{
BOOL bDel=FALSE;
	CTreeCtrl &t = GetTreeCtrl();
	if(listType==contents)
	if(t.GetCount()!=0)
		goto Select;
	t.DeleteAllItems();
	bDel=TRUE;

	HTREEITEM root,item,prnt,plg,arjPlg,auxPlg;
	root=t.InsertItem(TVIF_TEXT,htmlView->GetHTMLName(0,0), 0, 0, 0, 0, 0, NULL, NULL);//root _T("����������")
	item=t.InsertItem(TVIF_TEXT,htmlView->GetHTMLName(0,1)/*_T("� ���������")*/, 2, 2, 0, 0, 2, root, NULL);//child
	t.SetItemImage(item,2,2);
	plg=t.InsertItem(TVIF_TEXT,htmlView->GetHTMLName(0,2)/*_T("��� ������� �������...")*/, 0, 0, 0, 0, 0, root, NULL);
	arjPlg=t.InsertItem(TVIF_TEXT,_T("�������� �������"), 0, 0, 0, 0, 0, plg, NULL);
	prnt=t.InsertItem(TVIF_TEXT,htmlView->GetHTMLName(0,3)/*_T"�������� ������� ..."*/, 0, 0, 0, 0, 1, arjPlg, NULL);
	item=t.InsertItem(TVIF_TEXT,htmlView->GetHTMLName(0,4)/*_T("��������� GetPluginType")*/, 2, 2, 0, 0, 1, prnt, NULL);
	t.SetItemImage(item,2,2);
	item=t.InsertItem(TVIF_TEXT,htmlView->GetHTMLName(0,5)/*_T("��������� Open$12")*/, 2, 2, 0, 0, 2, prnt, NULL);
	t.SetItemImage(item,2,2);
	item=t.InsertItem(TVIF_TEXT,htmlView->GetHTMLName(0,6)/*_T("��������� Close$4")*/, 2, 2, 0, 0, 2, prnt, NULL);
	t.SetItemImage(item,2,2);
	item=t.InsertItem(TVIF_TEXT,htmlView->GetHTMLName(0,7)/*_T("��������� Add$24")*/, 2, 2, 0, 0, 2, prnt, NULL);
	t.SetItemImage(item,2,2);
	item=t.InsertItem(TVIF_TEXT,htmlView->GetHTMLName(0,8)/*_T("��������� CreateDir$24")*/, 2, 2, 0, 0, 2, prnt, NULL);
	t.SetItemImage(item,2,2);
	item=t.InsertItem(TVIF_TEXT,htmlView->GetHTMLName(0,9)/*_T("��������� RebuildCheckExistings$8")*/, 2, 2, 0, 0, 2, prnt, NULL);
	t.SetItemImage(item,2,2);
	item=t.InsertItem(TVIF_TEXT,htmlView->GetHTMLName(0,34)/*_T("��������� RenameFile$8")*/, 2, 2, 0, 0, 2, prnt, NULL);
	t.SetItemImage(item,2,2);
	item=t.InsertItem(TVIF_TEXT,htmlView->GetHTMLName(0,35)/*_T("��������� RenameDir$8")*/, 2, 2, 0, 0, 2, prnt, NULL);
	t.SetItemImage(item,2,2);
	item=t.InsertItem(TVIF_TEXT,htmlView->GetHTMLName(0,36)/*_T("��������� DeleteFile$8")*/, 2, 2, 0, 0, 2, prnt, NULL);
	t.SetItemImage(item,2,2);
	item=t.InsertItem(TVIF_TEXT,htmlView->GetHTMLName(0,37)/*_T("��������� DeleteDir$8")*/, 2, 2, 0, 0, 2, prnt, NULL);
	t.SetItemImage(item,2,2);
	item=t.InsertItem(TVIF_TEXT,htmlView->GetHTMLName(0,10)/*_T("��������� SetCallbacks$4xxx")*/, 2, 2, 0, 0, 2, prnt, NULL);
	t.SetItemImage(item,2,2);
	item=t.InsertItem(TVIF_TEXT,htmlView->GetHTMLName(0,11)/*_T("Callback checkFileInSelctn")*/, 2, 2, 0, 0, 2, prnt, NULL);
	t.SetItemImage(item,2,2);
	item=t.InsertItem(TVIF_TEXT,htmlView->GetHTMLName(0,12)/*_T("Callback excldFileFrSelctn")*/, 2, 2, 0, 0, 2, prnt, NULL);
	t.SetItemImage(item,2,2);
	item=t.InsertItem(TVIF_TEXT,htmlView->GetHTMLName(0,13)/*_T("Callback getFileInfoFromSelection")*/, 2, 2, 0, 0, 2, prnt, NULL);
	t.SetItemImage(item,2,2);
	item=t.InsertItem(TVIF_TEXT,htmlView->GetHTMLName(0,14)/*_T("Callback prgrssRout")*/, 2, 2, 0, 0, 2, prnt, NULL);
	t.SetItemImage(item,2,2);
	item=t.InsertItem(TVIF_TEXT,htmlView->GetHTMLName(0,15)/*_T("Callback showDlgOverwriteExistFile")*/, 0, 0, 0, 0, 2, prnt, NULL);
	t.SetItemImage(item,2,2);
	item=t.InsertItem(TVIF_TEXT,htmlView->GetHTMLName(0,16)/*_T("Callback saveOptions")*/, 2, 2, 0, 0, 2, prnt, NULL);
	t.SetItemImage(item,2,2);
	item=t.InsertItem(TVIF_TEXT,htmlView->GetHTMLName(0,17)/*_T("Callback readOptions")*/, 2, 2, 0, 0, 2, prnt, NULL);
	t.SetItemImage(item,2,2);
	item=t.InsertItem(TVIF_TEXT,htmlView->GetHTMLName(0,54)/*_T("��������� AddEmptyDirS20")*/, 2, 2, 0, 0, 2, prnt, NULL);
	t.SetItemImage(item,2,2);
	prnt=t.InsertItem(TVIF_TEXT,htmlView->GetHTMLName(0,18)/*_T("���������� ������� ...")*/, 0, 0, 0, 0, 0, arjPlg, NULL);
	item=t.InsertItem(TVIF_TEXT,htmlView->GetHTMLName(0,19), 2, 2, 0, 0, 2, prnt, NULL);
	t.SetItemImage(item,2,2);
	item=t.InsertItem(TVIF_TEXT,htmlView->GetHTMLName(0,20), 2, 2, 0, 0, 2, prnt, NULL);
	t.SetItemImage(item,2,2);
	item=t.InsertItem(TVIF_TEXT,htmlView->GetHTMLName(0,21), 2, 2, 0, 0, 2, prnt, NULL);
	t.SetItemImage(item,2,2);
	item=t.InsertItem(TVIF_TEXT,htmlView->GetHTMLName(0,22), 2, 2, 0, 0, 2, prnt, NULL);
	t.SetItemImage(item,2,2);
	item=t.InsertItem(TVIF_TEXT,htmlView->GetHTMLName(0,33), 2, 2, 0, 0, 2, prnt, NULL);
	t.SetItemImage(item,2,2);
	auxPlg=t.InsertItem(TVIF_TEXT,_T("������������� �������"), 0, 0, 0, 0, 0, plg, NULL);
	prnt=t.InsertItem(TVIF_TEXT,htmlView->GetHTMLName(0,23)/*_T"������� ������ ..."*/, 0, 0, 0, 0, 1, auxPlg, NULL);
	item=t.InsertItem(TVIF_TEXT,htmlView->GetHTMLName(0,24), 2, 2, 0, 0, 2, prnt, NULL);
	t.SetItemImage(item,2,2);
	item=t.InsertItem(TVIF_TEXT,htmlView->GetHTMLName(0,25), 2, 2, 0, 0, 2, prnt, NULL);
	t.SetItemImage(item,2,2);
	item=t.InsertItem(TVIF_TEXT,htmlView->GetHTMLName(0,26), 2, 2, 0, 0, 2, prnt, NULL);
	t.SetItemImage(item,2,2);
	item=t.InsertItem(TVIF_TEXT,htmlView->GetHTMLName(0,27), 2, 2, 0, 0, 2, prnt, NULL);
	t.SetItemImage(item,2,2);
	item=t.InsertItem(TVIF_TEXT,htmlView->GetHTMLName(0,28), 2, 2, 0, 0, 2, prnt, NULL);
	t.SetItemImage(item,2,2);
	item=t.InsertItem(TVIF_TEXT,htmlView->GetHTMLName(0,29), 2, 2, 0, 0, 2, prnt, NULL);
	t.SetItemImage(item,2,2);
	item=t.InsertItem(TVIF_TEXT,htmlView->GetHTMLName(0,30), 2, 2, 0, 0, 2, prnt, NULL);
	t.SetItemImage(item,2,2);
	item=t.InsertItem(TVIF_TEXT,htmlView->GetHTMLName(0,31), 2, 2, 0, 0, 2, prnt, NULL);
	t.SetItemImage(item,2,2);
	item=t.InsertItem(TVIF_TEXT,htmlView->GetHTMLName(0,32), 2, 2, 0, 0, 2, prnt, NULL);
	t.SetItemImage(item,2,2);

	//���������������: �������-������� ����:
	prnt=t.InsertItem(TVIF_TEXT,htmlView->GetHTMLName(0,53), 0, 0, 0, 0, 1, auxPlg, NULL);
	item=t.InsertItem(TVIF_TEXT,htmlView->GetHTMLName(0,38), 2, 2, 0, 0, 2, prnt, NULL);
	t.SetItemImage(item,2,2);
	item=t.InsertItem(TVIF_TEXT,htmlView->GetHTMLName(0,39), 2, 2, 0, 0, 2, prnt, NULL);
	t.SetItemImage(item,2,2);
	item=t.InsertItem(TVIF_TEXT,htmlView->GetHTMLName(0,40), 2, 2, 0, 0, 2, prnt, NULL);
	t.SetItemImage(item,2,2);
	item=t.InsertItem(TVIF_TEXT,htmlView->GetHTMLName(0,41), 2, 2, 0, 0, 2, prnt, NULL);
	t.SetItemImage(item,2,2);
	item=t.InsertItem(TVIF_TEXT,htmlView->GetHTMLName(0,42), 2, 2, 0, 0, 2, prnt, NULL);
	t.SetItemImage(item,2,2);
	item=t.InsertItem(TVIF_TEXT,htmlView->GetHTMLName(0,43), 2, 2, 0, 0, 2, prnt, NULL);
	t.SetItemImage(item,2,2);
	item=t.InsertItem(TVIF_TEXT,htmlView->GetHTMLName(0,44), 2, 2, 0, 0, 2, prnt, NULL);
	t.SetItemImage(item,2,2);
	item=t.InsertItem(TVIF_TEXT,htmlView->GetHTMLName(0,45), 2, 2, 0, 0, 2, prnt, NULL);
	t.SetItemImage(item,2,2);
	item=t.InsertItem(TVIF_TEXT,htmlView->GetHTMLName(0,46), 2, 2, 0, 0, 2, prnt, NULL);
	t.SetItemImage(item,2,2);
	item=t.InsertItem(TVIF_TEXT,htmlView->GetHTMLName(0,47), 2, 2, 0, 0, 2, prnt, NULL);
	t.SetItemImage(item,2,2);
	item=t.InsertItem(TVIF_TEXT,htmlView->GetHTMLName(0,48), 2, 2, 0, 0, 2, prnt, NULL);
	t.SetItemImage(item,2,2);
	item=t.InsertItem(TVIF_TEXT,htmlView->GetHTMLName(0,49), 2, 2, 0, 0, 2, prnt, NULL);
	t.SetItemImage(item,2,2);
	item=t.InsertItem(TVIF_TEXT,htmlView->GetHTMLName(0,50), 2, 2, 0, 0, 2, prnt, NULL);
	t.SetItemImage(item,2,2);
	item=t.InsertItem(TVIF_TEXT,htmlView->GetHTMLName(0,51), 2, 2, 0, 0, 2, prnt, NULL);
	t.SetItemImage(item,2,2);
	item=t.InsertItem(TVIF_TEXT,htmlView->GetHTMLName(0,52), 2, 2, 0, 0, 2, prnt, NULL);
	t.SetItemImage(item,2,2);
	item=t.InsertItem(TVIF_TEXT,htmlView->GetHTMLName(0,56), 2, 2, 0, 0, 2, plg, NULL);
	t.SetItemImage(item,2,2);
	item=t.InsertItem(TVIF_TEXT,htmlView->GetHTMLName(0,57), 2, 2, 0, 0, 2, plg, NULL);
	t.SetItemImage(item,2,2);
	item=t.InsertItem(TVIF_TEXT,htmlView->GetHTMLName(0,58), 2, 2, 0, 0, 2, plg, NULL);
	t.SetItemImage(item,2,2);
	item=t.InsertItem(TVIF_TEXT,htmlView->GetHTMLName(0,59), 2, 2, 0, 0, 2, plg, NULL);
	t.SetItemImage(item,2,2);
	item=t.InsertItem(TVIF_TEXT,htmlView->GetHTMLName(0,60), 2, 2, 0, 0, 2, plg, NULL);
	t.SetItemImage(item,2,2);
	item=t.InsertItem(TVIF_TEXT,htmlView->GetHTMLName(0,55), 2, 2, 0, 0, 2, root, NULL);
	t.SetItemImage(item,2,2);

	listType = contents;

	t.Expand(root,TVE_EXPAND);//oxirgi prnt->Kak soz

Select:
	item = t.GetRootItem();
	if(sel>0 && sel<MAX_HTMLS)
	{	for(int i=0; i<sel; i++)
		{	//t.Expand(item,TVE_EXPAND);
			item=t.GetNextVisibleItem(item);
			t.Expand(item,TVE_EXPAND);
		}
		t.SelectItem(item);
	}
	else if(!bDel)
		t.SelectItem(item);
}

void CLeftView::SelectItem(int sel)//Eng 1-marta bu yerga kirish mumkin emas;
{
	if(listType!=contents)
		return;

	CSinoSHlp32View::BeforeNavigateType saveType = htmlView->beforeNavigateType;
	htmlView->beforeNavigateType=htmlView->selectListItem;

	CTreeCtrl &t = GetTreeCtrl();
	//int tot=t.GetCount();
	HTREEITEM item = t.GetRootItem();
	t.Expand(item,TVE_EXPAND);
	//CString st=t.GetItemText(item);
	if(sel>0 && sel<MAX_HTMLS+2)//2 ta lishniysi bor;
	{	for(int i=0; i<sel; i++)
		{	item=t.GetNextVisibleItem(item);
			//st=t.GetItemText(item);
			//BOOL cmctd=t.EnsureVisible(item);
			//if(!cmctd)
			{	t.Expand(item,TVE_EXPAND);
			}
			//if(!cmctd)
			//	t.Expand(itemPre,TVE_COLLAPSE);//TVE_TOGGLE
		}
		t.SelectItem(item);
	}
	else
		t.SelectItem(item);

	t.EnsureVisible(item);
	//t.SetFocus();
	RECT rc;t.GetClientRect(&rc);
	t.SendMessage(WM_LBUTTONDOWN,0,MAKELONG(rc.right,rc.bottom));//
	//t.SetFocus();//t.ValidateRect(NULL);//t.UpUpdateWindow();//
	
	htmlView->beforeNavigateType=saveType;
}

void CLeftView::SetIndexPage(int sel)
{
BOOL bDel = FALSE;
	CTreeCtrl &t = GetTreeCtrl();
	if(listType==index)
	if(t.GetCount()!=0)
		goto Select;
	t.DeleteAllItems();
	bDel = TRUE;

	HTREEITEM item=t.InsertItem(TVIF_TEXT,_T("����������"), 0, 0, 0, 0, 0, NULL, NULL);
	t.SetItemImage(item,2,2);
	item=t.InsertItem(TVIF_TEXT,_T("� ��������� 'Sino'"), 0, 0, 0, 0, 0, NULL, NULL);
	t.SetItemImage(item,2,2);
	item=t.InsertItem(TVIF_TEXT,_T("��� ������� ������..."), 0, 0, 0, 0, 0, NULL, NULL);
	t.SetItemImage(item,2,2);
	item=t.InsertItem(TVIF_TEXT,_T("����������� ������..."), 0, 0, 0, 0, 0, NULL, NULL);//�������� �������
	t.SetItemImage(item,2,2);
	item=t.InsertItem(TVIF_TEXT,_T("��������� GetPluginType"), 0, 0, 0, 0, 0, NULL, NULL);
	t.SetItemImage(item,2,2);
	item=t.InsertItem(TVIF_TEXT,_T("��������� Open$12"), 0, 0, 0, 0, 0, NULL, NULL);
	t.SetItemImage(item,2,2);
	item=t.InsertItem(TVIF_TEXT,_T("��������� Close$4"), 0, 0, 0, 0, 0, NULL, NULL);
	t.SetItemImage(item,2,2);
	item=t.InsertItem(TVIF_TEXT,_T("��������� Add$24"), 0, 0, 0, 0, 0, NULL, NULL);
	t.SetItemImage(item,2,2);
	item=t.InsertItem(TVIF_TEXT,_T("��������� CreateDir$24"), 0, 0, 0, 0, 0, NULL, NULL);
	t.SetItemImage(item,2,2);
	item=t.InsertItem(TVIF_TEXT,_T("��������� RebuildCheckExistings$8"), 0, 0, 0, 0, 0, NULL, NULL);
	t.SetItemImage(item,2,2);
	item=t.InsertItem(TVIF_TEXT,_T("��������� RenameFile$12"), 0, 0, 0, 0, 0, NULL, NULL);
	t.SetItemImage(item,2,2);
	item=t.InsertItem(TVIF_TEXT,_T("��������� RenameDir$12"), 0, 0, 0, 0, 0, NULL, NULL);
	t.SetItemImage(item,2,2);
	item=t.InsertItem(TVIF_TEXT,_T("��������� DeleteFile$8"), 0, 0, 0, 0, 0, NULL, NULL);
	t.SetItemImage(item,2,2);
	item=t.InsertItem(TVIF_TEXT,_T("��������� DeleteDir$8"), 0, 0, 0, 0, 0, NULL, NULL);
	t.SetItemImage(item,2,2);
	item=t.InsertItem(TVIF_TEXT,_T("��������� SetCallbacks$4xxx"), 0, 0, 0, 0, 0, NULL, NULL);
	t.SetItemImage(item,2,2);
	item=t.InsertItem(TVIF_TEXT,_T("Callback checkFileInSelctn"), 0, 0, 0, 0, 0, NULL, NULL);
	t.SetItemImage(item,2,2);
	item=t.InsertItem(TVIF_TEXT,_T("Callback excldFileFrSelctn"), 0, 0, 0, 0, 0, NULL, NULL);
	t.SetItemImage(item,2,2);
	item=t.InsertItem(TVIF_TEXT,_T("Callback getFileInfoFromSelection"), 0, 0, 0, 0, 0, NULL, NULL);
	t.SetItemImage(item,2,2);
	item=t.InsertItem(TVIF_TEXT,_T("Callback prgrssRout"), 0, 0, 0, 0, 0, NULL, NULL);
	t.SetItemImage(item,2,2);
	item=t.InsertItem(TVIF_TEXT,_T("Callback showDlgOverwriteExistFile"), 0, 0, 0, 0, 0, NULL, NULL);
	t.SetItemImage(item,2,2);
	item=t.InsertItem(TVIF_TEXT,_T("Callback saveOptions"), 0, 0, 0, 0, 0, NULL, NULL);
	t.SetItemImage(item,2,2);
	item=t.InsertItem(TVIF_TEXT,_T("Callback readOptions"), 0, 0, 0, 0, 0, NULL, NULL);
	t.SetItemImage(item,2,2);
	item=t.InsertItem(TVIF_TEXT,_T("��������� AddEmptyDir$20"), 0, 0, 0, 0, 0, NULL, NULL);
	t.SetItemImage(item,2,2);
	//unpack arj:
	item=t.InsertItem(TVIF_TEXT,_T("���������� ������� ..."), 0, 0, 0, 0, 0, NULL, NULL);
	t.SetItemImage(item,2,2);
	item=t.InsertItem(TVIF_TEXT,_T("��������� OpenForUnpacking$8"), 0, 0, 0, 0, 0, NULL, NULL);
	t.SetItemImage(item,2,2);
	item=t.InsertItem(TVIF_TEXT,_T("��������� EnumDirectory$8"), 0, 0, 0, 0, 0, NULL, NULL);
	t.SetItemImage(item,2,2);
	item=t.InsertItem(TVIF_TEXT,_T("��������� Unpack$28"), 0, 0, 0, 0, 0, NULL, NULL);
	t.SetItemImage(item,2,2);
	item=t.InsertItem(TVIF_TEXT,_T("Callback addItemToPanelList"), 0, 0, 0, 0, 0, NULL, NULL);
	t.SetItemImage(item,2,2);
	item=t.InsertItem(TVIF_TEXT,_T("��������� ShowSearchDlg$12"), 0, 0, 0, 0, 0, NULL, NULL);
	t.SetItemImage(item,2,2);
	//aux,search:
	item=t.InsertItem(TVIF_TEXT,_T("������� ������..."), 0, 0, 0, 0, 0, NULL, NULL);//�������� �������
	t.SetItemImage(item,2,2);
	item=t.InsertItem(TVIF_TEXT,_T("������� ������ - GetPluginType"), 0, 0, 0, 0, 0, NULL, NULL);
	t.SetItemImage(item,2,2);
	item=t.InsertItem(TVIF_TEXT,_T("������� ������ - SearchForContainText$12"), 0, 0, 0, 0, 0, NULL, NULL);
	t.SetItemImage(item,2,2);
	item=t.InsertItem(TVIF_TEXT,_T("������� ������ - SetId$4"), 0, 0, 0, 0, 0, NULL, NULL);
	t.SetItemImage(item,2,2);
	item=t.InsertItem(TVIF_TEXT,_T("������� ������ - SearchForNotContainText$12"), 0, 0, 0, 0, 0, NULL, NULL);
	t.SetItemImage(item,2,2);
	item=t.InsertItem(TVIF_TEXT,_T("������� ������ - SearchForContainTextW$12"), 0, 0, 0, 0, 0, NULL, NULL);
	t.SetItemImage(item,2,2);
	item=t.InsertItem(TVIF_TEXT,_T("������� ������ - SearchForNotContainTextW$12"), 0, 0, 0, 0, 0, NULL, NULL);
	t.SetItemImage(item,2,2);
	item=t.InsertItem(TVIF_TEXT,_T("������� ������ - SetCallbacks$4xxx"), 0, 0, 0, 0, 0, NULL, NULL);
	t.SetItemImage(item,2,2);
	item=t.InsertItem(TVIF_TEXT,_T("������� ������ - QSearchFrList$8"), 0, 0, 0, 0, 0, NULL, NULL);
	t.SetItemImage(item,2,2);
	item=t.InsertItem(TVIF_TEXT,_T("������� ������ - ShowSearchDlg$8"), 0, 0, 0, 0, 0, NULL, NULL);
	t.SetItemImage(item,2,2);
	item=t.InsertItem(TVIF_TEXT,_T("�������-������� ����"), 0, 0, 0, 0, 0, NULL, NULL);
	t.SetItemImage(item,2,2);
	item=t.InsertItem(TVIF_TEXT,_T("Callback getCrntPanelNum"), 0, 0, 0, 0, 0, NULL, NULL);
	t.SetItemImage(item,2,2);
	item=t.InsertItem(TVIF_TEXT,_T("Callback getPanelCrntItem"), 0, 0, 0, 0, 0, NULL, NULL);
	t.SetItemImage(item,2,2);
	item=t.InsertItem(TVIF_TEXT,_T("Callback getTotalPanels"), 0, 0, 0, 0, 0, NULL, NULL);
	t.SetItemImage(item,2,2);
	item=t.InsertItem(TVIF_TEXT,_T("Callback getPanelSelectedItems"), 0, 0, 0, 0, 0, NULL, NULL);
	t.SetItemImage(item,2,2);
	item=t.InsertItem(TVIF_TEXT,_T("callback readOptions"), 0, 0, 0, 0, 0, NULL, NULL);
	t.SetItemImage(item,2,2);
	item=t.InsertItem(TVIF_TEXT,_T("callback saveOptions"), 0, 0, 0, 0, 0, NULL, NULL);
	t.SetItemImage(item,2,2);
	item=t.InsertItem(TVIF_TEXT,_T("��������� GetMenuItemText"), 0, 0, 0, 0, 0, NULL, NULL);
	t.SetItemImage(item,2,2);
	item=t.InsertItem(TVIF_TEXT,_T("��������� GetMenuNum"), 0, 0, 0, 0, 0, NULL, NULL);
	t.SetItemImage(item,2,2);
	item=t.InsertItem(TVIF_TEXT,_T("��������� GetMenuPos"), 0, 0, 0, 0, 0, NULL, NULL);
	t.SetItemImage(item,2,2);
	item=t.InsertItem(TVIF_TEXT,_T("��������� GetMenuText"), 0, 0, 0, 0, 0, NULL, NULL);
	t.SetItemImage(item,2,2);
	item=t.InsertItem(TVIF_TEXT,_T("��������� GetPluginName"), 0, 0, 0, 0, 0, NULL, NULL);
	t.SetItemImage(item,2,2);
	item=t.InsertItem(TVIF_TEXT,_T("��������� GetPluginType"), 0, 0, 0, 0, 0, NULL, NULL);
	t.SetItemImage(item,2,2);
	item=t.InsertItem(TVIF_TEXT,_T("��������� Run$4"), 0, 0, 0, 0, 0, NULL, NULL);
	t.SetItemImage(item,2,2);
	item=t.InsertItem(TVIF_TEXT,_T("��������� SetCallbacks$4xxx"), 0, 0, 0, 0, 0, NULL, NULL);
	t.SetItemImage(item,2,2);
	item=t.InsertItem(TVIF_TEXT,_T("��������� SetId$4"), 0, 0, 0, 0, 0, NULL, NULL);
	t.SetItemImage(item,2,2);
	item=t.InsertItem(TVIF_TEXT,_T("������� ��������� ��������"), 0, 0, 0, 0, 0, NULL, NULL);
	t.SetItemImage(item,2,2);
	item=t.InsertItem(TVIF_TEXT,_T("������� ����������� ������"), 0, 0, 0, 0, 0, NULL, NULL);
	t.SetItemImage(item,2,2);
	item=t.InsertItem(TVIF_TEXT,_T("������������ ������� ���������/�������������� �������"), 0, 0, 0, 0, 0, NULL, NULL);
	t.SetItemImage(item,2,2);
	item=t.InsertItem(TVIF_TEXT,_T("������� �������� ���������"), 0, 0, 0, 0, 0, NULL, NULL);
	t.SetItemImage(item,2,2);
	item=t.InsertItem(TVIF_TEXT,_T("������������ �������"), 0, 0, 0, 0, 0, NULL, NULL);
	t.SetItemImage(item,2,2);
	item=t.InsertItem(TVIF_TEXT,_T("���������� �����"), 0, 0, 0, 0, 0, NULL, NULL);
	t.SetItemImage(item,2,2);

	listType = index;
Select:
	item = t.GetRootItem();
	if(sel>0 && sel<MAX_HTMLS)
	{	for(int i=0; i<sel; i++)
		{	item=t.GetNextVisibleItem(item);
			t.Expand(item,TVE_EXPAND);
		}
		t.SelectItem(item);
	}
	else if(!bDel)
		t.SelectItem(item);
}

void CLeftView::SetSearchPage(int sel)
{
BOOL bDel = FALSE;
	CTreeCtrl &t = GetTreeCtrl();
	if(listType==search)
	if(t.GetCount()!=0)
		goto Select;
	t.DeleteAllItems();
	bDel = TRUE;
/*
	TVINSERTSTRUCT tvInsert;
	HTREEITEM prnt;
	tvInsert.hParent = NULL;
	tvInsert.hInsertAfter = NULL;
	tvInsert.item.mask = TVIF_TEXT;//|TVIF_SELECTEDIMAGE|TVIF_IMAGE;
	//tvInsert.item.iSelectedImage = 0;
	//tvInsert.item.iImage = 0;
	//tvInsert.item.stateMask = 1;//TVIS_OVERLAYMASK;

	t.InsertItem(TVIF_TEXT,_T("Link via TCP/IP"), 0, 0, 0, 0, 0, NULL, NULL);
	t.InsertItem(TVIF_TEXT,_T("Plugins"), 0, 0, 0, 0, 0, NULL, NULL);
	t.InsertItem(TVIF_TEXT,_T("Archive plugins"), 0, 0, 0, 0, 0, NULL, NULL);
	t.InsertItem(TVIF_TEXT,_T("GetPluginType"), 0, 0, 0, 0, 0, NULL, NULL);
	t.InsertItem(TVIF_TEXT,_T("Open$12"), 0, 0, 0, 0, 0, NULL, NULL);
	t.InsertItem(TVIF_TEXT,_T("Close$4"), 0, 0, 0, 0, 0, NULL, NULL);
	t.InsertItem(TVIF_TEXT,_T("Add$24"), 0, 0, 0, 0, 0, NULL, NULL);
	t.InsertItem(TVIF_TEXT,_T("CreateDir$24"), 0, 0, 0, 0, 0, NULL, NULL);
	t.InsertItem(TVIF_TEXT,_T("RebuildCheckExistings$8"), 0, 0, 0, 0, 0, NULL, NULL);
	t.InsertItem(TVIF_TEXT,_T("SetCallbacks$4xxx"), 0, 0, 0, 0, 0, NULL, NULL);
	t.InsertItem(TVIF_TEXT,_T("Callback checkFileInSelctn"), 0, 0, 0, 0, 0, NULL, NULL);
	t.InsertItem(TVIF_TEXT,_T("Callback getFileInfoFromSelection"), 0, 0, 0, 0, 0, NULL, NULL);
	t.InsertItem(TVIF_TEXT,_T("Callback prgrssRout"), 0, 0, 0, 0, 0, NULL, NULL);
	t.InsertItem(TVIF_TEXT,_T("Callback showDlgOverwriteExistFile"), 0, 0, 0, 0, 0, NULL, NULL);
	t.InsertItem(TVIF_TEXT,_T("Callback saveOptions"), 0, 0, 0, 0, 0, NULL, NULL);
	t.InsertItem(TVIF_TEXT,_T("Callback readOptions"), 0, 0, 0, 0, 0, NULL, NULL);
*/
	listType = search;
Select:
	HTREEITEM item = t.GetRootItem();
	if(sel>0)
	{	for(int i=0; i<sel; i++)
		{	item=t.GetNextVisibleItem(item);
			t.Expand(item,TVE_EXPAND);
		}
		t.SelectItem(item);
	}
	else if(!bDel)
		t.SelectItem(item);
}

void CLeftView::OnItemExpanding(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_TREEVIEW* pNMTreeView = (NM_TREEVIEW*)pNMHDR;
	if(pNMTreeView->action == TVE_EXPAND)
	{	CTreeCtrl &t = GetTreeCtrl();
		int tot = t.GetCount();
		if(!tot)return;
		HTREEITEM item = t.GetRootItem();
		for(int i=0; i<tot; i++)
		{	if(item==pNMTreeView->itemNew.hItem)
			{	if(0==pNMTreeView->itemNew.lParam)
				{	t.SetItemImage(item,1,1);
					break;
			}	}
			item=t.GetNextVisibleItem(item);
	}	}
	else if(pNMTreeView->action == TVE_COLLAPSE)
	{	CTreeCtrl &t = GetTreeCtrl();
		int tot = t.GetCount();
		if(!tot)return;
		HTREEITEM item = t.GetRootItem();
		for(int i=0; i<tot; i++)
		{	if(item==pNMTreeView->itemNew.hItem)
			{	if(0==pNMTreeView->itemNew.lParam)
				{	t.SetItemImage(item,0,0);
					break;
			}	}
			item=t.GetNextVisibleItem(item);
	}	}
	*pResult = 0;
}

// CLeftView diagnostics

#ifdef _DEBUG
void CLeftView::AssertValid() const
{
	CTreeView::AssertValid();
}

void CLeftView::Dump(CDumpContext& dc) const
{
	CTreeView::Dump(dc);
}

CSinoSHlp32Doc* CLeftView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CSinoSHlp32Doc)));
	return (CSinoSHlp32Doc*)m_pDocument;
}
#endif //_DEBUG


// CLeftView message handlers
