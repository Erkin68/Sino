#include "windows.h"
#include "shlobj.h"
#include "strsafe.h"
#include "Psapi.h"
#include "Archive.h"
#include "..\..\Sino.h"
#include "..\..\config.h"
#include "..\..\Operations\MyErrors.h"
#include "..\..\operations\Temporary.h"
#include "..\..\Operations\Execution.h"
#include "..\..\operations\DeleteOperation.h"
#include "..\..\operations\MyShell\ComboToDisk.h"
#include "..\..\operations\MyShell\MyShell.h"
#include "..\..\operations\Backgrnd thread copy operation.h"



extern int GetFilesCntInFolder(wchar_t*);



namespace archive
{
int numPlugins;
CArchPlgn *plgns=NULL;
extern HWND *prgrsDlg;

wchar_t destArcName[MAX_PATH],password[MAX_PATH];
float cmqLevel;
int   srcPanel,crypt,iAppndToPanelArc,iApndDestPanel;//0-not exist,1-exist,but overwrite,2-appned,3-cancel;
BOOL  bExcldPath,bDelAftArchiving,bSFXArchive;

//Yangi yaratilayotgan arxiv nomini topish:
wchar_t* CreateNameForDestination(HWND dlg,LPARAM lParam,/*int arcType,*/int iPlgn)
{
	int srcPanel = ((Panel*)lParam)->iThis;
	int totFiles = (int)SendMessage(GetDlgItem(dlg,IDC_COMBO_FILES_TO_COPY),CB_GETCOUNT,0,0);
	if(totFiles<1) return NULL;
static wchar_t s[MAX_PATH];
	s[0]=0;
	if(1==totFiles)
	{	
CrAsFirstName:
		int ln=(int)SendMessage(GetDlgItem(dlg,IDC_COMBO_FILES_TO_COPY),CB_GETLBTEXT,0,(LPARAM)s);
		if(CB_ERR==ln)
			return NULL;
		wchar_t *p=wcschr(s,'.');
		//if(p)MyStringCpy(p+1,MAX_PATH-1,(char*)plgns[panel[srcPanel].GetArch()->GetPlgNum()].extnsn);//[conf::Dlg.crntArchvr]
		if(p)MyStringCpy(p+1,MAX_PATH-1,plgns[iPlgn].extnsn);
		else
		{	s[ln++]='.';
			//MyStringCpy(&s[ln],MAX_PATH-ln,(char*)plgns[panel[srcPanel].GetArch()->GetPlgNum()].extnsn);//MyStringCat(s
			MyStringCpy(&s[ln],MAX_PATH-ln,plgns[iPlgn].extnsn);
		}
		/*switch(arcType)
		{	case 0://zip
				char *p=strchr(s,'.');
				if(p)
				{	*(++p)='z';//*(p+1)=0;MyStringCat(s,MAX_PATH-1,L"zip");
					*(++p)='i';
					*(++p)='p';
					*(++p)=0;
				}
				else MyStringCat(s,MAX_PATH-1,L".zip");
				return s;
	}*/	
		return s;
	}
	//if totFiles>1
	panel[srcPanel].GetPath(s);
	int ln = MyStringLength(s,MAX_PATH-1);
	if(s[ln-1]=='*' && s[ln-2]=='\\'){ln-=2;s[ln]=0;}
	else if(s[ln-1]=='\\') s[--ln]=0;
	if(ln<3) goto CrAsFirstName;
	wchar_t *p = wcsrchr(s,'\\');
	if(p)
	{	ln = MyStringLength(p+1,ln);
		memcpy(s,p+1,sizeof(wchar_t)*(ln+1));
	}
	s[ln++]='.';
	MyStringCpy(&s[ln],MAX_PATH-ln,plgns[iPlgn/*panel[srcPanel].GetArch()->GetPlgNum()*/].extnsn);
	/*switch(arcType)
	{	case 0://zip
			s[ln++]='.';//MyStringCat(s,MAX_PATH-1,L".zip");
			s[ln++]='z';
			s[ln++]='i';
			s[ln++]='p';
			s[ln]=0;
			break;
	}*/
	return s;
}

int GetPackPlgn(int iPlg)
{
int k=0;
	for(int i=0; i<numPlugins; i++)
	{	if(1==plgns[i].type || 2==1==plgns[i].type)
		{	if(iPlg==k++)
				return i;
	}	}
	return 0;
}

int GetUnpackPlgnNum(wchar_t *ext)
{
	for(int i=0; i<numPlugins; i++)
	{	if(0==_wcsicmp(plgns[i].extnsn,ext))
			return i;
	}
	return -1;
}


INT_PTR CALLBACK DlgProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
static int iPanSel=0;
static HFONT hf=0;static int hfRef=0;//obshiy hf, dinamik uchun emas:
static HBRUSH br=0;
static HBRUSH brHtBk=0;
wchar_t s[MAX_PATH];
	UNREFERENCED_PARAMETER(lParam);
	
	switch (message)
	{
	case WM_INITDIALOG:
		//Adjust to center:
		RECT rc; GetWindowRect(hDlg, &rc);
		int width,left,height,top;

		width = rc.right - rc.left;
		left = conf::wndLeft + (conf::wndWidth - width)/2;

		height = rc.bottom - rc.top;
		top = conf::wndTop + (conf::wndHeight - height)/2;
		MoveWindow(hDlg, left, top+20, width, height, TRUE);

		//Load language strings:
		LoadString(hInst,IDS_STRINGSW_36,s,MAX_PATH-1);
		SetWindowText(hDlg,s);
		LoadString(hInst,IDS_STRINGSW_37,s,MAX_PATH-1);
		SetDlgItemText(hDlg,IDC_COPY_STATIC_1,s);
		LoadString(hInst,IDS_STRINGSW_38,s,MAX_PATH-1);
		SetDlgItemText(hDlg,IDC_COPY_STATIC_2,s);
		LoadString(hInst,IDS_STRINGSW_39,s,MAX_PATH-1);
		SetDlgItemText(hDlg,IDC_CHECK_EXCEPTION_OR_SELECTION,s);
		LoadString(hInst,IDS_STRINGSW_40,s,MAX_PATH-1);
		SetDlgItemText(hDlg,IDC_CHECK_EXCEPTION_OR_SELECTION1,s);
		LoadString(hInst,IDS_STRINGSW_41,s,MAX_PATH-1);
		SetDlgItemText(hDlg,IDOK,s);
		LoadString(hInst,IDS_STRINGSW_42,s,MAX_PATH-1);
		SetDlgItemText(hDlg,IDC_BUTTON_ADD_TO_QUEUE,s);
		LoadString(hInst,IDS_STRINGSW_13,s,MAX_PATH-1);
		SetDlgItemText(hDlg,IDCANCEL,s);
		LoadString(hInst,IDS_STRINGSW_43,s,MAX_PATH-1);
		SetDlgItemText(hDlg,IDC_CHECK_CHANGE_DEFAULT,s);
		LoadString(hInst,IDS_STRINGSW_44,s,MAX_PATH-1);
		SetDlgItemText(hDlg,IDC_COPY_STATIC_3,s);
		LoadString(hInst,IDS_STRINGSW_45,s,MAX_PATH-1);
		SetDlgItemText(hDlg,IDC_BUTTON_BROWSE,s);

		int iCmb,iCmbFrst,iFrst;iCmbFrst=iFrst=iCmb=0;
		for(int i=0; i<numPlugins; i++)
		{	if(1==plgns[i].type || 2==1==plgns[i].type)
			{if(plgns[i].descrpn[0])
				SendMessage(GetDlgItem(hDlg,IDC_COMBO_ARCHIVER),CB_ADDSTRING,0,(LPARAM)plgns[i].descrpn);
			 else
				 SendMessage(GetDlgItem(hDlg,IDC_COMBO_ARCHIVER),CB_ADDSTRING,0, (LPARAM)plgns[i].extnsn);
			if(i==conf::Dlg.crntArchvr){iCmbFrst=iCmb;iFrst=i;}
			 ++iCmb;
		}	}

		SendMessage(GetDlgItem(hDlg,IDC_COMBO_ARCHIVER),CB_SETCURSEL,iCmbFrst,0);

		SendMessage(GetDlgItem(hDlg,IDC_COMBO_CRYPT),CB_ADDSTRING,0,(LPARAM)L"no crypt");
		if(plgns[iFrst].LoadPlugin())
		{	for(int i=0; i<plgns[iFrst].GetTotalCryptMethods(); i++)
				SendMessage(GetDlgItem(hDlg,IDC_COMBO_CRYPT),CB_ADDSTRING,0,
					(LPARAM)plgns[iFrst].GetCryptDescription$4(i));
			SendMessage(GetDlgItem(hDlg,IDC_COMBO_CRYPT),CB_SETCURSEL,0,0);
			plgns[iFrst].FreePlugin();
		}

		SendMessage(GetDlgItem(hDlg,IDC_COMBO_CRYPT),CB_SETCURSEL,0,0);

		SendMessage(GetDlgItem(hDlg,IDC_CHECK_PASSWORD_ARCHIVE),BM_SETCHECK,BST_UNCHECKED,0);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_INCLUDE_PATH_ARCHIVE),BM_SETCHECK,BST_CHECKED,0);
		SendMessage(GetDlgItem(hDlg,IDC_SLIDER_FASTER),TBM_SETPOS,TRUE,conf::cmqLevPerCent);//75 edi

		EnableWindow(GetDlgItem(hDlg,IDC_EDIT_PASSWORD_ARCHIVE),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_EDIT_PASSWORD_ARCHIVE2),FALSE);

		arcCrNamesCB.Read(arcCrNamesCBFName,GetDlgItem(hDlg,IDC_EDIT_DEST_ARCHIVE),40,MAX_PATH);

		wchar_t s[MAX_PATH];
		if(lParam)
		{	if(!fCopyOper::FillCopyFilesInfo(hDlg,lParam,iPanSel))
				EndDialog(hDlg,TRUE);
			wchar_t *arcName = CreateNameForDestination(hDlg,lParam,iFrst);
			panel[((Panel*)lParam)->iOpponent].GetPath(s);//((Panel*)lParam)->GetPath(s);
			int ln = MyStringLength(s,MAX_PATH-1);
			if(s[ln-1]=='*' && s[ln-2]=='\\'){s[ln-2]=0;ln-=2;}
			else if(s[ln-1]=='\\') s[--ln]=0;
			s[ln++]='\\';////MyStringCat(s,MAX_PATH-1,L"\\");
			MyStringCpy(&s[ln],MAX_PATH-ln,arcName);//MyStringCat(s,MAX_PATH-1,arcName);
			CBToDisk::AddToCB(GetDlgItem(hDlg,IDC_EDIT_DEST_ARCHIVE),s);//SetDlgItemText(hDlg,IDC_EDIT_DEST_ARCHIVE,s);
			int sel=(int)SendMessage(GetDlgItem(hDlg,IDC_EDIT_DEST_ARCHIVE),CB_FINDSTRING,-1,(LPARAM)s); 
			SendMessage(GetDlgItem(hDlg,IDC_EDIT_DEST_ARCHIVE),CB_SETCURSEL,sel,0);
		}

		SendMessage(hDlg,WM_USER+1,0,0);
		HWND h;h=SetFocus(GetDlgItem(hDlg,IDOK));//Ownedrawda defaultbutton bo'lmaydur;
		SetWindowLong(hDlg,GWLP_USERDATA,(LONG)lParam);
		return TRUE;
	case WM_CTLCOLORSTATIC:
	case WM_CTLCOLORDLG:HDC dc;dc = (HDC)wParam;
		SetTextColor(dc,conf::Dlg.dlgRGBs[0][1]);
		SetBkColor(dc,conf::Dlg.dlgRGBs[0][2]);
		return (INT_PTR)br;
	case WM_CTLCOLOREDIT:dc = (HDC)wParam;
		SetTextColor(dc,conf::Dlg.dlgRGBs[0][1]);
		SetBkColor(dc,conf::Dlg.dlgRGBs[0][2]);
		return (INT_PTR)br;
	case WM_CTLCOLORBTN:dc=(HDC)wParam;
		SetTextColor(dc,conf::Dlg.dlgRGBs[0][4]);
		SetBkColor(dc,conf::Dlg.dlgRGBs[0][5]);
		return (INT_PTR)brHtBk;
	case WM_DRAWITEM://WM_CTLCOLORBTN dagi knopkalar:
		LPDRAWITEMSTRUCT lpdis;lpdis = (LPDRAWITEMSTRUCT)lParam;
		GetWindowText(lpdis->hwndItem,s,MAX_PATH);
		UINT uStyle;uStyle = DFCS_BUTTONPUSH;
		rc = lpdis->rcItem;
		if(lpdis->itemState & ODS_SELECTED)
		{	uStyle |= DFCS_PUSHED|DFCS_TRANSPARENT;
			rc.left+=2;rc.top+=2;
		}
		DrawFrameControl(lpdis->hDC, &lpdis->rcItem, DFC_BUTTON, uStyle);
		if(lpdis->itemState & ODS_SELECTED)
			{rc.left+=1;rc.top+=1;rc.bottom-=2;rc.right-=3;}
		else
			{rc.left+=1;rc.top+=2;rc.bottom-=3;rc.right-=3;}
		FillRect(lpdis->hDC,&rc,brHtBk);//DrawText(lpdis->hDC,L"",50,&rc,DT_SINGLELINE|DT_VCENTER|DT_INTERNAL|DT_LEFT);
		if(lpdis->itemState & ODS_SELECTED)
			{rc.left-=1;rc.top-=1;rc.bottom+=3;rc.right+=3;}
		else
			{rc.left-=1;rc.top-=2;rc.bottom+=2;rc.right+=3;}
		DrawText(lpdis->hDC,s,MyStringLength(s,MAX_PATH),&rc,DT_SINGLELINE|DT_VCENTER|DT_CENTER);
		return TRUE;
	case WM_USER+1://hf obshiy uchun, dinamik o'zgartirish uchun emas:
		if(0==hfRef)
		{	hf = CreateFontIndirect(&conf::Dlg.dlgFnts[0]);
			br = CreateSolidBrush(conf::Dlg.dlgRGBs[0][0]);
			brHtBk = CreateSolidBrush(conf::Dlg.dlgRGBs[0][5]);
		}
		SendMessage(GetDlgItem(hDlg,IDC_BUTTON_BROWSE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDOK),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDCANCEL),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_COPY_STATIC_1),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_COPY_STATIC_2),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_COPY_STATIC_3),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_COPY_STATIC_4),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_COPY_STATIC_5),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_FILES_TO_COPY),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_DEST_ARCHIVE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_ARCHIVER),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_PASSWORD_ARCHIVE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_INCLUDE_PATH_ARCHIVE),WM_SETFONT,(WPARAM)hf,TRUE);
		++hfRef;
		return 0;//GWLP_USERDATA
	case WM_DESTROY:
		if(--hfRef<1)
		{	DeleteObject(hf);
			DeleteObject(br);
			DeleteObject(brHtBk);
		}
		return 0;
	case WM_COMMAND:
		switch(LOWORD(wParam))
		{	case IDC_COMBO_ARCHIVER:
				if(CBN_SELCHANGE==HIWORD(wParam))
				{	wchar_t *p;int iplg=GetPackPlgn((int)SendMessage(GetDlgItem(hDlg,IDC_COMBO_ARCHIVER),CB_GETCURSEL,0,0));
					if(CB_ERR==iplg)break;
					if(iplg>numPlugins-1)break;
					SendMessage(GetDlgItem(hDlg,IDC_COMBO_CRYPT),CB_RESETCONTENT,0,0);
					SendMessage(GetDlgItem(hDlg,IDC_COMBO_CRYPT),CB_ADDSTRING,0,(LPARAM)L"no crypt");
					if(plgns[iplg].LoadPlugin())
					{	for(int i=0; i<plgns[iplg].GetTotalCryptMethods(); i++)
							SendMessage(GetDlgItem(hDlg,IDC_COMBO_CRYPT),CB_ADDSTRING,0,
									(LPARAM)plgns[iplg].GetCryptDescription$4(i));					
						GetDlgItemText(hDlg,IDC_EDIT_DEST_ARCHIVE,s,MAX_PATH);
						p=wcsrchr(s,'.');
						if(p) MyStringCpy(p+1,MAX_PATH-1,(wchar_t*)plgns[iplg].extnsn);
						SetDlgItemText(hDlg,IDC_EDIT_DEST_ARCHIVE,s);
						plgns[iplg].FreePlugin();
				}	}
				break;
			case IDC_COMBO_CRYPT:
				if(CBN_SELCHANGE==HIWORD(wParam))
				{	int icrpt=(int)SendMessage(GetDlgItem(hDlg,IDC_COMBO_CRYPT),CB_GETCURSEL,0,0);
					if(icrpt>0)
					{	if(BST_CHECKED!=SendMessage(GetDlgItem(hDlg,IDC_CHECK_PASSWORD_ARCHIVE),BM_GETCHECK,0,0))
						{	SendMessage(GetDlgItem(hDlg,IDC_COMBO_CRYPT),CB_SETCURSEL,0,0);
	SetPassword:			Err::msg(hDlg,0,L"Please, before set password for crypting.");
							break;						
						}
						if(!GetDlgItemText(hDlg,IDC_EDIT_PASSWORD_ARCHIVE,s,MAX_PATH))
							goto SetPassword;
						if(!GetDlgItemText(hDlg,IDC_EDIT_PASSWORD_ARCHIVE2,s,MAX_PATH))
							goto SetPassword;
					}
					if(CB_ERR==icrpt)break;
					crypt = icrpt;
				}
				break;
			case IDC_CHECK_PASSWORD_ARCHIVE:
				if(BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_PASSWORD_ARCHIVE),BM_GETCHECK,0,0))
				{	EnableWindow(GetDlgItem(hDlg,IDC_EDIT_PASSWORD_ARCHIVE),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_PASSWORD_ARCHIVE2),TRUE);
					SendMessage(GetDlgItem(hDlg,IDC_COMBO_CRYPT),CB_SETCURSEL,0,1);					
				}
				else
				{	EnableWindow(GetDlgItem(hDlg,IDC_EDIT_PASSWORD_ARCHIVE),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_PASSWORD_ARCHIVE2),FALSE);
				}
				break;
			case IDC_CHECK_DELETE_AFTER_ARCHIVE:
				bDelAftArchiving = (BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_DELETE_AFTER_ARCHIVE),BM_GETCHECK,0,0));
				break;
			case IDC_CHECK_INCLUDE_SFX_ARCHIVE:wchar_t *p;
				int iplgn;iplgn=GetPackPlgn((int)SendMessage(GetDlgItem(hDlg,IDC_COMBO_ARCHIVER),CB_GETCURSEL,0,0));
				bSFXArchive = (BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_INCLUDE_SFX_ARCHIVE),BM_GETCHECK,0,0));
				GetDlgItemText(hDlg,IDC_EDIT_DEST_ARCHIVE,s,MAX_PATH);
				p=wcsrchr(s,'.');
				if(p)
				{	if(bSFXArchive) {*(++p)='e'; *(++p)='x'; *(++p)='e'; *(++p)=0;}
					else MyStringCpy(p+1,MAX_PATH-1,(wchar_t*)plgns[iplgn].extnsn);
				}
				SetDlgItemText(hDlg,IDC_EDIT_DEST_ARCHIVE,s);
				break;
			case IDC_BUTTON_ARCHIVER_OPTION:
				iplgn=GetPackPlgn((int)SendMessage(GetDlgItem(hDlg,IDC_COMBO_ARCHIVER),CB_GETCURSEL,0,0));
				if(plgns[iplgn].LoadPlugin())
				{	if(iplgn>-1 && iplgn<numPlugins)
					if(plgns[iplgn].ShowOptionDialog)
						plgns[iplgn].ShowOptionDialog(hDlg);
					plgns[iplgn].FreePlugin();
				}
				break;
			case IDC_COMBO_PANEL:wchar_t pth[MAX_PATH];
				if(CBN_SELCHANGE==HIWORD(wParam))
				{	int iPanSel=(int)SendMessage(GetDlgItem(hDlg,IDC_COMBO_PANEL),CB_GETCURSEL,0,0);
					SendMessageA(GetDlgItem(hDlg,IDC_COMBO_PANEL),CB_GETLBTEXT,iPanSel,(LPARAM)s);
					panel[_wtoi(s)-1].GetPath(pth);
					MyStringRemoveLastCharCheckPre(pth,MAX_PATH-1,'*','\\');
					GetDlgItemText(hDlg,IDC_EDIT_DEST_ARCHIVE,s,MAX_PATH);
					wchar_t *p = wcsrchr(s,'\\');
					if(p)
					{	MyStringCat(pth,MAX_PATH-1,p+1);
						SetDlgItemText(hDlg,IDC_EDIT_DEST_ARCHIVE,pth);
				}	}
				break;
			case IDC_BUTTON_BROWSE:
				BROWSEINFO bi; 
				bi.hwndOwner = hDlg;
				bi.pszDisplayName = s;
				bi.lpszTitle = L"Create archive to folder ...";
				bi.ulFlags = BIF_NONEWFOLDERBUTTON|BIF_DONTGOBELOWDOMAIN|BIF_NEWDIALOGSTYLE|
					BIF_NOTRANSLATETARGETS|BIF_RETURNFSANCESTORS;
				bi.lpfn = NULL;
				LPITEMIDLIST pidlRoot;pidlRoot = NULL;
				bi.pidlRoot = pidlRoot;
				LPITEMIDLIST pidlSelected;pidlSelected = SHBrowseForFolder(&bi);
				if(pidlRoot)
					CoTaskMemFree(pidlRoot);
				if(pidlSelected)
				{	SHGetPathFromIDList(pidlSelected,s);
					int ln = MyStringLength(s,MAX_PATH-1);
					GetDlgItemText(hDlg,IDC_EDIT_DEST_ARCHIVE,pth,MAX_PATH);
					wchar_t *p = wcsrchr(pth,'\\');
					if(p)
					{	if(ln>0)
						{	MyStringCat(s,MAX_PATH-1,s[ln-1]=='\\'?p+1:p);
							SetDlgItemText(hDlg,IDC_EDIT_DEST_ARCHIVE,s);
						}
						else// MyStringCat(s,MAX_PATH-1,p+1);
							SetDlgItemText(hDlg,IDC_EDIT_DEST_ARCHIVE,p+1);
					}
					else
					{	MyStringCat(s,MAX_PATH-1,pth);
						SetDlgItemText(hDlg,IDC_EDIT_DEST_ARCHIVE,s);
					}
					CoTaskMemFree(pidlSelected);
				}
	   			return (INT_PTR)TRUE;
			case IDOK:
				if(BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_PASSWORD_ARCHIVE),BM_GETCHECK,0,0))
				{	GetDlgItemText(hDlg,IDC_EDIT_PASSWORD_ARCHIVE,password,MAX_PATH);
					GetDlgItemText(hDlg,IDC_EDIT_PASSWORD_ARCHIVE2,s,MAX_PATH);
					if(wcscmp(s,password))
					{	Err::msg1(hDlg,0,L"Password and verify password are unindentical.",L"Please,enter the same word.");
						return TRUE;
				}	}
				else password[0]=0;
				//i=SendMessage(GetDlgItem(hDlg,IDC_EDIT_DEST_ARCHIVE),CB_GETLBTEXT,i,(LPARAM)destArcName);
				COMBOBOXINFO ci;ci.cbSize=sizeof(ci);
				if(!GetComboBoxInfo(GetDlgItem(hDlg,IDC_EDIT_DEST_ARCHIVE),&ci)) return TRUE;
				GetWindowText(ci.hwndItem,destArcName,MAX_PATH);

				conf::cmqLevPerCent=(char)SendMessage(GetDlgItem(hDlg,IDC_SLIDER_FASTER),TBM_GETPOS,0,0);
				int cmqMax;cmqMax=(int)SendMessage(GetDlgItem(hDlg,IDC_SLIDER_FASTER),TBM_GETRANGEMAX,0,0);
				int cmqMin;cmqMin=(int)SendMessage(GetDlgItem(hDlg,IDC_SLIDER_FASTER),TBM_GETRANGEMIN,0,0);
				if(cmqMax!=cmqMin) cmqLevel = (float)conf::cmqLevPerCent/(float)(cmqMax-cmqMin);
				else cmqLevel = 0.0f;
				conf::Dlg.crntArchvr = GetPackPlgn((int)SendMessage(GetDlgItem(hDlg,IDC_COMBO_ARCHIVER),CB_GETCURSEL,0,0));
				bExcldPath=(BST_CHECKED!=SendMessage(GetDlgItem(hDlg,IDC_CHECK_INCLUDE_PATH_ARCHIVE),BM_GETCHECK,0,0));
				arcCrNamesCB.Save(arcCrNamesCBFName,GetDlgItem(hDlg,IDC_EDIT_DEST_ARCHIVE),40);
				EndDialog(hDlg, 1);
				return (INT_PTR)TRUE;
			case IDCANCEL:
				//if(!GetWindowLong(hDlg,GWLP_USERDATA)) return TRUE;
				EndDialog(hDlg, 0);
				return (INT_PTR)TRUE;
		}
		break;
	}
	return (INT_PTR)FALSE;
}


VOID TryLoadPlugin(wchar_t *pth,wchar_t* name,int l)
{//LoadLibrary da exception beradur;
	if(numPlugins>conf::Dlg.totalAllovedArchvr)
	{	Err::msg(hWnd,0,L"There are any archiver plugins(above 20), ignore others...");
		return;
	}

	MyStringCpy(&pth[l],MAX_PATH-1,name);
//HMODULE hm = LoadLibraryEx(pth,NULL,LOAD_LIBRARY_AS_IMAGE_RESOURCE);//LOAD_LIBRARY_AS_DATAFILE);
//	if(!hm)return;
//	FreeLibrary(hm);
//	char st[260]; char *p=strrchr(pth,'\\');if(p)*p=0;
//	if(32>(int)FindExecutable(name,pth,st)) return;


//	DWORD bt;
//	if(!GetBinaryType(pth,&bt))return;


	if(!Execution::IsThisValidDllFile(pth))
		return;

BEGIN_TRY


HMODULE hm = LoadLibraryEx(pth,NULL,DONT_RESOLVE_DLL_REFERENCES);
	if(!hm)
	{	Err::msg(hWnd,-1,pth);
		return;
	}

	GetArchExtnsn_t GetArchExtnsn = (GetArchExtnsn_t)GetProcAddress(hm,"GetArchExtnsn");
	if(!GetArchExtnsn)//goto Fall;
	{		
Fall:	FreeLibrary(hm);             //shart emas, unpack archive bo'lishi mumkin;
		return;
	}
	GetPluginType_t GetPluginType = (GetPluginType_t)GetProcAddress(hm,"GetPluginType");
	if(!GetPluginType) goto Fall;
	Open$12_t Open$12 = (Open$12_t)GetProcAddress(hm,"Open$12");
	if(!Open$12) goto Fall;
	Close$4_t Close$4 = (Close$4_t)GetProcAddress(hm,"Close$4");
	if(!Close$4) goto Fall;
	SetCallbacks$4xxx_t SetCallbacks$4xxx = (SetCallbacks$4xxx_t)GetProcAddress(hm,"SetCallbacks$4xxx");
	if(!SetCallbacks$4xxx) goto Fall;

	FreeLibrary(hm);
	hm = LoadLibrary(pth);//DllMain ni yuklasin, endi;
	GetArchExtnsn = (GetArchExtnsn_t)GetProcAddress(hm,"GetArchExtnsn");
	GetPluginType = (GetPluginType_t)GetProcAddress(hm,"GetPluginType");
	Open$12 = (Open$12_t)GetProcAddress(hm,"Open$12");
	Close$4 = (Close$4_t)GetProcAddress(hm,"Close$4");
	SetCallbacks$4xxx = (SetCallbacks$4xxx_t)GetProcAddress(hm,"SetCallbacks$4xxx");

	Add$24_t Add$24 = (Add$24_t)GetProcAddress(hm,"Add$24");
	CreateDir$24_t CreateDir$24 = (CreateDir$24_t)GetProcAddress(hm,"CreateDir$24");
	AddEmptyDir$20_t AddEmptyDir$20 = (AddEmptyDir$20_t)GetProcAddress(hm,"AddEmptyDir$20");
	RebuildCheckExistings$8_t RebuildCheckExistings$8 = (RebuildCheckExistings$8_t)
										GetProcAddress(hm,"RebuildCheckExistings$8");
	RenameFile$12_t RenameFile$12 = (RenameFile$12_t)GetProcAddress(hm,"RenameFile$12");
	RenameDir$12_t RenameDir$12 = (RenameDir$12_t)GetProcAddress(hm,"RenameDir$12");
	DeleteFile$8_t DeleteFile$8 = (DeleteFile$8_t)GetProcAddress(hm,"DeleteFile$8");
	DeleteDir$8_t DeleteDir$8 = (DeleteDir$8_t)GetProcAddress(hm,"DeleteDir$8");
	GetTotalCryptMethods_t GetTotalCryptMethods = (GetTotalCryptMethods_t)GetProcAddress(hm,"GetTotalCryptMethods");
	GetCryptDescription$4_t GetCryptDescription$4 = (GetCryptDescription$4_t)
												GetProcAddress(hm,"GetCryptDescription$4");
	SetCryptMethod$8_t SetCryptMethod$8 = (SetCryptMethod$8_t)GetProcAddress(hm,"SetCryptMethod$8");
	GetPluginDescription_t GetPluginDescription = (GetPluginDescription_t)GetProcAddress(hm,"GetPluginDescription");
	ShowOptionDialog_t ShowOptionDialog = (ShowOptionDialog_t)GetProcAddress(hm,"ShowOptionDialog");
	SetId$4_t SetId$4 = (SetId$4_t)GetProcAddress(hm,"SetId$4");

	//Unpacking:
	OpenForUnpacking$8_t OpenForUnpacking$8 = (OpenForUnpacking$8_t)GetProcAddress(hm,"OpenForUnpacking$8");
	EnumDirectory$8_t EnumDirectory$8 = (EnumDirectory$8_t)GetProcAddress(hm,"EnumDirectory$8");
	Unpack$28_t Unpack$28 = (Unpack$28_t)GetProcAddress(hm,"Unpack$28");
	ShowSearchDlg$12_t ShowSearchDlg$12 = (ShowSearchDlg$12_t)GetProcAddress(hm,"ShowSearchDlg$12");

	int t=GetPluginType();
	if(t<1 || t>3) goto Fall;
	MODULEINFO mi;
	GetModuleInformation(GetCurrentProcess(),hm,&mi,sizeof(mi));

	/*for(int i=0; i<numPlugins; i++)
	{	//if(plgns[i].dllSize==mi.SizeOfImage)
		if(!strcmp(plgns[i].extnsn,extnsn))
			return;//goto Fall;
	}*/

	if(!plgns) plgns = (CArchPlgn*)malloc((numPlugins+1)*sizeof(CArchPlgn));
	else  plgns = (CArchPlgn*)realloc(plgns,(numPlugins+1)*sizeof(CArchPlgn));
	plgns[numPlugins].CArchPlgn::CArchPlgn();
	plgns[numPlugins].Add$24 = Add$24;
	plgns[numPlugins].CreateDir$24 = CreateDir$24;
	plgns[numPlugins].GetArchExtnsn = GetArchExtnsn;
	plgns[numPlugins].GetPluginType = GetPluginType;
	plgns[numPlugins].Open$12 = Open$12;
	plgns[numPlugins].Close$4 = Close$4;
	plgns[numPlugins].RebuildCheckExistings$8 = RebuildCheckExistings$8;
	plgns[numPlugins].RenameFile$12 = RenameFile$12;
	plgns[numPlugins].RenameDir$12 = RenameDir$12;
	plgns[numPlugins].DeleteFile$8 = DeleteFile$8;
	plgns[numPlugins].DeleteDir$8 = DeleteDir$8;
	plgns[numPlugins].SetCallbacks$4xxx = SetCallbacks$4xxx;
	plgns[numPlugins].GetTotalCryptMethods = GetTotalCryptMethods;
	plgns[numPlugins].GetCryptDescription$4 = GetCryptDescription$4;
	plgns[numPlugins].SetCryptMethod$8 = SetCryptMethod$8;
	plgns[numPlugins].GetPluginDescription = GetPluginDescription;
	plgns[numPlugins].ShowSearchDlg$12 = ShowSearchDlg$12;

	//Unpacking:
	plgns[numPlugins].OpenForUnpacking$8 = OpenForUnpacking$8;
	plgns[numPlugins].EnumDirectory$8 = EnumDirectory$8;
	plgns[numPlugins].Unpack$28 = Unpack$28;
	plgns[numPlugins].SetId$4 = SetId$4;

	plgns[numPlugins].type = t;
	if(GetPluginDescription)MyStringCpy(plgns[numPlugins].descrpn,MAX_PATH,(wchar_t*)GetPluginDescription());
	else plgns[numPlugins].descrpn[0]=0;
	if(GetArchExtnsn)MyStringCpy(plgns[numPlugins].extnsn,32,(wchar_t*)GetArchExtnsn());
	else plgns[numPlugins].extnsn[0]=0;
	SetCallbacks$4xxx(	CArchPlgn::checkFileInSelctn,
						CArchPlgn::excldFileFrSelctn,
						CArchPlgn::getFileInfoFromSelection,
						CArchPlgn::prgrssRout,
						CArchPlgn::showDlgOverwriteExistFile,
						CArchPlgn::saveOptions,
						CArchPlgn::readOptions,
						CArchPlgn::addItemToPanelList);
	MyStringCpy(plgns[numPlugins].pathAndName,MAX_PATH-1,pth);
	plgns[numPlugins].idNum = numPlugins;
	plgns[numPlugins].SetId$4(numPlugins);
	//plgns[numPlugins].dllSize = mi.SizeOfImage;

	plgns[numPlugins].FreePlugin();

	if(conf::Dlg.crntArchvr<0)conf::Dlg.crntArchvr=numPlugins;
	++numPlugins;
END_TRY
{
	Err::msg1(NULL,0,pth,L"Err.loading arch.plgn.");
}}

VOID ListArchDirLoadPlugins(wchar_t *path)
{
wchar_t s[MAX_PATH];
WIN32_FIND_DATA ff;
HANDLE hf = INVALID_HANDLE_VALUE;
	int l=MyStringCpy(s,MAX_PATH-1,path);
	if(MyStringRemoveLastCharCheckPre(s,MAX_PATH-1,'*','\\'))
		--l;

	hf = MyFindFirstFileEx(path,FindExInfoStandard,&ff,FindExSearchLimitToDirectories,NULL,0);
	do
	{	if(INVALID_HANDLE_VALUE==hf) return;
		if(FILE_ATTRIBUTE_DIRECTORY & ff.dwFileAttributes)//if(IsDirectory(path, &ff, FALSE))
		{	if(IsCrntOrPrntDirAttrb(ff.cFileName))
			{	int n=MyStringCpy(&s[l],MAX_PATH-1,ff.cFileName);
				MyStringCpy(&s[l+n],MAX_PATH-1-l,L"\\*");
				ListArchDirLoadPlugins(s);
		}	}
		else
			TryLoadPlugin(s,ff.cFileName,l);
	}
	while(FindNextFile(hf, &ff));
	FindClose(hf);
}

VOID FreePlugins()//CArch::~CArch ga qara, ochiq qolib ketgan arxivlar qoladur;
{
	//free(plgns);
	//plgns=NULL;
	//numPlugins=0;
}

VOID LoadPlugins()
{
	numPlugins=0;
	wchar_t *arcPlgPth = MyStringAddModulePath(L"Plugins\\Archive\\*");
	ListArchDirLoadPlugins(arcPlgPth);
}

INT_PTR CALLBACK arcExstOvwrtQuestnDlgProc(HWND hDlg,UINT message,WPARAM wParam,LPARAM lParam)
{
	UNREFERENCED_PARAMETER(lParam);
	switch(message)
	{
	case WM_INITDIALOG:
		//Adjust to center:
		RECT rc,rcPrnt; GetWindowRect(hDlg, &rc);
		HWND prnt;prnt = GetParent(hDlg);
		if(!prnt)prnt=GetDesktopWindow();
		GetWindowRect(prnt,&rcPrnt);
		int width,left,height,top;

		width = rc.right - rc.left;
		left = rcPrnt.left + (rcPrnt.right-rcPrnt.left - width)/2;
		if(left>rcPrnt.right-rcPrnt.left-width)left=rcPrnt.left;

		height = rc.bottom - rc.top;
		top = rcPrnt.top + (rcPrnt.bottom-rcPrnt.top - height)/2;
		if(top>rcPrnt.bottom-rcPrnt.top-top)top=rcPrnt.top;
		MoveWindow(hDlg, left, top+20, width, height, TRUE);

		//Load language strings:
		wchar_t s[MAX_PATH];
		/*LoadString(hInst,IDS_STRINGSW_235,s,MAX_PATH);//45
		SetWindowText(hDlg,s);
		LoadString(hInst,IDS_STRINGSW_47,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_STATIC,s);
		LoadString(hInst,IDS_STRINGSW_48,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_STATIC5,s);*/
		SetDlgItemText(hDlg,IDC_EDIT_ARC_NAME,((CArch*)lParam)->name);
		SetDlgItemText(hDlg,IDC_EDIT_ARC_RENAME,((CArch*)lParam)->name);		
		SetWindowLong(hDlg,GWLP_USERDATA,(LONG)lParam);
		return TRUE;
	case WM_DESTROY:
		return 0;
	case WM_COMMAND:
		switch(LOWORD(wParam))
		{	case IDOK://overwrite
				EndDialog(hDlg,1);
				return (INT_PTR)TRUE;
			case IDAPPEND:
				EndDialog(hDlg,2);
				return (INT_PTR)TRUE;
			case IDCANCEL:
				EndDialog(hDlg,3);
				return (INT_PTR)TRUE;
			case IDOVERWRITE_NEW:
				GetDlgItemText(hDlg,IDC_EDIT_ARC_RENAME,s,MAX_PATH);
				if(!IsFileExist(s))
				{	Err::msg1(hWnd,0,L"File already exist, choise other",s);
					return (INT_PTR)TRUE;
				}//else
				CArch *lPar=(CArch*)GetWindowLong(hDlg,GWLP_USERDATA);
				lPar->nameLn = MyStringCpy(lPar->name,MAX_PATH-1,s);
				EndDialog(hDlg,1);//rename as create new with new name;
				return (INT_PTR)TRUE;
		}
		break;
	}
	return (INT_PTR)FALSE;
}

BOOL CutSelectedNames(ArcStack *st, wchar_t *srcPth, int tot)//, BOOL bUnicodeConvert)
{
wchar_t src[MAX_PATH]; MyStringCpy(src,MAX_PATH-1,srcPth);
	MyStringRemoveLastCharCheckPre(src,MAX_PATH-1,'*','\\');
	for(int i=0; i<tot; i++)
	{	wchar_t *mismatchPtr = MyStringFindFirstUnmatch(st[i].FullPathAndName,src,MAX_PATH);
		if(mismatchPtr)
		{	//st[i].RelatedPathAndNameLn =
			//		MyStringCpy(st[i].RelatedPathAndName,MAX_PATH-1,mismatchPtr);
			for(st[i].RelatedPathAndNameLn=0;*mismatchPtr;st[i].RelatedPathAndNameLn++)
			{	if('\\'==(*mismatchPtr))
					st[i].RelatedPathAndName[st[i].RelatedPathAndNameLn]='/';
				else
					st[i].RelatedPathAndName[st[i].RelatedPathAndNameLn]=*mismatchPtr;
				++mismatchPtr;
			}
			st[i].RelatedPathAndName[st[i].RelatedPathAndNameLn]=0;
			//if(bUnicodeConvert)
			//{	BOOL bAnsi=AreFileApisANSI();
			//	if(bAnsi)
			//	{	wchar_t s[MAX_PATH];
			//		MultiByteToWideChar(AreFileApisANSI()?CP_ACP:CP_OEMCP,MB_PRECOMPOSED,st[i].RelatedPathAndName,MAX_PATH-1,s,MAX_PATH);
			//		WideCharToMultiByte(AreFileApisANSI()?CP_ACP:CP_OEMCP,WC_COMPOSITECHECK,s,-1,st[i].RelatedPathAndName,MAX_PATH-1,NULL,NULL);
	}	}	//}	}
	return TRUE;
}

BOOL AddPanArcPathToDestNames(ArcStack *st, wchar_t *arcPth, int tot)
{
wchar_t s[MAX_PATH];
	for(int i=0; i<tot; i++)
	{	memcpy(s,st[i].RelatedPathAndName,sizeof(wchar_t)*(st[i].RelatedPathAndNameLn+1));
		int l=MyStringCpy(st[i].RelatedPathAndName,MAX_PATH-1,arcPth);
		memcpy(&st[i].RelatedPathAndName[l],s,sizeof(wchar_t)*(st[i].RelatedPathAndNameLn+1));
		st[i].RelatedPathAndNameLn+=l;
		//BOOL bAnsi=AreFileApisANSI();
		//if(bAnsi)
		//{	wchar_t s[MAX_PATH];
		//	MultiByteToWideChar(AreFileApisANSI()?CP_ACP:CP_OEMCP,MB_PRECOMPOSED,st[i].RelatedPathAndName,MAX_PATH-1,s,MAX_PATH);
		//	WideCharToMultiByte(AreFileApisANSI()?CP_ACP:CP_OEMCP,WC_COMPOSITECHECK,s,-1,st[i].RelatedPathAndName,MAX_PATH-1,NULL,NULL);
	}	//}
	return TRUE;
}	

VOID buildArchvThrdFnc(LPVOID lpar)
{
 //2.Arxivni ochamiz:
CArch arch;
arch.hDlg = (HWND)lpar;
arch.bStop = FALSE;
arch.bCancel = FALSE;
arch.thrId = GetCurrentThreadId();
arch.beginTick = arch.beginTickTot = GetTickCount();
arch.stopTick[0] = arch.stopTickTot[0] = 0;
arch.cmqlev=(int)(cmqLevel * 9.0f);
arch.crypt = crypt;
arch.bDelAftArchiving=bDelAftArchiving;
arch.bExcldPath=bExcldPath;
arch.bSFXArchive=bSFXArchive;
enCheckCopyFilesToExisting = showEach;

 MyStringCpy(arch.password,MAX_PATH-1,password);
 arch.nameLn=MyStringCpy(arch.name,MAX_PATH-1,destArcName);//destArcName ni bo'shatamiz;
 //Srazu dst ga kopi qilib olaylik,keyingi threadga bo'shatish uchun;

 arch.totFiles = arch.GetSelectedFilesCnt(srcPanel);
 if(!arch.totFiles)goto End;
 arch.stack = (ArcStack*)malloc(arch.totFiles*sizeof(ArcStack));
 arch.GetSelectedFiles();
 CutSelectedNames(arch.stack,panel[srcPanel].GetPath(),arch.totFiles);//,0==iAppndToPanelArc?FALSE:TRUE);
 if(0==iAppndToPanelArc)AddPanArcPathToDestNames(arch.stack,panel[iApndDestPanel].GetArcPath(),arch.totFiles);
 arch.plgNum=panel[iApndDestPanel].GetArch()->GetPlgNum();
 BOOL bSkipAll=FALSE;

 //1.Avval dest arc bormi, o'zi, shuni aniqlaymiz:
 int iThrdArcFileExist=0;
 if(0==iAppndToPanelArc)//Append to opened arc,use EndDialog;
	 iThrdArcFileExist=2;
 else
 {	if(IsFileExist(arch.name))
	{	 iThrdArcFileExist=(int)DialogBoxParam(hInst,MAKEINTRESOURCE(IDD_DIALOG_ARCH_EXIST_OVEWRITE),
							arch.hDlg,arcExstOvwrtQuestnDlgProc,(LPARAM)&arch);
		if(3==iThrdArcFileExist) goto End;
 }	}

 //2.Arch file ni ochamiz.
 SetDlgItemText(arch.hDlg,IDC_STATIC5/*Total proggress*/,arch.name);
 arch.Open$12(arch.name,arch.plgNum,iThrdArcFileExist);
 if(arch.crypt)
	if(plgns[arch.plgNum].SetCryptMethod$8)
		if(!arch.SetCryptMethod$8(arch.crypt)) goto End;

 arch.prgrs.postedSz=arch.prgrs.postedSzStep=arch.prgrs.postedSzNextFile=0;

 if(2==iThrdArcFileExist)//Append existing;
	 if(!arch.RebuildCheckExistings$8(arch.GetPlgObj(),password))
		 goto End;

 for(arch.iCrntFileCopy=0; arch.iCrntFileCopy<arch.totFiles; arch.iCrntFileCopy++)
 {
  if(2==iThrdArcFileExist)
	  if(arch.stack[arch.iCrntFileCopy].numInSrc>-1)
		  continue;//Already rebuilded;

  SetDlgItemText(arch.hDlg,IDC_STATIC,arch.stack[arch.iCrntFileCopy].FullPathAndName);

  if(file==arch.stack[arch.iCrntFileCopy].attribute)
  {  if(!arch.Add$24(arch.iCrntFileCopy))
LoopCopy:
	 {	LPVOID* par[3]={(LPVOID*)GetLastError(),(LPVOID*)arch.stack[arch.iCrntFileCopy].FullPathAndName,(LPVOID*)arch.name};
		int r = (int)DialogBoxParam(hInst,MAKEINTRESOURCE(IDD_DIALOG_CHOISE_ACTION),arch.hDlg,fDelOper::actnDlgProc1,(LPARAM)par);
		if(0==r) goto End;//Cancel action;
		if(1==r) goto LoopCopy;
		if(3==r) bSkipAll=TRUE;//2-skip,3-skipAll;
     }
	 //arch.postedSz += arch.stack[arch.iCrntFileCopy].size; prgrsRoutga ko'chiramiz;
  }
  else
  {	
LoopCrea:
	if(!arch.CreateDir$24(arch.iCrntFileCopy))
	{	LPVOID* par[2]={(LPVOID*)GetLastError(),(LPVOID*)arch.name};
		int r = (int)DialogBoxParam(hInst,MAKEINTRESOURCE(IDD_DIALOG_CHOISE_ACTION),arch.hDlg,fDelOper::actnDlgProc,(LPARAM)par);
		if(0==r) goto End;//Cancel action;
		if(1==r) goto LoopCrea;
		if(3==r) bSkipAll=TRUE;//2-skip,3-skipAll;
  } }
Loop:
	MSG msg;//Only thread message:
	if(PeekMessage(&msg,(HWND)-1,MYWM_CANCEL-1,MYWM_CANCEL+10,PM_REMOVE))
	{	
		//static int i=0;
		//char ss[32];sprintf(ss,L"\n %d ",i++);
		//OutputDebugString(ss);
		//OutputDebugString(GetWinNotifyText(msg.message));
		
		switch(msg.message)
		{	case MYWM_CANCEL:
				arch.bCancel = TRUE;
				goto End;
			case MYWM_STOP:
				wchar_t s[MAX_PATH];
				if(arch.bStop)
				{	LoadString(hInst,IDS_STRINGSW_50,s,MAX_PATH);
					SetDlgItemText(arch.hDlg,IDC_BUTTON_STOP,s);
					arch.bStop = FALSE;
				}
				else
				{	LoadString(hInst,IDS_STRINGSW_3,s,MAX_PATH);
					SetDlgItemText(arch.hDlg,IDC_BUTTON_STOP,s);
					arch.bStop = TRUE;
					Sleep(250);
					goto Loop;
				}
				break;
 	}	}
	else if(arch.bStop)
	{	Sleep(250);
		goto Loop;
	}
	PostMessage(GetDlgItem(arch.hDlg,IDC_PROGRESS_COPY_TOTAL),PBM_SETPOS,1000*arch.iCrntFileCopy/arch.totFiles,0);
	wchar_t s[32];StringCchPrintf(s,32,L"%d%s",100*arch.iCrntFileCopy/arch.totFiles,L"%");
	SetDlgItemText(arch.hDlg,IDC_STATIC6,s);
	StringCchPrintf(s,32,L"%d%s%",100-100*arch.iCrntFileCopy/arch.totFiles,L"%");
	SetDlgItemText(arch.hDlg,IDC_STATIC8,s);
}
End:
 if(arch.plgObj)
	arch.Close$4();
 SendMessage(arch.hDlg,WM_USER+4,0,0);//DestroyWindow(arch.hDlg);//CreateDialog b-n yaratilganligi uchun;
 if(arch.stack) free(arch.stack);
 arch.stack=0;
 ExitThread(0);
}

INT_PTR CALLBACK AddArchiveQueueDlgProc(HWND hDlg,UINT message,WPARAM wParam,LPARAM lParam)
{
static HFONT hf=0;static int hfRef=0;//obshiy hf, dinamik uchun emas:
static HBRUSH br=0;
static HBRUSH brHtBk=0;
	UNREFERENCED_PARAMETER(lParam);
	switch(message)
	{
	case WM_INITDIALOG:
		//Adjust to center:
		RECT rc; GetWindowRect(hDlg, &rc);
		int width,left,height,top;

		width = rc.right - rc.left;
		left = width*hfRef % conf::wndWidth;//conf::wndLeft + (conf::wndWidth - width)/2;
		if(left>conf::wndWidth-width)left=0;

		height = rc.bottom - rc.top;
		top = (width*hfRef / conf::wndWidth)*height;//conf::wndTop + (conf::wndHeight - height)/2;
		if(top>conf::wndHeight-top)top=0;
		MoveWindow(hDlg, left, top+20, width, height, TRUE);

		//Load language strings:
		wchar_t s[MAX_PATH];
		LoadString(hInst,IDS_STRINGSW_235,s,MAX_PATH);//45
		SetWindowText(hDlg,s);
		LoadString(hInst,IDS_STRINGSW_47,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_STATIC,s);
		LoadString(hInst,IDS_STRINGSW_48,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_STATIC5,s);
		//LoadString(hInst,IDS_STRINGSW_49,s,MAX_PATH);
		//SetDlgItemText(hDlg,IDC_BUTTON_TO_BACKGROUND_COPY_QUEUE,s);
		ShowWindow(GetDlgItem(hDlg,IDC_BUTTON_TO_BACKGROUND_COPY_QUEUE),SW_HIDE);
		LoadString(hInst,IDS_STRINGSW_50,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_BUTTON_STOP,s);
		LoadString(hInst,IDS_STRINGSW_13,s,MAX_PATH);
		SetDlgItemText(hDlg,IDCANCEL,s);

		PostMessage(GetDlgItem(hDlg,IDC_PROGRESS_COPY_SINGLE),PBM_SETRANGE,0,MAKELPARAM(0,1000));
		PostMessage(GetDlgItem(hDlg,IDC_PROGRESS_COPY_TOTAL ),PBM_SETRANGE,0,MAKELPARAM(0,1000));
		PostMessage(GetDlgItem(hDlg,IDC_PROGRESS_COPY_SINGLE),PBM_SETSTEP,1,0);
		PostMessage(GetDlgItem(hDlg,IDC_PROGRESS_COPY_TOTAL ),PBM_SETSTEP,1,0);

		SendMessage(hDlg,WM_USER+1,0,0);
		if(!lParam) return TRUE;//Agar confDlg dan chaqirilgan b-sa,rang-shriftlarini o'zgartirish uchun;

		DWORD cpyThrdId;srcPanel=((Panel*)lParam)->iThis;
		CreateThread(NULL,1024,(LPTHREAD_START_ROUTINE)buildArchvThrdFnc,hDlg,0,&cpyThrdId);
		SetWindowLong(hDlg,GWLP_USERDATA,cpyThrdId);
		return TRUE;
	case WM_CTLCOLORSTATIC:
	case WM_CTLCOLORDLG:
		if(2==conf::Dlg.iBtnsType)//ownedraw
		{	HDC dc = (HDC)wParam;
			SetTextColor(dc,conf::Dlg.dlgRGBs[1][1]);
			SetBkColor(dc,conf::Dlg.dlgRGBs[1][2]);
			return (INT_PTR)br;
		}return 0;
	case WM_CTLCOLOREDIT:
		if(2==conf::Dlg.iBtnsType)//ownedraw
		{	HDC dc = (HDC)wParam;
			SetTextColor(dc,conf::Dlg.dlgRGBs[1][1]);
			SetBkColor(dc,conf::Dlg.dlgRGBs[1][2]);
			return (INT_PTR)br;
		}return 0;
	case WM_CTLCOLORBTN:
		if(2==conf::Dlg.iBtnsType)//ownedraw
		{	HDC dc=(HDC)wParam;
			SetTextColor(dc,conf::Dlg.dlgRGBs[1][4]);
			SetBkColor(dc,conf::Dlg.dlgRGBs[1][5]);
			return (INT_PTR)brHtBk;
		}return 0;
	case WM_DRAWITEM://WM_CTLCOLORBTN dagi knopkalar:
		if(2==conf::Dlg.iBtnsType)//ownedraw
		{	LPDRAWITEMSTRUCT lpdis;lpdis = (LPDRAWITEMSTRUCT)lParam;
			GetWindowText(lpdis->hwndItem,s,64);
			UINT uStyle;uStyle = DFCS_BUTTONPUSH;
			rc = lpdis->rcItem;
			if(lpdis->itemState & ODS_SELECTED)
			{	uStyle |= DFCS_PUSHED;
				rc.left+=2;rc.top+=2;
			}
			DrawFrameControl(lpdis->hDC, &lpdis->rcItem, DFC_BUTTON, uStyle);
			if(lpdis->itemState & ODS_SELECTED)
				{rc.left+=1;rc.top+=1;rc.bottom-=2;rc.right-=3;}
			else
				{rc.left+=1;rc.top+=2;rc.bottom-=3;rc.right-=3;}
			FillRect(lpdis->hDC,&rc,brHtBk);//DrawText(lpdis->hDC,"                                                  ",50,&rc,DT_SINGLELINE|DT_VCENTER|DT_INTERNAL|DT_LEFT);
			if(lpdis->itemState & ODS_SELECTED)
				{rc.left-=1;rc.top-=1;rc.bottom+=3;rc.right+=3;}
			else
				{rc.left-=1;rc.top-=2;rc.bottom+=2;rc.right+=3;}
			DrawText(lpdis->hDC,s,MyStringLength(s,64),&rc,DT_SINGLELINE|DT_VCENTER|DT_CENTER);
			return TRUE;
		}return 0;
	case WM_USER+1://hf obshiy uchun, dinamik o'zgartirish uchun emas:
		if(0==hfRef)
		{	hf = CreateFontIndirect(&conf::Dlg.dlgFnts[1]);
			br = CreateSolidBrush(conf::Dlg.dlgRGBs[1][0]);
			brHtBk = CreateSolidBrush(conf::Dlg.dlgRGBs[1][5]);
		}
		SendMessage(GetDlgItem(hDlg,IDC_STATIC),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_STATIC5),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_BUTTON_TO_BACKGROUND_COPY_QUEUE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_BUTTON_STOP),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDCANCEL),WM_SETFONT,(WPARAM)hf,TRUE);
		++hfRef;
		return 0;//GWLP_USERDATA
	case WM_USER+4:
		if(0==iAppndToPanelArc)
			EndDialog(hDlg,0);
		else
			DestroyWindow(hDlg);
		return 0;
	case WM_DESTROY:
		if(--hfRef<1)
		{	DeleteObject(hf);
			DeleteObject(br);
			DeleteObject(brHtBk);
		}
		return 0;
	case WM_USER+2://Dinamik o'zgartirish uchun:
		DeleteObject(hf);hfRef=1;
		hf = CreateFontIndirect(&conf::Dlg.dlgFnts[1]);
		SendMessage(GetDlgItem(hDlg,IDC_STATIC),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_STATIC5),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_BUTTON_TO_BACKGROUND_COPY_QUEUE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_BUTTON_STOP),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDCANCEL),WM_SETFONT,(WPARAM)hf,TRUE);
		return 0;//GWLP_USERDATA
	case WM_USER+3://Dinamik o'zgartirish uchun, colorni:
		DeleteObject(br);DeleteObject(brHtBk);hfRef=1;
		br = CreateSolidBrush(conf::Dlg.dlgRGBs[1][0]);
		brHtBk = CreateSolidBrush(conf::Dlg.dlgRGBs[1][5]);
		RedrawWindow(hDlg,NULL,NULL,RDW_INVALIDATE|RDW_ALLCHILDREN);
		return 0;//GWLP_USERDATA
	case WM_COMMAND:
		switch(LOWORD(wParam))
		{	case IDC_BUTTON_STOP:
				PostThreadMessage(GetWindowLong(hDlg,GWLP_USERDATA),MYWM_STOP,0,0);
				return (INT_PTR)TRUE;
			case IDCANCEL:
				PostThreadMessage(GetWindowLong(hDlg,GWLP_USERDATA),MYWM_CANCEL,0,0);
				if(0==iAppndToPanelArc)
					EndDialog(hDlg,0);
				else
					DestroyWindow(hDlg);
				return (INT_PTR)TRUE;
		}
		break;
	}
	return (INT_PTR)FALSE;
}

BOOL ShowDlg(Panel *frPanel)
{
	if(archive::numPlugins<1)
	{	Err::msg(frPanel->GetHWND(),0,L"No any archiver plugin in \"Plugins\\Archive\\\" folder,please,install any one.");
		return TRUE;
	}

	if(frPanel->GetTotSelects()==0)
	if(frPanel->GetHot()<1 || frPanel->GetHot()>frPanel->GetTotItems()-1)
		return TRUE;

	if(rndPathList==panel[frPanel->iOpponent].GetEntry()->GetCrntRecType())
	{	MessageBox(hWnd,L"Do not copy to results list of searching.",L"Warn!!!",MB_OK|MB_ICONWARNING|MB_SYSTEMMODAL);
		return FALSE;
	}
	
	if(1!=DialogBoxParam(hInst,MAKEINTRESOURCE(IDD_DIALOG_ADD_ARCHIVE),hWnd,DlgProc,(LPARAM)frPanel))
		return FALSE;

	panel[frPanel->iOpponent].GetArch()->SetPlgNum(conf::Dlg.crntArchvr);//frPanel
	iAppndToPanelArc=1;//use DestroyWindow
	iApndDestPanel=frPanel->iOpponent;
	HWND dlg = CreateDialogParam(hInst,MAKEINTRESOURCE(IDD_DIALOG_COPY_QUEUE),
								 frPanel->GetHWND(),(DLGPROC)AddArchiveQueueDlgProc,(LPARAM)frPanel);
	if(!dlg)Err::msg(panel[frPanel->iOpponent].GetHWND(),-1,L"CreateDialog failed!!!");
    else ShowWindow(dlg,SW_SHOW);
	return TRUE;
}

INT_PTR CALLBACK SelectUnpckrDlgProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	UNREFERENCED_PARAMETER(lParam);
	switch (message)
	{
	case WM_INITDIALOG:
		//Adjust to center:
		RECT rc; GetWindowRect(hDlg, &rc);
		int width,left,height,top;

		width = rc.right - rc.left;
		left = conf::wndLeft + (conf::wndWidth - width)/2;

		height = rc.bottom - rc.top;
		top = conf::wndTop + (conf::wndHeight - height)/2;
		MoveWindow(hDlg, left, top+20, width, height, TRUE);

		//Load language strings:
		/*LoadString(hInst,IDS_STRINGSW_36,s,MAX_PATH);
		SetWindowText(hDlg,s);
		LoadString(hInst,IDS_STRINGSW_37,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_COPY_STATIC_1,s);*/
		BOOL edIns;edIns=FALSE;
		for(int i=0; i<numPlugins; i++)
		{	if((1==plgns[i].type || 3==plgns[i].type) && plgns[i].descrpn[0])
			{	SendMessage(GetDlgItem(hDlg,IDC_COMBO_ARCHIVER),CB_ADDSTRING,0,
						(LPARAM)plgns[i].extnsn);
				if(!edIns)
				{	SetDlgItemText(hDlg,IDC_EDIT_ARCHIVER_DESCRIPTOR,plgns[i].descrpn);
					edIns=TRUE;
		}	}	}
		SetWindowLong(hDlg,GWLP_USERDATA,(LONG)lParam);
		SetTimer(hDlg,NULL,150,NULL);
		return TRUE;
	case WM_TIMER:
		int k;k=-1;wchar_t *pExt;pExt=(wchar_t*)GetWindowLong(hDlg,GWLP_USERDATA);
		if(pExt)
		{	for(int i=0; i<numPlugins; i++)
			{	if((1==plgns[i].type || 3==plgns[i].type) && plgns[i].descrpn)
				{	++k;
					if(!_wcsicmp(pExt,plgns[i].extnsn))//strcmp
					{	SendMessage(GetDlgItem(hDlg,IDC_COMBO_ARCHIVER),CB_SETCURSEL,k,0);
						k=-1; break;
		}	}	}	}
		else if(-1==k)
			SendMessage(GetDlgItem(hDlg,IDC_COMBO_ARCHIVER),CB_SETCURSEL,0,0);
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_ARCHIVER),CB_SHOWDROPDOWN,TRUE,0);
		KillTimer(hDlg,NULL);
		return TRUE;
	case WM_COMMAND: int r;
		switch(LOWORD(wParam))
		{	case IDC_COMBO_ARCHIVER:
				r = (int)SendMessage(GetDlgItem(hDlg,IDC_COMBO_ARCHIVER),CB_GETCURSEL,0,0);					
				if(CBN_SELENDOK==HIWORD(wParam))
				{	if(CB_ERR!=r)
					{	int ic=0;
						for(int i=0; i<numPlugins; i++)
						{	if((1==plgns[i].type || 3==plgns[i].type) && plgns[i].descrpn)
							{	if(ic++==r)
									EndDialog(hDlg, i);
				}	}	}	}
				else if(CB_ERR!=r)					
				{	int p=0;					
					for(int i=0; i<numPlugins; i++)
					{	if((1==plgns[i].type || 3==plgns[i].type) && plgns[i].descrpn[0])
						{	if(p++==r)
							{	SetDlgItemText(hDlg,IDC_EDIT_ARCHIVER_DESCRIPTOR,plgns[i].descrpn);
								break;
				}	}	}	}
				break;
			case IDOK:
				r = (int)SendMessage(GetDlgItem(hDlg,IDC_COMBO_ARCHIVER),CB_GETCURSEL,0,0);
				if(CB_ERR!=r)
				{	int ic=0;
					for(int i=0; i<numPlugins; i++)
					{	if((1==plgns[i].type || 3==plgns[i].type) && plgns[i].descrpn)
						{	if(ic++==r)
								EndDialog(hDlg, i);
				}	}	}
				return (INT_PTR)TRUE;
			case IDCANCEL:
				EndDialog(hDlg, -1);
				return (INT_PTR)TRUE;
		}
		break;
	}
	return (INT_PTR)FALSE;
}

VOID ShowSearchDlg$12(Panel *p)
{
	if(conf::Dlg.crntSchplg>-1)
	if(numPlugins>0)
	if(conf::Dlg.crntSchplg<numPlugins)
	{	CmnCntrl::ReleaseDragAndDrop();
		LPVOID buf=plgns[p->GetArch()->GetPlgNum()].ShowSearchDlg$12(p->GetArch()->GetPlgObj(),
																	p->GetHWND(),
																	p->GetEntry()->GetCrntRecArchPath());
		if(buf)
		{	p->FreeMem();//search.panel->FreeSelection();
			p->GetPath()[0] = 0;
			p->SetPathLn(0);
			p->GetEntry()->Push(p->GetPath(),rndPathList,0);
			p->FillRandomPathListFrArj(buf);
			p->AdjustScrollity();
			p->SetHot(0);
			p->ClrScr();
			p->Render();
		}
		CmnCntrl::CreateDragAndDrop();
}	}

BOOL ShowUnpckDlg(Panel *frPanel)
{
	if(archive::numPlugins<1)
	{	Err::msg(frPanel->GetHWND(),0,L"No any archiver plugin in \"Plugins\\Archive\\\" folder,please,install any one.");
		return FALSE;
	}

	if(frPanel->GetTotSelects()==0)
	if(frPanel->GetHot()<1 || frPanel->GetHot()>frPanel->GetTotItems()-1)
		return FALSE;

	if(frPanel->GetTotSelects()>1)
	{	Err::msg(frPanel->GetHWND(),0,L"Please,select only one item...");
		return FALSE;
	}
	else if(frPanel->GetTotSelects()<1)
	{	if(frPanel->GetHot()<1 || frPanel->GetHot()>frPanel->GetTotItems()-1)
		{	Err::msg(frPanel->GetHWND(),0,L"Please,select any one item...");
			return FALSE;
	}	}
	
	int r = (int)DialogBoxParam(hInst,MAKEINTRESOURCE(IDD_DIALOG_CHOICE_UNPACKER),hWnd,SelectUnpckrDlgProc,
						   (LPARAM)frPanel->GetItem(frPanel->GetHot())->GetExt());
	if(-1==r)
		return FALSE;//cancel;

	int id;
	if(frPanel->GetTotSelects()<=1 || frPanel->GetTotSelects()>frPanel->GetTotItems()-1)
		id = frPanel->GetHot();
	else//get from selection:
		id=frPanel->GetSelectedItemNum(0);

	return frPanel->FolderInToArch(r,id);
}

}//end of namespace