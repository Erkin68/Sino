#include "Archive.h"
#include "strsafe.h"
#include "..\..\Operations\MyErrors.h"
#include "..\..\Operations\MyShell\MyShell.h"
#include "..\..\config.h"
#include "..\..\Sino.h"
#include <locale.h>



CArchPlgn::CArchPlgn():hm(0),idNum(0),mRef(0)
{
}

CArchPlgn::~CArchPlgn()
{
}

BOOL CArchPlgn::LoadPlugin()
{	if(0==mRef)
	{	if(!hm)
		{	hm = LoadLibrary(pathAndName);
			if(!hm) return FALSE;
			Add$24 = (archive::Add$24_t)GetProcAddress(hm,"Add$24");
			CreateDir$24 = (archive::CreateDir$24_t)GetProcAddress(hm,"CreateDir$24");
			AddEmptyDir$20 = (archive::AddEmptyDir$20_t)GetProcAddress(hm,"AddEmptyDir$20");
			GetArchExtnsn = (archive::GetArchExtnsn_t)GetProcAddress(hm,"GetArchExtnsn");
			GetPluginType = (archive::GetPluginType_t)GetProcAddress(hm,"GetPluginType");
			Open$12 = (archive::Open$12_t)GetProcAddress(hm,"Open$12");
			Close$4 = (archive::Close$4_t)GetProcAddress(hm,"Close$4");
			RebuildCheckExistings$8 = (archive::RebuildCheckExistings$8_t)GetProcAddress(hm,"RebuildCheckExistings$8");
			RenameFile$12 = (archive::RenameFile$12_t)GetProcAddress(hm,"RenameFile$12");
			RenameDir$12 = (archive::RenameDir$12_t)GetProcAddress(hm,"RenameDir$12");
			DeleteFile$8 = (archive::DeleteFile$8_t)GetProcAddress(hm,"DeleteFile$8");
			DeleteDir$8 = (archive::DeleteDir$8_t)GetProcAddress(hm,"DeleteDir$8");
			SetCallbacks$4xxx = (archive::SetCallbacks$4xxx_t)GetProcAddress(hm,"SetCallbacks$4xxx");
			GetTotalCryptMethods = (archive::GetTotalCryptMethods_t)GetProcAddress(hm,"GetTotalCryptMethods");
			GetCryptDescription$4 = (archive::GetCryptDescription$4_t)GetProcAddress(hm,"GetCryptDescription$4");
			SetCryptMethod$8 = (archive::SetCryptMethod$8_t)GetProcAddress(hm,"SetCryptMethod$8");
			GetPluginDescription = (archive::GetPluginDescription_t)GetProcAddress(hm,"GetPluginDescription");
			ShowOptionDialog = (archive::ShowOptionDialog_t)GetProcAddress(hm,"ShowOptionDialog");
			SetId$4 = (archive::SetId$4_t)GetProcAddress(hm,"SetId$4");

			//Unpacking:
			OpenForUnpacking$8 = (archive::OpenForUnpacking$8_t)GetProcAddress(hm,"OpenForUnpacking$8");
			EnumDirectory$8 = (archive::EnumDirectory$8_t)GetProcAddress(hm,"EnumDirectory$8");
			Unpack$28 = (archive::Unpack$28_t)GetProcAddress(hm,"Unpack$28");
			ShowSearchDlg$12 = (archive::ShowSearchDlg$12_t)GetProcAddress(hm,"ShowSearchDlg$12");
			SetCallbacks$4xxx(	checkFileInSelctn,
								excldFileFrSelctn,
								getFileInfoFromSelection,
								prgrssRout,
								showDlgOverwriteExistFile,
								saveOptions,
								readOptions,
								addItemToPanelList
								);
			SetId$4(idNum);
	}	}
	++mRef;
	return TRUE;
}

VOID CArchPlgn::FreePlugin()
{	if(0==mRef)
	{	if(hm) FreeLibrary(hm);
		hm = 0;
		Add$24 = 0;
		CreateDir$24 = 0;
		GetArchExtnsn = 0;
		GetPluginType = 0;
		Open$12 = 0;
		Close$4 = 0;
		RebuildCheckExistings$8 = 0;
		RenameFile$12 = 0;
		RenameDir$12 = 0;
		DeleteFile$8 = 0;
		DeleteDir$8 = 0;
		SetCallbacks$4xxx = 0;
		GetTotalCryptMethods = 0;
		GetCryptDescription$4 = 0;
		SetCryptMethod$8 = 0;
		GetPluginDescription = 0;
		ShowOptionDialog = 0;
		SetId$4 = 0;

		//Unpacking:
		OpenForUnpacking$8 = 0;
		EnumDirectory$8 = 0;
		Unpack$28 = 0;
		ShowSearchDlg$12 = 0;
	}
	if(mRef>0)--mRef;
}

//************GLOBAL CALLBACK from plugins:*********
//************GLOBAL CALLBACK from plugins:*********
//************GLOBAL CALLBACK from plugins:*********
//************GLOBAL CALLBACK from plugins:*********
//************GLOBAL CALLBACK from plugins:*********
//************GLOBAL CALLBACK from plugins:*********
//************GLOBAL CALLBACK from plugins:*********
//************GLOBAL CALLBACK from plugins:*********
//************GLOBAL CALLBACK from plugins:*********
int CALLBACK CArchPlgn::checkFileInSelctn(CArch* arc,wchar_t *name)
{
	for(int i=0; i<arc->totFiles; i++)
	{	//pathsiz tekshiramiz:
		if(0==wcscmp(name,arc->stack[i].RelatedPathAndName))//FullPathAndName))
			return i;
	}
	return -1;
}

VOID CALLBACK CArchPlgn::excldFileFrSelctn(CArch *arc,int exclNum,int numInArch)
{
	if(exclNum>-1)
		arc->stack[exclNum].numInSrc = numInArch;
}

BOOL CALLBACK CArchPlgn::getFileInfoFromSelection(CArch *arc,int fileNumInSelection,
												  WIN32_FIND_DATA *ff)
{
HANDLE hF=FindFirstFile(arc->stack[fileNumInSelection].FullPathAndName,ff);
	if(hF==INVALID_HANDLE_VALUE)
		return FALSE;	
	FindClose(hF);
	return TRUE;
}	

DWORD CALLBACK CArchPlgn::prgrssRout(CArch *arc,
									 unsigned __int64 *CrntFileProgressed,//yo bu ikkitasi
									 unsigned __int64 *CrntFileTotal,     //bo'lishi kerak;
									 unsigned __int64 *TotalProgressed,   //yo bu ikkitasi bo'lishi kerak;
									 unsigned __int64 *Total)			  //xuddi 7z day;	
{
	if(!arc) return 0;
	if(!arc->hDlg) return 0;
	if((!CrntFileTotal) && (!Total)) return PROGRESS_CONTINUE;

	if(CrntFileProgressed)
		arc->prgrs.postedSz = arc->prgrs.postedSzStep + (*CrntFileProgressed);
	else
		arc->prgrs.postedSz = *TotalProgressed;

	double prgrsPos;
	if(CrntFileProgressed && CrntFileTotal)
	{	prgrsPos = (*CrntFileTotal)?(1000.0*(*CrntFileProgressed)/(*CrntFileTotal)):1000.0;
		PostMessage(GetDlgItem(arc->hDlg,IDC_PROGRESS_COPY_SINGLE),PBM_SETPOS,(int)prgrsPos,0);
	}
	//else
	//{	if(arc->stack[arc->prgrs.postedSzNextFile].size)
	//		prgrsPos = 1000.0f*((*TotalProgressed) - arc->prgrs.postedSzStep) / arc->stack[arc->prgrs.postedSzNextFile].size;
	//	else prgrsPos = 1000.0f;
	//	PostMessage(GetDlgItem(arc->hDlg,IDC_PROGRESS_COPY_SINGLE),PBM_SETPOS,(int)prgrsPos,0);
	//}

	double prgrsPosTot;
	if(TotalProgressed && Total)
	{	prgrsPosTot = (*Total)?(1000.0*(*TotalProgressed)/(*Total)):1000.0;
		PostMessage(GetDlgItem(arc->hDlg,IDC_PROGRESS_COPY_TOTAL),PBM_SETPOS,(int)prgrsPosTot,0);
	}
	//else
	//{	prgrsPosTot = arc->srcSz?(1000.0*arc->prgrs.postedSz/arc->srcSz):1000.0;
	//	PostMessage(GetDlgItem(arc->hDlg,IDC_PROGRESS_COPY_TOTAL),PBM_SETPOS,(int)prgrsPosTot,0);
	//}

	if(CrntFileProgressed && CrntFileTotal)
	{	if((*CrntFileProgressed) >= (*CrntFileTotal))
		{	arc->prgrs.postedSzStep += (*CrntFileTotal);		
			++arc->prgrs.postedSzNextFile;
	}	}
	if(TotalProgressed && Total)
	{	if((*TotalProgressed) >= arc->prgrs.postedSzStep + arc->stack[arc->prgrs.postedSzNextFile].size)
		{	arc->prgrs.postedSzStep += arc->stack[arc->prgrs.postedSzNextFile].size;
			++arc->prgrs.postedSzNextFile;
	}	}
	// ***************** % calculating: ***********************
	wchar_t s[MAX_PATH];
	if(CrntFileProgressed && CrntFileTotal)
	{	StringCchPrintf(s,MAX_PATH-1,L"%.2f %s",0.1f*prgrsPos,L"%");
		SetDlgItemText(arc->hDlg,IDC_STATIC1,s);
		StringCchPrintf(s,MAX_PATH-1,L"%.2f %s",100.0-0.1*prgrsPos,L"%");
		SetDlgItemText(arc->hDlg,IDC_STATIC3,s);
	}
	if(TotalProgressed && Total)
	{	StringCchPrintf(s,MAX_PATH-1,L"%.2f %s",0.1*prgrsPosTot,L"%");
		SetDlgItemText(arc->hDlg,IDC_STATIC6,s);
		StringCchPrintf(s,MAX_PATH-1,L"%.2f %s",100.0-0.1*prgrsPosTot,L"%");
		SetDlgItemText(arc->hDlg,IDC_STATIC8,s);
	}
	// ***************** tick calculating: ********************
	DWORD tick = GetTickCount() - arc->beginTick - arc->stopTick[0];
	MyTimeToString(s, tick);
	SetDlgItemText(arc->hDlg,IDC_STATIC2,s);
	if(CrntFileProgressed && CrntFileTotal)
	{	if(prgrsPos>0.0f)
		{	MyTimeToString(s, (int)(tick*(1000.0f-prgrsPos)/prgrsPos));
			SetDlgItemText(arc->hDlg,IDC_STATIC4,s);
	}	}
	
	tick = GetTickCount() - arc->beginTickTot - arc->stopTickTot[0];
	MyTimeToString(s, tick);
	SetDlgItemText(arc->hDlg,IDC_STATIC7,s);
	if(TotalProgressed && Total)
	{	if(prgrsPosTot>0.0f)
		{	MyTimeToString(s, (int)(tick*(1.0f-0.001f*prgrsPosTot)/(0.001f*prgrsPosTot)));
			SetDlgItemText(arc->hDlg,IDC_STATIC9,s);
	}	}
	
	if(arc->bCancel)
		return PROGRESS_CANCEL;

	//Agar 1tagina fayl b-sa:
	MSG msg;//Only thread message:

Loop:
	//message from thread queue:
	if(PeekMessage(&msg,(HWND)-1,MYWM_CANCEL-1,MYWM_CANCEL+10,PM_REMOVE))
	{	
		//static int i=0;
		//char ss[32];sprintf(ss,L"\n %d ",i++);
		//OutputDebugString(ss);
		//OutputDebugString(GetWinNotifyText(msg.message));

		switch(msg.message)
		{	case MYWM_CANCEL:
				return PROGRESS_CANCEL;
			case MYWM_STOP:
				if(arc->bStop)
				{	LoadString(hInst,IDS_STRINGSW_50,s,MAX_PATH);
					SetDlgItemText(arc->hDlg,IDC_BUTTON_STOP,s);
					arc->stopTick[0] = GetTickCount() - arc->stopTick[1];
					arc->stopTickTot[0] = GetTickCount() - arc->stopTickTot[1];
					arc->bStop = FALSE;
				}
				else
				{	LoadString(hInst,IDS_STRINGSW_3,s,MAX_PATH);
					SetDlgItemText(arc->hDlg,IDC_BUTTON_STOP,s);
					arc->bStop = TRUE;
					arc->stopTick[1] = arc->stopTickTot[1] = GetTickCount();
					Sleep(250);
					goto Loop;
				}
				break;
 	}	}
	else if(arc->bStop)
	{	Sleep(250);
		goto Loop;
	}
	return PROGRESS_CONTINUE;
}

INT_PTR CALLBACK AppndFileExistDlgProc(HWND,UINT,WPARAM,LPARAM);
int CALLBACK CArchPlgn::showDlgOverwriteExistFile(CArch *arc,
											int numInSelctn,
											wchar_t *nameInArch, 
											unsigned __int64 *fileSzInArch,
											FILETIME *ftInArch,
											WIN32_FIND_DATAW *ff)
{
	LPVOID *par[6]={(LPVOID*)arc,
					(LPVOID*)numInSelctn,
					(LPVOID*)nameInArch,
					(LPVOID*)fileSzInArch,
					(LPVOID*)ftInArch,
					(LPVOID*)ff};
	int r = (int)DialogBoxParam(	hInst,MAKEINTRESOURCE(IDD_COPY_FILE_EXIST),
							arc->hDlg,AppndFileExistDlgProc,
							(LPARAM)&par[0]);
	return r;
}

BOOL CALLBACK CArchPlgn::readOptions(int plgId,VOID *buf,int bufLen)
{
	if(plgId<0) return FALSE;//|| plgId>fSearchViaF7::numPlugins-1) return FALSE; ni qo'ymaymiz, hali numPlugins 1ta oshmagan bo'lishi mumkin;
DWORD rb;
wchar_t s[MAX_PATH];MyStringCpy(s,MAX_PATH-1,archive::plgns[plgId].pathAndName);//arc->name);
	wchar_t *p = wcsrchr(s,'.');
	if(p) *(p+1) = 0;
	MyStringCat(s,MAX_PATH-1,L"bin");
	HANDLE f = MyFopenViaCrF(s,L"r");//MyStringAddModulePath
	if(!f) return FALSE;
	if(!ReadFile(f,buf,bufLen,&rb,NULL))
		rb=0;
	CloseHandle(f);
	return (rb!=bufLen)?FALSE:TRUE;
}

BOOL CALLBACK CArchPlgn::saveOptions(int plgId,VOID *buf,int bufLen)
{
	if(plgId<0 || plgId>archive::numPlugins-1) return FALSE;
DWORD rb;
wchar_t s[MAX_PATH];MyStringCpy(s,MAX_PATH-1,archive::plgns[plgId].pathAndName);//arc->name);
	wchar_t *p = wcsrchr(s,'.');
	if(p) *(p+1) = 0;
	MyStringCat(s,MAX_PATH-1,L"bin");
	HANDLE f = MyFopenViaCrF(s,L"w");//MyStringAddModulePath
	if(!f) return FALSE;
	if(!WriteFile(f,buf,bufLen,&rb,NULL))
		rb=0;
	CloseHandle(f);

	if(0==plgId)//Oxirgi dll
	{	if(archive::plgns)
			free(archive::plgns);
		archive::plgns=NULL;
		archive::numPlugins=0;
	}
	return (rb!=bufLen)?FALSE:TRUE;
}

inline int CALLBACK CArchPlgn::addItemToPanelList(CArch *arc,wchar_t* name, WIN32_FIND_DATAW* ffdata)
{
	return (int)panel[arc->srcPanel].AddItem(name,
						(FILE_ATTRIBUTE_DIRECTORY==ffdata->dwFileAttributes)?folder:file,0,ffdata);
}

//************END of CALLBACKS from pugins.**********
//************END of CALLBACKS from pugins.**********
//************END of CALLBACKS from pugins.**********
//************END of CALLBACKS from pugins.**********
//************END of CALLBACKS from pugins.**********
//************END of CALLBACKS from pugins.**********
//************END of CALLBACKS from pugins.**********
//************END of CALLBACKS from pugins.**********
//************END of CALLBACKS from pugins.**********
//************END of CALLBACKS from pugins.**********
//************END of CALLBACKS from pugins.**********
//************END of CALLBACKS from pugins.**********
//************END of CALLBACKS from pugins.**********
INT_PTR CALLBACK AppndFileExistDlgProc(HWND hDlg,UINT message,WPARAM wParam,LPARAM lParam)
{
	switch(message)
	{
	case WM_INITDIALOG:
		//Adjust to center:
		RECT rc; GetWindowRect(hDlg, &rc);
		RECT rcPrnt; HWND prnt;prnt = GetParent(hDlg);if(!prnt)prnt=GetDesktopWindow();
		GetWindowRect(prnt, &rcPrnt);
		int width,left,height,top;

		width = rc.right - rc.left;
		left = rcPrnt.left + (rcPrnt.right-rcPrnt.left - width)/2;
		if(left<0)left=0;
		else if(left+width>conf::wndLeft+conf::wndWidth)
			left=conf::wndLeft+conf::wndWidth-width;

		height = rc.bottom - rc.top;
		top = rcPrnt.top + (rcPrnt.bottom-rcPrnt.top - height)/2;
		if(top<0)top=0;
		else if(top+height>conf::wndTop+conf::wndHeight)
			top=conf::wndTop+conf::wndHeight-height;

		MoveWindow(hDlg, left, top+20, width, height, TRUE);

		wchar_t s[MAX_PATH],s1[MAX_PATH];
		LoadString(hInst,IDS_STRINGSW_52,s,MAX_PATH);
		SetWindowText(hDlg,s);
		LoadString(hInst,IDS_STRINGSW_53,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_STATIC1,s);
		LoadString(hInst,IDS_STRINGSW_54,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_STATIC2,s);
		LoadString(hInst,IDS_STRINGSW_53,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_STATIC3,s);
		LoadString(hInst,IDS_STRINGSW_54,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_STATIC4,s);
		LoadString(hInst,IDS_STRINGSW_55,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_STATIC10,s);
		LoadString(hInst,IDS_STRINGSW_56,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_STATIC6,s);
		LoadString(hInst,IDS_STRINGSW_57,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_STATIC7,s);
		LoadString(hInst,IDS_STRINGSW_58,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_STATIC8,s);
		LoadString(hInst,IDS_STRINGSW_59,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_STATIC9,s);
		LoadString(hInst,IDS_STRINGSW_60,s,MAX_PATH);
		SetDlgItemText(hDlg,IDOK,s);
		MyStringCat(s,MAX_PATH-1,L" ");
		LoadString(hInst,IDS_STRINGSW_61,s1,MAX_PATH);
		MyStringCat(s,MAX_PATH-1,s1);
		SetDlgItemText(hDlg,IDOK_ALL,s);
		LoadString(hInst,IDS_STRINGSW_216,s,MAX_PATH);
		SetDlgItemText(hDlg,IDSKIP,s);
		LoadString(hInst,IDS_STRINGSW_61,s1,MAX_PATH);
		MyStringCat(s,MAX_PATH-1,s1);
		SetDlgItemText(hDlg,IDSKIP_ALL,s);
		LoadString(hInst,IDS_STRINGSW_13,s,MAX_PATH);
		SetDlgItemText(hDlg,IDCANCEL,s);

		LoadString(hInst,IDS_STRINGSW_60,s,MAX_PATH);
		MyStringCat(s,MAX_PATH-1,L" ");
		LoadString(hInst,IDS_STRINGSW_209,s1,MAX_PATH);
		MyStringCat(s,MAX_PATH-1,s1);
		SetDlgItemText(hDlg,IDOVERWRITE_OLDEST,s);
		MyStringCat(s,MAX_PATH-1,L" ");
		LoadString(hInst,IDS_STRINGSW_61,s1,MAX_PATH);
		MyStringCat(s,MAX_PATH-1,s1);
		SetDlgItemText(hDlg,IDOVERWRITE_OLDEST_ALL,s);

		LoadString(hInst,IDS_STRINGSW_60,s,MAX_PATH);
		MyStringCat(s,MAX_PATH-1,L" ");
		LoadString(hInst,IDS_STRINGSW_210,s1,MAX_PATH);
		MyStringCat(s,MAX_PATH-1,s1);
		SetDlgItemText(hDlg,IDOVERWRITE_LATEST,s);
		MyStringCat(s,MAX_PATH-1,L" ");
		LoadString(hInst,IDS_STRINGSW_61,s1,MAX_PATH);
		MyStringCat(s,MAX_PATH-1,s1);
		SetDlgItemText(hDlg,IDOVERWRITE_LATEST_ALL,s);

		LoadString(hInst,IDS_STRINGSW_60,s,MAX_PATH);
		MyStringCat(s,MAX_PATH-1,L" ");
		LoadString(hInst,IDS_STRINGSW_211,s1,MAX_PATH);
		MyStringCat(s,MAX_PATH-1,s1);
		SetDlgItemText(hDlg,IDOVERWRITE_BIGS,s);
		MyStringCat(s,MAX_PATH-1,L" ");
		LoadString(hInst,IDS_STRINGSW_61,s1,MAX_PATH);
		MyStringCat(s,MAX_PATH-1,s1);
		SetDlgItemText(hDlg,IDOVERWRITE_BIGS_ALL,s);

		LoadString(hInst,IDS_STRINGSW_60,s,MAX_PATH);
		MyStringCat(s,MAX_PATH-1,L" ");
		LoadString(hInst,IDS_STRINGSW_212,s1,MAX_PATH);
		MyStringCat(s,MAX_PATH-1,s1);
		SetDlgItemText(hDlg,IDOVERWRITE_LITTLES,s);
		MyStringCat(s,MAX_PATH-1,L" ");
		LoadString(hInst,IDS_STRINGSW_61,s1,MAX_PATH);
		MyStringCat(s,MAX_PATH-1,s1);
		SetDlgItemText(hDlg,IDOVERWRITE_LITTLES_ALL,s);

		LPVOID *par;par = (LPVOID*)(lParam);
		//LPVOID *par[6]={(LPVOID*)CArch*,
		//          (LPVOID*)numInSelctn,
		//			(LPVOID*)nameInArch,
		//			(LPVOID*)fileSzInArch,
		//			(LPVOID*)ftInArch,
		//			(LPVOID*)ff};
		ArcStack *stFile;stFile = &((CArch*)par[0])->stack[(int)par[1]];
		WIN32_FIND_DATA *ff;ff = (WIN32_FIND_DATA*)par[5];

		SetDlgItemText(hDlg,IDC_EDIT_SRC_PATH,stFile->FullPathAndName);
		MyStringCpy(s,MAX_PATH-1,((CArch*)par[0])->name);
		MyStringCat(s,MAX_PATH-1,L"\\");
		MyStringCat(s,MAX_PATH-1,(wchar_t*)par[2]);
		SetDlgItemText(hDlg,IDC_EDIT_DEST_PATH,s);
		unsigned __int64 sz;sz = (unsigned __int64)ff->nFileSizeHigh<<32 | (unsigned __int64)ff->nFileSizeLow;
		StringCchPrintf(s,MAX_PATH-1,L"%d",sz);
		SetDlgItemText(hDlg,IDC_EDIT_SRC_SIZE,s);
		StringCchPrintf(s,MAX_PATH-1,L"%d",*((unsigned __int64*)par[3]));
		SetDlgItemText(hDlg,IDC_EDIT_DEST_SIZE,s);

		FILETIME ft;SYSTEMTIME st;
		//HANDLE hF;WIN32_FIND_DATA ff;hF=FindFirstFile(stFile->FullPathAndName,&ff);
		//if(hF!=INVALID_HANDLE_VALUE)
		{	if(FileTimeToLocalFileTime(&ff->ftCreationTime,&ft) != 0)
			{	if(FileTimeToSystemTime(&ft, &st) != 0)
				{	StringCchPrintf(s,MAX_PATH-1,L"%d.%d.%d  %d:%d:%d",
									st.wDay,st.wMonth,st.wYear,
									st.wHour,st.wMinute,st.wSecond);
					SetDlgItemText(hDlg,IDC_EDIT_SRC_CREATE_TIME,s);
			}	}
			if(FileTimeToLocalFileTime(&ff->ftLastWriteTime,&ft) != 0)
			{	if(FileTimeToSystemTime(&ft, &st) != 0)
				{	StringCchPrintf(s,MAX_PATH-1,L"%d.%d.%d  %d:%d:%d",
									st.wDay,st.wMonth,st.wYear,
									st.wHour,st.wMinute,st.wSecond);
					SetDlgItemText(hDlg,IDC_EDIT_SRC_LAST_WRITE_TIME,s);
			}	}
			if(FileTimeToLocalFileTime(&ff->ftLastAccessTime,&ft) != 0)
			{	if(FileTimeToSystemTime(&ft, &st) != 0)
				{	StringCchPrintf(s,MAX_PATH-1,L"%d.%d.%d  %d:%d:%d",
									st.wDay,st.wMonth,st.wYear,
									st.wHour,st.wMinute,st.wSecond);
					SetDlgItemText(hDlg,IDC_EDIT_SRC_LAST_ACCESS_TIME,s);
			}	}
			if(FILE_ATTRIBUTE_ARCHIVE==ff->dwFileAttributes)
				SetDlgItemText(hDlg,IDC_EDIT_SRC_ATTRIBUTE,L"Archive");
			else if(FILE_ATTRIBUTE_COMPRESSED==ff->dwFileAttributes)
				SetDlgItemText(hDlg,IDC_EDIT_SRC_ATTRIBUTE,L"Compressed");
			else if(FILE_ATTRIBUTE_DEVICE==ff->dwFileAttributes)
				SetDlgItemText(hDlg,FILE_ATTRIBUTE_DEVICE,L"Device");
			else if(FILE_ATTRIBUTE_DIRECTORY==ff->dwFileAttributes)
				SetDlgItemText(hDlg,IDC_EDIT_SRC_ATTRIBUTE,L"Directory");
			else if(FILE_ATTRIBUTE_ENCRYPTED==ff->dwFileAttributes)
				SetDlgItemText(hDlg,IDC_EDIT_SRC_ATTRIBUTE,L"Encrypted");
			else if(FILE_ATTRIBUTE_HIDDEN==ff->dwFileAttributes)
				SetDlgItemText(hDlg,IDC_EDIT_SRC_ATTRIBUTE,L"Hidden");
			else if(FILE_ATTRIBUTE_NORMAL==ff->dwFileAttributes)
				SetDlgItemText(hDlg,IDC_EDIT_SRC_ATTRIBUTE,L"Normal");
			else if(FILE_ATTRIBUTE_NOT_CONTENT_INDEXED==ff->dwFileAttributes)
				SetDlgItemText(hDlg,IDC_EDIT_SRC_ATTRIBUTE,L"Not content indexed");
			else if(FILE_ATTRIBUTE_OFFLINE==ff->dwFileAttributes)
				SetDlgItemText(hDlg,IDC_EDIT_SRC_ATTRIBUTE,L"Offline");		
			else if(FILE_ATTRIBUTE_READONLY==ff->dwFileAttributes)
				SetDlgItemText(hDlg,IDC_EDIT_SRC_ATTRIBUTE,L"Readonly");
			else if(FILE_ATTRIBUTE_REPARSE_POINT==ff->dwFileAttributes)
				SetDlgItemText(hDlg,IDC_EDIT_SRC_ATTRIBUTE,L"Reparsepoint");
			else if(FILE_ATTRIBUTE_SPARSE_FILE==ff->dwFileAttributes)
				SetDlgItemText(hDlg,IDC_EDIT_SRC_ATTRIBUTE,L"Sparsefile");
			else if(FILE_ATTRIBUTE_SYSTEM==ff->dwFileAttributes)
				SetDlgItemText(hDlg,IDC_EDIT_SRC_ATTRIBUTE,L"System");
			else if(FILE_ATTRIBUTE_TEMPORARY==ff->dwFileAttributes)
				SetDlgItemText(hDlg,IDC_EDIT_SRC_ATTRIBUTE,L"Temporary");
			else if(FILE_ATTRIBUTE_VIRTUAL==ff->dwFileAttributes)
				SetDlgItemText(hDlg,IDC_EDIT_SRC_ATTRIBUTE,L"Virtual");
			//FindClose(hF);
		}
		FILETIME *ftInArc;ftInArc=(FILETIME*)par[4];
		if(FileTimeToLocalFileTime(ftInArc,&ft) != 0)
		{	if(FileTimeToSystemTime(&ft, &st) != 0)
			{	StringCchPrintf(s,MAX_PATH-1,L"%d.%d.%d  %d:%d:%d",
								st.wDay,st.wMonth,st.wYear,
								st.wHour,st.wMinute,st.wSecond);
				SetDlgItemText(hDlg,IDC_EDIT_DEST_CREATE_TIME,s);
		}	}
		return TRUE;
	//case WM_DESTROY:
	//	return TRUE;
	case WM_COMMAND:
		switch(LOWORD(wParam))
		{	case IDOK:
				EndDialog(hDlg,overwrite);
				return (INT_PTR)TRUE;
			case IDOK_ALL:
				EndDialog(hDlg,overwriteAll);
				return (INT_PTR)TRUE;
			case IDCANCEL:
				EndDialog(hDlg,cancel);
				return (INT_PTR)TRUE;
			case IDSKIP:
				EndDialog(hDlg,skip);
				return (INT_PTR)TRUE;
			case IDSKIP_ALL:
				EndDialog(hDlg,skipAll);
				return (INT_PTR)TRUE;
			case IDRENAME:
				EndDialog(hDlg,rename1);
				return (INT_PTR)TRUE;
			case IDRENAME_ALL:
				EndDialog(hDlg,renameAll);
				return (INT_PTR)TRUE;
			case IDOVERWRITE_OLDEST_ALL:
				EndDialog(hDlg,overwriteOldestAll);
				return (INT_PTR)TRUE;
			case IDOVERWRITE_OLDEST:
				EndDialog(hDlg,overwriteOldest);
				return (INT_PTR)TRUE;
			case IDOVERWRITE_LATEST_ALL:
				EndDialog(hDlg,overwriteLatestAll);
				return (INT_PTR)TRUE;
			case IDOVERWRITE_LATEST:
				EndDialog(hDlg,overwriteLatest);
				return (INT_PTR)TRUE;
			case IDOVERWRITE_BIGS_ALL:
				EndDialog(hDlg,overwriteBigestAll);
				return (INT_PTR)TRUE;
			case IDOVERWRITE_BIGS:
				EndDialog(hDlg,overwriteBigest);
				return (INT_PTR)TRUE;
			case IDOVERWRITE_LITTLES_ALL:
				EndDialog(hDlg,overwriteLittlestAll);
				return (INT_PTR)TRUE;
			case IDOVERWRITE_LITTLES:
				EndDialog(hDlg,overwriteLittlest);
				return (INT_PTR)TRUE;
		}
		break;
	}
	return (INT_PTR)FALSE;
}

CArch::CArch():plgObj(0),hDlg(0)
{
}

CArch::~CArch()
{
BEGIN_TRY
	if(plgObj && archive::plgns)
	{	if(archive::plgns[plgNum].Close$4)
			archive::plgns[plgNum].Close$4(plgObj);	
	}
	plgObj=NULL;

	//check, are there any open archive plugin there are:
	BOOL bArchiveAnyOpens=FALSE;
	for(int i=0; i<archive::numPlugins; i++)
	{	//if(1==archive::plgns[i].type || 3==archive::plgns[i].type))
		{	if(archive::plgns[i].hm)
			{	bArchiveAnyOpens=TRUE;
				break;
	}	}	}
/*	if(!bArchiveAnyOpens) see PlgnSaveOptn;
	{	if(archive::plgns)
			free(archive::plgns);
		archive::plgns=NULL;
		archive::numPlugins=0;
	}*/
END_TRY
{
}}

BOOL CArch::Add$24(int numInStack)
{
BEGIN_TRY
	crntFileSzPtr = &stack[numInStack].size;
	return archive::plgns[plgNum].Add$24(
					plgObj,
					stack[numInStack].FullPathAndName,
					stack[numInStack].RelatedPathAndName,
					password,
					cmqlev,
					bExcldPath);
END_TRY
{	return FALSE;
}}

BOOL CArch::Close$4()
{
BEGIN_TRY
	if(plgObj)
	{	if(!archive::plgns[plgNum].Close$4(plgObj))
		{	Err::msg(hDlg,-1,L"Err.in close archive.");
			return TRUE;
		}	
		archive::plgns[plgNum].FreePlugin();
		plgObj=0;
	}
	return TRUE;
END_TRY
{	return FALSE;
}}

BOOL CArch::CreateDir$24(int numInStack)
{
BEGIN_TRY
	return archive::plgns[plgNum].CreateDir$24(
						plgObj,
						stack[numInStack].FullPathAndName,
						stack[numInStack].RelatedPathAndName,
						password,
						cmqlev,
						bExcldPath);
END_TRY
{	return FALSE;
}}

BOOL CArch::Delete$8(wchar_t *fName,BOOL bFolder)//,int iCall,int numCalls)
{	if(plgNum<0)return FALSE;
	if(plgNum>archive::numPlugins-1)return FALSE;
BEGIN_TRY
	if(bFolder)
		{if(!archive::plgns[plgNum].DeleteDir$8) return FALSE;}
	else
		{if(!archive::plgns[plgNum].DeleteFile$8) return FALSE;}

//char oldName[MAX_PATH];MyStringCpy(oldName,MAX_PATH-1,name);
	//if(0==iCall)
	/*{	if(archive::plgns[plgNum].hm)
			archive::plgns[plgNum].Close$4(plgObj);
		plgObj=0;
		Open$12(name,plgNum,2);//opn exstng
	}*/
	BOOL r;
	if(bFolder)
		r=archive::plgns[plgNum].DeleteDir$8(plgObj, fName);
	else
		r=archive::plgns[plgNum].DeleteFile$8(plgObj, fName);

	//if(numCalls==iCall)
	/*{	Close$4();
		OpenForUnpacking$8(name,plgNum);
	}*/
	return r;
END_TRY
{	return FALSE;
}}

BOOL CArch::DeleteSelections(Panel *p)//faqat RMCpy da ishlataman;
{
BEGIN_TRY
	if(archive::plgns[p->GetArch()->GetPlgNum()].hm)
	archive::plgns[p->GetArch()->GetPlgNum()].Close$4(p->GetArch()->GetPlgObj());
	p->GetArch()->SetPlgObj(0);

	p->GetArch()->Open$12(p->GetArch()->name,p->GetArch()->GetPlgNum(),2);//opn exstng


	cpyTrdDat dat;//dat.hDlg = (HWND)lpar; prgrsDlg = &dat.hDlg;
  	dat.stack = 0;
  	dat.bStop = FALSE;
	dat.bCancel = FALSE;
	dat.bSwtchToBckgrnd = FALSE;
	dat.thrId = GetCurrentThreadId();
	dat.beginTick = dat.beginTickTot = GetTickCount();
	dat.stopTick[0] = dat.stopTickTot[0] = 0;
	enCheckCopyFilesToExisting = showEach;

	int totFiles = archive::GetRMCpySelectedFilesCnt();///faqat RMCpy da ishlataman,shu uchun;
	if(!totFiles)return TRUE;
	dat.stack = (CpyStack*)malloc(totFiles*sizeof(CpyStack));
	archive::GetRMCpySelectedFiles(dat.stack);
	for(dat.iCrntFileCopy=0; dat.iCrntFileCopy<totFiles; dat.iCrntFileCopy++)
	{	/*if(bFolder)
			r=archive::plgns[p->arch.plgNum].DeleteDir$8(p->arch.plgObj, fName);
		else
			r=archive::plgns[p->arch.plgNum].DeleteFile$8(p->arch.plgObj, fName);*/
	}
	if(dat.stack) free(dat.stack);




	p->GetArch()->Close$4();
	p->GetArch()->OpenForUnpacking$8(name,plgNum);
	p->FreeMem();
	p->FillArchItems(p->GetEntry()->GetCrntRecArchPath());
	p->ChangeSheetTabPath();
	p->AdjustScrollity();
	p->ScrollItemToView(p->GetHot());
	p->ClrScr();
	p->Render(NULL);
	return TRUE;
END_TRY
{	return FALSE;
}}

//stackdagi .Name ni cutSelectedFiles bajaradur;
int CArch::GetFilesInFolder(wchar_t *path, ArcStack *stack)//reentrance:
{
WIN32_FIND_DATA ff;
HANDLE hf = INVALID_HANDLE_VALUE;

int tot = 0;

	hf = MyFindFirstFileEx(path,FindExInfoStandard,&ff,FindExSearchLimitToDirectories,NULL,0);
	do
	{	if(INVALID_HANDLE_VALUE==hf) return tot;
		if(FILE_ATTRIBUTE_DIRECTORY & ff.dwFileAttributes)//if(IsDirectory(path, &ff, FALSE))
		{	if(IsCrntOrPrntDirAttrb(ff.cFileName))
			{	stack[tot].FullPathAndNameLn=MyStringCpy(stack[tot].FullPathAndName,MAX_PATH-1,path);
				if('*'==stack[tot].FullPathAndName[stack[tot].FullPathAndNameLn-1])
				if('\\'==stack[tot].FullPathAndName[stack[tot].FullPathAndNameLn-2])
					stack[tot].FullPathAndName[--stack[tot].FullPathAndNameLn]=0;
				stack[tot].FullPathAndNameLn += MyStringCpy(
						&stack[tot].FullPathAndName[stack[tot].FullPathAndNameLn],
						MAX_PATH-1,
						ff.cFileName);
				stack[tot].attribute = folder;
				int saveTot=tot;
				++tot;//folderniyam;
				stack[saveTot].FullPathAndName[stack[saveTot].FullPathAndNameLn]='\\';
				stack[saveTot].FullPathAndName[stack[saveTot].FullPathAndNameLn+1]='*';
				stack[saveTot].FullPathAndName[stack[saveTot].FullPathAndNameLn+2]=0;
				tot += GetFilesInFolder(stack[saveTot].FullPathAndName,&stack[tot]);
				stack[saveTot].FullPathAndName[stack[saveTot].FullPathAndNameLn+1]=0;
		}	}
		else
		{	stack[tot].FullPathAndNameLn=MyStringCpy(stack[tot].FullPathAndName,MAX_PATH-1,path);
			if('*'==stack[tot].FullPathAndName[stack[tot].FullPathAndNameLn-1])
			if('\\'==stack[tot].FullPathAndName[stack[tot].FullPathAndNameLn-2])
				stack[tot].FullPathAndName[--stack[tot].FullPathAndNameLn]=0;
			stack[tot].FullPathAndNameLn += MyStringCpy(
					&stack[tot].FullPathAndName[stack[tot].FullPathAndNameLn],
					MAX_PATH-1,
					ff.cFileName);
			stack[tot].size = ((unsigned __int64)ff.nFileSizeHigh<<32) | ff.nFileSizeLow;
			srcSz+=stack[tot].size;
			stack[tot].attribute = file;
			++tot;
	}	}
	while(FindNextFile(hf, &ff));
	FindClose(hf);
	return tot;
}

int GetFilesCntInFolder(wchar_t *path)//reentrance:
{
WIN32_FIND_DATA ff;
HANDLE hf = INVALID_HANDLE_VALUE;

int tot = 0;

	hf = MyFindFirstFileEx(path,FindExInfoStandard,&ff,FindExSearchLimitToDirectories,NULL,0);
	do
	{	if(INVALID_HANDLE_VALUE==hf) return tot;
		if(FILE_ATTRIBUTE_DIRECTORY & ff.dwFileAttributes)//if(IsDirectory(path, &ff, FALSE))
		{	if(IsCrntOrPrntDirAttrb(ff.cFileName))
			{	wchar_t s[MAX_PATH];
				int l=MyStringCpy(s,MAX_PATH-1,path);
				if('*'==s[l-1])//MyStringRemoveLastCharCheckPre(s,MAX_PATH-1,'*','\\');
				if('\\'==s[l-2])
					s[--l]=0;
				l+=MyStringCpy(&s[l],MAX_PATH-l,ff.cFileName);//MyStringCat(s,MAX_PATH-1,ff.cFileName);
				++tot;//folderniyam;
				s[l++]='\\';//MyStringCat(s,MAX_PATH-1,L"\\*");
				s[l++]='*';
				s[l]=0;
				tot += GetFilesCntInFolder(s);
		}	}
		else
		{	++tot;
	}	}
	while(FindNextFile(hf, &ff));
	FindClose(hf);
	return tot;
}

int CArch::GetSelectedFilesCnt(int srcpanel)
{
	srcPanel = srcpanel;
	totFiles=panel[srcPanel].GetTotSelects();
	if(!totFiles)
	{	int ht=panel[srcPanel].GetHot();
		if(ht>0 && ht<panel[srcPanel].GetTotItems())
		{	if(file == panel[srcPanel].GetItem(ht)->attribute)
				return 1;
			else if(folder == panel[srcPanel].GetItem(ht)->attribute)
			{	wchar_t pth[MAX_PATH]; 
				int l=panel[srcPanel].GetFullPathAndName(ht,pth,MAX_PATH-1);
				++totFiles;//folderniyam;
				//if(mSHFileOperation!=copyMethod)
				{	pth[l++]='\\';//MyStringCat(pth,MAX_PATH-1,L"\\*");
					pth[l++]='*';
					pth[l]=0;
					totFiles += GetFilesCntInFolder(pth);
			}	}
			return totFiles;
		}
		else return 0;
	}
	totFiles = 0;
	for(int i=0; i<panel[srcPanel].GetTotItems(); i++)
	{	if(selected==panel[srcPanel].GetItem(i)->state || (0==panel[srcPanel].GetTotSelects() && i==panel[srcPanel].GetHot()))
		{	if(file == panel[srcPanel].GetItem(i)->attribute)
				++totFiles;
			else if(folder == panel[srcPanel].GetItem(i)->attribute)
			{	wchar_t pth[MAX_PATH]; 
				panel[srcPanel].GetFullPathAndName(i,pth,MAX_PATH-1);
				++totFiles;//folderniyam;
				//if(mSHFileOperation!=copyMethod)
				{	MyStringCat(pth,MAX_PATH-1,L"\\*");
					totFiles += GetFilesCntInFolder(pth);
	}	}	}	}
	return totFiles;
}

int CArch::GetSelectedFiles()
{
int tot=panel[srcPanel].GetTotSelects();
	srcSz=0;
	if(!tot)
	{	int ht = panel[srcPanel].GetHot();
		if(ht>0 && ht<panel[srcPanel].GetTotItems())
		{	if(file == panel[srcPanel].GetItem(ht)->attribute)
			{	stack[tot].FullPathAndNameLn=MyStringCpy(stack[tot].FullPathAndName,MAX_PATH-1,panel[srcPanel].GetPath());
				if('*'==stack[tot].FullPathAndName[stack[tot].FullPathAndNameLn-1])//MyStringRemoveLastCharCheckPre(stack[tot].FullPathAndName,MAX_PATH-1,'*','\\'))
				if('\\'==stack[tot].FullPathAndName[stack[tot].FullPathAndNameLn-2])
				stack[tot].FullPathAndName[--stack[tot].FullPathAndNameLn]=0;//--stack[tot].FullPathAndNameLn;
				stack[tot].FullPathAndNameLn+=MyStringCat(stack[tot].FullPathAndName,MAX_PATH-1,panel[srcPanel].GetItem(ht)->Name);
				stack[tot].size = panel[srcPanel].GetItem(ht)->size;
				stack[tot].attribute = file;
				stack[tot].numInSrc = -1;
				srcSz+=stack[tot].size;
				return 1;
			}
			else if(folder == panel[srcPanel].GetItem(ht)->attribute)
			{	stack[tot].FullPathAndNameLn=panel[srcPanel].GetFullPathAndName(ht,stack[tot].FullPathAndName,MAX_PATH);
				stack[tot].FullPathAndName[stack[tot].FullPathAndNameLn]='\\';
				stack[tot].FullPathAndName[++stack[tot].FullPathAndNameLn]=0;
				stack[tot].attribute = folder;
				stack[tot].numInSrc = -1;
				stack[tot].size = 0;
				int saveTot=tot;
				++tot;//folderniyam;
				//if(mSHFileOperation!=copyMethod)
				{	stack[saveTot].FullPathAndName[stack[saveTot].FullPathAndNameLn]='*';
					stack[saveTot].FullPathAndName[stack[saveTot].FullPathAndNameLn+1]=0;
					tot += GetFilesInFolder(stack[saveTot].FullPathAndName,&stack[tot]);
					stack[saveTot].FullPathAndName[stack[saveTot].FullPathAndNameLn]=0;
	 		}	}
			return tot;
		}		
		else return 0;
	}
 tot=0;
 for(int i=0; i<panel[srcPanel].GetTotItems(); i++)
 {	if(selected==panel[srcPanel].GetItem(i)->state || (0==panel[srcPanel].GetTotSelects() && i==panel[srcPanel].GetHot()))
	{	if(file == panel[srcPanel].GetItem(i)->attribute)
		{	stack[tot].FullPathAndNameLn=MyStringCpy(stack[tot].FullPathAndName,MAX_PATH-1,panel[srcPanel].GetPath());
			if('*'==stack[tot].FullPathAndName[stack[tot].FullPathAndNameLn-1])//MyStringRemoveLastCharCheckPre(stack[tot].FullPathAndName,MAX_PATH-1,'*','\\'))
			if('\\'==stack[tot].FullPathAndName[stack[tot].FullPathAndNameLn-2])
				stack[tot].FullPathAndName[--stack[tot].FullPathAndNameLn]=0;//--stack[tot].FullPathAndNameLn;
			stack[tot].FullPathAndNameLn+=MyStringCat(stack[tot].FullPathAndName,MAX_PATH-1,panel[srcPanel].GetItem(i)->Name);
			stack[tot].size = panel[srcPanel].GetItem(i)->size;
			stack[tot].attribute = file;
			stack[tot].numInSrc = -1;
			srcSz+=stack[tot].size;
			++tot;
		}
		else if(folder == panel[srcPanel].GetItem(i)->attribute)
		{	stack[tot].FullPathAndNameLn=panel[srcPanel].GetFullPathAndName(i,stack[tot].FullPathAndName,MAX_PATH);
			stack[tot].FullPathAndName[stack[tot].FullPathAndNameLn]='\\';
			stack[tot].FullPathAndName[++stack[tot].FullPathAndNameLn]=0;
			stack[tot].attribute = folder;
			stack[tot].numInSrc = -1;
			stack[tot].size = 0;
			int saveTot=tot;
			++tot;//folderniyam;

			//if(mSHFileOperation!=copyMethod)
			{	stack[saveTot].FullPathAndName[stack[saveTot].FullPathAndNameLn]='*';
				stack[saveTot].FullPathAndName[stack[saveTot].FullPathAndNameLn+1]=0;
				tot += GetFilesInFolder(stack[saveTot].FullPathAndName,&stack[tot]);
				stack[saveTot].FullPathAndName[stack[saveTot].FullPathAndNameLn]=0;
 }	}	}	}
 return tot;
}

BOOL CArch::Open$12(wchar_t *nm,int plNum,int iArcFileExist)//0-not exist,1-ovewrite,2-append,3-cancel
{
BEGIN_TRY
	plgNum = plNum;
	nameLn=MyStringCpy(name,MAX_PATH-1,nm);
	if(archive::plgns[plgNum].LoadPlugin())
		plgObj = archive::plgns[plgNum].Open$12(nm,iArcFileExist!=2,this);
	else return FALSE;
	//AreFileApisANSI(void);
	return plgObj==NULL?FALSE:TRUE;
END_TRY
{	name[0]=0;nameLn=0;plgNum=-1;
	return FALSE;
}}

BOOL CArch::OpenForUnpacking$8(wchar_t *nm,int plNum)//0-not exist,1-ovewrite,2-append,3-cancel
{
BEGIN_TRY
	plgNum = plNum;
	nameLn = MyStringCpy(name,MAX_PATH-1,nm);
	if(archive::plgns[plgNum].LoadPlugin())
		plgObj = archive::plgns[plgNum].OpenForUnpacking$8(name,this);
	else return FALSE;
	if(!plgObj) return FALSE;
	//AreFileApisANSI(void);
	return TRUE;
END_TRY
{	name[0]=0;nameLn=0;plgNum=-1;	
	return FALSE;
}}

//Raspakovkadan chaqirilgan, lekin upakovkaga o'tish kerak.Mana muammo...
BOOL CArch::Rename$12(wchar_t *fName, wchar_t *fNewName,BOOL bFolder)
{	
	if(plgNum<0)return FALSE;
	if(plgNum>archive::numPlugins-1)return FALSE;
	if(bFolder)
		{if(!archive::plgns[plgNum].RenameDir$12) return FALSE;}
	else
		{if(!archive::plgns[plgNum].RenameFile$12) return FALSE;}

//char oldName[MAX_PATH];MyStringCpy(oldName,MAX_PATH-1,name);
	if(archive::plgns[plgNum].hm)
		archive::plgns[plgNum].Close$4(plgObj);
	plgObj=0;
BEGIN_TRY
	Open$12(name,plgNum,2);//opn exstng
	BOOL r;
	if(bFolder)
		r=archive::plgns[plgNum].RenameDir$12(plgObj, fName, fNewName);
	else
		r=archive::plgns[plgNum].RenameFile$12(plgObj, fName, fNewName);
	Close$4();
	OpenForUnpacking$8(name,plgNum);
	return r;
END_TRY
{	return FALSE;
}}

BOOL CArch::SetCryptMethod$8(int numCryptMethod)
{
BEGIN_TRY
	if(archive::plgns[plgNum].SetCryptMethod$8)
	{	archive::plgns[plgNum].SetCryptMethod$8(plgObj,numCryptMethod);
		return TRUE;
	}
	return FALSE;
END_TRY
{	return FALSE;
}}
