#ifndef _SCHSTRUCTS_H__
#define _SCHSTRUCTS_H__

#include "windows.h"
#include "Plugins_CPP.h"





typedef struct TSearchItem
{	
public:
		 TSearchItem();//const STATUS_Vtbl FAR *lpVtbl;
	struct
	{ 	__int32 bEnumSubDir : 1;
		__int32 bFindForText : 1;
		__int32 bFindForText_Unicode : 1;
		__int32 bFindForText_ASCII : 1;
		__int32 bFindForText_UpperCase : 1;
		__int32 bFindForExcldText : 1;
		__int32 bFindForExcldText_Unicode : 1;
		__int32 bFindForExcldText_ASCII : 1;
		__int32 bFindForExcldText_UpperCase : 1;
		__int32 bFindForAlterName : 1;
		__int32 bCrTimeBef : 1;
		__int32 bCrTimeAft : 1;
		__int32 bCrTimeBet : 1;
		__int32 bLstAccTimeBef : 1;
		__int32 bLstAccTimeAft : 1;
		__int32 bLastAccTimeBet : 1;
		__int32 bLstWrTimeBef : 1;
		__int32 bLstWrTimeAft : 1;
		__int32 bLstWrTimeBet : 1;
		__int32 bFileSz : 1;
		__int32 bFileAttr : 1;
		__int32 bFileAttArchive : 1;
		__int32 bFileAttCompr : 1;
		__int32 bFileAttDevice : 1;
		__int32 bFileAttDir : 1;
		__int32 bFileAttEncr : 1;
		__int32 bFileAttHidden : 1;
		__int32 bFileAttNormal : 1;
		__int32 bFileAttNotInd : 1;
		__int32 bFileAttOffl : 1;
		__int32 bFileAttReadOnly : 1;
		__int32 bFileAttRepPt : 1;
	};
	struct
	{	__int32 bFileAttSparseFile : 1;
		__int32 bFileAttSys : 1;
		__int32 bFileAttTemp : 1;
		__int32 bFileAttVirt : 1;
	};

	wchar_t filtr[2*MAX_PATH];//spare for unicode
	wchar_t rootPath[2*MAX_PATH];//spare for unicode
	wchar_t FindForText[2*MAX_PATH];
	int		FindForTextLn;
	wchar_t FindForExcldText[2*MAX_PATH];
	int		FindForExcldTextLn;
	wchar_t altName[MAX_PATH];
	wchar_t altNameW[MAX_PATH];
	FILETIME CrTimeBef;
	//char crTimeBefD[2*MAX_PATH];
	//char crTimeBefT[2*MAX_PATH];
	FILETIME CrTimeAft;
	//char crTimeAftD[2*MAX_PATH];
	//char crTimeAftT[2*MAX_PATH];
	FILETIME CrTimeBet[2];
	//char crTimeBetBD[2*MAX_PATH];
	//char crTimeBetBT[2*MAX_PATH];
	//char crTimeBetAD[2*MAX_PATH];
	//char crTimeBetAT[2*MAX_PATH];
	FILETIME LstAccTimeBef;
	//char LstAccTimeBefD[2*MAX_PATH];
	//char LstAccTimeBefT[2*MAX_PATH];
	FILETIME LstAccTimeAft;
	//char LstAccTimeAftD[2*MAX_PATH];
	//char LstAccTimeAftT[2*MAX_PATH];
	FILETIME LastAccTimeBet[2];
	//char LastAccTimeBetBD[2*MAX_PATH];
	//char LastAccTimeBetBT[2*MAX_PATH];
	//char LastAccTimeBetAD[2*MAX_PATH];
	//char LastAccTimeBetAT[2*MAX_PATH];
	FILETIME LstWrTimeBef;
	//char LstWrTimeBefD[2*MAX_PATH];
	//char LstWrTimeBefT[2*MAX_PATH];
	FILETIME LstWrTimeAft;
	//char LstWrTimeAftD[2*MAX_PATH];
	//char LstWrTimeAftT[2*MAX_PATH];
	FILETIME LstWrTimeBet[2];
	//char LstWrTimeBetBefD[2*MAX_PATH];
	//char LstWrTimeBetBefT[2*MAX_PATH];
	//char LstWrTimeAftBefD[2*MAX_PATH];
	//char LstWrTimeAftBefT[2*MAX_PATH];
	wchar_t sFileSzEqu[4];
	wchar_t sFileSz[MAX_PATH];
	int     iFileSzQual;
} SearchItem;

typedef struct TSearch
{
public:
			TSearch();
		   ~TSearch();
	HWND	hDlg;
	//LPVOID  panel;
	HANDLE	hThr;
	DWORD	thrId;
	BOOL	bStop,bRun;
	int		iCall;
	int		iFoundFiles;
	int		iFoundFolders;
	FILETIME crBef,crAft,crBtwn[2],lastBef,lastAft,lastBtwn[2],
			lastWrBef,lastWrAft,lastWrBtwn[2];
	DWORD   ticks[2];
	wchar_t *LBListBuf;
	VOID    SaveLBListBuf(HWND);
	VOID	LoadLBList(HWND);

	//doplnitelno dlya arxiva:
	PluginObj *plgnObj;
} Search;

typedef struct _MY_WIN32_FIND_DATA
{ DWORD    dwFileAttributes; 
  FILETIME ftCreationTime; 
  FILETIME ftLastAccessTime; 
  FILETIME ftLastWriteTime; 
  DWORD    nFileSizeHigh; 
  DWORD    nFileSizeLow; 
  DWORD    dwReserved0; 
  DWORD    dwReserved1; 
} MY_WIN32_FIND_DATA;

#endif