#include "windows.h"
#include "shlobj.h"
#include "strsafe.h"
#include "Psapi.h"
#include "Archive.h"
#include "..\..\Sino.h"
#include "..\..\config.h"
#include "..\..\Operations\MyErrors.h"
#include "..\..\operations\Temporary.h"
#include "..\..\Operations\Execution.h"
#include "..\..\operations\DeleteOperation.h"
#include "..\..\operations\MyShell\ComboToDisk.h"
#include "..\..\operations\MyShell\MyShell.h"
#include "..\..\operations\Backgrnd thread copy operation.h"



extern int GetFilesCntInFolder(wchar_t*);

namespace archive
{

extern HWND* prgrsDlg;
extern int   crypt,iAppndToPanelArc,iApndDestPanel,srcPanel;
extern wchar_t password[MAX_PATH], destArcName[MAX_PATH];
extern float cmqLevel;
extern BOOL  bExcldPath,bDelAftArchiving,bSFXArchive;
extern BOOL  CutSelectedNames(ArcStack*,wchar_t*,int);//,BOOL);
extern BOOL  AddPanArcPathToDestNames(ArcStack*,wchar_t*,int);
extern INT_PTR CALLBACK AddArchiveQueueDlgProc(HWND,UINT,WPARAM,LPARAM);

INT_PTR CALLBACK ToArjDlgProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
static HFONT hf=0;static int hfRef=0;//obshiy hf, dinamik uchun emas:
static HBRUSH br=0;
static HBRUSH brHtBk=0;
wchar_t s[MAX_PATH];
	UNREFERENCED_PARAMETER(lParam);
	
	switch (message)
	{
	case WM_INITDIALOG:
		//Adjust to center:
		RECT rc; GetWindowRect(hDlg, &rc);
		int width,left,height,top;

		width = rc.right - rc.left;
		left = conf::wndLeft + (conf::wndWidth - width)/2;

		height = rc.bottom - rc.top;
		top = conf::wndTop + (conf::wndHeight - height)/2;
		MoveWindow(hDlg, left, top+20, width, height, TRUE);

		//Load language strings:
		LoadString(hInst,IDS_STRINGSW_36,s,MAX_PATH-1);
		SetWindowText(hDlg,s);
		LoadString(hInst,IDS_STRINGSW_37,s,MAX_PATH-1);
		SetDlgItemText(hDlg,IDC_COPY_STATIC_1,s);
		LoadString(hInst,IDS_STRINGSW_38,s,MAX_PATH-1);
		SetDlgItemText(hDlg,IDC_COPY_STATIC_2,s);
		LoadString(hInst,IDS_STRINGSW_39,s,MAX_PATH-1);
		SetDlgItemText(hDlg,IDC_CHECK_EXCEPTION_OR_SELECTION,s);
		LoadString(hInst,IDS_STRINGSW_40,s,MAX_PATH-1);
		SetDlgItemText(hDlg,IDC_CHECK_EXCEPTION_OR_SELECTION1,s);
		LoadString(hInst,IDS_STRINGSW_41,s,MAX_PATH-1);
		SetDlgItemText(hDlg,IDOK,s);
		LoadString(hInst,IDS_STRINGSW_42,s,MAX_PATH-1);
		SetDlgItemText(hDlg,IDC_BUTTON_ADD_TO_QUEUE,s);
		LoadString(hInst,IDS_STRINGSW_13,s,MAX_PATH-1);
		SetDlgItemText(hDlg,IDCANCEL,s);
		LoadString(hInst,IDS_STRINGSW_43,s,MAX_PATH-1);
		SetDlgItemText(hDlg,IDC_CHECK_CHANGE_DEFAULT,s);
		LoadString(hInst,IDS_STRINGSW_44,s,MAX_PATH-1);
		SetDlgItemText(hDlg,IDC_COPY_STATIC_3,s);
		LoadString(hInst,IDS_STRINGSW_45,s,MAX_PATH-1);
		SetDlgItemText(hDlg,IDC_BUTTON_BROWSE,s);

		ShowWindow(GetDlgItem(hDlg,IDC_COPY_STATIC_4),SW_HIDE);
		ShowWindow(GetDlgItem(hDlg,IDC_COMBO_ARCHIVER),SW_HIDE);
		ShowWindow(GetDlgItem(hDlg,IDC_COMBO_ARCHIVER),SW_HIDE);
		ShowWindow(GetDlgItem(hDlg,IDC_CHECK_INCLUDE_SFX_ARCHIVE),SW_HIDE);
		ShowWindow(GetDlgItem(hDlg,IDC_CHECK_DELETE_AFTER_ARCHIVE),SW_HIDE);
		ShowWindow(GetDlgItem(hDlg,IDC_BUTTON_BROWSE),SW_HIDE);
		ShowWindow(GetDlgItem(hDlg,IDC_COMBO_PANEL),SW_HIDE);
		ShowWindow(GetDlgItem(hDlg,IDC_COPY_STATIC_3),SW_HIDE);
		//EnableWindow(GetDlgItem(hDlg,IDC_EDIT_DEST_ARCHIVE),FALSE);

		SendMessage(GetDlgItem(hDlg,IDC_COMBO_CRYPT),CB_ADDSTRING,0,(LPARAM)L"no crypt");
		if(((Panel*)lParam)->GetOpponent()->GetArch()->GetPlgObj())
		{	for(int i=0; i<plgns[((Panel*)lParam)->GetOpponent()->GetArch()->GetPlgNum()].GetTotalCryptMethods(); i++)
				SendMessage(GetDlgItem(hDlg,IDC_COMBO_CRYPT),CB_ADDSTRING,0,
					(LPARAM)plgns[((Panel*)lParam)->GetOpponent()->GetArch()->GetPlgNum()].GetCryptDescription$4(i));
			SendMessage(GetDlgItem(hDlg,IDC_COMBO_CRYPT),CB_SETCURSEL,0,0);
		}

		SendMessage(GetDlgItem(hDlg,IDC_COMBO_CRYPT),CB_SETCURSEL,0,0);

		SendMessage(GetDlgItem(hDlg,IDC_CHECK_PASSWORD_ARCHIVE),BM_SETCHECK,BST_UNCHECKED,0);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_INCLUDE_PATH_ARCHIVE),BM_SETCHECK,BST_CHECKED,0);
		SendMessage(GetDlgItem(hDlg,IDC_SLIDER_FASTER),TBM_SETPOS,TRUE,conf::cmqLevPerCent);//75 edi

		EnableWindow(GetDlgItem(hDlg,IDC_EDIT_PASSWORD_ARCHIVE),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_EDIT_PASSWORD_ARCHIVE2),FALSE);

		if(lParam)
		{	if(!fCopyOper::FillCopyFilesInfo(hDlg, lParam, ((Panel*)lParam)->iOpponent))
				EndDialog(hDlg,TRUE);
			SendMessage(GetDlgItem(hDlg,IDC_EDIT_DEST_ARCHIVE),CB_SETCURSEL,0,0);
		}

		SendMessage(hDlg,WM_USER+1,0,0);
		HWND h;h=SetFocus(GetDlgItem(hDlg,IDOK));//Ownedrawda defaultbutton bo'lmaydur;
		SetWindowLong(hDlg,GWLP_USERDATA,(LONG)lParam);
		return TRUE;
	case WM_CTLCOLORSTATIC:
	case WM_CTLCOLORDLG:HDC dc;dc = (HDC)wParam;
		SetTextColor(dc,conf::Dlg.dlgRGBs[0][1]);
		SetBkColor(dc,conf::Dlg.dlgRGBs[0][2]);
		return (INT_PTR)br;
	case WM_CTLCOLOREDIT:dc = (HDC)wParam;
		SetTextColor(dc,conf::Dlg.dlgRGBs[0][1]);
		SetBkColor(dc,conf::Dlg.dlgRGBs[0][2]);
		return (INT_PTR)br;
	case WM_CTLCOLORBTN:dc=(HDC)wParam;
		SetTextColor(dc,conf::Dlg.dlgRGBs[0][4]);
		SetBkColor(dc,conf::Dlg.dlgRGBs[0][5]);
		return (INT_PTR)brHtBk;
	case WM_DRAWITEM://WM_CTLCOLORBTN dagi knopkalar:
		LPDRAWITEMSTRUCT lpdis;lpdis = (LPDRAWITEMSTRUCT)lParam;
		GetWindowText(lpdis->hwndItem,s,MAX_PATH);
		UINT uStyle;uStyle = DFCS_BUTTONPUSH;
		rc = lpdis->rcItem;
		if(lpdis->itemState & ODS_SELECTED)
		{	uStyle |= DFCS_PUSHED|DFCS_TRANSPARENT;
			rc.left+=2;rc.top+=2;
		}
		DrawFrameControl(lpdis->hDC, &lpdis->rcItem, DFC_BUTTON, uStyle);
		if(lpdis->itemState & ODS_SELECTED)
			{rc.left+=1;rc.top+=1;rc.bottom-=2;rc.right-=3;}
		else
			{rc.left+=1;rc.top+=2;rc.bottom-=3;rc.right-=3;}
		FillRect(lpdis->hDC,&rc,brHtBk);//DrawText(lpdis->hDC,"",50,&rc,DT_SINGLELINE|DT_VCENTER|DT_INTERNAL|DT_LEFT);
		if(lpdis->itemState & ODS_SELECTED)
			{rc.left-=1;rc.top-=1;rc.bottom+=3;rc.right+=3;}
		else
			{rc.left-=1;rc.top-=2;rc.bottom+=2;rc.right+=3;}
		DrawText(lpdis->hDC,s,MyStringLength(s,MAX_PATH),&rc,DT_SINGLELINE|DT_VCENTER|DT_CENTER);
		return TRUE;
	case WM_USER+1://hf obshiy uchun, dinamik o'zgartirish uchun emas:
		if(0==hfRef)
		{	hf = CreateFontIndirect(&conf::Dlg.dlgFnts[0]);
			br = CreateSolidBrush(conf::Dlg.dlgRGBs[0][0]);
			brHtBk = CreateSolidBrush(conf::Dlg.dlgRGBs[0][5]);
		}
		SendMessage(GetDlgItem(hDlg,IDC_BUTTON_BROWSE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDOK),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDCANCEL),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_COPY_STATIC_1),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_COPY_STATIC_2),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_COPY_STATIC_3),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_COPY_STATIC_4),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_COPY_STATIC_5),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_FILES_TO_COPY),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_DEST_ARCHIVE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_ARCHIVER),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_PASSWORD_ARCHIVE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_INCLUDE_PATH_ARCHIVE),WM_SETFONT,(WPARAM)hf,TRUE);
		++hfRef;
		return 0;//GWLP_USERDATA
	case WM_DESTROY:
		if(--hfRef<1)
		{	DeleteObject(hf);
			DeleteObject(br);
			DeleteObject(brHtBk);
		}
		return 0;
	case WM_COMMAND:
		switch(LOWORD(wParam))
		{	/*case IDC_COMBO_ARCHIVER:
				if(CBN_SELCHANGE==HIWORD(wParam))
				{	int iplg=SendMessage(GetDlgItem(hDlg,IDC_COMBO_ARCHIVER),CB_GETCURSEL,0,0);
					if(CB_ERR==iplg)break;
					if(iplg>numPlugins-1)break;
					SendMessage(GetDlgItem(hDlg,IDC_COMBO_CRYPT),CB_RESETCONTENT,0,0);
					SendMessage(GetDlgItem(hDlg,IDC_COMBO_CRYPT),CB_ADDSTRING,0,(LPARAM)L"no crypt");
					if(plgns[iplg].LoadPlugin())
					{	for(int i=0; i<plgns[iplg].GetTotalCryptMethods(); i++)
							SendMessage(GetDlgItem(hDlg,IDC_COMBO_CRYPT),CB_ADDSTRING,0,
									(LPARAM)plgns[iplg].GetCryptDescription$4(i));					
						plgns[iplg].FreePlugin();
				}	}
				break;*/
			case IDC_COMBO_CRYPT:
				if(CBN_SELCHANGE==HIWORD(wParam))
				{	int icrpt=(int)SendMessage(GetDlgItem(hDlg,IDC_COMBO_CRYPT),CB_GETCURSEL,0,0);
					if(icrpt>0)
					{	if(BST_CHECKED!=SendMessage(GetDlgItem(hDlg,IDC_CHECK_PASSWORD_ARCHIVE),BM_GETCHECK,0,0))
						{	SendMessage(GetDlgItem(hDlg,IDC_COMBO_CRYPT),CB_SETCURSEL,0,0);
	SetPassword:			Err::msg(hDlg,0,L"Please, before set password for crypting.");
							break;						
						}
						if(!GetDlgItemText(hDlg,IDC_EDIT_PASSWORD_ARCHIVE,s,MAX_PATH))
							goto SetPassword;
						if(!GetDlgItemText(hDlg,IDC_EDIT_PASSWORD_ARCHIVE2,s,MAX_PATH))
							goto SetPassword;
					}
					if(CB_ERR==icrpt)break;
					crypt = icrpt;
				}
				break;
			case IDC_CHECK_PASSWORD_ARCHIVE:
				if(BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_PASSWORD_ARCHIVE),BM_GETCHECK,0,0))
				{	EnableWindow(GetDlgItem(hDlg,IDC_EDIT_PASSWORD_ARCHIVE),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_PASSWORD_ARCHIVE2),TRUE);
					SendMessage(GetDlgItem(hDlg,IDC_COMBO_CRYPT),CB_SETCURSEL,0,1);					
				}
				else
				{	EnableWindow(GetDlgItem(hDlg,IDC_EDIT_PASSWORD_ARCHIVE),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_PASSWORD_ARCHIVE2),FALSE);
				}
				break;
			/*case IDC_CHECK_DELETE_AFTER_ARCHIVE:
				bDelAftArchiving = (BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_DELETE_AFTER_ARCHIVE),BM_GETCHECK,0,0));
				break;
			case IDC_CHECK_INCLUDE_SFX_ARCHIVE:char *p;
				bSFXArchive = (BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_INCLUDE_SFX_ARCHIVE),BM_GETCHECK,0,0));
				GetDlgItemText(hDlg,IDC_EDIT_DEST_ARCHIVE,s,MAX_PATH);
				p=strrchr(s,'.');
				if(p)
				{	if(bSFXArchive)
						{*(++p)='e'; *(++p)='x'; *(++p)='e'; *(++p)=0;}
					else
						MyStringCpy(p+1,MAX_PATH-1,(char*)plgns[iplgn].extnsn);
				}
				SetDlgItemText(hDlg,IDC_EDIT_DEST_ARCHIVE,s);
				break;*/
			case IDC_BUTTON_ARCHIVER_OPTION:
				plgns[panel[HIWORD(GetWindowLong(hDlg,GWLP_USERDATA))].GetArch()->GetPlgNum()].ShowOptionDialog(hDlg);
				break;
			/*case IDC_COMBO_PANEL:char pth[MAX_PATH];
				if(CBN_SELCHANGE==HIWORD(wParam))
				{	int iPanSel=SendMessage(GetDlgItem(hDlg,IDC_COMBO_PANEL),CB_GETCURSEL,0,0);
					SendMessage(GetDlgItem(hDlg,IDC_COMBO_PANEL),CB_GETLBTEXT,iPanSel,(LPARAM)s);
					panel[atoi(s)-1].GetPath(pth);
					MyStringRemoveLastCharCheckPre(pth,MAX_PATH-1,'*','\\');
					GetDlgItemText(hDlg,IDC_EDIT_DEST_ARCHIVE,s,MAX_PATH);
					char *p = strrchr(s,'\\');
					if(p)
					{	MyStringCat(pth,MAX_PATH-1,p+1);
						SetDlgItemText(hDlg,IDC_EDIT_DEST_ARCHIVE,pth);
				}	}
				break;*/
			/*case IDC_BUTTON_BROWSE:
				BROWSEINFO bi; 
				bi.hwndOwner = hDlg;
				bi.pszDisplayName = s;
				bi.lpszTitle = "Create archive to folder ...";
				bi.ulFlags = BIF_NONEWFOLDERBUTTON|BIF_DONTGOBELOWDOMAIN|BIF_NEWDIALOGSTYLE|
					BIF_NOTRANSLATETARGETS|BIF_RETURNFSANCESTORS;
				bi.lpfn = NULL;
				LPITEMIDLIST pidlRoot;pidlRoot = NULL;
				bi.pidlRoot = pidlRoot;
				LPITEMIDLIST pidlSelected;pidlSelected = SHBrowseForFolder(&bi);
				if(pidlRoot)
					CoTaskMemFree(pidlRoot);
				if(pidlSelected)
				{	SHGetPathFromIDList(pidlSelected,s);
					int ln = MyStringLength(s,MAX_PATH-1);
					GetDlgItemText(hDlg,IDC_EDIT_DEST_ARCHIVE,pth,MAX_PATH);
					char *p = strrchr(pth,'\\');
					if(p)
					{	if(ln>0)
						{	MyStringCat(s,MAX_PATH-1,s[ln-1]=='\\'?p+1:p);
							SetDlgItemText(hDlg,IDC_EDIT_DEST_ARCHIVE,s);
						}
						else// MyStringCat(s,MAX_PATH-1,p+1);
							SetDlgItemText(hDlg,IDC_EDIT_DEST_ARCHIVE,p+1);
					}
					else
					{	MyStringCat(s,MAX_PATH-1,pth);
						SetDlgItemText(hDlg,IDC_EDIT_DEST_ARCHIVE,s);
					}
					CoTaskMemFree(pidlSelected);
				}
	   			return (INT_PTR)TRUE;*/
			case IDOK:
				if(BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_PASSWORD_ARCHIVE),BM_GETCHECK,0,0))
				{	GetDlgItemText(hDlg,IDC_EDIT_PASSWORD_ARCHIVE,password,MAX_PATH);
					GetDlgItemText(hDlg,IDC_EDIT_PASSWORD_ARCHIVE2,s,MAX_PATH);
					if(wcscmp(s,password))
					{	Err::msg(hDlg,0,L"Password and verify password are unindentical,please,enter the same word.");
						return TRUE;
				}	}
				else
					password[0]=0;
				//i=SendMessage(GetDlgItem(hDlg,IDC_EDIT_DEST_ARCHIVE),CB_GETLBTEXT,i,(LPARAM)destArcName);
				/*COMBOBOXINFO ci;ci.cbSize=sizeof(ci);
				if(!GetComboBoxInfo(GetDlgItem(hDlg,IDC_EDIT_DEST_ARCHIVE),&ci))
					return TRUE;
				GetWindowText(ci.hwndItem,destArcName,MAX_PATH);*/

				conf::cmqLevPerCent=(char)SendMessage(GetDlgItem(hDlg,IDC_SLIDER_FASTER),TBM_GETPOS,0,0);
				int cmqMax;cmqMax=(int)SendMessage(GetDlgItem(hDlg,IDC_SLIDER_FASTER),TBM_GETRANGEMAX,0,0);
				int cmqMin;cmqMin=(int)SendMessage(GetDlgItem(hDlg,IDC_SLIDER_FASTER),TBM_GETRANGEMIN,0,0);
				if(cmqMax!=cmqMin)
					cmqLevel = (float)conf::cmqLevPerCent/(float)(cmqMax-cmqMin);
				else
					cmqLevel = 0.0f;
				//arcType = SendMessage(GetDlgItem(hDlg,IDC_COMBO_ARCHIVER),CB_GETCURSEL,0,0);
				bExcldPath=(BST_CHECKED!=SendMessage(GetDlgItem(hDlg,IDC_CHECK_INCLUDE_PATH_ARCHIVE),BM_GETCHECK,0,0));
				//arcCrNamesCB.Save(arcCrNamesCBFName,GetDlgItem(hDlg,IDC_EDIT_DEST_ARCHIVE),40);
				EndDialog(hDlg, 1);
				return (INT_PTR)TRUE;
			case IDCANCEL:
				//if(!GetWindowLong(hDlg,GWLP_USERDATA)) return TRUE;
				EndDialog(hDlg, 0);
				return (INT_PTR)TRUE;
		}
		break;
	}
	return (INT_PTR)FALSE;
}

INT_PTR CALLBACK FrArjToArjQueueDlgProc(HWND hDlg,UINT message,WPARAM wParam,LPARAM lParam)
{
static HFONT hf=0;static int hfRef=0;//obshiy hf, dinamik uchun emas:
static HBRUSH br=0;
static HBRUSH brHtBk=0;
	UNREFERENCED_PARAMETER(lParam);
	switch(message)
	{
	case WM_INITDIALOG:
		//Adjust to center:
		RECT rc; GetWindowRect(hDlg, &rc);
		int width,left,height,top;

		width = rc.right - rc.left;
		left = width*hfRef % conf::wndWidth;//conf::wndLeft + (conf::wndWidth - width)/2;
		if(left>conf::wndWidth-width)left=0;

		height = rc.bottom - rc.top;
		top = (width*hfRef / conf::wndWidth)*height;//conf::wndTop + (conf::wndHeight - height)/2;
		if(top>conf::wndHeight-top)top=0;
		MoveWindow(hDlg, left, top+20, width, height, TRUE);

		//Load language strings:
		wchar_t s[MAX_PATH];
		LoadString(hInst,IDS_STRINGSW_235,s,MAX_PATH);//45
		SetWindowText(hDlg,s);
		LoadString(hInst,IDS_STRINGSW_47,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_STATIC,s);
		LoadString(hInst,IDS_STRINGSW_48,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_STATIC5,s);
		//LoadString(hInst,IDS_STRINGSW_49,s,MAX_PATH);
		//SetDlgItemText(hDlg,IDC_BUTTON_TO_BACKGROUND_COPY_QUEUE,s);
		ShowWindow(GetDlgItem(hDlg,IDC_BUTTON_TO_BACKGROUND_COPY_QUEUE),SW_HIDE);
		LoadString(hInst,IDS_STRINGSW_50,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_BUTTON_STOP,s);
		LoadString(hInst,IDS_STRINGSW_13,s,MAX_PATH);
		SetDlgItemText(hDlg,IDCANCEL,s);

		PostMessage(GetDlgItem(hDlg,IDC_PROGRESS_COPY_SINGLE),PBM_SETRANGE,0,MAKELPARAM(0,1000));
		PostMessage(GetDlgItem(hDlg,IDC_PROGRESS_COPY_TOTAL ),PBM_SETRANGE,0,MAKELPARAM(0,1000));
		PostMessage(GetDlgItem(hDlg,IDC_PROGRESS_COPY_SINGLE),PBM_SETSTEP,1,0);
		PostMessage(GetDlgItem(hDlg,IDC_PROGRESS_COPY_TOTAL ),PBM_SETSTEP,1,0);

		SendMessage(hDlg,WM_USER+1,0,0);
		if(!lParam) return TRUE;//Agar confDlg dan chaqirilgan b-sa,rang-shriftlarini o'zgartirish uchun;

		DWORD cpyThrdId;srcPanel=((Panel*)lParam)->iThis;
		CreateThread(NULL,1024,(LPTHREAD_START_ROUTINE)addArjToArjThrdFnc,hDlg,0,&cpyThrdId);
		SetWindowLong(hDlg,GWLP_USERDATA,cpyThrdId);
		return TRUE;
	case WM_CTLCOLORSTATIC:
	case WM_CTLCOLORDLG:HDC dc;dc = (HDC)wParam;
		SetTextColor(dc,conf::Dlg.dlgRGBs[1][1]);
		SetBkColor(dc,conf::Dlg.dlgRGBs[1][2]);
		return (INT_PTR)br;
	case WM_CTLCOLOREDIT:dc = (HDC)wParam;
		SetTextColor(dc,conf::Dlg.dlgRGBs[1][1]);
		SetBkColor(dc,conf::Dlg.dlgRGBs[1][2]);
		return (INT_PTR)br;
	case WM_CTLCOLORBTN:dc=(HDC)wParam;
		SetTextColor(dc,conf::Dlg.dlgRGBs[1][4]);
		SetBkColor(dc,conf::Dlg.dlgRGBs[1][5]);
		return (INT_PTR)brHtBk;
	case WM_DRAWITEM://WM_CTLCOLORBTN dagi knopkalar:
		LPDRAWITEMSTRUCT lpdis;lpdis = (LPDRAWITEMSTRUCT)lParam;
		GetWindowText(lpdis->hwndItem,s,64);
		UINT uStyle;uStyle = DFCS_BUTTONPUSH;
		rc = lpdis->rcItem;
		if(lpdis->itemState & ODS_SELECTED)
		{	uStyle |= DFCS_PUSHED;
			rc.left+=2;rc.top+=2;
		}
		DrawFrameControl(lpdis->hDC, &lpdis->rcItem, DFC_BUTTON, uStyle);
		if(lpdis->itemState & ODS_SELECTED)
			{rc.left+=1;rc.top+=1;rc.bottom-=2;rc.right-=3;}
		else
			{rc.left+=1;rc.top+=2;rc.bottom-=3;rc.right-=3;}
		FillRect(lpdis->hDC,&rc,brHtBk);//DrawText(lpdis->hDC,"                                                  ",50,&rc,DT_SINGLELINE|DT_VCENTER|DT_INTERNAL|DT_LEFT);
		if(lpdis->itemState & ODS_SELECTED)
			{rc.left-=1;rc.top-=1;rc.bottom+=3;rc.right+=3;}
		else
			{rc.left-=1;rc.top-=2;rc.bottom+=2;rc.right+=3;}
		DrawText(lpdis->hDC,s,MyStringLength(s,64),&rc,DT_SINGLELINE|DT_VCENTER|DT_CENTER);
		return TRUE;
	case WM_USER+1://hf obshiy uchun, dinamik o'zgartirish uchun emas:
		if(0==hfRef)
		{	hf = CreateFontIndirect(&conf::Dlg.dlgFnts[1]);
			br = CreateSolidBrush(conf::Dlg.dlgRGBs[1][0]);
			brHtBk = CreateSolidBrush(conf::Dlg.dlgRGBs[1][5]);
		}
		SendMessage(GetDlgItem(hDlg,IDC_STATIC),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_STATIC5),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_BUTTON_TO_BACKGROUND_COPY_QUEUE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_BUTTON_STOP),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDCANCEL),WM_SETFONT,(WPARAM)hf,TRUE);
		++hfRef;
		return 0;//GWLP_USERDATA
	case WM_USER+4:
		if(0==iAppndToPanelArc)
			EndDialog(hDlg,0);
		else
			DestroyWindow(hDlg);
		return 0;
	case WM_DESTROY:
		if(--hfRef<1)
		{	DeleteObject(hf);
			DeleteObject(br);
			DeleteObject(brHtBk);
		}
		return 0;
	case WM_USER+2://Dinamik o'zgartirish uchun:
		DeleteObject(hf);hfRef=1;
		hf = CreateFontIndirect(&conf::Dlg.dlgFnts[1]);
		SendMessage(GetDlgItem(hDlg,IDC_STATIC),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_STATIC5),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_BUTTON_TO_BACKGROUND_COPY_QUEUE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_BUTTON_STOP),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDCANCEL),WM_SETFONT,(WPARAM)hf,TRUE);
		return 0;//GWLP_USERDATA
	case WM_USER+3://Dinamik o'zgartirish uchun, colorni:
		DeleteObject(br);DeleteObject(brHtBk);hfRef=1;
		br = CreateSolidBrush(conf::Dlg.dlgRGBs[1][0]);
		brHtBk = CreateSolidBrush(conf::Dlg.dlgRGBs[1][5]);
		RedrawWindow(hDlg,NULL,NULL,RDW_INVALIDATE|RDW_ALLCHILDREN);
		return 0;//GWLP_USERDATA
	case WM_COMMAND:
		switch(LOWORD(wParam))
		{	case IDC_BUTTON_STOP:
				PostThreadMessage(GetWindowLong(hDlg,GWLP_USERDATA),MYWM_STOP,0,0);
				return (INT_PTR)TRUE;
			case IDCANCEL:
				PostThreadMessage(GetWindowLong(hDlg,GWLP_USERDATA),MYWM_CANCEL,0,0);
				if(0==iAppndToPanelArc)
					EndDialog(hDlg,0);
				else
					DestroyWindow(hDlg);
				return (INT_PTR)TRUE;
		}
		break;
	}
	return (INT_PTR)FALSE;
}

BOOL FrArjToArjShowDlg(Panel *frPanel, Panel* toPanel)//to existing and opening archive:
{
	if(archive::numPlugins<1)
	{	Err::msg(frPanel->GetHWND(),0,L"No any archiver plugin in \"Plugins\\Archive\\\" folder,please,install any one.");
		return TRUE;
	}
	if(frPanel->GetTotSelects()==0)
	if(frPanel->GetHot()<1 || frPanel->GetHot()>frPanel->GetTotItems()-1)
		return TRUE;
	if(!frPanel->GetArch()->GetPlgObj())
	{	Err::msg(frPanel->GetHWND(),0,L"From panel archive is closed!!!.");
		return TRUE;
	}
	if(!toPanel->GetArch()->GetPlgObj())
	{	Err::msg(frPanel->GetHWND(),0,L"Destination panel archive is closed!!!.");
		return TRUE;
	}
	int saveOpponent = frPanel->iOpponent;
	frPanel->iOpponent = toPanel->iThis;
	int r=(int)DialogBoxParam(hInst,MAKEINTRESOURCE(IDD_DIALOG_ADD_ARCHIVE),hWnd,ToArjDlgProc,(LPARAM)frPanel);
	frPanel->iOpponent = saveOpponent;
	if(1!=r)
		return FALSE;
	
	toPanel->GetArch()->Close$4();
	//toPanel->GetArch()->Open$12(toPanel->GetArcFilePathAndName(),2);//opn exstng
	MyStringCpy(destArcName,MAX_PATH-1,toPanel->GetArcFilePathAndName());
	iAppndToPanelArc=0;//not check for existing,use end dialog;
	iApndDestPanel=toPanel->iThis;
	saveOpponent = frPanel->iOpponent;
	frPanel->iOpponent = toPanel->iThis;
	r = (int)DialogBoxParam(hInst,MAKEINTRESOURCE(IDD_DIALOG_COPY_QUEUE),//CreateDialogParam edi
						   frPanel->GetHWND(),(DLGPROC)FrArjToArjQueueDlgProc,(LPARAM)frPanel);
	frPanel->iOpponent = saveOpponent;
	//toPanel->GetArch()->Close$4();
	toPanel->GetArch()->OpenForUnpacking$8(toPanel->GetArcFilePathAndName(),toPanel->GetArch()->GetPlgNum());
	toPanel->FreeMem();//p->FreeSelection(); shartmas
	toPanel->FillArchItems(toPanel->GetArcPath());
	toPanel->ChangeSheetTabPath();
	toPanel->AdjustScrollity();
	toPanel->ScrollItemToView(0);
	toPanel->ClrScr();
	toPanel->Render(NULL);
	toPanel->SetFocus();
	return TRUE;
}

BOOL ToArjShowDlg(Panel *frPanel, Panel* toPanel)//to existing and opening archive:
{
	if(archive::numPlugins<1)
	{	Err::msg(frPanel->GetHWND(),0,L"No any archiver plugin in \"Plugins\\Archive\\\" folder,please,install any one.");
		return TRUE;
	}
	if(frPanel->GetTotSelects()==0)
	if(frPanel->GetHot()<1 || frPanel->GetHot()>frPanel->GetTotItems()-1)
		return TRUE;

	if(!toPanel->GetArch()->GetPlgObj())
	{	Err::msg(frPanel->GetHWND(),0,L"Destination panel archive is closed!!!.");
		return TRUE;
	}

	int saveOpponent = frPanel->iOpponent;
	frPanel->iOpponent = toPanel->iThis;
	int r=(int)DialogBoxParam(hInst,MAKEINTRESOURCE(IDD_DIALOG_ADD_ARCHIVE),hWnd,ToArjDlgProc,(LPARAM)frPanel);
	frPanel->iOpponent = saveOpponent;
	if(1!=r)
		return FALSE;


	toPanel->GetArch()->Close$4();
	//toPanel->GetArch()->Open$12(toPanel->GetArcFilePathAndName(),2);//opn exstng
	MyStringCpy(destArcName,MAX_PATH-1,toPanel->GetArcFilePathAndName());
	iAppndToPanelArc=0;//not check for existing,use end dialog;
	iApndDestPanel=toPanel->iThis;
	saveOpponent = frPanel->iOpponent;
	frPanel->iOpponent = toPanel->iThis;
	r = (int)DialogBoxParam(hInst,MAKEINTRESOURCE(IDD_DIALOG_COPY_QUEUE),//CreateDialogParam edi
						   frPanel->GetHWND(),(DLGPROC)AddArchiveQueueDlgProc,(LPARAM)frPanel);
	frPanel->iOpponent = saveOpponent;
	//toPanel->GetArch()->Close$4();
	toPanel->GetArch()->OpenForUnpacking$8(toPanel->GetArcFilePathAndName(),toPanel->GetArch()->GetPlgNum());
	toPanel->FreeMem();//p->FreeSelection(); shartmas
	toPanel->FillArchItems(toPanel->GetArcPath());
	toPanel->ChangeSheetTabPath();
	toPanel->AdjustScrollity();
	toPanel->ScrollItemToView(0);
	toPanel->ClrScr();
	toPanel->Render(NULL);
	toPanel->SetFocus();
	return TRUE;
}

VOID addArjToArjThrdFnc(LPVOID lpar)
{
 //2.Arxivni ochamiz:
CArch arch;
arch.hDlg = (HWND)lpar; prgrsDlg = &arch.hDlg;
arch.bStop = FALSE;
arch.bCancel = FALSE;
arch.thrId = GetCurrentThreadId();
arch.beginTick = arch.beginTickTot = GetTickCount();
arch.stopTick[0] = arch.stopTickTot[0] = 0;
arch.cmqlev=(int)(cmqLevel * 9.0f);
arch.crypt = crypt;
arch.bDelAftArchiving=bDelAftArchiving;
arch.bExcldPath=bExcldPath;
arch.bSFXArchive=bSFXArchive;
enCheckCopyFilesToExisting = showEach;

//srPanel num in srcPanel;


 MyStringCpy(arch.password,MAX_PATH-1,password);
 arch.nameLn=MyStringCpy(arch.name,MAX_PATH-1,destArcName);//destArcName ni bo'shatamiz;
 //Srazu dst ga kopi qilib olaylik,keyingi threadga bo'shatish uchun;

 CTempDir tmp(CTempDir::arjCpyToArj);
 tmp.UnpackSelected(&panel[srcPanel]);

 MyStringCpy(arch.password,MAX_PATH-1,password);
 arch.nameLn=MyStringCpy(arch.name,MAX_PATH-1,destArcName);//destArcName ni bo'shatamiz;
 //Srazu dst ga kopi qilib olaylik,keyingi threadga bo'shatish uchun;

 wchar_t tmpp[MAX_PATH];int l=MyStringCpy(tmpp,MAX_PATH-1,tmp.GetPath());tmpp[l]='\\'; tmpp[l+1]='*'; tmpp[l+2]=0;
 arch.totFiles = GetFilesCntInFolder(tmpp);
 if(!arch.totFiles)goto End;
 arch.stack = (ArcStack*)malloc(arch.totFiles*sizeof(ArcStack));
 arch.GetFilesInFolder(tmpp,arch.stack);
 CutSelectedNames(arch.stack,tmpp,arch.totFiles);//,0==iAppndToPanelArc?FALSE:TRUE);
 if(0==iAppndToPanelArc)AddPanArcPathToDestNames(arch.stack,panel[iApndDestPanel].GetArcPath(),arch.totFiles);
 arch.plgNum=panel[iApndDestPanel].GetArch()->GetPlgNum();
 BOOL bSkipAll=FALSE;

 //1.Avval dest arc bormi, o'zi, shuni aniqlaymiz:
 int iThrdArcFileExist=0;
 if(0==iAppndToPanelArc)//Append to opened arc,use EndDialog;
	 iThrdArcFileExist=2;
 else
 {	if(IsFileExist(arch.name))
	{	 iThrdArcFileExist=(int)DialogBoxParam(hInst,MAKEINTRESOURCE(IDD_DIALOG_ARCH_EXIST_OVEWRITE),
							arch.hDlg,arcExstOvwrtQuestnDlgProc,(LPARAM)&arch);
		if(3==iThrdArcFileExist) goto End;
 }	}

 //2.Arch file ni ochamiz.
 SetDlgItemText(arch.hDlg,IDC_STATIC5/*Total proggress*/,arch.name);
 arch.Open$12(arch.name,arch.plgNum,iThrdArcFileExist);
 arch.SetCryptMethod$8(arch.crypt);

 arch.prgrs.postedSz=arch.prgrs.postedSzStep=arch.prgrs.postedSzNextFile=0;

 if(2==iThrdArcFileExist)//Append existing;
	 if(!arch.RebuildCheckExistings$8(arch.GetPlgObj(),password))
		 goto End;

 for(arch.iCrntFileCopy=0; arch.iCrntFileCopy<arch.totFiles; arch.iCrntFileCopy++)
 {
  if(2==iThrdArcFileExist)
	  if(arch.stack[arch.iCrntFileCopy].numInSrc>-1)
		  continue;//Already rebuilded;

  SetDlgItemText(arch.hDlg,IDC_STATIC,arch.stack[arch.iCrntFileCopy].FullPathAndName);

  if(file==arch.stack[arch.iCrntFileCopy].attribute)
  {  if(!arch.Add$24(arch.iCrntFileCopy))
LoopCopy:
	 {	LPVOID* par[3]={(LPVOID*)GetLastError(),(LPVOID*)arch.stack[arch.iCrntFileCopy].FullPathAndName,(LPVOID*)arch.name};
		int r = (int)DialogBoxParam(hInst,MAKEINTRESOURCE(IDD_DIALOG_CHOISE_ACTION),arch.hDlg,fDelOper::actnDlgProc1,(LPARAM)par);
		if(0==r) goto End;//Cancel action;
		if(1==r) goto LoopCopy;
		if(3==r) bSkipAll=TRUE;//2-skip,3-skipAll;
     }
	 //arch.postedSz += arch.stack[arch.iCrntFileCopy].size; prgrsRoutga ko'chiramiz;
  }
  else
  {	
LoopCrea:
	if(!arch.CreateDir$24(arch.iCrntFileCopy))
	{	LPVOID* par[2]={(LPVOID*)GetLastError(),(LPVOID*)arch.name};
		int r = (int)DialogBoxParam(hInst,MAKEINTRESOURCE(IDD_DIALOG_CHOISE_ACTION),arch.hDlg,fDelOper::actnDlgProc,(LPARAM)par);
		if(0==r) goto End;//Cancel action;
		if(1==r) goto LoopCrea;
		if(3==r) bSkipAll=TRUE;//2-skip,3-skipAll;
  } }
Loop:
	MSG msg;//Only thread message:
	if(PeekMessage(&msg,(HWND)-1,MYWM_CANCEL-1,MYWM_CANCEL+10,PM_REMOVE))
	{	
		//static int i=0;
		//char ss[32];sprintf(ss,"\n %d ",i++);
		//OutputDebugString(ss);
		//OutputDebugString(GetWinNotifyText(msg.message));
		
		switch(msg.message)
		{	case MYWM_CANCEL:
				arch.bCancel = TRUE;
				goto End;
			case MYWM_STOP:
				wchar_t s[MAX_PATH];
				if(arch.bStop)
				{	LoadString(hInst,IDS_STRINGSW_50,s,MAX_PATH);
					SetDlgItemText(arch.hDlg,IDC_BUTTON_STOP,s);
					arch.bStop = FALSE;
				}
				else
				{	LoadString(hInst,IDS_STRINGSW_3,s,MAX_PATH);
					SetDlgItemText(arch.hDlg,IDC_BUTTON_STOP,s);
					arch.bStop = TRUE;
					Sleep(250);
					goto Loop;
				}
				break;
 	}	}
	else if(arch.bStop)
	{	Sleep(250);
		goto Loop;
}	}
End:
 tmp.Close();
 if(arch.plgObj)
	arch.Close$4();
 SendMessage(arch.hDlg,WM_USER+4,0,0);//DestroyWindow(arch.hDlg);//CreateDialog b-n yaratilganligi uchun;
 if(arch.stack) free(arch.stack);
 arch.stack=0;
 ExitThread(0);
}

}//end of namespace;