// UnrarUsing.cpp : Defines the entry point for the console application.
//

#include "windows.h"

typedef LPVOID (*OpenForUnpacking$8_t)(wchar_t*,LPVOID);
OpenForUnpacking$8_t OpenForUnpacking$8=NULL;
typedef BOOL (*Close$4_t)(LPVOID);
Close$4_t Close$4=NULL;
typedef VOID (*SetCallbacks$4xxx_t)(LPVOID,...);
SetCallbacks$4xxx_t SetCallbacks$4xxx=NULL;
typedef void (*UnpackProgressRoutine_t)(unsigned __int64,unsigned __int64,wchar_t*);
typedef BOOL (*Unpack$28_t)(HWND,LPVOID,wchar_t*,wchar_t*,BOOL*,UnpackProgressRoutine_t,__int32*);
Unpack$28_t Unpack$28=NULL;
typedef BOOL (*UnpackToMem$20_t)(HWND,LPVOID,LPVOID,int*,wchar_t*);
UnpackToMem$20_t UnpackToMem$20=NULL;
typedef VOID (*SetPassword$8_t)(LPVOID,wchar_t*);
SetPassword$8_t SetPassword$8=NULL;


int  CALLBACK checkFileInSelctn(IN LPVOID host,IN char *fileName)
{return 0;}
VOID CALLBACK excldFileFrSelctn(IN LPVOID host,IN int fileNumberInSelection,IN int fileNumberInArchive)
{}
BOOL CALLBACK getFileInfoFromSelection(IN LPVOID host,IN int fileNumInSelection,OUT WIN32_FIND_DATA *fileInfo)
{return TRUE;}
DWORD CALLBACK prgrssRout(IN LPVOID host,IN unsigned __int64 *CrntFileProgressed,IN unsigned __int64 *CrntFileTotal,
						  IN unsigned __int64 *TotalProgressed,IN unsigned __int64 *Total)
{return 0;}
int CALLBACK showDlgOverwriteExistFile(	IN LPVOID host,IN int fileNumInSelection,IN wchar_t *fileNameInArchive,
										IN unsigned __int64 *fileSizeInArchive,IN FILETIME *fileCreateTimeInArchive,
										IN WIN32_FIND_DATA *fileInfoFromSelection)
{return 0;}
int  CALLBACK addItemToPanelList(IN LPVOID host,wchar_t*,WIN32_FIND_DATA*)
{return 0;}
BOOL CALLBACK saveOptions(IN int plgId,VOID*,int)
{return TRUE;}
BOOL CALLBACK readOptions(IN int plgId,VOID*,int)
{return TRUE;}
void UnpkPrgrsRout(unsigned __int64,unsigned __int64,wchar_t*)
{}

int main()
{HMODULE h=LoadLibrary(L"Plugins\\Archive\\Rar32\\Rar64Dbg.dll");
 if(!h)return 0;
	OpenForUnpacking$8=(OpenForUnpacking$8_t)GetProcAddress(h,"OpenForUnpacking$8");
	Close$4=(Close$4_t)GetProcAddress(h,"Close$4");
	SetCallbacks$4xxx=(SetCallbacks$4xxx_t)GetProcAddress(h,"SetCallbacks$4xxx");
	Unpack$28=(Unpack$28_t)GetProcAddress(h,"Unpack$28");
	UnpackToMem$20=(UnpackToMem$20_t)GetProcAddress(h,"UnpackToMem$20");
	SetPassword$8=(SetPassword$8_t)GetProcAddress(h,"SetPassword$8");
	
	if((!OpenForUnpacking$8) || (!Close$4) ||(!SetCallbacks$4xxx) || (!Unpack$28) || (!UnpackToMem$20)
			|| (!SetPassword$8))return 0;

LPVOID plg = OpenForUnpacking$8(L"Bin.rar",NULL);
	if(!plg)return 0;
	SetCallbacks$4xxx(	checkFileInSelctn,
						excldFileFrSelctn,
						getFileInfoFromSelection,
						prgrssRout,
						showDlgOverwriteExistFile,
						saveOptions,
						readOptions,
						addItemToPanelList);
	int iOwrBits=0;BOOL bCancel=FALSE;
	SetPassword$8(plg,L"jaloliddin");
	//Unpack$28(NULL,plg,L"D:\\Temp\\",L"Config\\Language.cnf",&bCancel,UnpkPrgrsRout,&iOwrBits);
	char buf[78277];int bufSz=78277;
	UnpackToMem$20(NULL,plg,buf,&bufSz,L"Config\\Language.cnf");
	
	Close$4(plg);
	FreeLibrary(h);	
	return 0;
}

