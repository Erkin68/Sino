#ifndef __PLUGINS_C_H__
#define __PLUGINS_C_H__


#include "windows.h"
#include "stdio.h"



//extern "C"
//{

typedef	int  (CALLBACK *checkFileInSelctn_t)(IN LPVOID host,
											 IN char *fileName);
typedef	VOID (CALLBACK *excldFileFrSelctn_t)(IN LPVOID host,
											 IN int fileNumberInSelection,
											 IN int fileNumberInArchive);
typedef	BOOL (CALLBACK *getFileInfoFromSelection_t)(
										IN LPVOID host,
										IN int fileNumInSelection,
										OUT WIN32_FIND_DATA *fileInfo);
typedef	DWORD (CALLBACK *prgrssRout_t)(IN LPVOID host,
									   IN unsigned __int64 *CrntFileProgressed,
									   IN unsigned __int64 *CrntFileTotal,
									   IN unsigned __int64 *TotalProgressed,
									   IN unsigned __int64 *Total);
typedef	int (CALLBACK *showDlgOverwriteExistFile_t)(
										IN LPVOID host,
										IN int fileNumInSelection,
										IN wchar_t *fileNameInArchive,
										IN unsigned __int64 *fileSizeInArchive,
										IN FILETIME *fileCreateTimeInArchive,
										IN WIN32_FIND_DATA *fileInfoFromSelection);
typedef int  (CALLBACK *addItemToPanelList_t)(IN LPVOID host,wchar_t*,WIN32_FIND_DATA*);
typedef BOOL (CALLBACK *saveOptions_t)(IN int plgId,VOID*,int);
typedef BOOL (CALLBACK *readOptions_t)(IN int plgId,VOID*,int);

//Callbacks:
extern checkFileInSelctn_t checkFileInSelctn;
extern excldFileFrSelctn_t excldFileFrSelctn;
extern getFileInfoFromSelection_t getFileInfoFromSelection;
extern prgrssRout_t prgrssRout;
extern showDlgOverwriteExistFile_t showDlgOverwriteExistFile;
extern saveOptions_t saveOptions;
extern readOptions_t readOptions;
extern addItemToPanelList_t addItemToPanelList;

typedef struct TPluginObj
{	FILE *fAddLstFile;
	//FILE *fDelLstFile;
	wchar_t addLstFileName[MAX_PATH];	
	//wchar_t delLstFileName[MAX_PATH];	
	wchar_t relPath[MAX_PATH];
	int compressLevel;
	union
	{	wchar_t rarFileName[MAX_PATH];
		wchar_t unrarFileName[MAX_PATH];
	};
	wchar_t password[MAX_PATH];
	union
	{	struct
		{	__int32 bOvwrtLtst 		: 1;
			__int32 bOvwrtOldst		: 1;
			__int32 bOvwrtBigst		: 1;
			__int32 bRename	   		: 1;
			__int32 bSkip	   		: 1;
			__int32 bOvwrt     		: 1;
			__int32 bOvwrtLtlst		: 1;
			__int32 bOvwrtLtstAll	: 1;
			__int32 bOvwrtOldstAll	: 1;
			__int32 bOvwrtBigstAll	: 1;
			__int32 bRenameAll		: 1;
			__int32 bSkipAll		: 1;
			__int32 bOvwrtAll		: 1;
			__int32 bOvwrtLtlstAll	: 1;
		};
		__int32 bools;
	};

	BOOL bAppend;
	BOOL bExcludePath;
	LPVOID host;
	int size_buf;
	void *buf;
	HANDLE hfmap;//if temporary to file mapping, this is handle,
	void *heapAndMapBuf;
	__int64 szChm;
	__int64 fstFilePos;
	enum
	{	pack,
		unpack//Open with OpenForUnpacking
	} packType;
} PluginObj;

typedef struct TOPT
{
wchar_t password[MAX_PATH];
wchar_t rarExePath[MAX_PATH];
wchar_t tempDir[MAX_PATH];
int     iType;//0-not setted,1-winrar,rar;
} OPT;
extern OPT opt;

//}
#endif