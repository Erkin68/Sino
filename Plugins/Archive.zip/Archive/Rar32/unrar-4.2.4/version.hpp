#define RARVER_MAJOR     4
#define RARVER_MINOR    20
#define RARVER_BETA      0
#define RARVER_DAY       9
#define RARVER_MONTH     6
#define RARVER_YEAR   2012
