//1-global namespaceda turishi shart:
#include "Plugins_CPP.h"
#include "resource.h"
#include "strsafe.h"
#include "My-unrar-4.2.4\rar.hpp"//archive.hpp"
#include "..\..\..\Operations\MyShell\MyShell.h"


extern INT_PTR CALLBACK optnDlg(HWND,UINT,WPARAM,LPARAM);


extern "C" {
extern wchar_t **strngs;
extern HMODULE plgnDllInst;
extern int  plgId;
extern int	MyStringCpySlashA(char*,int,char*);
extern wchar_t* mystrstrW(wchar_t*,wchar_t*);
extern wchar_t* mystrstrslashW(wchar_t*,wchar_t*,wchar_t**);
extern void msg(HWND,DWORD,LPWSTR,LPWSTR);
extern BOOL WriteFromList(PluginObj*);
extern int GetTempDir(wchar_t*);

typedef void (*UnpackProgressRoutine_t)(unsigned __int64,unsigned __int64,wchar_t*);

INT_PTR CALLBACK ExstngActnDlgProc(HWND,UINT,WPARAM,LPARAM);
INT_PTR CALLBACK AskPasswordDlgProc(HWND, UINT, WPARAM, LPARAM);
void UnstoreFile(ComprDataIO&,int64);

checkFileInSelctn_t checkFileInSelctn;
excldFileFrSelctn_t excldFileFrSelctn;
getFileInfoFromSelection_t getFileInfoFromSelection;
prgrssRout_t prgrssRout;
showDlgOverwriteExistFile_t showDlgOverwriteExistFile;
saveOptions_t saveOptions;
readOptions_t readOptions;
addItemToPanelList_t addItemToPanelList;


__declspec (dllexport) BOOL Close$4(PluginObj *plg)
{
	if(PluginObj::unpack==plg->packType)//plg->unexef)
	{	//((Archive*)&plg->arc)->Close();
		//delete ((Archive*)&plg->arc);
	}
	else if(PluginObj::pack==plg->packType)//plg->exef)
	{	WriteFromList(plg);
	}
	free(plg);
	return TRUE;
}

__declspec (dllexport) int GetPluginType()
{
	return 1;
}

__declspec (dllexport) const wchar_t* GetPluginDescription()
{
	return strngs[23];//"Sino chm-plugin version 1.1";
}

__declspec (dllexport) const wchar_t* GetPluginName()
{
	return strngs[0];
}

__declspec (dllexport) const wchar_t *GetArchExtnsn()
{
	return L"rar";
}

__declspec (dllexport) BOOL CreateDir$24(PluginObj *plg,wchar_t *FullPathAndName,wchar_t *RelatedPathAndName,
										 wchar_t *password,int compress_level,BOOL bExcldPath)
{
	return TRUE;
}

__declspec (dllexport) BOOL AddEmptyDir$20(PluginObj *plg,wchar_t *RelatedPathAndName,
										   wchar_t *password,int compress_level,BOOL bExcldPath)
{
	while(!opt.iType)
	{	if(!DialogBox(plgnDllInst,MAKEINTRESOURCE(IDD_DIALOG_OPTIONS),NULL,optnDlg))
			return FALSE;
	}
	if(!IsFileExist(opt.rarExePath)){opt.iType=0;return FALSE;}

	wchar_t s[MAX_PATH],crntDir[MAX_PATH],cmndLine[MAX_PATH];
	int l=GetTempDir(s);MyStringCpy(crntDir,MAX_PATH-1,s);
	s[l]='\\';
	l+=MyStringCpy(&s[l],MAX_PATH-1-l,RelatedPathAndName);
	if(!IsDirExist(s))
	{	if(!CreateDirectory(s,NULL))
			return FALSE;
	}
	s[l++]='1';s[l++]=0;
	CloseHandle(CreateFile(s,GENERIC_WRITE,FILE_SHARE_WRITE,NULL,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,NULL));
	s[l-2]=0;
	cmndLine[0]=' ';cmndLine[1]='m';cmndLine[2]=' ';
	int L=3+MyStringCpy(&cmndLine[3],MAX_PATH-4,plg->rarFileName);
	cmndLine[L++]=' ';L+=MyStringCpy(&cmndLine[L],MAX_PATH-1-L,RelatedPathAndName);
	cmndLine[L++]='*';cmndLine[L++]=0;
	STARTUPINFOW si;ZeroMemory(&si,sizeof(si));si.cb=sizeof(si);
	PROCESS_INFORMATION pi;
	if(CreateProcessW(opt.rarExePath,cmndLine,NULL,NULL,FALSE,NORMAL_PRIORITY_CLASS,
					  NULL,crntDir,&si,&pi))
	{	WaitForSingleObject(pi.hThread,INFINITE);//40000);
		RemoveDirectory(s);
	}
	//Udaleniye tempdir\1 fayla:
	/*s[l++]='1';s[l++]=0;
	cmndLine[1]='d';
	cmndLine[L-2]='1';
	CreateProcessW(opt.rarExePath,cmndLine,NULL,NULL,FALSE,NORMAL_PRIORITY_CLASS,NULL,crntDir,&si,&pi);*/
	return TRUE;
}

__declspec (dllexport) BOOL RenameDir$12(PluginObj *plg,wchar_t *FName,wchar_t *FNewName)
{
	while(!opt.iType)
	{	if(!DialogBox(plgnDllInst,MAKEINTRESOURCE(IDD_DIALOG_OPTIONS),NULL,optnDlg))
			return FALSE;
	}
	wchar_t cmndLine[MAX_PATH];int L=0;
	cmndLine[L++]=' ';cmndLine[L++]='r';cmndLine[L++]='n';cmndLine[L++]=' ';
	L+=MyStringCpy(&cmndLine[L],MAX_PATH-L-1,plg->rarFileName);
	cmndLine[L++]=' ';L+=MyStringCpy(&cmndLine[L],MAX_PATH-1-L,FName);
	cmndLine[L++]=' ';L+=MyStringCpy(&cmndLine[L],MAX_PATH-1-L,FNewName);
	STARTUPINFOW si;ZeroMemory(&si,sizeof(si));si.cb=sizeof(si);
	PROCESS_INFORMATION pi;
	if(CreateProcessW(opt.rarExePath,cmndLine,NULL,NULL,FALSE,NORMAL_PRIORITY_CLASS,NULL,NULL,&si,&pi))
		WaitForSingleObject(pi.hThread,INFINITE);//40000);
	DeleteFile(plg->addLstFileName);
	return TRUE;
}

__declspec (dllexport) BOOL DeleteDir$8(PluginObj *plg,wchar_t *FName)
{
	while(!opt.iType)
	{	if(!DialogBox(plgnDllInst,MAKEINTRESOURCE(IDD_DIALOG_OPTIONS),NULL,optnDlg))
			return FALSE;
	}
	wchar_t cmndLine[MAX_PATH];
	cmndLine[0]=' ';cmndLine[1]='d';cmndLine[2]=' ';
	int L=3+MyStringCpy(&cmndLine[3],MAX_PATH-4,plg->rarFileName);
	cmndLine[L++]=' ';L+=MyStringCpy(&cmndLine[L],MAX_PATH-1-L,FName);
	STARTUPINFOW si;ZeroMemory(&si,sizeof(si));si.cb=sizeof(si);
	PROCESS_INFORMATION pi;
	if(CreateProcessW(opt.rarExePath,cmndLine,NULL,NULL,FALSE,NORMAL_PRIORITY_CLASS,NULL,NULL,&si,&pi))
		WaitForSingleObject(pi.hThread,INFINITE);//40000);
	//fwprintf(plg->fDelLstFile,L"%s\n",FName);
	return TRUE;
}

void saveOpt()
{	
	saveOptions(plgId,&opt,sizeof(opt));
}

__declspec (dllexport) void SetId$4(int id)
{
	plgId = id;
	readOptions(id,&opt,sizeof(opt));
}

__declspec (dllexport) VOID SetCallbacks$4xxx(LPVOID frstCallback,...)
{
va_list args;
	va_start(args, frstCallback);//1
	checkFileInSelctn = (checkFileInSelctn_t)frstCallback;//2
	excldFileFrSelctn = (excldFileFrSelctn_t)va_arg(args, LPVOID);//3
	getFileInfoFromSelection = (getFileInfoFromSelection_t)va_arg(args, LPVOID);//4
	prgrssRout = (prgrssRout_t)va_arg(args, LPVOID);//5
	showDlgOverwriteExistFile = (showDlgOverwriteExistFile_t)va_arg(args, LPVOID);//6
	saveOptions = (saveOptions_t)va_arg(args, LPVOID);//7
	readOptions = (readOptions_t)va_arg(args, LPVOID);//8
	addItemToPanelList = (addItemToPanelList_t)va_arg(args, LPVOID);//9
va_end (args);
}

BOOL IsThisValidChmFile(HANDLE hFile)
{
DWORD rd;
	unsigned __int32 itsf;ReadFile(hFile,&itsf,sizeof(__int32),&rd,NULL);
	if(rd!=sizeof(__int32) || itsf!=0x46535449)
		return FALSE;
	unsigned __int32 version;ReadFile(hFile,&version,sizeof(__int32),&rd,NULL);
	if(rd!=sizeof(__int32))
		return FALSE;
	unsigned __int32 headerSize;ReadFile(hFile,&headerSize,sizeof(__int32),&rd,NULL);
	if(rd!=sizeof(__int32))
		return FALSE;
	if(headerSize != 0x60)
		return FALSE;
	unsigned __int32 unknown1; ReadFile(hFile,&unknown1,sizeof(__int32),&rd,NULL);
	if(rd!=sizeof(__int32))
		return FALSE;
	if (unknown1 != 0 && unknown1 != 1) // it's 0 in one .sll file
		return FALSE;
	ReadFile(hFile,&unknown1,sizeof(__int32),&rd,NULL);
	ReadFile(hFile,&unknown1,sizeof(__int32),&rd,NULL);
	DWORD Guid[8];ReadFile(hFile,Guid,8*sizeof(DWORD),&rd,NULL);
	if(Guid[0]!=0x7C01FD10) return FALSE;
	if(Guid[1]!=0x11d07baa) return FALSE;
	if(Guid[2]!=0xa0000c9e) return FALSE;
	if(Guid[3]!=0xece622c9) return FALSE;
	if(Guid[4]!=0x7c01fd11) return FALSE;
	if(Guid[5]!=0x11d07baa) return FALSE;
	if(Guid[6]!=0xa0000c9e) return FALSE;
	if(Guid[7]!=0xece622c9) return FALSE;
	return TRUE;
}

__declspec (dllexport) LPVOID Open$12(wchar_t *name,BOOL bCreateNew,LPVOID host)
{
PluginObj *plg;
	plg=(PluginObj*)malloc(sizeof(PluginObj));
	if(!plg)
	{	msg(NULL,0,strngs[2],name);
		return NULL;
	}
	MyStringCpy(plg->rarFileName,MAX_PATH-1,name);
	plg->host = host;
	plg->bools=0;
	plg->password[0]=0;
	plg->packType=PluginObj::pack;//Close uchun;
	int l=MyStringCpy(plg->addLstFileName,MAX_PATH,name);
	wchar_t* p=wcsrchr(plg->addLstFileName,'.');
	if(p)++p;
	else
	{	plg->addLstFileName[l++]='.';
		p=&plg->addLstFileName[l];
	}
	*p++='l';*p++='s';*p++='t';*p=0;
	plg->fAddLstFile = _wfopen(plg->addLstFileName,L"w");
	plg->relPath[0]=0;
	plg->compressLevel=-1;//min ga qoyib Addlarda oshiramiz:
	plg->bExcludePath=FALSE;

	/*l=MyStringCpy(plg->delLstFileName,MAX_PATH,plg->addLstFileName);
	p=wcsrchr(plg->delLstFileName,'.');
	if(p) {*p++ = 'd';*p++ = 'e';*p++ = 'l';*p++ = '.';}
	else
	{plg->delLstFileName[l++]='d';plg->delLstFileName[l++]='e';plg->delLstFileName[l++]='l';
	 plg->delLstFileName[l++]='.';p=&plg->delLstFileName[l];}
	*p++='l';*p++='s';*p++='t';*p=0;
	plg->fDelLstFile = _wfopen(plg->delLstFileName,L"w");*/
	return plg;
}

__declspec (dllexport) VOID SetPassword$8(PluginObj* plg,wchar_t *pass)
{	if(plg)wcscpy(plg->password,pass);
}

__declspec (dllexport) LPVOID OpenForUnpacking$8(wchar_t *name,LPVOID host)//host - CArc;
{
PluginObj *plg;
	plg=(PluginObj*)malloc(sizeof(PluginObj));
	if(!plg)
	{	msg(NULL,0,strngs[2]/*"Err.opening zip file."*/,name);//"error %d with zipfile in unzGetGlobalInfo \n",err);
		return NULL;
	}
	plg->host = host;
	plg->bools=0;
	plg->password[0]=0;
	plg->packType=PluginObj::unpack;//Close uchun;
	MyStringCpy(plg->unrarFileName,MAX_PATH-1,name);
	//plg->arc = new Archive;
	//((Archive*)&plg->arc)->RemoveSequentialFlag();
	//((Archive*)&plg->arc)->WOpen(NULL,plg->unrarFileName);
    return plg;
}

__declspec (dllexport) BOOL RebuildCheckExistings$8(PluginObj *plg,wchar_t *password)
{
	return TRUE;
}

__declspec (dllexport) BOOL RenameFile$12(PluginObj *plg,wchar_t *FName,wchar_t *FNewName)
{
	while(!opt.iType)
	{	if(!DialogBox(plgnDllInst,MAKEINTRESOURCE(IDD_DIALOG_OPTIONS),NULL,optnDlg))
			return FALSE;
	}
	wchar_t cmndLine[MAX_PATH];int L=0;
	cmndLine[L++]=' ';cmndLine[L++]='r';cmndLine[L++]='n';cmndLine[L++]=' ';
	L+=MyStringCpy(&cmndLine[L],MAX_PATH-L-1,plg->rarFileName);
	cmndLine[L++]=' ';L+=MyStringCpy(&cmndLine[L],MAX_PATH-1-L,FName);
	cmndLine[L++]=' ';L+=MyStringCpy(&cmndLine[L],MAX_PATH-1-L,FNewName);
	STARTUPINFOW si;ZeroMemory(&si,sizeof(si));si.cb=sizeof(si);
	PROCESS_INFORMATION pi;
	if(CreateProcessW(opt.rarExePath,cmndLine,NULL,NULL,FALSE,NORMAL_PRIORITY_CLASS,NULL,NULL,&si,&pi))
		WaitForSingleObject(pi.hThread,INFINITE);//40000);
	DeleteFile(plg->addLstFileName);
	return TRUE;
}

__declspec (dllexport) BOOL DeleteFile$8(PluginObj *plg,wchar_t *FName)
{
	while(!opt.iType)
	{	if(!DialogBox(plgnDllInst,MAKEINTRESOURCE(IDD_DIALOG_OPTIONS),NULL,optnDlg))
			return FALSE;
	}
	wchar_t cmndLine[MAX_PATH];
	cmndLine[0]=' ';cmndLine[1]='d';cmndLine[2]=' ';
	int L=3+MyStringCpy(&cmndLine[3],MAX_PATH-4,plg->rarFileName);
	cmndLine[L++]=' ';L+=MyStringCpy(&cmndLine[L],MAX_PATH-1-L,FName);
	STARTUPINFOW si;ZeroMemory(&si,sizeof(si));si.cb=sizeof(si);
	PROCESS_INFORMATION pi;
	if(CreateProcessW(opt.rarExePath,cmndLine,NULL,NULL,FALSE,NORMAL_PRIORITY_CLASS,NULL,NULL,&si,&pi))
		WaitForSingleObject(pi.hThread,INFINITE);//40000);
	//fwprintf(plg->fDelLstFile,L"%s\n",FName);
	return TRUE;
}

wchar_t *dirList,*pEndDirList;
int iDirList,szDirList;
VOID AddDirToList(PluginObj *plg,wchar_t *p)
{
BOOL bFind=FALSE;wchar_t *pp=&dirList[0];
    for(int i=0; i<iDirList; i++)
	{	if(0==wcscmp(pp,p))
		{	bFind=TRUE;
			break;
		}						
		pp += wcslen(pp)+1;
	}
	if(!bFind)
	{	int l=(int)wcslen(p);
		int szEnd = (int)(pEndDirList-&dirList[0]);
		if(szEnd > szDirList-l+1)
		{	szDirList += 512;
			dirList = (wchar_t*)realloc(dirList,szDirList*sizeof(wchar_t));
			pEndDirList = &dirList[szEnd];
		}
		WIN32_FIND_DATA ff;
		wcscpy(pEndDirList,p);
		pEndDirList += l+1;
		ff.dwFileAttributes=FILE_ATTRIBUTE_DIRECTORY;
		ff.nFileSizeHigh=0;
		ff.nFileSizeLow = 0;
		addItemToPanelList(plg->host,p,&ff);
		++iDirList;
}	}

__declspec (dllexport) BOOL EnumDirectory$8(PluginObj *plg, wchar_t *DirName)
{
wchar_t pswrd[MAX_PATH];
int iTryEnum = 0;

	Archive arc;
	arc.RemoveSequentialFlag();
	arc.WOpen(NULL,plg->unrarFileName);

TryWithPswrd:
    if(arc.IsArchive(true))
    {	//ErrHandler.SetErrorCode(RARX_CRC); parollik;
		if(arc.GetFailedHeaderDecryption())
		{	if(plg->password[0])
			{	iTryEnum = 1;
				arc.GetRAROptions()->Password.Set(plg->password);
				goto Nxt;
			}
			else if(opt.password[0])
			{	iTryEnum = 3;
				arc.GetRAROptions()->Password.Set(opt.password);
				goto Nxt;
			}
			else if(arc.HeaderCRC!=arc.NewMhd.HeadCRC)
			{	wchar_t s[MAX_PATH];GetModuleFileName(NULL,s,MAX_PATH);
				HMODULE hm;wchar_t *p=wcsrchr(s,'\\');if(p)
#ifdef _WIN64
				{	wcscpy(p+1,L"MyShell64.dll");
					hm=LoadLibrary(s);
				}else hm=LoadLibrary(L"MyShell64.dll");
#else
				{	wcscpy(p+1,L"MyShell.dll");
					hm=LoadLibrary(s);
				}else hm=LoadLibrary(L"MyShell.dll");
#endif
				if(!hm)return FALSE;
				if(1==DialogBoxParam(hm/*plgnDllInst*/,MAKEINTRESOURCE(IDD_DIALOG_PASSWORD),NULL,AskPasswordDlgProc,(LPARAM)pswrd))
				{	iTryEnum = 2;
					arc.GetRAROptions()->Password.Set(pswrd);
Nxt:				arc.SetFailedHeaderDecryption(false);
					arc.Seek(0,SEEK_SET);
					goto TryWithPswrd;
				}
				else
				{	arc.Close();
					return FALSE;
		}	}	}
		else if(2==iTryEnum) MyStringCpy(plg->password,MAX_PATH-1,pswrd);
		else if(3==iTryEnum) MyStringCpy(plg->password,MAX_PATH-1,opt.password);

//      if (!Arc.IsOpened())
//          break;
		dirList = (wchar_t*)malloc(2048*sizeof(wchar_t));
		pEndDirList=&dirList[0];
		dirList[0]=0;
		iDirList=0;szDirList=2048;

        while(arc.ReadHeader()>0)
        {
          int HeaderType=arc.GetHeaderType();
          if (HeaderType==ENDARC_HEAD)
            break;
          switch(HeaderType)
          {
            case FILE_HEAD:
			  wchar_t s[MAX_PATH],*p,*pp;
              if(0==arc.NewLhd.FileNameW[0])
			  	  UtfToWide(arc.NewLhd.FileName,s,arc.NewLhd.NameSize+1);
			  else MyStringCpy(s,MAX_PATH-1,arc.NewLhd.FileNameW);
			  pp=0;
			  p = mystrstrW(s,DirName);
			  if(p)//hech qachon continue berma, davomi bor,skip to nexti;
			  	  pp = wcschr(p,'\\');
		  	  if(p && (!pp))
			  {	if(FILE_ATTRIBUTE_DIRECTORY & arc.NewLhd.FileAttr)
					AddDirToList(plg,p);
				else
				{	WIN32_FIND_DATA ff;
					ff.dwFileAttributes=arc.NewLhd.FileAttr;
					ff.nFileSizeHigh=(arc.NewLhd.FullUnpSize & 0xffffffff000000)>>32;
					ff.nFileSizeLow = arc.NewLhd.FullUnpSize & 0xffffffff;
					arc.NewLhd.mtime.GetWin32(&ff.ftLastWriteTime);
					arc.NewLhd.atime.GetWin32(&ff.ftCreationTime);
					addItemToPanelList(plg->host,p,&ff);
			  }	}
			  else if(p)//dir alohida berilmasdan,fayllarda berilgan bo'lsachi;
			  {	if(pp)*pp=0;
				AddDirToList(plg,p);
			  }
              //IntToExt(arc.NewLhd.FileName,arc.NewLhd.FileName);
              //FileMatched=Cmd->IsProcessFile(arc.NewLhd)!=0;
              /*if (FileMatched)
              {
                ListFileHeader(arc.NewLhd,Verbose,Technical,TitleShown,Bare);
                if (!(arc.NewLhd.Flags & LHD_SPLIT_BEFORE))
                {
                  TotalUnpSize+=arc.NewLhd.FullUnpSize;
                  FileCount++;
                }
                TotalPackSize+=arc.NewLhd.FullPackSize;
                if (Technical)
                  ListSymLink(Arc);
#ifndef SFX_MODULE
                if (Verbose)
                  arc.ViewFileComment();
#endif
              }*/
              break;
#ifndef SFX_MODULE
            case SUB_HEAD:
              //if (Technical && FileMatched && !Bare)
              //  ListOldSubHeader(arc);
              break;
#endif
            case NEWSUB_HEAD:
              //if (FileMatched && !Bare)
              {
                //if (Technical)
                //  ListFileHeader(arc.SubHead,Verbose,true,TitleShown,false);
                //ListNewSubHeader(Cmd,arc,Technical);
              }
              break;
          }
          arc.SeekToNext();
		}
		free(dirList);
	}
	//ArcCount++;
	//arc.Seek(0,SEEK_SET);
	arc.Close();
	return TRUE;
}

/*HANDLE mfilecrdir(PluginObj *plg,HWND prntDlg,char *root,char *dirname,BOOL *bCancel)
{
HANDLE HF;WIN32_FIND_DATAA FF,ff;
char s[MAX_PATH],*p=&s[0]; int r,ln=MyStringCpyA(s,MAX_PATH,root);
	if(*dirname)
	{	s[ln]='\\';
		MyStringCpySlashA(&s[ln+1],MAX_PATH-ln,dirname);
	}
	while(p && (*p))
	{	p=strchr(p,'\\');
		if(p)
		{	//char c=*(++p);*p=0;
			//if(!IsDirExist(s))
			//	CreateDirectory(s,NULL);
			//*p=c;
			*p=0;
			if(!IsDirExistA(s))
				CreateDirectoryA(s,NULL);
			*p='\\';
			++p;
	}	}
	GetFileAttributesEx(plg->unrarFileName,GetFileExInfoStandard,&ff);

    HF = MyFindFirstFileEx((LPCTSTR)s,FindExInfoStandard,&FF,FindExSearchLimitToDirectories,NULL,0);
	if(INVALID_HANDLE_VALUE!=HF)
	{	FindClose(HF);
		if(FF.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)
			return 0;
		
		//if(IDNO==MessageBox(prntDlg,s,"File is already exist,overwrite?",MB_YESNO))
		//	return NULL;
		LPVOID par[3]={s,s,&ff};
		if(plg->bOvwrtLtstAll)
		{	
OvLts:		if(1==CmpFILETIMEs(&ff.ftCreationTime,&FF.ftCreationTime))
				goto Cr;
			return 0;
		}
		else if(plg->bOvwrtOldstAll)
		{	
OvOld:		if(-1==CmpFILETIMEs(&ff.ftCreationTime,&FF.ftCreationTime))
				goto Cr;
			return 0;
		}
		else if(plg->bOvwrtBigstAll)
		{	unsigned __int64 szf,szF;
OvBg:		szf = ((unsigned __int64)ff.nFileSizeHigh << 32) | (unsigned __int64)ff.nFileSizeLow;
			szF = ((unsigned __int64)FF.nFileSizeHigh  << 32) | (unsigned __int64)FF.nFileSizeLow;
			if(szf < szF)
				goto Cr;
			return 0;//go to next rec;
		}
		else if(plg->bRenameAll)
		{	char RenName[MAX_PATH],sAdd[32],*pExt;int iMyCopyRenameFileEx;
Renm:		pExt = (char*)strrchr(s,'.');
			iMyCopyRenameFileEx=0;
			if(pExt) memcpy(RenName,s,((char*)pExt) - ((char*)s));
			else MyStringCpyA(RenName,MAX_PATH-1,(char*)s);
			do
			{	++iMyCopyRenameFileEx;
				StringCchPrintfA(sAdd,32,"_%d",iMyCopyRenameFileEx);
				MyStringCatA(RenName,MAX_PATH-1,sAdd);
				if(pExt) MyStringCatA(RenName,MAX_PATH-1,pExt);
			} while(IsFileExistA(RenName));
		}
		else if(plg->bSkipAll)  return 0;
		else if(plg->bOvwrtAll) goto Cr;
		else if(plg->bOvwrtLtlstAll)
		{	unsigned __int64 szf,szF;
OvLtl:		szf = ((unsigned __int64)ff.nFileSizeHigh << 32) | (unsigned __int64)ff.nFileSizeLow;
			szF = ((unsigned __int64)FF.nFileSizeHigh  << 32) | (unsigned __int64)FF.nFileSizeLow;
			if(szf > szF)
				goto Cr;
			return 0;//go to next rec;
		}//else:		
		r=DialogBoxParam(plgnDllInst,MAKEINTRESOURCE(IDD_DIALOG_EXIST_ACTION),prntDlg,ExstngActnDlgProc,(LPARAM)par);
		switch(r)
		{	case -1://idcancel;
				*bCancel = TRUE;
				return NULL;
			case 1://IDC_BUTTON_OVERWRITE_LATEST
				plg->bOvwrtLtst=1;
				goto OvLts;
			case 2://IDC_BUTTON_OVERWRITE_OLDEST:
				plg->bOvwrtOldst=1;
				goto OvOld;
			case 3://IDC_BUTTON_OVERWRITE_BIGGEST:
				plg->bOvwrtBigst=1;
				goto OvBg;
			case 4://IDC_BUTTON_RENAME:
				plg->bRename=1;
				goto Renm;
			case 5://IDC_BUTTON_SKIP:
				plg->bSkip=1;
				return 0;
			case 6://IDC_BUTTON_OVERWRITE:
				plg->bOvwrt=1;
				goto Cr;
			case 7://IDC_BUTTON_OVERWRITE_LITTLEST:
				plg->bOvwrtLtlst=1;
				goto OvLtl;


			case 11://IDC_BUTTON_OVERWRITE_LATEST with check box
				plg->bOvwrtLtstAll=1;
				goto OvLts;
			case 12://IDC_BUTTON_OVERWRITE_OLDEST: with check box
				plg->bOvwrtOldstAll=1;
				goto OvOld;
			case 13://IDC_BUTTON_OVERWRITE_BIGGEST: with check box
				plg->bOvwrtBigstAll=1;
				goto OvBg;
			case 14://IDC_BUTTON_RENAME: with check box
				plg->bRenameAll=1;
				goto Renm;
			case 15://IDC_BUTTON_SKIP: with check box
				plg->bSkipAll=1;
				return 0;
			case 16://IDC_BUTTON_OVERWRITE: with check box
				plg->bOvwrtAll=1;
				goto Cr;
			case 17://IDC_BUTTON_OVERWRITE_LITTLEST: with check box
				plg->bOvwrtLtlstAll=1;
				goto OvLtl;
	}	}
	//else
Cr:
	return CreateFileA(s,GENERIC_WRITE,FILE_SHARE_WRITE,NULL,OPEN_ALWAYS,FILE_ATTRIBUTE_NORMAL,NULL);
}*/

int CreateFullDir(wchar_t *dst)
{
int d=0;wchar_t *p=dst;

	while((p = wcschr(p,'\\'))!=0)
	{	*p=0;
		if(!IsDirExist(dst))
		{	CreateDirectory(dst,NULL);
			++d;
		}
		*p='\\';
		++p;
	}
	return d;
}

__declspec (dllexport) BOOL Unpack$28(HWND prntDlg,PluginObj *plg,wchar_t *destDirNameW,wchar_t *arjDirAndNameW,
									  BOOL* bCancel,UnpackProgressRoutine_t lpprgs,__int32 *bOverwriteBits)
{
//char as[MAX_PATH];
wchar_t s[MAX_PATH],dst[MAX_PATH],*p,*pp,*pLastSlash;char ch[MAX_PATH];
int iTryEnum = 0,dstLn;BOOL bDir=FALSE;DWORD szHigh=0;
unsigned __int64 mySz=0,arcFileLength=0;

	ComprDataIO DataIO;
	Unpack *Unp=new Unpack(&DataIO);
	Unp->Init();

	Archive arc(NULL);
	arc.RemoveSequentialFlag();
	arc.WOpen(NULL,plg->unrarFileName);

	*((DWORD*)&arcFileLength)=GetFileSize(arc.GetHandle(),&szHigh);
	arcFileLength += (int)(szHigh << 32);

TryWithPswrd:
    if(arc.IsArchive(true))
    {	if(arc.GetFailedHeaderDecryption())
		{	if(plg->password[0])
			{	if(0==iTryEnum)
					iTryEnum = 1;
				arc.GetRAROptions()->Password.Set(plg->password);
				goto Nxt;
			}
			else if(opt.password[0])
			{	iTryEnum = 3;
				arc.GetRAROptions()->Password.Set(opt.password);
				goto Nxt;
			}
			else if(arc.HeaderCRC!=arc.NewMhd.HeadCRC)
			{Ask:	
				wchar_t s[MAX_PATH];GetModuleFileName(NULL,s,MAX_PATH);
				HMODULE hm;wchar_t *p=wcsrchr(s,'\\');if(p)
#ifdef _WIN64
				{	wcscpy(p+1,L"MyShell64.dll");
					hm=LoadLibrary(s);
				}else hm=LoadLibrary(L"MyShell64.dll");
#else
				{	wcscpy(p+1,L"MyShell.dll");
					hm=LoadLibrary(s);
				}else hm=LoadLibrary(L"MyShell.dll");
#endif
				if(!hm)return FALSE;
			    if(1==DialogBoxParam(hm/*plgnDllInst*/,MAKEINTRESOURCE(IDD_DIALOG_PASSWORD),NULL,AskPasswordDlgProc,(LPARAM)s))
				{	iTryEnum = 2;
					arc.GetRAROptions()->Password.Set(s);
Nxt:				arc.SetFailedHeaderDecryption(false);
					arc.Seek(0,SEEK_SET);
					if(4==iTryEnum)goto Ask;
					iTryEnum = 4;
					goto TryWithPswrd;
				}
				else
				{	arc.Close();
					return FALSE;
		}	}	}
		else if(2==iTryEnum) MyStringCpy(plg->password,MAX_PATH-1,s);
		else if(3==iTryEnum) MyStringCpy(plg->password,MAX_PATH-1,opt.password);
	
		dstLn = MyStringCpy(dst,MAX_PATH-1,destDirNameW);
		p = wcsrchr(dst,'\\');
		if(p)
		{	*(p+1)=0;
			dstLn=(int)(p-&dst[0]+1);
		}

		while(arc.ReadHeader()>0)
        { File CurFile;
		  int HeaderType=arc.GetHeaderType();
          if (HeaderType==ENDARC_HEAD)
            break;
          switch(HeaderType)
          { case FILE_HEAD:pp=0;
			  memset(s,0,MAX_PATH*sizeof(wchar_t));
			  if(0==arc.NewLhd.FileNameW[0])
			  	  UtfToWide(arc.NewLhd.FileName,s,arc.NewLhd.NameSize+1);
			  else MyStringCpy(s,MAX_PATH-1,arc.NewLhd.FileNameW);
			  if(FILE_ATTRIBUTE_DIRECTORY!=arc.NewLhd.FileAttr)
			  {	p = mystrstrslashW(s,arjDirAndNameW,&pLastSlash);
				if(p)
				{	if(!bDir)if(*p)
						bDir = TRUE;
					pp = wcschr(p+1,'\\');
					if(!pp)
					{	WIN32_FIND_DATA ff;ff.dwFileAttributes=arc.NewLhd.FileAttr;
						ff.nFileSizeHigh=(arc.NewLhd.FullUnpSize & 0xffffffff000000)>>32;
						ff.nFileSizeLow = arc.NewLhd.FullUnpSize & 0xffffffff;
						arc.NewLhd.mtime.GetWin32(&ff.ftLastWriteTime);
						arc.NewLhd.atime.GetWin32(&ff.ftCreationTime);
						
						MyStringCpy(&dst[dstLn],MAX_PATH-1-dstLn,pLastSlash);
						CreateFullDir(dst);
						CurFile.Create("",dst,FMF_WRITE);
			  }	  }	  }

			  mySz += arc.NewLhd.PackSize;
			  lpprgs(arcFileLength, mySz, dst);

			  arc.ConvertAttributes();
			  DataIO.UnpArcSize=arc.FileLength();
			  //DataIO.UnpVolume=false;
			  DataIO.UnpVolume=(arc.NewLhd.Flags & LHD_SPLIT_AFTER)!=0;
			  DataIO.NextVolumeMissing=false;
			  arc.Seek(arc.NextBlockPos-arc.NewLhd.FullPackSize,SEEK_SET);

			  DataIO.CurUnpRead=0;
			  DataIO.CurUnpWrite=0;
			  DataIO.UnpFileCRC=arc.OldFormat ? 0 : 0xffffffff;
			  DataIO.PackedCRC=0xffffffff;

			  //if(plg->password[0])
			  {	SecPassword FilePassword;
				FilePassword.Set(plg->password);
				DataIO.SetEncryption(
					(arc.NewLhd.Flags & LHD_PASSWORD)!=0 ? arc.NewLhd.UnpVer:0,&FilePassword,
					(arc.NewLhd.Flags & LHD_SALT)!=0 ? arc.NewLhd.Salt:NULL,false,
					 arc.NewLhd.UnpVer>=36);
			  }
			  DataIO.SetPackedSizeToRead(arc.NewLhd.FullPackSize);
			  DataIO.SetFiles(&arc,&CurFile);
			  DataIO.SetTestMode((p && (!pp))?false:true);
			  DataIO.SetSkipUnpCRC(arc.Solid);

			  #ifndef _WIN_CE
			 	if (/*!TestMode &&*/ !arc.BrokenFileHeader &&
					  (arc.NewLhd.FullPackSize<<11)>arc.NewLhd.FullUnpSize &&
					  (arc.NewLhd.FullUnpSize<100000000 || arc.FileLength()>arc.NewLhd.FullPackSize))
					  CurFile.Prealloc(arc.NewLhd.FullUnpSize);
			  #endif

			  CurFile.SetAllowDelete(true);//!Cmd->KeepBroken);

			  bool PrevExtracted,LinkCreateMode;
			  LinkCreateMode=false;//!Cmd->Test && !SkipSolid;
			  PrevExtracted=false;

			  if(p && (!pp))
				  WideToChar(dst,ch);
			  else
			  {	  WideToChar(s,ch);
			  }

			  if(ExtractLink(DataIO,arc,ch,DataIO.UnpFileCRC,LinkCreateMode))
				PrevExtracted=LinkCreateMode;
			  else
				if ((arc.NewLhd.Flags & LHD_SPLIT_BEFORE)==0)
				  if (arc.NewLhd.Method==0x30)
					UnstoreFile(DataIO,arc.NewLhd.FullUnpSize);
				  else
				  {
					Unp->SetDestSize(arc.NewLhd.FullUnpSize);
				#ifndef SFX_MODULE
					if (arc.NewLhd.UnpVer<=15)
					  Unp->DoUnpack(15,false);//FileCount>1 && arc.Solid);
					else
				#endif
					  Unp->DoUnpack(arc.NewLhd.UnpVer,(arc.NewLhd.Flags & LHD_SOLID)!=0);
				  }
				  bool ValidCRC;ValidCRC=arc.OldFormat && GET_UINT32(DataIO.UnpFileCRC)==GET_UINT32(arc.NewLhd.FileCRC) ||
				   !arc.OldFormat && GET_UINT32(DataIO.UnpFileCRC)==GET_UINT32(arc.NewLhd.FileCRC^0xffffffff);
				  bool AnySolidDataUnpackedWell,BrokenFile;
				  if ((arc.NewLhd.Flags & LHD_SOLID)==0)
					AnySolidDataUnpackedWell=false; // Reset the flag, because non-solid file is found.
				  else
					if (arc.NewLhd.Method!=0x30 && arc.NewLhd.FullUnpSize>0 && ValidCRC)
					  AnySolidDataUnpackedWell=true;
				 
				  BrokenFile=false;
				  if (!arc.Solid)//(!SkipSolid)
				  {
					if (ValidCRC)
					{
				#ifndef GUI
					  //if (Command!='P' && Command!='I')
					  //  mprintf("%s%s ",Cmd->DisablePercentage ? " ":"\b\b\b\b\b ",St(MOk));
				#endif
					}
					else
					{
					  if ((arc.NewLhd.Flags & LHD_PASSWORD)!=0 && !AnySolidDataUnpackedWell)
					  {
						//Log(arc.FileName,St(MEncrBadCRC),ArcFileName);
					  }
					  else
					  {
						//Log(arc.FileName,St(MCRCFailed),ArcFileName);
					  }
					  BrokenFile=true;
					  ErrHandler.SetErrorCode(RARX_CRC);
				#ifdef RARDLL
					  // If we already have ERAR_EOPEN as result of missing volume,
					  // we should not replace it with less precise ERAR_BAD_DATA.
					  if (Cmd->DllError!=ERAR_EOPEN)
						Cmd->DllError=ERAR_BAD_DATA;
				#endif
					  Alarm();
					}
				  }
				#ifndef GUI
				  //else
				  // mprintf("\b\b\b\b\b     ");
				#endif
				 //if (!TestMode && (Command=='X' || Command=='E') &&
					if(!IsLink(arc.NewLhd.FileAttr))
				  {
				#if defined(_WIN_ALL) || defined(_EMX)
					//if (Cmd->ClearArc)
					  arc.NewLhd.FileAttr&=~FA_ARCH;
				#endif
				  if(p && (!pp))
				  {		if (!BrokenFile)// || Cmd->KeepBroken)
						{
						  if (BrokenFile)
							CurFile.Truncate();
						  CurFile.SetOpenFileTime(
							/*Cmd->xmtime==EXTTIME_NONE ? NULL:*/&arc.NewLhd.mtime,
							/*Cmd->xctime==EXTTIME_NONE ? NULL:*/&arc.NewLhd.ctime,
							/*Cmd->xatime==EXTTIME_NONE ? NULL:*/&arc.NewLhd.atime);
						  CurFile.Close();
				#if defined(_WIN_ALL) && !defined(_WIN_CE) && !defined(SFX_MODULE)
						  if (//Cmd->SetCompressedAttr &&
							  (arc.NewLhd.FileAttr & FILE_ATTRIBUTE_COMPRESSED)!=0 && WinNT())
							SetFileCompression(CurFile.FileName,CurFile.FileNameW,true);
				#endif
						  CurFile.SetCloseFileTime(
							/*Cmd->xmtime==EXTTIME_NONE ? NULL:*/&arc.NewLhd.mtime,
							/*Cmd->xatime==EXTTIME_NONE ? NULL:*/&arc.NewLhd.atime);
						  //if (!Cmd->IgnoreGeneralAttr)
							SetFileAttr(CurFile.FileName,CurFile.FileNameW,arc.NewLhd.FileAttr);
						  PrevExtracted=true;
						}
						if(!bDir)
							goto End;
			  }	  }
              break;
#ifndef SFX_MODULE
            case SUB_HEAD:
              break;
#endif
            case NEWSUB_HEAD:
              {
              }
              break;
          }
          arc.SeekToNext();
	}	}
End:
	arc.Close();
	delete Unp;
	return TRUE;
}

__declspec (dllexport) BOOL UnpackToMem$20(HWND prntDlg,PluginObj *plg,
										   LPVOID dest,int *destSz,
										   wchar_t *arjDirAndNameW)
{
//char as[MAX_PATH];
wchar_t s[MAX_PATH];char ch[MAX_PATH];
int iTryEnum = 0;DWORD szHigh=0;BOOL bExst=FALSE;
unsigned __int64 mySz=0,arcFileLength=0;

	ComprDataIO DataIO;
	Unpack *Unp=new Unpack(&DataIO);
	Unp->Init();

	Archive arc(NULL);
	arc.RemoveSequentialFlag();
	arc.WOpen(NULL,plg->unrarFileName);

	*((DWORD*)&arcFileLength)=GetFileSize(arc.GetHandle(),&szHigh);
	arcFileLength += (int)(szHigh << 32);

TryWithPswrd:
    if(arc.IsArchive(true))
    {	if(arc.GetFailedHeaderDecryption())
		{	if(plg->password[0])
			{	if(0==iTryEnum)
					iTryEnum = 1;
				arc.GetRAROptions()->Password.Set(plg->password);
				goto Nxt;
			}
			else if(opt.password[0])
			{	iTryEnum = 3;
				arc.GetRAROptions()->Password.Set(opt.password);
				goto Nxt;
			}
			else if(arc.HeaderCRC!=arc.NewMhd.HeadCRC)
			{Ask:	
				wchar_t s[MAX_PATH];GetModuleFileName(NULL,s,MAX_PATH);
				HMODULE hm;wchar_t *p=wcsrchr(s,'\\');if(p)
#ifdef _WIN64
				{	wcscpy(p+1,L"MyShell64.dll");
					hm=LoadLibrary(s);
				}else hm=LoadLibrary(L"MyShell64.dll");
#else
				{	wcscpy(p+1,L"MyShell.dll");
					hm=LoadLibrary(s);
				}else hm=LoadLibrary(L"MyShell.dll");
#endif
				if(!hm)
				{arc.Close();
				 delete Unp;
				 return FALSE;
				}
			    if(1==DialogBoxParam(hm/*plgnDllInst*/,MAKEINTRESOURCE(IDD_DIALOG_PASSWORD),NULL,AskPasswordDlgProc,(LPARAM)s))
				{	iTryEnum = 2;
					arc.GetRAROptions()->Password.Set(s);
Nxt:				arc.SetFailedHeaderDecryption(false);
					arc.Seek(0,SEEK_SET);
					if(4==iTryEnum)goto Ask;
					iTryEnum = 4;
					goto TryWithPswrd;
				}
				else
				{	arc.Close();
					delete Unp;
				 	return FALSE;
		}	}	}
		else if(2==iTryEnum) MyStringCpy(plg->password,MAX_PATH-1,s);
		else if(3==iTryEnum) MyStringCpy(plg->password,MAX_PATH-1,opt.password);
	
		while(arc.ReadHeader()>0)
        { File CurFile;
		  int HeaderType=arc.GetHeaderType();
          if (HeaderType==ENDARC_HEAD)
            break;
          switch(HeaderType)
          { case FILE_HEAD:;
			  memset(s,0,MAX_PATH*sizeof(wchar_t));
			  if(0==arc.NewLhd.FileNameW[0])
			  	  UtfToWide(arc.NewLhd.FileName,s,arc.NewLhd.NameSize+1);
			  else MyStringCpy(s,MAX_PATH-1,arc.NewLhd.FileNameW);
			  if(FILE_ATTRIBUTE_DIRECTORY!=arc.NewLhd.FileAttr)
			  	bExst = (0==wcscmp(s,arjDirAndNameW));
			  
			  mySz += arc.NewLhd.PackSize;
			  arc.ConvertAttributes();
			  DataIO.UnpArcSize=arc.FileLength();
			  //DataIO.UnpVolume=false;
			  DataIO.UnpVolume=(arc.NewLhd.Flags & LHD_SPLIT_AFTER)!=0;
			  DataIO.NextVolumeMissing=false;
			  arc.Seek(arc.NextBlockPos-arc.NewLhd.FullPackSize,SEEK_SET);

			  DataIO.CurUnpRead=0;
			  DataIO.CurUnpWrite=0;
			  DataIO.UnpFileCRC=arc.OldFormat ? 0 : 0xffffffff;
			  DataIO.PackedCRC=0xffffffff;

			  //if(plg->password[0])
			  {	SecPassword FilePassword;
				FilePassword.Set(plg->password);
				DataIO.SetEncryption(
					(arc.NewLhd.Flags & LHD_PASSWORD)!=0 ? arc.NewLhd.UnpVer:0,&FilePassword,
					(arc.NewLhd.Flags & LHD_SALT)!=0 ? arc.NewLhd.Salt:NULL,false,
					 arc.NewLhd.UnpVer>=36);
			  }
			  DataIO.SetPackedSizeToRead(arc.NewLhd.FullPackSize);
			  DataIO.SetFiles(&arc,&CurFile);
			  DataIO.SetTestMode(true);
			  DataIO.SetSkipUnpCRC(arc.Solid);

			  if(bExst)
			  { if(arc.NewLhd.FullUnpSize>*destSz)
				{	*destSz=arc.NewLhd.FullUnpSize;
					arc.Close();
					delete Unp;
					return FALSE;
				}
				*destSz=arc.NewLhd.FullUnpSize;
				DataIO.SetUnpackToMemory((byte*)dest,*destSz);
			  }
			  bool PrevExtracted,LinkCreateMode;
			  LinkCreateMode=false;//!Cmd->Test && !SkipSolid;
			  PrevExtracted=false;

			  WideToChar(s,ch);

			  if(ExtractLink(DataIO,arc,ch,DataIO.UnpFileCRC,LinkCreateMode))
				PrevExtracted=LinkCreateMode;
			  else
				if ((arc.NewLhd.Flags & LHD_SPLIT_BEFORE)==0)
				  if (arc.NewLhd.Method==0x30)
					UnstoreFile(DataIO,arc.NewLhd.FullUnpSize);
				  else
				  {
					Unp->SetDestSize(arc.NewLhd.FullUnpSize);
				#ifndef SFX_MODULE
					if (arc.NewLhd.UnpVer<=15)
					  Unp->DoUnpack(15,false);//FileCount>1 && arc.Solid);
					else
				#endif
					  Unp->DoUnpack(arc.NewLhd.UnpVer,(arc.NewLhd.Flags & LHD_SOLID)!=0);
				  }
				  bool ValidCRC;ValidCRC=arc.OldFormat && GET_UINT32(DataIO.UnpFileCRC)==GET_UINT32(arc.NewLhd.FileCRC) ||
				   !arc.OldFormat && GET_UINT32(DataIO.UnpFileCRC)==GET_UINT32(arc.NewLhd.FileCRC^0xffffffff);
				  bool AnySolidDataUnpackedWell,BrokenFile;
				  if ((arc.NewLhd.Flags & LHD_SOLID)==0)
					AnySolidDataUnpackedWell=false; // Reset the flag, because non-solid file is found.
				  else
					if (arc.NewLhd.Method!=0x30 && arc.NewLhd.FullUnpSize>0 && ValidCRC)
					  AnySolidDataUnpackedWell=true;
				 
				  BrokenFile=false;
				  if (!arc.Solid)//(!SkipSolid)
				  {
					if (ValidCRC)
					{
				#ifndef GUI
					  //if (Command!='P' && Command!='I')
					  //  mprintf("%s%s ",Cmd->DisablePercentage ? " ":"\b\b\b\b\b ",St(MOk));
				#endif
					}
					else
					{
					  if ((arc.NewLhd.Flags & LHD_PASSWORD)!=0 && !AnySolidDataUnpackedWell)
					  {
						//Log(arc.FileName,St(MEncrBadCRC),ArcFileName);
					  }
					  else
					  {
						//Log(arc.FileName,St(MCRCFailed),ArcFileName);
					  }
					  BrokenFile=true;
					  ErrHandler.SetErrorCode(RARX_CRC);
				#ifdef RARDLL
					  // If we already have ERAR_EOPEN as result of missing volume,
					  // we should not replace it with less precise ERAR_BAD_DATA.
					  if (Cmd->DllError!=ERAR_EOPEN)
						Cmd->DllError=ERAR_BAD_DATA;
				#endif
					  Alarm();
					}
				  }
				#ifndef GUI
				  //else
				  // mprintf("\b\b\b\b\b     ");
				#endif
				 //if (!TestMode && (Command=='X' || Command=='E') &&
					if(!IsLink(arc.NewLhd.FileAttr))
				  {
				#if defined(_WIN_ALL) || defined(_EMX)
					//if (Cmd->ClearArc)
					  arc.NewLhd.FileAttr&=~FA_ARCH;
				#endif
			  }
              break;
#ifndef SFX_MODULE
            case SUB_HEAD:
              break;
#endif
            case NEWSUB_HEAD:
              {
              }
              break;
          }
          arc.SeekToNext();
	}	}
	arc.Close();
	delete Unp;
	return TRUE;
}

__declspec (dllexport) int GetTotalCryptMethods()
{
	return 1;
}

__declspec (dllexport) const wchar_t* GetCryptDescription$4(int cryptNum)
{
	switch(cryptNum)
	{	case 0:default:
			return L"Sino rar-32 version of crypting code";
	}
	return L"";
}

INT_PTR CALLBACK ExstngActnDlgProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
static HFONT hf=0;
static int hfRef=0;//obshiy hf, dinamik uchun emas:
static HBRUSH br=0;
static HBRUSH brHtBk=0;
static int endDialogCodeToWM_DESTROY;
int width,left,height,top;FILETIME ft;SYSTEMTIME st;
char s[MAX_PATH];LPVOID *pars;//UINT uStyle;
RECT r;HDC dc;//LPDRAWITEMSTRUCT lpdis;
WIN32_FIND_DATA ff;HANDLE h;
UNREFERENCED_PARAMETER(lParam);
	switch (message)
	{
	case WM_INITDIALOG:
		GetWindowRect(hDlg, &r);
		width = r.right - r.left;
		height = r.bottom - r.top;
		left=(GetSystemMetrics(SM_CXSCREEN) - width )/2;
		top =(GetSystemMetrics(SM_CYSCREEN) - height)/2;
		MoveWindow(hDlg, left, top+20, width, height, TRUE);
		SetWindowText(hDlg,strngs[21]);
		SetDlgItemText(hDlg,IDC_STATIC8,strngs[3]);//"Existing file in disk:"
		SetDlgItemText(hDlg,IDC_STATIC5,strngs[4]);//"File in archive:"
		SetDlgItemText(hDlg,IDC_STATIC1,strngs[5]);//"Size in bytes:"
		SetDlgItemText(hDlg,IDC_STATIC3,strngs[5]);//"Size in bytes:"
		SetDlgItemText(hDlg,IDC_STATIC2,strngs[6]);//"Write time:"
		SetDlgItemText(hDlg,IDC_STATIC4,strngs[6]);//"Write time:"
		SetDlgItemText(hDlg,IDC_STATIC7,strngs[7]);//"Size in bytes:"
		SetDlgItemText(hDlg,IDC_STATIC6,strngs[8]);//"Rename"
		SetDlgItemText(hDlg,IDC_CHECK_OVERWRITE_LATEST_AUTO,strngs[22]);//"Overwrite latest in future"
		SetDlgItemText(hDlg,IDC_CHECK_OVERWRITE_OLDEST_AUTO,strngs[9]);//"Overwrite oldest in future"
		SetDlgItemText(hDlg,IDC_CHECK_OVERWRITE_BIGGEST_AUTO,strngs[10]);//"Overwrite biggest in future"
		SetDlgItemText(hDlg,IDC_CHECK_RENAME_AUTO,strngs[11]);//"Auto rename in future"
		SetDlgItemText(hDlg,IDC_CHECK_SKIP_AUTO,strngs[12]);//"Skip in future"		 
		SetDlgItemText(hDlg,IDC_CHECK_OVERWRITE_AUTO,strngs[13]);//"Overwrite in future"		 
		SetDlgItemText(hDlg,IDC_CHECK_OVERWRITE_BIGGEST_AUTO2,strngs[14]);//"Overwrite littlest in future"
		SetDlgItemText(hDlg,IDC_BUTTON_OVERWRITE_LATEST,strngs[15]);//"Overwrite latest"
		SetDlgItemText(hDlg,IDC_BUTTON_OVERWRITE_OLDEST,strngs[16]);//"Overwrite oldest"
		SetDlgItemText(hDlg,IDC_BUTTON_OVERWRITE_BIGGEST,strngs[17]);//"Overwrite biggest"
		SetDlgItemText(hDlg,IDC_BUTTON_RENAME,strngs[8]);//"Rename"
		SetDlgItemText(hDlg,IDC_BUTTON_SKIP,strngs[18]);//"Skip"
		SetDlgItemText(hDlg,IDC_BUTTON_OVERWRITE,strngs[19]);//"Overwrite"
		SetDlgItemText(hDlg,IDC_BUTTON_OVERWRITE_LITTLEST,strngs[20]);//"Overwrite littlest"
		SetDlgItemText(hDlg,IDCANCEL,strngs[1]);//"Cancel"
		pars=(LPVOID*)lParam;
		SetDlgItemTextA(hDlg,IDC_EDIT_EXST_NAME,(char*)pars[0]);
		SetDlgItemTextA(hDlg,IDC_EDIT_INZIP_NAME,(char*)pars[1]);
		StringCchPrintfA(s,MAX_PATH-1,"%d",(unsigned __int64)(((WIN32_FIND_DATA*)pars[2])->nFileSizeHigh) << 32 | 
										  ((WIN32_FIND_DATA*)pars[2])->nFileSizeLow);
		SetDlgItemTextA(hDlg,IDC_EDIT_INZIP_SIZE,s);
		if(FileTimeToLocalFileTime(&((WIN32_FIND_DATA*)pars[2])->ftCreationTime,&ft) != 0)
		{	if(FileTimeToSystemTime(&ft, &st) != 0)
			{	StringCchPrintfA(s,MAX_PATH-1,"%d.%d.%d  %d:%d:%d",
								st.wDay,st.wMonth,st.wYear,
								st.wHour,st.wMinute,st.wSecond);
				SetDlgItemTextA(hDlg,IDC_EDIT_INZIP_WR_TIME,s);
		}	}

		h = MyFindFirstFileEx((LPCTSTR)pars[0],FindExInfoStandard,&ff,FindExSearchLimitToDirectories,NULL,0);
		if(INVALID_HANDLE_VALUE!=h)
		{	FindClose(h);
			if(!(FILE_ATTRIBUTE_DIRECTORY & ff.dwFileAttributes))
			{	StringCchPrintfA(s,MAX_PATH-1,"%d",(unsigned __int64)(ff.nFileSizeHigh) << 32 | ff.nFileSizeLow);
				SetDlgItemTextA(hDlg,IDC_EDIT_EXST_SIZE,s);
				if(FileTimeToLocalFileTime(&ff.ftCreationTime,&ft) != 0)
				{	if(FileTimeToSystemTime(&ft, &st) != 0)
					{	StringCchPrintfA(s,MAX_PATH-1,"%d.%d.%d  %d:%d:%d",
										st.wDay,st.wMonth,st.wYear,
										st.wHour,st.wMinute,st.wSecond);
						SetDlgItemTextA(hDlg,IDC_EDIT_EXST_WR_TIME,s);
		}	}	}	}
		SendMessage(hDlg,WM_USER+1,0,0);
		return TRUE;
	case WM_USER+1://hf obshiy uchun, dinamik o'zgartirish uchun emas:
		if(0==hfRef)
		{	LOGFONT lf;InitLOGFONT(&lf);
			hf = CreateFontIndirect(&lf);
			br = CreateSolidBrush(RGB(0x40,0x21,0x17));//0xc9,0x81,0x93));
			brHtBk = CreateSolidBrush(RGB(0x64,0x79,0x65));
		}
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_EXST_NAME),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_EXST_SIZE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_EXST_WR_TIME),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_INZIP_NAME),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_INZIP_SIZE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_INZIP_WR_TIME),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_RENAME),WM_SETFONT,(WPARAM)hf,TRUE);

		SendMessage(GetDlgItem(hDlg,IDC_STATIC8),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_STATIC5),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_STATIC1),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_STATIC3),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_STATIC2),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_STATIC4),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_STATIC7),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_STATIC6),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_OVERWRITE_LATEST_AUTO),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_OVERWRITE_OLDEST_AUTO),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_OVERWRITE_BIGGEST_AUTO),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_RENAME_AUTO),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_SKIP_AUTO),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_OVERWRITE_AUTO),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_OVERWRITE_BIGGEST_AUTO2),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_BUTTON_OVERWRITE_LATEST),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_BUTTON_OVERWRITE_OLDEST),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_BUTTON_OVERWRITE_BIGGEST),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_BUTTON_RENAME),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_BUTTON_SKIP),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_BUTTON_OVERWRITE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_BUTTON_OVERWRITE_LITTLEST),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDCANCEL),WM_SETFONT,(WPARAM)hf,TRUE);
		++hfRef;
		return TRUE;
	case WM_CTLCOLORSTATIC:
	case WM_CTLCOLORDLG:dc = (HDC)wParam;
		SetTextColor(dc,RGB(0xea,0xe0,0xff));
		SetBkColor(dc,RGB(0x40,0x21,0x17));
		return (INT_PTR)br;
	case WM_CTLCOLOREDIT:dc = (HDC)wParam;
		SetTextColor(dc,RGB(0xea,0xe0,0xff));
		SetBkColor(dc,RGB(0x40,0x21,0x17));
		return (INT_PTR)br;
	case WM_CTLCOLORBTN:dc=(HDC)wParam;
		SetTextColor(dc,RGB(0xd0,0xe0,0xff));
		SetBkColor(dc,RGB(0x64,0x79,0x65));
		return (INT_PTR)brHtBk;
/*	case WM_DRAWITEM:
		lpdis = (LPDRAWITEMSTRUCT)lParam;
		GetWindowTextA(lpdis->hwndItem,s,64);
		uStyle = DFCS_BUTTONPUSH;
		r = lpdis->rcItem;
		if(lpdis->itemState & ODS_SELECTED)
		{	uStyle |= DFCS_PUSHED|DFCS_TRANSPARENT;
			r.left+=2;r.top+=2;
		}
		DrawFrameControl(lpdis->hDC, &lpdis->rcItem, DFC_BUTTON, uStyle);
		if(lpdis->itemState & ODS_SELECTED)
			{r.left+=1;r.top+=1;r.bottom-=2;r.right-=3;}
		else
			{r.left+=1;r.top+=2;r.bottom-=3;r.right-=3;}
		FillRect(lpdis->hDC,&r,brHtBk);//DrawText(lpdis->hDC,"                                                  ",50,&rc,DT_SINGLELINE|DT_VCENTER|DT_INTERNAL|DT_LEFT);
		if(lpdis->itemState & ODS_SELECTED)
			{r.left-=1;r.top-=1;r.bottom+=3;r.right+=3;}
		else
			{r.left-=1;r.top-=2;r.bottom+=2;r.right+=3;}
		DrawTextA(lpdis->hDC,s,MyStringLengthA(s,64),&r,DT_SINGLELINE|DT_VCENTER|DT_CENTER);
		return TRUE;*/
	case WM_DESTROY:
		if(--hfRef<1)
		{	DeleteObject(hf);
			DeleteObject(br);
			DeleteObject(brHtBk);
		}
		return 0;
	case WM_COMMAND://int r;
		switch(LOWORD(wParam))
		{	case IDC_BUTTON_OVERWRITE_LATEST:		
				EndDialog(hDlg,(BST_CHECKED!=SendMessage(GetDlgItem(hDlg,
												IDC_CHECK_OVERWRITE_LATEST_AUTO),BM_GETCHECK,0,0))?1:11);
				return (INT_PTR)TRUE;
			case IDC_BUTTON_OVERWRITE_OLDEST:
				EndDialog(hDlg,(BST_CHECKED!=SendMessage(GetDlgItem(hDlg,
												IDC_CHECK_OVERWRITE_OLDEST_AUTO),BM_GETCHECK,0,0))?2:12);
				return (INT_PTR)TRUE;
			case IDC_BUTTON_OVERWRITE_BIGGEST:
				EndDialog(hDlg,(BST_CHECKED!=SendMessage(GetDlgItem(hDlg,
												IDC_CHECK_OVERWRITE_BIGGEST_AUTO),BM_GETCHECK,0,0))?3:13);
				return (INT_PTR)TRUE;				
			case IDC_BUTTON_RENAME:
				EndDialog(hDlg,(BST_CHECKED!=SendMessage(GetDlgItem(hDlg,
												IDC_CHECK_RENAME_AUTO),BM_GETCHECK,0,0))?4:14);
				return (INT_PTR)TRUE;				
			case IDC_BUTTON_SKIP:
				EndDialog(hDlg,(BST_CHECKED!=SendMessage(GetDlgItem(hDlg,
												IDC_CHECK_SKIP_AUTO),BM_GETCHECK,0,0))?5:15);
				return (INT_PTR)TRUE;				
			case IDC_BUTTON_OVERWRITE:
				EndDialog(hDlg,(BST_CHECKED!=SendMessage(GetDlgItem(hDlg,
												IDC_CHECK_OVERWRITE_AUTO),BM_GETCHECK,0,0))?6:16);
				return (INT_PTR)TRUE;				
			case IDC_BUTTON_OVERWRITE_LITTLEST:
				EndDialog(hDlg,(BST_CHECKED!=SendMessage(GetDlgItem(hDlg,
												IDC_BUTTON_OVERWRITE_LITTLEST),BM_GETCHECK,0,0))?7:17);
				return (INT_PTR)TRUE;				
			case IDCANCEL:
				EndDialog(hDlg, -1);
				return (INT_PTR)TRUE;
		}
		break;
	}
	return (INT_PTR)FALSE;
}

INT_PTR CALLBACK AskPasswordDlgProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
static HFONT hf=0;
static int hfRef=0;//obshiy hf, dinamik uchun emas:
static HBRUSH br=0;
static HBRUSH brHtBk=0;
int width,left,height,top;
//char s[MAX_PATH];//UINT uStyle;
RECT r;HDC dc;//LPDRAWITEMSTRUCT lpdis;
UNREFERENCED_PARAMETER(lParam);
	switch (message)
	{
	case WM_INITDIALOG:
		GetWindowRect(hDlg, &r);
		width = r.right - r.left;
		height = r.bottom - r.top;
		left=(GetSystemMetrics(SM_CXSCREEN) - width )/2;
		top =(GetSystemMetrics(SM_CYSCREEN) - height)/2;
		MoveWindow(hDlg, left, top+20, width, height, TRUE);
		SetWindowText(hDlg,strngs[24]);
		SetDlgItemText(hDlg,IDC_STATIC1,strngs[25]);//"Existing file in disk:"
		SetWindowLongPtr(hDlg,GWLP_USERDATA,lParam);//SetWindowLong(hDlg,GWL_USERDATA,lParam);
		SendMessage(hDlg,WM_USER+1,0,0);
		return TRUE;
	case WM_USER+1://hf obshiy uchun, dinamik o'zgartirish uchun emas:
		if(0==hfRef)
		{	LOGFONT lf;InitLOGFONT(&lf);
			hf = CreateFontIndirect(&lf);
			br = CreateSolidBrush(RGB(0x40,0x21,0x17));//0xc9,0x81,0x93));
			brHtBk = CreateSolidBrush(RGB(0x64,0x79,0x65));
		}
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_EXST_NAME),WM_SETFONT,(WPARAM)hf,TRUE);
		++hfRef;
		return TRUE;
	case WM_CTLCOLORSTATIC:
	case WM_CTLCOLORDLG:dc = (HDC)wParam;
		SetTextColor(dc,RGB(0xea,0xe0,0xff));
		SetBkColor(dc,RGB(0x40,0x21,0x17));
		return (INT_PTR)br;
	case WM_CTLCOLOREDIT:dc = (HDC)wParam;
		SetTextColor(dc,RGB(0xea,0xe0,0xff));
		SetBkColor(dc,RGB(0x40,0x21,0x17));
		return (INT_PTR)br;
	case WM_CTLCOLORBTN:dc=(HDC)wParam;
		SetTextColor(dc,RGB(0xd0,0xe0,0xff));
		SetBkColor(dc,RGB(0x64,0x79,0x65));
		return (INT_PTR)brHtBk;
/*	case WM_DRAWITEM:
		lpdis = (LPDRAWITEMSTRUCT)lParam;
		GetWindowTextA(lpdis->hwndItem,s,64);
		uStyle = DFCS_BUTTONPUSH;
		r = lpdis->rcItem;
		if(lpdis->itemState & ODS_SELECTED)
		{	uStyle |= DFCS_PUSHED|DFCS_TRANSPARENT;
			r.left+=2;r.top+=2;
		}
		DrawFrameControl(lpdis->hDC, &lpdis->rcItem, DFC_BUTTON, uStyle);
		if(lpdis->itemState & ODS_SELECTED)
			{r.left+=1;r.top+=1;r.bottom-=2;r.right-=3;}
		else
			{r.left+=1;r.top+=2;r.bottom-=3;r.right-=3;}
		FillRect(lpdis->hDC,&r,brHtBk);//DrawText(lpdis->hDC,"                                                  ",50,&rc,DT_SINGLELINE|DT_VCENTER|DT_INTERNAL|DT_LEFT);
		if(lpdis->itemState & ODS_SELECTED)
			{r.left-=1;r.top-=1;r.bottom+=3;r.right+=3;}
		else
			{r.left-=1;r.top-=2;r.bottom+=2;r.right+=3;}
		DrawTextA(lpdis->hDC,s,MyStringLengthA(s,64),&r,DT_SINGLELINE|DT_VCENTER|DT_CENTER);
		return TRUE;*/
	case WM_DESTROY:
		if(--hfRef<1)
		{	DeleteObject(hf);
			DeleteObject(br);
			DeleteObject(brHtBk);
		}
		return 0;
	case WM_COMMAND://int r;
		switch(LOWORD(wParam))
		{	case IDOK:
				EndDialog(hDlg,1);
				GetDlgItemText(hDlg,IDC_EDIT_DATA1,(LPWSTR)GetWindowLongPtr(hDlg,GWLP_USERDATA),MAX_PATH-1);//GetWindowLong(hDlg,GWL_USERDATA),MAX_PATH-1);
				return (INT_PTR)TRUE;				
			case IDCANCEL:
				EndDialog(hDlg, 0);
				return (INT_PTR)TRUE;
		}
		break;
	}
	return (INT_PTR)FALSE;
}

void UnstoreFile(ComprDataIO &DataIO,int64 DestUnpSize)
{
  Array<byte> Buffer(0x10000);
  while (1)
  {
    uint Code=DataIO.UnpRead(&Buffer[0],Buffer.Size());
    if (Code==0 || (int)Code==-1)
      break;
    Code=Code<DestUnpSize ? Code:(uint)DestUnpSize;
    DataIO.UnpWrite(&Buffer[0],Code);
    if (DestUnpSize>=0)
      DestUnpSize-=Code;
  }
}

}//extern "C"