#define _CRT_SECURE_NO_WARNINGS

#pragma warning (disable:4995)
#pragma warning (disable:4047)
#pragma warning (disable:4024)

#include "windows.h"
#include "stdio.h"
#include "strsafe.h"
#include "Plugins_C.h"

#define MAX_STRINGS 82

OPT opt={L"",L"",0};
wchar_t **strngs=NULL;
HMODULE plgnDllInst;
int		plgId=0;

extern void saveOpt();
extern void FreeFindData();


BOOL APIENTRY DllMain(HMODULE hModule,DWORD ul_reason_for_call,LPVOID lpReserved)
{
FILE *f;
int i,l;
wchar_t *pend;
wchar_t dllname[260],mnuStr[64];
	switch(ul_reason_for_call)
	{	case DLL_PROCESS_ATTACH:
			plgnDllInst=hModule;
			if(strngs)break;
			strngs = (wchar_t **)malloc(MAX_STRINGS*sizeof(wchar_t*));
#ifdef _DEBUG
			GetModuleFileName(hModule,dllname,260);//GetModuleHandle("Chm32dbg.dll")
#else
			GetModuleFileName(hModule,dllname,260);//GetModuleHandle("Chm32rel.dll")
#endif
			pend = wcsrchr(dllname,'\\');
			if(pend){*pend++='\\';*pend=0;}

			if(GetEnvironmentVariableW(L"languge",mnuStr,64))//Language instartup qo'yadur;
			{	if(!wcscmp(mnuStr,L"russian"))
					wcscat_s(dllname,260,L"PlgRarStrsRus.txt");
				else if(!wcscmp(mnuStr,L"uzbekl"))
					wcscat_s(dllname,260,L"PlgRarStrsUZBL.txt");
				else if(!wcscmp(mnuStr,L"uzbekk"))
					wcscat_s(dllname,260,L"PlgRarStrsUZBK.txt");
				else//if(wcscmp(mnuStr,L"Exit")
					wcscat_s(dllname,260,L"PlgRarStrsEng.txt");
			}	
			else wcscat_s(dllname,260,L"PlgRarStrsEng.txt");

			f=_wfopen(dllname,L"r,ccs=UNICODE");
			if(f)
			{	wchar_t s[260];fwscanf(f,L"%s", s);
				if(wcscmp(s,L"Plugin")) goto NillStr;
				fwscanf(f,L"%s", s);
				if(wcscmp(s,L"rar32.dll")) goto NillStr;
				fwscanf(f,L"%s", s);
				if(wcscmp(s,L"Strings:")) goto NillStr;
				for(i=0; i<MAX_STRINGS; i++)
				{	int t;fwscanf_s(f,L"%d", &t);
					if(t-1!=i) goto NillStr;
					//l=fscanf(f,"%s", s);
					l=fscanLineString(f,256,s);
					strngs[i]=(wchar_t*)malloc(sizeof(wchar_t)*(l+1));
					memcpy(strngs[i],s,sizeof(wchar_t)*(l+1));
				}
				fclose(f);
			}
			else
			{
NillStr:
				l=(int)wcslen(L"rar")+1;
					strngs[0]=(wchar_t*)malloc(sizeof(wchar_t)*l);MyStringCpy(strngs[0],l,L"rar");
				l=(int)wcslen(L"Cancel")+1;
					strngs[1]=(wchar_t*)malloc(sizeof(wchar_t)*l);MyStringCpy(strngs[1],l,L"Cancel");
				l=(int)wcslen(L"Error allocate memory for OpenForUnpacking")+1;
					strngs[2]=(wchar_t*)malloc(sizeof(wchar_t)*l);MyStringCpy(strngs[2],l,L"Error allocate memory for OpenForUnpacking");
				l=(int)wcslen(L"Existing file in disk:")+1;
					strngs[3]=(wchar_t*)malloc(sizeof(wchar_t)*l);MyStringCpy(strngs[3],l,L"Existing file in disk:");
				l=(int)wcslen(L"File in archive:")+1;
					strngs[4]=(wchar_t*)malloc(sizeof(wchar_t)*l);MyStringCpy(strngs[4],l,L"File in archive:");
				l=(int)wcslen(L"Size in bytes:")+1;
					strngs[5]=(wchar_t*)malloc(sizeof(wchar_t)*l);MyStringCpy(strngs[5],l,L"Size in bytes:");
				l=(int)wcslen(L"Write time:")+1;
					strngs[6]=(wchar_t*)malloc(sizeof(wchar_t)*l);MyStringCpy(strngs[6],l,L"Write time:");
				l=(int)wcslen(L"------------------------------------------------- Choise next action: --------------------------------------------------")+1;
					strngs[7]=(wchar_t*)malloc(sizeof(wchar_t)*l);MyStringCpy(strngs[7],l,L"------------------------------------------------- Choise next action: --------------------------------------------------");
				l=(int)wcslen(L"Rename")+1;
					strngs[8]=(wchar_t*)malloc(sizeof(wchar_t)*l);MyStringCpy(strngs[8],l,L"Rename");
				l=(int)wcslen(L"Overwrite oldest in future")+1;
					strngs[9]=(wchar_t*)malloc(sizeof(wchar_t)*l);MyStringCpy(strngs[9],l,L"Overwrite oldest in future");
				l=(int)wcslen(L"Overwrite biggest in future")+1;
					strngs[10]=(wchar_t*)malloc(sizeof(wchar_t)*l);MyStringCpy(strngs[10],l,L"Overwrite biggest in future");
				l=(int)wcslen(L"Auto rename in future")+1;
					strngs[11]=(wchar_t*)malloc(sizeof(wchar_t)*l);MyStringCpy(strngs[11],l,L"Auto rename in future");					
				l=(int)wcslen(L"Skip in future")+1;
					strngs[12]=(wchar_t*)malloc(sizeof(wchar_t)*l);MyStringCpy(strngs[12],l,L"Skip in future");
				l=(int)wcslen(L"Overwrite in future")+1;
					strngs[13]=(wchar_t*)malloc(sizeof(wchar_t)*l);MyStringCpy(strngs[13],l,L"Overwrite in future");
				l=(int)wcslen(L"Overwrite littlest in future")+1;
					strngs[14]=(wchar_t*)malloc(sizeof(wchar_t)*l);MyStringCpy(strngs[14],l,L"Overwrite littlest in future");
				l=(int)wcslen(L"Overwrite latest")+1;
					strngs[15]=(wchar_t*)malloc(sizeof(wchar_t)*l);MyStringCpy(strngs[15],l,L"Overwrite latest");				
				l=(int)wcslen(L"Overwrite oldest")+1;
					strngs[16]=(wchar_t*)malloc(sizeof(wchar_t)*l);MyStringCpy(strngs[16],l,L"Overwrite oldest");				
				l=(int)wcslen(L"Overwrite biggest")+1;
					strngs[17]=(wchar_t*)malloc(sizeof(wchar_t)*l);MyStringCpy(strngs[17],l,L"Overwrite biggest");				
				l=(int)wcslen(L"Skip")+1;
					strngs[18]=(wchar_t*)malloc(sizeof(wchar_t)*l);MyStringCpy(strngs[18],l,L"Skip");				
				l=(int)wcslen(L"Overwrite")+1;
					strngs[19]=(wchar_t*)malloc(sizeof(wchar_t)*l);MyStringCpy(strngs[19],l,L"Overwrite");
				l=(int)wcslen(L"Overwrite littlest")+1;
					strngs[20]=(wchar_t*)malloc(sizeof(wchar_t)*l);MyStringCpy(strngs[20],l,L"Overwrite littlest");
				l=(int)wcslen(L"This file already exist in disk ...")+1;
					strngs[21]=(wchar_t*)malloc(sizeof(wchar_t)*l);MyStringCpy(strngs[21],l,L"This file already exist in disk ...");
				l=(int)wcslen(L"Overwrite latest in future")+1;
					strngs[22]=(wchar_t*)malloc(sizeof(wchar_t)*l);MyStringCpy(strngs[22],l,L"Overwrite latest in future");
				l=(int)wcslen(L"Sino rar-plugin version 1.1")+1;
					strngs[23]=(wchar_t*)malloc(sizeof(wchar_t)*l);MyStringCpy(strngs[23],l,L"Sino rar-plugin version 1.1");
				l=(int)wcslen(L"Archive encrypted !!!")+1;
					strngs[24]=(wchar_t*)malloc(sizeof(wchar_t)*l);MyStringCpy(strngs[24],l,L"Archive encrypted !!!");
				l=(int)wcslen(L"Please,enter password.")+1;
					strngs[25]=(wchar_t*)malloc(sizeof(wchar_t)*l);MyStringCpy(strngs[25],l,L"Please,enter password.");
				l=(int)wcslen(L"Sino-rar archiver option.")+1;
					strngs[26]=(wchar_t*)malloc(sizeof(wchar_t)*l);MyStringCpy(strngs[26],l,L"Sino-rar archiver option.");
				l=(int)wcslen(L"Sino authors don't have lisense for rar prosecc packing.So you may allocate rar-archiver personally.")+1;
					strngs[27]=(wchar_t*)malloc(sizeof(wchar_t)*l);MyStringCpy(strngs[27],l,L"Sino authors don't have lisense for rar prosecc packing.So you may allocate rar-archiver personally.");
				l=(int)wcslen(L"Use WinRar.exe version.")+1;
					strngs[28]=(wchar_t*)malloc(sizeof(wchar_t)*l);MyStringCpy(strngs[28],l,L"Use WinRar.exe version.");
				l=(int)wcslen(L"Use console Rar.exe version.")+1;
					strngs[29]=(wchar_t*)malloc(sizeof(wchar_t)*l);MyStringCpy(strngs[29],l,L"Use console Rar.exe version.");
				l=(int)wcslen(L"Browse")+1;
					strngs[30]=(wchar_t*)malloc(sizeof(wchar_t)*l);MyStringCpy(strngs[30],l,L"Browse");
				l=(int)wcslen(L"Unrar software license:")+1;
					strngs[31]=(wchar_t*)malloc(sizeof(wchar_t)*l);MyStringCpy(strngs[31],l,L"Unrar software license:");
				l=(int)wcslen(L"UnRAR - free utility for RAR archives")+1;
					strngs[32]=(wchar_t*)malloc(sizeof(wchar_t)*l);MyStringCpy(strngs[32],l,L"UnRAR - free utility for RAR archives");
				l=(int)wcslen(L"License for use and distribution of FREE portable version")+1;
					strngs[33]=(wchar_t*)malloc(sizeof(wchar_t)*l);MyStringCpy(strngs[33],l,L"License for use and distribution of FREE portable version");
				l=(int)wcslen(L"All copyrights to RAR and the utility UnRAR are exclusively\n owned by the author - Alexander Roshal.")+1;
					strngs[34]=(wchar_t*)malloc(sizeof(wchar_t)*l);MyStringCpy(strngs[34],l,L"All copyrights to RAR and the utility UnRAR are exclusively\n owned by the author - Alexander Roshal.");
				l=(int)wcslen(L"OK")+1;
					strngs[35]=(wchar_t*)malloc(sizeof(wchar_t)*l);MyStringCpy(strngs[35],l,L"OK");
				l=(int)wcslen(L"Not installed")+1;
					strngs[36]=(wchar_t*)malloc(sizeof(wchar_t)*l);MyStringCpy(strngs[36],l,L"Not installed");
				l=(int)wcslen(L"Installed")+1;
					strngs[37]=(wchar_t*)malloc(sizeof(wchar_t)*l);MyStringCpy(strngs[37],l,L"Installed");
				l=(int)wcslen(L"Temporary folder")+1;
					strngs[38]=(wchar_t*)malloc(sizeof(wchar_t)*l);MyStringCpy(strngs[38],l,L"Temporary folder");
				l=(int)wcslen(L"Find files(chm):")+1;
					strngs[39]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[39],l,L"Find files(chm):");
				l=(int)wcslen(L"Archive root path:")+1;
					strngs[40]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[40],l,L"Archive root path:");
				l=(int)wcslen(L"Find for text(separate-';'):")+1;
					strngs[41]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[41],l,L"Find for text(separate-';'):");
				l=(int)wcslen(L"1-byte")+1;
					strngs[42]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[42],l,L"1-byte");
				l=(int)wcslen(L"Upper key sensivity")+1;
					strngs[43]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[43],l,L"Upper key sensivity");
				l=(int)wcslen(L"Find for not contain text(separate-';'):")+1;
					strngs[44]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[44],l,L"Find for not contain text(separate-';'):");
				l=(int)wcslen(L"Start")+1;
					strngs[45]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[45],l,L"Start");
				l=(int)wcslen(L"OK")+1;
					strngs[46]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[46],l,L"OK");
				l=(int)wcslen(L"Cancel")+1;
					strngs[47]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[47],l,L"Cancel");
				l=(int)wcslen(L"Find for alternative name:")+1;
					strngs[48]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[48],l,L"Find for alternative name:");
				l=(int)wcslen(L"Creation date and time before:")+1;
					strngs[49]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[49],l,L"Creation date and time before:");
				l=(int)wcslen(L"Creation date and time after:")+1;
					strngs[50]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[50],l,L"Creation date and time after:");
				l=(int)wcslen(L"Creation date and time between:")+1;
					strngs[51]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[51],l,L"Creation date and time between:");
				l=(int)wcslen(L"Last access date and time before:")+1;
					strngs[52]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[52],l,L"Last access date and time before:");
				l=(int)wcslen(L"Last access date and time after:")+1;
					strngs[53]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[53],l,L"Last access date and time after:");
				l=(int)wcslen(L"Last access date and time between:")+1;
					strngs[54]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[54],l,L"Last access date and time between:");
				l=(int)wcslen(L"Last write date and time before:")+1;
					strngs[55]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[55],l,L"Last write date and time before:");
				l=(int)wcslen(L"Last write date and time after:")+1;
					strngs[56]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[56],l,L"Last write date and time after:");
				l=(int)wcslen(L"Last write date and time between:")+1;
					strngs[57]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[57],l,L"Last write date and time between:");
				l=(int)wcslen(L"File size:")+1;
					strngs[58]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[58],l,L"File size:");
				l=(int)wcslen(L"File attribute:")+1;
					strngs[59]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[59],l,L"File attribute:");
				l=(int)wcslen(L"Archive")+1;
					strngs[60]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[60],l,L"Archive");
				l=(int)wcslen(L"Compressed")+1;
					strngs[61]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[61],l,L"Compressed");
				l=(int)wcslen(L"Device")+1;
					strngs[62]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[62],l,L"Device");
				l=(int)wcslen(L"Directory")+1;
					strngs[63]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[63],l,L"Directory");
				l=(int)wcslen(L"Encrypted")+1;
					strngs[64]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[64],l,L"Encrypted");
				l=(int)wcslen(L"Hidden")+1;
					strngs[65]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[65],l,L"Hidden");
				l=(int)wcslen(L"Normal")+1;
					strngs[66]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[66],l,L"Normal");
				l=(int)wcslen(L"Not indexed")+1;
					strngs[67]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[67],l,L"Not indexed");
				l=(int)wcslen(L"Read only")+1;
					strngs[68]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[68],l,L"Read only");
				l=(int)wcslen(L"Reparse point")+1;
					strngs[69]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[69],l,L"Reparse point");
				l=(int)wcslen(L"Sparse file")+1;
					strngs[70]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[70],l,L"Sparse file");
				l=(int)wcslen(L"System")+1;
					strngs[71]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[71],l,L"System");
				l=(int)wcslen(L"Temporary")+1;
					strngs[72]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[72],l,L"Temporary");
				l=(int)wcslen(L"Virtual")+1;
					strngs[73]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[73],l,L"Virtual");
				l=(int)wcslen(L"Enum subdirectories")+1;
					strngs[74]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[74],l,L"Enum subdirectories");
				l=(int)wcslen(L"Common parameters:")+1;
					strngs[75]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[75],l,L"Common parameters:");
				l=(int)wcslen(L"Size and time parameters:")+1;
					strngs[76]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[76],l,L"Size and time parameters:");
				l=(int)wcslen(L"Binary")+1;
					strngs[77]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[77],l,L"Binary");
				l=(int)wcslen(L"Stop")+1;
					strngs[78]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[78],l,L"Stop");
				l=(int)wcslen(L"Edit")+1;
					strngs[79]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[79],l,L"Edit");					
				l=(int)wcslen(L"View")+1;
					strngs[80]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[80],l,L"View");					
				l=(int)wcslen(L"Filter:")+1;
					strngs[81]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[81],l,L"Filter:");
			}
			break;
		case DLL_THREAD_ATTACH:
			break;
		case DLL_THREAD_DETACH:
			break;
		case DLL_PROCESS_DETACH:
			if(strngs)
			{	for(i=0; i<MAX_STRINGS; i++)
					free(strngs[i]);
				free(strngs);
				//FreeFindData();
				saveOpt();
				strngs=NULL;
			}
			break;
	}
	return TRUE;
}

void msg(HWND prnt,DWORD e,LPWSTR lpszFunction,LPWSTR msg1)
{ 
    // Retrieve the system error message for the last-error code
	int sz;
    wchar_t *lpMsgBuf;
    wchar_t *lpDisplayBuf;
	DWORD dw = (e==(DWORD)(-1))?GetLastError():e;

    if(!FormatMessage(
        FORMAT_MESSAGE_ALLOCATE_BUFFER | 
        FORMAT_MESSAGE_FROM_SYSTEM |
        FORMAT_MESSAGE_IGNORE_INSERTS,
        NULL,
        dw,
        MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
        (LPWSTR) &lpMsgBuf,
        0, NULL ))
	{
		lpMsgBuf=0;
	}

    // Display the error message and exit the process
	sz = 100+(wcslen((LPCWSTR)lpMsgBuf)+wcslen((LPCWSTR)lpszFunction)+40)*sizeof(WCHAR); 
    lpDisplayBuf = (LPVOID)LocalAlloc(LMEM_ZEROINIT, sz); 
    swprintf((LPWSTR)lpDisplayBuf, 
        L"%s failed with error %d: %s", 
        lpszFunction, dw, lpMsgBuf); 
    MessageBox(prnt, (LPCWSTR)lpDisplayBuf, msg1, MB_OK|MB_ICONWARNING|MB_SYSTEMMODAL); 

    LocalFree(lpDisplayBuf);
    LocalFree(lpMsgBuf);
    //ExitProcess(dw); 
}

int MyStringCpySlashA(char* buf, int mx, char* src)
{	register int l=-1;
	while(++l<mx)
	{	if(src[l]=='/')buf[l]='\\';
		else buf[l] = src[l];
		if(!src[l]) break;//('\0'==src[l])
	}
	if(buf[l])//0 bo'lmasa;
	if(l>=mx)
		buf[l] = 0;
	return l;
}

wchar_t* mystrstrW(wchar_t *s1,wchar_t *s2)
{
	for(;*s2;)//*s1 ham bor edi;
	{	if((*s1)==(*s2)) {++s1;++s2;continue;}
		//if('\\'==(*s1) && '/'==(*s2)) {++s1;++s2;continue;}
		//if('/'==(*s1) && '\\'==(*s2)) {++s1;++s2;continue;}
		return ((0==(*s2))?s1:0);
	}
	return s1;
}

wchar_t* mystrstrslashW(wchar_t *s1,wchar_t *s2,wchar_t **pSlash)
{
	*pSlash = s1;
	for(;*s2;)
	{	if('\\'==*s1)*pSlash = s1;;
		if((*s1)==(*s2)) {++s1;++s2;continue;}
		if('\\' == **pSlash)++(*pSlash);
		return ((0==(*s2))?s1:0);
	}
	if('\\' == **pSlash)++(*pSlash);
	return s1;
}

int MyStringCpySlash(wchar_t* buf, int mx, wchar_t* src)
{	register int l=-1;
	while(++l<mx)
	{	if(src[l]=='/')buf[l]='\\';
		else buf[l] = src[l];
		if(!src[l]) break;//('\0'==src[l])
	}
	if(buf[l])//0 bo'lmasa;
	if(l>=mx)
		buf[l] = 0;
	return l;
}

int GetTempDir(wchar_t *s)
{
	if(IsDirExist(opt.tempDir))
		return MyStringCpy(s,MAX_PATH-1,opt.tempDir);
	GetTempPath(MAX_PATH,opt.tempDir);
	return MyStringCpy(s,MAX_PATH-1,opt.tempDir);
}