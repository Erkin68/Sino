#include "shlobj.h"
#include "Plugins_CPP.h"
#include "resource.h"


extern "C" {
extern wchar_t **strngs;
extern HMODULE plgnDllInst;
extern int  plgId;
extern BOOL IsDirExist(wchar_t*);
}

INT_PTR CALLBACK optnDlg(HWND hDlg,UINT message,WPARAM wParam,LPARAM lParam)
{
RECT rc;BOOL r;OPENFILENAMEW ofname;int width,left,height,top;
	UNREFERENCED_PARAMETER(lParam);
	switch(message)
	{
	case WM_INITDIALOG:
		GetWindowRect(hDlg, &rc);
		width = rc.right - rc.left;		
		left = (GetSystemMetrics(SM_CXFULLSCREEN) - width)/2;
		height = rc.bottom - rc.top;
		top = (GetSystemMetrics(SM_CYFULLSCREEN) - height)/2;
		MoveWindow(hDlg, left, top+20, width, height, TRUE);
		//SetWindowPos(hDlg,HWND_TOPMOST,left, top+20, width, height, SWP_SHOWWINDOW);
		SetWindowText(hDlg,strngs[26]);
		SetDlgItemText(hDlg,IDC_STATIC_1,strngs[27]);
		SetDlgItemText(hDlg,IDC_RADIO_WINRAR,strngs[28]);
		SetDlgItemText(hDlg,IDC_RADIO_RAR,strngs[29]);
		SetDlgItemText(hDlg,IDC_RADIO_RAR,strngs[29]);
		SetDlgItemText(hDlg,IDC_BUTTON_WINRAR_BROWSE,strngs[30]);
		SetDlgItemText(hDlg,IDC_BUTTON_WINRAR_BROWSE2,strngs[30]);
		SetDlgItemText(hDlg,IDC_STATIC_2,strngs[31]);
		SetDlgItemText(hDlg,IDC_STATIC_2,strngs[31]);
		SetDlgItemText(hDlg,IDC_STATIC_3,strngs[32]);
		SetDlgItemText(hDlg,IDC_STATIC_4,strngs[33]);
		SetDlgItemText(hDlg,IDC_STATIC_5,strngs[34]);
		SetDlgItemText(hDlg,IDCANCEL,strngs[1]);
		SetDlgItemText(hDlg,IDOK,strngs[35]);
		SetDlgItemText(hDlg,IDC_BUTTON_WINRAR_TEMPORARY_FOLDER,strngs[38]);
		if(IsDirExist(opt.tempDir))
			SetDlgItemText(hDlg,IDC_EDIT_WINRAR_TEMPORARY_FOLDER,opt.tempDir);
		//SendMessageW(GetDlgItem(hDlg,IDC_COMBO_COMPRESS_METHOD),CB_INSERTSTRING,(WPARAM)-1,(LPARAM)L"uncompressed");
		if(readOptions(plgId,&opt,sizeof(opt)))
		{	switch(opt.iType)
			{	case 0:
					SetDlgItemText(hDlg,IDC_EDIT_WINRAR_INFO,strngs[36]);
					SetDlgItemText(hDlg,IDC_EDIT_WINRAR_INFO2,strngs[36]);
					break;
				case 1:
					SetDlgItemText(hDlg,IDC_EDIT_WINRAR_PATH,opt.rarExePath);
					SetDlgItemText(hDlg,IDC_EDIT_WINRAR_INFO,strngs[37]);
					SetDlgItemText(hDlg,IDC_EDIT_WINRAR_INFO2,strngs[36]);
					SendMessage(GetDlgItem(hDlg,IDC_RADIO_WINRAR),BM_SETCHECK,BST_CHECKED,0);
					break;
				case 2:
					SetDlgItemText(hDlg,IDC_EDIT_RAR_PATH,opt.rarExePath);
					SetDlgItemText(hDlg,IDC_EDIT_WINRAR_INFO,strngs[36]);
					SetDlgItemText(hDlg,IDC_EDIT_WINRAR_INFO2,strngs[37]);
					SendMessage(GetDlgItem(hDlg,IDC_RADIO_RAR),BM_SETCHECK,BST_CHECKED,0);
					break;
		}	}
		else
		{	SetDlgItemText(hDlg,IDC_EDIT_WINRAR_INFO,strngs[36]);
			SetDlgItemText(hDlg,IDC_EDIT_WINRAR_INFO2,strngs[36]);
		}
		return TRUE;
	case WM_COMMAND:
		switch(LOWORD(wParam))
		{	case IDC_RADIO_WINRAR: r = (BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_RADIO_WINRAR),BM_GETCHECK,0,0));
				EnableWindow(GetDlgItem(hDlg,IDC_EDIT_WINRAR_PATH),r);
				EnableWindow(GetDlgItem(hDlg,IDC_BUTTON_WINRAR_BROWSE),r);
				EnableWindow(GetDlgItem(hDlg,IDC_EDIT_RAR_PATH),!r);
				EnableWindow(GetDlgItem(hDlg,IDC_BUTTON_WINRAR_BROWSE2),!r);
				SetDlgItemText(hDlg,IDC_EDIT_WINRAR_INFO,r?strngs[36]:strngs[37]);
				SetDlgItemText(hDlg,IDC_EDIT_WINRAR_INFO2,r?strngs[37]:strngs[36]);
				return (INT_PTR)TRUE;
			case IDC_RADIO_RAR: r = (BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_RADIO_RAR),BM_GETCHECK,0,0));
				EnableWindow(GetDlgItem(hDlg,IDC_EDIT_WINRAR_PATH),!r);
				EnableWindow(GetDlgItem(hDlg,IDC_BUTTON_WINRAR_BROWSE),!r);
				EnableWindow(GetDlgItem(hDlg,IDC_EDIT_RAR_PATH),r);
				EnableWindow(GetDlgItem(hDlg,IDC_BUTTON_WINRAR_BROWSE2),r);
				SetDlgItemText(hDlg,IDC_EDIT_WINRAR_INFO,r?strngs[37]:strngs[36]);
				SetDlgItemText(hDlg,IDC_EDIT_WINRAR_INFO2,r?strngs[36]:strngs[37]);
				return (INT_PTR)TRUE;
			case IDC_BUTTON_WINRAR_BROWSE:
				ofname.lpstrFilter = L"exe";
				ofname.lpstrTitle = L"Search for WinRar.exe";
				ofname.lpstrDefExt = L"exe";
				ofname.lStructSize = sizeof(ofname);
				ofname.hwndOwner = hDlg;
				ofname.hInstance = plgnDllInst;
				ofname.lpstrCustomFilter = NULL;
				ofname.nMaxCustFilter = 0;
				ofname.nFilterIndex = 1;
				ofname.lpstrFile = opt.rarExePath;
				ofname.nMaxFile = MAX_PATH;
				ofname.lpstrFileTitle = NULL;
				ofname.nMaxFileTitle = 0;
				ofname.lpstrInitialDir = NULL;
				ofname.Flags = OFN_EXPLORER | OFN_FILEMUSTEXIST;
				ofname.lCustData = NULL;
				ofname.lpfnHook = NULL;
				ofname.lpTemplateName = NULL;
				if(GetOpenFileName(&ofname))
				{	SetDlgItemText(hDlg,IDC_EDIT_WINRAR_PATH,opt.rarExePath);
					opt.iType = 1;
				}
				else opt.iType = 0;
				return (INT_PTR)TRUE;
			case IDC_BUTTON_WINRAR_BROWSE2:
				ofname.lpstrFilter = L"exe";
				ofname.lpstrTitle = L"Search for Rar.exe";
				ofname.lpstrDefExt = L"exe";
				ofname.lStructSize = sizeof(ofname);
				ofname.hwndOwner = hDlg;
				ofname.hInstance = plgnDllInst;
				ofname.lpstrCustomFilter = NULL;
				ofname.nMaxCustFilter = 0;
				ofname.nFilterIndex = 1;
				ofname.lpstrFile = opt.rarExePath;
				ofname.nMaxFile = MAX_PATH;
				ofname.lpstrFileTitle = NULL;
				ofname.nMaxFileTitle = 0;
				ofname.lpstrInitialDir = NULL;
				ofname.Flags = OFN_EXPLORER | OFN_FILEMUSTEXIST;
				ofname.lCustData = NULL;
				ofname.lpfnHook = NULL;
				ofname.lpTemplateName = NULL;
				if(GetOpenFileName(&ofname))
				{	SetDlgItemText(hDlg,IDC_EDIT_WINRAR_PATH,opt.rarExePath);
					opt.iType = 2;
				}
				else opt.iType = 0;
				return (INT_PTR)TRUE;
			case IDC_BUTTON_WINRAR_TEMPORARY_FOLDER:
				BROWSEINFO bi; 
				bi.hwndOwner = hDlg;
				bi.pszDisplayName = opt.tempDir;
				bi.lpszTitle = L"Get temporary folder for rar ...";
				bi.ulFlags = BIF_NONEWFOLDERBUTTON|BIF_DONTGOBELOWDOMAIN|BIF_NEWDIALOGSTYLE|
					BIF_NOTRANSLATETARGETS|BIF_RETURNFSANCESTORS;
				bi.lpfn = NULL;
				LPITEMIDLIST pidlRoot;pidlRoot = NULL;
				bi.pidlRoot = pidlRoot;
				LPITEMIDLIST pidlSelected;pidlSelected = SHBrowseForFolder(&bi);
				if(pidlRoot)
					CoTaskMemFree(pidlRoot);
				if(pidlSelected)
				{	SHGetPathFromIDList(pidlSelected,opt.tempDir);
					SetDlgItemText(hDlg,IDC_EDIT_WINRAR_TEMPORARY_FOLDER,opt.tempDir);
					CoTaskMemFree(pidlSelected);
				}
				return (INT_PTR)TRUE;
			case IDOK:
				saveOptions(plgId,&opt,sizeof(OPT));
				EndDialog(hDlg,0);
				return (INT_PTR)TRUE;
			case IDCANCEL:
				EndDialog(hDlg,0);
				return (INT_PTR)TRUE;
		}
		break;
	}
	return (INT_PTR)FALSE;
}

extern "C" {
__declspec (dllexport) VOID ShowOptionDialog(HWND prnt)
{
	int r = (int)DialogBox(plgnDllInst,MAKEINTRESOURCE(IDD_DIALOG_OPTIONS),prnt,optnDlg);
}}
