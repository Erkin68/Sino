#include "Plugins_CPP.h"
#include "resource.h"
#include "..\..\..\Operations\MyShell\MyShell.h"



extern INT_PTR CALLBACK optnDlg(HWND,UINT,WPARAM,LPARAM);


extern "C"
{

extern wchar_t **strngs;
extern HMODULE plgnDllInst;
extern int  plgId;
extern int	MyStringCpySlashA(char*,int,char*);
extern wchar_t* mystrstrW(wchar_t*,wchar_t*);
extern wchar_t* mystrstrslashW(wchar_t*,wchar_t*,wchar_t**);
extern void msg(HWND,DWORD,LPWSTR,LPWSTR);
extern BOOL WriteFromList(PluginObj*);


/*BOOL FindAndExcludeCrntFolder(wchar_t *addLstFileName,wchar_t *crntFolder)
{
	wchar_t *p,*pp,s[MAX_PATH];
FILE *f=_wfopen(addLstFileName,L"r+");
	if(!f)return FALSE;
	crntFolder[0]=0;
	do
	{	fwscanf(f,L"%s",&s[0]);
		if(!crntFolder[0])
		{	MyStringCpy(crntFolder,MAX_PATH-1,s);
			p = wcsrchr(crntFolder,'\\');
			if(p)*p=0;
		}
		else
		{	for(p=&crntFolder[0],pp=&s[0]; *p && *pp;)
			{	if(*p != *pp)
				{	*p = 0;
					break;	
				}
				++p;++pp;
	}	}	} while(!feof(f));
	fclose(f);
	return TRUE;
}*/

BOOL WriteFromList(PluginObj *plg)
{
wchar_t s[2*MAX_PATH];int l=0;
	fclose(plg->fAddLstFile);//FindAndExcludeCrntFolder(plg->addLstFileName,crntFolder);
	//fclose(plg->fDelLstFile);
	while(!opt.iType)
	{	if(!DialogBox(plgnDllInst,MAKEINTRESOURCE(IDD_DIALOG_OPTIONS),NULL,optnDlg))
			return FALSE;
	}
	if(!IsFileExist(opt.rarExePath)){opt.iType=0;return FALSE;}
	//l=MyStringCpy(s,2*MAX_PATH-1,L"WinRar.exe");
	s[l++]=' ';s[l++]='a';//CreateProcess commandLine i uchun 1- simvoli - probel bo'lishi shart;



	if(plg->bExcludePath)
	{s[l++]=' ';s[l++]='-';s[l++]='e';s[l++]='p';}

	if(plg->compressLevel>-1)
	{	s[l++]=' ';s[l++]='-';s[l++]='m';
		switch(plg->compressLevel)
		{	case 0:	s[l++]='0'; break;
			case 1:case 2: s[l++]='1'; break;
			case 3:case 4: s[l++]='2'; break;
			case 5:case 6: s[l++]='3'; break;
			case 7:case 8: s[l++]='4'; break;
			case 9:default:s[l++]='5'; break;
	}	}

	if(plg->password[0])
		{s[l++]=' ';s[l++]='-';s[l++]='p';MyStringCpy(&s[l],2*MAX_PATH-l-1,plg->password);}

	s[l++]=' ';l+=MyStringCpy(&s[l],2*MAX_PATH-l-1,plg->rarFileName);
	s[l++]=' ';s[l++]='@';l+=MyStringCpy(&s[l],2*MAX_PATH-l-1,plg->addLstFileName);
	//ShellExecute(NULL,L"open",opt.rarExePath,s,plg->relPath,SW_SHOW);
	//SHELLEXECUTEINFO si;ZeroMemory(&si,sizeof(si));si.cbSize=sizeof(si);si.nShow=SW_SHOW;
	//si.lpVerb=L"open";si.lpFile=opt.rarExePath;si.lpDirectory=plg->relPath;si.lpParameters=s;
	//if(ShellExecuteEx(&si))
	STARTUPINFOW si;ZeroMemory(&si,sizeof(si));si.cb=sizeof(si);
	PROCESS_INFORMATION pi;
	if(CreateProcessW(opt.rarExePath,s,NULL,NULL,FALSE,NORMAL_PRIORITY_CLASS,
					 NULL,plg->relPath,&si,&pi))
		WaitForSingleObject(pi.hThread,INFINITE);//40000);
	DeleteFile(plg->addLstFileName);



	/*l=0;s[l++]=' ';s[l++]='d';//CreateProcess commandLine i uchun 1- simvoli - probel bo'lishi shart;
	if(plg->password[0])
		{s[l++]=' ';s[l++]='-';s[l++]='p';MyStringCpy(&s[l],2*MAX_PATH-l-1,plg->password);}

	s[l++]=' ';l+=MyStringCpy(&s[l],2*MAX_PATH-l-1,plg->rarFileName);
	s[l++]=' ';s[l++]='@';l+=MyStringCpy(&s[l],2*MAX_PATH-l-1,plg->delLstFileName);
	if(CreateProcessW(opt.rarExePath,s,NULL,NULL,FALSE,NORMAL_PRIORITY_CLASS,NULL,NULL,&si,&pi))
		WaitForSingleObject(pi.hThread,INFINITE);//40000);
	DeleteFile(plg->delLstFileName);*/
	return TRUE;
}

__declspec (dllexport) BOOL Add$24(PluginObj *plg,wchar_t *FullPathAndName,wchar_t *RelatedPathAndName,
								   wchar_t *password,int compress_level,BOOL bExcldPath)
{
wchar_t s[MAX_PATH],*p,*pp;
	for(p=RelatedPathAndName,pp=&s[0]; *p;)
	{	if(*p=='/')*pp='\\';
		else *pp=*p;
		++p;++pp;
	}*pp=0;
	fwprintf(plg->fAddLstFile,L"%s\n",s);
	if(!plg->relPath[0])
	{	MyStringCpy(plg->relPath,MAX_PATH-1,FullPathAndName);
		p = wcsstr(plg->relPath,s);
		if(p){if('\\'== *(p-1))*(p-1)=0;else *p=0;}
		else *wcsrchr(plg->relPath,'\\') = 0;
	}
	if(!plg->password[0])MyStringCpy(plg->password,MAX_PATH,password);
	if(plg->compressLevel<compress_level) plg->compressLevel=compress_level;
	if(bExcldPath)if(!plg->bExcludePath)plg->bExcludePath=TRUE;

	return TRUE;
}


}//end of "C"