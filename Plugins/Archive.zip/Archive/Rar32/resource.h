//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Rar32.rc
//
#define IDD_DIALOG_OPTIONS              132
#define IDC_RADIO_WINRAR                1002
#define IDC_RADIO_RAR                   1003
#define IDC_EDIT_WINRAR_PATH            1004
#define IDC_EDIT_RAR_PATH               1005
#define IDC_BUTTON_WINRAR_BROWSE        1006
#define IDC_BUTTON_WINRAR_BROWSE2       1007
#define IDC_EDIT_WINRAR_INFO            1008
#define IDC_EDIT_WINRAR_INFO2           1009
#define IDC_BUTTON_WINRAR_TEMPORARY_FOLDER 1010
#define IDC_STATIC_1                    1011
#define IDC_STATIC_2                    1012
#define IDC_STATIC_3                    1013
#define IDC_STATIC_4                    1014
#define IDC_STATIC_5                    1015
#define IDC_EDIT_WINRAR_TEMPORARY_FOLDER 1016

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        359
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1016
#define _APS_NEXT_SYMED_VALUE           360
#endif
#endif
