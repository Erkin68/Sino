#include "windows.h"
#include "strsafe.h"
#include "resource.h"
#include "commctrl.h"
#include "schstructs.h"
#include "Plugins_CPP.h"
#include "MyCallbacks.h"
#include "..\..\..\Operations\MyShell\MyShell.h"
#include "..\..\..\Operations\MyShell\ComboToDisk.h"
#include "..\..\..\Operations\MyShell\FindStrWthFltr.h"
#include <malloc.h>


#define IDC_BUTTON_EDIT                 2000
#define IDC_BUTTON_VIEW                 2001



extern "C"
{

extern wchar_t **strngs;
extern HMODULE plgnDllInst;

extern int MyStringCpySlash(wchar_t*,int,wchar_t*);
extern wchar_t* wstrstrslash(wchar_t*,wchar_t*);

extern BOOL SearchForContainText(LPVOID,wchar_t*,wchar_t*,WIN32_FIND_DATA*);
extern BOOL SearchForNotContainText(LPVOID,wchar_t*,wchar_t*,WIN32_FIND_DATA*);


Search	search;
SearchItem item;
HWND hResultsLB=NULL,hInfoEdit=NULL,hToPanelBTN=NULL,hViewBTN=NULL,hEditBTN=NULL;
CBToDisk selV7PthCB,selV7TxtCB,selV7ExclTxt,selV7NameCB;
MY_WIN32_FIND_DATA *findData=NULL;
wchar_t	initPath[MAX_PATH];
int	width,height,minWidth=580,minHeight=486,minHeightAftCrLB=638,findDataPtr=0,MAX_FIND_DATA_CNT=0;

VOID ResizeChilds(HWND dlg, int w, int h)
{
	width = w; height = h;

	SetWindowPos(GetDlgItem(dlg,IDC_TAB_FILE_SEACH),HWND_BOTTOM,3,3,w-7,420,SWP_SHOWWINDOW);//MoveWindow(GetDlgItem(dlg,IDC_TAB_FILE_SEACH),3,3,w-7,420,TRUE);//3 3 370 260
	//SetWindowPos(GetDlgItem(dlg,IDC_STATIC1),HWND_TOP,w-170,5,47,14,SWP_SHOWWINDOW);//268 5 27 8 method

	if(hResultsLB)
	{	SetWindowPos(hInfoEdit,HWND_TOP,2,448,w-4,22,SWP_SHOWWINDOW);
		SetWindowPos(hResultsLB,HWND_TOP,2,472,w-4,h-minHeight+14,SWP_SHOWWINDOW);
	}

	int id = TabCtrl_GetCurSel(GetDlgItem(dlg,IDC_TAB_FILE_SEACH));
	//if(0==id)
	//{
		//SetWindowPos(GetDlgItem(dlg,IDC_BUTTON_ADD_PATH),HWND_TOP,w-204,78,95,17,SWP_SHOWWINDOW);//210 46 77 13
		//SetWindowPos(GetDlgItem(dlg,IDC_BUTTON_ADD_DISK),HWND_TOP,w-106,78,95,17,SWP_SHOWWINDOW);//288 46 77 13

		SetWindowPos(GetDlgItem(dlg,IDC_COMBO_SEARCH_FOR_TEXT),HWND_TOP,7,138,w-14,12,id?SWP_HIDEWINDOW:SWP_SHOWWINDOW);//7 85 361 12
		SetWindowPos(GetDlgItem(dlg,IDC_COMBO_SEARCH_NOT_TEXT),HWND_TOP,7,268,w-14,12,id?SWP_HIDEWINDOW:SWP_SHOWWINDOW);
	
		SetWindowPos(GetDlgItem(dlg,IDC_COMBO_SEARCH_PATH),HWND_TOP,7,95,w-14,12,id?SWP_HIDEWINDOW:SWP_SHOWWINDOW);//7 59 361 12
	
		SetWindowPos(GetDlgItem(dlg,IDC_COMBO_SEARCH_NAME),HWND_TOP,7,50,w-14,12,
			id?SWP_HIDEWINDOW:SWP_SHOWWINDOW);//7 30 361 12
	//}

	/*IDCANCEL
	IDOK
	IDC_EDIT_ALTERNATIVE_FILE_NAME*/
}

VOID FreeFindData()
{	if(findData) free(findData);
	findData = NULL;
	findDataPtr=0;
	MAX_FIND_DATA_CNT=0;
}

VOID SetTabPage(HWND hDlg, int iTabPage)
{
switch(iTabPage)
{
 case 0: default:
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ALTERNATIVE_NAME),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_ALTERNATIVE_FILE_NAME),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_CREATE_TIME_BEFORE),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_CREATE_TIME_AFTER),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_DATE),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_DATE2),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_DATE_AFTER),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_DATE_AFTER2),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_CREATE_TIME_BETWEEN),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_LAST_ACCESS_TIME_BEFORE),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_LAST_ACCESS_TIME_AFTER),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE2),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_AFTER),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_AFTER2),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_LAST_ACCESS_TIME_BETWEEN),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_LAST_WRITE_TIME_BEFORE),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_LAST_WRITE_TIME_AFTER),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE2),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_AFTER),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_AFTER2),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_LAST_WRITE_TIME_BETWEEN),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_FILE_SIZE),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_COMBO_FILE_SIZE_EQUATION),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_FILE_SIZE),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_FILE_SIZE),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_COMBO_FILE_SIZE_QUANTITY),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_FILE_ATTRIBUTE),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_ARCHIVE),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_COMPRESSED),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_DEVICE),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_DIRECTORY),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_ENCRYPTED),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_HIDDEN),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_NORMAL),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_NOT_INDEXED),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_OFFLINE),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_READ_ONLY),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_REPARSE_POINT),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_SPARSE_FILE),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_SYSTEM),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_TEMPORARY),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_VIRTUAL),SW_HIDE);

 	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_BETWEEN_DATE),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_BETWEEN_TIME),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_BETWEEN_DATE2),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_BETWEEN_TIME2),SW_HIDE);
		  
 	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_BETWEEN),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_TIME_BETWEEN),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_BETWEEN2),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_TIME_BETWEEN2),SW_HIDE);

 	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_BETWEEN),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_TIME_BETWEEN),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_BETWEEN2),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_TIME_BETWEEN2),SW_HIDE);

	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_DAY),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_MOONS),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_YEAR),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_DAY),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_MOONS),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_YEAR),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_DAY),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_MOONS),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_YEAR),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_DAY),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_MOON),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_YEAR),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_DAY),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_MOON),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_YEAR),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_DAY),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_MOON),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_YEAR),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_DAY),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_MOON),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_YEAR),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_DAY),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_MOON),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_YEAR),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_DAY),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_MOON),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_YEAR),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_DAY),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_MOON),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_YEAR),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_DAY),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_MOON),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_YEAR),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_DAY),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_MOON),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_YEAR),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_HOUR),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_MIN),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_SEC),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_MILS),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_HOUR),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_MIN),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_SEC),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_MILS),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_HOUR),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_MIN),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_SEC),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_MILS),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_HOUR),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_MIN),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_SEC),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_MILS),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_HOUR),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_MIN),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_SEC),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_MILS),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_HOUR),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_MIN),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_SEC),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_MILS),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_HOUR),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_MIN),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_SEC),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_MILS),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_HOUR),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_MIN),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_SEC),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_MILS),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_HOUR),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_MIN),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_SEC),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_MILS),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_HOUR),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_MIN),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_SEC),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_MILS),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_HOUR),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_MIN),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_SEC),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_MILS),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_HOUR),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_MIN),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_SEC),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_MILS),SW_HIDE);

	//Page1:
	ShowWindow(GetDlgItem(hDlg,IDC_STATIC1),SW_SHOW); 
	ShowWindow(GetDlgItem(hDlg,IDC_STATIC2),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_COMBO_SEARCH_NAME),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_COMBO_SEARCH_PATH),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_TEXT_SEACH),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_COMBO_SEARCH_FOR_TEXT),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_UNICODE_OR_MULTIBYTE),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_BINARY_OR_CHARACTER),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_REGISTR_CAPS),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_NO_TEXT_SEACH),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_COMBO_SEARCH_NOT_TEXT),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_UNICODE_OR_MULTIBYTE2),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_BINARY_OR_CHARACTER2),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_REGISTR_CAPS2),SW_SHOW);
	//ShowWindow(GetDlgItem(hDlg,IDC_COMBO_METHOD),SW_SHOW);	
 break;
 case 1:
	ShowWindow(GetDlgItem(hDlg,IDC_STATIC1),SW_HIDE); 
	ShowWindow(GetDlgItem(hDlg,IDC_STATIC2),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_COMBO_SEARCH_NAME),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_COMBO_SEARCH_PATH),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_TEXT_SEACH),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_COMBO_SEARCH_FOR_TEXT),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_UNICODE_OR_MULTIBYTE),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_BINARY_OR_CHARACTER),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_REGISTR_CAPS),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_NO_TEXT_SEACH),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_COMBO_SEARCH_NOT_TEXT),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_UNICODE_OR_MULTIBYTE2),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_BINARY_OR_CHARACTER2),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_REGISTR_CAPS2),SW_HIDE);
	//ShowWindow(GetDlgItem(hDlg,IDC_COMBO_METHOD),SW_SHOW);

	//Page1:
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ALTERNATIVE_NAME),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_ALTERNATIVE_FILE_NAME),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_CREATE_TIME_BEFORE),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_CREATE_TIME_AFTER),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_DATE),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_DATE2),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_DATE_AFTER),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_DATE_AFTER2),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_CREATE_TIME_BETWEEN),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_LAST_ACCESS_TIME_BEFORE),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_LAST_ACCESS_TIME_AFTER),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE2),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_AFTER),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_AFTER2),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_LAST_ACCESS_TIME_BETWEEN),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_LAST_WRITE_TIME_BEFORE),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_LAST_WRITE_TIME_AFTER),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE2),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_AFTER),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_AFTER2),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_LAST_WRITE_TIME_BETWEEN),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_FILE_SIZE),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_COMBO_FILE_SIZE_EQUATION),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_FILE_SIZE),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_FILE_SIZE),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_COMBO_FILE_SIZE_QUANTITY),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_FILE_ATTRIBUTE),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_ARCHIVE),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_COMPRESSED),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_DEVICE),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_DIRECTORY),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_ENCRYPTED),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_HIDDEN),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_NORMAL),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_NOT_INDEXED),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_OFFLINE),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_READ_ONLY),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_REPARSE_POINT),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_SPARSE_FILE),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_SYSTEM),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_TEMPORARY),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_VIRTUAL),SW_SHOW);

 	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_BETWEEN_DATE),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_BETWEEN_TIME),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_BETWEEN_DATE2),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_BETWEEN_TIME2),SW_SHOW);
		  
 	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_BETWEEN),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_TIME_BETWEEN),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_BETWEEN2),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_TIME_BETWEEN2),SW_SHOW);

 	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_BETWEEN),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_TIME_BETWEEN),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_BETWEEN2),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_TIME_BETWEEN2),SW_SHOW);

	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_DAY),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_MOONS),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_YEAR),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_DAY),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_MOONS),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_YEAR),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_DAY),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_MOONS),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_YEAR),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_DAY),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_MOON),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_YEAR),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_DAY),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_MOON),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_YEAR),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_DAY),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_MOON),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_YEAR),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_DAY),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_MOON),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_YEAR),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_DAY),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_MOON),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_YEAR),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_DAY),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_MOON),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_YEAR),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_DAY),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_MOON),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_YEAR),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_DAY),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_MOON),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_YEAR),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_DAY),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_MOON),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_YEAR),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_HOUR),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_MIN),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_SEC),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_MILS),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_HOUR),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_MIN),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_SEC),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_MILS),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_HOUR),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_MIN),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_SEC),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_MILS),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_HOUR),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_MIN),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_SEC),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_MILS),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_HOUR),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_MIN),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_SEC),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_MILS),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_HOUR),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_MIN),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_SEC),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_MILS),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_HOUR),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_MIN),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_SEC),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_MILS),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_HOUR),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_MIN),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_SEC),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_MILS),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_HOUR),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_MIN),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_SEC),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_MILS),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_HOUR),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_MIN),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_SEC),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_MILS),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_HOUR),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_MIN),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_SEC),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_MILS),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_HOUR),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_MIN),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_SEC),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_MILS),SW_SHOW);

break;
}}

VOID CreateResultsLB(HWND hDlg)
{
	if(hResultsLB) return;

	//DC_COMBO_SEARCH_NAME
	//2 265
	RECT rc; GetWindowRect(hDlg, &rc);
	if(rc.bottom-rc.top<minHeightAftCrLB)
		MoveWindow(hDlg,rc.left, 
						rc.top,
						rc.right-rc.left,
						minHeightAftCrLB,
						TRUE);
	//Create List:
	hInfoEdit = CreateWindowEx(WS_EX_CLIENTEDGE,
							L"EDIT",
                            NULL,
                            WS_CHILD | WS_VISIBLE | ES_LEFT | ES_AUTOHSCROLL,
                            0,
							450,
							rc.right-rc.left-14,
							20,
                            hDlg,
                            NULL,
                            plgnDllInst,
                            NULL);
	hResultsLB = CreateWindowEx(WS_EX_CLIENTEDGE,
							L"LISTBOX",
                            NULL,
							WS_CHILD | WS_VISIBLE | WS_BORDER | LBS_EXTENDEDSEL | WS_VSCROLL | WS_HSCROLL |
							LBS_HASSTRINGS | LBS_MULTIPLESEL | LBS_NOTIFY | LBS_SORT | LBS_WANTKEYBOARDINPUT,
                            0,
							472,
							rc.right-rc.left-12,
							136,
                            hDlg,
                            NULL,
                            plgnDllInst,
                            NULL);
	SendMessage(hResultsLB, LB_SETHORIZONTALEXTENT, (rc.right-rc.left)*4, 0);
	SendMessage(hInfoEdit,EM_SETLIMITTEXT,55,0);
	//hInfoEditDC = GetDC(hInfoEdit);
	//hInfoEditRC.left = hInfoEditRC.top = 0;
	//hInfoEditRC.right = rc.right-rc.left-12;
	//hInfoEditRC.bottom = 20;
}

VOID CreateOutptBtns(HWND hDlg)
{
 if(!hToPanelBTN)
 {	hToPanelBTN = CreateWindowEx(WS_EX_CLIENTEDGE,
							L"BUTTON",
                            L"To panel",
                            WS_TABSTOP | WS_VISIBLE | WS_CHILD | WS_BORDER | BS_OWNERDRAW,
                            202,
							426,
							100,
							24,
                            hDlg,
                            (HMENU)(IDC_BUTTON_TO_PANEL),
                            plgnDllInst,
                            NULL);
	hEditBTN = CreateWindowEx(WS_EX_CLIENTEDGE,
							L"BUTTON",
                            strngs[62],//"Edit",
                            WS_TABSTOP | WS_VISIBLE | WS_CHILD | WS_BORDER | BS_OWNERDRAW,
                            102,
							426,
							100,
							24,
                            hDlg,
							(HMENU)(IDC_BUTTON_EDIT),
                            plgnDllInst,
                            NULL);
	hViewBTN = CreateWindowEx(WS_EX_CLIENTEDGE,
							L"BUTTON",
                            strngs[63],//"View",
                            WS_TABSTOP | WS_VISIBLE | WS_CHILD | WS_BORDER | BS_OWNERDRAW,
                            2,
							426,
							100,
							24,
                            hDlg,
                            (HMENU)IDC_BUTTON_VIEW,
                            plgnDllInst,
                            NULL);
 }
 SendMessage(hResultsLB,LB_SETSEL,TRUE,0);
 //PostMessage(hDlg,WM_NEXTDLGCTL,IDC_BUTTON_VIEW-3,TRUE);
 //SetFocus(hBrowseBTN);
 //SendMessage(hDlg,DM_SETDEFID,IDC_BUTTON_VIEW-3,0);
}

BOOL EditsToFileTime(FILETIME *ft, wchar_t *edtD, wchar_t *edtT)
{
	//edtD[2]=edtD[5]=edtD[10]=0;
	SYSTEMTIME st; st.wDay = (edtD[0]-'0')*10 + edtD[1]-'0';
	st.wMonth = (edtD[3]-'0')*10 + edtD[4]-'0';
	st.wYear = (edtD[6]-'0')*1000 + (edtD[7]-'0')*100 + (edtD[8]-'0')*10 + edtD[9]-'0';

	//edt[2]=edt[5]=edt[8]=edt[12]=0;
	st.wHour = (edtT[0]-'0')*10 + edtT[1]-'0';
	st.wMinute = (edtT[3]-'0')*10 + edtT[4]-'0';
	st.wSecond = (edtT[6]-'0')*10 + edtT[7]-'0';
	st.wMilliseconds = (edtT[9]-'0')*100 + (edtT[10]-'0')*10 + edtT[11]-'0';
	if(!SystemTimeToFileTime(&st,ft))
		return FALSE;
	return TRUE;
}

VOID ClearResultsLB()
{
	if(!hResultsLB) return;
	SendMessage(hResultsLB,LB_RESETCONTENT,0,0);	
}

VOID GetDlgItems(HWND hDlg)
{
	item.bEnumSubDir=(BST_CHECKED==SendMessage(
						GetDlgItem(hDlg,IDC_CHECK_ENUM_SUBDIR),BM_GETCHECK,0,0)) ? 1 : 0;

	if(!GetDlgItemText(hDlg,IDC_COMBO_SEARCH_NAME,item.filtr,MAX_PATH))
		item.filtr[0]=item.filtr[1] = 0;
	if(!GetDlgItemText(search.hDlg,IDC_COMBO_SEARCH_PATH,item.rootPath,MAX_PATH))
		item.rootPath[0] = 0;

	item.bFindForText = (BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_TEXT_SEACH),BM_GETCHECK,0,0));
	item.bFindForExcldText = (BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_NO_TEXT_SEACH),BM_GETCHECK,0,0));

	item.bFindForText_Unicode = (BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_UNICODE_OR_MULTIBYTE),BM_GETCHECK,0,0));
	if(item.bFindForText_Unicode)
	{item.FindForTextLn = GetDlgItemTextW(hDlg,IDC_COMBO_SEARCH_FOR_TEXT,(LPWSTR)item.FindForText,MAX_PATH);
	 if(!item.FindForTextLn)	
		item.FindForText[0] = item.FindForText[1] = 0;
	}else
	{ item.FindForTextLn = GetDlgItemText(hDlg,IDC_COMBO_SEARCH_FOR_TEXT,item.FindForText,MAX_PATH);
	 if(!item.FindForTextLn)	
		item.FindForText[0] = 0;
	}

	item.bFindForExcldText_Unicode = (BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_UNICODE_OR_MULTIBYTE2),BM_GETCHECK,0,0));
	if(item.bFindForExcldText_Unicode)
	{item.FindForExcldTextLn = GetDlgItemTextW(hDlg,IDC_COMBO_SEARCH_NOT_TEXT,(LPWSTR)item.FindForExcldText,MAX_PATH);
	 if(!item.FindForExcldTextLn)	
		item.FindForExcldText[0] = item.FindForExcldText[1] = 0;
	}else
	{ item.FindForExcldTextLn = GetDlgItemText(hDlg,IDC_COMBO_SEARCH_NOT_TEXT,item.FindForExcldText,MAX_PATH);
	 if(!item.FindForTextLn)	
		item.FindForExcldText[0] = 0;
	}

	item.bFindForText_ASCII = (BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_BINARY_OR_CHARACTER),BM_GETCHECK,0,0));
	item.bFindForExcldText_ASCII = (BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_BINARY_OR_CHARACTER2),BM_GETCHECK,0,0));

	item.bFindForText_UpperCase = (BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_REGISTR_CAPS),BM_GETCHECK,0,0));
	item.bFindForExcldText_UpperCase = (BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_REGISTR_CAPS2),BM_GETCHECK,0,0));

	item.bFindForAlterName = (BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_ALTERNATIVE_NAME),BM_GETCHECK,0,0));

	if(!GetDlgItemText(hDlg,IDC_EDIT_ALTERNATIVE_FILE_NAME,item.altName,MAX_PATH))
		item.altName[0] = 0;
	if(!GetDlgItemTextW(hDlg,IDC_EDIT_ALTERNATIVE_FILE_NAME,item.altNameW,MAX_PATH))
		item.altNameW[0] = 0;

	wchar_t sd[32]=L"";wchar_t st[32]=L"";
	item.bCrTimeBef = (BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_CREATE_TIME_BEFORE),BM_GETCHECK,0,0));
	if(item.bCrTimeBef)
	{	GetDlgItemText(hDlg,IDC_EDIT_CREATE_DATE,sd,MAX_PATH);
		GetDlgItemText(hDlg,IDC_EDIT_CREATE_DATE2,st,MAX_PATH);
		if(!EditsToFileTime(&item.CrTimeBef,sd,st))
			item.bCrTimeBef = FALSE;
	}
	
	item.bCrTimeAft = (BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_CREATE_TIME_AFTER),BM_GETCHECK,0,0));
	if(item.bCrTimeAft)
	{	GetDlgItemText(hDlg,IDC_EDIT_CREATE_DATE_AFTER,sd,MAX_PATH);
		GetDlgItemText(hDlg,IDC_EDIT_CREATE_DATE_AFTER2,st,MAX_PATH);
		if(!EditsToFileTime(&item.CrTimeAft,sd,st))
			item.bCrTimeAft = FALSE;
	}
	
	item.bCrTimeBet = (BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_CREATE_TIME_BETWEEN),BM_GETCHECK,0,0));
	if(item.bCrTimeBet)
	{	GetDlgItemText(hDlg,IDC_EDIT_CREATE_BETWEEN_DATE,sd,MAX_PATH);
		GetDlgItemText(hDlg,IDC_EDIT_CREATE_BETWEEN_TIME,st,MAX_PATH);
		if(!EditsToFileTime(&item.CrTimeBet[0],sd,st))
			item.bCrTimeBet = FALSE;
		GetDlgItemText(hDlg,IDC_EDIT_CREATE_BETWEEN_DATE2,sd,MAX_PATH);
		GetDlgItemText(hDlg,IDC_EDIT_CREATE_BETWEEN_TIME2,st,MAX_PATH);
		if(!EditsToFileTime(&item.CrTimeBet[1],sd,st))
			item.bCrTimeBet = FALSE;
	}

	item.bLstAccTimeBef = (BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_ACCESS_TIME_BEFORE),BM_GETCHECK,0,0));
	if(item.bLstAccTimeBef)
	{	GetDlgItemText(hDlg,IDC_EDIT_LAST_ACCESS_DATE,sd,MAX_PATH);
		GetDlgItemText(hDlg,IDC_EDIT_LAST_ACCESS_DATE2,st,MAX_PATH);
		if(!EditsToFileTime(&item.LstAccTimeBef,sd,st))
			item.bLstAccTimeBef = FALSE;
	}
	
	item.bLstAccTimeAft = (BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_ACCESS_TIME_AFTER),BM_GETCHECK,0,0));
	if(item.bLstAccTimeAft)
	{	GetDlgItemText(hDlg,IDC_EDIT_LAST_ACCESS_DATE_AFTER,sd,MAX_PATH);
		GetDlgItemText(hDlg,IDC_EDIT_LAST_ACCESS_DATE_AFTER2,st,MAX_PATH);
		if(!EditsToFileTime(&item.LstAccTimeAft,sd,st))
			item.bLstAccTimeAft = FALSE;
	}

	item.bLastAccTimeBet = (BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_ACCESS_TIME_BETWEEN),BM_GETCHECK,0,0));
	if(item.bLastAccTimeBet)
	{	GetDlgItemText(hDlg,IDC_EDIT_LAST_ACCESS_DATE_BETWEEN,sd,MAX_PATH);
		GetDlgItemText(hDlg,IDC_EDIT_LAST_ACCESS_TIME_BETWEEN,st,MAX_PATH);
		if(!EditsToFileTime(&item.LastAccTimeBet[0],sd,st))
			item.bLastAccTimeBet = FALSE;
		GetDlgItemText(hDlg,IDC_EDIT_LAST_ACCESS_DATE_BETWEEN2,sd,MAX_PATH);
		GetDlgItemText(hDlg,IDC_EDIT_LAST_ACCESS_TIME_BETWEEN2,st,MAX_PATH);
		if(!EditsToFileTime(&item.LastAccTimeBet[1],sd,st))
			item.bLastAccTimeBet = FALSE;
	}

	item.bLstWrTimeBef = (BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_WRITE_TIME_BEFORE),BM_GETCHECK,0,0));
	if(item.bLstWrTimeBef)
	{	GetDlgItemText(hDlg,IDC_EDIT_LAST_WRITE_DATE,sd,MAX_PATH);
		GetDlgItemText(hDlg,IDC_EDIT_LAST_WRITE_DATE2,st,MAX_PATH);
		if(!EditsToFileTime(&item.LstWrTimeBef,sd,st))
			item.bLstWrTimeBef = FALSE;
	}
	
	item.bLstWrTimeAft = (BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_WRITE_TIME_AFTER),BM_GETCHECK,0,0));
	if(item.bLstWrTimeAft)
	{	GetDlgItemText(hDlg,IDC_EDIT_LAST_WRITE_DATE_AFTER,sd,MAX_PATH);
		GetDlgItemText(hDlg,IDC_EDIT_LAST_WRITE_DATE_AFTER2,st,MAX_PATH);
		if(!EditsToFileTime(&item.LstWrTimeAft,sd,st))
			item.bLstWrTimeAft = FALSE;
	}
	
	item.bLstWrTimeBet = (BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_WRITE_TIME_BETWEEN),BM_GETCHECK,0,0));
	if(item.bLstWrTimeBet)
	{	GetDlgItemText(hDlg,IDC_EDIT_LAST_WRITE_DATE_BETWEEN,sd,MAX_PATH);
		GetDlgItemText(hDlg,IDC_EDIT_LAST_WRITE_TIME_BETWEEN,st,MAX_PATH);
		if(!EditsToFileTime(&item.LstWrTimeBet[0],sd,st))
			item.bLstWrTimeBet = FALSE;
		GetDlgItemText(hDlg,IDC_EDIT_LAST_WRITE_DATE_BETWEEN2,sd,MAX_PATH);
		GetDlgItemText(hDlg,IDC_EDIT_LAST_WRITE_TIME_BETWEEN2,st,MAX_PATH);
		if(!EditsToFileTime(&item.LstWrTimeBet[1],sd,st))
			item.bLstWrTimeBet = FALSE;
	}

	item.bFileSz = (BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_FILE_SIZE),BM_GETCHECK,0,0));
	if(!GetDlgItemText(hDlg,IDC_COMBO_FILE_SIZE_EQUATION,item.sFileSzEqu,MAX_PATH))
		item.sFileSzEqu[0] = 0;

	if(!GetDlgItemText(hDlg,IDC_EDIT_FILE_SIZE,item.sFileSz,MAX_PATH))
		item.sFileSz[0] = 0;

	item.iFileSzQual = (int)SendMessage(GetDlgItem(hDlg,IDC_COMBO_FILE_SIZE_QUANTITY),CB_GETCURSEL,0,0);

	item.bFileAttr = (BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_FILE_ATTRIBUTE),BM_GETCHECK,0,0));
	item.bFileAttArchive = (BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_ARCHIVE),BM_GETCHECK,0,0));
	item.bFileAttCompr = (BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_COMPRESSED),BM_GETCHECK,0,0));
	item.bFileAttDevice = (BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_DEVICE),BM_GETCHECK,0,0));
	item.bFileAttDir = (BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_DIRECTORY),BM_GETCHECK,0,0));
	item.bFileAttEncr= (BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_ENCRYPTED),BM_GETCHECK,0,0));
	item.bFileAttHidden = (BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_HIDDEN),BM_GETCHECK,0,0));
	item.bFileAttNormal = (BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_NORMAL),BM_GETCHECK,0,0));
	item.bFileAttNotInd = (BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_NOT_INDEXED),BM_GETCHECK,0,0));
	item.bFileAttOffl = (BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_OFFLINE),BM_GETCHECK,0,0));
	item.bFileAttReadOnly = (BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_READ_ONLY),BM_GETCHECK,0,0));
	item.bFileAttRepPt = (BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_REPARSE_POINT),BM_GETCHECK,0,0));
	item.bFileAttSparseFile = (BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_SPARSE_FILE),BM_GETCHECK,0,0));
	item.bFileAttSys = (BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_SYSTEM),BM_GETCHECK,0,0));
	item.bFileAttTemp = (BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_TEMPORARY),BM_GETCHECK,0,0));
	item.bFileAttVirt = (BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_VIRTUAL),BM_GETCHECK,0,0));
}

VOID AddToInfoEdit(wchar_t* rootPath, WIN32_FIND_DATA* ff)
{
wchar_t s[MAX_PATH];
	MyStringCpy(s,MAX_PATH,rootPath);
	if(ff)
	{	wchar_t *p = wcsrchr(s,'\\');
		if(p) *(p+1) = 0;
		MyStringCat(s,MAX_PATH,ff->cFileName);
	}
	SetWindowText(hInfoEdit,s);
	SendMessage(hInfoEdit,WM_PAINT,0,0);
	//DrawText(hInfoEditDC,s,-1,&hInfoEditRC,DT_RIGHT);
}

//Qo'shimcha parametrlar asosida qidirish:
BOOL CheckOtherSearchConditionsDirectFolder(wchar_t* rootPath,WIN32_FIND_DATA *pf, int type)
{
DWORD bCndtns = 0x00000000,bCndtnsMustbe = 0x00000000;

	if(0==type)//file
	{//1.1-Page, Filtr va RootPath -->> BeginSearch da;
	 //2.1-Page, Find for text:
	 if(item.bFindForText)
	 {if(item.FindForTextLn)
	  {bCndtnsMustbe |= 1;
	   if(item.bFindForText_Unicode)
	   {FindStrWthFltr fs((wchar_t*)item.FindForText);
	    for(int s=0; s<fs.GetNumStrs(); s++)
	    {	wchar_t *sub=fs.GetSubstr(s);
			//if(SearchForContainText(search.plgnObj,rootPath,sub,pf))
			//{	bCndtns |= 1;//[0] = TRUE;
		 	//	goto ToNotContainText;
	   }}	//}
	   else
	   {FindStrWthFltr fs(item.FindForText);
	    for(int s=0; s<fs.GetNumStrs(); s++)
	    {	wchar_t *sub=fs.GetSubstr(s);
			//if(SearchForContainText(search.plgnObj,rootPath,sub,pf))
			//{	bCndtns |= 1;//[0] = TRUE;
		 	//	goto ToNotContainText;
	 }}}}	//}
	 //3.1-Page, Find for do not contain text:
//ToNotContainText:
	 if(item.bFindForExcldText)
	 {if(item.FindForExcldTextLn)
	  {bCndtnsMustbe |= 2;
	   if(item.bFindForExcldText_Unicode)
	   {	FindStrWthFltr fs((wchar_t*)item.FindForExcldText);
			for(int s=0; s<fs.GetNumStrs(); s++)
			{	wchar_t *sub=fs.GetSubstr(s);
				//if(SearchForNotContainText(search.plgnObj,rootPath,sub,pf))
				//{	bCndtns |= 2;//[0] = TRUE;
		 		//	goto ToNotContainText;
		}	}	//}
		else
	    {	FindStrWthFltr fs(item.FindForExcldText);
			for(int s=0; s<fs.GetNumStrs(); s++)
			{	wchar_t *sub=fs.GetSubstr(s);
				//if(SearchForNotContainText(search.plgnObj,rootPath,sub,pf))
				//{	bCndtns |= 2;//[0] = TRUE;
		 		//	goto ToNotContainText;
	 }} }	}	//}

	 if(item.bFileSz)
	 {bCndtnsMustbe |= 4;
	  { if(item.sFileSz[0])
		{	if(CB_ERR==item.iFileSzQual) bCndtns |= 0x00000003;//[2] = TRUE;
			else
			{	unsigned __int64 sz = MyAtoU64(item.sFileSz);
				for(int i=0; i<item.iFileSzQual; i++)
					sz = sz <<  10;
				unsigned __int64 fsz = ((unsigned __int64)pf->nFileSizeHigh << 32) + (unsigned __int64)pf->nFileSizeLow;
				if('>'==item.sFileSzEqu[0])
				{	if(sz < fsz)
						bCndtns |= 4;
					//bCndtns[2] = (sz < fsz);
				}
				else if('<'==item.sFileSzEqu[0])
				{	if(sz > fsz)
						bCndtns |= 4;
					//bCndtns[2] = (sz > fsz);
				}
				else //if('='==item.sFileSzEqu[0])
				{	if(sz == fsz)
						bCndtns |= 4;
					//bCndtns[2] = (sz == fsz);
	}}}	}	}	}
	else//if(1==0)//folder
	{//1.1-Page, Filtr va RootPath -->> BeginSearch da;
	 //2.1-Page, Find for text:
	 //if(BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_TEXT_SEACH),BM_GETCHECK,0,0))
	 if(item.bFindForText)
		 return FALSE;
	 //3.1-Page, Find for do not contain text:
	 if(item.bFindForExcldText)
		 return FALSE;
	 //4.2-Page, Find for alternative name:
	 if(item.bFindForAlterName)
		 return FALSE;
	 if(item.bFileSz)
		 return FALSE;
	}

	//4.2-Page, Find for alternative name:
//FindAlternName:
	if(item.bFindForAlterName)
	{if(item.altName[0])
	 {	bCndtnsMustbe |= 0x00000008;
		if(0==wcscmp(pf->cAlternateFileName,item.altName))
			bCndtns |= 0x00000008;
	}}

	//5.2-Page, Find for creation time before:
	if(item.bCrTimeBef)
	{	bCndtnsMustbe |= 0x00000010;
		if(-1!=CmpFILETIMEs(&item.CrTimeBef,&pf->ftCreationTime))
			bCndtns |= 0x00000010;
	}

	//6.2-Page, Find for creation time after:
	if(item.bCrTimeAft)
	{	bCndtnsMustbe |= 0x00000020;
		if(1!=CmpFILETIMEs(&item.CrTimeAft,&pf->ftCreationTime))
			bCndtns |= 0x00000020;
	}

	//7.2-Page, Find for creation time between:
	if(item.bCrTimeBet)
	{	bCndtnsMustbe |= 0x00000040;
		if(1==CmpFILETIMEsBetween(&item.CrTimeBet[0],&item.CrTimeBet[1],&pf->ftCreationTime))
			bCndtns |= 0x00000040;
	}

	//8.2-Page, Find for last access time before:
	if(item.bLstAccTimeBef)
	{	bCndtnsMustbe |= 0x00000080;
		if(-1!=CmpFILETIMEs(&item.LstAccTimeBef,&pf->ftCreationTime))
			bCndtns |= 0x00000080;
	}

	//9.2-Page, Find last access time after:
	if(item.bLstAccTimeAft)
	{	bCndtnsMustbe |= 0x000000100;
		if(1!=CmpFILETIMEs(&item.LstAccTimeAft,&pf->ftLastAccessTime))
			bCndtns |= 0x00000100;
	}

	//10.2-Page, Find for last access time between:
	if(item.bLastAccTimeBet)
	{	bCndtnsMustbe |= 0x000000200;
		if(1==CmpFILETIMEsBetween(&item.LastAccTimeBet[0],&item.LastAccTimeBet[1],&pf->ftLastAccessTime))
			bCndtns |= 0x00000200;
	}

	//11.2-Page, Find for last write time before:
	if(item.bLstWrTimeBef)
	{	bCndtnsMustbe |= 0x000000400;
		if(-1!=CmpFILETIMEs(&item.LstWrTimeBef,&pf->ftLastWriteTime))
			bCndtns |= 0x00000400;
	}

	//12.2-Page, Find last write time after:
	if(item.bLstWrTimeAft)
	{	bCndtnsMustbe |= 0x00000800;
		if(1!=CmpFILETIMEs(&item.LstWrTimeAft,&pf->ftLastWriteTime))
			bCndtns |= 0x00000800;
	}

	//13.2-Page, Find for last write time between:
	if(item.bLstWrTimeBet)
	{	bCndtnsMustbe |= 0x00001000;
		if(1==CmpFILETIMEsBetween(&item.LstWrTimeBet[0],&item.LstWrTimeBet[1],&pf->ftLastWriteTime))
			bCndtns |= 0x00001000;
	}

	//14.2-Page, Find for file attribute:
	if(item.bFileAttr)
	{	if(item.bFileAttArchive)
		{	bCndtnsMustbe |= 0x0000002000;
			if((FILE_ATTRIBUTE_ARCHIVE & pf->dwFileAttributes) != 0)
				bCndtns |= 0x00002000;
		}
		if(item.bFileAttCompr)
		{	bCndtnsMustbe |= 0x0000004000;
			if((FILE_ATTRIBUTE_COMPRESSED & pf->dwFileAttributes) != 0)
				bCndtns |= 0x00004000;
		}
		if(item.bFileAttDevice)
		{	bCndtnsMustbe |= 0x0000008000;
			if((FILE_ATTRIBUTE_DEVICE & pf->dwFileAttributes) != 0)
				bCndtns |= 0x00008000;
		}
		if(item.bFileAttDir)
		{	bCndtnsMustbe |= 0x0000010000;
			if((FILE_ATTRIBUTE_DIRECTORY & pf->dwFileAttributes) != 0)
				bCndtns |= 0x00010000;
		}
		if(item.bFileAttEncr)
		{	bCndtnsMustbe |= 0x0000020000;
			if((FILE_ATTRIBUTE_ENCRYPTED & pf->dwFileAttributes) != 0)
				bCndtns |= 0x00020000;
		}
		if(item.bFileAttHidden)
		{	bCndtnsMustbe |= 0x0000040000;
			if((FILE_ATTRIBUTE_HIDDEN & pf->dwFileAttributes) != 0)
				bCndtns |= 0x00040000;
		}
		if(item.bFileAttNormal)
		{	bCndtnsMustbe |= 0x0000080000;
			if((FILE_ATTRIBUTE_NORMAL & pf->dwFileAttributes) != 0)
				bCndtns |= 0x00080000;
		}
		if(item.bFileAttNotInd)
		{	bCndtnsMustbe |= 0x0000100000;
			if((FILE_ATTRIBUTE_NOT_CONTENT_INDEXED & pf->dwFileAttributes) != 0)
				bCndtns |= 0x00100000;
		}
		if(item.bFileAttOffl)
		{	bCndtnsMustbe |= 0x00000200000;
			if((FILE_ATTRIBUTE_OFFLINE & pf->dwFileAttributes) != 0)
				bCndtns |= 0x00200000;
		}
		if(item.bFileAttReadOnly)
		{	bCndtnsMustbe |= 0x00000400000;
			if((FILE_ATTRIBUTE_READONLY & pf->dwFileAttributes) != 0)
				bCndtns |= 0x00400000;
		}
		if(item.bFileAttRepPt)
		{	bCndtnsMustbe |= 0x00000800000;
			if((FILE_ATTRIBUTE_REPARSE_POINT & pf->dwFileAttributes) != 0)
				bCndtns |= 0x00800000;
		}
		if(item.bFileAttSparseFile)
		{	bCndtnsMustbe |= 0x00001000000;
			if((FILE_ATTRIBUTE_SPARSE_FILE & pf->dwFileAttributes) != 0)
				bCndtns |= 0x01000000;
		}
		if(item.bFileAttSys)
		{	bCndtnsMustbe |= 0x00002000000;
			if((FILE_ATTRIBUTE_SYSTEM & pf->dwFileAttributes) != 0)
				bCndtns |= 0x02000000;
		}
		if(item.bFileAttTemp)
		{	bCndtnsMustbe |= 0x00004000000;
			if((FILE_ATTRIBUTE_TEMPORARY & pf->dwFileAttributes) != 0)
				bCndtns |= 0x04000000;
		}
		if(item.bFileAttVirt)
		{	bCndtnsMustbe |= 0x00008000000;
			if((FILE_ATTRIBUTE_VIRTUAL & pf->dwFileAttributes) != 0)
				bCndtns |= 0x08000000;
	}	}

	//Hamma usloviyalarni tekshirib chiqdik, endi qaytamiz:
	return (bCndtnsMustbe ^ bCndtns ? FALSE : TRUE);
}

VOID AddFindData(WIN32_FIND_DATA *ff)
{	if(findDataPtr>MAX_FIND_DATA_CNT-1)
	{	MAX_FIND_DATA_CNT += 64;
		if(findData) findData=(MY_WIN32_FIND_DATA*)malloc(sizeof(MY_WIN32_FIND_DATA) * MAX_FIND_DATA_CNT);
		else findData=(MY_WIN32_FIND_DATA*)realloc(findData,sizeof(MY_WIN32_FIND_DATA) * MAX_FIND_DATA_CNT);
	}
	findData[findDataPtr].dwFileAttributes = ff->dwFileAttributes; 
	findData[findDataPtr].ftCreationTime = ff->ftCreationTime; 
	findData[findDataPtr].ftLastAccessTime = ff->ftLastAccessTime; 
	findData[findDataPtr].ftLastWriteTime = ff->ftLastWriteTime; 
	findData[findDataPtr].nFileSizeHigh = ff->nFileSizeHigh; 
	findData[findDataPtr].nFileSizeLow = ff->nFileSizeLow; 
	findData[findDataPtr].dwReserved0 = ff->dwReserved0; 
	findData[findDataPtr].dwReserved1 = ff->dwReserved1; 

	++findDataPtr;
}

VOID AddToResultsLB(WIN32_FIND_DATA *ff,wchar_t *pathAndName)
{
wchar_t fullName[MAX_PATH+36];
	if(!hResultsLB) return;
	if(FILE_ATTRIBUTE_DIRECTORY & ff->dwFileAttributes)//dir
	{	if(!CheckOtherSearchConditionsDirectFolder(pathAndName,ff,1))
			return;
		fullName[0]='<';
		int l=MyStringCpySlash(&fullName[1],MAX_PATH-2,pathAndName);
		if('\\'==fullName[l] || '/'==fullName[l]){fullName[l]=0;--l;}
		fullName[++l]='>';fullName[++l]=0;//MyStringCat(fullName,MAX_PATH+36,">");//"]");
		SendMessageW(hResultsLB,LB_ADDSTRING,0,(LPARAM)fullName);
		AddFindData(ff);
		++search.iFoundFolders;
	}
	else//file
	{	if(!CheckOtherSearchConditionsDirectFolder(pathAndName,ff,0))
			return;
		MyStringCpySlash(fullName,MAX_PATH-1,pathAndName);
		SendMessageW(hResultsLB,LB_ADDSTRING,0,(LPARAM)fullName);
		AddFindData(ff);
		++search.iFoundFiles;
}	}

VOID FindSelectsItemsInRoot(HWND dlg,FindStrWthFltr* fs)
{
CStrW wTargetDir(search.plgnObj->tmpdir);
LPVOID par[3]={search.plgnObj,L"",fs};
	CExtract extract;
	extract.CreateFDIContext();
	extract.SetCallbacks(&k_MySearchCallbacks);
	extract.iOptn = 4;//search
	extract.ExtractFileW(*search.plgnObj->extrctFileNameStrW,wTargetDir,par);
	ResetEnumDirBuf();
}

VOID FindSelectsItems(HWND dlg,wchar_t *rootPath,FindStrWthFltr* fs)
{
CStrW wTargetDir(search.plgnObj->tmpdir);
LPVOID par[3]={search.plgnObj,rootPath,fs};
	CExtract extract;
	extract.CreateFDIContext();
	extract.SetCallbacks(&k_MySearchCallbacks);
	extract.iOptn = 4;//search
	extract.ExtractFileW(*search.plgnObj->extrctFileNameStrW,wTargetDir,par);
	ResetEnumDirBuf();
}

BOOL BeginSearch()
{
	search.bStop = FALSE;
	search.iFoundFiles = 0;
	search.iFoundFolders = 0;
	search.iCall++;
	search.ticks[0] = GetTickCount();

	EnableWindow(GetDlgItem(search.hDlg,IDCANCEL),FALSE);
	GetDlgItems(search.hDlg);
	FindStrWthFltr fs(item.filtr);
	if((!item.bEnumSubDir) && (0==item.rootPath[0]))
		FindSelectsItemsInRoot(search.hDlg,(0==fs.GetFullStrLn())?NULL:(&fs));
	else
	{	wchar_t name[MAX_PATH],*pn=&name[0];
		if(!item.rootPath[0])//rootPath, but bEnumSubDir checked,so enum all
		{	FindSelectsItems(search.hDlg,L"",(0==fs.GetFullStrLn())?NULL:(&fs));
		}
		else
		{	for(wchar_t *rp=&item.rootPath[0]; *rp; rp++)
			{	if(*rp!=0 && *rp!=';')
				{	*pn = *rp;
					++pn;
					continue;
				}
				if(*rp==';')
				{	*pn = 0;
					//Find filtr match for pn:
					if(0==fs.GetFullStrLn())
						FindSelectsItems(search.hDlg,name,NULL);
					else
						FindSelectsItems(search.hDlg,name,&fs);
					pn = &name[0];
					while(*rp==';')
						++rp;
	}	}	}	}
	
	//EnableWindow(GetDlgItem(search.hDlg,IDOK),TRUE);
	EnableWindow(GetDlgItem(search.hDlg,IDCANCEL),TRUE);

	search.iCall--;char s[256];
	search.ticks[1] = GetTickCount();
	StringCchPrintfA(s,MAX_PATH,"Founded folders: %d, Founded files: %d, elapsed time: %d milliseconds.",search.iFoundFolders,search.iFoundFiles,search.ticks[1]-search.ticks[0]);
	SetWindowTextA(hInfoEdit,s);
	//ExitThread(0); avval alohida thread edi, shu uchun turibdi.Hozir tez ishlashi
	return TRUE;//uchun asosiy threadga kiritilagn, ya'ni funk qilib chaqiriladur!!!
}

#define MAX_SAVE_SELECTION_STR	25
#define MAX_SEL_PATH			128
#define MAX_WMI_CHAR			128
#define selV7PthCBFName L"Plugins\\Archive\\Cab\\CBToDsk.bin"
#define selV7TxtCBFName L"Plugins\\Archive\\Cab\\CBToDsk.bin:stream"
#define selV7ExclTxtFName L"Plugins\\Archive\\Cab\\CBToDsk.bin:stream0"
#define selV7NameCBFName L"Plugins\\Archive\\Cab\\CBToDsk.bin:stream1"
INT_PTR CALLBACK FindFileDlgProc(HWND hDlg,UINT message,WPARAM wParam,LPARAM lParam)
{	//static int i=0;
	//char ss[32];sprintf(ss,"\n %d ",i++);
	//OutputDebugString(ss);
	//OutputDebugString(GetWinNotifyText(message));
	//sprintf(ss," %x %x",wParam,lParam);
	//OutputDebugString(ss);

static HFONT hf=0;
static int hfRef=0;//obshiy hf, dinamik uchun emas:
static HBRUSH br=0;
//static LPVOID panel;
static HBRUSH brHtBk=0;
static int endDialogCodeToWM_DESTROY;
wchar_t s[MAX_PATH];
RECT *rc;

	//UNREFERENCED_PARAMETER(lParam);
	switch(message)
	{
	case WM_SIZING:
		rc = (RECT*)lParam;
		if(rc->right-rc->left < minWidth)
			rc->right = rc->left + minWidth;
		if(hResultsLB)
		{	if(rc->bottom-rc->top < minHeightAftCrLB)
				rc->bottom = rc->top + minHeightAftCrLB;
		} else
		{	if(rc->bottom-rc->top < minHeight)
				rc->bottom = rc->top + minHeight;
			else if(rc->bottom-rc->top > minHeight)
				rc->bottom = rc->top + minHeight;
		}
		return 0;
	case WM_SIZE:
		ResizeChilds(hDlg, LOWORD(lParam), HIWORD(lParam));
		return 0;
	/*case WM_SYSCOMMAND:
		if(SC_CLOSE==wParam)
		{	EndDialog(hDlg,0);
			return 1;
		}
		else if(SC_MAXIMIZE==wParam)
		{	static BOOL bMAximize = FALSE;
			bMAximize = !bMAximize;
			ResizeDlg(hDlg,bMAximize?1:2);
			return 1;
		}
		return 0;*/
	case WM_INITDIALOG:RECT rc1;int left,top;
		endDialogCodeToWM_DESTROY=0;
		FreeFindData();
		//panel = (LPVOID)lParam;
		GetWindowRect(hDlg, &rc1);
		width = rc1.right - rc1.left;		
		left = (GetSystemMetrics(SM_CXFULLSCREEN) - width)/2;
		height = search.LBListBuf?(rc1.bottom - rc1.top):minHeight;
		top = (GetSystemMetrics(SM_CYFULLSCREEN) - height)/2;
		MoveWindow(hDlg, left, top+20, width, height, TRUE);

		//Load language strings:
		SetWindowText(hDlg,strngs[22]);
		SetDlgItemText(hDlg,IDC_STATIC1,strngs[64]);
		SetDlgItemText(hDlg,IDC_STATIC2,strngs[23]);
		SetDlgItemText(hDlg,IDC_CHECK_TEXT_SEACH,strngs[24]);
		SetDlgItemText(hDlg,IDC_CHECK_UNICODE_OR_MULTIBYTE,strngs[25]);
		//strngs[39]
		SetDlgItemText(hDlg,IDC_CHECK_BINARY_OR_CHARACTER,L"ASCII");//s);
		SetDlgItemText(hDlg,IDC_CHECK_REGISTR_CAPS,strngs[26]);
		SetDlgItemText(hDlg,IDC_CHECK_NO_TEXT_SEACH,strngs[27]);
		SetDlgItemText(hDlg,IDC_CHECK_UNICODE_OR_MULTIBYTE2,strngs[25]);
		//strngs[39]
		SetDlgItemText(hDlg,IDC_CHECK_BINARY_OR_CHARACTER2,L"ASCII");//s);
		SetDlgItemText(hDlg,IDC_CHECK_REGISTR_CAPS2,strngs[26]);
		SetDlgItemText(hDlg,IDOK,strngs[28]);
		//if(lParam)
			SetDlgItemText(hDlg,IDCANCEL,strngs[30]);
		//else ShowWindow(GetDlgItem(hDlg,IDCANCEL),SW_HIDE);
		SetDlgItemText(hDlg,IDC_CHECK_ALTERNATIVE_NAME,strngs[31]);
		SetDlgItemText(hDlg,IDC_CHECK_CREATE_TIME_BEFORE,strngs[32]);
		SetDlgItemText(hDlg,IDC_CHECK_CREATE_TIME_AFTER,strngs[33]);
		SetDlgItemText(hDlg,IDC_CHECK_CREATE_TIME_BETWEEN,strngs[34]);
		SetDlgItemText(hDlg,IDC_CHECK_LAST_ACCESS_TIME_BEFORE,strngs[35]);
		SetDlgItemText(hDlg,IDC_CHECK_LAST_ACCESS_TIME_AFTER,strngs[36]);
		SetDlgItemText(hDlg,IDC_CHECK_LAST_ACCESS_TIME_BETWEEN,strngs[37]);
		SetDlgItemText(hDlg,IDC_CHECK_LAST_WRITE_TIME_BEFORE,strngs[38]);
		SetDlgItemText(hDlg,IDC_CHECK_LAST_WRITE_TIME_AFTER ,strngs[39]);
		SetDlgItemText(hDlg,IDC_CHECK_LAST_WRITE_TIME_BETWEEN ,strngs[40]);
		SetDlgItemText(hDlg,IDC_CHECK_FILE_SIZE,strngs[41]);
		SetDlgItemText(hDlg,IDC_CHECK_FILE_ATTRIBUTE,strngs[42]);
		SetDlgItemText(hDlg,IDC_CHECK_ATTRIBUTE_ARCHIVE,strngs[43]);
		SetDlgItemText(hDlg,IDC_CHECK_ATTRIBUTE_COMPRESSED,strngs[44]);
		SetDlgItemText(hDlg,IDC_CHECK_ATTRIBUTE_DEVICE,strngs[45]);
		SetDlgItemText(hDlg,IDC_CHECK_ATTRIBUTE_DIRECTORY,strngs[46]);
		SetDlgItemText(hDlg,IDC_CHECK_ATTRIBUTE_ENCRYPTED,strngs[47]);
		SetDlgItemText(hDlg,IDC_CHECK_ATTRIBUTE_HIDDEN,strngs[48]);
		SetDlgItemText(hDlg,IDC_CHECK_ATTRIBUTE_NORMAL,strngs[49]);
		SetDlgItemText(hDlg,IDC_CHECK_ATTRIBUTE_NOT_INDEXED,strngs[50]);
		SetDlgItemText(hDlg,IDC_CHECK_ATTRIBUTE_OFFLINE,strngs[51]);
		SetDlgItemText(hDlg,IDC_CHECK_ATTRIBUTE_READ_ONLY,strngs[51]);
		SetDlgItemText(hDlg,IDC_CHECK_ATTRIBUTE_REPARSE_POINT,strngs[52]);
		SetDlgItemText(hDlg,IDC_CHECK_ATTRIBUTE_SPARSE_FILE,strngs[53]);
		SetDlgItemText(hDlg,IDC_CHECK_ATTRIBUTE_SYSTEM,strngs[54]);
		SetDlgItemText(hDlg,IDC_CHECK_ATTRIBUTE_TEMPORARY,strngs[55]);
		SetDlgItemText(hDlg,IDC_CHECK_ATTRIBUTE_VIRTUAL,strngs[56]);
		SetDlgItemText(hDlg,IDC_CHECK_ENUM_SUBDIR,strngs[57]);

		UpItem(hDlg,IDC_CHECK_ALTERNATIVE_NAME,462);
		UpItem(hDlg,IDC_EDIT_ALTERNATIVE_FILE_NAME,462);
		UpItem(hDlg,IDC_CHECK_CREATE_TIME_BEFORE,462);
		UpItem(hDlg,IDC_CHECK_CREATE_TIME_AFTER,462);
		UpItem(hDlg,IDC_EDIT_CREATE_DATE,462);
		UpItem(hDlg,IDC_EDIT_CREATE_DATE2,462);
		UpItem(hDlg,IDC_EDIT_CREATE_DATE_AFTER,462);
		UpItem(hDlg,IDC_EDIT_CREATE_DATE_AFTER2,462);
		UpItem(hDlg,IDC_CHECK_CREATE_TIME_BETWEEN,462);
		UpItem(hDlg,IDC_CHECK_LAST_ACCESS_TIME_BEFORE,462);
		UpItem(hDlg,IDC_CHECK_LAST_ACCESS_TIME_AFTER,462);
		UpItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE,462);
		UpItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE2,462);
		UpItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_AFTER,462);
		UpItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_AFTER2,462);
		UpItem(hDlg,IDC_CHECK_LAST_ACCESS_TIME_BETWEEN,462);
		UpItem(hDlg,IDC_CHECK_LAST_WRITE_TIME_BEFORE,462);
		UpItem(hDlg,IDC_CHECK_LAST_WRITE_TIME_AFTER,462);
		UpItem(hDlg,IDC_EDIT_LAST_WRITE_DATE,462);
		UpItem(hDlg,IDC_EDIT_LAST_WRITE_DATE2,462);
		UpItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_AFTER,462);
		UpItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_AFTER2,462);
		UpItem(hDlg,IDC_CHECK_LAST_WRITE_TIME_BETWEEN,462);
		UpItem(hDlg,IDC_CHECK_FILE_SIZE,462);
		UpItem(hDlg,IDC_COMBO_FILE_SIZE_EQUATION,462);
		UpItem(hDlg,IDC_EDIT_FILE_SIZE,462);
		UpItem(hDlg,IDC_SPIN_FILE_SIZE,462);
		UpItem(hDlg,IDC_COMBO_FILE_SIZE_QUANTITY,462);
		UpItem(hDlg,IDC_CHECK_FILE_ATTRIBUTE,462);
 		UpItem(hDlg,IDC_CHECK_ATTRIBUTE_ARCHIVE,462);
 		UpItem(hDlg,IDC_CHECK_ATTRIBUTE_COMPRESSED,462);
 		UpItem(hDlg,IDC_CHECK_ATTRIBUTE_DEVICE,462);
 		UpItem(hDlg,IDC_CHECK_ATTRIBUTE_DIRECTORY,462);
 		UpItem(hDlg,IDC_CHECK_ATTRIBUTE_ENCRYPTED,462);
 		UpItem(hDlg,IDC_CHECK_ATTRIBUTE_HIDDEN,462);
 		UpItem(hDlg,IDC_CHECK_ATTRIBUTE_NORMAL,462);
 		UpItem(hDlg,IDC_CHECK_ATTRIBUTE_NOT_INDEXED,462);
 		UpItem(hDlg,IDC_CHECK_ATTRIBUTE_OFFLINE,462);
 		UpItem(hDlg,IDC_CHECK_ATTRIBUTE_READ_ONLY,462);
 		UpItem(hDlg,IDC_CHECK_ATTRIBUTE_REPARSE_POINT,462);
 		UpItem(hDlg,IDC_CHECK_ATTRIBUTE_SPARSE_FILE,462);
 		UpItem(hDlg,IDC_CHECK_ATTRIBUTE_SYSTEM,462);
 		UpItem(hDlg,IDC_CHECK_ATTRIBUTE_TEMPORARY,462);
 		UpItem(hDlg,IDC_CHECK_ATTRIBUTE_VIRTUAL,462);

 		UpItem(hDlg,IDC_EDIT_CREATE_BETWEEN_DATE,462);
 		UpItem(hDlg,IDC_EDIT_CREATE_BETWEEN_TIME,462);
 		UpItem(hDlg,IDC_EDIT_CREATE_BETWEEN_DATE2,462);
 		UpItem(hDlg,IDC_EDIT_CREATE_BETWEEN_TIME2,462);
		  
 		UpItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_BETWEEN,462);
 		UpItem(hDlg,IDC_EDIT_LAST_ACCESS_TIME_BETWEEN,462);
 		UpItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_BETWEEN2,462);
 		UpItem(hDlg,IDC_EDIT_LAST_ACCESS_TIME_BETWEEN2,462);

 		UpItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_BETWEEN,462);
 		UpItem(hDlg,IDC_EDIT_LAST_WRITE_TIME_BETWEEN,462);
 		UpItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_BETWEEN2,462);
 		UpItem(hDlg,IDC_EDIT_LAST_WRITE_TIME_BETWEEN2,462);

		UpItem(hDlg,IDC_SPIN_CRTBEF_DAY,462);
		UpItem(hDlg,IDC_SPIN_CRTBEF_MOONS,462);
		UpItem(hDlg,IDC_SPIN_CRTBEF_YEAR,462);
		UpItem(hDlg,IDC_SPIN_CRTBET_DAY,462);
		UpItem(hDlg,IDC_SPIN_CRTBET_MOONS,462);
		UpItem(hDlg,IDC_SPIN_CRTBET_YEAR,462);
		UpItem(hDlg,IDC_SPIN_LSTBEF_DAY,462);
		UpItem(hDlg,IDC_SPIN_LSTBEF_MOONS,462);
		UpItem(hDlg,IDC_SPIN_LSTBEF_YEAR,462);
		UpItem(hDlg,IDC_SPIN_LSTBET_DAY,462);
		UpItem(hDlg,IDC_SPIN_LSTBET_MOON,462);
		UpItem(hDlg,IDC_SPIN_LSTBET_YEAR,462);
		UpItem(hDlg,IDC_SPIN_LSWTBEF_DAY,462);
		UpItem(hDlg,IDC_SPIN_LSWTBEF_MOON,462);
		UpItem(hDlg,IDC_SPIN_LSWTBEF_YEAR,462);
		UpItem(hDlg,IDC_SPIN_LSWTBET_DAY,462);
		UpItem(hDlg,IDC_SPIN_LSWTBET_MOON,462);
		UpItem(hDlg,IDC_SPIN_LSWTBET_YEAR,462);
		UpItem(hDlg,IDC_SPIN_CRAFT_DAY,462);
		UpItem(hDlg,IDC_SPIN_CRAFT_MOON,462);
		UpItem(hDlg,IDC_SPIN_CRAFT_YEAR,462);
		UpItem(hDlg,IDC_SPIN_CRBET_DAY,462);
		UpItem(hDlg,IDC_SPIN_CRBET_MOON,462);
		UpItem(hDlg,IDC_SPIN_CRBET_YEAR,462);
		UpItem(hDlg,IDC_SPIN_LSAFT_DAY,462);
		UpItem(hDlg,IDC_SPIN_LSAFT_MOON,462);
		UpItem(hDlg,IDC_SPIN_LSAFT_YEAR,462);
		UpItem(hDlg,IDC_SPIN_LSABET_DAY,462);
		UpItem(hDlg,IDC_SPIN_LSABET_MOON,462);
		UpItem(hDlg,IDC_SPIN_LSABET_YEAR,462);
		UpItem(hDlg,IDC_SPIN_LSWRAFT_DAY,462);
		UpItem(hDlg,IDC_SPIN_LSWRAFT_MOON,462);
		UpItem(hDlg,IDC_SPIN_LSWRAFT_YEAR,462);
		UpItem(hDlg,IDC_SPIN_LSWRBET_DAY,462);
		UpItem(hDlg,IDC_SPIN_LSWRBET_MOON,462);
		UpItem(hDlg,IDC_SPIN_LSWRBET_YEAR,462);
		UpItem(hDlg,IDC_SPIN_CRTBEF_HOUR,462);
		UpItem(hDlg,IDC_SPIN_CRTBEF_MIN,462);
		UpItem(hDlg,IDC_SPIN_CRTBEF_SEC,462);
		UpItem(hDlg,IDC_SPIN_CRTBEF_MILS,462);
		UpItem(hDlg,IDC_SPIN_CRTBET_HOUR,462);
		UpItem(hDlg,IDC_SPIN_CRTBET_MIN,462);
		UpItem(hDlg,IDC_SPIN_CRTBET_SEC,462);
		UpItem(hDlg,IDC_SPIN_CRTBET_MILS,462);
		UpItem(hDlg,IDC_SPIN_LSTBEF_HOUR,462);
		UpItem(hDlg,IDC_SPIN_LSTBEF_MIN,462);
		UpItem(hDlg,IDC_SPIN_LSTBEF_SEC,462);
		UpItem(hDlg,IDC_SPIN_LSTBEF_MILS,462);
		UpItem(hDlg,IDC_SPIN_LSTBET_HOUR,462);
		UpItem(hDlg,IDC_SPIN_LSTBET_MIN,462);
		UpItem(hDlg,IDC_SPIN_LSTBET_SEC,462);
		UpItem(hDlg,IDC_SPIN_LSTBET_MILS,462);
		UpItem(hDlg,IDC_SPIN_LSWTBEF_HOUR,462);
		UpItem(hDlg,IDC_SPIN_LSWTBEF_MIN,462);
		UpItem(hDlg,IDC_SPIN_LSWTBEF_SEC,462);
		UpItem(hDlg,IDC_SPIN_LSWTBEF_MILS,462);
		UpItem(hDlg,IDC_SPIN_LSWTBET_HOUR,462);
		UpItem(hDlg,IDC_SPIN_LSWTBET_MIN,462);
		UpItem(hDlg,IDC_SPIN_LSWTBET_SEC,462);
		UpItem(hDlg,IDC_SPIN_LSWTBET_MILS,462);
		UpItem(hDlg,IDC_SPIN_CRAFT_HOUR,462);
		UpItem(hDlg,IDC_SPIN_CRAFT_MIN,462);
		UpItem(hDlg,IDC_SPIN_CRAFT_SEC,462);
		UpItem(hDlg,IDC_SPIN_CRAFT_MILS,462);
		UpItem(hDlg,IDC_SPIN_CRBET_HOUR,462);
		UpItem(hDlg,IDC_SPIN_CRBET_MIN,462);
		UpItem(hDlg,IDC_SPIN_CRBET_SEC,462);
		UpItem(hDlg,IDC_SPIN_CRBET_MILS,462);
		UpItem(hDlg,IDC_SPIN_LSAFT_HOUR,462);
		UpItem(hDlg,IDC_SPIN_LSAFT_MIN,462);
		UpItem(hDlg,IDC_SPIN_LSAFT_SEC,462);
		UpItem(hDlg,IDC_SPIN_LSAFT_MILS,462);
		UpItem(hDlg,IDC_SPIN_LSABET_HOUR,462);
		UpItem(hDlg,IDC_SPIN_LSABET_MIN,462);
		UpItem(hDlg,IDC_SPIN_LSABET_SEC,462);
		UpItem(hDlg,IDC_SPIN_LSABET_MILS,462);
		UpItem(hDlg,IDC_SPIN_LSWRAFT_HOUR,462);
		UpItem(hDlg,IDC_SPIN_LSWRAFT_MIN,462);
		UpItem(hDlg,IDC_SPIN_LSWRAFT_SEC,462);
		UpItem(hDlg,IDC_SPIN_LSWRAFT_MILS,462);
		UpItem(hDlg,IDC_SPIN_LSWRBET_HOUR,462);
		UpItem(hDlg,IDC_SPIN_LSWRBET_MIN,462);
		UpItem(hDlg,IDC_SPIN_LSWRBET_SEC,462);
		UpItem(hDlg,IDC_SPIN_LSWRBET_MILS,462);

		SetTabPage(hDlg, 0);

		SendMessage(GetDlgItem(hDlg,IDC_CHECK_TEXT_SEACH),BM_SETCHECK,item.bFindForText?BST_CHECKED:BST_UNCHECKED,0);
		EnableWindow(GetDlgItem(hDlg,IDC_COMBO_SEARCH_FOR_TEXT),item.bFindForText?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_CHECK_UNICODE_OR_MULTIBYTE),FALSE);//item.bFindForText?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_CHECK_BINARY_OR_CHARACTER),FALSE);//item.bFindForText?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_CHECK_REGISTR_CAPS),FALSE);//item.bFindForText?TRUE:FALSE);

		SendMessage(GetDlgItem(hDlg,IDC_CHECK_NO_TEXT_SEACH),BM_SETCHECK,item.bFindForExcldText?BST_CHECKED:BST_UNCHECKED,0);
		EnableWindow(GetDlgItem(hDlg,IDC_COMBO_SEARCH_NOT_TEXT),FALSE);//item.bFindForExcldText?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_CHECK_UNICODE_OR_MULTIBYTE2),FALSE);//item.bFindForExcldText?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_CHECK_BINARY_OR_CHARACTER2),FALSE);//item.bFindForExcldText?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_CHECK_REGISTR_CAPS2),FALSE);//item.bFindForExcldText?TRUE:FALSE);

		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ALTERNATIVE_NAME),BM_SETCHECK,item.altName[0]?BST_CHECKED:BST_UNCHECKED,0);
		EnableWindow(GetDlgItem(hDlg,IDC_EDIT_ALTERNATIVE_FILE_NAME),item.altName[0]?TRUE:FALSE);

		SendMessage(GetDlgItem(hDlg,IDC_CHECK_CREATE_TIME_BEFORE),BM_SETCHECK,item.bCrTimeBef?BST_CHECKED:BST_UNCHECKED,0);
		EnableWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_DATE),item.bCrTimeBef?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_DATE2),item.bCrTimeBef?TRUE:FALSE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_CREATE_TIME_AFTER),BM_SETCHECK,item.bCrTimeAft?BST_CHECKED:BST_UNCHECKED,0);
		EnableWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_DATE_AFTER),item.bCrTimeAft?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_DATE_AFTER2),item.bCrTimeAft?TRUE:FALSE);		
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_CREATE_TIME_BETWEEN),BM_SETCHECK,item.bCrTimeBet?BST_CHECKED:BST_UNCHECKED,0);
		EnableWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_BETWEEN_DATE),item.bCrTimeBet?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_BETWEEN_TIME),item.bCrTimeBet?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_BETWEEN_DATE2),item.bCrTimeBet?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_BETWEEN_TIME2),item.bCrTimeBet?TRUE:FALSE);

		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_DAY),item.bCrTimeBef?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_MOONS),item.bCrTimeBef?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_YEAR),item.bCrTimeBef?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_HOUR),item.bCrTimeBef?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_MIN),item.bCrTimeBef?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_SEC),item.bCrTimeBef?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_MILS),item.bCrTimeBef?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_DAY),item.bCrTimeBef?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_MOONS),item.bCrTimeBet?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_YEAR),item.bCrTimeBet?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_HOUR),item.bCrTimeBet?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_MIN),item.bCrTimeBet?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_SEC),item.bCrTimeBet?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_MILS),item.bCrTimeBet?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_DAY),item.bCrTimeBet?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_MOON),item.bCrTimeBet?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_YEAR),item.bCrTimeBet?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_HOUR),item.bCrTimeBet?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_MIN),item.bCrTimeBet?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_SEC),item.bCrTimeBet?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_MILS),item.bCrTimeBet?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_DAY),item.bCrTimeAft?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_MOON),item.bCrTimeAft?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_YEAR),item.bCrTimeAft?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_HOUR),item.bCrTimeAft?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_MIN),item.bCrTimeAft?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_SEC),item.bCrTimeAft?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_MILS),item.bCrTimeAft?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_DAY),item.bCrTimeBef?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_MOONS),item.bCrTimeBef?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_YEAR),item.bCrTimeBef?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_HOUR),item.bCrTimeBef?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_MIN),item.bCrTimeBef?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_SEC),item.bCrTimeBef?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_MILS),item.bCrTimeBef?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_DAY),item.bCrTimeBef?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_MOON),item.bCrTimeBet?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_YEAR),item.bCrTimeBet?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_HOUR),item.bCrTimeBet?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_MIN),item.bCrTimeBet?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_SEC),item.bCrTimeBet?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_MILS),item.bCrTimeBet?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_DAY),item.bCrTimeBet?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_MOON),item.bCrTimeBet?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_YEAR),item.bCrTimeBet?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_HOUR),item.bCrTimeBet?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_MIN),item.bCrTimeBet?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_SEC),item.bCrTimeBet?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_MILS),item.bCrTimeBet?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_FILE_SIZE),item.bFileSz?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_DAY),item.bLstAccTimeAft?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_MOON),item.bLstAccTimeAft?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_YEAR),item.bLstAccTimeAft?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_HOUR),item.bLstAccTimeAft?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_MIN),item.bLstAccTimeAft?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_SEC),item.bLstAccTimeAft?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_MILS),item.bLstAccTimeAft?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_DAY),item.bLstWrTimeBet?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_MOON),item.bLstWrTimeBet?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_YEAR),item.bLstWrTimeBet?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_HOUR),item.bLstWrTimeBet?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_MIN),item.bLstWrTimeBet?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_SEC),item.bLstWrTimeBet?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_MILS),item.bLstWrTimeBet?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_DAY),item.bLstWrTimeBet?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_MOON),item.bLstWrTimeBet?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_YEAR),item.bLstWrTimeBet?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_HOUR),item.bLstWrTimeBet?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_MIN),item.bLstWrTimeBet?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_SEC),item.bLstWrTimeBet?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_MILS),item.bLstWrTimeBet?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_DAY),item.bLstWrTimeBef?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_MOON),item.bLstWrTimeBef?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_YEAR),item.bLstWrTimeBef?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_HOUR),item.bLstWrTimeBef?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_MIN),item.bLstWrTimeBef?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_SEC),item.bLstWrTimeBef?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_MILS),item.bLstWrTimeBef?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_DAY),item.bLstWrTimeAft?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_MOON),item.bLstWrTimeAft?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_YEAR),item.bLstWrTimeAft?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_HOUR),item.bLstWrTimeAft?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_MIN),item.bLstWrTimeAft?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_SEC),item.bLstWrTimeAft?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_MILS),item.bLstWrTimeAft?TRUE:FALSE);
		  
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_ACCESS_TIME_BETWEEN),BM_SETCHECK,item.bLastAccTimeBet?BST_CHECKED:BST_UNCHECKED,0);
		EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_BETWEEN),item.bLastAccTimeBet?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_TIME_BETWEEN),item.bLastAccTimeBet?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_BETWEEN2),item.bLastAccTimeBet?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_TIME_BETWEEN2),item.bLastAccTimeBet?TRUE:FALSE);

		SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_WRITE_TIME_BETWEEN),BM_SETCHECK,item.bLstWrTimeBet?BST_CHECKED:BST_UNCHECKED,0);
		EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_BETWEEN),item.bLstWrTimeBet?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_TIME_BETWEEN),item.bLstWrTimeBet?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_BETWEEN2),item.bLstWrTimeBet?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_TIME_BETWEEN2),item.bLstWrTimeBet?TRUE:FALSE);

		SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_ACCESS_TIME_BEFORE),BM_SETCHECK,item.bLstAccTimeBef?BST_CHECKED:BST_UNCHECKED,0);
		EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE),item.bLstAccTimeBef?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE2),item.bLstAccTimeBef?TRUE:FALSE);
		 
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_ACCESS_TIME_AFTER),BM_SETCHECK,item.bLstAccTimeAft?BST_CHECKED:BST_UNCHECKED,0);
		EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_AFTER),item.bLstAccTimeAft?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_AFTER2),item.bLstAccTimeAft?TRUE:FALSE);
		 
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_WRITE_TIME_BEFORE),BM_SETCHECK,item.bLstWrTimeBef?BST_CHECKED:BST_UNCHECKED,0);
		EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE),item.bLstWrTimeBef?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE2),item.bLstWrTimeBef?TRUE:FALSE);
	
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_WRITE_TIME_AFTER),BM_SETCHECK,item.bLstWrTimeAft?BST_CHECKED:BST_UNCHECKED,0);
		EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_AFTER),item.bLstWrTimeAft?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_AFTER2),item.bLstWrTimeAft?TRUE:FALSE);
	
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_FILE_SIZE),BM_SETCHECK,item.bFileSz?BST_CHECKED:BST_UNCHECKED,0);
		EnableWindow(GetDlgItem(hDlg,IDC_COMBO_FILE_SIZE_EQUATION),item.bFileSz?TRUE:FALSE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_FILE_SIZE),BM_SETCHECK,item.bFileSz?BST_CHECKED:BST_UNCHECKED,0);
		EnableWindow(GetDlgItem(hDlg,IDC_EDIT_FILE_SIZE),item.bFileSz?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_COMBO_FILE_SIZE_QUANTITY),item.bFileSz?TRUE:FALSE);

		SendMessage(GetDlgItem(hDlg,IDC_CHECK_FILE_ATTRIBUTE),BM_SETCHECK,item.bFileAttr?BST_CHECKED:BST_UNCHECKED,0);
		
		EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_ARCHIVE),item.bFileAttr?TRUE:FALSE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_ARCHIVE),BM_SETCHECK,item.bFileAttArchive?BST_CHECKED:BST_UNCHECKED,0);
		
		EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_COMPRESSED),item.bFileAttr?TRUE:FALSE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_COMPRESSED),BM_SETCHECK,item.bFileAttCompr?BST_CHECKED:BST_UNCHECKED,0);

		EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_DEVICE),item.bFileAttr?TRUE:FALSE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_DEVICE),BM_SETCHECK,item.bFileAttDevice?BST_CHECKED:BST_UNCHECKED,0);

		EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_DIRECTORY),item.bFileAttr?TRUE:FALSE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_DIRECTORY),BM_SETCHECK,item.bFileAttDir?BST_CHECKED:BST_UNCHECKED,0);

		EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_ENCRYPTED),item.bFileAttr?TRUE:FALSE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_ENCRYPTED),BM_SETCHECK,item.bFileAttEncr?BST_CHECKED:BST_UNCHECKED,0);

		EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_HIDDEN),item.bFileAttr?TRUE:FALSE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_HIDDEN),BM_SETCHECK,item.bFileAttHidden?BST_CHECKED:BST_UNCHECKED,0);

		EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_NORMAL),item.bFileAttr?TRUE:FALSE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_NORMAL),BM_SETCHECK,item.bFileAttNormal?BST_CHECKED:BST_UNCHECKED,0);

		EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_NOT_INDEXED),item.bFileAttr?TRUE:FALSE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_NOT_INDEXED),BM_SETCHECK,item.bFileAttNotInd?BST_CHECKED:BST_UNCHECKED,0);

		EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_OFFLINE),item.bFileAttr?TRUE:FALSE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_OFFLINE),BM_SETCHECK,item.bFileAttOffl?BST_CHECKED:BST_UNCHECKED,0);

		EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_READ_ONLY),item.bFileAttr?TRUE:FALSE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_READ_ONLY),BM_SETCHECK,item.bFileAttReadOnly?BST_CHECKED:BST_UNCHECKED,0);

		EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_REPARSE_POINT),item.bFileAttr?TRUE:FALSE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_REPARSE_POINT),BM_SETCHECK,item.bFileAttRepPt?BST_CHECKED:BST_UNCHECKED,0);

		EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_SPARSE_FILE),item.bFileAttr?TRUE:FALSE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_SPARSE_FILE),BM_SETCHECK,item.bFileAttSparseFile?BST_CHECKED:BST_UNCHECKED,0);

		EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_SYSTEM),item.bFileAttr?TRUE:FALSE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_SYSTEM),BM_SETCHECK,item.bFileAttSys?BST_CHECKED:BST_UNCHECKED,0);

		EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_TEMPORARY),item.bFileAttr?TRUE:FALSE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_TEMPORARY),BM_SETCHECK,item.bFileAttTemp?BST_CHECKED:BST_UNCHECKED,0);

		EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_VIRTUAL),item.bFileAttr?TRUE:FALSE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_VIRTUAL),BM_SETCHECK,item.bFileAttVirt?BST_CHECKED:BST_UNCHECKED,0);
  		 
		TCITEM tie;
		tie.mask = TCIF_TEXT;// | TCIF_IMAGE;
		tie.iImage = -1;
		tie.pszText = strngs[59];//"Size and time parameters:";
		TabCtrl_InsertItem(GetDlgItem(hDlg,IDC_TAB_FILE_SEACH),0, &tie);
		tie.pszText = strngs[58];//"Common parameters:";
		TabCtrl_InsertItem(GetDlgItem(hDlg,IDC_TAB_FILE_SEACH),0, &tie);

		TabCtrl_SetCurSel(GetDlgItem(hDlg,IDC_TAB_FILE_SEACH),0);

		SendMessageA(GetDlgItem(hDlg,IDC_COMBO_FILE_SIZE_EQUATION),CB_INSERTSTRING,(WPARAM)-1,(LPARAM)"<");
		SendMessageA(GetDlgItem(hDlg,IDC_COMBO_FILE_SIZE_EQUATION),CB_INSERTSTRING,(WPARAM)-1,(LPARAM)">");
		SendMessageA(GetDlgItem(hDlg,IDC_COMBO_FILE_SIZE_EQUATION),CB_INSERTSTRING,(WPARAM)-1,(LPARAM)"==");
		SendMessageA(GetDlgItem(hDlg,IDC_COMBO_FILE_SIZE_EQUATION),CB_SETCURSEL,0,0);

		SendMessageA(GetDlgItem(hDlg,IDC_COMBO_FILE_SIZE_QUANTITY),CB_INSERTSTRING,(WPARAM)-1,(LPARAM)"byte");
		SendMessageA(GetDlgItem(hDlg,IDC_COMBO_FILE_SIZE_QUANTITY),CB_INSERTSTRING,(WPARAM)-1,(LPARAM)"kb");
		SendMessageA(GetDlgItem(hDlg,IDC_COMBO_FILE_SIZE_QUANTITY),CB_INSERTSTRING,(WPARAM)-1,(LPARAM)"mb");
		SendMessageA(GetDlgItem(hDlg,IDC_COMBO_FILE_SIZE_QUANTITY),CB_INSERTSTRING,(WPARAM)-1,(LPARAM)"gb");
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_FILE_SIZE_QUANTITY),CB_SETCURSEL,0,0);

		SendMessage(GetDlgItem(hDlg,IDC_SPIN_FILE_SIZE),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_DAY),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_MOONS),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_YEAR),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_HOUR),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_MIN),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_SEC),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_MILS),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRTBET_DAY),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRTBET_MOONS),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRTBET_YEAR),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRTBET_HOUR),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRTBET_MIN),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRTBET_SEC),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRTBET_MILS),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRBET_DAY),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRBET_MOON),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRBET_YEAR),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRBET_HOUR),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRBET_MIN),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRBET_SEC),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRBET_MILS),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRAFT_DAY),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRAFT_MOON),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRAFT_YEAR),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRAFT_HOUR),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRAFT_MIN),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRAFT_SEC),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRAFT_MILS),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_DAY),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_MOONS),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_YEAR),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_HOUR),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_MIN),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_SEC),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_MILS),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_DAY),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_MOON),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_YEAR),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_HOUR),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_MIN),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_SEC),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_MILS),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_DAY),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_MOON),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_YEAR),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_HOUR),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_MIN),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_SEC),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_MILS),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSAFT_DAY),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSAFT_MOON),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSAFT_YEAR),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSAFT_HOUR),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSAFT_MIN),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSAFT_SEC),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSAFT_MILS),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSTBET_DAY),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSTBET_MOON),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSTBET_YEAR),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSTBET_HOUR),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSTBET_MIN),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSTBET_SEC),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSTBET_MILS),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSABET_DAY),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSABET_MOON),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSABET_YEAR),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSABET_HOUR),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSABET_MIN),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSABET_SEC),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSABET_MILS),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_DAY),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_MOON),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_YEAR),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_HOUR),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_MIN),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_SEC),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_MILS),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_DAY),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_MOON),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_YEAR),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_HOUR),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_MIN),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_SEC),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_MILS),UDM_SETRANGE32,0,100);

		SendMessage(GetDlgItem(hDlg,IDC_SPIN_FILE_SIZE),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_DAY),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_MOONS),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_YEAR),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_HOUR),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_MIN),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_SEC),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_MILS),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRTBET_DAY),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRTBET_MOONS),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRTBET_YEAR),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRTBET_HOUR),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRTBET_MIN),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRTBET_SEC),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRTBET_MILS),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRBET_DAY),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRBET_MOON),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRBET_YEAR),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRBET_HOUR),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRBET_MIN),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRBET_SEC),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRBET_MILS),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRAFT_DAY),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRAFT_MOON),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRAFT_YEAR),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRAFT_HOUR),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRAFT_MIN),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRAFT_SEC),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRAFT_MILS),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_DAY),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_MOONS),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_YEAR),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_HOUR),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_MIN),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_SEC),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_MILS),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_DAY),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_MOON),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_YEAR),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_HOUR),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_MIN),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_SEC),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_MILS),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_DAY),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_MOON),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_YEAR),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_HOUR),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_MIN),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_SEC),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_MILS),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSAFT_DAY),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSAFT_MOON),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSAFT_YEAR),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSAFT_HOUR),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSAFT_MIN),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSAFT_SEC),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSAFT_MILS),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSTBET_DAY),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSTBET_MOON),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSTBET_YEAR),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSTBET_HOUR),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSTBET_MIN),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSTBET_SEC),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSTBET_MILS),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSABET_DAY),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSABET_MOON),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSABET_YEAR),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSABET_HOUR),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSABET_MIN),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSABET_SEC),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSABET_MILS),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_DAY),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_MOON),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_YEAR),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_HOUR),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_MIN),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_SEC),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_MILS),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_DAY),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_MOON),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_YEAR),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_HOUR),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_MIN),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_SEC),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_MILS),UDM_SETPOS32,0,50);

		LocTimeToEdit(hDlg, IDC_EDIT_CREATE_DATE, IDC_EDIT_CREATE_DATE2);
		LocTimeToEdit(hDlg, IDC_EDIT_CREATE_DATE_AFTER, IDC_EDIT_CREATE_DATE_AFTER2);
		LocTimeToEdit(hDlg, IDC_EDIT_CREATE_BETWEEN_DATE, IDC_EDIT_CREATE_BETWEEN_TIME);
		LocTimeToEdit(hDlg, IDC_EDIT_CREATE_BETWEEN_DATE2, IDC_EDIT_CREATE_BETWEEN_TIME2);
		LocTimeToEdit(hDlg, IDC_EDIT_LAST_ACCESS_DATE, IDC_EDIT_LAST_ACCESS_DATE2);
		LocTimeToEdit(hDlg, IDC_EDIT_LAST_ACCESS_DATE_AFTER, IDC_EDIT_LAST_ACCESS_DATE_AFTER2);
		LocTimeToEdit(hDlg, IDC_EDIT_LAST_ACCESS_DATE_BETWEEN, IDC_EDIT_LAST_ACCESS_TIME_BETWEEN);
		LocTimeToEdit(hDlg, IDC_EDIT_LAST_ACCESS_DATE_BETWEEN2, IDC_EDIT_LAST_ACCESS_TIME_BETWEEN2);
		LocTimeToEdit(hDlg, IDC_EDIT_LAST_WRITE_DATE, IDC_EDIT_LAST_WRITE_DATE2);
		LocTimeToEdit(hDlg, IDC_EDIT_LAST_WRITE_DATE_AFTER, IDC_EDIT_LAST_WRITE_DATE_AFTER2);
		LocTimeToEdit(hDlg, IDC_EDIT_LAST_WRITE_DATE_BETWEEN, IDC_EDIT_LAST_WRITE_TIME_BETWEEN);
		LocTimeToEdit(hDlg, IDC_EDIT_LAST_WRITE_DATE_BETWEEN2, IDC_EDIT_LAST_WRITE_TIME_BETWEEN2);
	
		//if(lParam)
		{	selV7PthCB.Read(selV7PthCBFName,GetDlgItem(hDlg,IDC_COMBO_SEARCH_PATH),25,MAX_PATH);
			selV7TxtCB.Read(selV7TxtCBFName,GetDlgItem(hDlg,IDC_COMBO_SEARCH_FOR_TEXT),25,MAX_PATH);
			selV7ExclTxt.Read(selV7ExclTxtFName,GetDlgItem(hDlg,IDC_COMBO_SEARCH_NOT_TEXT),25,MAX_PATH);

			MyStringCpy(s,MAX_PATH,initPath);
			MyStringRemoveLastChar(s,MAX_PATH,'*');
			if(s[0])
				MyStringCat(s,MAX_PATH,L";");
			SetDlgItemText(hDlg,IDC_COMBO_SEARCH_PATH,s);
			selV7PthCB.AddToCB(GetDlgItem(hDlg,IDC_COMBO_SEARCH_PATH),s);
		

			SetDlgItemText(hDlg,IDC_EDIT_FILE_SIZE,L"1");
			if(!selV7NameCB.Read(selV7NameCBFName,
								 GetDlgItem(hDlg,IDC_COMBO_SEARCH_NAME),
								 MAX_SAVE_SELECTION_STR,
								 MAX_SEL_PATH))//fSeachViaF7.FillSearchFilterCB(hDlg,IDC_COMBO_SEARCH_NAME);
				SetDlgItemText(hDlg,IDC_COMBO_SEARCH_NAME,L"*.*;");
		}
		/*else//Agar confdan chaqirgan bo'lsa:
		{	EnableWindow(GetDlgItem(hDlg,IDC_COMBO_SEARCH_PATH),FALSE);
			EnableWindow(GetDlgItem(hDlg,IDC_BUTTON_ADD_PATH),FALSE);
			EnableWindow(GetDlgItem(hDlg,IDC_BUTTON_ADD_DISK),FALSE);
			SetDlgItemText(hDlg,IDC_COMBO_SEARCH_NAME,item.filtr);
			SetDlgItemText(hDlg,IDC_COMBO_SEARCH_PATH,item.rootPath);
			SendMessage(GetDlgItem(hDlg,IDC_CHECK_TEXT_SEACH),BM_SETCHECK,item.bFindForText?BST_CHECKED:BST_UNCHECKED,0);
			if(item.bFindForText)
			{	SetDlgItemText(hDlg,IDC_COMBO_SEARCH_FOR_TEXT,item.FindForText);
				EnableWindow(GetDlgItem(hDlg,IDC_COMBO_SEARCH_FOR_TEXT),TRUE);
				EnableWindow(GetDlgItem(hDlg,IDC_CHECK_UNICODE_OR_MULTIBYTE),TRUE);
				EnableWindow(GetDlgItem(hDlg,IDC_CHECK_BINARY_OR_CHARACTER),TRUE);
				EnableWindow(GetDlgItem(hDlg,IDC_CHECK_REGISTR_CAPS),TRUE);
				SendMessage(GetDlgItem(hDlg,IDC_CHECK_UNICODE_OR_MULTIBYTE),BM_SETCHECK,item.bFindForText_Unicode?BST_CHECKED:BST_UNCHECKED,0);
				SendMessage(GetDlgItem(hDlg,IDC_CHECK_BINARY_OR_CHARACTER),BM_SETCHECK,item.bFindForText_ASCII?BST_CHECKED:BST_UNCHECKED,0);
				SendMessage(GetDlgItem(hDlg,IDC_CHECK_REGISTR_CAPS),BM_SETCHECK,item.bFindForText_UpperCase?BST_CHECKED:BST_UNCHECKED,0);
			}
			SendMessage(GetDlgItem(hDlg,IDC_CHECK_NO_TEXT_SEACH),BM_SETCHECK,item.bFindForExcldText?BST_CHECKED:BST_UNCHECKED,0);
			if(item.bFindForExcldText)
			{	SetDlgItemText(hDlg,IDC_COMBO_SEARCH_NOT_TEXT,item.FindForExcldText);
				EnableWindow(GetDlgItem(hDlg,IDC_COMBO_SEARCH_NOT_TEXT),TRUE);
				EnableWindow(GetDlgItem(hDlg,IDC_CHECK_UNICODE_OR_MULTIBYTE2),TRUE);
				EnableWindow(GetDlgItem(hDlg,IDC_CHECK_BINARY_OR_CHARACTER2),TRUE);
				EnableWindow(GetDlgItem(hDlg,IDC_CHECK_REGISTR_CAPS2),TRUE);
				SendMessage(GetDlgItem(hDlg,IDC_CHECK_UNICODE_OR_MULTIBYTE2),BM_SETCHECK,item.bFindForExcldText_Unicode?BST_CHECKED:BST_UNCHECKED,0);
				SendMessage(GetDlgItem(hDlg,IDC_CHECK_BINARY_OR_CHARACTER2),BM_SETCHECK,item.bFindForExcldText_ASCII?BST_CHECKED:BST_UNCHECKED,0);
				SendMessage(GetDlgItem(hDlg,IDC_CHECK_REGISTR_CAPS2),BM_SETCHECK,item.bFindForExcldText_UpperCase?BST_CHECKED:BST_UNCHECKED,0);
			}

			SendMessage(GetDlgItem(hDlg,IDC_CHECK_ALTERNATIVE_NAME),BM_SETCHECK,item.bFindForAlterName?BST_CHECKED:BST_UNCHECKED,0);
			if(item.bFindForAlterName)
			{	SetDlgItemText(hDlg,IDC_EDIT_ALTERNATIVE_FILE_NAME,item.altName);
				EnableWindow(GetDlgItem(hDlg,IDC_EDIT_ALTERNATIVE_FILE_NAME),TRUE);
			}
			//wchar_t altNameW[MAX_PATH];

			SendMessage(GetDlgItem(hDlg,IDC_CHECK_CREATE_TIME_BEFORE),BM_SETCHECK,item.bCrTimeBef?BST_CHECKED:BST_UNCHECKED,0);
			if(item.bCrTimeBef)
			{	TimeToEdit(item.CrTimeBef,hDlg,IDC_EDIT_CREATE_DATE,IDC_EDIT_CREATE_DATE2);
				EnableWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_DATE),TRUE);
				EnableWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_DATE2),TRUE);
			}
			SendMessage(GetDlgItem(hDlg,IDC_CHECK_CREATE_TIME_AFTER),BM_SETCHECK,item.bCrTimeAft?BST_CHECKED:BST_UNCHECKED,0);
			if(item.bCrTimeAft)
			{	TimeToEdit(item.CrTimeAft,hDlg,IDC_EDIT_CREATE_DATE_AFTER,IDC_EDIT_CREATE_DATE_AFTER2);
				EnableWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_DATE_AFTER),TRUE);
				EnableWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_DATE_AFTER2),TRUE);
			}
			SendMessage(GetDlgItem(hDlg,IDC_CHECK_CREATE_TIME_BETWEEN),BM_SETCHECK,item.bCrTimeBet?BST_CHECKED:BST_UNCHECKED,0);
			if(item.bCrTimeBet)
			{	TimeToEdit(item.CrTimeBet[0],hDlg,IDC_EDIT_CREATE_BETWEEN_DATE,IDC_EDIT_CREATE_BETWEEN_TIME);
				TimeToEdit(item.CrTimeBet[1],hDlg,IDC_EDIT_CREATE_BETWEEN_DATE2,IDC_EDIT_CREATE_BETWEEN_TIME2);
				EnableWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_BETWEEN_DATE),TRUE);
				EnableWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_BETWEEN_TIME),TRUE);
				EnableWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_BETWEEN_DATE2),TRUE);
				EnableWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_BETWEEN_TIME2),TRUE);
			}
			SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_ACCESS_TIME_BEFORE),BM_SETCHECK,item.bLstAccTimeBef?BST_CHECKED:BST_UNCHECKED,0);
			if(item.bLstAccTimeBef)
			{	TimeToEdit(item.LstAccTimeBef,hDlg,IDC_EDIT_LAST_ACCESS_DATE,IDC_EDIT_LAST_ACCESS_DATE2);
				EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE),TRUE);
				EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE2),TRUE);
			}
			SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_ACCESS_TIME_AFTER),BM_SETCHECK,item.bLstAccTimeAft?BST_CHECKED:BST_UNCHECKED,0);
			if(item.bLstAccTimeAft)
			{	TimeToEdit(item.LstAccTimeBef,hDlg,IDC_EDIT_LAST_ACCESS_DATE_AFTER,IDC_EDIT_LAST_ACCESS_DATE_AFTER2);
				EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_AFTER),TRUE);
				EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_AFTER2),TRUE);
			}
			SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_ACCESS_TIME_BETWEEN),BM_SETCHECK,item.bLastAccTimeBet?BST_CHECKED:BST_UNCHECKED,0);
			if(item.bLastAccTimeBet)
			{	TimeToEdit(item.LastAccTimeBet[0],hDlg,IDC_EDIT_LAST_ACCESS_DATE_BETWEEN,IDC_EDIT_LAST_ACCESS_TIME_BETWEEN);
				TimeToEdit(item.LastAccTimeBet[1],hDlg,IDC_EDIT_LAST_ACCESS_DATE_BETWEEN2,IDC_EDIT_LAST_ACCESS_TIME_BETWEEN2);
				EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_BETWEEN),TRUE);
				EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_TIME_BETWEEN),TRUE);
				EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_BETWEEN2),TRUE);
				EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_TIME_BETWEEN2),TRUE);
			}
			SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_WRITE_TIME_BEFORE),BM_SETCHECK,item.bLstWrTimeBef?BST_CHECKED:BST_UNCHECKED,0);
			if(item.bLstWrTimeBef)
			{	TimeToEdit(item.LstWrTimeBef,hDlg,IDC_EDIT_LAST_WRITE_DATE,IDC_EDIT_LAST_WRITE_DATE2);
				EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE),TRUE);
				EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE2),TRUE);
			}
			SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_WRITE_TIME_AFTER),BM_SETCHECK,item.bLstWrTimeAft?BST_CHECKED:BST_UNCHECKED,0);
			if(item.bLstWrTimeAft)
			{	TimeToEdit(item.LstWrTimeAft,hDlg,IDC_EDIT_LAST_WRITE_DATE_AFTER,IDC_EDIT_LAST_WRITE_DATE_AFTER2);
				EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_AFTER),TRUE);
				EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_AFTER2),TRUE);
			}
			SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_WRITE_TIME_BETWEEN),BM_SETCHECK,item.bLstWrTimeBet?BST_CHECKED:BST_UNCHECKED,0);
			if(item.bLstWrTimeBet)
			{	TimeToEdit(item.LstWrTimeBet[0],hDlg,IDC_EDIT_LAST_WRITE_DATE_BETWEEN,IDC_EDIT_LAST_WRITE_TIME_BETWEEN);
				TimeToEdit(item.LstWrTimeBet[1],hDlg,IDC_EDIT_LAST_WRITE_DATE_BETWEEN2,IDC_EDIT_LAST_WRITE_TIME_BETWEEN2);
				EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_BETWEEN),TRUE);
				EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_TIME_BETWEEN),TRUE);
				EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_BETWEEN2),TRUE);
				EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_TIME_BETWEEN2),TRUE);
			}
			SendMessage(GetDlgItem(hDlg,IDC_CHECK_FILE_SIZE),BM_SETCHECK,item.bFileSz?BST_CHECKED:BST_UNCHECKED,0);
			if(item.bFileSz)
			{	EnableWindow(GetDlgItem(hDlg,IDC_COMBO_FILE_SIZE_EQUATION),TRUE);
				EnableWindow(GetDlgItem(hDlg,IDC_EDIT_FILE_SIZE),TRUE);
				EnableWindow(GetDlgItem(hDlg,IDC_COMBO_FILE_SIZE_QUANTITY),TRUE);
				switch(item.sFileSzEqu[0])
				{	case '<':
						SendMessage(GetDlgItem(hDlg,IDC_COMBO_FILE_SIZE_EQUATION),CB_SETCURSEL,0,0);
						break;
					case '>':
						SendMessage(GetDlgItem(hDlg,IDC_COMBO_FILE_SIZE_EQUATION),CB_SETCURSEL,1,0);
						break;
					case '=':
						SendMessage(GetDlgItem(hDlg,IDC_COMBO_FILE_SIZE_EQUATION),CB_SETCURSEL,2,0);
						break;
				}
				SetDlgItemText(hDlg,IDC_EDIT_FILE_SIZE,item.sFileSz);
				SendMessage(GetDlgItem(hDlg,IDC_COMBO_FILE_SIZE_QUANTITY),CB_SETCURSEL,item.iFileSzQual,0);
			}
			SendMessage(GetDlgItem(hDlg,IDC_CHECK_FILE_ATTRIBUTE),BM_SETCHECK,item.bFileAttr?BST_CHECKED:BST_UNCHECKED,0);
			if(item.bFileAttr)
			{	EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_ARCHIVE),TRUE);
				EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_COMPRESSED),TRUE);
				EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_DEVICE),TRUE);
				EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_DIRECTORY),TRUE);
				EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_ENCRYPTED),TRUE);
				EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_HIDDEN),TRUE);
				EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_NORMAL),TRUE);
				EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_NOT_INDEXED),TRUE);
				EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_OFFLINE),TRUE);
				EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_READ_ONLY),TRUE);
				EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_REPARSE_POINT),TRUE);
				EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_SPARSE_FILE),TRUE);
				EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_SYSTEM),TRUE);
				EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_TEMPORARY),TRUE);
				EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_VIRTUAL),TRUE);
				SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_ARCHIVE),BM_SETCHECK,item.bFileAttArchive?BST_CHECKED:BST_UNCHECKED,0);
				SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_COMPRESSED),BM_SETCHECK,item.bFileAttCompr?BST_CHECKED:BST_UNCHECKED,0);
				SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_DEVICE),BM_SETCHECK,item.bFileAttDevice?BST_CHECKED:BST_UNCHECKED,0);
				SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_DIRECTORY),BM_SETCHECK,item.bFileAttDir?BST_CHECKED:BST_UNCHECKED,0);
				SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_ENCRYPTED),BM_SETCHECK,item.bFileAttEncr?BST_CHECKED:BST_UNCHECKED,0);
				SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_HIDDEN),BM_SETCHECK,item.bFileAttHidden?BST_CHECKED:BST_UNCHECKED,0);
				SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_NORMAL),BM_SETCHECK,item.bFileAttNormal?BST_CHECKED:BST_UNCHECKED,0);
				SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_NOT_INDEXED),BM_SETCHECK,item.bFileAttNotInd?BST_CHECKED:BST_UNCHECKED,0);
				SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_OFFLINE),BM_SETCHECK,item.bFileAttOffl?BST_CHECKED:BST_UNCHECKED,0);
				SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_READ_ONLY),BM_SETCHECK,item.bFileAttReadOnly?BST_CHECKED:BST_UNCHECKED,0);
				SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_REPARSE_POINT),BM_SETCHECK,item.bFileAttRepPt?BST_CHECKED:BST_UNCHECKED,0);
				SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_SPARSE_FILE),BM_SETCHECK,item.bFileAttSparseFile?BST_CHECKED:BST_UNCHECKED,0);
				SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_SYSTEM),BM_SETCHECK,item.bFileAttSys?BST_CHECKED:BST_UNCHECKED,0);
				SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_TEMPORARY),BM_SETCHECK,item.bFileAttTemp?BST_CHECKED:BST_UNCHECKED,0);
				SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_VIRTUAL),BM_SETCHECK,item.bFileAttVirt?BST_CHECKED:BST_UNCHECKED,0);
		}	}*/
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_SEARCH_NAME),CB_SETEDITSEL,0,MAKELPARAM(0,-1));
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ENUM_SUBDIR),BM_SETCHECK,
					item.bEnumSubDir?BST_CHECKED:BST_UNCHECKED,0);
		COMBOBOXINFO ci; ci.cbSize = sizeof(COMBOBOXINFO);
		if(SendMessage(GetDlgItem(hDlg,IDC_COMBO_SEARCH_NAME),CB_GETCOMBOBOXINFO,0,(LPARAM)&ci))
			SetFocus(ci.hwndItem);
		PostMessage(hDlg,WM_NEXTDLGCTL,IDC_COMBO_SEARCH_NAME,MAKELONG(0,TRUE));

		search.iCall = 0;
		search.bStop = TRUE;
		search.bRun = FALSE;
		SendMessage(hDlg,WM_USER+1,0,0);

		if(search.LBListBuf)
		{	CreateResultsLB(hDlg);
			search.LoadLBList(hResultsLB);
			CreateOutptBtns(hDlg);
		}

		//Text bo'yicha poiski yo'q:
		EnableWindow(GetDlgItem(hDlg,IDC_CHECK_TEXT_SEACH),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_CHECK_NO_TEXT_SEACH),FALSE);
		return TRUE;
	case WM_CTLCOLORSTATIC:
	case WM_CTLCOLORLISTBOX:
	case WM_CTLCOLORSCROLLBAR:
	case WM_CTLCOLORDLG:HDC dc;dc = (HDC)wParam;
		SetTextColor(dc,RGB(0x20,0x20,0x00));//conf::Dlg.dlgRGBs[6][1]);
		SetBkColor(dc,RGB(224,231,241));//0xec,0xe1,0xec));//conf::Dlg.dlgRGBs[6][2]);
		return (INT_PTR)br;
	case WM_CTLCOLOREDIT:dc = (HDC)wParam;
		SetTextColor(dc,RGB(0x20,0x20,0));//conf::Dlg.dlgRGBs[6][1]);
		SetBkColor(dc,RGB(224,231,241));//conf::Dlg.dlgRGBs[6][2]);
		return (INT_PTR)br;
	case WM_CTLCOLORBTN:dc=(HDC)wParam;
		SetTextColor(dc,RGB(0x20,0x20,0x00));//conf::Dlg.dlgRGBs[6][1]);
		SetBkColor(dc,RGB(224,231,241));//0xee,0xae,0xd7));//conf::Dlg.dlgRGBs[6][2]);
		return (INT_PTR)brHtBk;
/*	case WM_DRAWITEM://WM_CTLCOLORBTN dagi knopkalar:
		LPDRAWITEMSTRUCT lpdis;lpdis = (LPDRAWITEMSTRUCT)lParam;
		GetWindowText(lpdis->hwndItem,s,64);
		RECT r;UINT uStyle;uStyle = DFCS_BUTTONPUSH;
		r = lpdis->rcItem;
		if(lpdis->itemState & ODS_SELECTED)
		{	uStyle |= DFCS_PUSHED|DFCS_TRANSPARENT;
			r.left+=2;r.top+=2;
		}
		DrawFrameControl(lpdis->hDC, &lpdis->rcItem, DFC_BUTTON, uStyle);
		if(lpdis->itemState & ODS_SELECTED)
			{r.left+=1;r.top+=1;r.bottom-=2;r.right-=3;}
		else
			{r.left+=1;r.top+=2;r.bottom-=3;r.right-=3;}
		FillRect(lpdis->hDC,&r,brHtBk);//DrawText(lpdis->hDC,"                                                  ",50,&rc,DT_SINGLELINE|DT_VCENTER|DT_INTERNAL|DT_LEFT);
		if(lpdis->itemState & ODS_SELECTED)
			{r.left-=1;r.top-=1;r.bottom+=3;r.right+=3;}
		else
			{r.left-=1;r.top-=2;r.bottom+=2;r.right+=3;}
		DrawText(lpdis->hDC,s,MyStringLength(s,64),&r,DT_SINGLELINE|DT_VCENTER|DT_CENTER);
		return TRUE;*/
	case WM_USER+1://hf obshiy uchun, dinamik o'zgartirish uchun emas:
		if(0==hfRef)
		{	LOGFONTA lf;InitLOGFONTA(&lf);
			hf = CreateFontIndirectA(&lf);
			br = CreateSolidBrush(RGB(224,231,241));//0xeb,0xe0,0xeb));//conf::Dlg.dlgRGBs[6][0]);
			brHtBk = CreateSolidBrush(RGB(224,231,241));//conf::Dlg.dlgRGBs[6][5]);
			//dlgRGBs[d][0] = 0x00c98193;//0x00ebe0eb;//Back
			//dlgRGBs[d][1] = 0x008a0000;//0x00c98193;//0x008a0000;//Front
			//dlgRGBs[d][2] = 0x00c08197;//0x00ece1ec;//Select back
			//dlgRGBs[d][3] = 0x000000ff;//Select
			//dlgRGBs[d][4] = 0x00ff0000;//0x001e1404;//0x00ff0000;//Hot
			//dlgRGBs[d][5] = 0x00748975;//0x00eeaed7;//Hot back
		}
		SendMessage(GetDlgItem(hDlg,IDC_TAB_FILE_SEACH),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_STATIC8),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_STATIC1),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_STATIC2),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_STATIC3),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_STATIC4),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_STATIC5),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_STATIC6),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_STATIC7),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_SEARCH_NAME),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_SEARCH_PATH),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_TEXT_SEACH),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_SEARCH_FOR_TEXT),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_UNICODE_OR_MULTIBYTE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_BINARY_OR_CHARACTER),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_REGISTR_CAPS),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_NO_TEXT_SEACH),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_UNICODE_OR_MULTIBYTE2),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_BINARY_OR_CHARACTER2),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_REGISTR_CAPS2),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDOK),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDCANCEL),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ALTERNATIVE_NAME),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_ALTERNATIVE_FILE_NAME),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_CREATE_TIME_BEFORE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_CREATE_TIME_AFTER),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_CREATE_DATE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_CREATE_DATE2),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_CREATE_DATE_AFTER),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_CREATE_DATE_AFTER2),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_CREATE_TIME_BETWEEN),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_CREATE_BETWEEN_DATE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_CREATE_BETWEEN_TIME),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_CREATE_BETWEEN_DATE2),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_CREATE_BETWEEN_TIME2),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_ACCESS_TIME_BEFORE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_ACCESS_TIME_AFTER),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE2),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_AFTER),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_AFTER2),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_ACCESS_TIME_BETWEEN),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_BETWEEN),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_TIME_BETWEEN),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_BETWEEN2),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_TIME_BETWEEN2),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_WRITE_TIME_BEFORE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_WRITE_TIME_AFTER),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE2),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_AFTER),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_AFTER2),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_WRITE_TIME_BETWEEN),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_BETWEEN),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_TIME_BETWEEN),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_BETWEEN2),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_TIME_BETWEEN2),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_FILE_SIZE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_FILE_SIZE_EQUATION),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_FILE_SIZE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_FILE_SIZE_QUANTITY),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_FILE_ATTRIBUTE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_ARCHIVE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_COMPRESSED),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_DEVICE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_DIRECTORY),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_ENCRYPTED),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_HIDDEN),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_NORMAL),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_NOT_INDEXED),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_OFFLINE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_READ_ONLY),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_REPARSE_POINT),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_SPARSE_FILE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_SYSTEM),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_TEMPORARY),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_VIRTUAL),WM_SETFONT,(WPARAM)hf,TRUE);
		++hfRef;
		return 0;//GWL_USERDATA
	case WM_DESTROY:
		if(--hfRef<1)
		{	DeleteObject(hf);
			DeleteObject(br);
			DeleteObject(brHtBk);
		}
		if(2==endDialogCodeToWM_DESTROY)
			search.SaveLBListBuf(hResultsLB);
		else
		{	free(search.LBListBuf);
			search.LBListBuf=NULL;
		}
		hResultsLB = NULL;
		hToPanelBTN=NULL;
		width = 0;
		return 0;
	case WM_COMMAND:
		switch(LOWORD(wParam))
		{	case IDOK:
				if(!search.bRun)//Start:
				{	SetDlgItemText(hDlg,IDOK,strngs[61]);

					if(search.iCall)return FALSE;
					if(GetDlgItemText(hDlg,IDC_COMBO_SEARCH_PATH,s,MAX_PATH))
						selV7PthCB.AddToCB(GetDlgItem(hDlg,IDC_COMBO_SEARCH_PATH),s);
					if(GetDlgItemText(hDlg,IDC_COMBO_SEARCH_FOR_TEXT,s,MAX_PATH))
						selV7TxtCB.AddToCB(GetDlgItem(hDlg,IDC_COMBO_SEARCH_FOR_TEXT),s);
					if(GetDlgItemText(hDlg,IDC_COMBO_SEARCH_NOT_TEXT,s,MAX_PATH))
						selV7ExclTxt.AddToCB(GetDlgItem(hDlg,IDC_COMBO_SEARCH_NOT_TEXT),s);
					if(GetDlgItemText(hDlg,IDC_COMBO_SEARCH_NAME,s,MAX_PATH))
						selV7NameCB.AddToCB(GetDlgItem(hDlg,IDC_COMBO_SEARCH_NAME),s);
					selV7PthCB.Save(selV7PthCBFName,GetDlgItem(hDlg,IDC_COMBO_SEARCH_PATH),25);
					selV7TxtCB.Save(selV7TxtCBFName,GetDlgItem(hDlg,IDC_COMBO_SEARCH_FOR_TEXT),25);
					selV7ExclTxt.Save(selV7ExclTxtFName,GetDlgItem(hDlg,IDC_COMBO_SEARCH_NOT_TEXT),25);
					selV7NameCB.Save(selV7NameCBFName,GetDlgItem(hDlg,IDC_COMBO_SEARCH_NAME),25);

					ClearResultsLB();
					CreateResultsLB(hDlg);

					//FILETIME crBef,crAft,crBtwn[2],lastBef,lastAft,lastBtwn[2],
					//lastWrBef,lastWrAft,lastWrBtwn[2];

					search.hDlg = hDlg;
					search.bRun = TRUE;
   					BeginSearch();
					search.bRun = FALSE;
					SetDlgItemText(hDlg,IDOK,strngs[28]);
					CreateOutptBtns(hDlg);
				}
				else //Stop:
				{	search.bStop = TRUE;
					//LoadString(g_hInstance,IDS_STRINGSW_3,s,MAX_PATH);
					//SetDlgItemText(hDlg,IDOK,s);
				}
				return FALSE;
			case IDCANCEL:
				//if(0==panel) return FALSE;//confdan chaqirilgan;
				//int r;r = SendMessage(hResultsLB,LB_GETCOUNT,0,0);
				if(!search.iCall)
					EndDialog(hDlg,0);
				return FALSE;
			case IDC_CHECK_TEXT_SEACH:
				if(BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_TEXT_SEACH),BM_GETCHECK,0,0))
				{	EnableWindow(GetDlgItem(hDlg,IDC_COMBO_SEARCH_FOR_TEXT),TRUE);
					//EnableWindow(GetDlgItem(hDlg,IDC_CHECK_UNICODE_OR_MULTIBYTE),TRUE);
					//EnableWindow(GetDlgItem(hDlg,IDC_CHECK_BINARY_OR_CHARACTER),TRUE);
					//EnableWindow(GetDlgItem(hDlg,IDC_CHECK_REGISTR_CAPS),TRUE);
				}
				else
				{	EnableWindow(GetDlgItem(hDlg,IDC_COMBO_SEARCH_FOR_TEXT),FALSE);
					//EnableWindow(GetDlgItem(hDlg,IDC_CHECK_UNICODE_OR_MULTIBYTE),FALSE);
					//EnableWindow(GetDlgItem(hDlg,IDC_CHECK_BINARY_OR_CHARACTER),FALSE);
					//EnableWindow(GetDlgItem(hDlg,IDC_CHECK_REGISTR_CAPS),FALSE);
				}
				return (INT_PTR)TRUE;
			case IDC_CHECK_NO_TEXT_SEACH:
				if(BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_NO_TEXT_SEACH),BM_GETCHECK,0,0))
				{	//EnableWindow(GetDlgItem(hDlg,IDC_COMBO_SEARCH_NOT_TEXT),TRUE);
					//EnableWindow(GetDlgItem(hDlg,IDC_CHECK_UNICODE_OR_MULTIBYTE2),TRUE);
					//EnableWindow(GetDlgItem(hDlg,IDC_CHECK_BINARY_OR_CHARACTER2),TRUE);
					//EnableWindow(GetDlgItem(hDlg,IDC_CHECK_REGISTR_CAPS2),TRUE);
				}
				else
				{	//EnableWindow(GetDlgItem(hDlg,IDC_COMBO_SEARCH_NOT_TEXT),FALSE);
					//EnableWindow(GetDlgItem(hDlg,IDC_CHECK_UNICODE_OR_MULTIBYTE2),FALSE);
					//EnableWindow(GetDlgItem(hDlg,IDC_CHECK_BINARY_OR_CHARACTER2),FALSE);
					//EnableWindow(GetDlgItem(hDlg,IDC_CHECK_REGISTR_CAPS2),FALSE);
				}
				return (INT_PTR)TRUE;
			case IDC_CHECK_UNICODE_OR_MULTIBYTE:
				if(BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_UNICODE_OR_MULTIBYTE),BM_GETCHECK,0,0))
				{	//strngs[4]
					SetDlgItemText(hDlg,IDC_CHECK_UNICODE_OR_MULTIBYTE,L"Unicode");
				}
				else
					SetDlgItemText(hDlg,IDC_CHECK_UNICODE_OR_MULTIBYTE,strngs[25]);
				return (INT_PTR)TRUE;
			case IDC_CHECK_UNICODE_OR_MULTIBYTE2:
				if(BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_UNICODE_OR_MULTIBYTE2),BM_GETCHECK,0,0))
				{	//strngs[4]
					SetDlgItemText(hDlg,IDC_CHECK_UNICODE_OR_MULTIBYTE2,L"Unicode");
				}
				else
					SetDlgItemText(hDlg,IDC_CHECK_UNICODE_OR_MULTIBYTE2,strngs[25]);
				return (INT_PTR)TRUE;
			case IDC_CHECK_BINARY_OR_CHARACTER:
				if(BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_BINARY_OR_CHARACTER),BM_GETCHECK,0,0))
					SetDlgItemText(hDlg,IDC_CHECK_BINARY_OR_CHARACTER,strngs[60]);
				else
				{	//SetDlgItemText(hDlg,IDC_CHECK_BINARY_OR_CHARACTER,strngs[39]);
					SetDlgItemText(hDlg,IDC_CHECK_BINARY_OR_CHARACTER,L"ASCII");
				}
				break;
			case IDC_CHECK_BINARY_OR_CHARACTER2:
				if(BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_BINARY_OR_CHARACTER2),BM_GETCHECK,0,0))
					SetDlgItemText(hDlg,IDC_CHECK_BINARY_OR_CHARACTER2,strngs[60]);
				else
				{	//strngs[39]
					SetDlgItemText(hDlg,IDC_CHECK_BINARY_OR_CHARACTER2,L"ASCII");
				}
				break;
			case IDC_CHECK_ALTERNATIVE_NAME:
				if(BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_ALTERNATIVE_NAME),BM_GETCHECK,0,0))
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_ALTERNATIVE_FILE_NAME),TRUE);
				else
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_ALTERNATIVE_FILE_NAME),FALSE);
				break;
			case IDC_CHECK_CREATE_TIME_BEFORE:
				if(BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_CREATE_TIME_BEFORE),BM_GETCHECK,0,0))
				{	//SendMessage(GetDlgItem(hDlg,IDC_CHECK_CREATE_TIME_AFTER),BM_SETCHECK,BST_UNCHECKED,0);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_DATE),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_DATE2),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_DAY),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_MOONS),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_YEAR),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_HOUR),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_MIN),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_SEC),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_MILS),TRUE);
					//item.bCrTimeBef = 1;
				}
				else
				{	EnableWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_DATE),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_DATE2),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_DAY),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_MOONS),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_YEAR),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_HOUR),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_MIN),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_SEC),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_MILS),FALSE);
					//item.bCrTimeBef = 0;
				}
				break;
			case IDC_CHECK_CREATE_TIME_AFTER:
				if(BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_CREATE_TIME_AFTER),BM_GETCHECK,0,0))
				{	//SendMessage(GetDlgItem(hDlg,IDC_CHECK_CREATE_TIME_BEFORE),BM_SETCHECK,BST_UNCHECKED,0);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_DATE_AFTER),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_DATE_AFTER2),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_DAY),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_MOON),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_YEAR),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_HOUR),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_MIN),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_SEC),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_MILS),TRUE);
					//item.bCrTimeAft = 1;
				}
				else
				{	EnableWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_DATE_AFTER),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_DATE_AFTER2),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_DAY),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_MOON),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_YEAR),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_HOUR),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_MIN),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_SEC),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_MILS),FALSE);
					//item.bCrTimeAft = 0;
				}
				break;				 
			case IDC_CHECK_CREATE_TIME_BETWEEN:
				if(BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_CREATE_TIME_BETWEEN),BM_GETCHECK,0,0))
				{	EnableWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_BETWEEN_DATE),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_BETWEEN_TIME),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_BETWEEN_DATE2),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_BETWEEN_TIME2),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_DAY),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_MOONS),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_YEAR),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_HOUR),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_MIN),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_SEC),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_MILS),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_DAY),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_MOON),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_YEAR),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_HOUR),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_MIN),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_SEC),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_MILS),TRUE);
					//item.bCrTimeBef = 1;
				}
				else
				{	EnableWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_BETWEEN_DATE),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_BETWEEN_TIME),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_BETWEEN_DATE2),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_BETWEEN_TIME2),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_DAY),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_MOONS),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_YEAR),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_HOUR),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_MIN),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_SEC),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_MILS),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_DAY),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_MOON),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_YEAR),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_HOUR),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_MIN),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_SEC),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_MILS),FALSE);
					//item.bCrTimeBef = 0;
				}
				break;
			case IDC_CHECK_LAST_ACCESS_TIME_BETWEEN:
				if(BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_ACCESS_TIME_BETWEEN),BM_GETCHECK,0,0))
				{	EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_BETWEEN),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_TIME_BETWEEN),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_BETWEEN2),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_TIME_BETWEEN2),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_DAY),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_MOON),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_YEAR),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_HOUR),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_MIN),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_SEC),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_MILS),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_DAY),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_MOON),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_YEAR),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_HOUR),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_MIN),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_SEC),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_MILS),TRUE);
					//item.bLastAccTimeBet = 0;
				}
				else
				{	EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_BETWEEN),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_TIME_BETWEEN),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_BETWEEN2),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_TIME_BETWEEN2),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_DAY),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_MOON),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_YEAR),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_HOUR),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_MIN),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_SEC),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_MILS),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_DAY),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_MOON),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_YEAR),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_HOUR),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_MIN),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_SEC),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_MILS),FALSE);
					//item.bLastAccTimeBet = 0;
				}
				break;
			case IDC_CHECK_LAST_WRITE_TIME_BETWEEN:
				if(BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_WRITE_TIME_BETWEEN),BM_GETCHECK,0,0))
				{	EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_BETWEEN),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_TIME_BETWEEN),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_BETWEEN2),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_TIME_BETWEEN2),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_DAY),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_MOON),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_YEAR),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_HOUR),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_MIN),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_SEC),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_MILS),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_DAY),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_MOON),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_YEAR),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_HOUR),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_MIN),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_SEC),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_MILS),TRUE);
					//item.bLstWrTimeBet = 1;
				}
				else
				{	EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_BETWEEN),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_TIME_BETWEEN),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_BETWEEN2),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_TIME_BETWEEN2),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_DAY),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_MOON),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_YEAR),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_HOUR),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_MIN),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_SEC),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_MILS),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_DAY),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_MOON),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_YEAR),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_HOUR),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_MIN),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_SEC),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_MILS),FALSE);
					//item.bLstWrTimeBet = 0;
				}
				break;
			case IDC_CHECK_LAST_ACCESS_TIME_BEFORE:
				if(BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_ACCESS_TIME_BEFORE),BM_GETCHECK,0,0))
				{	//SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_ACCESS_TIME_AFTER),BM_SETCHECK,BST_UNCHECKED,0);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE2),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_DAY),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_MOONS),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_YEAR),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_HOUR),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_MIN),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_SEC),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_MILS),TRUE);
					//item.bLstAccTimeBef = 1;
				}
				else
				{	EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE2),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_DAY),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_MOONS),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_YEAR),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_HOUR),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_MIN),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_SEC),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_MILS),FALSE);
					//item.bLstAccTimeBef = 0;
				}
				break;
			case IDC_CHECK_LAST_ACCESS_TIME_AFTER:
				if(BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_ACCESS_TIME_AFTER),BM_GETCHECK,0,0))
				{	//SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_ACCESS_TIME_BEFORE),BM_SETCHECK,BST_UNCHECKED,0);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_AFTER),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_AFTER2),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_DAY),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_MOON),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_YEAR),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_HOUR),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_MIN),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_SEC),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_MILS),TRUE);
					//item.bLstAccTimeAft = 1;
				}
				else
				{	EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_AFTER),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_AFTER2),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_DAY),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_MOON),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_YEAR),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_HOUR),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_MIN),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_SEC),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_MILS),FALSE);
					//item.bLstAccTimeAft = 0;
				}
				break;
			case IDC_CHECK_LAST_WRITE_TIME_BEFORE:
				if(BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_WRITE_TIME_BEFORE),BM_GETCHECK,0,0))
				{	//SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_WRITE_TIME_AFTER),BM_SETCHECK,BST_UNCHECKED,0);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE2),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_DAY),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_MOON),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_YEAR),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_HOUR),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_MIN),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_SEC),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_MILS),TRUE);
					//item.bLstWrTimeBef = 1;
				}
				else
				{	EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE2),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_DAY),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_MOON),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_YEAR),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_HOUR),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_MIN),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_SEC),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_MILS),FALSE);
					//item.bLstWrTimeBef = 0;
				}
				break;
			case IDC_CHECK_LAST_WRITE_TIME_AFTER:
				if(BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_WRITE_TIME_AFTER),BM_GETCHECK,0,0))
				{	//SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_WRITE_TIME_BEFORE),BM_SETCHECK,BST_UNCHECKED,0);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_AFTER),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_AFTER2),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_DAY),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_MOON),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_YEAR),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_HOUR),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_MIN),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_SEC),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_MILS),TRUE);
					//item.bLstWrTimeAft = 1;
				}
				else
				{	EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_AFTER),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_AFTER2),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_DAY),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_MOON),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_YEAR),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_HOUR),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_MIN),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_SEC),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_MILS),FALSE);
					//item.bLstWrTimeAft = 0;
				}
				break;
			case IDC_CHECK_FILE_SIZE:
				if(BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_FILE_SIZE),BM_GETCHECK,0,0))
				{	EnableWindow(GetDlgItem(hDlg,IDC_COMBO_FILE_SIZE_EQUATION),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_FILE_SIZE),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_FILE_SIZE),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_COMBO_FILE_SIZE_QUANTITY),TRUE);
					//item.bFileSz = 1;
				}
				else
				{	EnableWindow(GetDlgItem(hDlg,IDC_COMBO_FILE_SIZE_EQUATION),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_FILE_SIZE),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_FILE_SIZE),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_COMBO_FILE_SIZE_QUANTITY),FALSE);
					//item.bFileSz = 0;
				}
				break;
			case IDC_CHECK_FILE_ATTRIBUTE:
				if(BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_FILE_ATTRIBUTE),BM_GETCHECK,0,0))
				{	EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_ARCHIVE),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_COMPRESSED),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_DEVICE),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_DIRECTORY),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_ENCRYPTED),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_HIDDEN),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_NORMAL),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_NOT_INDEXED),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_OFFLINE),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_READ_ONLY),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_REPARSE_POINT),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_SPARSE_FILE),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_SYSTEM),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_TEMPORARY),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_VIRTUAL),TRUE);
					//item.bFileAttr = 1;
				}
				else
				{	EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_ARCHIVE),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_COMPRESSED),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_DEVICE),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_DIRECTORY),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_ENCRYPTED),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_HIDDEN),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_NORMAL),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_NOT_INDEXED),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_OFFLINE),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_READ_ONLY),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_REPARSE_POINT),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_SPARSE_FILE),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_SYSTEM),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_TEMPORARY),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_VIRTUAL),FALSE);
					//item.bFileAttr = 0;
				}
				break;
			case IDC_CHECK_ENUM_SUBDIR:
				item.bEnumSubDir=(BST_CHECKED==SendMessage(
						GetDlgItem(hDlg,IDC_CHECK_ENUM_SUBDIR),BM_GETCHECK,0,0)) ? 1 : 0;
				break;
			case IDC_EDIT_CREATE_DATE:
			case IDC_EDIT_CREATE_DATE_AFTER:
			case IDC_EDIT_CREATE_BETWEEN_DATE:
			case IDC_EDIT_CREATE_BETWEEN_DATE2:
			case IDC_EDIT_LAST_ACCESS_DATE:
			case IDC_EDIT_LAST_ACCESS_DATE_AFTER:
			case IDC_EDIT_LAST_ACCESS_DATE_BETWEEN:
			case IDC_EDIT_LAST_ACCESS_DATE_BETWEEN2:
			case IDC_EDIT_LAST_WRITE_DATE:
			case IDC_EDIT_LAST_WRITE_DATE_AFTER:
			case IDC_EDIT_LAST_WRITE_DATE_BETWEEN:
			case IDC_EDIT_LAST_WRITE_DATE_BETWEEN2:
				if(EN_KILLFOCUS==HIWORD(wParam))
				{	if(GetWindowText((HWND)lParam,s,MAX_PATH))
					{	//first 2 char before '.' - day of month
						if(s[0] < '0') s[0] = '0';
						if(s[0] > '3') s[0] = '3';
						if(s[1] < (s[0]<'1'?'1':'0')) s[1] = s[0]<'1'?'1':'0';
						if(s[1] > (s[0]<'3'?'9':'1')) s[1] = s[0]<'3'?'9':'1';
						if(s[2] != '.') s[2] = '.';
						//second 2 char after first '.' - month
						if(s[3] < '0') s[3] = '0';
						if(s[3] > '1') s[3] = '1';
						if(s[4] < (s[3]<'1'?'1':'0')) s[4] = s[3]<'1'?'1':'0';
						if(s[4] > (s[3]<'1'?'9':'2')) s[4] = s[3]<'1'?'9':'2';
						if(s[5] != '.') s[5] = '.';
						//last 2 char after second '.' - year
						if(s[6] < '0') s[6] = '0';
						if(s[6] > '9') s[6] = '9';
						if(s[7] < '0') s[7] = '0';
						if(s[7] > '9') s[7] = '9';
						if(s[8] < '0') s[8] = '0';
						if(s[8] > '9') s[8] = '9';
						if(s[9] < '0') s[9] = '0';
						if(s[9] > '9') s[9] = '9';
						s[10] = 0;
						SetWindowText((HWND)lParam,s);
				}	}
				break;
			case IDC_EDIT_CREATE_DATE2:
			case IDC_EDIT_CREATE_DATE_AFTER2:
			case IDC_EDIT_CREATE_BETWEEN_TIME:
			case IDC_EDIT_CREATE_BETWEEN_TIME2:
			case IDC_EDIT_LAST_ACCESS_DATE2:
			case IDC_EDIT_LAST_ACCESS_DATE_AFTER2:
			case IDC_EDIT_LAST_ACCESS_TIME_BETWEEN:
			case IDC_EDIT_LAST_ACCESS_TIME_BETWEEN2:
			case IDC_EDIT_LAST_WRITE_DATE2:
			case IDC_EDIT_LAST_WRITE_DATE_AFTER2:
			case IDC_EDIT_LAST_WRITE_TIME_BETWEEN:
			case IDC_EDIT_LAST_WRITE_TIME_BETWEEN2:
				if(EN_KILLFOCUS==HIWORD(wParam))
				{	if(GetWindowText((HWND)lParam,s,MAX_PATH))
					{	//first 2 char before '.' - hour
						if(s[0] < '0') s[0] = '0';
						if(s[0] > '2') s[0] = '2';
						if(s[1] < '0') s[1] = '0';
						if(s[1] > (s[0]<'2'?'9':'4')) s[1] = s[0]<'2'?'9':'4';
						if(s[2] != '.') s[2] = '.';
						//second 2 char after first '.' - minute
						if(s[3] < '0') s[3] = '0';
						if(s[3] > '6') s[3] = '6';
						if(s[4] < '0') s[4] = '0';
						if(s[4] > (s[3]<'6'?'9':'0')) s[4] = s[3]<'6'?'9':'0';
						if(s[5] != '.') s[5] = '.';
						//third 2 char after second '.' - second
						if(s[6] < '0') s[6] = '0';
						if(s[6] > '6') s[6] = '6';
						if(s[7] < '0') s[7] = '0';
						if(s[7] > (s[6]<'6'?'9':'0')) s[7] = s[6]<'6'?'9':'0';
						if(s[8] != '.') s[8] = '.';
						//last 2 char - millisecond
						if(s[9] < '0') s[9] = '0';
						if(s[9] > '9') s[9] = '9';
						if(s[10] < '0') s[10] = '0';
						if(s[10] > '9') s[10] = '9';
						if(s[11] < '0') s[11] = '0';
						if(s[11] > '9') s[11] = '9';
						s[12] = 0;
						SetWindowText((HWND)lParam,s);
				}	}
				break;
			case IDC_BUTTON_TO_PANEL://hToPanelBTN
				if(hToPanelBTN)
				{	//endDialogCodeToWM_DESTROY=2;
					EndDialog(hDlg,2);
				}
				break;
			case IDC_BUTTON_EDIT:
				break;
			case IDC_BUTTON_VIEW:
				break;
		}
		break;
	case WM_VKEYTOITEM://LBS_WANTKEYBOARDINPUT stylr LB bo'lsa;
		if(0x41==LOWORD(wParam))//VK_A
		{	if(0x8000 & GetKeyState(VK_LCONTROL))
			{	int tot=(int)SendMessage(hResultsLB,LB_GETCOUNT,0,0);
				SendMessage(hResultsLB,LB_SELITEMRANGE,TRUE, MAKELPARAM(0,tot-1));//SendMessage(hResultsLB,LB_SELITEMRANGEEX,0, tot);
				return -2;
		}	}
		else if(VK_DELETE==LOWORD(wParam))
		{	int tot=(int)SendMessage(hResultsLB,LB_GETCOUNT,0,0);
			int totSeltn=(int)SendMessage(hResultsLB,LB_GETSELCOUNT,0,0);
			if(LB_ERR==totSeltn) return -1;//Boshqa oparatsiyasini qilsun LB;
			if(tot==totSeltn)
			{	RECT r;int lr;
				SendMessage(hResultsLB,LB_RESETCONTENT,0,0);
				GetWindowRect(hResultsLB,&r);
				ScreenToClient(hDlg,LPPOINT(&r.left));
				ScreenToClient(hDlg,LPPOINT(&r.right));
				lr=r.bottom-r.top;if(lr>130)lr-=130;
				r.bottom = r.top+130;
				MoveWindow(hResultsLB,r.left,r.top,r.right-r.left,r.bottom-r.top,TRUE);
				GetWindowRect(hDlg,&r);
				HWND prnt;prnt = GetParent(hDlg);
				if(!prnt)prnt=GetDesktopWindow();
				ScreenToClient(prnt,LPPOINT(&r.left));
				ScreenToClient(prnt,LPPOINT(&r.right));
				MoveWindow(hDlg,r.left,r.top,r.right-r.left,r.bottom-r.top-lr,TRUE);
			}
			else if(1==totSeltn)
			{	int sel=(int)SendMessage(hResultsLB,LB_GETCURSEL,0,0);
				if(LB_ERR==sel) return -1;
				SendMessage(hResultsLB,LB_DELETESTRING,sel,0);
				SendMessage(hResultsLB,LB_SETSEL,FALSE,-1);
				SendMessage(hResultsLB,LB_SELITEMRANGE,TRUE,MAKELONG(sel,sel));
				SendMessage(hResultsLB,LB_SETCARETINDEX,sel,TRUE);
			}
			else
			{	int *sels=(int*)malloc(sizeof(int)*totSeltn);
				if(!sels)
				{	MessageBox(hDlg,L"Err. allocating mem.",L"For ListBox control",MB_OK);
					return -1;
				}
				if(LB_ERR!=SendMessage(hResultsLB,LB_GETSELITEMS,totSeltn,(LPARAM)sels))//int crSel=SendMessage(hResultLB,LB_GETCURSEL,0,0);
				{	for(int i=0; i<totSeltn; i++)//boshidan pastga qarab borilsa 1tadan kamaytirib borish kerak,
						SendMessage(hResultsLB,LB_DELETESTRING,sels[i]-i,0);//shu uchun teskarisidan kelamiz:
				}
				SendMessage(hResultsLB,LB_SETSEL,FALSE,-1);
				SendMessage(hResultsLB,LB_SELITEMRANGE,TRUE,MAKELONG(sels[0],sels[0]));
				SendMessage(hResultsLB,LB_SETCARETINDEX,sels[0],TRUE);
				free(sels);
			}
			return -2;
		}
		return -1;
	case WM_NOTIFY:
		NMHDR *lpnmhdr;lpnmhdr = (LPNMHDR)lParam;
		switch(lpnmhdr->idFrom)
		{	case IDC_TAB_FILE_SEACH:
				if(TCN_SELCHANGE == lpnmhdr->code)
				{	int id;
					id = TabCtrl_GetCurSel(GetDlgItem(hDlg,IDC_TAB_FILE_SEACH));
					SetTabPage(hDlg,id);
				}
				break;
			//case IDC_SPIN_FILE_SIZE:
				//OutputDebugString(" IDC_SPIN_FILE_SIZE");
			//	break;
		}
		break;
	case WM_VSCROLL:
		unsigned __int64 szFile;szFile = 0;
		if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_FILE_SIZE))
		{	if(SB_THUMBPOSITION==LOWORD(wParam) || SB_THUMBTRACK==LOWORD(wParam))
			{	if(HIWORD(wParam)>50)
				{	if(GetDlgItemText(hDlg,IDC_EDIT_FILE_SIZE,s,MAX_PATH))
						szFile = MyAtoU64(s);
					MyU64To(s,MAX_PATH,++szFile);//StringCchPrintf(s,MAX_PATH,"%u",++szFile);
					SetDlgItemText(hDlg,IDC_EDIT_FILE_SIZE,s);
				} else
				{	if(GetDlgItemText(hDlg,IDC_EDIT_FILE_SIZE,s,MAX_PATH))
						szFile = MyAtoU64(s);
					if(szFile>0)szFile--;
					MyU64To(s,MAX_PATH,szFile);
					SetDlgItemText(hDlg,IDC_EDIT_FILE_SIZE,s);
			}	}
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_CRTBEF_DAY))
		{	AlignDayFrSpin(hDlg,wParam,IDC_EDIT_CREATE_DATE,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_CRTBEF_MOONS))
		{	AlignMoonFrSpin(hDlg,wParam,IDC_EDIT_CREATE_DATE,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_CRTBEF_YEAR))
		{	AlignYearFrSpin(hDlg,wParam,IDC_EDIT_CREATE_DATE,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_CRTBEF_HOUR))
		{	AlignHourFrSpin(hDlg,wParam,IDC_EDIT_CREATE_DATE2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_CRTBEF_MIN))
		{	AlignMinFrSpin(hDlg,wParam,IDC_EDIT_CREATE_DATE2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_CRTBEF_SEC))
		{	AlignSecFrSpin(hDlg,wParam,IDC_EDIT_CREATE_DATE2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_CRTBEF_MILS))
		{	AlignMilsFrSpin(hDlg,wParam,IDC_EDIT_CREATE_DATE2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_CRTBET_DAY))
		{	AlignDayFrSpin(hDlg,wParam,IDC_EDIT_CREATE_BETWEEN_DATE,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_CRTBET_MOONS))
		{	AlignMoonFrSpin(hDlg,wParam,IDC_EDIT_CREATE_BETWEEN_DATE,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_CRTBET_YEAR))
		{	AlignYearFrSpin(hDlg,wParam,IDC_EDIT_CREATE_BETWEEN_DATE,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_CRTBET_HOUR))
		{	AlignHourFrSpin(hDlg,wParam,IDC_EDIT_CREATE_BETWEEN_TIME,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_CRTBET_MIN))
		{	AlignMinFrSpin(hDlg,wParam,IDC_EDIT_CREATE_BETWEEN_TIME,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_CRTBET_SEC))
		{	AlignSecFrSpin(hDlg,wParam,IDC_EDIT_CREATE_BETWEEN_TIME,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_CRTBET_MILS))
		{	AlignMilsFrSpin(hDlg,wParam,IDC_EDIT_CREATE_BETWEEN_TIME,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_CRBET_DAY))
		{	AlignDayFrSpin(hDlg,wParam,IDC_EDIT_CREATE_BETWEEN_DATE2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_CRBET_MOON))
		{	AlignMoonFrSpin(hDlg,wParam,IDC_EDIT_CREATE_BETWEEN_DATE2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_CRBET_YEAR))
		{	AlignYearFrSpin(hDlg,wParam,IDC_EDIT_CREATE_BETWEEN_DATE2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_CRBET_HOUR))
		{	AlignHourFrSpin(hDlg,wParam,IDC_EDIT_CREATE_BETWEEN_TIME2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_CRBET_MIN))
		{	AlignMinFrSpin(hDlg,wParam,IDC_EDIT_CREATE_BETWEEN_TIME2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_CRBET_SEC))
		{	AlignSecFrSpin(hDlg,wParam,IDC_EDIT_CREATE_BETWEEN_TIME2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_CRBET_MILS))
		{	AlignMilsFrSpin(hDlg,wParam,IDC_EDIT_CREATE_BETWEEN_TIME2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_CRAFT_DAY))
		{	AlignDayFrSpin(hDlg,wParam,IDC_EDIT_CREATE_DATE_AFTER,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_CRAFT_MOON))
		{	AlignMoonFrSpin(hDlg,wParam,IDC_EDIT_CREATE_DATE_AFTER,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_CRAFT_YEAR))
		{	AlignYearFrSpin(hDlg,wParam,IDC_EDIT_CREATE_DATE_AFTER,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_CRAFT_HOUR))
		{	AlignHourFrSpin(hDlg,wParam,IDC_EDIT_CREATE_DATE_AFTER2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_CRAFT_MIN))
		{	AlignMinFrSpin(hDlg,wParam,IDC_EDIT_CREATE_DATE_AFTER2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_CRAFT_SEC))
		{	AlignSecFrSpin(hDlg,wParam,IDC_EDIT_CREATE_DATE_AFTER2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_CRAFT_MILS))
		{	AlignMilsFrSpin(hDlg,wParam,IDC_EDIT_CREATE_DATE_AFTER2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSTBEF_DAY))
		{	AlignDayFrSpin(hDlg,wParam,IDC_EDIT_LAST_ACCESS_DATE,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSTBEF_MOONS))
		{	AlignMoonFrSpin(hDlg,wParam,IDC_EDIT_LAST_ACCESS_DATE,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSTBEF_YEAR))
		{	AlignYearFrSpin(hDlg,wParam,IDC_EDIT_LAST_ACCESS_DATE,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSTBEF_HOUR))
		{	AlignHourFrSpin(hDlg,wParam,IDC_EDIT_LAST_ACCESS_DATE2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSTBEF_MIN))
		{	AlignMinFrSpin(hDlg,wParam,IDC_EDIT_LAST_ACCESS_DATE2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSTBEF_SEC))
		{	AlignSecFrSpin(hDlg,wParam,IDC_EDIT_LAST_ACCESS_DATE2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSTBEF_MILS))
		{	AlignMilsFrSpin(hDlg,wParam,IDC_EDIT_LAST_ACCESS_DATE2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSWTBET_DAY))
		{	AlignDayFrSpin(hDlg,wParam,IDC_EDIT_LAST_WRITE_DATE_BETWEEN,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSWTBET_MOON))
		{	AlignMoonFrSpin(hDlg,wParam,IDC_EDIT_LAST_WRITE_DATE_BETWEEN,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSWTBET_YEAR))
		{	AlignYearFrSpin(hDlg,wParam,IDC_EDIT_LAST_WRITE_DATE_BETWEEN,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSWTBET_HOUR))
		{	AlignHourFrSpin(hDlg,wParam,IDC_EDIT_LAST_WRITE_TIME_BETWEEN,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSWTBET_MIN))
		{	AlignMinFrSpin(hDlg,wParam,IDC_EDIT_LAST_WRITE_TIME_BETWEEN,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSWTBET_SEC))
		{	AlignSecFrSpin(hDlg,wParam,IDC_EDIT_LAST_WRITE_TIME_BETWEEN,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSWTBET_MILS))
		{	AlignMilsFrSpin(hDlg,wParam,IDC_EDIT_LAST_WRITE_TIME_BETWEEN,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSWRBET_DAY))
		{	AlignDayFrSpin(hDlg,wParam,IDC_EDIT_LAST_WRITE_DATE_BETWEEN2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSWRBET_MOON))
		{	AlignMoonFrSpin(hDlg,wParam,IDC_EDIT_LAST_WRITE_DATE_BETWEEN2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSWRBET_YEAR))
		{	AlignYearFrSpin(hDlg,wParam,IDC_EDIT_LAST_WRITE_DATE_BETWEEN2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSWRBET_HOUR))
		{	AlignHourFrSpin(hDlg,wParam,IDC_EDIT_LAST_WRITE_TIME_BETWEEN2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSWRBET_MIN))
		{	AlignMinFrSpin(hDlg,wParam,IDC_EDIT_LAST_WRITE_TIME_BETWEEN2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSWRBET_SEC))
		{	AlignSecFrSpin(hDlg,wParam,IDC_EDIT_LAST_WRITE_TIME_BETWEEN2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSWRBET_MILS))
		{	AlignMilsFrSpin(hDlg,wParam,IDC_EDIT_LAST_WRITE_TIME_BETWEEN2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSAFT_DAY))
		{	AlignDayFrSpin(hDlg,wParam,IDC_EDIT_LAST_ACCESS_DATE_AFTER,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSAFT_MOON))
		{	AlignMoonFrSpin(hDlg,wParam,IDC_EDIT_LAST_ACCESS_DATE_AFTER,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSAFT_YEAR))
		{	AlignYearFrSpin(hDlg,wParam,IDC_EDIT_LAST_ACCESS_DATE_AFTER,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSAFT_HOUR))
		{	AlignHourFrSpin(hDlg,wParam,IDC_EDIT_LAST_ACCESS_DATE_AFTER2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSAFT_MIN))
		{	AlignMinFrSpin(hDlg,wParam,IDC_EDIT_LAST_ACCESS_DATE_AFTER2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSAFT_SEC))
		{	AlignSecFrSpin(hDlg,wParam,IDC_EDIT_LAST_ACCESS_DATE_AFTER2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSAFT_MILS))
		{	AlignMilsFrSpin(hDlg,wParam,IDC_EDIT_LAST_ACCESS_DATE_AFTER2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSTBET_DAY))
		{	AlignDayFrSpin(hDlg,wParam,IDC_EDIT_LAST_ACCESS_DATE_BETWEEN,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSTBET_MOON))
		{	AlignMoonFrSpin(hDlg,wParam,IDC_EDIT_LAST_ACCESS_DATE_BETWEEN,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSTBET_YEAR))
		{	AlignYearFrSpin(hDlg,wParam,IDC_EDIT_LAST_ACCESS_DATE_BETWEEN,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSTBET_HOUR))
		{	AlignHourFrSpin(hDlg,wParam,IDC_EDIT_LAST_ACCESS_TIME_BETWEEN,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSTBET_MIN))
		{	AlignMinFrSpin(hDlg,wParam,IDC_EDIT_LAST_ACCESS_TIME_BETWEEN,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSTBET_SEC))
		{	AlignSecFrSpin(hDlg,wParam,IDC_EDIT_LAST_ACCESS_TIME_BETWEEN,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSTBET_MILS))
		{	AlignMilsFrSpin(hDlg,wParam,IDC_EDIT_LAST_ACCESS_TIME_BETWEEN,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSABET_DAY))
		{	AlignDayFrSpin(hDlg,wParam,IDC_EDIT_LAST_ACCESS_DATE_BETWEEN2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSABET_MOON))
		{	AlignMoonFrSpin(hDlg,wParam,IDC_EDIT_LAST_ACCESS_DATE_BETWEEN2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSABET_YEAR))
		{	AlignYearFrSpin(hDlg,wParam,IDC_EDIT_LAST_ACCESS_DATE_BETWEEN2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSABET_HOUR))
		{	AlignHourFrSpin(hDlg,wParam,IDC_EDIT_LAST_ACCESS_TIME_BETWEEN2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSABET_MIN))
		{	AlignMinFrSpin(hDlg,wParam,IDC_EDIT_LAST_ACCESS_TIME_BETWEEN2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSABET_SEC))
		{	AlignSecFrSpin(hDlg,wParam,IDC_EDIT_LAST_ACCESS_TIME_BETWEEN2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSABET_MILS))
		{	AlignMilsFrSpin(hDlg,wParam,IDC_EDIT_LAST_ACCESS_TIME_BETWEEN2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_DAY))
		{	AlignDayFrSpin(hDlg,wParam,IDC_EDIT_LAST_WRITE_DATE,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_MOON))
		{	AlignMoonFrSpin(hDlg,wParam,IDC_EDIT_LAST_WRITE_DATE,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_YEAR))
		{	AlignYearFrSpin(hDlg,wParam,IDC_EDIT_LAST_WRITE_DATE,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_HOUR))
		{	AlignHourFrSpin(hDlg,wParam,IDC_EDIT_LAST_WRITE_DATE2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_MIN))
		{	AlignMinFrSpin(hDlg,wParam,IDC_EDIT_LAST_WRITE_DATE2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_SEC))
		{	AlignSecFrSpin(hDlg,wParam,IDC_EDIT_LAST_WRITE_DATE2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_MILS))
		{	AlignMilsFrSpin(hDlg,wParam,IDC_EDIT_LAST_WRITE_DATE2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_DAY))
		{	AlignDayFrSpin(hDlg,wParam,IDC_EDIT_LAST_WRITE_DATE_AFTER,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_MOON))
		{	AlignMoonFrSpin(hDlg,wParam,IDC_EDIT_LAST_WRITE_DATE_AFTER,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_YEAR))
		{	AlignYearFrSpin(hDlg,wParam,IDC_EDIT_LAST_WRITE_DATE_AFTER,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_HOUR))
		{	AlignHourFrSpin(hDlg,wParam,IDC_EDIT_LAST_WRITE_DATE_AFTER2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_MIN))
		{	AlignMinFrSpin(hDlg,wParam,IDC_EDIT_LAST_WRITE_DATE_AFTER2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_SEC))
		{	AlignSecFrSpin(hDlg,wParam,IDC_EDIT_LAST_WRITE_DATE_AFTER2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_MILS))
		{	AlignMilsFrSpin(hDlg,wParam,IDC_EDIT_LAST_WRITE_DATE_AFTER2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		break;
	/*case WM_CONTEXTMENU:
		if(wParam==(WPARAM)hResultsLB)
		{	POINT pt;pt.x = LOWORD(lParam);
			pt.y = HIWORD(lParam);
			ScreenToClient(hResultsLB,&pt);
			int r=SendMessage(hResultsLB,LB_ITEMFROMPOINT,0,MAKELONG(pt.x,pt.y));
			r &= 0xffff;
			r=SendMessageA(hResultsLB,LB_GETTEXT,r,(LPARAM)s);
			if(LB_ERR!=r)
			{	//myWMI::TAddtnMenuItems it;
				if(s[0]=='<')
				{	s[r-1]=0;
					//it.pNext = NULL;
					//it.itemStr = s;
					//it.iPan = this-&panel[0];
					//it.iPanItem = id;
					//it.iMsg = IDM_FILE_STREAM;
					DoExplorerMenu(hResultsLB,&s[1],&pt,NULL);//&it);
				}
				else
					DoExplorerMenu(hResultsLB,s,&pt,NULL);//&it);
		}	}
		break;*/
	}
	return (INT_PTR)FALSE;
}

__declspec (dllexport) LPVOID ShowSearchDlg$12(PluginObj *plg, HWND prnt, wchar_t *path)
{
	MyStringCpy(initPath,MAX_PATH-1,path);
	search.plgnObj = plg;
#ifdef _WIN64
HMODULE hm = LoadLibrary(L"MyShell64.dll");
#else
HMODULE hm = LoadLibrary(L"MyShell.dll");
#endif
	if(2==DialogBox(hm,MAKEINTRESOURCE(IDD_DIALOG_SEACH_VIA_F7),prnt,FindFileDlgProc))//plgnDllInst
		return search.LBListBuf;
	//else:
	return NULL;
}

VOID GetFindData(MY_WIN32_FIND_DATA *p,int i)
{	if(i<findDataPtr)
		*p = findData[i];
	else
		ZeroMemory(p,sizeof(MY_WIN32_FIND_DATA));
}

TSearch::TSearch():LBListBuf(NULL)
{
}

TSearch::~TSearch()
{
	if(LBListBuf) free(LBListBuf);
	LBListBuf=NULL;
}

TSearchItem::TSearchItem():bFindForText(FALSE),FindForTextLn(0),
	bFindForText_Unicode(FALSE),bFindForText_ASCII(FALSE),
	bFindForText_UpperCase(FALSE),bFindForExcldText(FALSE),
	FindForExcldTextLn(0),bFindForExcldText_Unicode(FALSE),
	bFindForExcldText_ASCII(FALSE),bFindForExcldText_UpperCase(FALSE),
	bFindForAlterName(FALSE),bCrTimeBef(FALSE),bCrTimeAft(FALSE),
	bCrTimeBet(FALSE),bLastAccTimeBet(FALSE),bLstAccTimeBef(FALSE),
	bLstAccTimeAft(FALSE),bLstWrTimeBef(FALSE),bLstWrTimeAft(FALSE),
	bLstWrTimeBet(FALSE),bFileSz(FALSE),iFileSzQual(0),
	bFileAttr(FALSE),bFileAttArchive(FALSE),bFileAttCompr(FALSE),
	bFileAttDevice(FALSE),bFileAttDir(FALSE),bFileAttEncr(FALSE),
	bFileAttHidden(FALSE),bFileAttNormal(FALSE),bFileAttNotInd(FALSE),
	bFileAttOffl(FALSE),bFileAttReadOnly(FALSE),bFileAttRepPt(FALSE),
	bFileAttSparseFile(FALSE),bFileAttSys(FALSE),bFileAttTemp(FALSE),
	bFileAttVirt(FALSE)
{
	filtr[0]=0;
	rootPath[0]=0;
	FindForText[0]=0;
	FindForExcldText[0]=0;
	altName[0]=0;
	altNameW[0]=0;
	GetSystemTimeAsFileTime(&CrTimeBef);
	GetSystemTimeAsFileTime(&CrTimeAft);
	GetSystemTimeAsFileTime(&CrTimeBet[0]);
	GetSystemTimeAsFileTime(&CrTimeBet[1]);
	GetSystemTimeAsFileTime(&LstAccTimeBef);
	GetSystemTimeAsFileTime(&LstAccTimeAft);
	GetSystemTimeAsFileTime(&LastAccTimeBet[0]);
	GetSystemTimeAsFileTime(&LastAccTimeBet[1]);
	GetSystemTimeAsFileTime(&LstWrTimeBef);
	GetSystemTimeAsFileTime(&LstWrTimeAft);
	GetSystemTimeAsFileTime(&LstWrTimeBet[0]);
	GetSystemTimeAsFileTime(&LstWrTimeBet[1]);
	sFileSzEqu[0]=0;
	sFileSz[0]=0;
}

VOID TSearch::SaveLBListBuf(HWND hLB)
{
	//1.Calc the size:
/*	int sz=sizeof(int);
	int iLBCnt=SendMessage(hLB,(UINT)LB_GETCOUNT,0,0);
	if(LB_ERR==iLBCnt) return;
	for(int i=0; i<iLBCnt; i++)
		sz += 1+SendMessage(hLB,(UINT)LB_GETTEXTLEN,i,0);
	sz += 2;//for double null termination;
	//2.Allocateing buffer:
	if(LBListBuf)LBListBuf=(char*)realloc(LBListBuf,sz);
	else LBListBuf = (char*)malloc(sz);
	//3.Fill memory:
	char *pBuf = (char*)LBListBuf;
	*((int*)(pBuf))=iLBCnt;
	pBuf+=sizeof(int);
	for(int i=0; i<iLBCnt; i++)
	{	int r = SendMessage(hLB,(UINT)LB_GETTEXT,i,(LPARAM)pBuf);
		if(LB_ERR==r) break;
		pBuf += r+1;
		if(pBuf>=LBListBuf+sz)break;
	}
	*pBuf++ = 0;
	*pBuf = 0;*/

	//Yangi modifikatsiya: 1 ta string, 1ta WIN32_FIND_DATA, oxirida string o'rnida 0 b-n tugaydu:
	int sz=sizeof(int);
	int iLBCnt=(int)SendMessage(hLB,(UINT)LB_GETCOUNT,0,0);
	if(LB_ERR==iLBCnt) return;
	for(int i=0; i<iLBCnt; i++)
		sz += sizeof(wchar_t)*(1+(int)SendMessage(hLB,(UINT)LB_GETTEXTLEN,i,0));
	sz += sizeof(wchar_t)*2;//for double null termination;

	sz += iLBCnt * sizeof(MY_WIN32_FIND_DATA);
	
	//2.Allocateing buffer:
	if(LBListBuf)LBListBuf=(wchar_t*)realloc(LBListBuf,sz);
	else LBListBuf = (wchar_t*)malloc(sz);
	//3.Fill memory:
	wchar_t *pBuf = (wchar_t*)LBListBuf;
	*((int*)(pBuf))=iLBCnt;
	pBuf+=sizeof(int);
	for(int i=0; i<iLBCnt; i++)
	{	int r = (int)SendMessage(hLB,(UINT)LB_GETTEXT,i,(LPARAM)pBuf);
		if(LB_ERR==r) break;
		pBuf += r+1;

		GetFindData((MY_WIN32_FIND_DATA*)pBuf,i);
		pBuf += sizeof(MY_WIN32_FIND_DATA);

		if(pBuf>=LBListBuf+sz)break;
	}
	*pBuf++ = 0;
	*pBuf = 0;
}

VOID TSearch::LoadLBList(HWND hLB)
{
	//1.Calc the size:
	wchar_t *pBuf = LBListBuf;
	int *cnt = (int*)pBuf;
	pBuf += sizeof(int);
	for(int i=0; i<(*cnt); i++)
	{	if(LB_ERR==SendMessageW(hLB,(UINT)LB_ADDSTRING,0,(LPARAM)pBuf))break;
		pBuf += lstrlenW(pBuf)+sizeof(MY_WIN32_FIND_DATA)+1;
}	}

}//extern "C"
