#pragma once 
#include "windows.h"
#include "Cabinet C++ Project 14.0/Cabinet/Extract.hpp"


using namespace Cabinet;



extern CExtract::kCallbacks k_MyEnumExtrCallbacks,k_MyUnpExtrCallbacks,k_MySearchCallbacks;
extern CCompress::kCallbacks k_MyAddCmprsCallbacks,k_MyCrDirCmprsCallbacks;

extern wchar_t startDir[MAX_PATH];//Sino start dir;
//extern char *enumDirBuf;
//extern long enumDirBufSz;

extern void DestroyEnumDirBuf();
extern void ResetEnumDirBuf();


