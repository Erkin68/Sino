#include "windows.h"
#include "strsafe.h"
#include "resource.h"
#include "Plugins_C.h"
#include "MyCallbacks.h"
#include "Cabinet C++ Project 14.0/Cabinet/Static.hpp" //as cpp function call
#include "..\..\..\Operations\MyShell\MyShell.h"


using namespace Cabinet;


extern "C" {
extern wchar_t **strngs;
extern int plgId;
extern HMODULE plgnDllInst;
extern unsigned __int64 sysRAMSIZE;
extern unsigned __int64 sysPAGEFILESIZE;

extern void msg(HWND,DWORD,LPTSTR,LPTSTR);

//INT_PTR CALLBACK ExstngActnDlgProc(HWND,UINT,WPARAM,LPARAM);

typedef void (*UnpackProgressRoutine_t)(unsigned __int64,unsigned __int64,wchar_t*);

checkFileInSelctn_t checkFileInSelctn;
excldFileFrSelctn_t excldFileFrSelctn;
getFileInfoFromSelection_t getFileInfoFromSelection;
prgrssRout_t prgrssRout;
showDlgOverwriteExistFile_t showDlgOverwriteExistFile;
saveOptions_t saveOptions;
readOptions_t readOptions;
addItemToPanelList_t addItemToPanelList;

OPT opt;

wchar_t* GetMyTempPath()
{
	if(IsDirExist(opt.pth))
		return opt.pth;
	if(readOptions)readOptions(plgId,&opt,sizeof(OPT));
	if(IsDirExist(opt.pth))
		return opt.pth;
	GetTempPath(MAX_PATH-1,opt.pth);
	return opt.pth;
}

VOID SaveOldCab(PluginObj *plg,wchar_t *cabName)//Append qilganda eskisini tempga ochib tashlab qo'yish:
{
	int l = MyStringCpy(plg->tmpdir,MAX_PATH-1,GetMyTempPath());
	wchar_t *p = &plg->tmpdir[l];
	int tt=0;do
	{	StringCchPrintfW(p,MAX_PATH-l,L"%d",tt);
		++tt;
	}while(IsDirExist(plg->tmpdir));
	MyStringCat(plg->tmpdir,MAX_PATH-1,L"\\");
	CreateDirectory(plg->tmpdir,0);
	CStrW wTargetDir(plg->tmpdir);
	CExtract extract;
	extract.CreateFDIContext();
	extract.SetCallbacks(&k_MyUnpExtrCallbacks);
	extract.iOptn = 2;//UTF;
	LPVOID par[7]={NULL,plg,plg->tmpdir,"",FALSE,0,0};
	CStrW oldCab(cabName);
	extract.ExtractFileW(oldCab,wTargetDir,par);
	*wcsrchr(plg->tmpdir,'\\')=0;
}

BOOL MyAddFolder(LPVOID *plg,CCompress *cmprs,CStrW sw_Path, const CStrW& sw_Filter=L"*.*",
				 CCompress::eCompress e_Compress=CCompress::E_ComprLZX, int s32_BaseLen=-1)
{
    CFile::TerminatePathW(sw_Path);

    int s32_Len = sw_Path.Len();
    if (s32_BaseLen < 0) 
        s32_BaseLen = s32_Len;

    sw_Path += sw_Filter;

    WIN32_FIND_DATAW k_Find;
    HANDLE h_File = FindFirstFileW(sw_Path, &k_Find);

    if (h_File == INVALID_HANDLE_VALUE)
    {
        //DWORD u32_Err = GetLastError();
        //if (u32_Err == ERROR_FILE_NOT_FOUND)
        //   return TRUE; // The folder is empty

		//((PluginObj*)plg)->compress->mi_Error.Set(0, u32_Err, 0);
        return FALSE;
    }

    CStrW sw_File; int addFiles=0;
    do
    {
        // skip directories "." and ".." but do not skip a diretory ".NET"
        if (k_Find.cFileName[0] == '.' && 
            k_Find.cFileName[1] == 0)
            continue;

        if (k_Find.cFileName[0] == '.' && 
            k_Find.cFileName[1] == '.' && 
            k_Find.cFileName[2] == 0)
            continue;

        sw_File = sw_Path;
        sw_File[s32_Len] = 0;
        sw_File += k_Find.cFileName;

        if (k_Find.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)
        {   if(!MyAddFolder(plg,((PluginObj*)plg)->compress,sw_File, sw_Filter, e_Compress, s32_BaseLen))
            {   //FindClose(h_File);return FALSE; bu uniki,maniki pastdagisi:
				//Quruq direktoriyaning o'zini tiqamiz:
				//if(cmprs->AddFileW(sw_File, (WCHAR*)sw_File + s32_BaseLen, e_Compress))
				//	++addFiles;
			}
			else ++addFiles;
		}
        else
        {	((PluginObj*)plg)->cmprsPar[0]=sw_Path;
			((PluginObj*)plg)->cmprsPar[1]=(WCHAR*)sw_File + s32_BaseLen;
			((PluginObj*)plg)->cmprsPar[2]=(LPVOID)9;//compress_level;
			((PluginObj*)plg)->cmprsPar[3]=(LPVOID)FALSE;//bExcldPath;
			((PluginObj*)plg)->cmprsPar[4]=&k_Find;
			((PluginObj*)plg)->cmprsPar[6]=0;//size64 0
			((PluginObj*)plg)->cmprsPar[7]=0;//size64 1
			if(cmprs->AddFileW(sw_File, (WCHAR*)sw_File + s32_BaseLen, e_Compress))
            {	++addFiles;
                //FindClose(h_File);
                //return FALSE;
            }
        }
    }
    while (FindNextFileW(h_File, &k_Find));

    FindClose(h_File);
	return addFiles > 0 ? TRUE : FALSE;
}

VOID AppendOldCab(PluginObj *plg)
{
	plg->cmprsPar[0]=plg->tmpdir;
	plg->cmprsPar[1]="";
	plg->cmprsPar[2]=(LPVOID)7;
	plg->cmprsPar[3]=(LPVOID)0;
	plg->cmprsPar[4]=0;//&ff;
	plg->cmprsPar[6]=0;//size64 0
	plg->cmprsPar[7]=0;//size64 1
	CStrW sw(L"*");
	CStrW addfw(plg->tmpdir);
	MyAddFolder((LPVOID*)plg,((PluginObj*)plg)->compress,addfw,sw,
							 plg->cmprsOptn.method==0 ? CCompress::E_ComprNONE : 
						   (plg->cmprsOptn.method==1 ? CCompress::E_ComprMSZIP : CCompress::E_ComprLZX));
	SHFILEOPSTRUCT fo; fo.hwnd = NULL;
	plg->tmpdir[1+MyStringLength(plg->tmpdir,MAX_PATH)]=0;
	fo.wFunc = FO_DELETE;
	fo.pFrom = plg->tmpdir;
	fo.fFlags = FOF_SILENT | FOF_NOCONFIRMATION | FOF_NOERRORUI | FOF_NOCONFIRMMKDIR;
	SHFileOperation(&fo);
}

__declspec (dllexport) LPVOID Open$12(wchar_t *name,BOOL bCreateNew,LPVOID host)
{
int nameLn;PluginObj *plg=(PluginObj*)malloc(sizeof(PluginObj));
wchar_t s[MAX_PATH];int l,t=0;

	if(!plg)
	{	msg(NULL,0,strngs[1]/*"Err.opening zip file."*/,name);//"error %d with zipfile in unzGetGlobalInfo \n",err);
		return NULL;
	}
	plg->bools=0;
	plg->host = host;
	nameLn=MyStringCpy(plg->comprsFileName,MAX_PATH,name);
	wchar_t *p=wcsrchr(plg->comprsFileName,'.');
	if(!((*(p+1)=='c' || *(p+1)=='C') && (*(p+2)=='a' || *(p+2)=='A') && (*(p+3)=='b' || *(p+3)=='B')))
		{*(p+1)='c'; *(p+2)='a'; *(p+3)='b';}


	p=wcsrchr(name,'\\');wchar_t *pp=wcsrchr(name,'/');
	if(!p)p=pp;
	else if(p<pp)p=pp;
	if(!p)p=name;else ++p;
	plg->bUTF=0;
	for(wchar_t *pp=p;*pp;)
	{	if(*pp++ > 255)
		{	plg->bUTF=1;
			break;
	}	}

	if(!bCreateNew)
	{	if(IsFileExist(name))
		{	SaveOldCab(plg,name);
			DeleteFile(name);
		}
		else bCreateNew=FALSE;
	}

	l=MyStringCpy(s,MAX_PATH-1,name);
	p = wcsrchr(s,'\\');
	if(p) ++p;
	else p = &s[0];
	do
	{	StringCchPrintf(p,MAX_PATH-l-1,L"%d.cab",t++);
	} while(IsFileExist(s));
	plg->comprsFileNameStrW = new CStrW(s);
	
	plg->compress = new CCompress;
	if(!plg->compress->CreateFCIContextW(*plg->comprsFileNameStrW,TRUE,TRUE,0xFFFFFFFF,0,plg))
	{	delete plg->comprsFileNameStrW;
		delete plg->compress;
		free(plg);
		return NULL;
	}
	if(readOptions)readOptions(plgId,&opt,sizeof(OPT));
	plg->compress->SetCallbacks(&k_MyAddCmprsCallbacks);
	plg->compress->SetTempDirectoryW(GetMyTempPath());

	plg->packType=PluginObj::pack;//Close uchun;
	plg->bAppend = bCreateNew?0:1;
	plg->password[0]=0;
	plg->cmprsOptn.method = opt.optn[0];
	return plg;
}

__declspec (dllexport) int GetPluginType()
{
	return 1;
}

__declspec (dllexport) const wchar_t* GetPluginDescription()
{
	return strngs[65];//L"Sino cab-extraction plugin version 1.1";
}

__declspec (dllexport) const wchar_t* GetPluginName()
{
	return strngs[1];
}

__declspec (dllexport) const wchar_t *GetArchExtnsn()
{
	return L"cab";
}

INT_PTR CALLBACK optnDlg(HWND hDlg,UINT message,WPARAM wParam,LPARAM lParam)
{
RECT rc;
int width,left,height,top;
	UNREFERENCED_PARAMETER(lParam);
	switch(message)
	{
	case WM_INITDIALOG:
		GetWindowRect(hDlg, &rc);
		width = rc.right - rc.left;		
		left = (GetSystemMetrics(SM_CXFULLSCREEN) - width)/2;
		height = rc.bottom - rc.top;
		top = (GetSystemMetrics(SM_CYFULLSCREEN) - height)/2;
		MoveWindow(hDlg, left, top+20, width, height, TRUE);		
		SendMessageW(GetDlgItem(hDlg,IDC_COMBO_COMPRESS_METHOD),CB_INSERTSTRING,(WPARAM)-1,(LPARAM)L"uncompressed");
		SendMessageW(GetDlgItem(hDlg,IDC_COMBO_COMPRESS_METHOD),CB_INSERTSTRING,(WPARAM)-1,(LPARAM)L"zip");
		SendMessageW(GetDlgItem(hDlg,IDC_COMBO_COMPRESS_METHOD),CB_INSERTSTRING,(WPARAM)-1,(LPARAM)L"lzx");
		if(readOptions && readOptions(plgId,&opt,sizeof(opt)))
		{	SendMessageW(GetDlgItem(hDlg,IDC_COMBO_COMPRESS_METHOD),CB_SETCURSEL,opt.optn[0],0);
			SetDlgItemText(hDlg,IDC_EDIT_TEMP_PATH,opt.pth);
		}
		else
		{	SendMessageW(GetDlgItem(hDlg,IDC_COMBO_COMPRESS_METHOD),CB_SETCURSEL,0,0);
			GetTempPath(MAX_PATH-1,opt.pth);
			SetDlgItemText(hDlg,IDC_EDIT_TEMP_PATH,opt.pth);
		}
		SetWindowText(hDlg,strngs[66]);
		SetDlgItemText(hDlg,IDC_STATIC1,strngs[67]);
		SetDlgItemText(hDlg,IDC_STATIC2,strngs[68]);
		SetDlgItemText(hDlg,IDC_STATIC3,strngs[69]);
		SetDlgItemText(hDlg,IDOK,strngs[29]);
		SetDlgItemText(hDlg,IDCANCEL,strngs[30]);
		SetDlgItemText(hDlg,IDC_BUTTON_BROWSE_TEMP_PATH,strngs[0]);		
		return TRUE;
	case WM_COMMAND:
		switch(LOWORD(wParam))
		{	case IDC_BUTTON_BROWSE_TEMP_PATH:BROWSEINFO bi;LPCITEMIDLIST pidlRoot,pidlSelected;
				pidlRoot = NULL;
				bi.hwndOwner = hDlg;
				bi.pszDisplayName = opt.pth;
				bi.lpszTitle = L"Get temporary directory path for cab processing...";
				bi.ulFlags = BIF_NONEWFOLDERBUTTON|BIF_DONTGOBELOWDOMAIN|BIF_NEWDIALOGSTYLE|
							 BIF_NOTRANSLATETARGETS|BIF_RETURNFSANCESTORS;
				bi.lpfn = NULL;
				bi.pidlRoot = pidlRoot;
				pidlSelected = SHBrowseForFolder(&bi);
				if(pidlRoot)
					CoTaskMemFree((LPVOID)pidlRoot);
				if(pidlSelected)
				{	SHGetPathFromIDList(pidlSelected,opt.pth);
					SetDlgItemText(hDlg,IDC_EDIT_TEMP_PATH,opt.pth);
					CoTaskMemFree((LPVOID)pidlSelected);
				}
				return (INT_PTR)TRUE;
			case IDOK:
				opt.optn[0]=(int)SendMessageW(GetDlgItem(hDlg,IDC_COMBO_COMPRESS_METHOD),CB_GETCURSEL,0,0);
				GetDlgItemText(hDlg,IDC_EDIT_TEMP_PATH,opt.pth,MAX_PATH);
				if(!IsDirExist(opt.pth))
				{	MessageBox(hDlg,opt.pth,L"This directory is not exist",MB_OK);
					return (INT_PTR)TRUE;
				}
				if(saveOptions)
				  saveOptions(plgId,&opt,sizeof(OPT));
				EndDialog(hDlg,0);
				return (INT_PTR)TRUE;
			case IDCANCEL:
				EndDialog(hDlg,0);
				return (INT_PTR)TRUE;
		}
		break;
	}
	return (INT_PTR)FALSE;
}

__declspec (dllexport) VOID ShowOptionDialog(HWND prnt)
{
	int r = (int)DialogBox(plgnDllInst,MAKEINTRESOURCE(IDD_DIALOG_OPTIONS),prnt,optnDlg);
}

__declspec (dllexport) BOOL Add$24(PluginObj *plg,wchar_t *FullPathAndName,wchar_t *RelatedPathAndName,
								   wchar_t *password,int compress_level,BOOL bExcldPath)
{
WIN32_FIND_DATA ff;HANDLE h=FindFirstFile(FullPathAndName,&ff);
if(INVALID_HANDLE_VALUE==h) return FALSE;
	FindClose(h);
	if(password && password[0])
		plg->compress->SetEncryptionKey(password,MyStringLength(password,MAX_PATH-1));

	//if(0==plg->bAppend)
	{	plg->cmprsPar[0]=FullPathAndName;
		plg->cmprsPar[1]=RelatedPathAndName;
		plg->cmprsPar[2]=(LPVOID)compress_level;
		plg->cmprsPar[3]=(LPVOID)bExcldPath;
		plg->cmprsPar[4]=&ff;
		plg->cmprsPar[6]=0;//size64 0
		plg->cmprsPar[7]=0;//size64 1
		CStrW sw(RelatedPathAndName);
		CStrW addfw(FullPathAndName);
		plg->compress->AddFileW(addfw,sw,plg->cmprsOptn.method==0 ? CCompress::E_ComprNONE : 
							   (plg->cmprsOptn.method==1 ? CCompress::E_ComprMSZIP : CCompress::E_ComprLZX));
	}
	return TRUE;
}

__declspec (dllexport) BOOL CreateDir$24(PluginObj *plg,wchar_t *FullPathAndName,
										 wchar_t *RelatedPathAndName,
										 wchar_t *password,int compress_level,BOOL bExcldPath)
{
	if(plg->bAppend)
	{	wchar_t s[MAX_PATH];int l=MyStringCpy(s,MAX_PATH-1,plg->tmpdir);
		if('\\'!=s[l-1])s[l++]='\\';
		l += MyStringCpy(&s[l],MAX_PATH-1,RelatedPathAndName);
		CreateDirectory(s,NULL);
		//Yana 1 ta fayl ham taxlab qo'yamiz,chunki dir pustoy b-sa yaratmaydur;
		s[l++]='\\';
		MyStringCpy(&s[l],MAX_PATH-l,L"tmp");
		CloseHandle(CreateFile(s,GENERIC_WRITE,FILE_SHARE_WRITE,NULL,CREATE_ALWAYS,FILE_ATTRIBUTE_TEMPORARY,NULL));
	}
	return TRUE;//direktoriya cabga kerak emas;
}

__declspec (dllexport) BOOL RenameDir$12(PluginObj *plg,wchar_t *FName,wchar_t *FNewName)
{
	if(PluginObj::pack!=plg->packType)return FALSE;
	if(plg->bAppend)
	{	wchar_t s[MAX_PATH],to[MAX_PATH],*p;SHFILEOPSTRUCTW fo;
		int l=MyStringCpy(s,MAX_PATH-1,plg->tmpdir);
		if('\\'!=s[l-1])s[l++]='\\';
		l += MyStringCpy(&s[l],MAX_PATH-1,FName);
		s[l+1]=0;
		MyStringCpy(to,l,s);
		p=wcsrchr(to,'\\');
		if(p)++p;
		else p=&to[l];
		l=MyStringCpy(p,MAX_PATH-1,FNewName);
		l+=(int)(p-&to[0]);
		to[l+1]=0;
		fo.hwnd=NULL;
		fo.wFunc = FO_RENAME;
		fo.pFrom = s;
		fo.pTo = to;
		fo.fFlags = FOF_SILENT | FOF_NOCONFIRMATION | FOF_NOERRORUI | FOF_NOCONFIRMMKDIR;
		if(SHFileOperationW(&fo))
		{	l=GetLastError();
			++l;
	}	}
	return TRUE;
}

__declspec (dllexport) BOOL RenameFile$12(PluginObj *plg,wchar_t *FName,wchar_t *FNewName)
{
	if(PluginObj::pack!=plg->packType)return FALSE;
	if(plg->bAppend)
	{	wchar_t s[MAX_PATH],to[MAX_PATH],*p;SHFILEOPSTRUCTW fo;
		int l=MyStringCpy(s,MAX_PATH-1,plg->tmpdir);
		if('\\'!=s[l-1])s[l++]='\\';
		l += MyStringCpy(&s[l],MAX_PATH-1,FName);
		s[l+1]=0;
		MyStringCpy(to,l,s);
		p=wcsrchr(to,'\\');
		if(p)++p;
		else p=&to[l];
		l=MyStringCpy(p,MAX_PATH-1,FNewName);
		l+=(int)(p-&to[0]);
		to[l+1]=0;
		fo.hwnd=NULL;
		fo.wFunc = FO_RENAME;
		fo.pFrom = s;
		fo.pTo = to;
		fo.fFlags = FOF_SILENT | FOF_NOCONFIRMATION | FOF_NOERRORUI | FOF_NOCONFIRMMKDIR;
		if(SHFileOperationW(&fo))
		{	l=GetLastError();
			++l;
	}	}
	return TRUE;
}

__declspec (dllexport) BOOL DeleteFile$8(PluginObj *plg,wchar_t *FName)
{
	if(PluginObj::pack!=plg->packType)return FALSE;
	if(plg->bAppend)
	{	wchar_t s[MAX_PATH];int l=MyStringCpy(s,MAX_PATH-1,plg->tmpdir);
		if('\\'!=s[l-1])s[l++]='\\';
		l += MyStringCpy(&s[l],MAX_PATH-1,FName);
		DeleteFile(s);
	}
	return TRUE;
}

__declspec (dllexport) BOOL DeleteDir$8(PluginObj *plg,wchar_t *FName)
{
	if(PluginObj::pack!=plg->packType)return FALSE;
	if(plg->bAppend)
	{	wchar_t s[MAX_PATH];SHFILEOPSTRUCT fo;
		int l=MyStringCpy(s,MAX_PATH-1,plg->tmpdir);
		if('\\'!=s[l-1])s[l++]='\\';
		l += MyStringCpy(&s[l],MAX_PATH-1,FName);
		s[l+1]=0;
		fo.hwnd=NULL;
		fo.wFunc = FO_DELETE;
		fo.pFrom = s;
		fo.fFlags = FOF_SILENT | FOF_NOCONFIRMATION | FOF_NOERRORUI | FOF_NOCONFIRMMKDIR;
		SHFileOperation(&fo);
	}
	return TRUE;
}

__declspec (dllexport) void SetId$4(int id)
{
	plgId = id;
	if(readOptions)readOptions(id,&opt,sizeof(OPT));
}

__declspec (dllexport) VOID SetCallbacks$4xxx(LPVOID frstCallback,...)
{
va_list args;
	va_start(args, frstCallback);//1
	checkFileInSelctn = (checkFileInSelctn_t)frstCallback;//2
	excldFileFrSelctn = (excldFileFrSelctn_t)va_arg(args, LPVOID);//3
	getFileInfoFromSelection = (getFileInfoFromSelection_t)va_arg(args, LPVOID);//4
	prgrssRout = (prgrssRout_t)va_arg(args, LPVOID);//5
	showDlgOverwriteExistFile = (showDlgOverwriteExistFile_t)va_arg(args, LPVOID);//6
	saveOptions = (saveOptions_t)va_arg(args, LPVOID);//7
	readOptions = (readOptions_t)va_arg(args, LPVOID);//8
	addItemToPanelList = (addItemToPanelList_t)va_arg(args, LPVOID);//9
va_end (args);
}

__declspec (dllexport) LPVOID OpenForUnpacking$8(wchar_t *name,LPVOID host)//host - CArc;
{
int nameLn;PluginObj *plg;WIN32_FIND_DATA ff;HANDLE h;
	h=FindFirstFile(name,&ff);
	if(INVALID_HANDLE_VALUE==h)return NULL;
	FindClose(h);
	plg=(PluginObj*)malloc(sizeof(PluginObj));
	if(!plg)
	{	msg(NULL,0,strngs[1]/*"Err.opening zip file."*/,name);//"error %d with zipfile in unzGetGlobalInfo \n",err);
		return NULL;
	}
	plg->bools=0;
	nameLn=MyStringCpy(plg->extrctFileName,MAX_PATH,name);
	plg->extrctFileNameStrW = new CStrW(name);
	plg->host = host;
	plg->packType=PluginObj::unpack;//Close uchun;
	return plg;
}

__declspec (dllexport) BOOL RebuildCheckExistings$8(PluginObj *plg,wchar_t *password)
{
	return TRUE;
}

__declspec (dllexport) BOOL EnumDirectory$8(PluginObj *plg,wchar_t *DirName)
{
char dirName[MAX_PATH];
WideCharToMultiByte(AreFileApisANSI()?CP_ACP:CP_OEMCP,WC_COMPOSITECHECK,DirName,-1,dirName,MAX_PATH-1,NULL,NULL);
	LPVOID par[2]={plg,dirName};//enumDir
	CExtract extract;
	//plg->codePage = extract.mu32_Codepage;
	extract.CreateFDIContext();
	extract.SetCallbacks(&k_MyEnumExtrCallbacks);
	extract.iOptn = 1;//enum
	extract.ExtractFileW(*plg->extrctFileNameStrW,startDir,par);
	ResetEnumDirBuf();
	return TRUE;
}

//Autonom thread bo'lgani uchun, alohida klass beramiz:
__declspec (dllexport) BOOL Unpack$28(HWND prntDlg,PluginObj *plg,wchar_t *destDirName,wchar_t *arjDirAndName,
									  BOOL* bCancel,UnpackProgressRoutine_t lpprgs,__int32 *bOverwriteBits)
{
wchar_t *p;
char ArjDirAndName[MAX_PATH];
LPVOID par[7]={prntDlg,plg,destDirName,ArjDirAndName,bCancel,lpprgs,bOverwriteBits};
WideCharToMultiByte(AreFileApisANSI()?CP_ACP:CP_OEMCP,WC_COMPOSITECHECK,arjDirAndName,-1,ArjDirAndName,MAX_PATH-1,NULL,NULL);
	p=wcsrchr(destDirName,'\\'); if(p)*(p+1)=0;
	CStrW wTargetDir(destDirName);
	CExtract extract;
	extract.CreateFDIContext();
	extract.SetCallbacks(&k_MyUnpExtrCallbacks);
	extract.iOptn = 2;//UTF;
	extract.ExtractFileW(*plg->extrctFileNameStrW,wTargetDir,par);
	if(p)*(p+1)='\\';//obyazatekmno
	return TRUE;
}

__declspec (dllexport) int GetTotalCryptMethods()
{
	return 1;
}

__declspec (dllexport) const wchar_t* GetCryptDescription$4(int cryptNum)
{
	switch(cryptNum)
	{	case 0:default:
			return L"Sino exe-32 modified version of crypting code";
	}
	return L"";
}

/*INT_PTR CALLBACK ExstngActnDlgProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
static HFONT hf=0;
static int hfRef=0;//obshiy hf, dinamik uchun emas:
static HBRUSH br=0;
static HBRUSH brHtBk=0;
static int endDialogCodeToWM_DESTROY;
int width,left,height,top;FILETIME ft;SYSTEMTIME st;
wchar_t s[MAX_PATH];UINT uStyle;LPVOID *pars;
RECT r;HDC dc;LPDRAWITEMSTRUCT lpdis;
WIN32_FIND_DATA ff;HANDLE h;
UNREFERENCED_PARAMETER(lParam);
	switch (message)
	{
	case WM_INITDIALOG:
		GetWindowRect(hDlg, &r);
		width = r.right - r.left;
		height = r.bottom - r.top;
		left=(GetSystemMetrics(SM_CXSCREEN) - width )/2;
		top =(GetSystemMetrics(SM_CYSCREEN) - height)/2;
		MoveWindow(hDlg, left, top+20, width, height, TRUE);
		SetWindowText(hDlg,strngs[21]);
		SetDlgItemText(hDlg,IDC_STATIC8,strngs[2]);//"Existing file in disk:"
		SetDlgItemText(hDlg,IDC_STATIC5,strngs[3]);//"File in archive:"
		SetDlgItemText(hDlg,IDC_STATIC1,strngs[4]);//"Size in bytes:"
		SetDlgItemText(hDlg,IDC_STATIC3,strngs[4]);//"Size in bytes:"
		SetDlgItemText(hDlg,IDC_STATIC2,strngs[5]);//"Write time:"
		SetDlgItemText(hDlg,IDC_STATIC4,strngs[5]);//"Write time:"
		SetDlgItemText(hDlg,IDC_STATIC7,strngs[6]);//"Size in bytes:"
		SetDlgItemText(hDlg,IDC_STATIC6,strngs[7]);//"Rename"
		SetDlgItemText(hDlg,IDC_CHECK_OVERWRITE_LATEST_AUTO,strngs[8]);//"Overwrite latest in future"
		SetDlgItemText(hDlg,IDC_CHECK_OVERWRITE_OLDEST_AUTO,strngs[9]);//"Overwrite oldest in future"
		SetDlgItemText(hDlg,IDC_CHECK_OVERWRITE_BIGGEST_AUTO,strngs[10]);//"Overwrite biggest in future"
		SetDlgItemText(hDlg,IDC_CHECK_RENAME_AUTO,strngs[11]);//"Auto rename in future"
		SetDlgItemText(hDlg,IDC_CHECK_SKIP_AUTO,strngs[12]);//"Skip in future"		 
		SetDlgItemText(hDlg,IDC_CHECK_OVERWRITE_AUTO,strngs[13]);//"Overwrite in future"		 
		SetDlgItemText(hDlg,IDC_CHECK_OVERWRITE_BIGGEST_AUTO2,strngs[14]);//"Overwrite littlest in future"
		SetDlgItemText(hDlg,IDC_BUTTON_OVERWRITE_LATEST,strngs[15]);//"Overwrite latest"
		SetDlgItemText(hDlg,IDC_BUTTON_OVERWRITE_OLDEST,strngs[16]);//"Overwrite oldest"
		SetDlgItemText(hDlg,IDC_BUTTON_OVERWRITE_BIGGEST,strngs[17]);//"Overwrite biggest"
		SetDlgItemText(hDlg,IDC_BUTTON_RENAME,strngs[7]);//"Rename"
		SetDlgItemText(hDlg,IDC_BUTTON_SKIP,strngs[18]);//"Skip"
		SetDlgItemText(hDlg,IDC_BUTTON_OVERWRITE,strngs[19]);//"Overwrite"
		SetDlgItemText(hDlg,IDC_BUTTON_OVERWRITE_LITTLEST,strngs[20]);//"Overwrite littlest"
		SetDlgItemText(hDlg,IDCANCEL,strngs[29]);//"Cancel"
		pars=(LPVOID*)lParam;
		SetDlgItemText(hDlg,IDC_EDIT_EXST_NAME,(char*)pars[0]);
		SetDlgItemText(hDlg,IDC_EDIT_INZIP_NAME,(char*)pars[1]);
		StringCchPrintf(s,MAX_PATH-1,L"%d",(unsigned __int64)(((WIN32_FIND_DATA*)pars[2])->nFileSizeHigh) << 32 | 
										  ((WIN32_FIND_DATA*)pars[2])->nFileSizeLow);
		SetDlgItemText(hDlg,IDC_EDIT_INZIP_SIZE,s);
		if(FileTimeToLocalFileTime(&((WIN32_FIND_DATA*)pars[2])->ftCreationTime,&ft) != 0)
		{	if(FileTimeToSystemTime(&ft, &st) != 0)
			{	StringCchPrintf(s,MAX_PATH-1,L"%d.%d.%d  %d:%d:%d",
								st.wDay,st.wMonth,st.wYear,
								st.wHour,st.wMinute,st.wSecond);
				SetDlgItemText(hDlg,IDC_EDIT_INZIP_WR_TIME,s);
		}	}

		h = MyFindFirstFileEx((char*)pars[0],FindExInfoStandard,&ff,FindExSearchLimitToDirectories,NULL,0);
		if(INVALID_HANDLE_VALUE!=h)
		{	FindClose(h);
			if(!(FILE_ATTRIBUTE_DIRECTORY & ff.dwFileAttributes))
			{	StringCchPrintf(s,MAX_PATH-1,"%d",(unsigned __int64)(ff.nFileSizeHigh) << 32 | ff.nFileSizeLow);
				SetDlgItemText(hDlg,IDC_EDIT_EXST_SIZE,s);
				if(FileTimeToLocalFileTime(&ff.ftCreationTime,&ft) != 0)
				{	if(FileTimeToSystemTime(&ft, &st) != 0)
					{	StringCchPrintf(s,MAX_PATH-1,"%d.%d.%d  %d:%d:%d",
										st.wDay,st.wMonth,st.wYear,
										st.wHour,st.wMinute,st.wSecond);
						SetDlgItemText(hDlg,IDC_EDIT_EXST_WR_TIME,s);
		}	}	}	}
		SendMessage(hDlg,WM_USER+1,0,0);
		return TRUE;
	case WM_USER+1://hf obshiy uchun, dinamik o'zgartirish uchun emas:
		if(0==hfRef)
		{	LOGFONT lf;InitLOGFONT(&lf);
			hf = CreateFontIndirect(&lf);
			br = CreateSolidBrush(RGB(0x40,0x21,0x17));//0xc9,0x81,0x93));
			brHtBk = CreateSolidBrush(RGB(0x64,0x79,0x65));
		}
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_EXST_NAME),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_EXST_SIZE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_EXST_WR_TIME),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_INZIP_NAME),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_INZIP_SIZE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_INZIP_WR_TIME),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_RENAME),WM_SETFONT,(WPARAM)hf,TRUE);

		SendMessage(GetDlgItem(hDlg,IDC_STATIC8),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_STATIC5),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_STATIC1),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_STATIC3),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_STATIC2),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_STATIC4),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_STATIC7),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_STATIC6),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_OVERWRITE_LATEST_AUTO),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_OVERWRITE_OLDEST_AUTO),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_OVERWRITE_BIGGEST_AUTO),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_RENAME_AUTO),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_SKIP_AUTO),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_OVERWRITE_AUTO),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_OVERWRITE_BIGGEST_AUTO2),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_BUTTON_OVERWRITE_LATEST),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_BUTTON_OVERWRITE_OLDEST),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_BUTTON_OVERWRITE_BIGGEST),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_BUTTON_RENAME),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_BUTTON_SKIP),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_BUTTON_OVERWRITE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_BUTTON_OVERWRITE_LITTLEST),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDCANCEL),WM_SETFONT,(WPARAM)hf,TRUE);
		++hfRef;
		return TRUE;
	case WM_CTLCOLORSTATIC:
	case WM_CTLCOLORDLG:dc = (HDC)wParam;
		SetTextColor(dc,RGB(0xea,0xe0,0xff));
		SetBkColor(dc,RGB(0x40,0x21,0x17));
		return (INT_PTR)br;
	case WM_CTLCOLOREDIT:dc = (HDC)wParam;
		SetTextColor(dc,RGB(0xea,0xe0,0xff));
		SetBkColor(dc,RGB(0x40,0x21,0x17));
		return (INT_PTR)br;
	case WM_CTLCOLORBTN:dc=(HDC)wParam;
		SetTextColor(dc,RGB(0xd0,0xe0,0xff));
		SetBkColor(dc,RGB(0x64,0x79,0x65));
		return (INT_PTR)brHtBk;
	case WM_DRAWITEM:
		lpdis = (LPDRAWITEMSTRUCT)lParam;
		GetWindowText(lpdis->hwndItem,s,64);
		uStyle = DFCS_BUTTONPUSH;
		r = lpdis->rcItem;
		if(lpdis->itemState & ODS_SELECTED)
		{	uStyle |= DFCS_PUSHED|DFCS_TRANSPARENT;
			r.left+=2;r.top+=2;
		}
		DrawFrameControl(lpdis->hDC, &lpdis->rcItem, DFC_BUTTON, uStyle);
		if(lpdis->itemState & ODS_SELECTED)
			{r.left+=1;r.top+=1;r.bottom-=2;r.right-=3;}
		else
			{r.left+=1;r.top+=2;r.bottom-=3;r.right-=3;}
		FillRect(lpdis->hDC,&r,brHtBk);//DrawText(lpdis->hDC,"                                                  ",50,&rc,DT_SINGLELINE|DT_VCENTER|DT_INTERNAL|DT_LEFT);
		if(lpdis->itemState & ODS_SELECTED)
			{r.left-=1;r.top-=1;r.bottom+=3;r.right+=3;}
		else
			{r.left-=1;r.top-=2;r.bottom+=2;r.right+=3;}
		DrawText(lpdis->hDC,s,MyStringLength(s,64),&r,DT_SINGLELINE|DT_VCENTER|DT_CENTER);
		return TRUE;
	case WM_DESTROY:
		if(--hfRef<1)
		{	DeleteObject(hf);
			DeleteObject(br);
			DeleteObject(brHtBk);
		}
		return 0;
	case WM_COMMAND://int r;
		switch(LOWORD(wParam))
		{	case IDC_BUTTON_OVERWRITE_LATEST:		
				EndDialog(hDlg,(BST_CHECKED!=SendMessage(GetDlgItem(hDlg,
												IDC_CHECK_OVERWRITE_LATEST_AUTO),BM_GETCHECK,0,0))?1:11);
				return (INT_PTR)TRUE;
			case IDC_BUTTON_OVERWRITE_OLDEST:
				EndDialog(hDlg,(BST_CHECKED!=SendMessage(GetDlgItem(hDlg,
												IDC_CHECK_OVERWRITE_OLDEST_AUTO),BM_GETCHECK,0,0))?2:12);
				return (INT_PTR)TRUE;
			case IDC_BUTTON_OVERWRITE_BIGGEST:
				EndDialog(hDlg,(BST_CHECKED!=SendMessage(GetDlgItem(hDlg,
												IDC_CHECK_OVERWRITE_BIGGEST_AUTO),BM_GETCHECK,0,0))?3:13);
				return (INT_PTR)TRUE;				
			case IDC_BUTTON_RENAME:
				EndDialog(hDlg,(BST_CHECKED!=SendMessage(GetDlgItem(hDlg,
												IDC_CHECK_RENAME_AUTO),BM_GETCHECK,0,0))?4:14);
				return (INT_PTR)TRUE;				
			case IDC_BUTTON_SKIP:
				EndDialog(hDlg,(BST_CHECKED!=SendMessage(GetDlgItem(hDlg,
												IDC_CHECK_SKIP_AUTO),BM_GETCHECK,0,0))?5:15);
				return (INT_PTR)TRUE;				
			case IDC_BUTTON_OVERWRITE:
				EndDialog(hDlg,(BST_CHECKED!=SendMessage(GetDlgItem(hDlg,
												IDC_CHECK_OVERWRITE_AUTO),BM_GETCHECK,0,0))?6:16);
				return (INT_PTR)TRUE;				
			case IDC_BUTTON_OVERWRITE_LITTLEST:
				EndDialog(hDlg,(BST_CHECKED!=SendMessage(GetDlgItem(hDlg,
												IDC_BUTTON_OVERWRITE_LITTLEST),BM_GETCHECK,0,0))?7:17);
				return (INT_PTR)TRUE;				
			case IDCANCEL:
				EndDialog(hDlg, -1);
				return (INT_PTR)TRUE;
		}
		break;
	}
	return (INT_PTR)FALSE;
}*/

__declspec (dllexport) VOID SetCryptMethod$8(PluginObj *plg,int n)
{
//	if(n==0)
//		plg->cryptMethod = n;
}

__declspec (dllexport) BOOL Close$4(PluginObj *plg)
{
SHFILEOPSTRUCT fo;wchar_t s[MAX_PATH];int l;
	if(PluginObj::unpack==plg->packType)
	{	DestroyEnumDirBuf();
		delete plg->extrctFileNameStrW;
	}
	else if(PluginObj::pack==plg->packType)
	{	if(plg->bAppend)
			AppendOldCab(plg);
		delete plg->compress;
		fo.hwnd = NULL;
		l=MyStringCpy(s,MAX_PATH-1,plg->comprsFileNameStrW->operator WCHAR*());
		s[l+1]=0;
		fo.wFunc = FO_RENAME;
		fo.pFrom = s;
		fo.pTo = plg->comprsFileName;
		l=MyStringLength(plg->comprsFileName,MAX_PATH);
		plg->comprsFileName[l+1]=0;
		fo.fFlags = FOF_SILENT | FOF_NOCONFIRMATION | FOF_NOERRORUI | FOF_NOCONFIRMMKDIR;
		SHFileOperation(&fo);

		//if(!MoveFileW(plg->comprsFileNameStrW->operator WCHAR*(),plg->comprsFileName))
		//{	int e=GetLastError();
		//		e++;
		//}
		delete plg->comprsFileNameStrW;
	}	
	free(plg);
	return TRUE;
}

}//end of extern C"