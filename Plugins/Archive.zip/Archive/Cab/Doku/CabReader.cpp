#include "stdafx.h"
#include "CabReader.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

CCabReader::CCabReader()
: m_nFileCount(0)
, m_dwTotalSize(0)
{
}

CCabReader::~CCabReader()
{
}

BOOL CCabReader::ReadCabinetFile(CString strFileName, FILE* fp /* = NULL */)
{
	FILE* file = NULL;
	if (fp == NULL)
	{
		_tfopen_s(&file, strFileName, _T("r+b"));
	}
	else
	{
		file = fp;
	}

	if (file != NULL)
	{
		CabHeader header;
		fread(&header, sizeof(CFHEADER), 1, file);

		if ((header.flags & cfhdrRESERVE_PRESENT) != 0)
		{
			fread(&header.cbCFHeader, sizeof(header.cbCFHeader), 1, file);	// 0 to 60000
			fread(&header.cbCFFolder, sizeof(header.cbCFFolder), 1, file);	// 0 to 255
			fread(&header.cbCFData, sizeof(header.cbCFData), 1, file);		// 0 to 255

			// abReserve
			if (header.cbCFHeader > 0)
			{
				fread(header.abReserve, header.cbCFHeader, 1, file);
			}
		}

		if ((header.flags & cfhdrPREV_CABINET) != 0)
		{
			// szCabinetPrev
			for (int j=0; ;j++)
			{
				char ch = 0;
				fread(&ch, 1, 1, file);
				if (ch == 0)
				{
					break;
				}

				header.szCabinetPrev[j] = ch;
			}

			// szDiskPrev
			for (int j=0; ;j++)
			{
				char ch = 0;
				fread(&ch, 1, 1, file);
				if (ch == 0)
				{
					break;
				}

				header.szDiskPrev[j] = ch;
			}
		}

		if ((header.flags & cfhdrNEXT_CABINET) != 0)
		{
			// szCabinetNext
			for (int j=0; ;j++)
			{
				char ch = 0;
				fread(&ch, 1, 1, file);
				if (ch == 0)
				{
					break;
				}

				header.szCabinetNext[j] = ch;
			}

			// szDiskNext
			for (int j=0; ;j++)
			{
				char ch = 0;
				fread(&ch, 1, 1, file);
				if (ch == 0)
				{
					break;
				}

				header.szDiskNext[j] = ch;
			}
		}

		m_nFileCount = header.cFiles;

		for (int i=0; i<header.cFolders; i++)
		{
			CabFolder folder;
			fread(&folder, sizeof(CFFOLDER), 1, file);

			if ((header.flags & cfhdrRESERVE_PRESENT) != 0)
			{
				if (header.cbCFFolder > 0)
				{
					fread(folder.abReserve, header.cbCFFolder, 1, file);
				}
			}
		}

		for (int i=0; i<header.cFiles; i++)
		{
			CabFile cab_file;
			fread(&cab_file, sizeof(CFFILE), 1, file);

			for (int j=0; ;j++)
			{
				char ch = 0;
				fread(&ch, 1, 1, file);
				if (ch == 0)
				{
					break;
				}

				cab_file.szName[j] = ch;
			}

			m_dwTotalSize += cab_file.cbFile;
			if (!m_strAutoRunFileName.IsEmpty())
			{
				if (m_strAutoRunFileName.CompareNoCase(cab_file.GetFileName()) == 0)
				{
					if ((cab_file.attribs & _A_EXEC) == 0)
					{
						int len = CStringA(cab_file.GetFileName()).GetLength();
						int offset = len + 1 + sizeof(u2);
						fseek(file, -offset, SEEK_CUR);

						u2 attr = cab_file.attribs | _A_EXEC;
						fwrite(&attr, sizeof(u2), 1, file);
						fflush(file);

						fseek(file, offset - sizeof(u2), SEEK_CUR);
					}
				}
			}
			else
			{
				if ((cab_file.attribs & _A_EXEC) > 0)
				{
					m_strAutoRunFileName = cab_file.GetFileName();
				}
			}

#ifdef _DEBUG
			cab_file.Dump();
#endif
		}

		if (fp == NULL)
		{
			fclose(file);
			file = NULL;
		}

		return TRUE;
	}

	return FALSE;
}
