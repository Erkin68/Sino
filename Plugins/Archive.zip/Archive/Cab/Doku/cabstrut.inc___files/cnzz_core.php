(function(){
try{
var d=window._CNZZDbridge_1236358.bobject;
var scheme =  (document.location.protocol=='https:')?'https:':'http:';
d.callRequest([,scheme+'//cnzz.mmstat.com/9.gif?abc=1']);
d.callScript([]);
        d.createIcon([            "<a href='http://www.cnzz.com/stat/website.php?web_id=1236358' target=_blank title='&#31449;&#38271;&#32479;&#35745;'><img border=0 hspace=0 vspace=0 src='http://icon.cnzz.com/pic.gif'></a>"
            ])}catch(err){
}
})();
