document.writeln('<form action=http://www.pudn.com/search_db.asp method=get target=_blank>\n');
document.writeln('&nbsp;<INPUT maxLength=50 size=20 name=keyword>\n');
document.writeln('<input type=submit value="Search codes">\n');
//document.writeln('<pre name="code" class="c++">');
document.writeln('<BR>');
google_ad_client = "pub-8055710228382273";
google_ad_slot = "3520185622";
google_ad_width = 728;
google_ad_height = 90;

document.writeln('<script type="text/javascript"');
document.writeln('  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">');
document.writeln('</script>');
