#pragma once

typedef unsigned char	u1;
typedef unsigned short	u2;
typedef unsigned int	u4;

#pragma pack(push)
#pragma pack(1)
struct CFHEADER
{
    u1  signature[4];	/* cabinet file signature */
    u4  reserved1;	/* reserved */
    u4  cbCabinet;	/* size of this cabinet file in bytes */
    u4  reserved2;	/* reserved */

    u4  coffFiles;	/* offset of the first CFFILE entry */
    u4  reserved3;	/* reserved */
    u1  versionMinor;	/* cabinet file format version, minor */
    u1  versionMajor;	/* cabinet file format version, major */
    u2  cFolders;	/* number of CFFOLDER entries in this cabinet */
    u2  cFiles;	/* number of CFFILE entries in this cabinet */
    u2  flags;	/* cabinet file option indicators */

    u2  setID;	/* must be the same for all cabinets in a set */
    u2  iCabinet;	/* number of this cabinet file in a set */
	//u2  cbCFHeader; 	/* (optional) size of per-cabinet reserved area */
	//u1  cbCFFolder; 	/* (optional) size of per-folder reserved area */
	//u1  cbCFData; 	/* (optional) size of per-datablock reserved area */

	//u1  abReserve[];	/* (optional) per-cabinet reserved area */
	//u1  szCabinetPrev[];	/* (optional) name of previous cabinet file */
	//u1  szDiskPrev[];	/* (optional) name of previous disk */
	//u1  szCabinetNext[];	/* (optional) name of next cabinet file */
	//u1  szDiskNext[];	/* (optional) name of next disk */
};

struct CFFOLDER
{
    u4  coffCabStart;	/* offset of the first CFDATA block in this folder */
    u2  cCFData;	/* number of CFDATA blocks in this folder */
    u2  typeCompress;	/* compression type indicator */
    //u1  abReserve[];	/* (optional) per-folder reserved area */
};

struct CFFILE
{
    u4  cbFile;	/* uncompressed size of this file in bytes */
    u4  uoffFolderStart;	/* uncompressed offset of this file in the folder */
    u2  iFolder;	/* index into the CFFOLDER area */
    u2  date;	/* date stamp for this file */
    u2  time;	/* time stamp for this file */
    u2  attribs;	/* attribute flags for this file */
	//u1  szName[];	/* name of this file */
};

struct CFDATA
{
    u4  csum;	/* checksum of this CFDATA entry */
    u2  cbData;	/* number of compressed bytes in this block */
    u2  cbUncomp;	/* number of uncompressed bytes in this block */
    //u1  abReserve[];	/* (optional) per-datablock reserved area */
    //u1  ab[cbData];	/* compressed data bytes */
};

#define cfhdrPREV_CABINET       0x0001
#define cfhdrNEXT_CABINET       0x0002
#define cfhdrRESERVE_PRESENT    0x0004

#define ifoldCONTINUED_FROM_PREV      (0xFFFD)
#define ifoldCONTINUED_TO_NEXT        (0xFFFE)
#define ifoldCONTINUED_PREV_AND_NEXT  (0xFFFF)

#define _A_RDONLY      (0x01)	/* file is read-only */
#define _A_HIDDEN      (0x02)	/* file is hidden */
#define _A_SYSTEM      (0x04)	/* file is a system file */
#define _A_ARCH        (0x20)	/* file modified since last backup */
#define _A_EXEC        (0x40)	/* run after extraction */
#define _A_NAME_IS_UTF (0x80)	/* szName[] contains UTF */

#pragma pack(pop)

class CabHeader : public CFHEADER
{
public:
	CabHeader()
	{
		memset(this, 0, sizeof(CabHeader));
	}

#ifdef _DEBUG
	void Dump()
	{
	}
#endif

public:
	u2  cbCFHeader; 	/* (optional) size of per-cabinet reserved area */
	u1  cbCFFolder; 	/* (optional) size of per-folder reserved area */
	u1  cbCFData; 	/* (optional) size of per-datablock reserved area */

	u1  abReserve[60000];	/* (optional) per-cabinet reserved area */

	u1  szCabinetPrev[MAX_PATH];	/* (optional) name of previous cabinet file */
	u1  szDiskPrev[MAX_PATH];	/* (optional) name of previous disk */
	u1  szCabinetNext[MAX_PATH];	/* (optional) name of next cabinet file */
	u1  szDiskNext[MAX_PATH];	/* (optional) name of next disk */
};

class CabFolder : public CFFOLDER
{
public:
	CabFolder()
	{
		memset(this, 0, sizeof(CabFolder));
	}

#ifdef _DEBUG
	void Dump()
	{
	}
#endif

public:
	u1  abReserve[MAX_PATH];	/* (optional) per-folder reserved area */
};


class CabFile : public CFFILE
{
public:
	CabFile()
	{
		memset(this, 0, sizeof(CabFile));
	}

	CString GetFileName() const
	{
		return CString(CStringA((char *)szName));
	}

	DWORD GetFileSize() const
	{
		return (DWORD)cbFile;
	}

	CString GetFileDate() const
	{
		CString strDate;

		int year = (date >> 9) + 1980;
		int month = (date - ((year-1980)<<9)) >> 5;
		int day = (date - ((year-1980)<<9)) - (month<<5);

		int hour = (time >> 11);
		int min = (time - (hour << 11)) >> 5;
		int sec = ((time - (hour << 11)) - (min << 5)) * 2;

		strDate.Format(_T("%04d/%02d/%02d %02d:%02d:%02d"), year, month, day, hour, min, sec);

		return strDate;
	}

	CString GetAttributes() const
	{
		CString strAttr;

		char c1,c2,c3,c4,c5,c6;
		c1=c2=c3=c4=c5=c6='-';

		if ((attribs & _A_RDONLY) > 0) c1='R';
		if ((attribs & _A_HIDDEN) > 0) c2='H';
		if ((attribs & _A_SYSTEM) > 0) c3='S';
		if ((attribs & _A_ARCH) > 0) c4='A';
		if ((attribs & _A_EXEC) > 0) c5='X';
		if ((attribs & _A_NAME_IS_UTF) > 0) c6='U';

		strAttr.Format(_T("%c%c%c%c%c%c"), c1, c2, c3, c4, c5, c6);

		return strAttr;
	}

#ifdef _DEBUG
	void Dump()
	{
		int y = (date >> 9) + 1980;
		int m = (date - ((y-1980)<<9)) >> 5;
		int d = (date - ((y-1980)<<9)) - (m<<5);

		int hour = (time >> 11);
		int min = (time - (hour << 11)) >> 5;
		int sec = ((time - (hour << 11)) - (min << 5)) * 2;

		char c1,c2,c3,c4,c5,c6;
		c1=c2=c3=c4=c5=c6='-';

		if ((attribs & _A_RDONLY) > 0) c1='R';
		if ((attribs & _A_HIDDEN) > 0) c2='H';
		if ((attribs & _A_SYSTEM) > 0) c3='S';
		if ((attribs & _A_ARCH) > 0) c4='A';
		if ((attribs & _A_EXEC) > 0) c5='X';
		if ((attribs & _A_NAME_IS_UTF) > 0) c6='U';

		CStringA strOutput;
		strOutput.Format("%s\t%d\t%04d/%02d/%02d %02d:%02d:%02d\t%c%c%c%c%c%c\n", (char *)szName, cbFile, y, m, d, hour, min, sec,c1,c2,c3,c4,c5,c6);

		::OutputDebugStringA(strOutput);
	}
#endif

public:
	u1  szName[MAX_PATH];	/* name of this file */
};

class CabData : public CFDATA
{
public:
	CabData()
	{
		memset(this, 0, sizeof(CabData));
	}

#ifdef _DEBUG
	void Dump()
	{
	}
#endif
};

class CCabReader
{
public:
	CCabReader();
	~CCabReader();

	BOOL ReadCabinetFile(CString strFileName, FILE* fp = NULL);

	int GetFileCount() const
	{
		return m_nFileCount;
	}

	DWORD GetTotalSize() const
	{
		return m_dwTotalSize;
	}

	CString GetAutoRunFileName() const
	{
		return m_strAutoRunFileName;
	}

	void SetAutoRunFileName(CString strFileName)
	{
		m_strAutoRunFileName = strFileName;
	}

private:
	int		m_nFileCount;
	DWORD	m_dwTotalSize;
	CString	m_strAutoRunFileName;
};