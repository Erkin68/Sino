//1.CExtract.OnBeforeCopyFile()This is called before Cabinet.dll copies an extracted file to disk. You get detailed information about the file to be extracted. If you don't want this file to be copied to disk you can return FALSE here and the file will be skipped. (Examples see below) This callback can be used to display progress information in your GUI if you extract small files (< 10 MB).
//2.CExtract.OnAfterCopyFile ()This is called after Cabinet.dll has placed a new file onto disk.This callback can be used to display progress information in your GUI if you extract small files (< 10 MB).If you have enabled Extraction to Memory, no file is written to disk, instead this callback receives the entire content of the file in a buffer / Byte Array
//3.CExtract.OnProgessInfo   ()This must be used if you extract huge files (> 50 MB) and want to show the progress in the GUI.This callback is called every 200 ms while huge files are written to disk. Example: 
//4.CExtract.OnCabinetInfo   ()This function will be called exactly once for each cabinet when it is opened. It passes information about the CAB file.
//5.CExtract.OnNextCabinet   ()This function will be called when the next cabinet file in the sequence of splitted cabinets needs to be opened.Here you can display a message like "Please insert disk 2!"

#include "windows.h"
#include <stdio.h>
#include "Plugins_C.h"
#include "Cabinet C++ Project 14.0/Cabinet/Extract.hpp"


using namespace Cabinet;

#define MIN_BUF_SIZE 1024//o'rtacha 25 so'zdan tzxminan 41 ta directoriy

CExtract::kCallbacks k_MyEnumExtrCallbacks;
wchar_t startDir[MAX_PATH];

wchar_t* wstrstrslash(wchar_t*,wchar_t*);
BOOL OnBeforeCopyFileEnumClls(Cabinet::CExtract::kCabinetFileInfo*, void*);
void OnAfterCopyFileEnumClls (WCHAR* u16_File, Cabinet::CMemory* pi_ExtractMem, void* p_Param){}
void OnProgressInfoEnumClls  (Cabinet::CExtract::kProgressInfo* pk_Progress, void* p_Param){}
void OnCabinetInfoEnumClls   (Cabinet::CExtract::kCabinetInfo* pk_Info, void* p_Param){}
void OnNextCabinetEnumClls   (Cabinet::CExtract::kCabinetInfo* pk_Info, int s32_Error, void* p_Param){}
//int StreamGetLenEnumClls (void* p_Param);
//int StreamReadEnumClls   (void* p_Buffer, int Pos, UINT u32_Count, void* p_Param);

extern "C" { void StartUpCallbacks()
{	k_MyEnumExtrCallbacks.f_OnBeforeCopyFile = &OnBeforeCopyFileEnumClls;
	k_MyEnumExtrCallbacks.f_OnAfterCopyFile  = &OnAfterCopyFileEnumClls;
	k_MyEnumExtrCallbacks.f_OnProgressInfo   = &OnProgressInfoEnumClls;
	k_MyEnumExtrCallbacks.f_OnCabinetInfo    = &OnCabinetInfoEnumClls;
	k_MyEnumExtrCallbacks.f_OnNextCabinet    = &OnNextCabinetEnumClls;
	if(!GetModuleFileNameW(NULL,startDir,MAX_PATH))
	if(!GetWindowsDirectoryW(startDir,MAX_PATH))
	if(!GetSystemDirectoryW(startDir,MAX_PATH))
		swprintf(startDir,L"C:\\");
}}

static WIN32_FIND_DATAA ff={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
static char s[MAX_PATH];
VOID FindDirFromEnumList(void*,wchar_t*,wchar_t*);
BOOL OnBeforeCopyFileEnumClls(Cabinet::CExtract::kCabinetFileInfo* pk_Info, void* p_Param)
{
wchar_t *p;int l=0;
	if(0==((wchar_t*)((LPVOID*)p_Param)[1])[0])//root
	{	p=wcschr(pk_Info->u16_RelPath,'\\');
		if(p)
		{	FindDirFromEnumList(p_Param,pk_Info->u16_RelPath,p);
			return FALSE;
		}
		else
		{	if(pk_Info->u16_RelPath[0])
			l=WideCharToMultiByte(AreFileApisANSI()?CP_ACP:CP_OEMCP,0,pk_Info->u16_RelPath,-1,s,MAX_PATH,NULL,NULL);
			if(!l)WideCharToMultiByte(AreFileApisANSI()?CP_ACP:CP_OEMCP,0,pk_Info->u16_File,-1,s,MAX_PATH,NULL,NULL);
			if(!l)return FALSE;
			ff.nFileSizeLow=pk_Info->s32_Size;
			ff.dwFileAttributes=pk_Info->u16_Attribs;
			ff.ftCreationTime.dwLowDateTime=pk_Info->k_Time.dwLowDateTime;
			ff.ftCreationTime.dwHighDateTime=pk_Info->k_Time.dwHighDateTime;
			addItemToPanelList( ( (PluginObj*) (((LPVOID*)p_Param)[0]) )->host,s,&ff);
			return FALSE;
	}	}
	//else: if not root
	p=wstrstrslash(pk_Info->u16_RelPath,(wchar_t*)((LPVOID*)p_Param)[1]);
	if(!p)return FALSE;
	wchar_t *pslsh=wcschr(p,'\\');
	if(!pslsh)
	{	ff.nFileSizeLow=pk_Info->s32_Size;
		ff.dwFileAttributes=pk_Info->u16_Attribs;
		ff.ftCreationTime.dwLowDateTime=pk_Info->k_Time.dwLowDateTime;
		ff.ftCreationTime.dwHighDateTime=pk_Info->k_Time.dwHighDateTime;
		l=WideCharToMultiByte(AreFileApisANSI()?CP_ACP:CP_OEMCP,0,p,-1,s,MAX_PATH,NULL,NULL);
		if(!l)WideCharToMultiByte(AreFileApisANSI()?CP_ACP:CP_OEMCP,0,pk_Info->u16_File,-1,s,MAX_PATH,NULL,NULL);
		if(!l)return FALSE;
		addItemToPanelList( ( (PluginObj*) (((LPVOID*)p_Param)[0]) )->host,s,&ff);
		return FALSE;
	}
	FindDirFromEnumList(p_Param,p,pslsh);
	return FALSE;
}

static long enumDirBufSz=0;
static wchar_t *enumDirBuf=0,*pEnumDirBuf=0;
static wchar_t pOldPath[MAX_PATH]={0};
void DestroyEnumDirBuf()
{
	if(enumDirBuf)
		free(enumDirBuf);
	enumDirBuf=0;
	pEnumDirBuf=0;
	enumDirBufSz=0;
}

void ResetEnumDirBuf()
{
	pEnumDirBuf=enumDirBuf;
	if(pEnumDirBuf)
		pEnumDirBuf[0]=0;
	if(pOldPath)
		pOldPath[0]=0;
}

VOID CheckDirList(void* p_Param,wchar_t *newPath,int ln)
{	
	if(!enumDirBuf)
	{	enumDirBuf=(wchar_t*)malloc(sizeof(wchar_t)*MIN_BUF_SIZE);
		if(!enumDirBuf)return;
		pEnumDirBuf=enumDirBuf;
		enumDirBufSz=MIN_BUF_SIZE;
		*((BYTE*)pEnumDirBuf)=(BYTE)ln;
		pEnumDirBuf = (wchar_t*) (((BYTE*)pEnumDirBuf)+1);
		for(int i=0; i<ln+1; i++) pEnumDirBuf[i]=newPath[i];
		pEnumDirBuf += ln+1;
		*pEnumDirBuf=0;//oxirgisini 0 qilib qo'yamiz:
	}
	else
	{	wchar_t *p=enumDirBuf;BOOL bFind=FALSE;
		while(*((char*)p))
		{	bFind=TRUE;
			BYTE l = *((char*)p);
			p = (wchar_t*)(((char*)p)+1);
			for(BYTE i=0; i<l; i++)
			{	if(p[i]!=newPath[i])
				{	bFind=FALSE;
					break;
			}	}
			if(bFind)break;
			p+=l+1;
		}
		if(bFind)return;
		if(pEnumDirBuf-enumDirBuf>ln+enumDirBufSz-MAX_PATH-2)
		{	enumDirBuf=(wchar_t*)realloc(enumDirBuf,sizeof(wchar_t)*(ln+enumDirBufSz+MIN_BUF_SIZE+2));
			if(!enumDirBuf)return;
			enumDirBufSz += ln+MIN_BUF_SIZE+2;
		}
		*((char*)pEnumDirBuf) = (BYTE)ln;
		pEnumDirBuf = (wchar_t*)(((char*)pEnumDirBuf)+1);
		for(int i=0; i<=ln; i++)
			pEnumDirBuf[i]=newPath[i];
		pEnumDirBuf += ln+1;
		*pEnumDirBuf=0;
	}
	ff.dwFileAttributes=FILE_ATTRIBUTE_DIRECTORY;
	if(WideCharToMultiByte(AreFileApisANSI()?CP_ACP:CP_OEMCP,0,newPath,-1,s,MAX_PATH,NULL,NULL))
		addItemToPanelList(( (PluginObj*) (((LPVOID*)p_Param)[0]) )->host,s,&ff);
}

VOID FindDirFromEnumList(void* p_Param,wchar_t *pd,wchar_t *pdEnd)
{
wchar_t *p,*pBeg=&pOldPath[0];
	if(pOldPath[0])if(0==wcsncmp(pOldPath,pd,pdEnd-pd))return;//wcscmp(pOldPath,pd))return;
	for(p=&pOldPath[0]; *pd;)
	{	if(pd<=pdEnd)
		{	if('\\'==(*pd))// || '/'==(*pd))
			{	*p=0;
				CheckDirList(p_Param,pBeg,p-pBeg);
				*p='\\';
				pBeg=p+1;
			}
			*p=*pd;
			++p;++pd;
		}
		else
		{	*p=0;
			return;
}	}	}

wchar_t* wstrstrslash(wchar_t *s1,wchar_t *s2)
{
	for(;*s2;)//*s1 ham bor edi;
	{	if((*s1)==(*s2)) {++s1;++s2;continue;}
		if('\\'==(*s1) && '\\'==(*s2)) {++s1;++s2;continue;}
		//if('\\'==(*s1) && '/'==(*s2)) {++s1;++s2;continue;}
		//if('/'==(*s1) && '\\'==(*s2)) {++s1;++s2;continue;}
		//if('/'==(*s1) && '/'==(*s2)) {++s1;++s2;continue;}
		return ((0==(*s2))?s1:0);
	}
	return s1;
}