//1.CExtract.OnBeforeCopyFile()This is called before Cabinet.dll copies an extracted file to disk. You get detailed information about the file to be extracted. If you don't want this file to be copied to disk you can return FALSE here and the file will be skipped. (Examples see below) This callback can be used to display progress information in your GUI if you extract small files (< 10 MB).
//2.CExtract.OnAfterCopyFile ()This is called after Cabinet.dll has placed a new file onto disk.This callback can be used to display progress information in your GUI if you extract small files (< 10 MB).If you have enabled Extraction to Memory, no file is written to disk, instead this callback receives the entire content of the file in a buffer / Byte Array
//3.CExtract.OnProgessInfo   ()This must be used if you extract huge files (> 50 MB) and want to show the progress in the GUI.This callback is called every 200 ms while huge files are written to disk. Example: 
//4.CExtract.OnCabinetInfo   ()This function will be called exactly once for each cabinet when it is opened. It passes information about the CAB file.
//5.CExtract.OnNextCabinet   ()This function will be called when the next cabinet file in the sequence of splitted cabinets needs to be opened.Here you can display a message like "Please insert disk 2!"

#include "windows.h"
#include <stdio.h>
#include "Plugins_C.h"
#include "Cabinet C++ Project 14.0/Cabinet/Extract.hpp"
#include "SchStructs.h"
#include "..\..\..\Operations\Myshell\ComboToDisk.h"
#include "..\..\..\Operations\Myshell\FindStrWthFltr.h"

using namespace Cabinet;

#define MIN_BUF_SIZE 1024//o'rtacha 25 so'zdan tzxminan 41 ta directoriy

CExtract::kCallbacks k_MyEnumExtrCallbacks,k_MyUnpExtrCallbacks,k_MySearchCallbacks;//,k_MyDelExtrCallbacks;
CCompress::kCallbacks k_MyAddCmprsCallbacks;//,k_MyCrDirCmprsCallbacks;
wchar_t startDir[MAX_PATH];//dll attach process paytida GetModuleFileName qiliadi;


extern "C"
{
extern Search	search;
extern SearchItem item;

char* strstrslashA(char*,char*);
wchar_t* strstrslash(wchar_t*,wchar_t*);
char* strstrslashGetLastA(char*,char*,char**);
wchar_t* strstrslashGetLast(wchar_t*,wchar_t*,wchar_t**);
extern VOID AddToInfoEdit(wchar_t*,WIN32_FIND_DATA*);
extern VOID AddToResultsLB(WIN32_FIND_DATA*,wchar_t*);
}

BOOL OnBeforeCopyFileEnumClls(Cabinet::CExtract::kCabinetFileInfo*, void*);
void OnAfterCopyFileEnumClls (WCHAR* u16_File, Cabinet::CMemory* pi_ExtractMem, void* p_Param){}
void OnProgressInfoEnumClls  (Cabinet::CExtract::kProgressInfo* pk_Progress, void* p_Param){}
void OnCabinetInfoEnumClls   (Cabinet::CExtract::kCabinetInfo* pk_Info, void* p_Param){}
void OnNextCabinetEnumClls   (Cabinet::CExtract::kCabinetInfo* pk_Info, int s32_Error, void* p_Param){}
//int StreamGetLenEnumClls (void* p_Param);
//int StreamReadEnumClls   (void* p_Buffer, int Pos, UINT u32_Count, void* p_Param);

BOOL OnBeforeCopyFileUnpClls(Cabinet::CExtract::kCabinetFileInfo*, void*);
void OnAfterCopyFileUnpClls (WCHAR* u16_File, Cabinet::CMemory* pi_ExtractMem, void* p_Param){}
void OnProgressInfoUnpClls  (Cabinet::CExtract::kProgressInfo*,void*);
void OnCabinetInfoUnpClls   (Cabinet::CExtract::kCabinetInfo* pk_Info, void* p_Param){}
void OnNextCabinetUnpClls   (Cabinet::CExtract::kCabinetInfo* pk_Info, int s32_Error, void* p_Param){}

BOOL OnBeforeCopyFileSearchClls(Cabinet::CExtract::kCabinetFileInfo*, void*);
void OnAfterCopyFileSearchClls (WCHAR* u16_File, Cabinet::CMemory* pi_ExtractMem, void* p_Param){}
void OnProgressInfoSearchClls  (Cabinet::CExtract::kProgressInfo*,void*);
void OnCabinetInfoSearchClls   (Cabinet::CExtract::kCabinetInfo* pk_Info, void* p_Param){}
void OnNextCabinetSearchClls   (Cabinet::CExtract::kCabinetInfo* pk_Info, int s32_Error, void* p_Param){}


//BOOL OnBeforeCopyFileDelClls(Cabinet::CExtract::kCabinetFileInfo*, void*);
//void OnAfterCopyFileDelClls (WCHAR* u16_File, Cabinet::CMemory* pi_ExtractMem, void* p_Param){}
//void OnProgressInfoDelClls  (Cabinet::CExtract::kProgressInfo*,void*){}
//void OnCabinetInfoDelClls   (Cabinet::CExtract::kCabinetInfo* pk_Info, void* p_Param){}
//void OnNextCabinetDelClls   (Cabinet::CExtract::kCabinetInfo* pk_Info, int s32_Error, void* p_Param){}

int  FilePlacedAddCmprsCall(PCCAB, WCHAR*, int, BOOL, void*);
BOOL GetNextCabinetAddCmprsCall(PCCAB, ULONG, unsigned char*, void*);
int  UpdateStatusAddCmprsCall(UINT, CCompress::kCurStatus*, void*);

//int  FilePlacedCrDirCmprsCall(PCCAB, WCHAR*, int, BOOL, void*);
//BOOL GetNextCabinetCrDirCmprsCall(PCCAB, ULONG, unsigned char*, void*);
//int  UpdateStatusCrDirCmprsCall(UINT, CCompress::kCurStatus*, void*);

extern "C" {
typedef void (*UnpackProgressRoutine_t)(unsigned __int64,unsigned __int64,wchar_t*);
extern int MyStringCpyA(char*,int,char*);
extern int MyStringCpy(wchar_t*,int,wchar_t*);
extern int MyStringCpyCrctSlashA(char*,int,char*);
extern int MyStringCpyCrctSlash(wchar_t*,int,wchar_t*);
void StartUpCallbacks()
{	if(!GetModuleFileNameW(NULL,startDir,MAX_PATH))
	if(!GetWindowsDirectoryW(startDir,MAX_PATH))
	if(!GetSystemDirectoryW(startDir,MAX_PATH))
		swprintf(startDir,L"C:\\");

	k_MyEnumExtrCallbacks.f_OnBeforeCopyFile = &OnBeforeCopyFileEnumClls;
	k_MyEnumExtrCallbacks.f_OnAfterCopyFile  = &OnAfterCopyFileEnumClls;
	k_MyEnumExtrCallbacks.f_OnProgressInfo   = &OnProgressInfoEnumClls;
	k_MyEnumExtrCallbacks.f_OnCabinetInfo    = &OnCabinetInfoEnumClls;
	k_MyEnumExtrCallbacks.f_OnNextCabinet    = &OnNextCabinetEnumClls;

	k_MyUnpExtrCallbacks.f_OnBeforeCopyFile = &OnBeforeCopyFileUnpClls;
	k_MyUnpExtrCallbacks.f_OnAfterCopyFile  = &OnAfterCopyFileUnpClls;
	k_MyUnpExtrCallbacks.f_OnProgressInfo   = &OnProgressInfoUnpClls;
	k_MyUnpExtrCallbacks.f_OnCabinetInfo    = &OnCabinetInfoUnpClls;
	k_MyUnpExtrCallbacks.f_OnNextCabinet    = &OnNextCabinetUnpClls;

	k_MySearchCallbacks.f_OnBeforeCopyFile = &OnBeforeCopyFileSearchClls;
	k_MySearchCallbacks.f_OnAfterCopyFile  = &OnAfterCopyFileSearchClls;
	k_MySearchCallbacks.f_OnProgressInfo   = &OnProgressInfoSearchClls;
	k_MySearchCallbacks.f_OnCabinetInfo    = &OnCabinetInfoSearchClls;
	k_MySearchCallbacks.f_OnNextCabinet    = &OnNextCabinetSearchClls;

	//k_MyDelExtrCallbacks.f_OnBeforeCopyFile = &OnBeforeCopyFileDelClls;
	//k_MyDelExtrCallbacks.f_OnAfterCopyFile  = &OnAfterCopyFileDelClls;
	//k_MyDelExtrCallbacks.f_OnProgressInfo   = &OnProgressInfoDelClls;
	//k_MyDelExtrCallbacks.f_OnCabinetInfo    = &OnCabinetInfoDelClls;
	//k_MyDelExtrCallbacks.f_OnNextCabinet    = &OnNextCabinetDelClls;

	k_MyAddCmprsCallbacks.f_FilePlaced = &FilePlacedAddCmprsCall;
	k_MyAddCmprsCallbacks.f_GetNextCabinet = &GetNextCabinetAddCmprsCall;
	k_MyAddCmprsCallbacks.f_UpdateStatus = &UpdateStatusAddCmprsCall;

	//k_MyCrDirCmprsCallbacks.f_FilePlaced = &FilePlacedCrDirCmprsCall;
	//k_MyCrDirCmprsCallbacks.f_GetNextCabinet = &GetNextCabinetCrDirCmprsCall;
	//k_MyCrDirCmprsCallbacks.f_UpdateStatus = &UpdateStatusCrDirCmprsCall;
}}

static WIN32_FIND_DATA ff={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
static char s[MAX_PATH];
VOID FindDirFromEnumList(void*,unsigned char*,unsigned char*);
BOOL OnBeforeCopyFileEnumClls(Cabinet::CExtract::kCabinetFileInfo* pk_Info, void* p_Param)
{
wchar_t s[MAX_PATH];
unsigned char *p,*pp;int l=0;
	if(0==((char*)((LPVOID*)p_Param)[1])[0])//root
	{	p=(unsigned char*)strchr((char*)pk_Info->u16_RelPath,'\\');
		pp=(unsigned char*)strchr((char*)pk_Info->u16_RelPath,'/');
		if(!p) p = pp;
		else if(p<pp)p=pp;
		if(p)
		{	FindDirFromEnumList(p_Param,(unsigned char*)pk_Info->u16_RelPath,p);
			return FALSE;
		}
		else
		{	if(pk_Info->u16_RelPath[0])
			{	ff.nFileSizeLow=pk_Info->s32_Size;
				ff.dwFileAttributes=pk_Info->u16_Attribs;
				ff.ftCreationTime.dwLowDateTime=pk_Info->k_Time.dwLowDateTime;
				ff.ftCreationTime.dwHighDateTime=pk_Info->k_Time.dwHighDateTime;
				MultiByteToWideChar(AreFileApisANSI()?CP_ACP:CP_OEMCP,MB_PRECOMPOSED,
								   (char*)pk_Info->u16_RelPath,-1,s,MAX_PATH-1);
				addItemToPanelList( ( (PluginObj*) (((LPVOID*)p_Param)[0]) )->host,s,&ff);
				return FALSE;
	}	}	}
	//else: if not root
	p=(unsigned char*)strstrslashA((char*)pk_Info->u16_RelPath,(char*)((LPVOID*)p_Param)[1]);
	if(!p)return FALSE;
	unsigned char *pslsh=(unsigned char *)strchr((char*)p,'\\');
	unsigned char *pslsh1=(unsigned char *)strchr((char*)p,'/');
	if(!pslsh)pslsh=pslsh1;
	else if(pslsh<pslsh1)pslsh=pslsh1;
	if(!pslsh)
	{	ff.nFileSizeLow=pk_Info->s32_Size;
		ff.dwFileAttributes=pk_Info->u16_Attribs;
		ff.ftCreationTime.dwLowDateTime=pk_Info->k_Time.dwLowDateTime;
		ff.ftCreationTime.dwHighDateTime=pk_Info->k_Time.dwHighDateTime;
		MultiByteToWideChar(AreFileApisANSI()?CP_ACP:CP_OEMCP,MB_PRECOMPOSED,(LPCSTR)p,-1,s,MAX_PATH-1);
		addItemToPanelList( ( (PluginObj*) (((LPVOID*)p_Param)[0]) )->host,s,&ff);
		return FALSE;
	}
	FindDirFromEnumList(p_Param,p,pslsh);
	return FALSE;
}

static long enumDirBufSz=0;
static char *enumDirBuf=0,*pEnumDirBuf=0;
static wchar_t *enumDirBufW=0,*pEnumDirBufW=0;
static char pOldPath[MAX_PATH]={0};
static wchar_t pOldPathW[MAX_PATH]={0};
void DestroyEnumDirBuf()
{
	if(enumDirBuf)
		free(enumDirBuf);
	enumDirBuf=0;
	pEnumDirBuf=0;
	enumDirBufSz=0;
	if(enumDirBufW)
		free(enumDirBufW);
	enumDirBufW=0;
	pEnumDirBufW=0;
}

void ResetEnumDirBuf()
{
	pEnumDirBuf=enumDirBuf;
	if(pEnumDirBuf)
		pEnumDirBuf[0]=0;
	if(pOldPath)
		pOldPath[0]=0;
	pEnumDirBufW=enumDirBufW;
	if(pEnumDirBufW)
		pEnumDirBufW[0]=0;
	if(pOldPathW)
		pOldPathW[0]=0;
}

VOID CheckDirList(void* p_Param,unsigned char *newPath,int ln)
{	
wchar_t s[MAX_PATH];
	if(!enumDirBuf)
	{	enumDirBuf=(char*)malloc(sizeof(char)*MIN_BUF_SIZE);
		if(!enumDirBuf)return;
		pEnumDirBuf=enumDirBuf;
		enumDirBufSz=MIN_BUF_SIZE;
		*((BYTE*)pEnumDirBuf)=(BYTE)ln;
		pEnumDirBuf = (char*) (((BYTE*)pEnumDirBuf)+1);
		for(int i=0; i<ln+1; i++) pEnumDirBuf[i]=newPath[i];
		pEnumDirBuf += ln+1;
		*pEnumDirBuf=0;//oxirgisini 0 qilib qo'yamiz:
	}
	else
	{	char *p=enumDirBuf;BOOL bFind=FALSE;
		while(*((char*)p))
		{	bFind=TRUE;
			BYTE l = *p++;
			for(BYTE i=0; i<l; i++)
			{	if(p[i]!=newPath[i])
				{	bFind=FALSE;
					break;
			}	}
			if(bFind)break;
			p+=l+1;
		}
		if(bFind)return;
		if(pEnumDirBuf-enumDirBuf>ln+enumDirBufSz-MAX_PATH-2)
		{	enumDirBuf=(char*)realloc(enumDirBuf,sizeof(char)*(ln+enumDirBufSz+MIN_BUF_SIZE+2));
			if(!enumDirBuf)return;
			enumDirBufSz += ln+MIN_BUF_SIZE+2;
		}
		*pEnumDirBuf++ = (BYTE)ln;
		for(int i=0; i<=ln; i++)
			pEnumDirBuf[i]=newPath[i];
		pEnumDirBuf += ln+1;
		*pEnumDirBuf=0;
	}
	ff.dwFileAttributes=FILE_ATTRIBUTE_DIRECTORY;
	MultiByteToWideChar(AreFileApisANSI()?CP_ACP:CP_OEMCP,MB_PRECOMPOSED,(char*)newPath,-1,s,MAX_PATH);
	addItemToPanelList(( (PluginObj*) (((LPVOID*)p_Param)[0]) )->host,s,&ff);
}

VOID FindDirFromEnumList(void* p_Param,unsigned char *pd,unsigned char *pdEnd)
{
unsigned char *p,*pBeg=(unsigned char*)&pOldPath[0];
	if(pOldPath[0])if(0==strncmp(pOldPath,(char*)pd,pdEnd-pd))return;//wcscmp(pOldPath,pd))return;
	for(p=(unsigned char*)&pOldPath[0]; *pd;)
	{	if(pd<=pdEnd)
		{	if('\\'==(*pd) || '/'==(*pd))
			{	unsigned char sl=*p;
				*p=0;
				CheckDirList(p_Param,pBeg,(int)(p-pBeg));
				*p=sl;//'\\';
				pBeg=p+1;
			}
			*p=*pd;
			++p;++pd;
		}
		else
		{	*p=0;
			return;
}	}	}

extern "C" {
char* strstrslashA(char *s1,char *s2)
{
	for(;*s2;)//*s1 ham bor edi;
	{	if((*s1)==(*s2)) {++s1;++s2;continue;}
		if('\\'==(*s1) && '/'==(*s2)) {++s1;++s2;continue;}
		if('/'==(*s1) && '\\'==(*s2)) {++s1;++s2;continue;}
		return ((0==(*s2))?s1:0);
	}
	return s1;
}

wchar_t* strstrslashW(wchar_t *s1,wchar_t *s2)
{
	for(;*s2;)//*s1 ham bor edi;
	{	if((*s1)==(*s2)) {++s1;++s2;continue;}
		if('\\'==(*s1) && '/'==(*s2)) {++s1;++s2;continue;}
		if('/'==(*s1) && '\\'==(*s2)) {++s1;++s2;continue;}
		return ((0==(*s2))?s1:0);
	}
	return s1;
}

BOOL strcmpslashA(char *s1,char *s2)
{
	for(;(*s1) && (*s2);)//*s1 ham bor edi;
	{	if((*s1)==(*s2)) {++s1;++s2;continue;}
		if('\\'==(*s1) && '/'==(*s2)) {++s1;++s2;continue;}
		if('/'==(*s1) && '\\'==(*s2)) {++s1;++s2;continue;}
		return TRUE;
	}
	return (*s1==*s2?FALSE:TRUE);
}

BOOL strcmpslashW(wchar_t *s1,wchar_t *s2)
{
	for(;(*s1) && (*s2);)//*s1 ham bor edi;
	{	if((*s1)==(*s2)) {++s1;++s2;continue;}
		if('\\'==(*s1) && '/'==(*s2)) {++s1;++s2;continue;}
		if('/'==(*s1) && '\\'==(*s2)) {++s1;++s2;continue;}
		return TRUE;
	}
	return (*s1==*s2?FALSE:TRUE);
}

char* strstrslashGetLastA(char *s1,char *s2,char **pLastSlash)
{
	*pLastSlash = s1;
	for(;*s2;)//*s1 ham bor edi;
	{	if('\\'==(*s1) || '/'==(*s1)) *pLastSlash = s1;
		if((*s1)==(*s2)) {++s1;++s2;continue;}
		if('\\'==(*s1) && '/'==(*s2)) {++s1;++s2;continue;}
		if('/'==(*s1) && '\\'==(*s2)) {++s1;++s2;continue;}
		return ((0==(*s2))?s1:0);
	}
	return s1;
}

wchar_t* strstrslashGetLastW(wchar_t *s1,wchar_t *s2,wchar_t **pLastSlash)
{
	*pLastSlash = s1;
	for(;*s2;)//*s1 ham bor edi;
	{	if('\\'==(*s1) || '/'==(*s1)) *pLastSlash = s1;
		if((*s1)==(*s2)) {++s1;++s2;continue;}
		if('\\'==(*s1) && '/'==(*s2)) {++s1;++s2;continue;}
		if('/'==(*s1) && '\\'==(*s2)) {++s1;++s2;continue;}
		return ((0==(*s2))?s1:0);
	}
	return s1;
}

}//extern "C"

//******************** Unpack routine **********************
//******************** Unpack routine **********************
//******************** Unpack routine **********************
//******************** Unpack routine **********************
//******************** Unpack routine **********************
//******************** Unpack routine **********************
//******************** Unpack routine **********************
//******************** Unpack routine **********************
//******************** Unpack routine **********************
//******************** Unpack routine **********************
BOOL OnBeforeCopyFileUnpClls(Cabinet::CExtract::kCabinetFileInfo* pk_Info, void* p_Param)
{
static wchar_t s[MAX_PATH];int l;
char *pLastSlash,*p=strstrslashGetLastA((char*)pk_Info->u16_RelPath,(char*)((LPVOID*)p_Param)[3],&pLastSlash);//Unp name
	if(p)
	{	if(0==(*p))
		{	pk_Info->u16_Path=(wchar_t*)((LPVOID*)p_Param)[2];
			l=MyStringCpy(s,MAX_PATH,(wchar_t*)((LPVOID*)p_Param)[2]);
			MyStringCpy(&s[l],MAX_PATH-l,(wchar_t*)pk_Info->u16_File);
			pk_Info->u16_FullPath=(wchar_t*)&s[0];
			return TRUE;
		}
		else
		{	static wchar_t sw[MAX_PATH];
			if(pLastSlash>((char*)pk_Info->u16_RelPath))
				if(0!=*(pLastSlash+1))
					++pLastSlash;
			MultiByteToWideChar(AreFileApisANSI()?CP_ACP:CP_OEMCP,MB_PRECOMPOSED,pLastSlash,-1,sw,MAX_PATH);
			pk_Info->u16_Path=(wchar_t*)((LPVOID*)p_Param)[2];
			l=MyStringCpy(s,MAX_PATH,(wchar_t*)((LPVOID*)p_Param)[2]);
			MyStringCpyCrctSlash(&s[l],MAX_PATH-l,sw);
			pk_Info->u16_FullPath=(wchar_t*)&s[0];
			MyStringCpy(sw,MAX_PATH,s);
			wchar_t* pss=wcsrchr(sw,'\\');if(pss)*pss=0;
			pk_Info->u16_Path=(wchar_t*)&sw[0];
			return TRUE;
	}	}
	return FALSE;
}

void OnProgressInfoUnpClls(Cabinet::CExtract::kProgressInfo* pk_Progress, void* p_Param)
{
	if(0!=((LPVOID*)p_Param)[5])
		((UnpackProgressRoutine_t)((LPVOID*)p_Param)[5])(pk_Progress->u32_Written,pk_Progress->u32_TotSize,(wchar_t*)(((LPVOID*)p_Param)[2]));
	else
	{	if(prgrssRout)
		{	unsigned __int64 CrntFileProgressed = pk_Progress->u32_Written;
			unsigned __int64 CrntFileTotal = pk_Progress->u32_TotSize;
			prgrssRout(((PluginObj*)((LPVOID*)p_Param)[1])->host,
						&CrntFileProgressed,
						&CrntFileTotal,
						0,
						0);
}	}	}

// ******************** Delete routine ************************
// ******************** Delete routine ************************
// ******************** Delete routine ************************
// ******************** Delete routine ************************
// ******************** Delete routine ************************
// ******************** Delete routine ************************
// ******************** Delete routine ************************
// ******************** Delete routine ************************
// ******************** Delete routine ************************
// ******************** Delete routine ************************
// ******************** Delete routine ************************
// ******************** Delete routine ************************
// ******************** Delete routine ************************
// ******************** Delete routine ************************
/*BOOL OnBeforeCopyFileDelClls(Cabinet::CExtract::kCabinetFileInfo* pk_Info, void* p_Param)
{
wchar_t pth[MAX_PATH];
	MultiByteToWideChar(AreFileApisANSI()?CP_ACP:CP_OEMCP,MB_PRECOMPOSED,
						(char*)pk_Info->u16_RelPath,-1,pth,MAX_PATH-1);
	if((BOOL)((LPVOID*)p_Param)[2])
	{	wchar_t *ps=strstrslashW(pth,(wchar_t*)((LPVOID*)p_Param)[1]);
		if(ps)
			return TRUE;
	}
	else
	{	if(strcmpslashW(pth,(wchar_t*)((LPVOID*)p_Param)[1]))
			return TRUE;
	}
	return FALSE;
}*/

// ***************** Add$24 *****************
// ***************** Add$24 *****************
// ***************** Add$24 *****************
// ***************** Add$24 *****************
// ***************** Add$24 *****************
// ***************** Add$24 *****************
// ***************** Add$24 *****************
// ***************** Add$24 *****************
// ***************** Add$24 *****************
// ***************** Add$24 *****************
// ***************** Add$24 *****************
// ***************** Add$24 *****************

int  FilePlacedAddCmprsCall(PCCAB pccab, WCHAR* s, int k, BOOL b, void* p_Param)
{
	return 0;
}

BOOL GetNextCabinetAddCmprsCall(PCCAB pccab, ULONG u, unsigned char* c, void* p_Param)
{
	return TRUE;
}

int  UpdateStatusAddCmprsCall(UINT u, CCompress::kCurStatus* k, void* p_Param)
{
WIN32_FIND_DATAA *ff = (WIN32_FIND_DATAA*)((PluginObj*)p_Param)->cmprsPar[4];//WIN32_FIND_DATAA *ff=(WIN32_FIND_DATAA *)(((LPVOID*)p_Param)[6]);

unsigned __int64 *CrntFileProgressed = (unsigned __int64*)&(((PluginObj*)p_Param)->cmprsPar[6]);
unsigned __int64 CrntFileTotal;

	if(ff)
	{	CrntFileTotal =	ff->nFileSizeLow;
		if(ff->nFileSizeHigh)
			CrntFileTotal += (unsigned __int64)ff->nFileSizeHigh << 32;
	}
	else
	{
		CrntFileTotal =	k->cb2;
	}
	
	*CrntFileProgressed += k->cb2;//u32_TotUncompressedSize;

	if(prgrssRout)
		prgrssRout(((PluginObj*)p_Param)->host,//prgrssRout(((PluginObj*)((LPVOID*)p_Param)[0])->host,
					CrntFileProgressed,
					&CrntFileTotal,
					0,
					0);
	return 0;
}


//************* CreateDir$24 ***************
//************* CreateDir$24 ***************
//************* CreateDir$24 ***************
//************* CreateDir$24 ***************
//************* CreateDir$24 ***************
//************* CreateDir$24 ***************
//************* CreateDir$24 ***************
//************* CreateDir$24 ***************
//************* CreateDir$24 ***************
//************* CreateDir$24 ***************
//************* CreateDir$24 ***************
/*int  FilePlacedCrDirCmprsCall(PCCAB pccab, WCHAR* s, int k, BOOL b, void* p_Param)
{
	return 0;
}

BOOL GetNextCabinetCrDirCmprsCall(PCCAB pccab, ULONG u, unsigned char* c, void* p_Param)
{
	return TRUE;
}

int  UpdateStatusCrDirCmprsCall(UINT u, CCompress::kCurStatus* k, void* p_Param)
{
	return 0;
}*/

//************** SearchRoot routine ***************
//************** SearchRoot routine ***************
//************** SearchRoot routine ***************
//************** SearchRoot routine ***************
//************** SearchRoot routine ***************
//************** SearchRoot routine ***************
//************** SearchRoot routine ***************
//************** SearchRoot routine ***************
//************** SearchRoot routine ***************
//************** SearchRoot routine ***************
//************** SearchRoot routine ***************
//************** SearchRoot routine ***************
//************** SearchRoot routine ***************
//************** SearchRoot routine ***************
//************** SearchRoot routine ***************
//************** SearchRoot routine ***************
//************** SearchRoot routine ***************
VOID CheckDirSearchList(void* p_Param,wchar_t *newPath,int ln,FindStrWthFltr *fs)
{	
	if(!enumDirBufW)
	{	enumDirBufW=(wchar_t*)malloc(sizeof(wchar_t)*MIN_BUF_SIZE);
		if(!enumDirBufW)return;
		pEnumDirBufW=enumDirBufW;
		enumDirBufSz=MIN_BUF_SIZE;
		*((WCHAR*)pEnumDirBufW)=(WCHAR)ln;
		pEnumDirBufW = (wchar_t*) (((WCHAR*)pEnumDirBufW)+1);
		for(int i=0; i<ln+1; i++) pEnumDirBufW[i]=newPath[i];
		pEnumDirBufW += ln+1;
		*pEnumDirBufW=0;//oxirgisini 0 qilib qo'yamiz:
	}
	else
	{	wchar_t *p=enumDirBufW;BOOL bFind=FALSE;
		while(*((wchar_t*)p))
		{	bFind=TRUE;
			WCHAR l = *p++;
			for(WCHAR i=0; i<l; i++)
			{	if(p[i]!=newPath[i])
				{	bFind=FALSE;
					break;
			}	}
			if(bFind)break;
			p+=l+1;
		}
		if(bFind)return;
		if(pEnumDirBufW-enumDirBufW>ln+enumDirBufSz-MAX_PATH-2)
		{	enumDirBufW=(wchar_t*)realloc(enumDirBufW,sizeof(wchar_t)*(ln+enumDirBufSz+MIN_BUF_SIZE+2));
			if(!enumDirBufW)return;
			enumDirBufSz += ln+MIN_BUF_SIZE+2;
		}
		*pEnumDirBufW++ = (WCHAR)ln;
		for(int i=0; i<=ln; i++)
			pEnumDirBufW[i]=newPath[i];
		pEnumDirBufW += ln+1;
		*pEnumDirBufW=0;
	}
	ff.dwFileAttributes=FILE_ATTRIBUTE_DIRECTORY;
	AddToInfoEdit(newPath,0);
	if(fs->CheckNameAndExt(newPath))	
		AddToResultsLB(&ff,newPath);
}

BOOL FindDirFromSearchList(void* p_Param,wchar_t *pd,wchar_t *pdEnd,FindStrWthFltr *fs)
{
wchar_t *p,*pBeg=&pOldPathW[0];BOOL rt=FALSE;
	if(pOldPathW[0])if(0==wcsncmp(pOldPathW,(wchar_t*)pd,pdEnd-pd))return FALSE;
	for(p=&pOldPathW[0]; *pd;)
	{	if(pd<=pdEnd)
		{	if('\\'==(*pd) || '/'==(*pd))
			{	wchar_t sl=*p;
				*p=0;
				CheckDirSearchList(p_Param,pBeg,(int)(p-pBeg),fs);
				*p=sl;//'\\';
				pBeg=p+1;
				rt=TRUE;
			}
			*p=*pd;
			++p;++pd;
		}
		else
		{	*p=0;
			return rt;
	}	}
	return rt;
}

BOOL OnBeforeCopyFileSearchClls(Cabinet::CExtract::kCabinetFileInfo* pk_Info, void* p_Param)
{
wchar_t *p;int l=0;
	FindStrWthFltr *fs = (FindStrWthFltr*)(((LPVOID*)p_Param)[2]);
	p=strstrslashW(pk_Info->u16_RelPath,(wchar_t*)((LPVOID*)p_Param)[1]);
	if(!p)return FALSE;
	wchar_t *pslsh=wcschr(p,'\\');
	wchar_t *pslsh1=wcschr(p,'/');
	if(!pslsh)pslsh=pslsh1;
	else if(pslsh<pslsh1)pslsh=pslsh1;
	if((!pslsh) || item.bEnumSubDir)
	{	ff.dwFileAttributes=pk_Info->u16_Attribs;
		if(fs->CheckNameAndExt(pk_Info->u16_RelPath))
		{	ff.dwFileAttributes=pk_Info->u16_Attribs;
			if(FILE_ATTRIBUTE_DIRECTORY & ff.dwFileAttributes)
			{	if(item.bEnumSubDir)
				{	AddToInfoEdit(pk_Info->u16_RelPath,0);
					return FALSE;
			}	}
			else
				AddToResultsLB(&ff,pk_Info->u16_RelPath);
			return FALSE;
		}
		return FALSE;
	}
	//else
	FindDirFromSearchList(p_Param,p,pslsh,fs);
	return FALSE;
}

void OnProgressInfoSearchClls(Cabinet::CExtract::kProgressInfo* pk_Progress, void* p_Param)
{
	if(0!=((LPVOID*)p_Param)[5])
		((UnpackProgressRoutine_t)((LPVOID*)p_Param)[5])(pk_Progress->u32_Written,pk_Progress->u32_TotSize,(wchar_t*)(((LPVOID*)p_Param)[2]));
	else
	{	if(prgrssRout)
		{	unsigned __int64 CrntFileProgressed = pk_Progress->u32_Written;
			unsigned __int64 CrntFileTotal = pk_Progress->u32_TotSize;
			prgrssRout(((PluginObj*)((LPVOID*)p_Param)[1])->host,
						&CrntFileProgressed,
						&CrntFileTotal,
						0,
						0);
}	}	}