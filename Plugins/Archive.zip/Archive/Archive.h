#ifndef _ARCHIVE_H__
#define _ARCHIVE_H__

#include "windows.h"
#include "..\..\Operations\CopyOperation.h"
#include "..\..\Operations\DeleteOperation.h"

#define BEGIN_TRY __try {
#define END_TRY }\
			__except(EXCEPTION_EXECUTE_HANDLER)


#define MYWM_CANCEL						0x7f00
#define MYWM_STOP						0x7f01
#define MYWM_GOTOBCKGRND				0x7f02
#define MYWM_ROLLDOWN					0x7f03
#define MYWM_ERASE_COPIED_AND_EXIT		0x7f04
#define MYWM_SET_CHECK_COPIED			0x7f05


struct ArcStack
{	wchar_t	 attribute;
	int		 numInSrc;
	unsigned __int64	 size;//in bytes;
	wchar_t  RelatedPathAndName[MAX_PATH];
	wchar_t  FullPathAndName[MAX_PATH];
	int   RelatedPathAndNameLn;
	int   FullPathAndNameLn;
};

class CArch;
class CArchPlgn;
namespace archive
{
	//Ob'yazatelniye:
	typedef	BOOL (*Add$24_t)(LPVOID,wchar_t*,wchar_t*,wchar_t*,int,BOOL);
	typedef	BOOL (*CreateDir$24_t)(LPVOID,wchar_t*,wchar_t*,wchar_t*,int,BOOL);
	typedef BOOL (*AddEmptyDir$20_t)(LPVOID,wchar_t*,wchar_t*,int,BOOL);

	typedef const wchar_t* (*GetArchExtnsn_t)();
	typedef const int (*GetPluginType_t)();
	typedef LPVOID (*Open$12_t)(wchar_t*,BOOL,LPVOID);
	typedef BOOL (*Close$4_t)(LPVOID);
	typedef BOOL (*RebuildCheckExistings$8_t)(LPVOID,wchar_t*);
	typedef BOOL (*RenameFile$12_t)(LPVOID,wchar_t*,wchar_t*);
	typedef BOOL (*RenameDir$12_t)(LPVOID,wchar_t*,wchar_t*);
	typedef BOOL (*DeleteFile$8_t)(LPVOID,wchar_t*);
	typedef BOOL (*DeleteDir$8_t)(LPVOID,wchar_t*);
	typedef VOID (*SetCallbacks$4xxx_t)(LPVOID,...);
	typedef LPVOID (*ShowSearchDlg$12_t)(LPVOID,HWND,wchar_t*);
	typedef VOID (*SetId$4_t)(int);
	typedef VOID (*UnpackProgressRoutine_t)(unsigned __int64,unsigned __int64,wchar_t*);

	//Ob'yazatelniye dlya raspakovochnyx:
	typedef LPVOID (*OpenForUnpacking$8_t)(wchar_t*,LPVOID);
	typedef BOOL (*EnumDirectory$8_t)(LPVOID,wchar_t*);
	typedef BOOL (*Unpack$28_t)(HWND,LPVOID,wchar_t*,wchar_t*,BOOL*,UnpackProgressRoutine_t,__int32*); 

	//Dopolnitelniye:
	typedef int  (*GetTotalCryptMethods_t)();
	typedef const wchar_t* (*GetCryptDescription$4_t)(int);
	typedef VOID (*SetCryptMethod$8_t)(LPVOID,int);
	typedef const wchar_t* (*GetPluginDescription_t)();
	typedef VOID (*ShowOptionDialog_t)(HWND);

	extern BOOL ShowDlg(Panel*);//Add to archive dlg;
	extern BOOL ToArjShowDlg(Panel*,Panel*);//to existing and opening archive:
	extern BOOL FrArjToArjShowDlg(Panel*,Panel*);//to existing and opening archive:
	extern BOOL ShowUnpckDlg(Panel*);
	extern VOID ShowSearchDlg$12(Panel*);
	extern VOID buildArchvThrdFnc(LPVOID);
	extern VOID addArjToArjThrdFnc(LPVOID);
	extern INT_PTR CALLBACK arcExstOvwrtQuestnDlgProc(HWND,UINT,WPARAM,LPARAM);
	extern VOID FreePlugins();
	extern VOID LoadPlugins();
	extern VOID TryLoadPlugin(wchar_t*,wchar_t*,int);

//ArchiveCopy.cpp:************
	extern VOID UnpackCpyProgressRoutine(__in unsigned __int64,__in unsigned __int64,__in wchar_t*);
	extern INT_PTR CALLBACK CopyQueueDlgProc(HWND,UINT,WPARAM,LPARAM);
	extern int GetUnpackPlgnNum(wchar_t*);
	extern int GetCpySelectedFilesCnt(Panel*);
	extern int GetCpySelectedFiles(CpyStack*,Panel*);
	extern int GetRMCpySelectedFilesCnt();
	extern int GetRMCpySelectedFiles(CpyStack*);

	extern CArchPlgn *plgns;
	extern int numPlugins;
}
using namespace archive;

class CArch;
class CArchPlgn
{
friend VOID archive::TryLoadPlugin(wchar_t*,wchar_t*,int);

//First public functns for calling from plugins:
static int   CALLBACK checkFileInSelctn(CArch*,wchar_t*);
static VOID  CALLBACK excldFileFrSelctn(CArch*,int,int);
static BOOL  CALLBACK getFileInfoFromSelection(CArch*,int,OUT WIN32_FIND_DATA*);
static DWORD CALLBACK prgrssRout(CArch*,unsigned __int64*,unsigned __int64*,unsigned __int64*,unsigned __int64*);
static int   CALLBACK showDlgOverwriteExistFile(CArch*,int,wchar_t*,unsigned __int64*,FILETIME*,WIN32_FIND_DATA*);
static BOOL  CALLBACK saveOptions(int,VOID*,int);
static BOOL  CALLBACK readOptions(int,VOID*,int);
static int   CALLBACK addItemToPanelList(CArch*,wchar_t*,WIN32_FIND_DATAW*);

public:
	CArchPlgn();
	~CArchPlgn();
	HMODULE hm;
	//int	dllSize;
	wchar_t pathAndName[MAX_PATH],descrpn[MAX_PATH],extnsn[16];
	int  type,idNum,mRef;

	BOOL LoadPlugin();
	VOID FreePlugin();

	archive::Add$24_t Add$24;
	archive::CreateDir$24_t CreateDir$24;
	archive::AddEmptyDir$20_t AddEmptyDir$20;
	archive::GetArchExtnsn_t GetArchExtnsn;
	archive::GetPluginType_t GetPluginType;
	archive::Open$12_t Open$12;
	archive::Close$4_t Close$4;
	archive::RebuildCheckExistings$8_t RebuildCheckExistings$8;
	archive::RenameFile$12_t RenameFile$12;
	archive::RenameDir$12_t RenameDir$12;
	archive::DeleteFile$8_t DeleteFile$8;
	archive::DeleteDir$8_t DeleteDir$8;
	archive::SetCallbacks$4xxx_t SetCallbacks$4xxx;
	archive::SetId$4_t SetId$4;

	archive::OpenForUnpacking$8_t OpenForUnpacking$8;
	archive::EnumDirectory$8_t EnumDirectory$8;
	archive::Unpack$28_t Unpack$28;
	archive::ShowSearchDlg$12_t ShowSearchDlg$12;

	archive::GetTotalCryptMethods_t GetTotalCryptMethods;
	archive::GetCryptDescription$4_t GetCryptDescription$4;
	archive::SetCryptMethod$8_t SetCryptMethod$8;
	archive::GetPluginDescription_t GetPluginDescription;
	archive::ShowOptionDialog_t ShowOptionDialog;
};

class CArch
{
friend VOID archive::buildArchvThrdFnc(LPVOID);
friend VOID archive::addArjToArjThrdFnc(LPVOID);
friend INT_PTR CALLBACK AppndFileExistDlgProc(HWND,UINT,WPARAM,LPARAM);
friend INT_PTR CALLBACK archive::arcExstOvwrtQuestnDlgProc(HWND,UINT,WPARAM,LPARAM);
friend VOID fDelOper::deleteExThrdFnc(LPVOID*);

friend class CZLib;
friend class Panel;
friend class FillManager;
friend class CArchPlgn;
friend class SheetTab;
public:
			CArch();
		   ~CArch();

	BOOL	Add$24(int);
	BOOL	Close$4();
	BOOL	CreateDir$24(int);
	int		GetFilesInFolder(wchar_t*,ArcStack*);
	int		GetSelectedFilesCnt(int);
	int		GetSelectedFiles();
	BOOL	Open$12(wchar_t*,int,int);
	BOOL	OpenForUnpacking$8(wchar_t*,int);
	BOOL	RebuildCheckExistings$8(LPVOID,wchar_t*);
	BOOL	Rename$12(wchar_t*,wchar_t*,BOOL);
	BOOL	Delete$8(wchar_t*,BOOL);//,int,int);
	BOOL	DeleteSelections(Panel*);
	BOOL	SetCryptMethod$8(int);
	int     GetPlgNum();
	LPVOID  GetPlgObj();
	VOID	SetPlgObj(LPVOID);
	VOID	SetPlgNum(int);

protected:
	HWND	 hDlg;
	BOOL	 bStop,bCancel;
	ArcStack *stack;
	DWORD	 thrId,beginTickTot,stopTickTot[2],beginTick,stopTick[2];
	BOOL	 bExcldPath,bDelAftArchiving,bSFXArchive;
	LPVOID   plgObj;
	int		 plgNum;
	int		 iCrntFileCopy,totFiles,nameLn,srcPanel;
struct 
{	int postedSzNextFile;
	unsigned __int64 postedSz,postedSzStep;
} prgrs;
	unsigned __int64 srcSz,*crntFileSzPtr;
	int		 cmqlev,crypt;
	wchar_t	 name[MAX_PATH],password[MAX_PATH];//archive file name;
};

inline BOOL CArch::RebuildCheckExistings$8(LPVOID plgObj,wchar_t *s)
{
BEGIN_TRY
	return archive::plgns[plgNum].RebuildCheckExistings$8(plgObj,s);
END_TRY
{	return FALSE;
}}

inline int CArch::GetPlgNum(){return plgNum;}
inline VOID CArch::SetPlgNum(int plnum){plgNum=plnum;}
inline LPVOID CArch::GetPlgObj(){return plgObj;}
inline VOID	CArch::SetPlgObj(LPVOID obj){plgObj=obj;}

#endif