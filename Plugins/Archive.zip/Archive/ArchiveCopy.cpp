#include "Archive.h"
//#include "shlobj.h"
#include "strsafe.h"
#include "..\..\Sino.h"
#include "..\..\Config.h"
//#include "LinkSocket.h"
//#include "MyErrors.h"
#include "..\..\Operations\RenMove.h"
#include "..\..\Operations\DeleteOperation.h"
#include "..\..\Operations\Backgrnd thread copy operation.h"
#include "..\..\Operations\MyShell\resource.h"
//#include "..\WindowsManagmentInstrumentation.h"

#pragma warning(disable:4995)

namespace archive
{

HWND *prgrsDlg=0;
VOID UnpackCpyProgressRoutine(__in unsigned __int64 TotalSize,__in unsigned __int64 TotalTransferred,wchar_t *name)
{
//	fCopyOper::copySrcSz += TotalTransferred;
//	fCopyOper::avDstSz -= TotalTransferred;
	if(prgrsDlg && TotalSize>0)
	{	unsigned __int64 p=100*TotalTransferred/TotalSize;		
		PostMessage(GetDlgItem(*prgrsDlg,IDC_PROGRESS_COPY_SINGLE),PBM_SETPOS,(WPARAM)p,0);
		//PostMessage(GetDlgItem(*prgrsDlg,IDC_PROGRESS_COPY_TOTAL ),PBM_SETPOS,(WPARAM)p,0);
		wchar_t s[64];
		int l=wsprintf(s,L"%d ",p);s[l]='%';s[l+1]=0;
		SetDlgItemText(*prgrsDlg,IDC_STATIC1,s);
		l=wsprintf(s,L"%d ",100-p);s[l]='%';s[l+1]=0;
		SetDlgItemText(*prgrsDlg,IDC_STATIC3,s);
		SetDlgItemText(*prgrsDlg,IDC_STATIC,name);
		ShowWindow(GetDlgItem(*prgrsDlg,IDC_STATIC6),SW_HIDE);
		ShowWindow(GetDlgItem(*prgrsDlg,IDC_STATIC8),SW_HIDE);
		ShowWindow(GetDlgItem(*prgrsDlg,IDC_STATIC5),SW_HIDE);
		ShowWindow(GetDlgItem(*prgrsDlg,IDC_PROGRESS_COPY_TOTAL),SW_HIDE);
}	}

/*VOID UnpackRMCpyProgressRoutine(__in unsigned __int64 TotalSize,__in unsigned __int64 TotalTransferred)
{
	fRenMove::copySrcSz += TotalTransferred;
	fRenMove::avDstSz -= TotalTransferred;
	if(TotalTransferred>0.01)
		PostMessage(GetDlgItem(*prgrsDlg,IDC_PROGRESS_COPY_SINGLE),PBM_SETPOS,(WPARAM)(1000*TotalSize/TotalTransferred),0);
	PostMessage(GetDlgItem(*prgrsDlg,IDC_PROGRESS_COPY_TOTAL ),PBM_SETPOS,
    (int)(fRenMove::srcSz?(1000.0f*fRenMove::copySrcSz/fRenMove::srcSz):1000.0f),0);
}*/

int GetCpySelectedFilesCnt(Panel *p)
{
	int tot=p->GetTotSelects();
	if(!tot)
	{	int ht=p->GetHot();
		if(ht>0 && ht<p->GetTotItems())
		{	if(file == p->GetItem(ht)->attribute)
				return 1;
			else if(folder == p->GetItem(ht)->attribute)
			{	wchar_t pth[MAX_PATH]; 
				int l=p->GetFullPathAndName(ht,pth,MAX_PATH);
				++tot;//folderniyam;
			}
			return tot;
		}
		else return 0;
	}
	tot = 0;
	for(int i=0; i<p->GetTotItems(); i++)
	{	if(selected==p->GetItem(i)->state || (0==p->GetTotSelects() && i==p->GetHot()))
		{	if(file == p->GetItem(i)->attribute)
				++tot;
			else if(folder == p->GetItem(i)->attribute)
			{	wchar_t pth[MAX_PATH];
				int l=p->GetFullPathAndName(i,pth,MAX_PATH);
				++tot;//folderniyam;
	}	}	}
	return tot;
}

int GetRMCpySelectedFilesCnt()
{
	int tot=panel[fRenMove::srcPanel].GetTotSelects();
	if(!tot)
	{	int ht=panel[fRenMove::srcPanel].GetHot();
		if(ht>0 && ht<panel[fRenMove::srcPanel].GetTotItems())
		{	if(file == panel[fRenMove::srcPanel].GetItem(ht)->attribute)
				return 1;
			else if(folder == panel[fRenMove::srcPanel].GetItem(ht)->attribute)
			{	wchar_t pth[MAX_PATH]; 
				int l=panel[fRenMove::srcPanel].GetFullPathAndName(ht,pth,MAX_PATH);
				++tot;//folderniyam;
			}
			return tot;
		}
		else return 0;
	}
	tot = 0;
	for(int i=0; i<panel[fRenMove::srcPanel].GetTotItems(); i++)
	{	if(selected==panel[fRenMove::srcPanel].GetItem(i)->state || (0==panel[fRenMove::srcPanel].GetTotSelects() && i==panel[fRenMove::srcPanel].GetHot()))
		{	if(file == panel[fRenMove::srcPanel].GetItem(i)->attribute)
				++tot;
			else if(folder == panel[fRenMove::srcPanel].GetItem(i)->attribute)
			{	wchar_t pth[MAX_PATH];
				int l=panel[fRenMove::srcPanel].GetFullPathAndName(i,pth,MAX_PATH);
				++tot;//folderniyam;
	}	}	}
	return tot;
}

int GetCpySelectedFiles(CpyStack *stack,Panel *p)//from archive directory:
{
	int tot=p->GetTotSelects();
	if(!tot)
	{	int ht = p->GetHot();
		if(ht>0 && ht<p->GetTotItems())
		{	if(file == p->GetItem(ht)->attribute)
			{	MyStringCpy(stack[tot].Name,MAX_PATH-1,p->GetItem(ht)->Name);
				MyStringCpy(stack[tot].FullPathAndName,MAX_PATH-1,p->GetArcItPathAndName(ht));
				
				stack[tot].size = p->GetItem(ht)->size;
				stack[tot].attribute = file;
				return 1;
			}
			else if(folder == p->GetItem(ht)->attribute)
			{	MyStringCpy(stack[tot].Name,MAX_PATH-1,p->GetItem(ht)->Name);
				MyStringCpy(stack[tot].FullPathAndName,MAX_PATH-1,p->GetArcItPathAndName(ht));
				
				stack[tot].attribute = folder;
				++tot;//folderniyam;
	 		}
			return tot;
		}		
		else return 0;
	}
 tot=0;
 for(int i=0; i<p->GetTotItems(); i++)
 {	if(selected==p->GetItem(i)->state || (0==p->GetTotSelects() && i==p->GetHot()))
	{	if(file == p->GetItem(i)->attribute)
		{	MyStringCpy(stack[tot].Name,MAX_PATH-1,p->GetItem(i)->Name);
			MyStringCpy(stack[tot].FullPathAndName,MAX_PATH-1,p->GetArcItPathAndName(i));
			
			stack[tot].size = p->GetItem(i)->size;
			stack[tot].attribute = file;
			++tot;
		}
		else if(folder == p->GetItem(i)->attribute)
		{	MyStringCpy(stack[tot].Name,MAX_PATH-1,p->GetItem(i)->Name);
			MyStringCpy(stack[tot].FullPathAndName,MAX_PATH-1,p->GetArcItPathAndName(i));
			
			stack[tot].attribute = folder;
			++tot;//folderniyam;
 }	}	}
 return tot;
}

int GetRMCpySelectedFiles(CpyStack *stack)//from archive directory:
{
	int tot=panel[fRenMove::srcPanel].GetTotSelects();
	if(!tot)
	{	int ht = panel[fRenMove::srcPanel].GetHot();
		if(ht>0 && ht<panel[fRenMove::srcPanel].GetTotItems())
		{	if(file == panel[fRenMove::srcPanel].GetItem(ht)->attribute)
			{	MyStringCpy(stack[tot].Name,MAX_PATH-1,panel[fRenMove::srcPanel].GetItem(ht)->Name);
				MyStringCpy(stack[tot].FullPathAndName,MAX_PATH-1,panel[fRenMove::srcPanel].GetArcItPathAndName(ht));
				
				stack[tot].size = panel[fRenMove::srcPanel].GetItem(ht)->size;
				stack[tot].attribute = file;
				return 1;
			}
			else if(folder == panel[fRenMove::srcPanel].GetItem(ht)->attribute)
			{	MyStringCpy(stack[tot].Name,MAX_PATH-1,panel[fRenMove::srcPanel].GetItem(ht)->Name);
				MyStringCpy(stack[tot].FullPathAndName,MAX_PATH-1,panel[fRenMove::srcPanel].GetArcItPathAndName(ht));
				
				stack[tot].attribute = folder;
				++tot;//folderniyam;
	 		}
			return tot;
		}		
		else return 0;
	}
 tot=0;
 for(int i=0; i<panel[fRenMove::srcPanel].GetTotItems(); i++)
 {	if(selected==panel[fRenMove::srcPanel].GetItem(i)->state || (0==panel[fRenMove::srcPanel].GetTotSelects() && i==panel[fRenMove::srcPanel].GetHot()))
	{	if(file == panel[fRenMove::srcPanel].GetItem(i)->attribute)
		{	MyStringCpy(stack[tot].Name,MAX_PATH-1,panel[fRenMove::srcPanel].GetItem(i)->Name);
			MyStringCpy(stack[tot].FullPathAndName,MAX_PATH-1,panel[fRenMove::srcPanel].GetArcItPathAndName(i));
			
			stack[tot].size = panel[fRenMove::srcPanel].GetItem(i)->size;
			stack[tot].attribute = file;
			++tot;
		}
		else if(folder == panel[fRenMove::srcPanel].GetItem(i)->attribute)
		{	MyStringCpy(stack[tot].Name,MAX_PATH-1,panel[fRenMove::srcPanel].GetItem(i)->Name);
			MyStringCpy(stack[tot].FullPathAndName,MAX_PATH-1,panel[fRenMove::srcPanel].GetArcItPathAndName(i));
			
			stack[tot].attribute = folder;
			++tot;//folderniyam;
 }	}	}
 return tot;
}

VOID cpyFrFileExThrdFnc(LPVOID lpar)//arxivdan direct folderga copy qilish;
{
//Unpack progressni ishlatsa magar:	
//panel[fCopyOper::srcPanel].GetArch()->SetDlg((HWND)lpar);
cpyTrdDat dat; dat.hDlg = (HWND)lpar; prgrsDlg = &dat.hDlg;
  	dat.stack = 0;
  	dat.bStop = FALSE;
	dat.bCancel = FALSE;
	dat.bSwtchToBckgrnd = FALSE;
	dat.thrId = GetCurrentThreadId();
	dat.beginTick = dat.beginTickTot = GetTickCount();
	dat.stopTick[0] = dat.stopTickTot[0] = 0;
	enCheckCopyFilesToExisting = showEach;

 wchar_t dst[MAX_PATH],buf[MAX_PATH];
 size_t dstPathLn;

 int totFiles = GetCpySelectedFilesCnt(&panel[fCopyOper::srcPanel]);
 if(!totFiles)goto End;
 dat.stack = (CpyStack*)malloc(totFiles*sizeof(CpyStack));
 GetCpySelectedFiles(dat.stack,&panel[fCopyOper::srcPanel]);
 //CutSelectedNames(dat.stack,panel[fCopyOper::srcPanel].GetPath(),totFiles);

 dstPathLn=MyStringCpy(dst,MAX_PATH-1,fCopyOper::destPath);
 if(fCopyOper::allToRenFolder==fCopyOper::srcType)
 {	if('\\'!=dst[dstPathLn-1])
	{	if('*'!=dst[dstPathLn-1])
		{	dst[dstPathLn++]='\\';//MyStringCat(dst,MAX_PATH-1,L"\\");//Yangi yo'l kiritsa;
 			dst[dstPathLn]=0;
		}
		else dst[--dstPathLn]=0;
	}
	int m=MessageBox(dat.hDlg,L"Create this directory?",dst,MB_YESNOCANCEL|MB_ICONWARNING|MB_SYSTEMMODAL);
	if(IDNO==m)
	{	fCopyOper::srcType=fCopyOper::unchange;
		wchar_t *p=wcsrchr(dst,'\\');
		if(p) *(p+1)=0;
	}
	else if(IDCANCEL==m)
		goto End;	
  	if(!MyCreateDirectory(dst,NULL))//yangi yo'lini avval yaratib olsun;
		goto End;
 }

 __int32 bools=0;
 for(dat.iCrntFileCopy=0; dat.iCrntFileCopy<totFiles; dat.iCrntFileCopy++)
 {
 if(fCopyOper::unchange==fCopyOper::srcType || fCopyOper::allToRenFolder==fCopyOper::srcType)
	MyStringCpy(&dst[dstPathLn],(int)(MAX_PATH-dstPathLn),dat.stack[dat.iCrntFileCopy].Name);//MyStringCat(dst,MAX_PATH-1,dat.stack[dat.iCrntFileCopy].Name);
 else
 {	if(fCopyOper::allToRenFolder!=fCopyOper::srcType)
	{	if(fCopyOper::rename1Folder==fCopyOper::srcType)
		{	if(dat.iCrntFileCopy>0)
			{	wchar_t *p=NULL;
				if(folder==dat.stack[0].attribute)//o'zgartirsa:
					p = wcschr(dat.stack[dat.iCrntFileCopy].Name,'\\');
				MyStringCpy(&dst[dstPathLn],(int)(MAX_PATH-dstPathLn),p?p:dat.stack[dat.iCrntFileCopy].Name);//MyStringCat(dst,MAX_PATH-1,p?p:dat.stack[dat.iCrntFileCopy].Name);
 }	}	}	}

 if(fCopyOper::mCopyFileEx==fCopyOper::copyMethod)
 {  if(!wcscmp(dat.stack[dat.iCrntFileCopy].FullPathAndName,dst))
    {	LoadString(hInst,IDS_STRINGSW_51,buf,MAX_PATH);
		MessageBox(NULL,buf,L"Err.",MB_OK|MB_ICONWARNING|MB_SYSTEMMODAL);
    }
    else
		plgns[panel[fCopyOper::srcPanel].GetArch()->GetPlgNum()].Unpack$28(
							panel[fCopyOper::srcPanel].GetHWND(),
							panel[fCopyOper::srcPanel].GetArch()->GetPlgObj(),
							dst,
							dat.stack[dat.iCrntFileCopy].FullPathAndName,
							&dat.bCancel,
							(archive::UnpackProgressRoutine_t)UnpackCpyProgressRoutine,
							&bools);
	fCopyOper::copySrcSz += dat.stack[dat.iCrntFileCopy].size;
	fCopyOper::avDstSz -= dat.stack[dat.iCrntFileCopy].size;
	PostMessage(GetDlgItem(dat.hDlg,IDC_PROGRESS_COPY_SINGLE),PBM_SETPOS,100,0);
	PostMessage(GetDlgItem(dat.hDlg,IDC_PROGRESS_COPY_TOTAL ),PBM_SETPOS,
		(int)(fCopyOper::srcSz?(1000.0f*fCopyOper::copySrcSz/fCopyOper::srcSz):100.0f),0);
    if(dat.bCancel) goto End;
	dat.stopTick[0] = 0;
	dat.beginTick = GetTickCount(); 
 }
 dst[dstPathLn]=0;
	
Loop:
	MSG msg;//Only thread message:
	if(PeekMessage(&msg,(HWND)-1,MYWM_CANCEL-1,MYWM_CANCEL+10,PM_REMOVE))
	{	//static int i=0;
		//char ss[32];sprintf(ss,L"\n %d ",i++);
		//OutputDebugString(ss);
		//OutputDebugString(GetWinNotifyText(msg.message));		
		switch(msg.message)
		{	case MYWM_CANCEL:
				dat.bCancel = TRUE;
				goto End;
			case MYWM_STOP:
				wchar_t s[MAX_PATH];
				if(dat.bStop)
				{	LoadString(hInst,IDS_STRINGSW_50,s,MAX_PATH);
					SetDlgItemText(dat.hDlg,IDC_BUTTON_STOP,s);
					dat.bStop = FALSE;
				}
				else
				{	LoadString(hInst,IDS_STRINGSW_3,s,MAX_PATH);
					SetDlgItemText(dat.hDlg,IDC_BUTTON_STOP,s);
					dat.bStop = TRUE;
					Sleep(250);
					goto Loop;
				}
				break;
			/*case MYWM_GOTOBCKGRND:
				EndDialog(dat.hDlg,0);//DestroyWindow
				dat.hDlg = CreateDialog(hInst,
								MAKEINTRESOURCE(IDD_DIALOG_COPY_QUEUE),
								NULL,CopyBckgrndDlgProc);
				ShowWindow(dat.hDlg,SW_SHOW);
				dat.bSwtchToBckgrnd = TRUE;
				return;*/
 	}	}
	else if(dat.bStop)
	{	Sleep(250);
		goto Loop;
}	}
End:
 if(!dat.bSwtchToBckgrnd)
	EndDialog(dat.hDlg,0);//DestroyWindow
 if(dat.stack) free(dat.stack);
 ExitThread(0);
}

VOID RMcpyFrFileExThrdFnc(LPVOID lpar)//arxivdan direct folderga copy qilish;
{
//Unpack progressni ishlatsa magar:	
//panel[fRenMove::srcPanel].GetArch()->SetDlg((HWND)lpar);
cpyTrdDat dat; dat.hDlg = (HWND)lpar; prgrsDlg = &dat.hDlg;
  	dat.stack = 0;
  	dat.bStop = FALSE;
	dat.bCancel = FALSE;
	dat.bSwtchToBckgrnd = FALSE;
	dat.thrId = GetCurrentThreadId();
	dat.beginTick = dat.beginTickTot = GetTickCount();
	dat.stopTick[0] = dat.stopTickTot[0] = 0;
	enCheckCopyFilesToExisting = showEach;

 wchar_t dst[MAX_PATH];
 size_t dstPathLn;

 int totFiles = GetRMCpySelectedFilesCnt();
 if(!totFiles)goto End;
 dat.stack = (CpyStack*)malloc(totFiles*sizeof(CpyStack));
 GetRMCpySelectedFiles(dat.stack);
 //CutSelectedNames(dat.stack,panel[fRenMove::srcPanel].GetPath(),totFiles);

 dstPathLn=MyStringCpy(dst,MAX_PATH-1,fRenMove::destPath);
 if(fRenMove::allToRenFolder==fRenMove::srcType)
 {	if('\\'!=dst[dstPathLn-1])
	{	if('*'!=dst[dstPathLn-1])
		{	dst[dstPathLn++]='\\';//MyStringCat(dst,MAX_PATH-1,L"\\");//Yangi yo'l kiritsa;
 			dst[dstPathLn]=0;
		}
		else dst[--dstPathLn]=0;
	}
	int m=MessageBox(dat.hDlg,L"Create this directory?",dst,MB_YESNOCANCEL|MB_ICONWARNING|MB_SYSTEMMODAL);
	if(IDNO==m)
	{	fRenMove::srcType=fRenMove::unchange;
		wchar_t *p=wcsrchr(dst,'\\');
		if(p) *(p+1)=0;
	}
	else if(IDCANCEL==m)
		goto End;	
  	if(!MyCreateDirectory(dst,NULL))//yangi yo'lini avval yaratib olsun;
		goto End;
 }

 __int32 bools=0;
 for(dat.iCrntFileCopy=0; dat.iCrntFileCopy<totFiles; dat.iCrntFileCopy++)
 {
 if(fRenMove::unchange==fRenMove::srcType || fRenMove::allToRenFolder==fRenMove::srcType)
	MyStringCpy(&dst[dstPathLn],(int)(MAX_PATH-dstPathLn),dat.stack[dat.iCrntFileCopy].Name);//MyStringCat(dst,MAX_PATH-1,dat.stack[dat.iCrntFileCopy].Name);
 else
 {	if(fRenMove::allToRenFolder!=fRenMove::srcType)
	{	if(fRenMove::rename1Folder==fRenMove::srcType)
		{	if(dat.iCrntFileCopy>0)
			{	wchar_t *p=NULL;
				if(folder==dat.stack[0].attribute)//o'zgartirsa:
					p = wcschr(dat.stack[dat.iCrntFileCopy].Name,'\\');
				MyStringCpy(&dst[dstPathLn],(int)(MAX_PATH-dstPathLn),p?p:dat.stack[dat.iCrntFileCopy].Name);//MyStringCat(dst,MAX_PATH-1,p?p:dat.stack[dat.iCrntFileCopy].Name);
 }	}	}	}

 plgns[panel[fRenMove::srcPanel].GetArch()->GetPlgNum()].Unpack$28(
					panel[fRenMove::srcPanel].GetHWND(),
					panel[fRenMove::srcPanel].GetArch()->GetPlgObj(),
					dst,
					dat.stack[dat.iCrntFileCopy].FullPathAndName,
					&dat.bCancel,
					(archive::UnpackProgressRoutine_t)UnpackCpyProgressRoutine,//UnpackRMCpyProgressRoutine
					&bools);
fRenMove::copySrcSz += dat.stack[dat.iCrntFileCopy].size;
fRenMove::avDstSz -= dat.stack[dat.iCrntFileCopy].size;
PostMessage(GetDlgItem(dat.hDlg,IDC_PROGRESS_COPY_SINGLE),PBM_SETPOS,100,0);
PostMessage(GetDlgItem(dat.hDlg,IDC_PROGRESS_COPY_TOTAL ),PBM_SETPOS,
 (int)(fRenMove::srcSz?(1000.0f*fRenMove::copySrcSz/fRenMove::srcSz):100.0f),0);
 if(dat.bCancel) goto End;
dat.stopTick[0] = 0;
dat.beginTick = GetTickCount(); 
 
dst[dstPathLn]=0;
	
Loop:
	MSG msg;//Only thread message:
	if(PeekMessage(&msg,(HWND)-1,MYWM_CANCEL-1,MYWM_CANCEL+10,PM_REMOVE))
	{	//static int i=0;
		//char ss[32];sprintf(ss,"\n %d ",i++);
		//OutputDebugString(ss);
		//OutputDebugString(GetWinNotifyText(msg.message));		
		switch(msg.message)
		{	case MYWM_CANCEL:
				dat.bCancel = TRUE;
				goto End;
			case MYWM_STOP:
				wchar_t s[MAX_PATH];
				if(dat.bStop)
				{	LoadString(hInst,IDS_STRINGSW_50,s,MAX_PATH);
					SetDlgItemText(dat.hDlg,IDC_BUTTON_STOP,s);
					dat.bStop = FALSE;
				}
				else
				{	LoadString(hInst,IDS_STRINGSW_3,s,MAX_PATH);
					SetDlgItemText(dat.hDlg,IDC_BUTTON_STOP,s);
					dat.bStop = TRUE;
					Sleep(250);
					goto Loop;
				}
				break;
			/*case MYWM_GOTOBCKGRND:
				EndDialog(dat.hDlg,0);//DestroyWindow
				dat.hDlg = CreateDialog(hInst,
								MAKEINTRESOURCE(IDD_DIALOG_COPY_QUEUE),
								NULL,CopyBckgrndDlgProc);
				ShowWindow(dat.hDlg,SW_SHOW);
				dat.bSwtchToBckgrnd = TRUE;
				return;*/
 	}	}
	else if(dat.bStop)
	{	Sleep(250);
		goto Loop;
}	}
End:
 if(!dat.bSwtchToBckgrnd)
	EndDialog(dat.hDlg,0);//DestroyWindow
 if(dat.stack) free(dat.stack);
 ExitThread(0);
}

//arxivdan direktoriga copy qilish:
INT_PTR CALLBACK CopyQueueDlgProc(HWND hDlg,UINT message,WPARAM wParam,LPARAM lParam)
{
static HFONT hf=0;static int hfRef=0;//obshiy hf, dinamik uchun emas:
static HBRUSH br=0;
static HBRUSH brHtBk=0;
	UNREFERENCED_PARAMETER(lParam);
	switch(message)
	{
	case WM_INITDIALOG:
		//OutputDebugString("\nCopyQueueDlgProc WM_INITDIALOG 0");

		//Adjust to center:
		RECT rc; GetWindowRect(hDlg, &rc);
		int width,left,height,top;

		width = rc.right - rc.left;
		left = conf::wndLeft + (conf::wndWidth - width)/2;

		height = rc.bottom - rc.top;
		top = conf::wndTop + (conf::wndHeight - height)/2;
		MoveWindow(hDlg, left, top+20, width, height, TRUE);

		//Load language strings:
		wchar_t s[MAX_PATH];
		LoadString(hInst,IDS_STRINGSW_46,s,MAX_PATH);
		SetWindowText(hDlg,s);
		LoadString(hInst,IDS_STRINGSW_47,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_STATIC,s);
		LoadString(hInst,IDS_STRINGSW_48,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_STATIC5,s);
		LoadString(hInst,IDS_STRINGSW_49,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_BUTTON_TO_BACKGROUND_COPY_QUEUE,s);
		LoadString(hInst,IDS_STRINGSW_50,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_BUTTON_STOP,s);
		LoadString(hInst,IDS_STRINGSW_13,s,MAX_PATH);
		SetDlgItemText(hDlg,IDCANCEL,s);
		//PostMessage(GetDlgItem(hDlg,IDC_PROGRESS_COPY_SINGLE),PBM_SETRANGE,0,MAKELPARAM(0,100));defau
		//PostMessage(GetDlgItem(hDlg,IDC_PROGRESS_COPY_TOTAL ),PBM_SETRANGE,0,MAKELPARAM(0,100));defau
		PostMessage(GetDlgItem(hDlg,IDC_PROGRESS_COPY_SINGLE),PBM_SETSTEP,1,0);
		PostMessage(GetDlgItem(hDlg,IDC_PROGRESS_COPY_TOTAL ),PBM_SETSTEP,1,0);
		SendMessage(hDlg,WM_USER+1,0,0);
		static DWORD cpyThrdId;
		switch(lParam)
		{	case 0://from copy queue:
				fCopyOper::copySrcSz = 0;
				CreateThread(NULL,1024,(LPTHREAD_START_ROUTINE)cpyFrFileExThrdFnc,hDlg,0,&cpyThrdId);
				break;
			case 1://from RMcopy queue:
				fRenMove::copySrcSz = 0;
				CreateThread(NULL,1024,(LPTHREAD_START_ROUTINE)RMcpyFrFileExThrdFnc,hDlg,0,&cpyThrdId);
				break;
			//case 2://to copy queue: ToArjShowDlg bajaradur;
		}
		return TRUE;
	case WM_CTLCOLORSTATIC:
	case WM_CTLCOLORDLG:HDC dc;dc = (HDC)wParam;
		SetTextColor(dc,conf::Dlg.dlgRGBs[1][1]);
		SetBkColor(dc,conf::Dlg.dlgRGBs[1][2]);
		return (INT_PTR)br;
	case WM_CTLCOLOREDIT:dc = (HDC)wParam;
		SetTextColor(dc,conf::Dlg.dlgRGBs[1][1]);
		SetBkColor(dc,conf::Dlg.dlgRGBs[1][2]);
		return (INT_PTR)br;
	case WM_CTLCOLORBTN:dc=(HDC)wParam;
		SetTextColor(dc,conf::Dlg.dlgRGBs[1][4]);
		SetBkColor(dc,conf::Dlg.dlgRGBs[1][5]);
		return (INT_PTR)brHtBk;
	case WM_DRAWITEM://WM_CTLCOLORBTN dagi knopkalar:
		LPDRAWITEMSTRUCT lpdis;lpdis = (LPDRAWITEMSTRUCT)lParam;
		GetWindowText(lpdis->hwndItem,s,64);
		UINT uStyle;uStyle = DFCS_BUTTONPUSH;
		rc = lpdis->rcItem;
		if(lpdis->itemState & ODS_SELECTED)
		{	uStyle |= DFCS_PUSHED;
			rc.left+=2;rc.top+=2;
		}
		DrawFrameControl(lpdis->hDC, &lpdis->rcItem, DFC_BUTTON, uStyle);
		if(lpdis->itemState & ODS_SELECTED)
			{rc.left+=1;rc.top+=1;rc.bottom-=2;rc.right-=3;}
		else
			{rc.left+=1;rc.top+=2;rc.bottom-=3;rc.right-=3;}
		FillRect(lpdis->hDC,&rc,brHtBk);//DrawText(lpdis->hDC,"                                                  ",50,&rc,DT_SINGLELINE|DT_VCENTER|DT_INTERNAL|DT_LEFT);
		if(lpdis->itemState & ODS_SELECTED)
			{rc.left-=1;rc.top-=1;rc.bottom+=3;rc.right+=3;}
		else
			{rc.left-=1;rc.top-=2;rc.bottom+=2;rc.right+=3;}
		DrawText(lpdis->hDC,s,MyStringLength(s,64),&rc,DT_SINGLELINE|DT_VCENTER|DT_CENTER);
		return TRUE;
	case WM_USER+1://hf obshiy uchun, dinamik o'zgartirish uchun emas:
		if(0==hfRef)
		{	hf = CreateFontIndirect(&conf::Dlg.dlgFnts[1]);
			br = CreateSolidBrush(conf::Dlg.dlgRGBs[1][0]);
			brHtBk = CreateSolidBrush(conf::Dlg.dlgRGBs[1][5]);
		}
		SendMessage(GetDlgItem(hDlg,IDC_STATIC),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_STATIC5),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_BUTTON_TO_BACKGROUND_COPY_QUEUE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_BUTTON_STOP),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDCANCEL),WM_SETFONT,(WPARAM)hf,TRUE);
		++hfRef;
		return 0;//GWLP_USERDATA
	case WM_DESTROY:
		if(--hfRef<1)
		{	DeleteObject(hf);
			DeleteObject(br);
			DeleteObject(brHtBk);
		}
		return 0;
	case WM_USER+2://Dinamik o'zgartirish uchun:
		DeleteObject(hf);hfRef=1;
		hf = CreateFontIndirect(&conf::Dlg.dlgFnts[1]);
		SendMessage(GetDlgItem(hDlg,IDC_STATIC),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_STATIC5),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_BUTTON_TO_BACKGROUND_COPY_QUEUE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_BUTTON_STOP),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDCANCEL),WM_SETFONT,(WPARAM)hf,TRUE);
		return 0;//GWLP_USERDATA
	case WM_USER+3://Dinamik o'zgartirish uchun, colorni:
		DeleteObject(br);DeleteObject(brHtBk);hfRef=1;
		br = CreateSolidBrush(conf::Dlg.dlgRGBs[1][0]);
		brHtBk = CreateSolidBrush(conf::Dlg.dlgRGBs[1][5]);
		RedrawWindow(hDlg,NULL,NULL,RDW_INVALIDATE|RDW_ALLCHILDREN);
		return 0;//GWLP_USERDATA
	case WM_COMMAND:
		switch(LOWORD(wParam))
		{	case IDC_BUTTON_TO_BACKGROUND_COPY_QUEUE:
				if(!GetWindowLong(hDlg,GWLP_USERDATA))return TRUE;
				PostThreadMessage(cpyThrdId,MYWM_GOTOBCKGRND,0,0);
				return (INT_PTR)TRUE;
			case IDC_BUTTON_STOP:
				if(!GetWindowLong(hDlg,GWLP_USERDATA))return TRUE;
				PostThreadMessage(cpyThrdId,MYWM_STOP,0,0);
				return (INT_PTR)TRUE;
			case IDCANCEL:
				if(!GetWindowLong(hDlg,GWLP_USERDATA))return TRUE;
				PostThreadMessage(cpyThrdId,MYWM_CANCEL,0,0);
				EndDialog(hDlg,0);
				return (INT_PTR)TRUE;
		}
		break;
	}
	return (INT_PTR)FALSE;
}

}//end of namespace;