#define _CRT_SECURE_NO_WARNINGS

#include "Plugins_C.h"
#include "strsafe.h"
#include "zip.h"
#include "unzip.h"
#include "iowin32.h"
#include "resource.h"
#include "..\..\..\Operations\MyShell\MyShellC.h"

extern wchar_t **strngs;
extern HMODULE plgnDllInst;


extern void msg(HWND,DWORD,LPTSTR,LPTSTR);
extern void msgWA(DWORD,LPWSTR,LPTSTR);
extern void msgWW(DWORD,LPWSTR,LPWSTR);
extern FILETIME *ZipTimeToFileTime(tm_unz*);
extern ZPOS64_T ZEXPORT unzGetFirstFileOffset(unzFile);

typedef void (*UnpackProgressRoutine_t)(unsigned __int64,unsigned __int64,wchar_t*);

LPVOID OpenForUnpacking$8(wchar_t *name,LPVOID host)//host - CArc;
{
int nameLn;
wchar_t *p;

	PluginObj *plg=malloc(sizeof(PluginObj));
	if(!plg)
	{	msgWA(0,strngs[65]/*"Err.opening zip file."*/,(LPTSTR)name);//"error %d with zipfile in unzGetGlobalInfo \n",err);
		return NULL;
	}
	//plg->bAnsi=AreFileApisANSI();
	plg->host = host;
	nameLn=MyStringCpy(plg->unzpFileName,MAX_PATH-1,name);
	p=wcsrchr(name,'.');
	plg->bSFX = FALSE;
	if(p)//Bu hozircha predvaritelno;
	{	if(*(p+1)=='e' ||*(p+1)=='E')
		if(*(p+2)=='x' ||*(p+2)=='X')
		if(*(p+3)=='e' ||*(p+3)=='E')
			plg->bSFX = TRUE;
	}
	/*plg->bOvwrtLtst 	= 0;
	plg->bOvwrtOldst	= 0;
	plg->bOvwrtBigst	= 0;
	plg->bRename	   	= 0;
	plg->bSkip	   		= 0;
	plg->bOvwrt     	= 0;
	plg->bOvwrtLtlst	= 0;
	plg->bOvwrtLtstAll	= 0;
	plg->bOvwrtOldstAll	= 0;
	plg->bOvwrtBigstAll	= 0;
	plg->bRenameAll		= 0;
	plg->bSkipAll		= 0;
	plg->bOvwrtAll		= 0;
	plg->bOvwrtLtlstAll	= 0;*/
	plg->bools=0;
	plg->cryptMethod=-1;
	plg->packType=unpacking;//Close uchun;
	fill_win32_filefunc64W(&plg->ffuncUnzip);
    plg->uf = unzOpen2_64(name,&plg->ffuncUnzip);
	plg->fstFilePos = unzGetFirstFileOffset(plg->uf);
	plg->password[0]=0;
	if(plg->bSFX)
	if(0==plg->fstFilePos)
		plg->bSFX = FALSE;
	if(UNZ_OK!=unzGetGlobalInfo64(plg->uf,&plg->giunz))
	{	//msg(0,strngs[66]/*"Err.opening zip file."*/,name);//"error %d with zipfile in unzGetGlobalInfo \n",err);
		//free(plg);
		//return NULL;  bo'sh zip bo'lishi ham mumkin;
	}
	return plg;
}

/*BOOL EnumDirectory$8(PluginObj *plg, char *DirName)
{
int i,err;
wchar_t s[MAX_PATH];
char dirName[MAX_PATH];


	err = unzFastForEnumGoToFirstFile(plg->uf);
	if(UNZ_OK!=err)
	{	//msg(0,strngs[67],"");//"error %d with zipfile in unzGetGlobalInfo \n",err);
		return FALSE; //bo'sh zi ham bo'lishi mumkin;
	}

	if(plg->bAnsi)
	{	MultiByteToWideChar(CP_ACP,MB_PRECOMPOSED,DirName,MAX_PATH-1,s,MAX_PATH);
		WideCharToMultiByte(CP_OEMCP,0,s,-1,dirName,MAX_PATH-1,NULL,NULL);
	} else MyStrringCpy(dirName,MAX_PATH,DirName);

	for(i=0; i<plg->giunz.number_entry; i++)
    {	char fileName[MAX_PATH];unz_file_info64 unzf_info;
		char *pBgn=&fileName[0];
		err = unzGetCurrentFileInfo64(plg->uf,
									  &unzf_info,
									  fileName,
									  sizeof(fileName)-1,
                                      NULL,
									  0,
									  NULL,
									  0);
		if(err==UNZ_OK)
		{	char *pm,*pnm;
			for(pm=&fileName[0],pnm=dirName; (*pm) || (*pnm); pm++,pnm++)
			{	if('/'==(*pm) && '\\'==(*pnm))
				{	(*pm) = '\\';
					continue;
				}
				if('\\'==(*pm) && '/'==(*pnm))
					continue;
				if((*pm)!=(*pnm))
					break;
			}
			if((*pm)==(*pnm))//ikkalasi teng:
			{	WIN32_FIND_DATA ff;FILETIME *ft;//wchar_t s[MAX_PATH];
				if(('\\'==(*(pm-1)) || '/'==(*(pm-1))) && ('\\'==(*(pnm-1)) || '/'==(*(pnm-1))))
					goto Next;//Shu papka ekan;				
Add:			if(err!=UNZ_OK)
					goto Next;
				ff.nFileSizeHigh=(unzf_info.uncompressed_size & 0xffffffff00000000)>>32;
				ff.nFileSizeLow = unzf_info.uncompressed_size & 0x00000000ffffffff;
				ft=ZipTimeToFileTime(&unzf_info.tmu_date);
				ff.ftCreationTime = *ft;
				if('\\'==(*(pm-1)) || '/'==(*(pm-1)))//Oxiri '/' yo '\' b-n tugagan;
				{	if((*pm)!=0)//Yana davom etadimi, bu papkaning ichi, kerakmas;
						goto Next;
					ff.dwFileAttributes=FILE_ATTRIBUTE_DIRECTORY;
					*(pm-1)=0;
				}
				else ff.dwFileAttributes=FILE_ATTRIBUTE_NORMAL;
				if(plg->bAnsi)
				{	MultiByteToWideChar(CP_OEMCP,MB_PRECOMPOSED,fileName,MAX_PATH-1,s,MAX_PATH);
					WideCharToMultiByte(CP_ACP,0,s,-1,fileName,MAX_PATH-1,NULL,NULL);
				}
				addItemToPanelList(plg->host,pBgn,&ff);//fileName
			}
			else
			{	int iSlash=0;
				int endIsSlash = ('\\'==(*pnm) || '/'==(*pnm))?0:1;
				if(*pm!=0 && *pnm!=0)
					goto Next;//Uje 1-1iga to'g'ri kelmaydi;
				if(*pm==0)
					goto Next;
				pBgn = pm;
				while(*pm)
				{	if('/'==(*pm))
					{	if(*(pm+1)!=0)//Yana davom etadimi, bu papkaning ichi, kerakmas;
							goto Next;
						(*pm) = '\\';
						if(++iSlash>endIsSlash)
							goto Next;
					}
					else if('\\'==(*pm))
					{	if(*(pm+1)!=0)//Yana davom etadimi, bu papkaning ichi, kerakmas;
							goto Next;
						if(++iSlash>endIsSlash)
							goto Next;
					}
					++pm;
				}
				goto Add;
		}	}
Next:
		if(i<plg->giunz.number_entry-1)
		{	err = unzFastForEnumGoToNextFile(plg->uf);
			if(err!=UNZ_OK)
			{	msg(0,strngs[68],"");//"error %d with zipfile in unzGoToNextFile"
				return FALSE;
	}	}	}
	return TRUE;
}*/

BOOL EnumDirectory$8(PluginObj *plg, wchar_t *DirNameW)
{
int i,err,nNamePos;
wchar_t s[MAX_PATH];
char dirName[MAX_PATH];
//SYSTEMTIME st[8];long stw[4]={0,0,0,0};

	//GetSystemTime(&st[0]);
	nNamePos = WideCharToMultiByte(CP_OEMCP,0,DirNameW,-1,dirName,MAX_PATH,NULL,NULL);
	if(nNamePos)--nNamePos;

	err = unzFastForEnumGoToFirstFile(plg->uf);
	if(UNZ_OK!=err)
		return FALSE; //bo'sh zi ham bo'lishi mumkin;

	//GetSystemTime(&st[1]);
	//stw[0] += st[1].wSecond*60 + st[1].wMilliseconds -
	//		  st[0].wSecond*60 - st[0].wMilliseconds ;


	for(i=0; i<plg->giunz.number_entry; i++)
    {	char fileName[MAX_PATH];unz_file_info64 unzf_info;

		//GetSystemTime(&st[2]);
		err = unzFastForEnumGetCurrentFileInfo64(plg->uf,
									  &unzf_info,
									  fileName,
									  sizeof(fileName)-1,NULL,0,NULL,0);//err = unzGetCurrentFileInfo64(plg->uf,&unzf_info,fileName,sizeof(fileName)-1,NULL,0,NULL,0);
		//GetSystemTime(&st[3]);
		//stw[1] += st[3].wSecond*60 + st[3].wMilliseconds -
		//		  st[2].wSecond*60 - st[2].wMilliseconds ;

		if(err==UNZ_OK)
		{	char *pm,*pn;//BOOL bUnicodeCnvrt=FALSE;
			WIN32_FIND_DATA ff;FILETIME *ft;
			ff.dwFileAttributes=FILE_ATTRIBUTE_NORMAL;

			for(pm=&fileName[0]; (*pm);)
			{	if('/'==(*pm)) (*pm) = '\\';
				//if((*pm)>255)bUnicodeCnvrt=TRUE;//>127 uchun;
				++pm;
			}
			if(*(pm-1)=='\\')
			{	ff.dwFileAttributes=FILE_ATTRIBUTE_DIRECTORY;
				*(pm-1)=0;
			}
			pn=strstr(fileName,dirName);
			if(!pn)goto Next;
			pm=strchr(&fileName[nNamePos],'\\');
			if(pm)
			{	if(*(pm+1)!=0)
					goto Next;//Ichma-ich papka ichi;
			}
			ff.nFileSizeHigh=(unzf_info.uncompressed_size & 0xffffffff00000000)>>32;
			ff.nFileSizeLow = unzf_info.uncompressed_size & 0x00000000ffffffff;
			ft=ZipTimeToFileTime(&unzf_info.tmu_date);
			ff.ftCreationTime = *ft;

			//if(bUnicodeCnvrt && AreFileApisANSI())
			{	MultiByteToWideChar(CP_OEMCP,MB_PRECOMPOSED,&fileName[nNamePos],MAX_PATH-1,s,MAX_PATH);
			//	WideCharToMultiByte(CP_ACP,0,s,-1,&fileName[nNamePos],MAX_PATH-1,NULL,NULL);
			}

			//GetSystemTime(&st[4]);
			addItemToPanelList(plg->host,s,/*&fileName[nNamePos]*/&ff);
			//GetSystemTime(&st[5]);
			//stw[2] += st[5].wSecond*60 + st[5].wMilliseconds -
			//		  st[4].wSecond*60 - st[4].wMilliseconds ;
		}
Next:
		if(i<plg->giunz.number_entry-1)
		{	//GetSystemTime(&st[6]);
			err = unzFastForEnumGoToNextFile(plg->uf);//unzGoToNextFile(plg->uf);
			//GetSystemTime(&st[7]);
			//stw[3] += st[7].wSecond*60 + st[7].wMilliseconds -
			//		  st[6].wSecond*60 - st[6].wMilliseconds ;
			if(err!=UNZ_OK)
			{	msgWA(0,strngs[68]/*"error %d with zipfile in unzGoToNextFile"*/,(LPTSTR)"");
				return FALSE;
	}	}	}
	return TRUE;
}

BOOL FullEnum$4(PluginObj *plg)
{
int i,err;
wchar_t s[MAX_PATH];
char dirName[MAX_PATH]="";
//SYSTEMTIME st[8];long stw[4]={0,0,0,0};

	//GetSystemTime(&st[0]);
	err = unzFastForEnumGoToFirstFile(plg->uf);
	if(UNZ_OK!=err)
		return FALSE; //bo'sh zi ham bo'lishi mumkin;

	//GetSystemTime(&st[1]);
	//stw[0] += st[1].wSecond*60 + st[1].wMilliseconds -
	//		  st[0].wSecond*60 - st[0].wMilliseconds ;


	for(i=0; i<plg->giunz.number_entry; i++)
    {	char fileName[MAX_PATH];unz_file_info64 unzf_info;
		err = unzFastForEnumGetCurrentFileInfo64(plg->uf,
									  &unzf_info,
									  fileName,
									  sizeof(fileName)-1,NULL,0,NULL,0);//err = unzGetCurrentFileInfo64(plg->uf,&unzf_info,fileName,sizeof(fileName)-1,NULL,0,NULL,0);
		if(err==UNZ_OK)
		{	char *pm;
			WIN32_FIND_DATA ff;FILETIME *ft;
			ff.dwFileAttributes=FILE_ATTRIBUTE_NORMAL;

			for(pm=&fileName[0]; (*pm);)
			{	if('/'==(*pm)) (*pm) = '\\';
				//if((*pm)>255)bUnicodeCnvrt=TRUE;//>127 uchun;
				++pm;
			}
			if(*(pm-1)=='\\')
			{	ff.dwFileAttributes=FILE_ATTRIBUTE_DIRECTORY;
				*(pm-1)=0;
			}
			ff.nFileSizeHigh=(unzf_info.uncompressed_size & 0xffffffff00000000)>>32;
			ff.nFileSizeLow = unzf_info.uncompressed_size & 0x00000000ffffffff;
			ft=ZipTimeToFileTime(&unzf_info.tmu_date);
			ff.ftCreationTime = *ft;

			//if(bUnicodeCnvrt && AreFileApisANSI())
			{	MultiByteToWideChar(CP_OEMCP,MB_PRECOMPOSED,fileName,MAX_PATH-1,s,MAX_PATH);
			//	WideCharToMultiByte(CP_ACP,0,s,-1,&fileName[nNamePos],MAX_PATH-1,NULL,NULL);
			}

			//GetSystemTime(&st[4]);
			addItemToPanelList(plg->host,s,/*&fileName[nNamePos]*/&ff);
			//GetSystemTime(&st[5]);
			//stw[2] += st[5].wSecond*60 + st[5].wMilliseconds -
			//		  st[4].wSecond*60 - st[4].wMilliseconds ;
		}
		if(i<plg->giunz.number_entry-1)
		{	//GetSystemTime(&st[6]);
			err = unzFastForEnumGoToNextFile(plg->uf);//unzGoToNextFile(plg->uf);
			//GetSystemTime(&st[7]);
			//stw[3] += st[7].wSecond*60 + st[7].wMilliseconds -
			//		  st[6].wSecond*60 - st[6].wMilliseconds ;
			if(err!=UNZ_OK)
			{	msgWA(0,strngs[68]/*"error %d with zipfile in unzGoToNextFile"*/,(LPTSTR)"");
				return FALSE;
	}	}	}
	return TRUE;
}

INT_PTR CALLBACK ExstngActnDlgProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
static HFONT hf=0;
static int hfRef=0;//obshiy hf, dinamik uchun emas:
static HBRUSH br=0;
static HBRUSH brHtBk=0;
static int endDialogCodeToWM_DESTROY;
int width,left,height,top;FILETIME ft;SYSTEMTIME st;
char s[MAX_PATH];LPVOID *pars;//UINT uStyle;
RECT r;HDC dc;//LPDRAWITEMSTRUCT lpdis;
WIN32_FIND_DATA ff;HANDLE h;
UNREFERENCED_PARAMETER(lParam);
	switch (message)
	{
	case WM_INITDIALOG:
		GetWindowRect(hDlg, &r);
		width = r.right - r.left;
		height = r.bottom - r.top;
		left=(GetSystemMetrics(SM_CXSCREEN) - width )/2;
		top =(GetSystemMetrics(SM_CYSCREEN) - height)/2;
		MoveWindow(hDlg, left, top+20, width, height, TRUE);
		SetWindowTextW(hDlg,strngs[89]);
		SetDlgItemTextW(hDlg,IDC_STATIC8,strngs[70]);//"Existing file in disk:"
		SetDlgItemTextW(hDlg,IDC_STATIC5,strngs[71]);//"File in archive:"
		SetDlgItemTextW(hDlg,IDC_STATIC1,strngs[72]);//"Size in bytes:"
		SetDlgItemTextW(hDlg,IDC_STATIC3,strngs[72]);//"Size in bytes:"
		SetDlgItemTextW(hDlg,IDC_STATIC2,strngs[73]);//"Write time:"
		SetDlgItemTextW(hDlg,IDC_STATIC4,strngs[73]);//"Write time:"
		SetDlgItemTextW(hDlg,IDC_STATIC7,strngs[74]);//"Size in bytes:"
		SetDlgItemTextW(hDlg,IDC_STATIC6,strngs[75]);//"Rename"
		SetDlgItemTextW(hDlg,IDC_CHECK_OVERWRITE_LATEST_AUTO,strngs[76]);//"Overwrite latest in future"
		SetDlgItemTextW(hDlg,IDC_CHECK_OVERWRITE_OLDEST_AUTO,strngs[77]);//"Overwrite oldest in future"
		SetDlgItemTextW(hDlg,IDC_CHECK_OVERWRITE_BIGGEST_AUTO,strngs[78]);//"Overwrite biggest in future"
		SetDlgItemTextW(hDlg,IDC_CHECK_RENAME_AUTO,strngs[79]);//"Auto rename in future"
		SetDlgItemTextW(hDlg,IDC_CHECK_SKIP_AUTO,strngs[80]);//"Skip in future"		 
		SetDlgItemTextW(hDlg,IDC_CHECK_OVERWRITE_AUTO,strngs[81]);//"Overwrite in future"		 
		SetDlgItemTextW(hDlg,IDC_CHECK_OVERWRITE_BIGGEST_AUTO2,strngs[82]);//"Overwrite littlest in future"
		SetDlgItemTextW(hDlg,IDC_BUTTON_OVERWRITE_LATEST,strngs[83]);//"Overwrite latest"
		SetDlgItemTextW(hDlg,IDC_BUTTON_OVERWRITE_OLDEST,strngs[84]);//"Overwrite oldest"
		SetDlgItemTextW(hDlg,IDC_BUTTON_OVERWRITE_BIGGEST,strngs[85]);//"Overwrite biggest"
		SetDlgItemTextW(hDlg,IDC_BUTTON_RENAME,strngs[75]);//"Rename"
		SetDlgItemTextW(hDlg,IDC_BUTTON_SKIP,strngs[86]);//"Skip"
		SetDlgItemTextW(hDlg,IDC_BUTTON_OVERWRITE,strngs[87]);//"Overwrite"
		SetDlgItemTextW(hDlg,IDC_BUTTON_OVERWRITE_LITTLEST,strngs[88]);//"Overwrite littlest"
		SetDlgItemTextW(hDlg,IDCANCEL,strngs[11]);//"Cancel"
		pars=(LPVOID*)lParam;
		SetDlgItemTextA(hDlg,IDC_EDIT_EXST_NAME,(char*)pars[0]);
		SetDlgItemTextA(hDlg,IDC_EDIT_INZIP_NAME,(char*)pars[1]);
		StringCchPrintfA(s,MAX_PATH-1,"%d",(unsigned __int64)(((WIN32_FIND_DATA*)pars[2])->nFileSizeHigh) << 32 | 
										  ((WIN32_FIND_DATA*)pars[2])->nFileSizeLow);
		SetDlgItemTextA(hDlg,IDC_EDIT_INZIP_SIZE,s);
		if(FileTimeToLocalFileTime(&((WIN32_FIND_DATA*)pars[2])->ftCreationTime,&ft) != 0)
		{	if(FileTimeToSystemTime(&ft, &st) != 0)
			{	StringCchPrintfA(s,MAX_PATH-1,"%d.%d.%d  %d:%d:%d",
								st.wDay,st.wMonth,st.wYear,
								st.wHour,st.wMinute,st.wSecond);
				SetDlgItemTextA(hDlg,IDC_EDIT_INZIP_WR_TIME,s);
		}	}

		h = MyFindFirstFileExA((LPCTSTR)pars[0],FindExInfoStandard,&ff,FindExSearchLimitToDirectories,NULL,0);
		if(INVALID_HANDLE_VALUE!=h)
		{	FindClose(h);
			if(!(FILE_ATTRIBUTE_DIRECTORY & ff.dwFileAttributes))
			{	StringCchPrintfA(s,MAX_PATH-1,"%d",(unsigned __int64)(ff.nFileSizeHigh) << 32 | ff.nFileSizeLow);
				SetDlgItemTextA(hDlg,IDC_EDIT_EXST_SIZE,s);
				if(FileTimeToLocalFileTime(&ff.ftCreationTime,&ft) != 0)
				{	if(FileTimeToSystemTime(&ft, &st) != 0)
					{	StringCchPrintfA(s,MAX_PATH-1,"%d.%d.%d  %d:%d:%d",
										st.wDay,st.wMonth,st.wYear,
										st.wHour,st.wMinute,st.wSecond);
						SetDlgItemTextA(hDlg,IDC_EDIT_EXST_WR_TIME,s);
		}	}	}	}
		SendMessage(hDlg,WM_USER+1,0,0);
		return TRUE;
	case WM_USER+1://hf obshiy uchun, dinamik o'zgartirish uchun emas:
		if(0==hfRef)
		{	LOGFONTW lf;InitLOGFONT(&lf);
			hf = CreateFontIndirect(&lf);
			br = CreateSolidBrush(RGB(0x40,0x21,0x17));//0xc9,0x81,0x93));
			brHtBk = CreateSolidBrush(RGB(0x64,0x79,0x65));
		}
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_EXST_NAME),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_EXST_SIZE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_EXST_WR_TIME),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_INZIP_NAME),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_INZIP_SIZE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_INZIP_WR_TIME),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_RENAME),WM_SETFONT,(WPARAM)hf,TRUE);

		SendMessage(GetDlgItem(hDlg,IDC_STATIC8),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_STATIC5),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_STATIC1),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_STATIC3),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_STATIC2),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_STATIC4),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_STATIC7),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_STATIC6),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_OVERWRITE_LATEST_AUTO),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_OVERWRITE_OLDEST_AUTO),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_OVERWRITE_BIGGEST_AUTO),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_RENAME_AUTO),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_SKIP_AUTO),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_OVERWRITE_AUTO),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_OVERWRITE_BIGGEST_AUTO2),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_BUTTON_OVERWRITE_LATEST),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_BUTTON_OVERWRITE_OLDEST),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_BUTTON_OVERWRITE_BIGGEST),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_BUTTON_RENAME),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_BUTTON_SKIP),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_BUTTON_OVERWRITE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_BUTTON_OVERWRITE_LITTLEST),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDCANCEL),WM_SETFONT,(WPARAM)hf,TRUE);
		++hfRef;
		return TRUE;
	case WM_CTLCOLORSTATIC:
	case WM_CTLCOLORDLG:dc = (HDC)wParam;
		SetTextColor(dc,RGB(0xea,0xe0,0xff));
		SetBkColor(dc,RGB(0x40,0x21,0x17));
		return (INT_PTR)br;
	case WM_CTLCOLOREDIT:dc = (HDC)wParam;
		SetTextColor(dc,RGB(0xea,0xe0,0xff));
		SetBkColor(dc,RGB(0x40,0x21,0x17));
		return (INT_PTR)br;
	case WM_CTLCOLORBTN:dc=(HDC)wParam;
		SetTextColor(dc,RGB(0xd0,0xe0,0xff));
		SetBkColor(dc,RGB(0x64,0x79,0x65));
		return (INT_PTR)brHtBk;
/*	case WM_DRAWITEM:
		lpdis = (LPDRAWITEMSTRUCT)lParam;
		GetWindowTextA(lpdis->hwndItem,s,64);
		uStyle = DFCS_BUTTONPUSH;
		r = lpdis->rcItem;
		if(lpdis->itemState & ODS_SELECTED)
		{	uStyle |= DFCS_PUSHED|DFCS_TRANSPARENT;
			r.left+=2;r.top+=2;
		}
		DrawFrameControl(lpdis->hDC, &lpdis->rcItem, DFC_BUTTON, uStyle);
		if(lpdis->itemState & ODS_SELECTED)
			{r.left+=1;r.top+=1;r.bottom-=2;r.right-=3;}
		else
			{r.left+=1;r.top+=2;r.bottom-=3;r.right-=3;}
		FillRect(lpdis->hDC,&r,brHtBk);//DrawText(lpdis->hDC,"                                                  ",50,&rc,DT_SINGLELINE|DT_VCENTER|DT_INTERNAL|DT_LEFT);
		if(lpdis->itemState & ODS_SELECTED)
			{r.left-=1;r.top-=1;r.bottom+=3;r.right+=3;}
		else
			{r.left-=1;r.top-=2;r.bottom+=2;r.right+=3;}
		DrawTextA(lpdis->hDC,s,MyStringLength(s,64),&r,DT_SINGLELINE|DT_VCENTER|DT_CENTER);
		return TRUE;*/
	case WM_DESTROY:
		if(--hfRef<1)
		{	DeleteObject(hf);
			DeleteObject(br);
			DeleteObject(brHtBk);
		}
		return 0;
	case WM_COMMAND://int r;
		switch(LOWORD(wParam))
		{	case IDC_BUTTON_OVERWRITE_LATEST:		
				EndDialog(hDlg,(BST_CHECKED!=SendMessage(GetDlgItem(hDlg,
												IDC_CHECK_OVERWRITE_LATEST_AUTO),BM_GETCHECK,0,0))?1:11);
				return (INT_PTR)TRUE;
			case IDC_BUTTON_OVERWRITE_OLDEST:
				EndDialog(hDlg,(BST_CHECKED!=SendMessage(GetDlgItem(hDlg,
												IDC_CHECK_OVERWRITE_OLDEST_AUTO),BM_GETCHECK,0,0))?2:12);
				return (INT_PTR)TRUE;
			case IDC_BUTTON_OVERWRITE_BIGGEST:
				EndDialog(hDlg,(BST_CHECKED!=SendMessage(GetDlgItem(hDlg,
												IDC_CHECK_OVERWRITE_BIGGEST_AUTO),BM_GETCHECK,0,0))?3:13);
				return (INT_PTR)TRUE;				
			case IDC_BUTTON_RENAME:
				EndDialog(hDlg,(BST_CHECKED!=SendMessage(GetDlgItem(hDlg,
												IDC_CHECK_RENAME_AUTO),BM_GETCHECK,0,0))?4:14);
				return (INT_PTR)TRUE;				
			case IDC_BUTTON_SKIP:
				EndDialog(hDlg,(BST_CHECKED!=SendMessage(GetDlgItem(hDlg,
												IDC_CHECK_SKIP_AUTO),BM_GETCHECK,0,0))?5:15);
				return (INT_PTR)TRUE;				
			case IDC_BUTTON_OVERWRITE:
				EndDialog(hDlg,(BST_CHECKED!=SendMessage(GetDlgItem(hDlg,
												IDC_CHECK_OVERWRITE_AUTO),BM_GETCHECK,0,0))?6:16);
				return (INT_PTR)TRUE;				
			case IDC_BUTTON_OVERWRITE_LITTLEST:
				EndDialog(hDlg,(BST_CHECKED!=SendMessage(GetDlgItem(hDlg,
												IDC_BUTTON_OVERWRITE_LITTLEST),BM_GETCHECK,0,0))?7:17);
				return (INT_PTR)TRUE;				
			case IDCANCEL:
				EndDialog(hDlg, -1);
				return (INT_PTR)TRUE;
		}
		break;
	}
	return (INT_PTR)FALSE;
}

BOOL unpckCreateDirectory(wchar_t *path)
{
wchar_t *p;
	for(p=path; *p;)
	{	if(*p=='\\')
		{	*p=0;
			if(IsDirExist(path)){*p='\\'; ++p;continue;}
			CreateDirectoryW(path,NULL);
			*p='\\';
		}
		++p;
	}
	return CreateDirectoryW(path,NULL);
}

int unpkOpenDest(HWND dlgPrnt,HANDLE *hf,wchar_t *destPathAndName,wchar_t *srcNameInArj,
				 PluginObj *plg,WIN32_FIND_DATA *ff,BOOL *bCancel)
{
//1.Check destDirName for existing:
HANDLE HF = INVALID_HANDLE_VALUE;
WIN32_FIND_DATA FF;
BOOL bDir=(ff->dwFileAttributes==FILE_ATTRIBUTE_DIRECTORY);
wchar_t *p,fullPathAndName[MAX_PATH],s[MAX_PATH];HMODULE hm;
int ln = MyStringCpy(fullPathAndName,MAX_PATH-1,destPathAndName);
	ln += MyStringCpy(&fullPathAndName[ln],MAX_PATH-ln-1,srcNameInArj);
	if(bDir)
	{	if(IsDirExist(fullPathAndName)) return 0;
		if(unpckCreateDirectory(fullPathAndName)) return 0;//goto next ga o'tib ketishi uchun;
		msgWW(0,strngs[69],fullPathAndName);//err create dir in disk;
		return -1;
	}
	//else, if file:
	HF = MyFindFirstFileEx(fullPathAndName,FindExInfoStandard,&FF,FindExSearchLimitToDirectories,NULL,0);
	if(INVALID_HANDLE_VALUE==HF) goto Cr;
	FindClose(HF);		
	if(!(FILE_ATTRIBUTE_DIRECTORY & FF.dwFileAttributes))//if(IsFileExist(fullPathAndName))
	{	int r;LPVOID par[3]={fullPathAndName,srcNameInArj,ff};
		if(plg->bOvwrtLtstAll)
		{	
OvLts:		if(1==CmpFILETIMEs(&ff->ftCreationTime,&FF.ftCreationTime))
				goto Cr;
			return 0;
		}
		else if(plg->bOvwrtOldstAll)
		{	
OvOld:		if(-1==CmpFILETIMEs(&ff->ftCreationTime,&FF.ftCreationTime))
				goto Cr;
			return 0;
		}
		else if(plg->bOvwrtBigstAll)
		{	unsigned __int64 szf,szF;
OvBg:		szf = ((unsigned __int64)ff->nFileSizeHigh << 32) | (unsigned __int64)ff->nFileSizeLow;
			szF = ((unsigned __int64)FF.nFileSizeHigh  << 32) | (unsigned __int64)FF.nFileSizeLow;
			if(szf < szF)
				goto Cr;
			return 0;//go to next rec;
		}
		else if(plg->bRenameAll)
		{	wchar_t RenName[MAX_PATH],sAdd[32],*pExt;int iMyCopyRenameFileEx;
Renm:		pExt = (wchar_t*)wcsrchr(fullPathAndName,'.');
			iMyCopyRenameFileEx=0;
			if(pExt) memcpy(RenName,fullPathAndName,((wchar_t*)pExt) - ((wchar_t*)fullPathAndName));
			else MyStringCpy(RenName,MAX_PATH-1,(wchar_t*)fullPathAndName);
			do
			{	++iMyCopyRenameFileEx;
				StringCchPrintfW(sAdd,32,L"_%d",iMyCopyRenameFileEx);
				MyStringCat(RenName,MAX_PATH-1,sAdd);
				if(pExt) MyStringCat(RenName,MAX_PATH-1,pExt);
			} while(IsFileExist(RenName));
		}
		else if(plg->bSkipAll)  return 0;
		else if(plg->bOvwrtAll) goto Cr;
		else if(plg->bOvwrtLtlstAll)
		{	unsigned __int64 szf,szF;
OvLtl:		szf = ((unsigned __int64)ff->nFileSizeHigh << 32) | (unsigned __int64)ff->nFileSizeLow;
			szF = ((unsigned __int64)FF.nFileSizeHigh  << 32) | (unsigned __int64)FF.nFileSizeLow;
			if(szf > szF)
				goto Cr;
			return 0;//go to next rec;
		}//else:
		GetModuleFileName(NULL,s,MAX_PATH);
		p=wcsrchr(s,'\\');if(p)
#ifdef _WIN64
		{	wcscpy(p+1,L"MyShell64.dll");
			hm=LoadLibrary(s);
		}else hm=LoadLibrary(L"MyShell64.dll");
#else
		{	wcscpy(p+1,L"MyShell.dll");
			hm=LoadLibrary(s);
		}else hm=LoadLibrary(L"MyShell.dll");
#endif
		if(!hm)return FALSE;
		r=(int)DialogBoxParam(hm/*plgnDllInst*/,MAKEINTRESOURCE(IDD_DIALOG_EXIST_ACTION),dlgPrnt,ExstngActnDlgProc,(LPARAM)par);
		switch(r)
		{	case -1://idcancel;
				*bCancel = TRUE;
				return -1;
			case 1://IDC_BUTTON_OVERWRITE_LATEST
				plg->bOvwrtLtst=1;
				goto OvLts;
			case 2://IDC_BUTTON_OVERWRITE_OLDEST:
				plg->bOvwrtOldst=1;
				goto OvOld;
			case 3://IDC_BUTTON_OVERWRITE_BIGGEST:
				plg->bOvwrtBigst=1;
				goto OvBg;
			case 4://IDC_BUTTON_RENAME:
				plg->bRename=1;
				goto Renm;
			case 5://IDC_BUTTON_SKIP:
				plg->bSkip=1;
				return 0;
			case 6://IDC_BUTTON_OVERWRITE:
				plg->bOvwrt=1;
				goto Cr;
			case 7://IDC_BUTTON_OVERWRITE_LITTLEST:
				plg->bOvwrtLtlst=1;
				goto OvLtl;


			case 11://IDC_BUTTON_OVERWRITE_LATEST with check box
				plg->bOvwrtLtstAll=1;
				goto OvLts;
			case 12://IDC_BUTTON_OVERWRITE_OLDEST: with check box
				plg->bOvwrtOldstAll=1;
				goto OvOld;
			case 13://IDC_BUTTON_OVERWRITE_BIGGEST: with check box
				plg->bOvwrtBigstAll=1;
				goto OvBg;
			case 14://IDC_BUTTON_RENAME: with check box
				plg->bRenameAll=1;
				goto Renm;
			case 15://IDC_BUTTON_SKIP: with check box
				plg->bSkipAll=1;
				return 0;
			case 16://IDC_BUTTON_OVERWRITE: with check box
				plg->bOvwrtAll=1;
				goto Cr;
			case 17://IDC_BUTTON_OVERWRITE_LITTLEST: with check box
				plg->bOvwrtLtlstAll=1;
				goto OvLtl;
	}
	//else
Cr:
	*hf=CreateFileW(fullPathAndName,GENERIC_WRITE,FILE_SHARE_WRITE,NULL,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,NULL);
	if(INVALID_HANDLE_VALUE==(*hf))
	{	msgWW(0,strngs[91],fullPathAndName);
		return 0;
	}}
	return 1;
}

INT_PTR CALLBACK pswrdDlg(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
static HFONT hf=0;
static int hfRef=0;//obshiy hf, dinamik uchun emas:
static HBRUSH br=0;
static HBRUSH brHtBk=0;
static int endDialogCodeToWM_DESTROY;
int width,left,height,top;//wchar_t s[MAX_PATH];
RECT r;HDC dc;//LPDRAWITEMSTRUCT lpdis;//UINT uStyle;
UNREFERENCED_PARAMETER(lParam);
	switch (message)
	{
	case WM_INITDIALOG:
		GetWindowRect(hDlg, &r);
		width = r.right - r.left;
		height = r.bottom - r.top;
		left=(GetSystemMetrics(SM_CXSCREEN) - width )/2;
		top =(GetSystemMetrics(SM_CYSCREEN) - height)/2;
		MoveWindow(hDlg, left, top+20, width, height, TRUE);
		SetWindowTextW(hDlg,strngs[90]);//"Enter password, please:"
		SetDlgItemTextW(hDlg,IDOK,strngs[10]);
		SetDlgItemTextW(hDlg,IDCANCEL,strngs[11]);
		SetWindowLongPtr(hDlg,GWLP_USERDATA,lParam);//SetWindowLong(hDlg,GWL_USERDATA,lParam);password str address;
		SendMessage(hDlg,WM_USER+1,0,0);
		return TRUE;
	case WM_USER+1://hf obshiy uchun, dinamik o'zgartirish uchun emas:
		if(0==hfRef)
		{	LOGFONTW lf;InitLOGFONT(&lf);
			hf = CreateFontIndirect(&lf);
			br = CreateSolidBrush(RGB(0x40,0x21,0x17));//0xc9,0x81,0x93));
			brHtBk = CreateSolidBrush(RGB(0x64,0x79,0x65));
		}
		SendMessage(GetDlgItem(hDlg,IDCANCEL),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDOK),WM_SETFONT,(WPARAM)hf,TRUE);
		++hfRef;
		return TRUE;
	case WM_CTLCOLORSTATIC:
	case WM_CTLCOLORDLG:dc = (HDC)wParam;
		SetTextColor(dc,RGB(0xea,0xe0,0xff));
		SetBkColor(dc,RGB(0x40,0x21,0x17));
		return (INT_PTR)br;
	case WM_CTLCOLOREDIT:dc = (HDC)wParam;
		SetTextColor(dc,RGB(0xea,0xe0,0xff));
		SetBkColor(dc,RGB(0x40,0x21,0x17));
		return (INT_PTR)br;
	case WM_CTLCOLORBTN:dc=(HDC)wParam;
		SetTextColor(dc,RGB(0xd0,0xe0,0xff));
		SetBkColor(dc,RGB(0x64,0x79,0x65));
		return (INT_PTR)brHtBk;
	/*case WM_DRAWITEM:
		lpdis = (LPDRAWITEMSTRUCT)lParam;
		GetWindowText(lpdis->hwndItem,s,64);
		uStyle = DFCS_BUTTONPUSH;
		r = lpdis->rcItem;
		if(lpdis->itemState & ODS_SELECTED)
		{	uStyle |= DFCS_PUSHED|DFCS_TRANSPARENT;
			r.left+=2;r.top+=2;
		}
		DrawFrameControl(lpdis->hDC, &lpdis->rcItem, DFC_BUTTON, uStyle);
		if(lpdis->itemState & ODS_SELECTED)
			{r.left+=1;r.top+=1;r.bottom-=2;r.right-=3;}
		else
			{r.left+=1;r.top+=2;r.bottom-=3;r.right-=3;}
		FillRect(lpdis->hDC,&r,brHtBk);//DrawText(lpdis->hDC,"                                                  ",50,&rc,DT_SINGLELINE|DT_VCENTER|DT_INTERNAL|DT_LEFT);
		if(lpdis->itemState & ODS_SELECTED)
			{r.left-=1;r.top-=1;r.bottom+=3;r.right+=3;}
		else
			{r.left-=1;r.top-=2;r.bottom+=2;r.right+=3;}
		DrawText(lpdis->hDC,s,MyStringLength(s,64),&r,DT_SINGLELINE|DT_VCENTER|DT_CENTER);
		return TRUE;*/
	case WM_DESTROY:
		if(--hfRef<1)
		{	DeleteObject(hf);
			DeleteObject(br);
			DeleteObject(brHtBk);
		}
		return 0;
	case WM_COMMAND://int r;
		switch(LOWORD(wParam))
		{	case IDOK:
				GetDlgItemTextA(hDlg,IDC_EDIT_DATA1/*IDC_EDIT_PASSWORD*/,(LPSTR)GetWindowLongPtr(hDlg,GWLP_USERDATA),MAX_PATH-1);//GetWindowLong(hDlg,GWL_USERDATA),MAX_PATH-1);
				EndDialog(hDlg, 1);
				return (INT_PTR)TRUE;
			case IDCANCEL:
				EndDialog(hDlg, 0);
				return (INT_PTR)TRUE;
		}
		break;
	}
	return (INT_PTR)FALSE;
}

BOOL Unpack$28(HWND prntDlg,PluginObj *plg,wchar_t *destDirNameW,wchar_t *arjDirAndNameW,
			   BOOL *bCancel,UnpackProgressRoutine_t lpprgs,__int32 *bOverwriteBits)
{
int i,err,nNamePos;
wchar_t dirName[MAX_PATH],*pm,*pnm,*pext=0;
char arjDirAndName[MAX_PATH];
//int dirNameLn=MyStringLength(arjDirAndNameW,MAX_PATH);
wchar_t dstName[MAX_PATH];

	WideCharToMultiByte(CP_OEMCP,0,arjDirAndNameW,-1,arjDirAndName,MAX_PATH,NULL,NULL);

	plg->bools = *bOverwriteBits;
	for(pm=destDirNameW,pnm=&dstName[0]; *pm;)
	{	*pnm = *pm;
		if((*pnm)=='\\')
			pext = pnm;
		++pm;++pnm;
	} if(pext)*(pext+1)=0;//dumini qirqib otaramiz;
	pnm=arjDirAndNameW;
	for(pm=arjDirAndNameW; (*pm);)
	{	if('/'==(*pm)){ (*pm) = '\\'; pnm = pm; }
		else if('\\'==(*pm)) pnm = pm;
		++pm;
	}
	nNamePos=(pnm>arjDirAndNameW?((int)(pnm-arjDirAndNameW)+1):0);


	err = unzFastForEnumGoToFirstFile(plg->uf);
	if(UNZ_OK!=err)
	{	//msg(0,strngs[67]/*"Err.opening zip file."*/,"");//"error %d with zipfile in unzGetGlobalInfo \n",err);
		return FALSE; //bo'sh zi ham bo'lishi mumkin;
	}

	MyStringCpy(dirName,MAX_PATH,arjDirAndNameW);

	for(i=0; i<plg->giunz.number_entry; i++)
    {	char fileNameA[MAX_PATH];wchar_t fileName[MAX_PATH];unz_file_info64 unzf_info;
		err = unzFastForEnumGetCurrentFileInfo64(plg->uf,
									  &unzf_info,
									  fileNameA,
									  sizeof(fileName)-1,
                                      NULL,
									  0,
									  NULL,
									  0);
		if(err==UNZ_OK)
		{	HANDLE hf=0;DWORD rd=0;unsigned __int64 alrwrtd=0;char buf[16384];//BOOL bUnicodeCnvrt=FALSE;//128*128
			WIN32_FIND_DATA ff;FILETIME *ft;//wchar_t s[MAX_PATH];
			ff.dwFileAttributes=FILE_ATTRIBUTE_NORMAL;
			MultiByteToWideChar(CP_OEMCP,0,fileNameA,-1,fileName,MAX_PATH);
			for(pm=&fileName[0]; (*pm);)
			{	if('/'==(*pm)) (*pm) = '\\';
				//if((*pm)>255)bUnicodeCnvrt=TRUE;//>127 uchun;
				++pm;
			}
			if(*(pm-1)=='\\')
			{	ff.dwFileAttributes=FILE_ATTRIBUTE_DIRECTORY;
				*(pm-1)=0;
			}
			pm=wcsstr(fileName,dirName);
			if(!pm)goto Next;
			ff.nFileSizeHigh=(unzf_info.uncompressed_size & 0xffffffff00000000)>>32;
			ff.nFileSizeLow = unzf_info.uncompressed_size & 0x00000000ffffffff;
			ft=ZipTimeToFileTime(&unzf_info.tmu_date);
			ff.ftCreationTime = *ft;
			//if(bUnicodeCnvrt && AreFileApisANSI())
			//{	MultiByteToWideChar(CP_OEMCP,MB_PRECOMPOSED,&fileName[nNamePos],MAX_PATH-1,s,MAX_PATH);
			//	WideCharToMultiByte(CP_ACP,0,s,-1,&fileName[nNamePos],MAX_PATH-1,NULL,NULL);
			//}			
			
			//Yoziladigan tomoni, 1-destDirName-ning o'zi mavjud.Ichidagi sub dirlar uchun mavjud bo'lmasa,
			//yaratish kerakmi-yo'qmi? Shuni so'rash kerakmi? Fayl bor bo'lsa, ustidan yozish kerakmi?
			//bCancel ga qay holda TRUE qaytariladi? Stop yoki cancel bosganda bo'lsa kerak...
			err=unpkOpenDest(prntDlg,&hf,dstName,&fileName[nNamePos],plg,&ff,bCancel);
			*bOverwriteBits = plg->bools;//Yozib qo'yamiz;
			if(0==err)goto Next;//directory ham shunga kiradi;
			else if(-1==err)return TRUE;
			//else:err>0
TryLoop:
			//O'qiladigan tomoni:
			err = unzOpenCurrentFilePassword(plg->uf,plg->password);
			if(err!=UNZ_OK) goto Skp;

			rd=0;alrwrtd=0;
			do
			{	err = unzReadCurrentFile(plg->uf,buf,16384);
				if(-3==err)//maniki:
				{	HMODULE hm;wchar_t *p,s[MAX_PATH];GetModuleFileName(NULL,s,MAX_PATH);
					p=wcsrchr(s,'\\');if(p)
#ifdef _WIN64
					{	wcscpy(p+1,L"MyShell64.dll");
						hm=LoadLibrary(s);
					}else hm=LoadLibrary(L"MyShell64.dll");
#else
					{	wcscpy(p+1,L"MyShell.dll");
						hm=LoadLibrary(s);
					}else hm=LoadLibrary(L"MyShell.dll");
#endif
					if(!hm)break;
					if(!DialogBoxParam(hm/*plgnDllInst*/,MAKEINTRESOURCE(IDD_DIALOG_PASSWORD),prntDlg,pswrdDlg,(LPARAM)plg->password))
					{	if(hf)
						{	wchar_t s[MAX_PATH];CloseHandle(hf);
							StringCchPrintf(s,MAX_PATH-1,L"%s%s",dstName,fileName);
							DeleteFile(s);
						}
						//unzCloseCurrentFile(plg->uf);
						*bCancel = TRUE;
						return TRUE;
					}
					else
					{	//unzCloseCurrentFile(plg->uf);
						goto TryLoop;
				}	}
				if(err<0) goto Skp;
				if(err>0) WriteFile(hf,buf,err,&rd,NULL);
				alrwrtd+=err;
				if(unzf_info.uncompressed_size>0 && lpprgs)
					lpprgs(alrwrtd/unzf_info.uncompressed_size,(int)(100.0f*i/plg->giunz.number_entry),dstName);
			} while(err>0 && rd>0);
Skp:
			err=UNZ_ERRNO;
			if(hf)CloseHandle(hf);
			//err=unzCloseCurrentFile(plg->uf);
		}
Next:
		if(lpprgs)lpprgs(100,(int)(100.0f*i/plg->giunz.number_entry),dstName);

		if(i<plg->giunz.number_entry-1)
		{	err = unzFastForEnumGoToNextFile(plg->uf);
			if(err!=UNZ_OK)
			{	msgWA(0,strngs[68]/*"error %d with zipfile in unzGoToNextFile"*/,(LPTSTR)"");
				return FALSE;
	}	}	}
	return TRUE;
}