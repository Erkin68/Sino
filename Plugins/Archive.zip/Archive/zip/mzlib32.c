#define _CRT_SECURE_NO_WARNINGS

#include "Plugins_C.h"
#include "strsafe.h"
#include "zip.h"
#include "unzip.h"
#include "iowin32.h"
#include "resource.h"

#define WRITEBUFFERSIZE (16384)
#define MAXFILENAME (256)
#define _CRT_SECURE_NO_WARNINGS
#define FOPEN_FUNC(filename, mode) fopen64(filename, mode)
#define FTELLO_FUNC(stream) ftello64(stream)
#define FSEEKO_FUNC(stream, offset, origin) fseeko64(stream, offset, origin)

#define cancel					0
#define showEach				1
#define overwrite				2
#define overwriteAll			3
#define skip					4
#define skipAll					5
#define rename1					6
#define renameAll				7
#define overwriteOldest			8
#define overwriteOldestAll		9
#define overwriteLatest			10
#define overwriteLatestAll		11
#define overwriteBigest			12
#define overwriteBigestAll		13
#define overwriteLittlest		14
#define overwriteLittlestAll	15

extern wchar_t **strngs;
extern HMODULE plgnDllInst;
extern int	   plgId;

checkFileInSelctn_t checkFileInSelctn;
excldFileFrSelctn_t excldFileFrSelctn;
getFileInfoFromSelection_t getFileInfoFromSelection;
prgrssRout_t prgrssRout;
showDlgOverwriteExistFile_t showDlgOverwriteExistFile;
saveOptions_t saveOptions;
readOptions_t readOptions;
addItemToPanelList_t addItemToPanelList;


uLong filetime(wchar_t*,tm_zip*,uLong*);
int getFileCrc(const wchar_t*,void*,unsigned long,unsigned long*);
int isLargeFile(const wchar_t*);
void msg0(DWORD,LPTSTR);
void msg(DWORD,LPTSTR,LPTSTR);
void msgWA(DWORD,LPWSTR,LPTSTR);
void msgWW(DWORD,LPWSTR,LPWSTR);
unsigned __int64 *ZipTimeToUInt64(tm_unz*);
unsigned __int64* ZipFileTimeToUint64(unsigned int,unsigned int,tm_unz*);
FILETIME *ZipTimeToFileTime(tm_unz*);

extern int MyUnzipGetFileCRC(unzFile);
extern int MyGetFileCrcAndSize(const wchar_t*,void*,unsigned long,unsigned long*,unsigned __int64*);
extern int ZEXPORT unzUncompressedReadCurrentFile(unzFile,voidp,unsigned);
extern int ZEXPORT zipWriteCompressedInFileInZip(zipFile,const void*,unsigned int);
extern __int64 getFileSize(const wchar_t*);
extern unsigned int zipAddSXFHeader(zipFile*);
extern unsigned int zipCopySXFHeaderMem(zipFile*,void*,ZPOS64_T);
//extern unsigned int zipCopySXFHeader(zipFile*,zlib_filefunc64_32_def,voidpf,DWORD);
extern int zstrstr_slash(char*,char*);
extern char* zstrrchr2_excl_end(char*,char,char);
extern ZPOS64_T ZEXPORT unzGetFirstFileOffsetFromMem(void*);
extern ZPOS64_T ZEXPORT unzGetFirstFileOffset(unzFile);


BOOL Add$24(PluginObj *plg,wchar_t *FullPathAndName,wchar_t *RelatedPathAndName,
			wchar_t *password,int compress_level,BOOL bExcldPath)
{
FILE * fin;
zip_fileinfo zi;
int size_read;
const char *savefilenameinzip;
char *changeSlash,*lastslash ;
char RelatedPathAndNameA[MAX_PATH];
char passwordA[MAX_PATH];
//wchar_t s[MAX_PATH];char c[MAX_PATH];
unsigned long crcFile=0;
unsigned __int64 alrdyReaded=0;
unsigned __int64 fSize;
int zip64 = 0;
int err=0;

	if(!plg->zf)return FALSE;

	WideCharToMultiByte(CP_OEMCP,0,RelatedPathAndName,-1,RelatedPathAndNameA,MAX_PATH,NULL,NULL);
	WideCharToMultiByte(CP_OEMCP,0,password,-1,passwordA,MAX_PATH,NULL,NULL);

    zi.tmz_date.tm_sec = zi.tmz_date.tm_min = zi.tmz_date.tm_hour =
    zi.tmz_date.tm_mday = zi.tmz_date.tm_mon = zi.tmz_date.tm_year = 0;
    zi.dosDate = 0;
    zi.internal_fa = 0;
    zi.external_fa = 0;
    filetime(FullPathAndName,&zi.tmz_date,&zi.dosDate);

	if ((password != NULL) && (err==ZIP_OK))
    err = MyGetFileCrcAndSize(FullPathAndName,plg->buf,plg->size_buf,&crcFile,&fSize);
	zip64 = fSize>=0xffffffff?1:0;//zip64 = isLargeFile(FullPathAndName);

    /* The path name saved, should not include a leading slash. */
    /*if it did, windows/xp and dynazip couldn't read the zip file. */
    savefilenameinzip = RelatedPathAndNameA;
    while(savefilenameinzip[0] == '\\' || savefilenameinzip[0] == '/')
		savefilenameinzip++;

	//Hamma '\' simvolini '/' ga almashtiramiz:
	for(changeSlash = (char*)savefilenameinzip; *changeSlash; changeSlash++)
	{	if('/'==*changeSlash || '\\'==*changeSlash)
		{	*changeSlash='/';
			lastslash = changeSlash;
	}	}

	/*should the zip file contain any path at all?*/
    if(bExcldPath)
	{	if(lastslash != NULL)
			savefilenameinzip = lastslash+1; // base filename follows last slash.
	}

	//if(plg->bAnsi)
	//{	MultiByteToWideChar(CP_ACP,MB_PRECOMPOSED,savefilenameinzip,MAX_PATH-1,s,MAX_PATH);
	//	WideCharToMultiByte(CP_OEMCP,0,s,-1,c,MAX_PATH-1,NULL,NULL);
	//}

	/**/
    err = zipOpenNewFileInZip3_64(plg->zf,
					 savefilenameinzip,&zi,//plg->bAnsi?c:savefilenameinzip,&zi,
                     NULL,0,NULL,0,NULL /* comment*/,
                     (compress_level != 0) ? Z_DEFLATED : 0,
                     compress_level,0,
                     /* -MAX_WBITS, DEF_MEM_LEVEL, Z_DEFAULT_STRATEGY, */
                     -MAX_WBITS, DEF_MEM_LEVEL, Z_DEFAULT_STRATEGY,
					 passwordA[0]?passwordA:NULL,
					 crcFile, zip64);

    if(err != ZIP_OK)
	{	msgWW(err,L"error opening",FullPathAndName);
		return FALSE;
	}
    else
    {	fin = FOPEN_FUNC(FullPathAndName,L"rb");
        if (fin==NULL)
        {   err=ZIP_ERRNO;
			msgWW(err,strngs[51]/*"error in opening for reading"*/,FullPathAndName);
			return FALSE;
	}	}

    if(err == ZIP_OK)
    do
    {	err = ZIP_OK;
        size_read = (int)fread(plg->buf,1,plg->size_buf,fin);
        if(size_read < plg->size_buf)if (feof(fin)==0)
        {	err = ZIP_ERRNO;
			msgWW(err,strngs[52]/*"error in reading from"*/,FullPathAndName);
			return FALSE;
        }

        if(size_read>0)
        {	err = zipWriteInFileInZip(plg->zf,plg->buf,size_read);
            if(err<0)
            {	msgWW(err,strngs[53]/*"error in writing in the zipfile"*/,FullPathAndName);
				return FALSE;
        	}
			alrdyReaded+=size_read;
			prgrssRout(plg->host,&alrdyReaded,&fSize,0,0);
	}	}
	while((err == ZIP_OK) && (size_read>0));

    if(fin)
        fclose(fin);

    if(err<0)
        err=ZIP_ERRNO;
    else
    {	err = zipCloseFileInZip(plg->zf);
        if (err!=ZIP_OK)
		{	msgWW(err,(LPTSTR)strngs[56]/*"error in closing in the zipfile"*/,FullPathAndName);
			return FALSE;
	}	}
	return TRUE;
}

BOOL CreateDir$24(PluginObj *plg,wchar_t *FullPathAndName,wchar_t *RelatedPathAndName,
				  wchar_t *password,int compress_level,BOOL bExcldPath)
{
zip_fileinfo zi;
//wchar_t s[MAX_PATH];char c[MAX_PATH];
char RelatedPathAndNameA[MAX_PATH];
char passwordA[MAX_PATH];
const char *savefilenameinzip;
char *changeSlash,*lastslash ;
int zip64 = 0;
int err=0;

	WideCharToMultiByte(CP_OEMCP,0,RelatedPathAndName,-1,RelatedPathAndNameA,MAX_PATH,NULL,NULL);
	WideCharToMultiByte(CP_OEMCP,0,password,-1,passwordA,MAX_PATH,NULL,NULL);

	if(!plg->zf)return FALSE;

	//if(plg->bAppend) rebuild ga o'tdi;
	//if(plg->unzpf)
    //if(unzLocateFile(plg->unzpf,RelatedPathAndName,0/*CASESENSITIVITY*/)!=0/*UNZ_OK*/)
	//	return TRUE;

    zi.tmz_date.tm_sec = zi.tmz_date.tm_min = zi.tmz_date.tm_hour =
    zi.tmz_date.tm_mday = zi.tmz_date.tm_mon = zi.tmz_date.tm_year = 0;
    zi.dosDate = 0;
    zi.internal_fa = 0;
    zi.external_fa = 0x30;
    filetime(FullPathAndName,&zi.tmz_date,&zi.dosDate);
/*
    err = zipOpenNewFileInZip(zf,filenameinzip,&zi,
                              NULL,0,NULL,0,NULL / * comment * /,
                              (opt_compress_level != 0) ? Z_DEFLATED : 0,
                              opt_compress_level);
*/

    /* The path name saved, should not include a leading slash. */
    /*if it did, windows/xp and dynazip couldn't read the zip file. */
    savefilenameinzip = RelatedPathAndNameA;
    while(savefilenameinzip[0] == '\\' || savefilenameinzip[0] == '/')
		savefilenameinzip++;

	//Hamma '\' simvolini '/' ga almashtiramiz:
	for(changeSlash = (char*)savefilenameinzip; *changeSlash; changeSlash++)
	{	if('\\'==*changeSlash || '/'==*changeSlash)
		{	*changeSlash='/';
			lastslash = changeSlash;
	}	}

	/*should the zip file contain any path at all?*/
    if(bExcldPath)
	{	if(lastslash != NULL)
			savefilenameinzip = lastslash+1; // base filename follows last slash.
	}
	
	//if(plg->bAnsi) o'zi shunday ham OEM
	//{	MultiByteToWideChar(CP_ACP,MB_PRECOMPOSED,savefilenameinzip,MAX_PATH-1,s,MAX_PATH);
	//	WideCharToMultiByte(CP_OEMCP,0,s,-1,c,MAX_PATH-1,NULL,NULL);
	//}

	/**/
    err = zipOpenNewFileInZip4(plg->zf,
					 savefilenameinzip,&zi,//plg->bAnsi?c:savefilenameinzip,&zi,
                     NULL,0,NULL,0,NULL /* comment*/,
                     (compress_level != 0) ? Z_DEFLATED : 0,
                     compress_level,1,
                     /* -MAX_WBITS, DEF_MEM_LEVEL, Z_DEFAULT_STRATEGY, */
                     -MAX_WBITS, DEF_MEM_LEVEL, Z_DEFAULT_STRATEGY,
					 passwordA[0]?passwordA:NULL,0,14,2);

    if(err != ZIP_OK)
	{	msgWW(err,strngs[55]/*"error in opening in zipfile"*/,FullPathAndName);
		return FALSE;
	}
    else
    {	err = zipCloseFileInZip(plg->zf);
        if (err!=ZIP_OK)
		{	msgWW(err,strngs[54]/*"error in closing in the zipfile"*/,FullPathAndName);
			return FALSE;
	}	}
	return TRUE;
}

BOOL CreateTempFileName(PluginObj *plg)
{
FILE *f=0;
int	ln=MyStringCpy(plg->tmpZpFileName,MAX_PATH-1,plg->zpFileName);
	plg->tmpZpFileName[ln-1]='#';
	f=_wfopen(plg->tmpZpFileName,L"rb");
	if(f)
	{	int n=0;
		fclose(f);
		for(;;)
		{	StringCchPrintfW(&plg->tmpZpFileName[ln-1],MAX_PATH-1,L"%d#",n);
			f=_wfopen(plg->tmpZpFileName,L"rb");
			if(!f) return TRUE;
			fclose(f);
			++n;
		}
		return FALSE;
	}
	//else:
	return TRUE;
}

const wchar_t *GetArchExtnsn()
{
	return L"zip";
}

const int GetPluginType()
{
	return 1;
}

BOOL TryToCreateFileMapping(PluginObj *plg,__int64 *zpFileSz)
{
HANDLE hMapFile;
LPCTSTR pBuf;
DWORD szH=(DWORD)(((*zpFileSz) & 0xffffffff00000000)<<32);
DWORD szL=(DWORD)( (*zpFileSz) & 0xffffffff);

	plg->hfmap = 0;
	plg->heapAndMapBuf = 0;
	hMapFile = CreateFileMappingW(
                 INVALID_HANDLE_VALUE,	// use paging file
                 NULL,					// default security 
                 PAGE_READWRITE,		// read/write access
                 szH,					// max. object size 
                 szL,					// buffer size  
				 plg->zpFileName);		// name of mapping object 
	if(hMapFile == NULL) 
		return FALSE;
	pBuf = (LPTSTR)MapViewOfFile(hMapFile, // handle to map object
                        FILE_MAP_ALL_ACCESS,// read/write permission
                        0,                   
                        0,                   
                        (SIZE_T)(*zpFileSz)); 
	if(pBuf == NULL) 
		return FALSE;
	plg->hfmap = hMapFile;
	plg->heapAndMapBuf = (void*)pBuf;
	return TRUE;
}

LPVOID Open$12(wchar_t *name,BOOL bCreateNew,LPVOID host)
{
int nameLn;
wchar_t *p;
	PluginObj *plg=malloc(sizeof(PluginObj));
	plg->host = host;
	nameLn=MyStringCpy(plg->zpFileName,MAX_PATH-1,name);
	p=wcsrchr(name,'.');
	plg->bSFX = FALSE;
	if(p)
	{	if(*(p+1)=='e' ||*(p+1)=='E')
		if(*(p+2)=='x' ||*(p+2)=='X')
		if(*(p+3)=='e' ||*(p+3)=='E')
			plg->bSFX = TRUE;
	}
	/*plg->bOvwrtLtst 	= 0;
	plg->bOvwrtOldst	= 0;
	plg->bOvwrtBigst	= 0;
	plg->bRename	   	= 0;
	plg->bSkip	   		= 0;
	plg->bOvwrt     	= 0;
	plg->bOvwrtLtlst	= 0;
	plg->bOvwrtLtstAll	= 0;
	plg->bOvwrtOldstAll	= 0;
	plg->bOvwrtBigstAll	= 0;
	plg->bRenameAll		= 0;
	plg->bSkipAll		= 0;
	plg->bOvwrtAll		= 0;
	plg->bOvwrtLtlstAll	= 0;*/
	plg->bools=0;
	plg->bAppend = !bCreateNew;
	plg->size_buf=WRITEBUFFERSIZE;
	plg->cryptMethod=-1;
	plg->buf=malloc(plg->size_buf);
	if(!plg->buf)
	{	free(plg);
		return NULL;
	}

	//plg->bAnsi=AreFileApisANSI();
	plg->password[0]=0;
	if(bCreateNew)
	{	
CreateZip:
		fill_win32_filefunc64W(&plg->ffuncZip);
		plg->zf = zipOpen2_64(plg->zpFileName,0,NULL,&plg->ffuncZip);
		if(!plg->zf)
		{	msgWA(0,strngs[57]/*"Err.opening zip file."*/,(LPTSTR)name);
			free(plg->buf);
			free(plg);
			return NULL;
		}
		if(plg->bSFX)
		{	if(bCreateNew)
				zipAddSXFHeader(plg->zf);
			//else							//rename o'zi qiladur;
			//	zipCopySXFHeader(plg->zf);	//qolgani ham o'zi qilsun;
		}
		return plg;
	}
	else
	{	//Found the packtype:
		FILE *unzf;
		plg->szZip = getFileSize(name);
		if(plg->szZip<100*1024*1024)//100 mB dan kichik b-sa:
		{	plg->heapAndMapBuf = malloc((size_t)plg->szZip);
			if(!plg->heapAndMapBuf)
				goto TryToFileMapping;
			plg->packType=heap;//hozircha;
			unzf=_wfopen(name,L"rb");
			if(!unzf)
				goto TryToFileMapping;
			if(plg->szZip!=fread(plg->heapAndMapBuf, 1, (size_t)plg->szZip, unzf))
			{	fclose(unzf);
				free(plg->heapAndMapBuf);
				free(plg->buf);
				msgWA(0,strngs[52],(LPTSTR)name);
				return NULL;
			}
			fclose(unzf);
			goto CreateZip;
		}
		else
		{	
TryToFileMapping:
			if(TryToCreateFileMapping(plg,&plg->szZip))
			{	plg->packType=disk;//hozircha;
				unzf=_wfopen(name,L"rb");
				if(!unzf)
					goto TryToDisk;
				if(plg->szZip!=fread(plg->heapAndMapBuf, 1, (size_t)plg->szZip, unzf))
				{	fclose(unzf);
					free(plg->heapAndMapBuf);
					free(plg->buf);
					free(plg);
					msgWA(0,strngs[52],(LPTSTR)name);
					return NULL;
				}
				fclose(unzf);
				goto CreateZip;
			}
			else goto TryToDisk;
		}
		//else
		{	
TryToDisk:	plg->packType=disk;
			fill_win32_filefunc64W(&plg->ffuncZip);
			if(!CreateTempFileName(plg))
			{	msgWA(0,strngs[61],(LPTSTR)name);
				free(plg->buf);
				free(plg);
				return NULL;
			}
			plg->zf = zipOpen2_64(plg->tmpZpFileName,0,NULL,&plg->ffuncZip);
			if(!plg->zf)
			{	msgWA(0,strngs[62]/*"Err.opening zip file."*/,(LPTSTR)name);
				free(plg->buf);
				free(plg);
				return NULL;
	}	}	}
	return plg;
}

BOOL Close$4(PluginObj *plg)
{
	if(plg->bAppend)
	{	if(heap==plg->packType)
		{	free(plg->heapAndMapBuf);
			zipClose(plg->zf,NULL);
			plg->zf=0;
			free(plg->buf);
			plg->buf=NULL;
			plg->size_buf=0;
			free(plg);
			plg=0;
			return TRUE;
		}
		else if(pagefile==plg->packType)
		{	UnmapViewOfFile(plg->heapAndMapBuf);
			CloseHandle(plg->hfmap);
			zipClose(plg->zf,NULL);
			plg->zf=0;
			free(plg->buf);
			plg->buf=NULL;
			plg->size_buf=0;
			free(plg);
			plg=0;
			return TRUE;
		}
		else if(unpacking==plg->packType)
		{	unzClose(plg->uf);
			plg->zf=0;
			free(plg);
			return TRUE;
		}
		else//disk:
		{	zipClose(plg->zf,NULL);
			plg->zf=0;
			free(plg->buf);
			plg->buf=NULL;
			plg->size_buf=0;
			if(!MoveFileExW(plg->tmpZpFileName,plg->zpFileName,MOVEFILE_REPLACE_EXISTING|MOVEFILE_WRITE_THROUGH))
			{	if(CopyFileW(plg->tmpZpFileName,plg->zpFileName,FALSE))
				{	if(!DeleteFileW(plg->tmpZpFileName))
					{	free(plg);
						plg=0;
						return FALSE;
				}	}
				free(plg);
				plg=0;
				return TRUE;
			}
			if(plg)
			{	free(plg);
				plg=0;
	}	}	}
	else if(unpacking==plg->packType)
	{	unzClose(plg->uf);
		free(plg);
		plg=0;
	}
	else
	{	zipClose(plg->zf,NULL);
		plg->zf=0;
		free(plg->buf);
		plg->buf=NULL;
		plg->size_buf=0;
		free(plg);
		plg=0;
	}
	return TRUE;
}

BOOL CheckUnzFileForUpdating(plg,name,chckFilesToExisting,
							 iNumInSeltns,cpsize,uncpsize,
							 filedate,filetime)
PluginObj *plg;
char *name;
int *chckFilesToExisting;
int *iNumInSeltns;
unsigned int cpsize;
unsigned int uncpsize;
unsigned int filedate;
unsigned int filetime;
{
WIN32_FIND_DATA ff;
tm_unz tmunz;
int r;
unsigned __int64 ft;
unsigned __int64 szf;
unsigned __int64 *zpFt;

	(*iNumInSeltns) = checkFileInSelctn(plg->host,name);
	if(*iNumInSeltns<0 || skipAll==(*chckFilesToExisting) ||
						(cpsize==0 && uncpsize==0))//directory
		return TRUE;

	if(overwriteAll==(*chckFilesToExisting))
		return FALSE;

	if(!getFileInfoFromSelection(plg->host,(*iNumInSeltns),&ff))
		return TRUE;

	zpFt = ZipFileTimeToUint64(filedate,filetime,&tmunz);
	ft=(unsigned __int64)ff.ftCreationTime.dwHighDateTime<<32 | (unsigned __int64)ff.ftCreationTime.dwLowDateTime;
	szf = ((unsigned __int64)ff.nFileSizeHigh<<32) | (unsigned __int64)ff.nFileSizeLow;
	if(overwriteOldestAll==(*chckFilesToExisting))
	{	if((*zpFt)>ft)
			return TRUE;
	}
	else if(overwriteLatestAll==(*chckFilesToExisting))
	{	if((*zpFt)<ft)
			return TRUE;
	}
	else if(overwriteBigestAll==(*chckFilesToExisting))
	{	if(szf<uncpsize)
			return TRUE;
	}
	else if(overwriteLittlestAll==(*chckFilesToExisting))
	{	if(szf>uncpsize)
			return TRUE;
	}
	r = showDlgOverwriteExistFile(plg->host,(*iNumInSeltns),name,
		&szf,ZipTimeToFileTime(&tmunz),&ff);

	if(r==overwriteAll || r==skipAll || r==renameAll || r==overwriteOldestAll ||
	   r==overwriteLatestAll || r==overwriteBigestAll || r==overwriteLittlestAll )
	  (*chckFilesToExisting) = r;
	if(r==skip || r==skipAll)
		return TRUE;
	else if(overwrite==(*chckFilesToExisting) || overwriteAll==(*chckFilesToExisting))
		return FALSE;
	else if(r==cancel)
	{	(*chckFilesToExisting) = overwriteAll;
		return TRUE;//FALSE;
	}
	else if(r==overwriteOldest || r==overwriteOldestAll)
	{	if((*zpFt)>ft)
			return TRUE;
	}
	else if(r==overwriteLatest || r==overwriteLatestAll)
	{	if((*zpFt)<ft)
			return TRUE;
	}
	else if(r==overwriteBigest || r==overwriteBigestAll)
	{	if(szf<uncpsize)
			return TRUE;
	}
	else if(r==overwriteLittlest || r==overwriteLittlestAll)
	{	if(szf>uncpsize)
			return TRUE;
	}
	return FALSE;
}

extern unsigned int WriteToZipFileHandle(zipFile*,void*,int);
extern unsigned int ReadFromUnzipFileHandle(unzFile*,void*,int);
extern int GetNodeInfoFromCentralHeaderMem(void*,char*,ZPOS64_T*,ZPOS64_T*);
extern int AddEndFileEntryForAppendingFromZip(zipFile,uInt,uInt,uInt,uInt,uInt,uInt,uInt,uInt,uInt,uInt,char*,unsigned int,char*,uInt,uInt,uLong*);
extern ZPOS64_T unz64local_SearchCentralDir64FromMem(void*,ZPOS64_T*);
BOOL RebuildCheckExistingUseMem(PluginObj *plg,char *password)
{
#define READ_8(adr)  ((unsigned char)*(adr))
#define READ_16(adr) ( READ_8(adr) | (READ_8(adr+1) << 8) )
#define READ_32(adr) ( READ_16(adr) | (READ_16((adr)+2) << 16) )

#define WRITE_8(buff, n) do { \
  *((unsigned char*)(buff)) = (unsigned char) ((n) & 0xff); \
} while(0)
#define WRITE_16(buff, n) do { \
  WRITE_8((unsigned char*)(buff), n); \
  WRITE_8(((unsigned char*)(buff)) + 1, (n) >> 8); \
} while(0)
#define WRITE_32(buff, n) do { \
  WRITE_16((unsigned char*)(buff), (n) & 0xffff); \
  WRITE_16((unsigned char*)(buff) + 2, (n) >> 16); \
} while(0)

int err;
//char *changeSlash;
int iExstInSeltns;
int chckFilesToExisting=showEach;

int entries = 0;
char *header;
char filename[1024];
char extra[1024];
char*unzmem=plg->heapAndMapBuf;
ZPOS64_T filePosInCentralDir,offsetBeg,offset=0;
unsigned int offsetInCentralDir=0;


	if(!unzmem)
    {	msgWA(0,strngs[63],(LPTSTR)plg->zpFileName);//"error opening"
		return FALSE;
	}

	filePosInCentralDir = unz64local_SearchCentralDir64FromMem(unzmem,&plg->szZip);

	plg->fstFilePos = unzGetFirstFileOffsetFromMem(unzmem+filePosInCentralDir);
	if(plg->bSFX)
	if(0==plg->fstFilePos)
		plg->bSFX = FALSE;
	if(plg->bSFX)
	{	if(!WriteToZipFileHandle(plg->zf,unzmem,(int)plg->fstFilePos)==plg->fstFilePos)
		{	err = Z_ERRNO;
			return FALSE;
		}
		unzmem += plg->fstFilePos;
		offset = plg->fstFilePos;
	}

	while(unzmem-(char*)plg->heapAndMapBuf<plg->szZip)
	{	err = 0;
		offsetBeg = offset;
		if(offsetBeg > 0xffffffff)offsetBeg=0;//disk almashadur;
		header = unzmem;//fread(header, 1, 30, unzf) == 30)
		offset += 30;
		unzmem += 30;
		
		// File entry 
		if(READ_32(header) == 0x04034b50)
		{	unsigned int version = READ_16(header + 4);
			unsigned int gpflag = READ_16(header + 6);
			unsigned int method = READ_16(header + 8);
			unsigned int filetime = READ_16(header + 10);
			unsigned int filedate = READ_16(header + 12);
			unsigned int crc = READ_32(header + 14); // crc 
			unsigned int cpsize = READ_32(header + 18); // compressed size 
			unsigned int uncpsize = READ_32(header + 22); // uncompressed sz 
			unsigned int fnsize = READ_16(header + 26); // file name length 
			unsigned int extsize = READ_16(header + 28); // extra field length 
			BOOL bUpdateFrUnzip=FALSE;
			filename[0] = extra[0] = '\0';

			// Filename 
			if(fnsize > 0)
			{	if(fnsize < sizeof(filename))
				{	unsigned int i;
					for(i=0; i<fnsize; i++)
						filename[i] = unzmem[i];//fread(filename, 1, fnsize, unzf) == fnsize)
					unzmem+=fnsize;
					offset += fnsize;
					filename[fnsize]=0;						
					bUpdateFrUnzip=CheckUnzFileForUpdating(plg,filename,
												&chckFilesToExisting,
												&iExstInSeltns,
												cpsize,uncpsize,
												filedate,filetime);
					if(bUpdateFrUnzip)
					{	// Header
					    if(!WriteToZipFileHandle(plg->zf,header,30)==30)
						{	err = Z_ERRNO;
							break;
						}

						// Filename
						if(!WriteToZipFileHandle(plg->zf,filename,fnsize)==fnsize)
						{	err = Z_ERRNO;
							break;
						}
						excldFileFrSelctn(plg->host,iExstInSeltns,entries);
					}
					else
					{	err = Z_ERRNO;
						break;
				}	}
				else
				{	err = Z_ERRNO;
					break;
			}	}
			else
			{	err = Z_STREAM_ERROR;
				break;
			}

			// Extra field 
			if(extsize > 0)
			{	if(extsize < sizeof(extra))
				{	if(bUpdateFrUnzip)
					{	if(WriteToZipFileHandle(plg->zf,unzmem,extsize)==extsize)
						{	unzmem+=extsize;
							offset += extsize;
						}
						else
						{	err = Z_ERRNO;
							break;
					}	}
					else
					{	err = Z_ERRNO;
						break;
				}   }
				else
				{	err = Z_ERRNO;
					break;
			}	}
		
			// Data
			{	int dataSize = cpsize;
				if(dataSize == 0)
					dataSize = uncpsize;
				if(dataSize > 0)
				{	if(bUpdateFrUnzip)
					{	if(WriteToZipFileHandle(plg->zf,unzmem,dataSize)==dataSize)
						{	unzmem+=dataSize;
							offset += dataSize;
						}
						else
							err = Z_ERRNO;
					}
					else
						err = Z_ERRNO;
					if(err != Z_OK)
						break;
			}   }

			// Close file in zip, fill for central directory entry 
			if(bUpdateFrUnzip)
			{	char cibuf[46];char *pcibuf=cibuf;
				unsigned int	version1,
								version2,
								gpflag1,
								method1,
								filetime1,
								filedate1,
								crc1,
								cpsize1,
								uncpsize1,
								fnsize1,
								extsize1,
								comntsize,
								//diskNumb,
								intAttrb,
								extAttrb;//,
								//crntOffst1;
				int r=GetNodeInfoFromCentralHeaderMem(	(char*)plg->heapAndMapBuf,
														cibuf,
														&filePosInCentralDir,
														&offset);
				if(r<0){err = Z_MEM_ERROR;break;}
				//else:
				filePosInCentralDir+=r;
				version1 = READ_16(pcibuf + 4);
				version2 = READ_16(pcibuf + 6);
				gpflag1 = READ_16(pcibuf + 8);
				method1 = READ_16(pcibuf + 10);
				filetime1 = READ_16(pcibuf + 12);
				filedate1 = READ_16(pcibuf + 14);
				crc1 = READ_32(pcibuf + 16); // crc 
				cpsize1 = READ_32(pcibuf + 20); // compressed size 
				uncpsize1 = READ_32(pcibuf + 24); // uncompressed sz 
				fnsize1 = READ_16(pcibuf + 28); // file name length 
				extsize1 = READ_16(pcibuf + 30); // extra field length 
				comntsize = READ_16(pcibuf + 32); // comment filed length 
				//diskNumb = READ_16(pcibuf + 34); // disk # 
				intAttrb = READ_16(pcibuf + 36); // int attrb 
				extAttrb = READ_32(pcibuf + 38); // ext attrb 
				//crntOffst1 = READ_32(pcibuf + 42); // crnt offset 
				if(gpflag1 != gpflag)
					{err = Z_MEM_ERROR;break;}
				if(method1 != method)
					{err = Z_MEM_ERROR;break;}
				if(filetime1 != filetime)
					{err = Z_MEM_ERROR;break;}
				if(filedate1 != filedate)
					{err = Z_MEM_ERROR;break;}
				if(crc1 != crc)
					{err = Z_MEM_ERROR;break;}
				if(cpsize1 != cpsize)
					{err = Z_MEM_ERROR;break;}
				if(uncpsize1 != uncpsize)
					{err = Z_MEM_ERROR;break;}
				if(fnsize1 != fnsize)
					{err = Z_MEM_ERROR;break;}
				if(extsize1 != extsize)
					{err = Z_MEM_ERROR;break;}
				r=AddEndFileEntryForAppendingFromZip(plg->zf,version1,version2,gpflag,method,
							uncpsize,cpsize,filedate,filetime,crc,fnsize,filename,extsize,extra,
							intAttrb,extAttrb,(uLong*)&offsetBeg);
				if(r < 0)
				{	err = Z_MEM_ERROR;
					break;
			}	}
			// Success 
			entries++;
		}
		else
			break;
	}

	return err==0?TRUE:FALSE;
}

BOOL RenameFileUseMem(PluginObj *plg,char *fName,char *fNewName)
{
#define READ_8(adr)  ((unsigned char)*(adr))
#define READ_16(adr) ( READ_8(adr) | (READ_8(adr+1) << 8) )
#define READ_32(adr) ( READ_16(adr) | (READ_16((adr)+2) << 16) )

#define WRITE_8(buff, n) do { \
  *((unsigned char*)(buff)) = (unsigned char) ((n) & 0xff); \
} while(0)
#define WRITE_16(buff, n) do { \
  WRITE_8((unsigned char*)(buff), n); \
  WRITE_8(((unsigned char*)(buff)) + 1, (n) >> 8); \
} while(0)
#define WRITE_32(buff, n) do { \
  WRITE_16((unsigned char*)(buff), (n) & 0xffff); \
  WRITE_16((unsigned char*)(buff) + 2, (n) >> 16); \
} while(0)

int err;
//char *changeSlash;

int entries = 0;
char *header;
char filename[1024];
char extra[1024];
char *unzmem=plg->heapAndMapBuf;
ZPOS64_T filePosInCentralDir,offsetBeg,offset=0,numMismatch=0;
unsigned int offsetInCentralDir=0;

	if(!unzmem)
    {	msgWA(0,strngs[63],(LPTSTR)plg->zpFileName);//"error opening"
		return FALSE;
	}

	filePosInCentralDir = unz64local_SearchCentralDir64FromMem(unzmem,&plg->szZip);

	plg->fstFilePos = unzGetFirstFileOffsetFromMem(unzmem+filePosInCentralDir);
	if(plg->bSFX)
	if(0==plg->fstFilePos)
		plg->bSFX = FALSE;
	if(plg->bSFX)
	{	if(!WriteToZipFileHandle(plg->zf,unzmem,(int)plg->fstFilePos)==plg->fstFilePos)
		{	err = Z_ERRNO;
			return FALSE;
		}
		unzmem += plg->fstFilePos;
		offset = plg->fstFilePos;
	}

	while(unzmem-(char*)plg->heapAndMapBuf<plg->szZip)
	{	err = 0;
		offsetBeg = offset+numMismatch;
		if(offsetBeg > 0xffffffff)offsetBeg=0;//disk almashadur;
		header = unzmem;//fread(header, 1, 30, unzf) == 30)
		offset += 30;
		unzmem += 30;
		
		/* File entry */
		if(READ_32(header) == 0x04034b50)
		{	unsigned int version = READ_16(header + 4);
			unsigned int gpflag = READ_16(header + 6);
			unsigned int method = READ_16(header + 8);
			unsigned int filetime = READ_16(header + 10);
			unsigned int filedate = READ_16(header + 12);
			unsigned int crc = READ_32(header + 14); /* crc */
			unsigned int cpsize = READ_32(header + 18); /* compressed size */
			unsigned int uncpsize = READ_32(header + 22); /* uncompressed sz */
			unsigned int fnsize = READ_16(header + 26); /* file name length */
			unsigned int extsize = READ_16(header + 28); /* extra field length */
			unsigned int fnsizeOld = fnsize;

			/* Close file in zip, fill for central directory entry */
			char cibuf[46];char *pcibuf=cibuf;int r;
			unsigned int	version1,
							version2,
							gpflag1,
							method1,
							filetime1,
							filedate1,
							crc1,
							cpsize1,
							uncpsize1,
							fnsize1,
							extsize1,
							comntsize,
							//diskNumb,
							intAttrb,
							extAttrb;//,
							//crntOffst1;

			filename[0] = extra[0] = '\0';

			/* Filename */
			if(fnsize > 0)
			{	if(fnsize < sizeof(filename))
				{	unsigned int i;
					for(i=0; i<fnsize; i++)
						filename[i] = unzmem[i];//fread(filename, 1, fnsize, unzf) == fnsize)
					unzmem+=fnsize;
					offset += fnsize;
					filename[fnsize]=0;
					if(zstrstr_slash(filename,fName))//if(0==strcmp(filename,fName))
					{	char *p = zstrrchr2_excl_end(filename,'\\','/');
						if(p)
						{	BOOL bsl = ('\\'==(*p) || '/'==(*p)) ? TRUE : FALSE;
						    fnsize = MyStringCpy(bsl ? p+1 : p,1023,fNewName);
							if(p!=&filename[0])
								fnsize += (int)(1+p-&filename[0]);
						}
						else//Root dir b-sa, bez slash ham keladur;
							fnsize = MyStringCpy(filename,1023,fNewName);
						WRITE_16(header+26,fnsize);
						numMismatch += fnsize-fnsizeOld;
					}
					// Header
					if(!WriteToZipFileHandle(plg->zf,header,30)==30)
					{	err = Z_ERRNO;
						break;
					}

					// Filename
					if(!WriteToZipFileHandle(plg->zf,filename,fnsize)==fnsize)
					{	err = Z_ERRNO;
						break;
				}	}
				else
				{	err = Z_ERRNO;
					break;
			}	}
			else
			{	err = Z_STREAM_ERROR;
				break;
			}

			/* Extra field */
			if(extsize > 0)
			{	if(extsize < sizeof(extra))
				{	if(WriteToZipFileHandle(plg->zf,unzmem,extsize)==extsize)
					{	unzmem+=extsize;
						offset += extsize;
					}
					else
					{	err = Z_ERRNO;
						break;
				}   }
				else
				{	err = Z_ERRNO;
					break;
			}	}
		
			/* Data */
			{	int dataSize = cpsize;
				if(dataSize == 0)
					dataSize = uncpsize;
				if(dataSize > 0)
				{	if(WriteToZipFileHandle(plg->zf,unzmem,dataSize)==dataSize)
					{	unzmem+=dataSize;
						offset += dataSize;
					}
					else
						err = Z_ERRNO;
					if(err != Z_OK)
						break;
			}   }

			r=GetNodeInfoFromCentralHeaderMem(plg->heapAndMapBuf,cibuf,&filePosInCentralDir,&offset);
			if(r<0){err = Z_MEM_ERROR;break;}
			//else:
			filePosInCentralDir+=r;
			version1 = READ_16(pcibuf + 4);
			version2 = READ_16(pcibuf + 6);
			gpflag1 = READ_16(pcibuf + 8);
			method1 = READ_16(pcibuf + 10);
			filetime1 = READ_16(pcibuf + 12);
			filedate1 = READ_16(pcibuf + 14);
			crc1 = READ_32(pcibuf + 16); /* crc */
			cpsize1 = READ_32(pcibuf + 20); /* compressed size */
			uncpsize1 = READ_32(pcibuf + 24); /* uncompressed sz */
			fnsize1 = READ_16(pcibuf + 28); /* file name length */
			extsize1 = READ_16(pcibuf + 30); /* extra field length */
			comntsize = READ_16(pcibuf + 32); /* comment filed length */
			//diskNumb = READ_16(pcibuf + 34); /* disk # */
			intAttrb = READ_16(pcibuf + 36); /* int attrb */
			extAttrb = READ_32(pcibuf + 38); /* ext attrb */
			//crntOffst1 = READ_32(pcibuf + 42); /* crnt offset */
			if(gpflag1 != gpflag)
				{err = Z_MEM_ERROR;break;}
			if(method1 != method)
				{err = Z_MEM_ERROR;break;}
			if(filetime1 != filetime)
				{err = Z_MEM_ERROR;break;}
			if(filedate1 != filedate)
				{err = Z_MEM_ERROR;break;}
			if(crc1 != crc)
				{err = Z_MEM_ERROR;break;}
			if(cpsize1 != cpsize)
				{err = Z_MEM_ERROR;break;}
			if(uncpsize1 != uncpsize)
				{err = Z_MEM_ERROR;break;}
			if(fnsize1 != fnsizeOld)
				{err = Z_MEM_ERROR;break;}
			if(extsize1 != extsize)
				{err = Z_MEM_ERROR;break;}
			r=AddEndFileEntryForAppendingFromZip(plg->zf,version1,version2,gpflag,method,
						uncpsize,cpsize,filedate,filetime,crc,fnsize,filename,extsize,extra,
						intAttrb,extAttrb,(uLong*)&offsetBeg);
			if(r < 0)
			{	err = Z_MEM_ERROR;
				break;
			}
			/* Success */
			entries++;
		}
		else
			break;
	}

	return err==0?TRUE:FALSE;
}

BOOL RenameDirUseMem(PluginObj *plg,char *FName,char *FNewName)
{
#define READ_8(adr)  ((unsigned char)*(adr))
#define READ_16(adr) ( READ_8(adr) | (READ_8(adr+1) << 8) )
#define READ_32(adr) ( READ_16(adr) | (READ_16((adr)+2) << 16) )

#define WRITE_8(buff, n) do { \
  *((unsigned char*)(buff)) = (unsigned char) ((n) & 0xff); \
} while(0)
#define WRITE_16(buff, n) do { \
  WRITE_8((unsigned char*)(buff), n); \
  WRITE_8(((unsigned char*)(buff)) + 1, (n) >> 8); \
} while(0)
#define WRITE_32(buff, n) do { \
  WRITE_16((unsigned char*)(buff), (n) & 0xffff); \
  WRITE_16((unsigned char*)(buff) + 2, (n) >> 16); \
} while(0)

int err;
//char *changeSlash;

int fNameLn,entries = 0;
char *header;
char filename[1024];
char extra[1024];
char *unzmem=plg->heapAndMapBuf;
ZPOS64_T filePosInCentralDir,offsetBeg,offset=0,numMismatch=0;
unsigned int fNameLnoffsetInCentralDir=0;
//wchar_t ws[MAX_PATH];
char fName[MAX_PATH];
char fNewName[MAX_PATH];

	if(!unzmem)
    {	msgWA(0,strngs[63],(LPTSTR)plg->zpFileName);//"error opening"
		return FALSE;
	}

	//if(plg->bAnsi)
	//{	MultiByteToWideChar(CP_ACP,MB_PRECOMPOSED,FName,MAX_PATH-1,ws,MAX_PATH);
	//	fNameLn = WideCharToMultiByte(CP_OEMCP,0,ws,-1,fName,MAX_PATH-1,NULL,NULL)-1;
	//	MultiByteToWideChar(CP_ACP,MB_PRECOMPOSED,FNewName,MAX_PATH-1,ws,MAX_PATH);
	//	WideCharToMultiByte(CP_OEMCP,0,ws,-1,fNewName,MAX_PATH-1,NULL,NULL);
	//}
	//else
	{	fNameLn = MyStringCpy(fName,MAX_PATH,FName);
		MyStringCpy(fNewName,MAX_PATH,FNewName);
	}

	filePosInCentralDir = unz64local_SearchCentralDir64FromMem(unzmem,&plg->szZip);

	plg->fstFilePos = unzGetFirstFileOffsetFromMem(unzmem+filePosInCentralDir);
	if(plg->bSFX)
	if(0==plg->fstFilePos)
		plg->bSFX = FALSE;
	if(plg->bSFX)
	{	if(!WriteToZipFileHandle(plg->zf,unzmem,(int)plg->fstFilePos)==plg->fstFilePos)
		{	err = Z_ERRNO;
			return FALSE;
		}
		unzmem += plg->fstFilePos;
		offset = plg->fstFilePos;
	}

	while(unzmem-(char*)plg->heapAndMapBuf<plg->szZip)
	{	err = 0;
		offsetBeg = offset+numMismatch;
		if(offsetBeg > 0xffffffff)offsetBeg=0;//disk almashadur;
		header = unzmem;//fread(header, 1, 30, unzf) == 30)
		offset += 30;
		unzmem += 30;
		
		/* File entry */
		if(READ_32(header) == 0x04034b50)
		{	unsigned int version = READ_16(header + 4);
			unsigned int gpflag = READ_16(header + 6);
			unsigned int method = READ_16(header + 8);
			unsigned int filetime = READ_16(header + 10);
			unsigned int filedate = READ_16(header + 12);
			unsigned int crc = READ_32(header + 14); /* crc */
			unsigned int cpsize = READ_32(header + 18); /* compressed size */
			unsigned int uncpsize = READ_32(header + 22); /* uncompressed sz */
			unsigned int fnsize = READ_16(header + 26); /* file name length */
			unsigned int extsize = READ_16(header + 28); /* extra field length */
			unsigned int fnsizeOld = fnsize;

			/* Close file in zip, fill for central directory entry */
			char cibuf[46];char *pcibuf=cibuf;int r;
			unsigned int	version1,
							version2,
							gpflag1,
							method1,
							filetime1,
							filedate1,
							crc1,
							cpsize1,
							uncpsize1,
							fnsize1,
							extsize1,
							comntsize,
							//diskNumb,
							intAttrb,
							extAttrb;//,
							//crntOffst1;

			filename[0] = extra[0] = '\0';

			/* Filename */
			if(fnsize > 0)
			{	if(fnsize < sizeof(filename))
				{	unsigned int i;
					for(i=0; i<fnsize; i++)
						filename[i] = unzmem[i];//fread(filename, 1, fnsize, unzf) == fnsize)
					unzmem+=fnsize;
					offset += fnsize;
					filename[fnsize]=0;
					if(zstrstr_slash(filename,fName))//if(0==strcmp(filename,fName))
					{	char *p,tail[MAX_PATH];MyStringCpy(tail,MAX_PATH,&filename[fNameLn]);
						filename[fNameLn] = 0;
						p = zstrrchr2_excl_end(filename,'\\','/');
						if(p)
						{	BOOL bsl = ('\\'==(*p) || '/'==(*p)) ? TRUE : FALSE;
							fnsize = MyStringCpy(bsl ? p+1 : p,1023,fNewName);
							if(p!=&filename[0])
								fnsize += (int)(1+p-&filename[0]);
						}
						else//Root dir b-sa, bez slash ham keladur;
							fnsize = MyStringCpy(filename,1023,fNewName);
						fnsize += MyStringCpy(&filename[fnsize],1023-fnsize,tail);
						WRITE_16(header+26,fnsize);
						numMismatch += fnsize-fnsizeOld;
					}
					// Header
					if(!WriteToZipFileHandle(plg->zf,header,30)==30)
					{	err = Z_ERRNO;
						break;
					}

					// Filename
					if(!WriteToZipFileHandle(plg->zf,filename,fnsize)==fnsize)
					{	err = Z_ERRNO;
						break;
				}	}
				else
				{	err = Z_ERRNO;
					break;
			}	}
			else
			{	err = Z_STREAM_ERROR;
				break;
			}

			/* Extra field */
			if(extsize > 0)
			{	if(extsize < sizeof(extra))
				{	if(WriteToZipFileHandle(plg->zf,unzmem,extsize)==extsize)
					{	unzmem+=extsize;
						offset += extsize;
					}
					else
					{	err = Z_ERRNO;
						break;
				}   }
				else
				{	err = Z_ERRNO;
					break;
			}	}
		
			/* Data */
			{	int dataSize = cpsize;
				if(dataSize == 0)
					dataSize = uncpsize;
				if(dataSize > 0)
				{	if(WriteToZipFileHandle(plg->zf,unzmem,dataSize)==dataSize)
					{	unzmem+=dataSize;
						offset += dataSize;
					}
					else
						err = Z_ERRNO;
					if(err != Z_OK)
						break;
			}   }

			r=GetNodeInfoFromCentralHeaderMem(plg->heapAndMapBuf,cibuf,&filePosInCentralDir,&offset);
			if(r<0){err = Z_MEM_ERROR;break;}
			//else:
			filePosInCentralDir+=r;
			version1 = READ_16(pcibuf + 4);
			version2 = READ_16(pcibuf + 6);
			gpflag1 = READ_16(pcibuf + 8);
			method1 = READ_16(pcibuf + 10);
			filetime1 = READ_16(pcibuf + 12);
			filedate1 = READ_16(pcibuf + 14);
			crc1 = READ_32(pcibuf + 16); /* crc */
			cpsize1 = READ_32(pcibuf + 20); /* compressed size */
			uncpsize1 = READ_32(pcibuf + 24); /* uncompressed sz */
			fnsize1 = READ_16(pcibuf + 28); /* file name length */
			extsize1 = READ_16(pcibuf + 30); /* extra field length */
			comntsize = READ_16(pcibuf + 32); /* comment filed length */
			//diskNumb = READ_16(pcibuf + 34); /* disk # */
			intAttrb = READ_16(pcibuf + 36); /* int attrb */
			extAttrb = READ_32(pcibuf + 38); /* ext attrb */
			//crntOffst1 = READ_32(pcibuf + 42); /* crnt offset */
			if(gpflag1 != gpflag)
				{err = Z_MEM_ERROR;break;}
			if(method1 != method)
				{err = Z_MEM_ERROR;break;}
			if(filetime1 != filetime)
				{err = Z_MEM_ERROR;break;}
			if(filedate1 != filedate)
				{err = Z_MEM_ERROR;break;}
			if(crc1 != crc)
				{err = Z_MEM_ERROR;break;}
			if(cpsize1 != cpsize)
				{err = Z_MEM_ERROR;break;}
			if(uncpsize1 != uncpsize)
				{err = Z_MEM_ERROR;break;}
			if(fnsize1 != fnsizeOld)
				{err = Z_MEM_ERROR;break;}
			if(extsize1 != extsize)
				{err = Z_MEM_ERROR;break;}
			r=AddEndFileEntryForAppendingFromZip(plg->zf,version1,version2,gpflag,method,
						uncpsize,cpsize,filedate,filetime,crc,fnsize,filename,extsize,extra,
						intAttrb,extAttrb,(uLong*)&offsetBeg);
			if(r < 0)
			{	err = Z_MEM_ERROR;
				break;
			}
			/* Success */
			entries++;
		}
		else
			break;
	}

	return err==0?TRUE:FALSE;
}

BOOL DeleteFileUseMem(PluginObj *plg,char *fName)
{
#define READ_8(adr)  ((unsigned char)*(adr))
#define READ_16(adr) ( READ_8(adr) | (READ_8(adr+1) << 8) )
#define READ_32(adr) ( READ_16(adr) | (READ_16((adr)+2) << 16) )

#define WRITE_8(buff, n) do { \
  *((unsigned char*)(buff)) = (unsigned char) ((n) & 0xff); \
} while(0)
#define WRITE_16(buff, n) do { \
  WRITE_8((unsigned char*)(buff), n); \
  WRITE_8(((unsigned char*)(buff)) + 1, (n) >> 8); \
} while(0)
#define WRITE_32(buff, n) do { \
  WRITE_16((unsigned char*)(buff), (n) & 0xffff); \
  WRITE_16((unsigned char*)(buff) + 2, (n) >> 16); \
} while(0)

int err;
//char *changeSlash;

int entries = 0;
char *header;
char filename[1024];
char extra[1024];
char *unzmem=plg->heapAndMapBuf;
ZPOS64_T filePosInCentralDir,offsetBeg,offset=0,numMismatch=0;
unsigned int offsetInCentralDir=0;

	if(!unzmem)
    {	msgWA(0,strngs[63],(LPTSTR)plg->zpFileName);//"error opening"
		return FALSE;
	}

	filePosInCentralDir = unz64local_SearchCentralDir64FromMem(unzmem,&plg->szZip);

	plg->fstFilePos = unzGetFirstFileOffsetFromMem(unzmem+filePosInCentralDir);
	if(plg->bSFX)
	if(0==plg->fstFilePos)
		plg->bSFX = FALSE;
	if(plg->bSFX)
	{	if(!WriteToZipFileHandle(plg->zf,unzmem,(int)plg->fstFilePos)==plg->fstFilePos)
		{	err = Z_ERRNO;
			return FALSE;
		}
		unzmem += plg->fstFilePos;
		offset = plg->fstFilePos;
	}

	while(unzmem-(char*)plg->heapAndMapBuf<plg->szZip)
	{	BOOL bDelete = FALSE;
		err = 0;
		offsetBeg = offset+numMismatch;
		if(offsetBeg > 0xffffffff)offsetBeg=0;//disk almashadur;
		header = unzmem;//fread(header, 1, 30, unzf) == 30)
		offset += 30;
		unzmem += 30;
		
		/* File entry */
		if(READ_32(header) == 0x04034b50)
		{	unsigned int version = READ_16(header + 4);
			unsigned int gpflag = READ_16(header + 6);
			unsigned int method = READ_16(header + 8);
			unsigned int filetime = READ_16(header + 10);
			unsigned int filedate = READ_16(header + 12);
			unsigned int crc = READ_32(header + 14); /* crc */
			unsigned int cpsize = READ_32(header + 18); /* compressed size */
			unsigned int uncpsize = READ_32(header + 22); /* uncompressed sz */
			unsigned int fnsize = READ_16(header + 26); /* file name length */
			unsigned int extsize = READ_16(header + 28); /* extra field length */
			unsigned int fnsizeOld = fnsize;

			/* Close file in zip, fill for central directory entry */
			char cibuf[46];char *pcibuf=cibuf;int r;
			unsigned int	version1,
							version2,
							gpflag1,
							method1,
							filetime1,
							filedate1,
							crc1,
							cpsize1,
							uncpsize1,
							fnsize1,
							extsize1,
							comntsize,
							//diskNumb,
							intAttrb,
							extAttrb;//,
							//crntOffst1;

			filename[0] = extra[0] = '\0';

			/* Filename */
			if(fnsize > 0)
			{	if(fnsize < sizeof(filename))
				{	unsigned int i;
					for(i=0; i<fnsize; i++)
						filename[i] = unzmem[i];//fread(filename, 1, fnsize, unzf) == fnsize)
					unzmem+=fnsize;
					offset += fnsize;
					filename[fnsize]=0;
					if(zstrstr_slash(filename,fName))//if(0==strcmp(filename,fName))
					{	bDelete = TRUE;
						/*char *p = zstrrchr2_excl_end(filename,'\\','/');
						if(p)
						{	BOOL bsl = ('\\'==(*p) || '/'==(*p)) ? TRUE : FALSE;
						    fnsize = MyStringCpy(bsl ? p+1 : p,1023,fNewName);
							if(p!=&filename[0])
								fnsize += 1+p-&filename[0];
						}
						else//Root dir b-sa, bez slash ham keladur;
							fnsize = MyStringCpy(filename,1023,fNewName);
						WRITE_16(header+26,fnsize);
						numMismatch += fnsize-fnsizeOld;*/
					}
					// Header
					if(!bDelete)
					if(!WriteToZipFileHandle(plg->zf,header,30)==30)
					{	err = Z_ERRNO;
						break;
					}

					// Filename
					if(!bDelete)
					if(!WriteToZipFileHandle(plg->zf,filename,fnsize)==fnsize)
					{	err = Z_ERRNO;
						break;
				}	}
				else
				{	err = Z_ERRNO;
					break;
			}	}
			else
			{	err = Z_STREAM_ERROR;
				break;
			}

			/* Extra field */
			if(!bDelete)
			{	if(extsize > 0)
				{	if(extsize < sizeof(extra))
					{	if(WriteToZipFileHandle(plg->zf,unzmem,extsize)==extsize)
						{	unzmem+=extsize;
							offset += extsize;
						}
						else
						{	err = Z_ERRNO;
							break;
					}   }
					else
					{	err = Z_ERRNO;
						break;
			}	}	}
			else if(extsize > 0 && extsize < sizeof(extra))
			{	unzmem+=extsize;
				offset += extsize;
			}
		
			/* Data */
			if(!bDelete)
			{	int dataSize = cpsize;
				if(dataSize == 0)
					dataSize = uncpsize;
				if(dataSize > 0)
				{	if(WriteToZipFileHandle(plg->zf,unzmem,dataSize)==dataSize)
					{	unzmem+=dataSize;
						offset += dataSize;
					}
					else
						err = Z_ERRNO;
					if(err != Z_OK)
						break;
			}   }
			else
			{	int dataSize = cpsize;
				if(dataSize == 0)
					dataSize = uncpsize;
				unzmem+=dataSize;
				offset += dataSize;
			}

			r=GetNodeInfoFromCentralHeaderMem(plg->heapAndMapBuf,cibuf,&filePosInCentralDir,&offset);
			if(r<0){err = Z_MEM_ERROR;break;}
			//else:
			filePosInCentralDir+=r;
			if(!bDelete)
			{
			version1 = READ_16(pcibuf + 4);
			version2 = READ_16(pcibuf + 6);
			gpflag1 = READ_16(pcibuf + 8);
			method1 = READ_16(pcibuf + 10);
			filetime1 = READ_16(pcibuf + 12);
			filedate1 = READ_16(pcibuf + 14);
			crc1 = READ_32(pcibuf + 16); /* crc */
			cpsize1 = READ_32(pcibuf + 20); /* compressed size */
			uncpsize1 = READ_32(pcibuf + 24); /* uncompressed sz */
			fnsize1 = READ_16(pcibuf + 28); /* file name length */
			extsize1 = READ_16(pcibuf + 30); /* extra field length */
			comntsize = READ_16(pcibuf + 32); /* comment filed length */
			//diskNumb = READ_16(pcibuf + 34); /* disk # */
			intAttrb = READ_16(pcibuf + 36); /* int attrb */
			extAttrb = READ_32(pcibuf + 38); /* ext attrb */
			//crntOffst1 = READ_32(pcibuf + 42); /* crnt offset */
			if(gpflag1 != gpflag)
				{err = Z_MEM_ERROR;break;}
			if(method1 != method)
				{err = Z_MEM_ERROR;break;}
			if(filetime1 != filetime)
				{err = Z_MEM_ERROR;break;}
			if(filedate1 != filedate)
				{err = Z_MEM_ERROR;break;}
			if(crc1 != crc)
				{err = Z_MEM_ERROR;break;}
			if(cpsize1 != cpsize)
				{err = Z_MEM_ERROR;break;}
			if(uncpsize1 != uncpsize)
				{err = Z_MEM_ERROR;break;}
			if(fnsize1 != fnsizeOld)
				{err = Z_MEM_ERROR;break;}
			if(extsize1 != extsize)
				{err = Z_MEM_ERROR;break;}
			r=AddEndFileEntryForAppendingFromZip(plg->zf,version1,version2,gpflag,method,
						uncpsize,cpsize,filedate,filetime,crc,fnsize,filename,extsize,extra,
						intAttrb,extAttrb,(uLong*)&offsetBeg);
			if(r < 0)
			{	err = Z_MEM_ERROR;
				break;
			}
			}
			/* Success */
			entries++;
		}
		else
			break;
	}

	return err==0?TRUE:FALSE;
}

BOOL DeleteDirUseMem(PluginObj *plg,char *FName)
{
#define READ_8(adr)  ((unsigned char)*(adr))
#define READ_16(adr) ( READ_8(adr) | (READ_8(adr+1) << 8) )
#define READ_32(adr) ( READ_16(adr) | (READ_16((adr)+2) << 16) )

#define WRITE_8(buff, n) do { \
  *((unsigned char*)(buff)) = (unsigned char) ((n) & 0xff); \
} while(0)
#define WRITE_16(buff, n) do { \
  WRITE_8((unsigned char*)(buff), n); \
  WRITE_8(((unsigned char*)(buff)) + 1, (n) >> 8); \
} while(0)
#define WRITE_32(buff, n) do { \
  WRITE_16((unsigned char*)(buff), (n) & 0xffff); \
  WRITE_16((unsigned char*)(buff) + 2, (n) >> 16); \
} while(0)

int err;
//char *changeSlash;

int entries = 0;
char *header;
char filename[1024];
char extra[1024];
char *unzmem=plg->heapAndMapBuf;
ZPOS64_T filePosInCentralDir,offsetBeg,offset=0,numMismatch=0;
unsigned int fNameLnoffsetInCentralDir=0;
//wchar_t ws[MAX_PATH];
char fName[MAX_PATH];

	if(!unzmem)
    {	msgWA(0,strngs[63],(LPTSTR)plg->zpFileName);//"error opening"
		return FALSE;
	}

	//if(plg->bAnsi)
	//{	MultiByteToWideChar(CP_ACP,MB_PRECOMPOSED,FName,MAX_PATH-1,ws,MAX_PATH);
	//	WideCharToMultiByte(CP_OEMCP,0,ws,-1,fName,MAX_PATH-1,NULL,NULL);
	//} else 
	MyStringCpy(fName,MAX_PATH,FName);

	filePosInCentralDir = unz64local_SearchCentralDir64FromMem(unzmem,&plg->szZip);

	plg->fstFilePos = unzGetFirstFileOffsetFromMem(unzmem+filePosInCentralDir);
	if(plg->bSFX)
	if(0==plg->fstFilePos)
		plg->bSFX = FALSE;
	if(plg->bSFX)
	{	if(!WriteToZipFileHandle(plg->zf,unzmem,(int)plg->fstFilePos)==plg->fstFilePos)
		{	err = Z_ERRNO;
			return FALSE;
		}
		unzmem += plg->fstFilePos;
		offset = plg->fstFilePos;
	}

	while(unzmem-(char*)plg->heapAndMapBuf<plg->szZip)
	{	BOOL bDelete = FALSE;
		err = 0;
		offsetBeg = offset+numMismatch;
		if(offsetBeg > 0xffffffff)offsetBeg=0;//disk almashadur;
		header = unzmem;//fread(header, 1, 30, unzf) == 30)
		offset += 30;
		unzmem += 30;
		
		/* File entry */
		if(READ_32(header) == 0x04034b50)
		{	unsigned int version = READ_16(header + 4);
			unsigned int gpflag = READ_16(header + 6);
			unsigned int method = READ_16(header + 8);
			unsigned int filetime = READ_16(header + 10);
			unsigned int filedate = READ_16(header + 12);
			unsigned int crc = READ_32(header + 14); /* crc */
			unsigned int cpsize = READ_32(header + 18); /* compressed size */
			unsigned int uncpsize = READ_32(header + 22); /* uncompressed sz */
			unsigned int fnsize = READ_16(header + 26); /* file name length */
			unsigned int extsize = READ_16(header + 28); /* extra field length */
			unsigned int fnsizeOld = fnsize;

			/* Close file in zip, fill for central directory entry */
			char cibuf[46];char *pcibuf=cibuf;int r;
			unsigned int	version1,
							version2,
							gpflag1,
							method1,
							filetime1,
							filedate1,
							crc1,
							cpsize1,
							uncpsize1,
							fnsize1,
							extsize1,
							comntsize,
							//diskNumb,
							intAttrb,
							extAttrb;//,
							//crntOffst1;

			filename[0] = extra[0] = '\0';

			/* Filename */
			if(fnsize > 0)
			{	if(fnsize < sizeof(filename))
				{	unsigned int i;
					for(i=0; i<fnsize; i++)
						filename[i] = unzmem[i];//fread(filename, 1, fnsize, unzf) == fnsize)
					unzmem+=fnsize;
					offset += fnsize;
					filename[fnsize]=0;
					if(zstrstr_slash(filename,fName))//if(0==strcmp(filename,fName))
					{	bDelete = TRUE;
						/*char *p,tail[MAX_PATH];MyStringCpy(tail,MAX_PATH,&filename[fNameLn]);
						filename[fNameLn] = 0;
						p = zstrrchr2_excl_end(filename,'\\','/');
						if(p)
						{	BOOL bsl = ('\\'==(*p) || '/'==(*p)) ? TRUE : FALSE;
							fnsize = MyStringCpy(bsl ? p+1 : p,1023,fNewName);
							if(p!=&filename[0])
								fnsize += 1+p-&filename[0];
						}
						else//Root dir b-sa, bez slash ham keladur;
							fnsize = MyStringCpy(filename,1023,fNewName);
						fnsize += MyStringCpy(&filename[fnsize],1023-fnsize,tail);
						WRITE_16(header+26,fnsize);
						numMismatch += fnsize-fnsizeOld;*/
					}
					// Header
					if(!bDelete)
					if(!WriteToZipFileHandle(plg->zf,header,30)==30)
					{	err = Z_ERRNO;
						break;
					}

					// Filename
					if(!bDelete)
					if(!WriteToZipFileHandle(plg->zf,filename,fnsize)==fnsize)
					{	err = Z_ERRNO;
						break;
				}	}
				else
				{	err = Z_ERRNO;
					break;
			}	}
			else
			{	err = Z_STREAM_ERROR;
				break;
			}

			/* Extra field */
			if(!bDelete)
			{	if(extsize > 0)
				{	if(extsize < sizeof(extra))
					{	if(WriteToZipFileHandle(plg->zf,unzmem,extsize)==extsize)
						{	unzmem+=extsize;
							offset += extsize;
						}
						else
						{	err = Z_ERRNO;
							break;
					}   }
					else
					{	err = Z_ERRNO;
						break;
			}	}	}
			else if(extsize > 0 && extsize < sizeof(extra))
			{	unzmem+=extsize;
				offset += extsize;
			}
		
			/* Data */
			if(!bDelete)
			{	int dataSize = cpsize;
				if(dataSize == 0)
					dataSize = uncpsize;
				if(dataSize > 0)
				{	if(WriteToZipFileHandle(plg->zf,unzmem,dataSize)==dataSize)
					{	unzmem+=dataSize;
						offset += dataSize;
					}
					else
						err = Z_ERRNO;
					if(err != Z_OK)
						break;
			}   }
			else
			{	int dataSize = cpsize;
				if(dataSize == 0)
					dataSize = uncpsize;
				unzmem+=dataSize;
				offset += dataSize;
			}

			r=GetNodeInfoFromCentralHeaderMem(plg->heapAndMapBuf,cibuf,&filePosInCentralDir,&offset);
			if(r<0){err = Z_MEM_ERROR;break;}
			//else:
			filePosInCentralDir+=r;
			if(!bDelete)
			{
			version1 = READ_16(pcibuf + 4);
			version2 = READ_16(pcibuf + 6);
			gpflag1 = READ_16(pcibuf + 8);
			method1 = READ_16(pcibuf + 10);
			filetime1 = READ_16(pcibuf + 12);
			filedate1 = READ_16(pcibuf + 14);
			crc1 = READ_32(pcibuf + 16); /* crc */
			cpsize1 = READ_32(pcibuf + 20); /* compressed size */
			uncpsize1 = READ_32(pcibuf + 24); /* uncompressed sz */
			fnsize1 = READ_16(pcibuf + 28); /* file name length */
			extsize1 = READ_16(pcibuf + 30); /* extra field length */
			comntsize = READ_16(pcibuf + 32); /* comment filed length */
			//diskNumb = READ_16(pcibuf + 34); /* disk # */
			intAttrb = READ_16(pcibuf + 36); /* int attrb */
			extAttrb = READ_32(pcibuf + 38); /* ext attrb */
			//crntOffst1 = READ_32(pcibuf + 42); /* crnt offset */
			if(gpflag1 != gpflag)
				{err = Z_MEM_ERROR;break;}
			if(method1 != method)
				{err = Z_MEM_ERROR;break;}
			if(filetime1 != filetime)
				{err = Z_MEM_ERROR;break;}
			if(filedate1 != filedate)
				{err = Z_MEM_ERROR;break;}
			if(crc1 != crc)
				{err = Z_MEM_ERROR;break;}
			if(cpsize1 != cpsize)
				{err = Z_MEM_ERROR;break;}
			if(uncpsize1 != uncpsize)
				{err = Z_MEM_ERROR;break;}
			if(fnsize1 != fnsizeOld)
				{err = Z_MEM_ERROR;break;}
			if(extsize1 != extsize)
				{err = Z_MEM_ERROR;break;}
			r=AddEndFileEntryForAppendingFromZip(plg->zf,version1,version2,gpflag,method,
						uncpsize,cpsize,filedate,filetime,crc,fnsize,filename,extsize,extra,
						intAttrb,extAttrb,(uLong*)&offsetBeg);
			if(r < 0)
			{	err = Z_MEM_ERROR;
				break;
			}
			}
			/* Success */
			entries++;
		}
		else
			break;
	}

	return err==0?TRUE:FALSE;
}

extern unzFile myUnzOnlyOpenInternal(const void*,ZPOS64_T*);
extern int GetNodeInfoFromCentralHeader(unzFile*,char*,ZPOS64_T*,ZPOS64_T*);
BOOL RebuildCheckExistings$8(PluginObj *plg,wchar_t *passwordW)
{
#define READ_8(adr)  ((unsigned char)*(adr))
#define READ_16(adr) ( READ_8(adr) | (READ_8(adr+1) << 8) )
#define READ_32(adr) ( READ_16(adr) | (READ_16((adr)+2) << 16) )

#define WRITE_8(buff, n) do { \
  *((unsigned char*)(buff)) = (unsigned char) ((n) & 0xff); \
} while(0)
#define WRITE_16(buff, n) do { \
  WRITE_8((unsigned char*)(buff), n); \
  WRITE_8(((unsigned char*)(buff)) + 1, (n) >> 8); \
} while(0)
#define WRITE_32(buff, n) do { \
  WRITE_16((unsigned char*)(buff), (n) & 0xffff); \
  WRITE_16((unsigned char*)(buff) + 2, (n) >> 16); \
} while(0)

int err;
//char *changeSlash;
int iExstInSeltns;
int chckFilesToExisting=showEach;

int entries = 0;
char header[30];
char filename[1024];
char password[MAX_PATH];
char extra[1024];
unzFile unzf;//FILE *unzf
ZPOS64_T filePosInCentralDir,offsetBeg,offset=0;
unsigned int offsetInCentralDir=0;

	WideCharToMultiByte(CP_OEMCP,0,passwordW,-1,password,MAX_PATH,NULL,NULL);

	if(disk!=plg->packType)
		return RebuildCheckExistingUseMem(plg,password);

	unzf = myUnzOnlyOpenInternal(plg->zpFileName,&filePosInCentralDir);//unzf=fopen(plg->zpFileName,"rb");
	if(!unzf)
    {	msgWA(0,strngs[64],(LPTSTR)plg->zpFileName);//"error opening"
		return FALSE;
	}

	plg->fstFilePos = unzGetFirstFileOffset(unzf);
	if(plg->bSFX)
	if(0==plg->fstFilePos)
		plg->bSFX = FALSE;
	if(plg->bSFX)
	{	void *sfxHeader=malloc((size_t)plg->fstFilePos);
		if(ReadFromUnzipFileHandle(unzf,sfxHeader,(int)plg->fstFilePos)!=plg->fstFilePos)
		{	
ErrSfxHeader:
			err = Z_ERRNO;
			free(sfxHeader);
			return FALSE;
		}
		if(WriteToZipFileHandle(plg->zf,sfxHeader,(int)plg->fstFilePos)!=plg->fstFilePos)
			goto ErrSfxHeader;
		free(sfxHeader);
		offset = plg->fstFilePos;
	}

	while(ReadFromUnzipFileHandle(unzf,header,30) == 30)//fread(header, 1, 30, unzf) == 30)
	{	err = 0;
		offsetBeg = offset;
		if(offsetBeg > 0xffffffff)offsetBeg=0;//disk almashadur;
		offset += 30;
		/* File entry */
		if(READ_32(header) == 0x04034b50)
		{	unsigned int version = READ_16(header + 4);
			unsigned int gpflag = READ_16(header + 6);
			unsigned int method = READ_16(header + 8);
			unsigned int filetime = READ_16(header + 10);
			unsigned int filedate = READ_16(header + 12);
			unsigned int crc = READ_32(header + 14); /* crc */
			unsigned int cpsize = READ_32(header + 18); /* compressed size */
			unsigned int uncpsize = READ_32(header + 22); /* uncompressed sz */
			unsigned int fnsize = READ_16(header + 26); /* file name length */
			unsigned int extsize = READ_16(header + 28); /* extra field length */
			BOOL bUpdateFrUnzip=FALSE;
			filename[0] = extra[0] = '\0';

			/* Filename */
			if(fnsize > 0)
			{	if(fnsize < sizeof(filename))
				{	if(ReadFromUnzipFileHandle(unzf,filename,fnsize) == fnsize)//fread(filename, 1, fnsize, unzf) == fnsize)
					{	offset += fnsize;
						filename[fnsize]=0;						
						bUpdateFrUnzip=CheckUnzFileForUpdating(plg,filename,
													&chckFilesToExisting,
													&iExstInSeltns,
													cpsize,uncpsize,
													filedate,filetime);
						if(bUpdateFrUnzip)
						{	// Header
						    if(!WriteToZipFileHandle(plg->zf,header,30)==30)
							{	err = Z_ERRNO;
								break;
							}

							// Filename
							if(!WriteToZipFileHandle(plg->zf,filename,fnsize)==fnsize)
							{	err = Z_ERRNO;
								break;
							}
							excldFileFrSelctn(plg->host,iExstInSeltns,entries);
					}	}
					else
					{	err = Z_ERRNO;
						break;
				}	}
				else
				{	err = Z_ERRNO;
					break;
			}	}
			else
			{	err = Z_STREAM_ERROR;
				break;
			}

			/* Extra field */
			if(extsize > 0)
			{	if(extsize < sizeof(extra))
				{	if(ReadFromUnzipFileHandle(unzf,extra,extsize) == extsize)//fread(extra, 1, extsize, unzf) == extsize)
					{	offset += extsize;
						if(bUpdateFrUnzip)
						{	if(!WriteToZipFileHandle(plg->zf,extra,extsize)==extsize)
							{	err = Z_ERRNO;
								break;
					}	}	}
					else
					{	err = Z_ERRNO;
						break;
				}   }
				else
				{	err = Z_ERRNO;
					break;
			}	}
		
			/* Data */
			{	int dataSize = cpsize;
				if(dataSize == 0)
					dataSize = uncpsize;
				if(dataSize > 0)
				{	char* data = malloc(dataSize);
					if(data != NULL)
					{	if(ReadFromUnzipFileHandle(unzf,data,dataSize) == dataSize)//fread(data, 1, dataSize, unzf) == dataSize)
						{	offset += dataSize;
							if(bUpdateFrUnzip)
							{	if(!WriteToZipFileHandle(plg->zf,data,dataSize)==dataSize)
									err = Z_ERRNO;
						}	}
						else
							err = Z_ERRNO;
						free(data);
						if(err != Z_OK)
							break;
					}
					else
					{	err = Z_MEM_ERROR;
						break;
			}   }	}

			/* Close file in zip, fill for central directory entry */
			if(bUpdateFrUnzip)
			{	char cibuf[46];char *pcibuf=cibuf;
				unsigned int	version1,
								version2,
								gpflag1,
								method1,
								filetime1,
								filedate1,
								crc1,
								cpsize1,
								uncpsize1,
								fnsize1,
								extsize1,
								comntsize,
								//diskNumb,
								intAttrb,
								extAttrb;//,
								//crntOffst1;
				int r=GetNodeInfoFromCentralHeader(unzf,cibuf,&filePosInCentralDir,&offset);
				if(r<0){err = Z_MEM_ERROR;break;}
				//else:
				filePosInCentralDir+=r;
				version1 = READ_16(pcibuf + 4);
				version2 = READ_16(pcibuf + 6);
				gpflag1 = READ_16(pcibuf + 8);
				method1 = READ_16(pcibuf + 10);
				filetime1 = READ_16(pcibuf + 12);
				filedate1 = READ_16(pcibuf + 14);
				crc1 = READ_32(pcibuf + 16); /* crc */
				cpsize1 = READ_32(pcibuf + 20); /* compressed size */
				uncpsize1 = READ_32(pcibuf + 24); /* uncompressed sz */
				fnsize1 = READ_16(pcibuf + 28); /* file name length */
				extsize1 = READ_16(pcibuf + 30); /* extra field length */
				comntsize = READ_16(pcibuf + 32); /* comment filed length */
				//diskNumb = READ_16(pcibuf + 34); /* disk # */
				intAttrb = READ_16(pcibuf + 36); /* int attrb */
				extAttrb = READ_32(pcibuf + 38); /* ext attrb */
				//crntOffst1 = READ_32(pcibuf + 42); /* crnt offset */
				if(gpflag1 != gpflag)
					{err = Z_MEM_ERROR;break;}
				if(method1 != method)
					{err = Z_MEM_ERROR;break;}
				if(filetime1 != filetime)
					{err = Z_MEM_ERROR;break;}
				if(filedate1 != filedate)
					{err = Z_MEM_ERROR;break;}
				if(crc1 != crc)
					{err = Z_MEM_ERROR;break;}
				if(cpsize1 != cpsize)
					{err = Z_MEM_ERROR;break;}
				if(uncpsize1 != uncpsize)
					{err = Z_MEM_ERROR;break;}
				if(fnsize1 != fnsize)
					{err = Z_MEM_ERROR;break;}
				if(extsize1 != extsize)
					{err = Z_MEM_ERROR;break;}
				r=AddEndFileEntryForAppendingFromZip(plg->zf,version1,version2,gpflag,method,
							uncpsize,cpsize,filedate,filetime,crc,fnsize,filename,extsize,extra,
							intAttrb,extAttrb,(uLong*)&offsetBeg);
				if(r < 0)
				{	err = Z_MEM_ERROR;
					break;
			}	}
			/* Success */
			entries++;
		}
		else
			break;
	}

	/* Close */
	unzClose(unzf);//fclose(unzf);
	return err==0?TRUE:FALSE;
}

BOOL RenameFile$12(PluginObj *plg,wchar_t *FNameW,wchar_t *FNewNameW)
{
#define READ_8(adr)  ((unsigned char)*(adr))
#define READ_16(adr) ( READ_8(adr) | (READ_8(adr+1) << 8) )
#define READ_32(adr) ( READ_16(adr) | (READ_16((adr)+2) << 16) )

#define WRITE_8(buff, n) do { \
  *((unsigned char*)(buff)) = (unsigned char) ((n) & 0xff); \
} while(0)
#define WRITE_16(buff, n) do { \
  WRITE_8((unsigned char*)(buff), n); \
  WRITE_8(((unsigned char*)(buff)) + 1, (n) >> 8); \
} while(0)
#define WRITE_32(buff, n) do { \
  WRITE_16((unsigned char*)(buff), (n) & 0xffff); \
  WRITE_16((unsigned char*)(buff) + 2, (n) >> 16); \
} while(0)

int err;

int entries = 0;
char header[30];
char filename[1024];
char fName[MAX_PATH];
char fNewName[MAX_PATH];
char extra[1024];
unzFile unzf;//FILE *unzf
ZPOS64_T filePosInCentralDir,offsetBeg,offset=0,numMismatch=0;
unsigned int offsetInCentralDir=0;

	WideCharToMultiByte(CP_OEMCP,0,FNameW,-1,fName,MAX_PATH-1,NULL,NULL);
	WideCharToMultiByte(CP_OEMCP,0,FNewNameW,-1,fNewName,MAX_PATH-1,NULL,NULL);

	if(disk!=plg->packType)
		return RenameFileUseMem(plg,fName,fNewName);

	unzf = myUnzOnlyOpenInternal(plg->zpFileName,&filePosInCentralDir);//unzf=fopen(plg->zpFileName,"rb");
	if(!unzf)
    {	msgWA(0,strngs[64],(LPTSTR)plg->zpFileName);//"error opening"
		return FALSE;
	}

	plg->fstFilePos = unzGetFirstFileOffset(unzf);
	if(plg->bSFX)
	if(0==plg->fstFilePos)
		plg->bSFX = FALSE;
	if(plg->bSFX)
	{	void *sfxHeader=malloc((size_t)plg->fstFilePos);
		if(ReadFromUnzipFileHandle(unzf,sfxHeader,(int)plg->fstFilePos)!=plg->fstFilePos)
		{	
ErrSfxHeader:
			err = Z_ERRNO;
			free(sfxHeader);
			return FALSE;
		}
		if(WriteToZipFileHandle(plg->zf,sfxHeader,(int)plg->fstFilePos)!=plg->fstFilePos)
			goto ErrSfxHeader;
		free(sfxHeader);
		offset = plg->fstFilePos;
	}

	while(ReadFromUnzipFileHandle(unzf,header,30) == 30)//fread(header, 1, 30, unzf) == 30)
	{	err = 0;
		offsetBeg = offset+numMismatch;
		if(offsetBeg > 0xffffffff)offsetBeg=0;//disk almashadur;
		offset += 30;
		/* File entry */
		if(READ_32(header) == 0x04034b50)
		{	unsigned int version = READ_16(header + 4);
			unsigned int gpflag = READ_16(header + 6);
			unsigned int method = READ_16(header + 8);
			unsigned int filetime = READ_16(header + 10);
			unsigned int filedate = READ_16(header + 12);
			unsigned int crc = READ_32(header + 14); /* crc */
			unsigned int cpsize = READ_32(header + 18); /* compressed size */
			unsigned int uncpsize = READ_32(header + 22); /* uncompressed sz */
			unsigned int fnsize = READ_16(header + 26); /* file name length */
			unsigned int extsize = READ_16(header + 28); /* extra field length */
			unsigned int fnsizeOld = fnsize;

			/* Close file in zip, fill for central directory entry */
			char cibuf[46];char *pcibuf=cibuf;int r;
			unsigned int	version1,
							version2,
							gpflag1,
							method1,
							filetime1,
							filedate1,
							crc1,
							cpsize1,
							uncpsize1,
							fnsize1,
							extsize1,
							comntsize,
							//diskNumb,
							intAttrb,
							extAttrb;//,
							//crntOffst1;


			filename[0] = extra[0] = '\0';

			/* Filename */
			if(fnsize > 0)
			{	if(fnsize < sizeof(filename))
				{	if(ReadFromUnzipFileHandle(unzf,filename,fnsize) == fnsize)//fread(filename, 1, fnsize, unzf) == fnsize)
					{	offset += fnsize;
						filename[fnsize]=0;	
						if(zstrstr_slash(filename,fName))//if(0==strcmp(filename,fName))
						{	char *p = zstrrchr2_excl_end(filename,'\\','/');
						    if(p)
							{	BOOL bsl = ('\\'==(*p) || '/'==(*p)) ? TRUE : FALSE;
							    fnsize = MyStringCpy(bsl ? p+1 : p,1023,fNewName);
								if(p!=&filename[0])
									fnsize += (int)(1+p-&filename[0]);
							}
							else//Root dir b-sa, bez slash ham keladur;
								fnsize = MyStringCpy(filename,1023,fNewName);
							WRITE_16(header+26,fnsize);
							numMismatch += fnsize-fnsizeOld;
						}
						// Header
						if(!WriteToZipFileHandle(plg->zf,header,30)==30)
						{	err = Z_ERRNO;
							break;
						}

						// Filename
						if(!WriteToZipFileHandle(plg->zf,filename,fnsize)==fnsize)
						{	err = Z_ERRNO;
							break;
					}	}
					else
					{	err = Z_ERRNO;
						break;
				}	}
				else
				{	err = Z_ERRNO;
					break;
			}	}
			else
			{	err = Z_STREAM_ERROR;
				break;
			}

			/* Extra field */
			if(extsize > 0)
			{	if(extsize < sizeof(extra))
				{	if(ReadFromUnzipFileHandle(unzf,extra,extsize) == extsize)//fread(extra, 1, extsize, unzf) == extsize)
					{	offset += extsize;
						if(!WriteToZipFileHandle(plg->zf,extra,extsize)==extsize)
						{	err = Z_ERRNO;
							break;
					}	}
					else
					{	err = Z_ERRNO;
						break;
				}   }
				else
				{	err = Z_ERRNO;
					break;
			}	}
		
			/* Data */
			{	int dataSize = cpsize;
				if(dataSize == 0)
					dataSize = uncpsize;
				if(dataSize > 0)
				{	char* data = malloc(dataSize);
					if(data != NULL)
					{	if(ReadFromUnzipFileHandle(unzf,data,dataSize) == dataSize)//fread(data, 1, dataSize, unzf) == dataSize)
						{	offset += dataSize;
							if(!WriteToZipFileHandle(plg->zf,data,dataSize)==dataSize)
								err = Z_ERRNO;
						}
						else
							err = Z_ERRNO;
						free(data);
						if(err != Z_OK)
							break;
					}
					else
					{	err = Z_MEM_ERROR;
						break;
			}   }	}

			r=GetNodeInfoFromCentralHeader(unzf,cibuf,&filePosInCentralDir,&offset);
			if(r<0){err = Z_MEM_ERROR;break;}
			//else:
			filePosInCentralDir+=r;
			version1 = READ_16(pcibuf + 4);
			version2 = READ_16(pcibuf + 6);
			gpflag1 = READ_16(pcibuf + 8);
			method1 = READ_16(pcibuf + 10);
			filetime1 = READ_16(pcibuf + 12);
			filedate1 = READ_16(pcibuf + 14);
			crc1 = READ_32(pcibuf + 16); /* crc */
			cpsize1 = READ_32(pcibuf + 20); /* compressed size */
			uncpsize1 = READ_32(pcibuf + 24); /* uncompressed sz */
			fnsize1 = READ_16(pcibuf + 28); /* file name length */
			extsize1 = READ_16(pcibuf + 30); /* extra field length */
			comntsize = READ_16(pcibuf + 32); /* comment filed length */
			//diskNumb = READ_16(pcibuf + 34); /* disk # */
			intAttrb = READ_16(pcibuf + 36); /* int attrb */
			extAttrb = READ_32(pcibuf + 38); /* ext attrb */
			//crntOffst1 = READ_32(pcibuf + 42); /* crnt offset */
			if(gpflag1 != gpflag)
				{err = Z_MEM_ERROR;break;}
			if(method1 != method)
				{err = Z_MEM_ERROR;break;}
			if(filetime1 != filetime)
				{err = Z_MEM_ERROR;break;}
			if(filedate1 != filedate)
				{err = Z_MEM_ERROR;break;}
			if(crc1 != crc)
				{err = Z_MEM_ERROR;break;}
			if(cpsize1 != cpsize)
				{err = Z_MEM_ERROR;break;}
			if(uncpsize1 != uncpsize)
				{err = Z_MEM_ERROR;break;}
			if(fnsize1 != fnsizeOld)
				{err = Z_MEM_ERROR;break;}
			if(extsize1 != extsize)
				{err = Z_MEM_ERROR;break;}
			r=AddEndFileEntryForAppendingFromZip(plg->zf,version1,version2,gpflag,method,
						uncpsize,cpsize,filedate,filetime,crc,fnsize,filename,extsize,extra,
						intAttrb,extAttrb,(uLong*)&offsetBeg);
			if(r < 0)
			{	err = Z_MEM_ERROR;
				break;
			}
			/* Success */
			entries++;
		}
		else
			break;
	}

	/* Close */
	unzClose(unzf);//fclose(unzf);
	return err==0?TRUE:FALSE;
}

BOOL RenameDir$12(PluginObj *plg,wchar_t *FNameW,wchar_t *FNewNameW)
{
#define READ_8(adr)  ((unsigned char)*(adr))
#define READ_16(adr) ( READ_8(adr) | (READ_8(adr+1) << 8) )
#define READ_32(adr) ( READ_16(adr) | (READ_16((adr)+2) << 16) )

#define WRITE_8(buff, n) do { \
  *((unsigned char*)(buff)) = (unsigned char) ((n) & 0xff); \
} while(0)
#define WRITE_16(buff, n) do { \
  WRITE_8((unsigned char*)(buff), n); \
  WRITE_8(((unsigned char*)(buff)) + 1, (n) >> 8); \
} while(0)
#define WRITE_32(buff, n) do { \
  WRITE_16((unsigned char*)(buff), (n) & 0xffff); \
  WRITE_16((unsigned char*)(buff) + 2, (n) >> 16); \
} while(0)

int err,fNameLn,entries = 0;
char header[30];
char filename[1024];
char fName[MAX_PATH];
char fNewName[MAX_PATH];
char extra[1024];
unzFile unzf;//FILE *unzf
ZPOS64_T filePosInCentralDir,offsetBeg,offset=0,numMismatch=0;
unsigned int offsetInCentralDir=0;

	fNameLn = WideCharToMultiByte(CP_OEMCP,0,FNameW,-1,fName,MAX_PATH-1,NULL,NULL)-1;
	WideCharToMultiByte(CP_OEMCP,0,FNewNameW,-1,fNewName,MAX_PATH-1,NULL,NULL);

	if(disk!=plg->packType)
		return RenameDirUseMem(plg,fName,fNewName);

	unzf = myUnzOnlyOpenInternal(plg->zpFileName,&filePosInCentralDir);//unzf=fopen(plg->zpFileName,"rb");
	if(!unzf)
    {	msgWA(0,strngs[64],(LPTSTR)plg->zpFileName);//"error opening"
		return FALSE;
	}

	plg->fstFilePos = unzGetFirstFileOffset(unzf);
	if(plg->bSFX)
	if(0==plg->fstFilePos)
		plg->bSFX = FALSE;
	if(plg->bSFX)
	{	void *sfxHeader=malloc((size_t)plg->fstFilePos);
		if(ReadFromUnzipFileHandle(unzf,sfxHeader,(int)plg->fstFilePos)!=plg->fstFilePos)
		{	
ErrSfxHeader:
			err = Z_ERRNO;
			free(sfxHeader);
			return FALSE;
		}
		if(WriteToZipFileHandle(plg->zf,sfxHeader,(int)plg->fstFilePos)!=plg->fstFilePos)
			goto ErrSfxHeader;
		free(sfxHeader);
		offset = plg->fstFilePos;
	}

	while(ReadFromUnzipFileHandle(unzf,header,30) == 30)//fread(header, 1, 30, unzf) == 30)
	{	err = 0;
		offsetBeg = offset+numMismatch;
		if(offsetBeg > 0xffffffff)offsetBeg=0;//disk almashadur;
		offset += 30;
		/* File entry */
		if(READ_32(header) == 0x04034b50)
		{	unsigned int version = READ_16(header + 4);
			unsigned int gpflag = READ_16(header + 6);
			unsigned int method = READ_16(header + 8);
			unsigned int filetime = READ_16(header + 10);
			unsigned int filedate = READ_16(header + 12);
			unsigned int crc = READ_32(header + 14); /* crc */
			unsigned int cpsize = READ_32(header + 18); /* compressed size */
			unsigned int uncpsize = READ_32(header + 22); /* uncompressed sz */
			unsigned int fnsize = READ_16(header + 26); /* file name length */
			unsigned int extsize = READ_16(header + 28); /* extra field length */
			unsigned int fnsizeOld = fnsize;

			/* Close file in zip, fill for central directory entry */
			char cibuf[46];char *pcibuf=cibuf;int r;
			unsigned int	version1,
							version2,
							gpflag1,
							method1,
							filetime1,
							filedate1,
							crc1,
							cpsize1,
							uncpsize1,
							fnsize1,
							extsize1,
							comntsize,
							//diskNumb,
							intAttrb,
							extAttrb;//,
							//crntOffst1;


			filename[0] = extra[0] = '\0';

			/* Filename */
			if(fnsize > 0)
			{	if(fnsize < sizeof(filename))
				{	if(ReadFromUnzipFileHandle(unzf,filename,fnsize) == fnsize)//fread(filename, 1, fnsize, unzf) == fnsize)
					{	offset += fnsize;
						filename[fnsize]=0;	
						if(zstrstr_slash(filename,fName))//if(0==strcmp(filename,fName))
						{	char *p,tail[MAX_PATH];MyStringCpy(tail,MAX_PATH,&filename[fNameLn]);
							filename[fNameLn] = 0;
							p = zstrrchr2_excl_end(filename,'\\','/');
							if(p)
						    {	BOOL bsl = ('\\'==(*p) || '/'==(*p)) ? TRUE : FALSE;
							    fnsize = MyStringCpy(bsl ? p+1 : p,1023,fNewName);
								if(p!=&filename[0])
									fnsize += (int)(1+p-&filename[0]);
							}
							else//Root dir b-sa, bez slash ham keladur;
								fnsize = MyStringCpy(filename,1023,fNewName);
							fnsize += MyStringCpy(&filename[fnsize],1023-fnsize,tail);
							WRITE_16(header+26,fnsize);
							numMismatch += fnsize-fnsizeOld;
						}
						// Header
						if(!WriteToZipFileHandle(plg->zf,header,30)==30)
						{	err = Z_ERRNO;
							break;
						}

						// Filename
						if(!WriteToZipFileHandle(plg->zf,filename,fnsize)==fnsize)
						{	err = Z_ERRNO;
							break;
					}	}
					else
					{	err = Z_ERRNO;
						break;
				}	}
				else
				{	err = Z_ERRNO;
					break;
			}	}
			else
			{	err = Z_STREAM_ERROR;
				break;
			}

			/* Extra field */
			if(extsize > 0)
			{	if(extsize < sizeof(extra))
				{	if(ReadFromUnzipFileHandle(unzf,extra,extsize) == extsize)//fread(extra, 1, extsize, unzf) == extsize)
					{	offset += extsize;
						if(!WriteToZipFileHandle(plg->zf,extra,extsize)==extsize)
						{	err = Z_ERRNO;
							break;
					}	}
					else
					{	err = Z_ERRNO;
						break;
				}   }
				else
				{	err = Z_ERRNO;
					break;
			}	}
		
			/* Data */
			{	int dataSize = cpsize;
				if(dataSize == 0)
					dataSize = uncpsize;
				if(dataSize > 0)
				{	char* data = malloc(dataSize);
					if(data != NULL)
					{	if(ReadFromUnzipFileHandle(unzf,data,dataSize) == dataSize)//fread(data, 1, dataSize, unzf) == dataSize)
						{	offset += dataSize;
							if(!WriteToZipFileHandle(plg->zf,data,dataSize)==dataSize)
								err = Z_ERRNO;
						}
						else
							err = Z_ERRNO;
						free(data);
						if(err != Z_OK)
							break;
					}
					else
					{	err = Z_MEM_ERROR;
						break;
			}   }	}

			r=GetNodeInfoFromCentralHeader(unzf,cibuf,&filePosInCentralDir,&offset);
			if(r<0){err = Z_MEM_ERROR;break;}
			//else:
			filePosInCentralDir+=r;
			version1 = READ_16(pcibuf + 4);
			version2 = READ_16(pcibuf + 6);
			gpflag1 = READ_16(pcibuf + 8);
			method1 = READ_16(pcibuf + 10);
			filetime1 = READ_16(pcibuf + 12);
			filedate1 = READ_16(pcibuf + 14);
			crc1 = READ_32(pcibuf + 16); /* crc */
			cpsize1 = READ_32(pcibuf + 20); /* compressed size */
			uncpsize1 = READ_32(pcibuf + 24); /* uncompressed sz */
			fnsize1 = READ_16(pcibuf + 28); /* file name length */
			extsize1 = READ_16(pcibuf + 30); /* extra field length */
			comntsize = READ_16(pcibuf + 32); /* comment filed length */
			//diskNumb = READ_16(pcibuf + 34); /* disk # */
			intAttrb = READ_16(pcibuf + 36); /* int attrb */
			extAttrb = READ_32(pcibuf + 38); /* ext attrb */
			//crntOffst1 = READ_32(pcibuf + 42); /* crnt offset */
			if(gpflag1 != gpflag)
				{err = Z_MEM_ERROR;break;}
			if(method1 != method)
				{err = Z_MEM_ERROR;break;}
			if(filetime1 != filetime)
				{err = Z_MEM_ERROR;break;}
			if(filedate1 != filedate)
				{err = Z_MEM_ERROR;break;}
			if(crc1 != crc)
				{err = Z_MEM_ERROR;break;}
			if(cpsize1 != cpsize)
				{err = Z_MEM_ERROR;break;}
			if(uncpsize1 != uncpsize)
				{err = Z_MEM_ERROR;break;}
			if(fnsize1 != fnsizeOld)
				{err = Z_MEM_ERROR;break;}
			if(extsize1 != extsize)
				{err = Z_MEM_ERROR;break;}
			r=AddEndFileEntryForAppendingFromZip(plg->zf,version1,version2,gpflag,method,
						uncpsize,cpsize,filedate,filetime,crc,fnsize,filename,extsize,extra,
						intAttrb,extAttrb,(uLong*)&offsetBeg);
			if(r < 0)
			{	err = Z_MEM_ERROR;
				break;
			}
			/* Success */
			entries++;
		}
		else
			break;
	}

	/* Close */
	unzClose(unzf);//fclose(unzf);
	return err==0?TRUE:FALSE;
}

BOOL DeleteFile$8(PluginObj *plg,wchar_t *FNameW)
{
#define READ_8(adr)  ((unsigned char)*(adr))
#define READ_16(adr) ( READ_8(adr) | (READ_8(adr+1) << 8) )
#define READ_32(adr) ( READ_16(adr) | (READ_16((adr)+2) << 16) )

#define WRITE_8(buff, n) do { \
  *((unsigned char*)(buff)) = (unsigned char) ((n) & 0xff); \
} while(0)
#define WRITE_16(buff, n) do { \
  WRITE_8((unsigned char*)(buff), n); \
  WRITE_8(((unsigned char*)(buff)) + 1, (n) >> 8); \
} while(0)
#define WRITE_32(buff, n) do { \
  WRITE_16((unsigned char*)(buff), (n) & 0xffff); \
  WRITE_16((unsigned char*)(buff) + 2, (n) >> 16); \
} while(0)

int err;

int entries = 0;
char header[30];
char filename[1024];
//wchar_t ws[MAX_PATH];
char fName[MAX_PATH];
char extra[1024];
unzFile unzf;//FILE *unzf
ZPOS64_T filePosInCentralDir,offsetBeg,offset=0,numMismatch=0;
unsigned int offsetInCentralDir=0;

char FName[MAX_PATH];
	
	WideCharToMultiByte(CP_OEMCP,0,FNameW,-1,FName,MAX_PATH,NULL,NULL);


	//if(plg->bAnsi)
	//{	MultiByteToWideChar(CP_ACP,MB_PRECOMPOSED,FName,MAX_PATH-1,ws,MAX_PATH);
	//	WideCharToMultiByte(CP_OEMCP,0,ws,-1,fName,MAX_PATH-1,NULL,NULL);
	//} else 
	MyStringCpy(fName,MAX_PATH,FName);

	if(disk!=plg->packType)
		return DeleteFileUseMem(plg,fName);

	unzf = myUnzOnlyOpenInternal(plg->zpFileName,&filePosInCentralDir);//unzf=fopen(plg->zpFileName,"rb");
	if(!unzf)
    {	msgWA(0,strngs[64],(LPTSTR)plg->zpFileName);//"error opening"
		return FALSE;
	}

	plg->fstFilePos = unzGetFirstFileOffset(unzf);
	if(plg->bSFX)
	if(0==plg->fstFilePos)
		plg->bSFX = FALSE;
	if(plg->bSFX)
	{	void *sfxHeader=malloc((size_t)plg->fstFilePos);
		if(ReadFromUnzipFileHandle(unzf,sfxHeader,(int)plg->fstFilePos)!=plg->fstFilePos)
		{	
ErrSfxHeader:
			err = Z_ERRNO;
			free(sfxHeader);
			return FALSE;
		}
		if(WriteToZipFileHandle(plg->zf,sfxHeader,(int)plg->fstFilePos)!=plg->fstFilePos)
			goto ErrSfxHeader;
		free(sfxHeader);
		offset = plg->fstFilePos;
	}

	while(ReadFromUnzipFileHandle(unzf,header,30) == 30)//fread(header, 1, 30, unzf) == 30)
	{	BOOL bDelete = FALSE;
		err = 0;
		offsetBeg = offset+numMismatch;
		if(offsetBeg > 0xffffffff)offsetBeg=0;//disk almashadur;
		offset += 30;
		/* File entry */
		if(READ_32(header) == 0x04034b50)
		{	unsigned int version = READ_16(header + 4);
			unsigned int gpflag = READ_16(header + 6);
			unsigned int method = READ_16(header + 8);
			unsigned int filetime = READ_16(header + 10);
			unsigned int filedate = READ_16(header + 12);
			unsigned int crc = READ_32(header + 14); /* crc */
			unsigned int cpsize = READ_32(header + 18); /* compressed size */
			unsigned int uncpsize = READ_32(header + 22); /* uncompressed sz */
			unsigned int fnsize = READ_16(header + 26); /* file name length */
			unsigned int extsize = READ_16(header + 28); /* extra field length */
			unsigned int fnsizeOld = fnsize;

			/* Close file in zip, fill for central directory entry */
			char cibuf[46];char *pcibuf=cibuf;int r;
			unsigned int	version1,
							version2,
							gpflag1,
							method1,
							filetime1,
							filedate1,
							crc1,
							cpsize1,
							uncpsize1,
							fnsize1,
							extsize1,
							comntsize,
							//diskNumb,
							intAttrb,
							extAttrb;//,
							//crntOffst1;


			filename[0] = extra[0] = '\0';

			/* Filename */
			if(fnsize > 0)
			{	if(fnsize < sizeof(filename))
				{	if(ReadFromUnzipFileHandle(unzf,filename,fnsize) == fnsize)//fread(filename, 1, fnsize, unzf) == fnsize)
					{	offset += fnsize;
						filename[fnsize]=0;	
						if(zstrstr_slash(filename,fName))//if(0==strcmp(filename,fName))
						{	bDelete=TRUE;
							/*char *p = zstrrchr2_excl_end(filename,'\\','/');
						    if(p)
							{	BOOL bsl = ('\\'==(*p) || '/'==(*p)) ? TRUE : FALSE;
							    fnsize = MyStringCpy(bsl ? p+1 : p,1023,fNewName);
								if(p!=&filename[0])
									fnsize += 1+p-&filename[0];
							}
							else//Root dir b-sa, bez slash ham keladur;
								fnsize = MyStringCpy(filename,1023,fNewName);
							WRITE_16(header+26,fnsize);
							numMismatch += fnsize-fnsizeOld;*/
						}
						// Header
						if(!bDelete)
						if(!WriteToZipFileHandle(plg->zf,header,30)==30)
						{	err = Z_ERRNO;
							break;
						}

						// Filename
						if(!bDelete)
						if(!WriteToZipFileHandle(plg->zf,filename,fnsize)==fnsize)
						{	err = Z_ERRNO;
							break;
					}	}
					else
					{	err = Z_ERRNO;
						break;
				}	}
				else
				{	err = Z_ERRNO;
					break;
			}	}
			else
			{	err = Z_STREAM_ERROR;
				break;
			}

			/* Extra field */
			if(!bDelete)
			{	if(extsize > 0)
				{	if(extsize < sizeof(extra))
					{	if(ReadFromUnzipFileHandle(unzf,extra,extsize) == extsize)//fread(extra, 1, extsize, unzf) == extsize)
						{	offset += extsize;
							if(!WriteToZipFileHandle(plg->zf,extra,extsize)==extsize)
							{	err = Z_ERRNO;
								break;
						}	}
						else
						{	err = Z_ERRNO;
							break;
					}   }
					else
					{	err = Z_ERRNO;
						break;
			}	}	}
			else if(extsize > 0 && extsize < sizeof(extra))
			{	offset += extsize;
			}
		
			/* Data */
			if(!bDelete)
			{	int dataSize = cpsize;
				if(dataSize == 0)
					dataSize = uncpsize;
				if(dataSize > 0)
				{	char* data = malloc(dataSize);
					if(data != NULL)
					{	if(ReadFromUnzipFileHandle(unzf,data,dataSize) == dataSize)//fread(data, 1, dataSize, unzf) == dataSize)
						{	offset += dataSize;
							if(!WriteToZipFileHandle(plg->zf,data,dataSize)==dataSize)
								err = Z_ERRNO;
						}
						else
							err = Z_ERRNO;
						free(data);
						if(err != Z_OK)
							break;
					}
					else
					{	err = Z_MEM_ERROR;
						break;
			}   }	}
			else
			{	int dataSize = cpsize;
				if(dataSize == 0)
					dataSize = uncpsize;
				offset += dataSize;
			}

			r=GetNodeInfoFromCentralHeader(unzf,cibuf,&filePosInCentralDir,&offset);
			if(r<0){err = Z_MEM_ERROR;break;}
			//else:
			filePosInCentralDir+=r;
			if(!bDelete)
			{
			version1 = READ_16(pcibuf + 4);
			version2 = READ_16(pcibuf + 6);
			gpflag1 = READ_16(pcibuf + 8);
			method1 = READ_16(pcibuf + 10);
			filetime1 = READ_16(pcibuf + 12);
			filedate1 = READ_16(pcibuf + 14);
			crc1 = READ_32(pcibuf + 16); /* crc */
			cpsize1 = READ_32(pcibuf + 20); /* compressed size */
			uncpsize1 = READ_32(pcibuf + 24); /* uncompressed sz */
			fnsize1 = READ_16(pcibuf + 28); /* file name length */
			extsize1 = READ_16(pcibuf + 30); /* extra field length */
			comntsize = READ_16(pcibuf + 32); /* comment filed length */
			//diskNumb = READ_16(pcibuf + 34); /* disk # */
			intAttrb = READ_16(pcibuf + 36); /* int attrb */
			extAttrb = READ_32(pcibuf + 38); /* ext attrb */
			//crntOffst1 = READ_32(pcibuf + 42); /* crnt offset */
			if(gpflag1 != gpflag)
				{err = Z_MEM_ERROR;break;}
			if(method1 != method)
				{err = Z_MEM_ERROR;break;}
			if(filetime1 != filetime)
				{err = Z_MEM_ERROR;break;}
			if(filedate1 != filedate)
				{err = Z_MEM_ERROR;break;}
			if(crc1 != crc)
				{err = Z_MEM_ERROR;break;}
			if(cpsize1 != cpsize)
				{err = Z_MEM_ERROR;break;}
			if(uncpsize1 != uncpsize)
				{err = Z_MEM_ERROR;break;}
			if(fnsize1 != fnsizeOld)
				{err = Z_MEM_ERROR;break;}
			if(extsize1 != extsize)
				{err = Z_MEM_ERROR;break;}
			r=AddEndFileEntryForAppendingFromZip(plg->zf,version1,version2,gpflag,method,
						uncpsize,cpsize,filedate,filetime,crc,fnsize,filename,extsize,extra,
						intAttrb,extAttrb,(uLong*)&offsetBeg);
			if(r < 0)
			{	err = Z_MEM_ERROR;
				break;
			}
			}
			/* Success */
			entries++;
		}
		else
			break;
	}

	/* Close */
	unzClose(unzf);//fclose(unzf);
	return err==0?TRUE:FALSE;
}

BOOL DeleteDir$8(PluginObj *plg,wchar_t *FNameW)
{
#define READ_8(adr)  ((unsigned char)*(adr))
#define READ_16(adr) ( READ_8(adr) | (READ_8(adr+1) << 8) )
#define READ_32(adr) ( READ_16(adr) | (READ_16((adr)+2) << 16) )

#define WRITE_8(buff, n) do { \
  *((unsigned char*)(buff)) = (unsigned char) ((n) & 0xff); \
} while(0)
#define WRITE_16(buff, n) do { \
  WRITE_8((unsigned char*)(buff), n); \
  WRITE_8(((unsigned char*)(buff)) + 1, (n) >> 8); \
} while(0)
#define WRITE_32(buff, n) do { \
  WRITE_16((unsigned char*)(buff), (n) & 0xffff); \
  WRITE_16((unsigned char*)(buff) + 2, (n) >> 16); \
} while(0)

int err,fNameLn,entries = 0;
char header[30];
char filename[1024];
//wchar_t ws[MAX_PATH];
char fName[MAX_PATH];
char extra[1024];
unzFile unzf;//FILE *unzf
ZPOS64_T filePosInCentralDir,offsetBeg,offset=0,numMismatch=0;
unsigned int offsetInCentralDir=0;
char FName[MAX_PATH];
	
	WideCharToMultiByte(CP_OEMCP,0,FNameW,-1,FName,MAX_PATH,NULL,NULL);

	if(disk!=plg->packType)
		return DeleteDirUseMem(plg,FName);

	//if(plg->bAnsi)
	//{	MultiByteToWideChar(CP_ACP,MB_PRECOMPOSED,FName,MAX_PATH-1,ws,MAX_PATH);
	//	fNameLn = WideCharToMultiByte(CP_OEMCP,0,ws,-1,fName,MAX_PATH-1,NULL,NULL);
	//} else 
	fNameLn = MyStringCpy(fName,MAX_PATH,FName);

	unzf = myUnzOnlyOpenInternal(plg->zpFileName,&filePosInCentralDir);//unzf=fopen(plg->zpFileName,"rb");
	if(!unzf)
    {	msgWA(0,strngs[64],(LPTSTR)plg->zpFileName);//"error opening"
		return FALSE;
	}

	plg->fstFilePos = unzGetFirstFileOffset(unzf);
	if(plg->bSFX)
	if(0==plg->fstFilePos)
		plg->bSFX = FALSE;
	if(plg->bSFX)
	{	void *sfxHeader=malloc((size_t)plg->fstFilePos);
		if(ReadFromUnzipFileHandle(unzf,sfxHeader,(int)plg->fstFilePos)!=plg->fstFilePos)
		{	
ErrSfxHeader:
			err = Z_ERRNO;
			free(sfxHeader);
			return FALSE;
		}
		if(WriteToZipFileHandle(plg->zf,sfxHeader,(int)plg->fstFilePos)!=plg->fstFilePos)
			goto ErrSfxHeader;
		free(sfxHeader);
		offset = plg->fstFilePos;
	}

	while(ReadFromUnzipFileHandle(unzf,header,30) == 30)//fread(header, 1, 30, unzf) == 30)
	{	BOOL bDelete = FALSE;
		err = 0;
		offsetBeg = offset+numMismatch;
		if(offsetBeg > 0xffffffff)offsetBeg=0;//disk almashadur;
		offset += 30;
		/* File entry */
		if(READ_32(header) == 0x04034b50)
		{	unsigned int version = READ_16(header + 4);
			unsigned int gpflag = READ_16(header + 6);
			unsigned int method = READ_16(header + 8);
			unsigned int filetime = READ_16(header + 10);
			unsigned int filedate = READ_16(header + 12);
			unsigned int crc = READ_32(header + 14); /* crc */
			unsigned int cpsize = READ_32(header + 18); /* compressed size */
			unsigned int uncpsize = READ_32(header + 22); /* uncompressed sz */
			unsigned int fnsize = READ_16(header + 26); /* file name length */
			unsigned int extsize = READ_16(header + 28); /* extra field length */
			unsigned int fnsizeOld = fnsize;

			/* Close file in zip, fill for central directory entry */
			char cibuf[46];char *pcibuf=cibuf;int r;
			unsigned int	version1,
							version2,
							gpflag1,
							method1,
							filetime1,
							filedate1,
							crc1,
							cpsize1,
							uncpsize1,
							fnsize1,
							extsize1,
							comntsize,
							//diskNumb,
							intAttrb,
							extAttrb;//,
							//crntOffst1;


			filename[0] = extra[0] = '\0';

			/* Filename */
			if(fnsize > 0)
			{	if(fnsize < sizeof(filename))
				{	if(ReadFromUnzipFileHandle(unzf,filename,fnsize) == fnsize)//fread(filename, 1, fnsize, unzf) == fnsize)
					{	offset += fnsize;
						filename[fnsize]=0;	
						if(zstrstr_slash(filename,fName))//if(0==strcmp(filename,fName))
						{	bDelete = TRUE;
							/*char *p,tail[MAX_PATH];MyStringCpy(tail,MAX_PATH,&filename[fNameLn]);
							filename[fNameLn] = 0;
							p = zstrrchr2_excl_end(filename,'\\','/');
							if(p)
						    {	BOOL bsl = ('\\'==(*p) || '/'==(*p)) ? TRUE : FALSE;
							    fnsize = MyStringCpy(bsl ? p+1 : p,1023,fNewName);
								if(p!=&filename[0])
									fnsize += 1+p-&filename[0];
							}
							else//Root dir b-sa, bez slash ham keladur;
								fnsize = MyStringCpy(filename,1023,fNewName);
							fnsize += MyStringCpy(&filename[fnsize],1023-fnsize,tail);
							WRITE_16(header+26,fnsize);
							numMismatch += fnsize-fnsizeOld;*/
						}
						// Header
						if(!bDelete)
						if(!WriteToZipFileHandle(plg->zf,header,30)==30)
						{	err = Z_ERRNO;
							break;
						}

						// Filename
						if(!bDelete)
						if(!WriteToZipFileHandle(plg->zf,filename,fnsize)==fnsize)
						{	err = Z_ERRNO;
							break;
					}	}
					else
					{	err = Z_ERRNO;
						break;
				}	}
				else
				{	err = Z_ERRNO;
					break;
			}	}
			else
			{	err = Z_STREAM_ERROR;
				break;
			}

			/* Extra field */
			if(!bDelete)
			{	if(extsize > 0)
				{	if(extsize < sizeof(extra))
					{	if(ReadFromUnzipFileHandle(unzf,extra,extsize) == extsize)//fread(extra, 1, extsize, unzf) == extsize)
						{	offset += extsize;
							if(!WriteToZipFileHandle(plg->zf,extra,extsize)==extsize)
							{	err = Z_ERRNO;
								break;
						}	}
						else
						{	err = Z_ERRNO;
							break;
					}   }
					else
					{	err = Z_ERRNO;
						break;
			}	}	}
			else if(extsize > 0 && extsize < sizeof(extra))
			{	offset += extsize;
			}
		
			/* Data */
			if(!bDelete)
			{	int dataSize = cpsize;
				if(dataSize == 0)
					dataSize = uncpsize;
				if(dataSize > 0)
				{	char* data = malloc(dataSize);
					if(data != NULL)
					{	if(ReadFromUnzipFileHandle(unzf,data,dataSize) == dataSize)//fread(data, 1, dataSize, unzf) == dataSize)
						{	offset += dataSize;
							if(!WriteToZipFileHandle(plg->zf,data,dataSize)==dataSize)
								err = Z_ERRNO;
						}
						else
							err = Z_ERRNO;
						free(data);
						if(err != Z_OK)
							break;
					}
					else
					{	err = Z_MEM_ERROR;
						break;
			}   }	}
			else
			{	int dataSize = cpsize;
				if(dataSize == 0)
					dataSize = uncpsize;
				offset += dataSize;
			}

			r=GetNodeInfoFromCentralHeader(unzf,cibuf,&filePosInCentralDir,&offset);
			if(r<0){err = Z_MEM_ERROR;break;}
			//else:
			filePosInCentralDir+=r;
			if(!bDelete)
			{
			version1 = READ_16(pcibuf + 4);
			version2 = READ_16(pcibuf + 6);
			gpflag1 = READ_16(pcibuf + 8);
			method1 = READ_16(pcibuf + 10);
			filetime1 = READ_16(pcibuf + 12);
			filedate1 = READ_16(pcibuf + 14);
			crc1 = READ_32(pcibuf + 16); /* crc */
			cpsize1 = READ_32(pcibuf + 20); /* compressed size */
			uncpsize1 = READ_32(pcibuf + 24); /* uncompressed sz */
			fnsize1 = READ_16(pcibuf + 28); /* file name length */
			extsize1 = READ_16(pcibuf + 30); /* extra field length */
			comntsize = READ_16(pcibuf + 32); /* comment filed length */
			//diskNumb = READ_16(pcibuf + 34); /* disk # */
			intAttrb = READ_16(pcibuf + 36); /* int attrb */
			extAttrb = READ_32(pcibuf + 38); /* ext attrb */
			//crntOffst1 = READ_32(pcibuf + 42); /* crnt offset */
			if(gpflag1 != gpflag)
				{err = Z_MEM_ERROR;break;}
			if(method1 != method)
				{err = Z_MEM_ERROR;break;}
			if(filetime1 != filetime)
				{err = Z_MEM_ERROR;break;}
			if(filedate1 != filedate)
				{err = Z_MEM_ERROR;break;}
			if(crc1 != crc)
				{err = Z_MEM_ERROR;break;}
			if(cpsize1 != cpsize)
				{err = Z_MEM_ERROR;break;}
			if(uncpsize1 != uncpsize)
				{err = Z_MEM_ERROR;break;}
			if(fnsize1 != fnsizeOld)
				{err = Z_MEM_ERROR;break;}
			if(extsize1 != extsize)
				{err = Z_MEM_ERROR;break;}
			r=AddEndFileEntryForAppendingFromZip(plg->zf,version1,version2,gpflag,method,
						uncpsize,cpsize,filedate,filetime,crc,fnsize,filename,extsize,extra,
						intAttrb,extAttrb,(uLong*)&offsetBeg);
			if(r < 0)
			{	err = Z_MEM_ERROR;
				break;
			}
			}
			/* Success */
			entries++;
		}
		else
			break;
	}

	/* Close */
	unzClose(unzf);//fclose(unzf);
	return err==0?TRUE:FALSE;
}

VOID SetCallbacks$4xxx(LPVOID frstCallback,...)
{
va_list args;
	va_start(args, frstCallback);//1
	checkFileInSelctn = (checkFileInSelctn_t)frstCallback;//2
	excldFileFrSelctn = (excldFileFrSelctn_t)va_arg(args, LPVOID);//3
	getFileInfoFromSelection = (getFileInfoFromSelection_t)va_arg(args, LPVOID);//4
	prgrssRout = (prgrssRout_t)va_arg(args, LPVOID);//5
	showDlgOverwriteExistFile = (showDlgOverwriteExistFile_t)va_arg(args, LPVOID);//6
	saveOptions = (saveOptions_t)va_arg(args, LPVOID);//7
	readOptions = (readOptions_t)va_arg(args, LPVOID);//8
	addItemToPanelList = (addItemToPanelList_t)va_arg(args, LPVOID);//9
va_end (args);
}

int GetTotalCryptMethods()
{
	return 1;
}

const wchar_t* GetPluginDescription()
{
wchar_t mnuStr[64];
	if(GetEnvironmentVariableW(L"languge",mnuStr,64))//Language instartup qo'yadur;
	{	if(!wcscmp(mnuStr,L"russian"))
			return L"Sino zip-������, ���������������� ������ 1.2.7";
		else if(!wcscmp(mnuStr,L"uzbekl"))
			return L"Sino zip-plagin, modifikatsiyalangan Infozip versiyasi 1.2.7";
		else if(!wcscmp(mnuStr,L"uzbekk"))
			return L"Sino zip-������, ����������������� Infozip �������� 1.2.7";
		else//if(wcscmp(mnuStr,L"Exit")
			return L"Sino zip-plugin modified Infozip version 1.2.7";
	}	
	else return L"Sino zip-plugin modified Infozip version 1.2.7";
}

const wchar_t* GetCryptDescription$4(int cryptNum)
{
wchar_t mnuStr[64];
	switch(cryptNum)
	{	case 0:default:
			if(GetEnvironmentVariableW(L"languge",mnuStr,64))//Language instartup qo'yadur;
			{	if(!wcscmp(mnuStr,L"russian"))
					return L"���������������� ������ ������������ �� Infozip-������,Gilles Vollant";
				else if(!wcscmp(mnuStr,L"uzbekl"))
					return L"Infozip-paketining modifikatsiyalashtirilgan kriptografiya versiyasi,Gilles Vollant";
				else if(!wcscmp(mnuStr,L"uzbekk"))
					return L"Infozip-���������� ���������������������� ������������ ��������,Gilles Vollant";
				else//if(wcscmp(mnuStr,L"Exit")
					return L"Gilles Vollant modified version of crypting code in Infozip distribution";
			}	
			else return L"Gilles Vollant modified version of crypting code in Infozip distribution";
	}
	return L"";
}

VOID SetCryptMethod$8(PluginObj *plg,int n)
{
	if(n==0)
		plg->cryptMethod = n;
}

INT_PTR CALLBACK optnDlg(HWND hDlg,UINT message,WPARAM wParam,LPARAM lParam)
{
static HFONT hf=0;
static HBRUSH br=0;
static HBRUSH brHtBk=0;
RECT rc;
int width,left,height,top;
	UNREFERENCED_PARAMETER(lParam);
	switch(message)
	{
	case WM_INITDIALOG:
		GetWindowRect(hDlg, &rc);
		width = rc.right - rc.left;		
		left = (GetSystemMetrics(SM_CXFULLSCREEN) - width)/2;
		height = rc.bottom - rc.top;
		top = (GetSystemMetrics(SM_CYFULLSCREEN) - height)/2;
		MoveWindow(hDlg, left, top+20, width, height, TRUE);
		SetWindowTextW(hDlg,strngs[92]);
		SetDlgItemTextW(hDlg,IDOK,strngs[10]);
		SetDlgItemTextW(hDlg,IDC_STATIC1,strngs[93]);
		SetDlgItemTextW(hDlg,IDC_STATIC2,strngs[94]);
		SendMessage(hDlg,WM_USER+1,0,0);
		return TRUE;
	case WM_DRAWITEM:
		SendMessage(GetDlgItem(hDlg,IDOK),WM_SETFONT,(WPARAM)hf,TRUE);
		return TRUE;
	case WM_USER+1://hf obshiy uchun, dinamik o'zgartirish uchun emas:
			//if(0==hfRef)
			{	LOGFONTW fnt;
				InitLOGFONT(&fnt,0);
				hf = CreateFontIndirect(&fnt);
				br = CreateSolidBrush(RGB(0x40,0x21,0x17));//0xc9,0x81,0x93));
				brHtBk = CreateSolidBrush(RGB(0x64,0x79,0x65));
			}
			SendMessage(GetDlgItem(hDlg,IDOK),WM_SETFONT,(WPARAM)hf,TRUE);
			SendMessage(GetDlgItem(hDlg,IDC_STATIC1),WM_SETFONT,(WPARAM)hf,TRUE);
			SendMessage(GetDlgItem(hDlg,IDC_STATIC2),WM_SETFONT,(WPARAM)hf,TRUE);
			SendMessage(GetDlgItem(hDlg,IDC_STATIC3),WM_SETFONT,(WPARAM)hf,TRUE);
			SendMessage(GetDlgItem(hDlg,IDC_STATIC4),WM_SETFONT,(WPARAM)hf,TRUE);
			SendMessage(GetDlgItem(hDlg,IDC_STATIC5),WM_SETFONT,(WPARAM)hf,TRUE);
			SendMessage(GetDlgItem(hDlg,IDC_STATIC6),WM_SETFONT,(WPARAM)hf,TRUE);
			SendMessage(GetDlgItem(hDlg,IDC_STATIC7),WM_SETFONT,(WPARAM)hf,TRUE);
			SendMessage(GetDlgItem(hDlg,IDC_STATIC8),WM_SETFONT,(WPARAM)hf,TRUE);
			SendMessage(GetDlgItem(hDlg,IDC_STATIC9),WM_SETFONT,(WPARAM)hf,TRUE);
			SendMessage(GetDlgItem(hDlg,IDC_STATIC10),WM_SETFONT,(WPARAM)hf,TRUE);
			SendMessage(GetDlgItem(hDlg,IDC_STATIC11),WM_SETFONT,(WPARAM)hf,TRUE);
			SendMessage(GetDlgItem(hDlg,IDC_STATIC12),WM_SETFONT,(WPARAM)hf,TRUE);
			SendMessage(GetDlgItem(hDlg,IDC_STATIC13),WM_SETFONT,(WPARAM)hf,TRUE);
			SendMessage(GetDlgItem(hDlg,IDC_STATIC14),WM_SETFONT,(WPARAM)hf,TRUE);
			SendMessage(GetDlgItem(hDlg,IDC_STATIC15),WM_SETFONT,(WPARAM)hf,TRUE);
			//++hfRef;
			return 0;//GWL_USERDATA
		case WM_DESTROY:
			//if(--hfRef<1)
			{	DeleteObject(hf);
				DeleteObject(br);
				DeleteObject(brHtBk);
			}
			return 0;
	case WM_COMMAND:
		switch(LOWORD(wParam))
		{	case IDOK:
			case IDCANCEL:
				EndDialog(hDlg,0);
				return (INT_PTR)TRUE;
		}
		break;
	}
	return (INT_PTR)FALSE;
}

VOID ShowOptionDialog(HWND prnt)
{
	int r = (int)DialogBox(plgnDllInst,MAKEINTRESOURCE(IDD_DIALOG_OPTIONS),prnt,optnDlg);
}