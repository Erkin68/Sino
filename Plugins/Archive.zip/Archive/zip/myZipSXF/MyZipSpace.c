#include "shlobj.h"
#include "strsafe.h"
#include "resource.h"
#include "../unzip.h"

#define WRITEBUFFERSIZE (16384) 

extern unsigned __int64 totalProgressed;
extern unsigned __int64 zipSize;
extern char pth[260];
extern char renamePth[260];
extern char pasw[260];
extern int iOverwrite;
extern BOOL bPrcssStart;
extern BOOL bClose;
extern BOOL bIgnorePath;
extern BOOL bUseToAll;
extern HINSTANCE hInst;
extern HWND prcssDlg;


extern INT_PTR CALLBACK fileExistQueueDlg(HWND,UINT,WPARAM,LPARAM);
extern int ZEXPORT unzReadCurrentFileChkPassword(unzFile,voidp,unsigned,BOOL*);
extern void fill_win32_filefunc64A OF((zlib_filefunc64_def*));
extern INT_PTR CALLBACK IncrctPswrdDlg(HWND,UINT,WPARAM,LPARAM);



unsigned __int64 *TranslateTMFormatToUINT64(tm_unz *tm)
{
static unsigned __int64 ut;
SYSTEMTIME st;
FILETIME ft;
	st.wYear = (tm->tm_year < 1980 ? (tm->tm_year+1980) : tm->tm_year); 
	st.wMonth = tm->tm_mon; 
	st.wDayOfWeek = 0;//tm->tm_mday; 
	st.wDay = tm->tm_mday; 
	st.wHour = tm->tm_hour; 
	st.wMinute = tm->tm_min; 
	st.wSecond = tm->tm_sec; 
    st.wMilliseconds = 0;
	SystemTimeToFileTime(&st,&ft);
	ut = (unsigned __int64)ft.dwHighDateTime<<32 | (unsigned __int64)ft.dwLowDateTime;
	return &ut;
}

/*  change_file_date : change the date/time of a file
    filename : the filename of the file where date/time must be modified
    dosdate : the new date at the MSDos format (4 bytes)
    tmu_date : the SAME new date at the tm_unz format */
void change_file_date(const char *filename,uLong dosdate,tm_unz tmu_date)
{
  HANDLE hFile;
  FILETIME ftm,ftLocal,ftCreate,ftLastAcc,ftLastWrite;

  hFile = CreateFileA(filename,GENERIC_READ | GENERIC_WRITE,
                      0,NULL,OPEN_EXISTING,0,NULL);
  GetFileTime(hFile,&ftCreate,&ftLastAcc,&ftLastWrite);
  DosDateTimeToFileTime((WORD)(dosdate>>16),(WORD)dosdate,&ftLocal);
  LocalFileTimeToFileTime(&ftLocal,&ftm);
  SetFileTime(hFile,&ftm,&ftLastAcc,&ftm);
  CloseHandle(hFile);
}
 
BOOL do_extract_currentfile(unzFile uf)
{
char write_filenameInDisk[260];
char filename_inzip[256];
char* filename_withoutpath;
char* write_filename;
unsigned __int64 szf,tmf,*arjtm;
char* p;
int err=UNZ_OK;
void* buf;
wchar_t s[MAX_PATH];
char RetCar[3] = { 0x0d, 0x0a, 0x00 };
FILE *fout=NULL;
uInt size_buf;
LPVOID par[2];
WIN32_FIND_DATA *ff;
unz_file_info64 file_info;
uLong ratio=0;
BOOL bDirectory=FALSE;
BOOL bReopen = FALSE;


Reopen:

err = unzGetCurrentFileInfo64(uf,&file_info,filename_inzip,sizeof(filename_inzip),NULL,0,NULL,0);

	if(err!=UNZ_OK)
    {	MessageBox(NULL,"Error with","Zipfile in unzGetCurrentFileInfo.",MB_OK|MB_ICONWARNING);
        return FALSE;
    }

	if(!bReopen)
	{    size_buf = WRITEBUFFERSIZE;
		buf = (void*)malloc(size_buf);
		if(buf==NULL)
		{	MessageBox(NULL,"Error","Allocating memory",MB_OK|MB_ICONWARNING);
			return FALSE;
		}

		p = filename_withoutpath = filename_inzip;
		while ((*p) != '\0')
		{	if (((*p)=='/') || ((*p)=='\\'))
			{   (*p) = '\\';//shu yerda almashtirduk; 
				filename_withoutpath = p+1;
			}
			p++;
		}

		//oxirgisi '/' yo '\' b-sa va hajmi 0 b-sa bu direktory:
		if((*filename_withoutpath)==0 && file_info.uncompressed_size==0)
		{	bDirectory = TRUE;
			if(bIgnorePath)
			{	free(buf);
				return TRUE;//Directory ochib o'tirmasun;
			}
			*(filename_withoutpath-1)=0;//oxiriga bitta slash qolib ketayapti;
			StringCchPrintf(write_filenameInDisk,260,"%s\\%s",pth,filename_inzip);
		}
		else
		{	if((*filename_withoutpath)==0)
			{	*(--filename_withoutpath)=0;//oxiriga bitta slash qolib ketayapti;
				while((*filename_withoutpath)!='\\')
					--filename_withoutpath;
			}
			write_filename = bIgnorePath?filename_withoutpath:filename_inzip;
			StringCchPrintf(write_filenameInDisk,260,"%s\\%s",pth,write_filename);
		}

		MultiByteToWideChar(CP_OEMCP,MB_PRECOMPOSED,write_filenameInDisk,MAX_PATH,s,MAX_PATH);
		WideCharToMultiByte(CP_ACP,0,s,-1,write_filenameInDisk,MAX_PATH,NULL,NULL);
	}

	err = unzOpenCurrentFilePassword(uf,pasw[0]?pasw:NULL);
    if(err!=UNZ_OK)
        MessageBox(NULL,"Zipfile in unzOpenCurrentFilePassword.","Error with",MB_OK|MB_ICONWARNING);

	if(bUseToAll)
	{	if(1==iOverwrite)goto WrFile;//overwrite
		if(2==iOverwrite)goto End;//skip
	}

	if(!bReopen)
	{	ff=IsFileExistA((char*)write_filenameInDisk);
		if(!ff)
			goto WrFile;
	}

	if(bDirectory)
		goto End;//Directory sozdavat qilib o'tirma, o'zi bor ekan;

	if(!bReopen)
	{	szf = ((unsigned __int64)ff->nFileSizeHigh << 32) | (unsigned __int64)ff->nFileSizeLow;
		tmf = ((unsigned __int64)ff->ftCreationTime.dwHighDateTime << 32) | (unsigned __int64)ff->ftCreationTime.dwLowDateTime;
		arjtm = TranslateTMFormatToUINT64(&file_info.tmu_date);
	}

	if(bUseToAll)
	{	if(3==iOverwrite)//overwrite oldest
		{	if(tmf<(*arjtm)) goto WrFile;
			else goto End;
		}
		if(4==iOverwrite)//overwrite latest
		{	if(tmf<(*arjtm)) goto WrFile;
			else goto End;
		}
		if(5==iOverwrite)//overwrite littlest
		{	if(szf<file_info.uncompressed_size) goto WrFile;
			else goto End;
		}
		if(6==iOverwrite)//overwrite largest
		{	if(szf>file_info.uncompressed_size) goto WrFile;
			else goto End;
		}
		if(8==iOverwrite)//overwrite auto rename
		{	if(!bReopen)
			{	int iMyCopyRenameFileEx=0;
				int l=strlen(write_filenameInDisk);
				do
				{	if(++iMyCopyRenameFileEx>25000000)
					{	MessageBox(prcssDlg,write_filenameInDisk,"Error to build new name,Can't write new file",MB_OK);
						goto End;
					}
					StringCchPrintf(&write_filenameInDisk[l],32,"_%d",iMyCopyRenameFileEx);
				} while(IsFileExistA(write_filenameInDisk));
			}
			goto WrFile;
	}	}

	if(!bReopen)
	{	par[0]=(LPVOID)write_filenameInDisk;
		par[1]=(LPVOID)&file_info;
		DialogBoxParam(hInst,MAKEINTRESOURCE(IDD_DIALOG_FILE_EXIST),prcssDlg,fileExistQueueDlg,(LPARAM)&par[0]);
	}

	if(0==iOverwrite){bUseToAll=TRUE;goto End;}//cancel
	if(1==iOverwrite)goto WrFile;//overwrite
	if(2==iOverwrite)goto End;//skip
	if(3==iOverwrite)//overwrite oldest
	{	if(tmf<(*arjtm)) goto WrFile;
		else goto End;
	}
	if(4==iOverwrite)//overwrite latest
	{	if(tmf<(*arjtm)) goto WrFile;
		else goto End;
	}
	if(5==iOverwrite)//overwrite littlest
	{	if(szf<file_info.uncompressed_size) goto WrFile;
		else goto End;
	}
	if(6==iOverwrite)//overwrite largest
	{	if(szf>file_info.uncompressed_size) goto WrFile;
		else goto End;
	}
	if(7==iOverwrite)//overwrite rename
	{	if(!bReopen)
			StringCchPrintf(write_filenameInDisk,MAX_PATH,renamePth);
		goto End;
	}
	if(8==iOverwrite)//overwrite auto rename
	{	if(!bReopen)
		{	int iMyCopyRenameFileEx=0;
			int l=strlen(write_filenameInDisk);
			do
			{	if(++iMyCopyRenameFileEx>2500000)
				{	MessageBox(prcssDlg,write_filenameInDisk,"Error to build new name,Can't write new file",MB_OK);
					goto End;
				}
				StringCchPrintf(&write_filenameInDisk[l],32,"_%d",iMyCopyRenameFileEx);
			} while(IsFileExistA(write_filenameInDisk));
		}
		goto WrFile;
	}
	goto End;

WrFile:
	if(bDirectory)
	{	if(!bReopen)
		{	if(!CreateDirectory(write_filenameInDisk,NULL))
			{	if(ERROR_ALREADY_EXISTS!=GetLastError())
				{	if(IDYES!=MessageBox(prcssDlg,write_filenameInDisk,"Directory was not crated,continue",MB_YESNO|MB_ICONWARNING))
					{	unzCloseCurrentFile (uf);
						free(buf);
						return TRUE;
		}	}	}	}
		goto End;
	}
	if(!bReopen)
	{    fopen_s(&fout,write_filenameInDisk,"wb");
		/* some zipfile don't contain directory alone before file */
		if(fout==NULL)
			MessageBox(NULL,"Error opening",write_filename,MB_OK|MB_ICONWARNING);
		SetDlgItemText(prcssDlg,IDC_EDIT_FILE_PATH,write_filenameInDisk);
		SendMessage(GetDlgItem(prcssDlg,IDC_EDIT_TOTAL_FILES),EM_REPLACESEL,(WPARAM)FALSE, (LPARAM)write_filenameInDisk);
		SendMessage(GetDlgItem(prcssDlg,IDC_EDIT_TOTAL_FILES),EM_REPLACESEL,(WPARAM)FALSE, (LPARAM)(LPCSTR)RetCar);
		SendMessage(GetDlgItem(prcssDlg,IDC_EDIT_TOTAL_FILES),EM_SCROLLCARET,(WPARAM)0, (LPARAM)0);
	}

    if(fout!=NULL)
    {	//printf(" extracting: %s\n",write_filename);
		unsigned __int64 totProgrd=0;
        do
        {	static int passErr=0;
			err = unzReadCurrentFile(uf,buf,size_buf);//err = unzReadCurrentFileChkPassword(uf,buf,size_buf,&bPasswErr);
			if(-3==err)
            {	if(passErr++<3)//Umuman chiqib ketsun;
				{	if(!DialogBox(hInst,MAKEINTRESOURCE(ID_SFX_CR_ARJ_DLG),NULL,IncrctPswrdDlg))
					{ 	unzCloseCurrentFile(uf);
						free(buf);
						return FALSE;
					}
					bReopen = TRUE;
					unzCloseCurrentFile(uf);
					goto Reopen;
				}
				MessageBox(NULL,"Incorrect password,","Finishing...",MB_OK|MB_ICONWARNING);
				goto End;
			}
            else if (err<0)
            {	MessageBox(NULL,"Error with","Zipfile in unzReadCurrentFile",MB_OK|MB_ICONWARNING);
                break;
            }
            if(err>0)
			{	MSG msg;
				if (fwrite(buf,err,1,fout)!=1)
                {	MessageBox(NULL,"Error in","Writing extracted file",MB_OK|MB_ICONWARNING);
                    err=UNZ_ERRNO;
                    break;
				}
				totProgrd+=err;
				PostMessage(GetDlgItem(prcssDlg,IDC_PROGRESS_FILE),PBM_SETPOS,
							(int)(100.0f*totProgrd/file_info.uncompressed_size),0);
				PostMessage(GetDlgItem(prcssDlg,IDC_PROGRESS_TOTAL),PBM_SETPOS,
							(int)(100.0f*(totalProgressed+totProgrd)/zipSize),0);
				while(PeekMessage(&msg, NULL, 0U, 0U, PM_REMOVE))
				{	{	TranslateMessage(&msg);
						DispatchMessage(&msg);
		}	}	}	}
        while(err>0);

        if(fout)
			fclose(fout);

		totalProgressed += totProgrd;

        if(err==0)
			change_file_date(write_filenameInDisk,file_info.dosDate,
                             file_info.tmu_date);
	}
End:
    if(err==UNZ_OK)
    {	err = unzCloseCurrentFile (uf);
        if(err!=UNZ_OK)
            MessageBox(NULL,"Error with","Zipfile in unzCloseCurrentFile",MB_OK|MB_ICONWARNING);
    }
    else
        unzCloseCurrentFile(uf); /* don't lose the error */    
    free(buf);
    return TRUE;
}

BOOL do_extract(unzFile uf,int offst)
{
uLong i;
unz_global_info64 gi;
int err,opt_overwrite=0;
FILE* fout=NULL;
MSG msg;

    err = unzGetGlobalInfo64(uf,&gi);
    if (err!=UNZ_OK)
	{   MessageBox(NULL,"error with","zipfile in unzGetGlobalInfo.",MB_OK|MB_ICONWARNING);
		return FALSE;
	}

	totalProgressed=0;

    for(i=0;i<gi.number_entry;i++)
	{	if(!do_extract_currentfile(uf))
            return FALSE;

		if(0==iOverwrite && bUseToAll)
			break;
		
		PostMessage(GetDlgItem(prcssDlg,IDC_PROGRESS_FILE),PBM_SETPOS,100,0);
		PostMessage(GetDlgItem(prcssDlg,IDC_PROGRESS_TOTAL),PBM_SETPOS,(int)(100.0f*(totalProgressed/zipSize)),0);

		while(PeekMessage(&msg, NULL, 0U, 0U, PM_REMOVE))
		{	{	TranslateMessage(&msg);
				DispatchMessage(&msg);
		}	}

        if((i+1)<gi.number_entry)
        {   err = unzGoToNextFile(uf);
            if (err!=UNZ_OK)
            {	MessageBox(NULL,"error with","zipfile in unzGoToNextFile.",MB_OK|MB_ICONWARNING);
                return FALSE;
    }	}	}
    return TRUE;
}

BOOL ProcessArchive(int zipOffsetInPE)
{
char name[260];
unzFile uf;
zlib_filefunc64_def ffunc;
	GetModuleFileName(NULL, name, sizeof(name));
	fill_win32_filefunc64A(&ffunc);
    uf = unzOpen2_64(name,&ffunc);
	if(!uf)
	{	MessageBox(NULL,"Error open executable file!",name,MB_OK|MB_ICONWARNING);
		return FALSE;
	}
	if(do_extract(uf, zipOffsetInPE))
	{	unzClose(uf);
		return TRUE;
	}
	unzClose(uf);
	return FALSE;
}

unsigned __int64 FindZipPartSize(HANDLE f,int *exesize)//exesize as offset of zip file beginning;
{
int i;
unsigned char buff[4096];
unsigned __int64 filesize;
IMAGE_DOS_HEADER *dosheader;
IMAGE_NT_HEADERS32 *header;
IMAGE_SECTION_HEADER *sectiontable;
DWORD filesizeL,filesizeH,read,maxpointer=0;
	(*exesize)=0;

	if(!ReadFile(f, buff, sizeof(buff), &read, NULL))
	{	MessageBox(NULL,"Reading first 4096 bytes from executable file!","Error",MB_OK|MB_ICONWARNING);
		return 0;
	}
	dosheader = (IMAGE_DOS_HEADER*)buff;
	if(dosheader->e_magic != IMAGE_DOS_SIGNATURE)
	{	MessageBox(NULL,"Bad dos header in executable file!","Error",MB_OK|MB_ICONWARNING);
		return 0;
	}
	if((ULONG)dosheader->e_lfanew >= (ULONG)(sizeof(buff) - sizeof(IMAGE_NT_HEADERS32)))
	{	MessageBox(NULL,"Bad dos header in executable file!","Error",MB_OK|MB_ICONWARNING);
		return 0;
	}

	// Locate PE header
	header = (IMAGE_NT_HEADERS32*)(buff + dosheader->e_lfanew);
	if(header->Signature != IMAGE_NT_SIGNATURE)
	{	MessageBox(NULL,"Bad NT header in executable file!","Error",MB_OK|MB_ICONWARNING);
		return 0;
	}
	sectiontable = (IMAGE_SECTION_HEADER*)((BYTE*)header + sizeof(IMAGE_NT_HEADERS32));
	if((BYTE*)sectiontable >= buff + sizeof(buff))
	{	MessageBox(NULL,"No section inNT header in executable file!","Error",MB_OK|MB_ICONWARNING);
		return 0;
	}

	// For each section
	for(i = 0; i < header->FileHeader.NumberOfSections; ++i)
	{	if(sectiontable->PointerToRawData > maxpointer)
		{	maxpointer = sectiontable->PointerToRawData;
			(*exesize) = sectiontable->PointerToRawData + sectiontable->SizeOfRawData;
		}
		sectiontable++;
	}

	// Seek to the overlay
	filesizeL = GetFileSize(f, &filesizeH);
	filesize  = (unsigned __int64)filesizeH<<32 | (unsigned __int64)filesizeL;
	if((*exesize) == filesize)
	{	MessageBox(NULL,"Zip archive datas not found in executable file!","Error",MB_OK|MB_ICONWARNING);
		return 0;
	}
	if(filesize == INVALID_FILE_SIZE || (*exesize) > filesize)
	{	MessageBox(NULL,"Zip archive datas not found in executable file!","Error",MB_OK|MB_ICONWARNING);
		return 0;
	}
	filesize -= (*exesize);
	return filesize;
}

/*int ZipCheckPassword(char *pasw)
{
  passwOK = false;
  if (_remSize < 16)
    return E_NOTIMPL;
  Byte *p = _bufAligned;
  UInt16 format = GetUi16(p);
  if (format != 3)
    return E_NOTIMPL;
  UInt16 algId = GetUi16(p + 2);
  if (algId < kAES128)
    return E_NOTIMPL;
  algId -= kAES128;
  if (algId > 2)
    return E_NOTIMPL;
  UInt16 bitLen = GetUi16(p + 4);
  UInt16 flags = GetUi16(p + 6);
  if (algId * 64 + 128 != bitLen)
    return E_NOTIMPL;
  _key.KeySize = 16 + algId * 8;
  if ((flags & 1) == 0)
    return E_NOTIMPL;
  if ((flags & 0x4000) != 0)
  {
    // Use 3DES
    return E_NOTIMPL;
  }

  UInt32 rdSize = GetUi16(p + 8);
  if ((rdSize & 0xF) != 0 || rdSize + 16 > _remSize)
    return E_NOTIMPL;
  memmove(p, p + 10, rdSize);
  Byte *validData = p + rdSize + 16;
  if (GetUi32(validData - 6) != 0) // reserved
    return E_NOTIMPL;
  UInt32 validSize = GetUi16(validData - 2);
  if ((validSize & 0xF) != 0 || 16 + rdSize + validSize != _remSize)
    return E_NOTIMPL;


  {
    RINOK(SetKey(_key.MasterKey, _key.KeySize));
    RINOK(SetInitVector(_iv, 16));
    Init();
    Filter(p, rdSize);
  }

  Byte fileKey[32];
  NSha1::CContext sha;
  sha.Init();
  sha.Update(_iv, 16);
  sha.Update(p, rdSize - 16); // we don't use last 16 bytes (PAD bytes)
  DeriveKey(sha, fileKey);
  
  RINOK(SetKey(fileKey, _key.KeySize));
  RINOK(SetInitVector(_iv, 16));
  Init();
  Filter(validData, validSize);

  if (validSize < 4)
    return E_NOTIMPL;
  validSize -= 4;
  if (GetUi32(validData + validSize) != CrcCalc(validData, validSize))
    return S_OK;
  passwOK = true;
  Init();
  return S_OK;
}*/

/*#if CRYPT
    {
      ush i, e;

      if (p == (char *)NULL) {
        if ((p = (char *)malloc(IZ_PWLEN+1)) == (char *)NULL)
          err(1, "out of memory");
        else if ((p = getp("Enter password: ", p, IZ_PWLEN+1)) == (char *)NULL)
          err(1, "no tty to prompt for password");
      }
#if (defined(USE_ZLIB) && !defined(USE_OWN_CRCTAB))
      // initialize crc_32_tab pointer for decryption 
      CRC_32_TAB = (ZCONST ulg Far *)get_crc_table();
#endif
      init_keys(p);
      for (i = 0; i < RAND_HEAD_LEN; i++)
        e = NEXTBYTE;
      if (e != (ush)(h[LOCFLG] & EXTFLG ? h[LOCTIM + 1] : h[LOCCRC + 3]))
        err(3, "incorrect password for first entry");
    }
#else // !CRYPT 
    err(3, "cannot decrypt entry (need to recompile with full crypt.c)");
#endif // ?CRYPT */