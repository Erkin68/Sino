//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by myZipSXF.rc
//
#define IDSTOP                          3
#define ID_SFX_CR_ARJ_DLG               5
#define IDC_EDIT_PATH                   101
#define IDD_MYZIPSXF_DIALOG             102
#define IDC_BUTTON_BROWSE               103
#define IDC_CHECK_IGNORE_PATH           104
#define IDC_EDIT_PATH_PASSWORD          105
#define IDD_DIALOG_PROCESS_ARJ          130
#define IDD_DIALOG_FILE_EXIST           131
#define IDI_ICON1                       132
#define IDC_PROGRESS_FILE               1004
#define IDC_EDIT_FILE_PATH              1005
#define IDC_PROGRESS_TOTAL              1006
#define IDC_EDIT_RENAME                 1006
#define IDC_EDIT_TOTAL_FILES            1007
#define IDC_EDIT_SRC_SZ                 1008
#define IDC_EDIT_DST_TIME               1009
#define IDC_EDIT_SRC_TIME               1010
#define IDC_BUTTON_OVERWRITE            1011
#define IDC_BUTTON_SKIP                 1012
#define IDC_BUTTON_OVERWRITE_OLDEST     1013
#define IDC_BUTTON_OVERWRITE_LATEST     1014
#define IDC_BUTTON_OVERWRITE_LITTLEST   1015
#define IDC_BUTTON_OVERWRITE_LAGEST     1016
#define IDC_BUTTON_RENAME               1017
#define IDC_BUTTON_AUTO_RENAME          1018
#define IDC_CHECK_USE_TO_ALL            1019
#define IDC_EDIT_FILE                   1020
#define IDC_EDIT_DEST_SZ                1021
#define IDC_CHECK_DELETE_ME             1022
#define IDC_STATIC_PASSWORD             1023
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        133
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1024
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
