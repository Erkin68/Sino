#include "windows.h"
#include "shlobj.h"
#include "strsafe.h"
#include "resource.h"
#include "../unzip.h"

int zipOffset,iOverwrite=0;
unsigned __int64 zipSize;
unsigned __int64 totalProgressed=0;
char pth[260],pasw[260],renamePth[260];
BOOL bPrcssStart = TRUE;
BOOL bClose = FALSE;
BOOL bIgnorePath;
BOOL bUseToAll=FALSE;
BOOL bDeleteMe=FALSE;
HINSTANCE hInst;
HWND prcssDlg;

VOID OpenArchive(char*,char*,BOOL);
INT_PTR CALLBACK sfxOpenArjDlg(HWND,UINT,WPARAM,LPARAM);
INT_PTR CALLBACK sfxPrcssArjDlg(HWND,UINT,WPARAM,LPARAM);
HANDLE OpenOwnPEFile();
unsigned __int64 FindZipPartSize(HANDLE,int*);
BOOL ProcessArchive(int);
VOID DeleteMe();

typedef __out HANDLE (WINAPI *FindFirstFileEx_t)(__in LPCSTR,
												 __in FINDEX_INFO_LEVELS,
												 __out LPVOID,
												 __in FINDEX_SEARCH_OPS,
												 __reserved LPVOID,
												 __in DWORD);
FindFirstFileEx_t MyFindFirstFileEx;
HANDLE WINAPI MyFindFirstFileExM(__in LPCTSTR lpFileName,             // file name
								 __in  FINDEX_INFO_LEVELS fInfoLevelId,// information level
								 __out LPVOID lpFindFileData,          // information buffer
								 __in  FINDEX_SEARCH_OPS fSearchOp,    // filtering type
								 __reserved LPVOID lpSearchFilter,     // search criteria
								 __in DWORD dwAdditionalFlags);        // additional search control

int __stdcall WinMain(HINSTANCE hInstance,HINSTANCE hPrevInstance,LPTSTR lpCmdLine,int nCmdShow)
{
WIN32_FIND_DATA ff;HANDLE h;char pt[MAX_PATH],*pend;
	hInst = hInstance;
//	STARTUPINFO sti;sti.cb=sizeof(sti);
//	GetStartupInfo(&sti);

	GetModuleFileName(NULL,pt,MAX_PATH);
	pend = strrchr(pt,'\\');
	if(pend) *pend = 0;
	MyFindFirstFileEx=NULL;
	h = FindFirstFileEx(pt,FindExInfoStandard,&ff,FindExSearchLimitToDirectories,NULL,0);
	if(INVALID_HANDLE_VALUE!=h)
	{	FindClose(h);
		if(FILE_ATTRIBUTE_DIRECTORY & ff.dwFileAttributes)
			MyFindFirstFileEx=(FindFirstFileEx_t)FindFirstFileEx;
	}
	if(!MyFindFirstFileEx)MyFindFirstFileEx=MyFindFirstFileExM;

	if(1234==DialogBox(hInstance,MAKEINTRESOURCE(ID_SFX_CR_ARJ_DLG),NULL,sfxOpenArjDlg))
	{	prcssDlg=CreateDialog(hInstance,MAKEINTRESOURCE(IDD_DIALOG_PROCESS_ARJ),NULL,sfxPrcssArjDlg);
		ShowWindow(prcssDlg,SW_SHOW);
		h = OpenOwnPEFile();
		if(!h) return 1;
		zipSize = FindZipPartSize(h,&zipOffset);
		if(!zipSize) return 1;
		CloseHandle(h);
		if(ProcessArchive(zipOffset))
		{	if(bDeleteMe)
			{	char s[260];
				GetModuleFileName(NULL, s, 260);
				if(IDNO==MessageBox(prcssDlg,s,"Delete own sfx-zip file:",MB_YESNO))
					bDeleteMe=FALSE;
		}	}
		if(!bClose)
			DestroyWindow(prcssDlg);
		if(bDeleteMe)
			DeleteMe();
	}
	return 1;
}

INT_PTR CALLBACK sfxOpenArjDlg(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
RECT rc;
char *p;
int width,left,height,top;
HANDLE hf;WIN32_FIND_DATA ffd;
LPITEMIDLIST pidlRoot,pidlSelected;
BROWSEINFO bi; 
	UNREFERENCED_PARAMETER(lParam);
	switch (message)
	{
	case WM_INITDIALOG:
		GetWindowRect(hDlg, &rc);
		width = rc.right - rc.left;		
		left = (GetSystemMetrics(SM_CXFULLSCREEN) - width)/2;
		height = rc.bottom - rc.top;
		top = (GetSystemMetrics(SM_CYFULLSCREEN) - height)/2;
		MoveWindow(hDlg, left, top+20, width, height, TRUE);
		GetModuleFileName(NULL, pth, sizeof(pth));
		p=strrchr(pth,'\\');
		if(p) *p=0;
		SetDlgItemText(hDlg,IDC_EDIT_PATH,pth);
		return (INT_PTR)TRUE;

	case WM_COMMAND:
		switch(LOWORD(wParam))
		{	case IDOK:
				if(!GetDlgItemText(hDlg,IDC_EDIT_PATH,pth,260))
				{	MessageBox(NULL,"Please,","Fill path info first",MB_OK);
					return (INT_PTR)TRUE;
				}
				GetDlgItemText(hDlg,IDC_EDIT_PATH_PASSWORD,pasw,260);
				hf = MyFindFirstFileEx(pth,FindExInfoStandard,&ffd,FindExSearchLimitToDirectories,NULL,0);
				if(INVALID_HANDLE_VALUE==hf)
				{	MessageBox(NULL,"Error, path not exist.",pth,MB_OK);
					return (INT_PTR)TRUE;
				}
				FindClose(hf);
				if(!(FILE_ATTRIBUTE_DIRECTORY & ffd.dwFileAttributes))
				{	MessageBox(NULL,"Error, this is not folder.",pth,MB_OK);
					return (INT_PTR)TRUE;
				}
				bIgnorePath=(BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_IGNORE_PATH),BM_GETCHECK,0,0));
				bDeleteMe=(BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_DELETE_ME),BM_GETCHECK,0,0));
				//OpenArchive(pth,pasw,(BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_IGNORE_PATH),BM_GETCHECK,0,0)));
				EndDialog(hDlg, 1234);
				return (INT_PTR)TRUE;
			case IDCANCEL:
				EndDialog(hDlg, LOWORD(wParam));
				return (INT_PTR)0;
			case IDC_BUTTON_BROWSE:
				bi.hwndOwner = hDlg;
				bi.pszDisplayName = pth;
				bi.lpszTitle = "Extract zip archive to folder ...";
				bi.ulFlags = BIF_NONEWFOLDERBUTTON|BIF_DONTGOBELOWDOMAIN|BIF_NEWDIALOGSTYLE|
					BIF_NOTRANSLATETARGETS|BIF_RETURNFSANCESTORS;
				bi.lpfn = NULL;
				pidlRoot = NULL;
				bi.pidlRoot = pidlRoot;
				pidlSelected = SHBrowseForFolder(&bi);
				if(pidlRoot)
					CoTaskMemFree(pidlRoot);
				if(pidlSelected)
				{	SHGetPathFromIDList(pidlSelected,pth);
					SetDlgItemText(hDlg,IDC_EDIT_PATH,pth);
					CoTaskMemFree(pidlSelected);
				}
				break;
		}
		break;
	}
	return (INT_PTR)FALSE;
}

INT_PTR CALLBACK sfxPrcssArjDlg(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
RECT rc;
int width,left,height,top;
	UNREFERENCED_PARAMETER(lParam);
	switch (message)
	{
	case WM_INITDIALOG:
		GetWindowRect(hDlg, &rc);
		width = rc.right - rc.left;		
		left = (GetSystemMetrics(SM_CXFULLSCREEN) - width)/2;
		height = rc.bottom - rc.top;
		top = (GetSystemMetrics(SM_CYFULLSCREEN) - height)/2;
		MoveWindow(hDlg, left, top+20, width, height, TRUE);
		return (INT_PTR)TRUE;
	case WM_COMMAND:
		switch(LOWORD(wParam))
		{	case IDCANCEL:
				DestroyWindow(hDlg);
				bClose = TRUE;
				return (INT_PTR)0;
			case IDSTOP:
				bPrcssStart = !bPrcssStart;
				SetDlgItemText(hDlg,IDSTOP,bPrcssStart?"Start":"Stop");
				return (INT_PTR)0;
		}
		break;
	}
	return (INT_PTR)FALSE;
}

INT_PTR CALLBACK fileExistQueueDlg(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
RECT rc;
char s[260];
char *fname;
int width,left,height,top;
unz_file_info64 *zp_file_info;
WIN32_FIND_DATA fd;
SYSTEMTIME st;
FILETIME ft;
HANDLE hff;

	UNREFERENCED_PARAMETER(lParam);
	switch (message)
	{
	case WM_INITDIALOG:
		GetWindowRect(hDlg, &rc);
		width = rc.right - rc.left;		
		left = (GetSystemMetrics(SM_CXFULLSCREEN) - width)/2;
		height = rc.bottom - rc.top;
		top = (GetSystemMetrics(SM_CYFULLSCREEN) - height)/2;
		MoveWindow(hDlg, left, top+20, width, height, TRUE);
		fname = ((LPVOID*)lParam)[0];
		zp_file_info = ((LPVOID*)lParam)[1];

		hff=FindFirstFile(fname,&fd);
		if(INVALID_HANDLE_VALUE!=hff)
		{	FindClose(hff);			
			SetDlgItemText(hDlg,IDC_EDIT_FILE,fname);
			StringCchPrintf(s,260,"%d",(((unsigned __int64)fd.nFileSizeHigh << 32) | (unsigned __int64)fd.nFileSizeLow)/1024);
			SetDlgItemText(hDlg,IDC_EDIT_DEST_SZ,s);
			if(FileTimeToLocalFileTime(&fd.ftCreationTime,&ft) != 0)
			{	if(FileTimeToSystemTime(&ft, &st) != 0)
				{	StringCchPrintf(s,MAX_PATH,"%d.%d.%d  %d:%d:%d",
									st.wDay,st.wMonth,st.wYear,
									st.wHour,st.wMinute,st.wSecond);
					SetDlgItemText(hDlg,IDC_EDIT_DST_TIME,s);
			}	}
			StringCchPrintf(s,260,"%d",zp_file_info->uncompressed_size/1024);
			SetDlgItemText(hDlg,IDC_EDIT_SRC_SZ,s);
			StringCchPrintf(s,MAX_PATH,"%d.%d.%d  %d:%d:%d",
							zp_file_info->tmu_date.tm_mday,
							zp_file_info->tmu_date.tm_mon,
							zp_file_info->tmu_date.tm_year<1980?zp_file_info->tmu_date.tm_year+1980:zp_file_info->tmu_date.tm_year,
							zp_file_info->tmu_date.tm_hour,
							zp_file_info->tmu_date.tm_min,
							zp_file_info->tmu_date.tm_sec);
			SetDlgItemText(hDlg,IDC_EDIT_SRC_TIME,s);
		}
		return (INT_PTR)TRUE;
	case WM_COMMAND:
		switch(LOWORD(wParam))
		{	case IDCANCEL:
				DestroyWindow(hDlg);
				iOverwrite=0;
				bClose = TRUE;
				return (INT_PTR)0;
			case IDC_BUTTON_OVERWRITE:
				GetDlgItemText(hDlg,IDC_EDIT_RENAME,renamePth,260);
				bUseToAll=(BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_USE_TO_ALL),BM_GETCHECK,0,0));
				iOverwrite=1;
				DestroyWindow(hDlg);
				return (INT_PTR)0;
			case IDC_BUTTON_SKIP:
				GetDlgItemText(hDlg,IDC_EDIT_RENAME,renamePth,260);
				bUseToAll=(BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_USE_TO_ALL),BM_GETCHECK,0,0));
				iOverwrite=2;
				DestroyWindow(hDlg);
				return (INT_PTR)0;
			case IDC_BUTTON_OVERWRITE_OLDEST:
				GetDlgItemText(hDlg,IDC_EDIT_RENAME,renamePth,260);
				bUseToAll=(BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_USE_TO_ALL),BM_GETCHECK,0,0));
				iOverwrite=3;
				DestroyWindow(hDlg);
				return (INT_PTR)0;
			case IDC_BUTTON_OVERWRITE_LATEST:
				GetDlgItemText(hDlg,IDC_EDIT_RENAME,renamePth,260);
				bUseToAll=(BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_USE_TO_ALL),BM_GETCHECK,0,0));
				iOverwrite=4;
				DestroyWindow(hDlg);
				return (INT_PTR)0;
			case IDC_BUTTON_OVERWRITE_LITTLEST:
				GetDlgItemText(hDlg,IDC_EDIT_RENAME,renamePth,260);
				bUseToAll=(BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_USE_TO_ALL),BM_GETCHECK,0,0));
				iOverwrite=5;
				DestroyWindow(hDlg);
				return (INT_PTR)0;
			case IDC_BUTTON_OVERWRITE_LAGEST:
				GetDlgItemText(hDlg,IDC_EDIT_RENAME,renamePth,260);
				bUseToAll=(BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_USE_TO_ALL),BM_GETCHECK,0,0));
				iOverwrite=6;
				DestroyWindow(hDlg);
				return (INT_PTR)0;
			case IDC_BUTTON_RENAME:
				GetDlgItemText(hDlg,IDC_EDIT_RENAME,renamePth,260);
				bUseToAll=(BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_USE_TO_ALL),BM_GETCHECK,0,0));
				iOverwrite=7;
				DestroyWindow(hDlg);
				return (INT_PTR)0;
			case IDC_BUTTON_AUTO_RENAME:
				GetDlgItemText(hDlg,IDC_EDIT_RENAME,renamePth,260);
				bUseToAll=(BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_USE_TO_ALL),BM_GETCHECK,0,0));
				iOverwrite=8;
				DestroyWindow(hDlg);
				return (INT_PTR)0;
		}
		break;
	}
	return (INT_PTR)FALSE;
}

INT_PTR CALLBACK IncrctPswrdDlg(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
RECT rc;
int width,left,height,top;
	UNREFERENCED_PARAMETER(lParam);
	switch (message)
	{
	case WM_INITDIALOG:
		GetWindowRect(hDlg, &rc);
		width = rc.right - rc.left;		
		left = (GetSystemMetrics(SM_CXFULLSCREEN) - width)/2;
		height = rc.bottom - rc.top;
		top = (GetSystemMetrics(SM_CYFULLSCREEN) - height)/2;
		MoveWindow(hDlg, left, top+20, width, height, TRUE);

		SetWindowText(hDlg,"Correct password,please...");
		ShowWindow(GetDlgItem(hDlg,IDC_BUTTON_BROWSE),SW_HIDE);
		ShowWindow(GetDlgItem(hDlg,IDC_CHECK_IGNORE_PATH),SW_HIDE);
		ShowWindow(GetDlgItem(hDlg,IDC_EDIT_PATH),SW_HIDE);
		ShowWindow(GetDlgItem(hDlg,IDC_CHECK_DELETE_ME),SW_HIDE);
		ShowWindow(GetDlgItem(hDlg,IDC_STATIC),SW_HIDE);
		ShowWindow(GetDlgItem(hDlg,IDC_STATIC_PASSWORD),SW_HIDE);
		//PostMessage(hDlg,WM_NEXTDLGCTL,IDC_EDIT_PATH_PASSWORD,MAKELONG(TRUE,TRUE));//
		if(!SetFocus(GetDlgItem(hDlg,IDC_EDIT_PATH_PASSWORD)))
			width=GetLastError();
		return (INT_PTR)TRUE;

	case WM_COMMAND:
		switch(LOWORD(wParam))
		{	case IDOK:
				GetDlgItemText(hDlg,IDC_EDIT_PATH_PASSWORD,pasw,260);
				EndDialog(hDlg, 1);
				return (INT_PTR)TRUE;
			case IDCANCEL:
				EndDialog(hDlg, 0);
				return (INT_PTR)TRUE;
		}
		break;
	}
	return (INT_PTR)FALSE;
}

HANDLE OpenOwnPEFile()
{
char buff[260];
HANDLE hFile;
	GetModuleFileName(NULL, buff, sizeof(buff));
	hFile = CreateFile(buff, GENERIC_READ, FILE_SHARE_READ,
						NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
	if(INVALID_HANDLE_VALUE == hFile)
	{	MessageBox(NULL,"Error open executable file!",buff,MB_OK|MB_ICONWARNING);
		return 0;
	}
	return hFile;
}

VOID DeleteMe()
{
char *p;
HANDLE				hfile;
STARTUPINFO			si;
PROCESS_INFORMATION	pi;
TCHAR szName[_MAX_PATH];
TCHAR szBatName[_MAX_PATH];

    GetModuleFileName(NULL, szName, _MAX_PATH);
	StringCchCopy(szBatName,_MAX_PATH,szName);
	p=strrchr(szBatName,'\\');
	if(p) *p=0;
	StringCchCat(szBatName,MAX_PATH,"\\SFXDel.bat");

   // Create a batch file that continuously attempts to delete our executable
   // file.  When the executable no longer exists, remove its containing
   // subdirectory, and then delete the batch file too.
   hfile = CreateFile(szBatName,GENERIC_WRITE,0,NULL,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL | FILE_FLAG_SEQUENTIAL_SCAN, NULL);
   if (hfile != INVALID_HANDLE_VALUE)
   {DWORD dwNumberOfBytesWritten;
	TCHAR szBatFile[_MAX_PATH];
    StringCchPrintf(szBatFile,_MAX_PATH,":Repeat\r\n");
    WriteFile(hfile, szBatFile, lstrlen(szBatFile) * sizeof(TCHAR),&dwNumberOfBytesWritten, NULL);
    StringCchPrintf(szBatFile,_MAX_PATH,"del \"%s\"\r\n", szName);
    WriteFile(hfile, szBatFile, lstrlen(szBatFile) * sizeof(TCHAR),&dwNumberOfBytesWritten, NULL);
    StringCchPrintf(szBatFile,_MAX_PATH,"if exist \"%s\" goto Repeat\r\n", szName);
    WriteFile(hfile, szBatFile, lstrlen(szBatFile) * sizeof(TCHAR),&dwNumberOfBytesWritten, NULL);
    StringCchPrintf(szBatFile,_MAX_PATH,":Repeat2\r\n");
    WriteFile(hfile, szBatFile, lstrlen(szBatFile) * sizeof(TCHAR),&dwNumberOfBytesWritten, NULL);
    StringCchPrintf(szBatFile,_MAX_PATH,"del \"%s\"\r\n",szBatName);
    WriteFile(hfile, szBatFile, lstrlen(szBatFile) * sizeof(TCHAR),&dwNumberOfBytesWritten, NULL);
    StringCchPrintf(szBatFile,_MAX_PATH,"if exist \"%s\" goto Repeat2\r\n",szBatName);
    WriteFile(hfile, szBatFile, lstrlen(szBatFile) * sizeof(TCHAR),&dwNumberOfBytesWritten, NULL);

    // Write the batch file and close it.
    CloseHandle(hfile);

    // Get ready to spawn the batch file we just created.
    ZeroMemory(&si, sizeof(si));
    si.cb = sizeof(si);

    // We want its console window to be invisible to the user.
    si.dwFlags = STARTF_USESHOWWINDOW;
    si.wShowWindow = SW_HIDE;

    // Spawn the batch file with low-priority and suspended.
    if (CreateProcess(NULL,szBatName, NULL, NULL, FALSE,
       CREATE_SUSPENDED | IDLE_PRIORITY_CLASS, NULL, __TEXT("\\"), &si, &pi)) {

       // Lower the batch file's priority even more.
       SetThreadPriority(pi.hThread, THREAD_PRIORITY_IDLE);

       // Raise our priority so that we terminate as quickly as possible.
       SetThreadPriority(GetCurrentThread(), THREAD_PRIORITY_TIME_CRITICAL);
       SetPriorityClass(GetCurrentProcess(), HIGH_PRIORITY_CLASS);

       // Allow the batch file to run and clean-up our handles.
       CloseHandle(pi.hProcess);
       ResumeThread(pi.hThread);
       // We want to terminate right away now so that we can be deleted
       CloseHandle(pi.hThread);
} }	}

//FindNextFile ni ishlatmaganimiz uchun uning My -yi kerakmas;
HANDLE WINAPI MyFindFirstFileExM(__in LPCTSTR lpFileName,             // file name
								 __in  FINDEX_INFO_LEVELS fInfoLevelId,// information level
								 __out LPVOID lpFindFileData,          // information buffer
								 __in  FINDEX_SEARCH_OPS fSearchOp,    // filtering type
								 __reserved LPVOID lpSearchFilter,     // search criteria
								 __in DWORD dwAdditionalFlags)		   // additional search control
{
HANDLE r=FindFirstFileEx(lpFileName,fInfoLevelId,lpFindFileData,fSearchOp,lpSearchFilter,dwAdditionalFlags);
HANDLE hDir = CreateFile(lpFileName,FILE_LIST_DIRECTORY,FILE_SHARE_READ|FILE_SHARE_DELETE,NULL,
						 OPEN_EXISTING,FILE_FLAG_BACKUP_SEMANTICS,NULL);
	if(INVALID_HANDLE_VALUE!=hDir)
	{	CloseHandle(hDir);
		((WIN32_FIND_DATA*)lpFindFileData)->dwFileAttributes |= FILE_ATTRIBUTE_DIRECTORY;
	}
	return r;

}