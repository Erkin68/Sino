// addArjTo.cpp : Defines the entry point for the application.
//

#include "windows.h"
#define BUFSZ 65536

int __stdcall WinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPTSTR    lpCmdLine,
                     int       nCmdShow)
{
DWORD sz,szH,rb;//i;
//char c[4];
void *buf;
unsigned __int64 cpred=0;
HANDLE hExe,hZip;
#ifdef _DEBUG
	hExe = CreateFile("../myZipSXF.exe",GENERIC_WRITE|GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE,
#else
	hExe = CreateFile("myZipSXF.exe",GENERIC_WRITE|GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE,
#endif
						NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
	if(INVALID_HANDLE_VALUE == hExe)
	{	MessageBox(NULL,"Error open executable file!","myZipSXF.exe",MB_OK|MB_ICONWARNING);
		return 0;
	}
#ifdef _DEBUG
	hZip = CreateFile("../apndArch.zip",GENERIC_READ,FILE_SHARE_READ,
#else
	hZip = CreateFile("apndArch.zip",GENERIC_READ,FILE_SHARE_READ,
#endif
						NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
	if(INVALID_HANDLE_VALUE == hZip)
	{	MessageBox(NULL,"Error open archive file!","apndArch.zip",MB_OK|MB_ICONWARNING);
		CloseHandle(hExe);
		return 0;
	}
	sz=GetFileSize(hZip,&szH);
	SetFilePointer(hExe,sz,0,FILE_END);
	buf = malloc(BUFSZ);//sz);

	while(cpred<sz)
	{	ReadFile(hZip,buf,BUFSZ,&rb,NULL);
		if(rb>0)
		{	WriteFile(hExe,buf,rb,&rb,NULL);
			cpred+=rb;
	}	}

//	for(i=0; i<sz; i++)
//	{	ReadFile(hZip,&c,1,&rb,NULL);
//		WriteFile(hExe,&c,1,&rb,NULL);
//	}
	free(buf);
	CloseHandle(hExe);
	CloseHandle(hZip);
	return (int)1;
}