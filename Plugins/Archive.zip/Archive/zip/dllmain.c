#define _CRT_SECURE_NO_WARNINGS

#include "windows.h"
#include "stdio.h"

#define MAX_STRINGS 95

wchar_t **strngs=NULL;
HMODULE plgnDllInst;
int		plgId=0;

extern void saveOpt();
extern void FreeFindData();

BOOL APIENTRY DllMain(HMODULE hModule,DWORD ul_reason_for_call,LPVOID lpReserved)
{
FILE *f;
int i,l;
wchar_t *pend;//char dllnameA[260];
wchar_t dllname[260],mnuStr[64];
	switch(ul_reason_for_call)
	{	case DLL_PROCESS_ATTACH:
			plgnDllInst=hModule;
			if(strngs)break;
			strngs = (wchar_t **)malloc(MAX_STRINGS*sizeof(wchar_t*));
			GetModuleFileNameW(hModule,dllname,260);
			pend = wcsrchr(dllname,'\\');
			if(pend){*pend++='\\';*pend=0;}

			if(GetEnvironmentVariableW(L"languge",mnuStr,64))//Language instartup qo'yadur;
			{	if(!wcscmp(mnuStr,L"russian"))
					wcscat(dllname,L"PlgZipStrsRus.txt");
				else if(!wcscmp(mnuStr,L"uzbekl"))
					wcscat(dllname,L"PlgZipStrsUZBL.txt");
				else if(!wcscmp(mnuStr,L"uzbekk"))
					wcscat(dllname,L"PlgZipStrsUZBK.txt");
				else//if(wcscmp(mnuStr,L"Exit")
					wcscat(dllname,L"PlgZipStrsEng.txt");
			}	
			else wcscat(dllname,L"PlgZipStrsEng.txt");

			f=_wfopen(dllname,L"r,ccs=UNICODE");
			if(f)
			{	wchar_t s[260];fwscanf(f,L"%s", s);
				if(wcscmp(s,L"Plugin")) goto NillStr;
				fwscanf(f,L"%s", s);
				if(wcscmp(s,L"mzlib32.dll")) goto NillStr;
				fwscanf(f,L"%s", s);
				if(wcscmp(s,L"Strings:")) goto NillStr;
				for(i=0; i<MAX_STRINGS; i++)
				{	int t;fwscanf_s(f,L"%d", &t);
					if(t-1!=i) goto NillStr;
					//l=fscanf(f,"%s", s);
					l=fscanLineString(f,256,s);
					strngs[i]=(wchar_t*)malloc(sizeof(wchar_t)*(l+1));
					memcpy(strngs[i],s,sizeof(wchar_t)*(l+1));
				}
				fclose(f);
			}
			else
			{
NillStr:
				l=(int)wcslen(L"Find files:")+1;
					strngs[0]=(wchar_t*)malloc(l*sizeof(wchar_t));wcscpy(strngs[0],L"Find files:");
				l=(int)wcslen(L"Filter:")+1;
					strngs[1]=(wchar_t*)malloc(l*sizeof(wchar_t));wcscpy(strngs[1],L"Filter:");
				l=(int)wcslen(L"Storage disks:")+1;
					strngs[2]=(wchar_t*)malloc(l*sizeof(wchar_t));wcscpy(strngs[2],L"Storage disks:");
				l=(int)wcslen(L"Archive root path:")+1;
					strngs[3]=(wchar_t*)malloc(l*sizeof(wchar_t));wcscpy(strngs[3],L"Archive root path:");
				l=(int)wcslen(L"Add")+1;
					strngs[4]=(wchar_t*)malloc(l*sizeof(wchar_t));wcscpy(strngs[4],L"Add");
				l=(int)wcslen(L"Find for text(separate-';'):")+1;
					strngs[5]=(wchar_t*)malloc(l*sizeof(wchar_t));wcscpy(strngs[5],L"Find for text(separate-';'):");
				l=(int)wcslen(L"1-byte")+1;
					strngs[6]=(wchar_t*)malloc(l*sizeof(wchar_t));wcscpy(strngs[6],L"1-byte");
				l=(int)wcslen(L"Upper key sensivity")+1;
					strngs[7]=(wchar_t*)malloc(l*sizeof(wchar_t));wcscpy(strngs[7],L"Upper key sensivity");
				l=(int)wcslen(L"Find for not contain text(separate-';'):")+1;
					strngs[8]=(wchar_t*)malloc(l*sizeof(wchar_t));wcscpy(strngs[8],L"Find for not contain text(separate-';'):");
				l=(int)wcslen(L"Start")+1;
					strngs[9]=(wchar_t*)malloc(l*sizeof(wchar_t));wcscpy(strngs[9],L"Start");
				l=(int)wcslen(L"OK")+1;
					strngs[10]=(wchar_t*)malloc(l*sizeof(wchar_t));wcscpy(strngs[10],L"OK");
				l=(int)wcslen(L"Cancel")+1;
					strngs[11]=(wchar_t*)malloc(l*sizeof(wchar_t));wcscpy(strngs[11],L"Cancel");
				l=(int)wcslen(L"Find for alternative name:")+1;
					strngs[12]=(wchar_t*)malloc(l*sizeof(wchar_t));wcscpy(strngs[12],L"Find for alternative name:");
				l=(int)wcslen(L"Creation date and time before:")+1;
					strngs[13]=(wchar_t*)malloc(l*sizeof(wchar_t));wcscpy(strngs[13],L"Creation date and time before:");
				l=(int)wcslen(L"Creation date and time after:")+1;
					strngs[14]=(wchar_t*)malloc(l*sizeof(wchar_t));wcscpy(strngs[14],L"Creation date and time after:");
				l=(int)wcslen(L"Creation date and time between:")+1;
					strngs[15]=(wchar_t*)malloc(l*sizeof(wchar_t));wcscpy(strngs[15],L"Creation date and time between:");
				l=(int)wcslen(L"Last access date and time before:")+1;
					strngs[16]=(wchar_t*)malloc(l*sizeof(wchar_t));wcscpy(strngs[16],L"Last access date and time before:");
				l=(int)wcslen(L"Last access date and time after:")+1;
					strngs[17]=(wchar_t*)malloc(l*sizeof(wchar_t));wcscpy(strngs[17],L"Last access date and time after:");
				l=(int)wcslen(L"Last access date and time between:")+1;
					strngs[18]=(wchar_t*)malloc(l*sizeof(wchar_t));wcscpy(strngs[18],L"Last access date and time between:");
				l=(int)wcslen(L"Last write date and time before:")+1;
					strngs[19]=(wchar_t*)malloc(l*sizeof(wchar_t));wcscpy(strngs[19],L"Last write date and time before:");
				l=(int)wcslen(L"Last write date and time after:")+1;
					strngs[20]=(wchar_t*)malloc(l*sizeof(wchar_t));wcscpy(strngs[20],L"Last write date and time after:");
				l=(int)wcslen(L"Last write date and time between:")+1;
					strngs[21]=(wchar_t*)malloc(l*sizeof(wchar_t));wcscpy(strngs[21],L"Last write date and time between:");
				l=(int)wcslen(L"File size:")+1;
					strngs[22]=(wchar_t*)malloc(l*sizeof(wchar_t));wcscpy(strngs[22],L"File size:");
				l=(int)wcslen(L"File attribute:")+1;
					strngs[23]=(wchar_t*)malloc(l*sizeof(wchar_t));wcscpy(strngs[23],L"File attribute:");
				l=(int)wcslen(L"Archive")+1;
					strngs[24]=(wchar_t*)malloc(l*sizeof(wchar_t));wcscpy(strngs[24],L"Archive");
				l=(int)wcslen(L"Compressed")+1;
					strngs[25]=(wchar_t*)malloc(l*sizeof(wchar_t));wcscpy(strngs[25],L"Compressed");
				l=(int)wcslen(L"Device")+1;
					strngs[26]=(wchar_t*)malloc(l*sizeof(wchar_t));wcscpy(strngs[26],L"Device");
				l=(int)wcslen(L"Directory")+1;
					strngs[27]=(wchar_t*)malloc(l*sizeof(wchar_t));wcscpy(strngs[27],L"Directory");
				l=(int)wcslen(L"Encrypted")+1;
					strngs[28]=(wchar_t*)malloc(l*sizeof(wchar_t));wcscpy(strngs[28],L"Encrypted");
				l=(int)wcslen(L"Hidden")+1;
					strngs[29]=(wchar_t*)malloc(l*sizeof(wchar_t));wcscpy(strngs[29],L"Hidden");
				l=(int)wcslen(L"Normal")+1;
					strngs[30]=(wchar_t*)malloc(l*sizeof(wchar_t));wcscpy(strngs[30],L"Normal");
				l=(int)wcslen(L"Not indexed")+1;
					strngs[31]=(wchar_t*)malloc(l*sizeof(wchar_t));wcscpy(strngs[31],L"Not indexed");
				l=(int)wcslen(L"Offline")+1;
					strngs[32]=(wchar_t*)malloc(l*sizeof(wchar_t));wcscpy(strngs[32],L"Offline");
				l=(int)wcslen(L"Read only")+1;
					strngs[33]=(wchar_t*)malloc(l*sizeof(wchar_t));wcscpy(strngs[33],L"Read only");
				l=(int)wcslen(L"Reparse point")+1;
					strngs[34]=(wchar_t*)malloc(l*sizeof(wchar_t));wcscpy(strngs[34],L"Reparse point");
				l=(int)wcslen(L"Sparse file")+1;
					strngs[35]=(wchar_t*)malloc(l*sizeof(wchar_t));wcscpy(strngs[35],L"Sparse file");
				l=(int)wcslen(L"System")+1;
					strngs[36]=(wchar_t*)malloc(l*sizeof(wchar_t));wcscpy(strngs[36],L"System");
				l=(int)wcslen(L"Temporary")+1;
					strngs[37]=(wchar_t*)malloc(l*sizeof(wchar_t));wcscpy(strngs[37],L"Temporary");
				l=(int)wcslen(L"Virtual")+1;
					strngs[38]=(wchar_t*)malloc(l*sizeof(wchar_t));wcscpy(strngs[38],L"Virtual");
				l=(int)wcslen(L"Enum subdirectories")+1;
					strngs[39]=(wchar_t*)malloc(l*sizeof(wchar_t));wcscpy(strngs[39],L"Enum subdirectories");
				l=(int)wcslen(L"Common parameters:")+1;
					strngs[40]=(wchar_t*)malloc(l*sizeof(wchar_t));wcscpy(strngs[40],L"Common parameters:");
				l=(int)wcslen(L"Size and time parameters:")+1;
					strngs[41]=(wchar_t*)malloc(l*sizeof(wchar_t));
						wcscpy(strngs[41],L"Size and time parameters:");
				l=(int)wcslen(L"Binary")+1;
					strngs[42]=(wchar_t*)malloc(l*sizeof(wchar_t));wcscpy(strngs[42],L"Binary");
				l=(int)wcslen(L"Stop")+1;
					strngs[43]=(wchar_t*)malloc(l*sizeof(wchar_t));wcscpy(strngs[43],L"Stop");
				l=(int)wcslen(L"Select all")+1;
					strngs[44]=(wchar_t*)malloc(l*sizeof(wchar_t));wcscpy(strngs[44],L"Stop");
				l=(int)wcslen(L"Select all fixed")+1;
					strngs[45]=(wchar_t*)malloc(l*sizeof(wchar_t));wcscpy(strngs[45],L"Select all fixed");					
				l=(int)wcslen(L"Browse")+1;
					strngs[46]=(wchar_t*)malloc(l*sizeof(wchar_t));wcscpy(strngs[46],L"Browse");					
				l=(int)wcslen(L"Edit")+1;
					strngs[47]=(wchar_t*)malloc(l*sizeof(wchar_t));wcscpy(strngs[47],L"Edit");					
				l=(int)wcslen(L"View")+1;
					strngs[48]=(wchar_t*)malloc(l*sizeof(wchar_t));wcscpy(strngs[48],L"View");					
				l=(int)wcslen(L"Error allocating memory in add file to archive")+1;
					strngs[49]=(wchar_t*)malloc(l*sizeof(wchar_t));wcscpy(strngs[49],L"Error allocating memory in add file to archive");
				l=(int)wcslen(L"Error opening")+1;
					strngs[50]=(wchar_t*)malloc(l*sizeof(wchar_t));wcscpy(strngs[50],L"Error opening");
				l=(int)wcslen(L"Error in opening for reading")+1;
					strngs[51]=(wchar_t*)malloc(l*sizeof(wchar_t));wcscpy(strngs[51],L"Error in opening for reading");
				l=(int)wcslen(L"Error in reading from")+1;
					strngs[52]=(wchar_t*)malloc(l*sizeof(wchar_t));wcscpy(strngs[52],L"Error in reading from");
				l=(int)wcslen(L"Error in writing in the zipfile")+1;
					strngs[53]=(wchar_t*)malloc(l*sizeof(wchar_t));wcscpy(strngs[53],L"Error in writing in the zipfile");
				l=(int)wcslen(L"Error in closing in the zipfile")+1;
					strngs[54]=(wchar_t*)malloc(l*sizeof(wchar_t));wcscpy(strngs[54],L"Error in closing in the zipfile");
				l=(int)wcslen(L"Error in opening in zipfile")+1;
					strngs[55]=(wchar_t*)malloc(l*sizeof(wchar_t));wcscpy(strngs[55],L"Error in opening in zipfile");
				l=(int)wcslen(L"error in closing in the zipfile")+1;
					strngs[56]=(wchar_t*)malloc(l*sizeof(wchar_t));wcscpy(strngs[56],L"error in closing in the zipfile");
				l=(int)wcslen(L"Error opening zip file")+1;
					strngs[57]=(wchar_t*)malloc(l*sizeof(wchar_t));wcscpy(strngs[57],L"Error opening zip file");
				l=(int)wcslen(L"Error unzGetGlobalInfo")+1;
					strngs[58]=(wchar_t*)malloc(l*sizeof(wchar_t));wcscpy(strngs[58],L"Error unzGetGlobalInfo");
				l=(int)wcslen(L"Error unzGetCurrentFileInfo")+1;
					strngs[59]=(wchar_t*)malloc(l*sizeof(wchar_t));wcscpy(strngs[59],L"Error unzGetCurrentFileInfo");
				l=(int)wcslen(L"Error unzGoToNextFile")+1;
					strngs[60]=(wchar_t*)malloc(l*sizeof(wchar_t));wcscpy(strngs[60],L"Error unzGoToNextFile");
				l=(int)wcslen(L"Error creating temporary file name")+1;
					strngs[61]=(wchar_t*)malloc(l*sizeof(wchar_t));wcscpy(strngs[61],L"Error creating temporary file name");
				l=(int)wcslen(L"Error open temporary file")+1;
					strngs[62]=(wchar_t*)malloc(l*sizeof(wchar_t));wcscpy(strngs[62],L"Error open temporary file");
				l=(int)wcslen(L"Error heap and map memory buffer")+1;
					strngs[63]=(wchar_t*)malloc(l*sizeof(wchar_t));wcscpy(strngs[63],L"Error heap and map memory buffer");
				l=(int)wcslen(L"Error oening internal")+1;
					strngs[64]=(wchar_t*)malloc(l*sizeof(wchar_t));wcscpy(strngs[64],L"Error oening internal");
				l=(int)wcslen(L"Error allocate memory for OpenForUnpacking")+1;
					strngs[65]=(wchar_t*)malloc(l*sizeof(wchar_t));wcscpy(strngs[65],L"Error allocate memory for OpenForUnpacking");
				l=(int)wcslen(L"Error unzGetGlobalInfo64")+1;
					strngs[66]=(wchar_t*)malloc(l*sizeof(wchar_t));wcscpy(strngs[66],L"Error unzGetGlobalInfo64");
				l=(int)wcslen(L"Error EnumDirectory$8 unzGoToFirstFile")+1;
					strngs[67]=(wchar_t*)malloc(l*sizeof(wchar_t));wcscpy(strngs[67],L"Error EnumDirectory$8 unzGoToFirstFile");
				l=(int)wcslen(L"Error EnumDirectory$8 unzGoToNextFile")+1;
					strngs[68]=(wchar_t*)malloc(l*sizeof(wchar_t));wcscpy(strngs[68],L"Error EnumDirectory$8 unzGoToNextFile");
				l=(int)wcslen(L"Error creating directory in disk:")+1;
					strngs[69]=(wchar_t*)malloc(l*sizeof(wchar_t));wcscpy(strngs[69],L"Error creating directory in disk:");
				l=(int)wcslen(L"Existing file in disk:")+1;
					strngs[70]=(wchar_t*)malloc(l*sizeof(wchar_t));wcscpy(strngs[70],L"Existing file in disk:");
				l=(int)wcslen(L"File in archive:")+1;
					strngs[71]=(wchar_t*)malloc(l*sizeof(wchar_t));wcscpy(strngs[71],L"File in archive:");
				l=(int)wcslen(L"Size in bytes:")+1;
					strngs[72]=(wchar_t*)malloc(l*sizeof(wchar_t));wcscpy(strngs[72],L"Size in bytes:");
				l=(int)wcslen(L"Write time:")+1;
					strngs[73]=(wchar_t*)malloc(l*sizeof(wchar_t));wcscpy(strngs[73],L"Write time:");
				l=(int)wcslen(L"------------------------------------------------- Choise next action: --------------------------------------------------")+1;
					strngs[74]=(wchar_t*)malloc(l*sizeof(wchar_t));wcscpy(strngs[74],L"------------------------------------------------- Choise next action: --------------------------------------------------");
				l=(int)wcslen(L"Rename")+1;
					strngs[75]=(wchar_t*)malloc(l*sizeof(wchar_t));wcscpy(strngs[75],L"Rename");
				l=(int)wcslen(L"Overwrite latest in future")+1;
					strngs[76]=(wchar_t*)malloc(l*sizeof(wchar_t));wcscpy(strngs[76],L"Overwrite latest in future");
				l=(int)wcslen(L"Overwrite oldest in future")+1;
					strngs[77]=(wchar_t*)malloc(l*sizeof(wchar_t));wcscpy(strngs[77],L"Overwrite oldest in future");
				l=(int)wcslen(L"Overwrite biggest in future")+1;
					strngs[78]=(wchar_t*)malloc(l*sizeof(wchar_t));wcscpy(strngs[78],L"Overwrite biggest in future");
				l=(int)wcslen(L"Auto rename in future")+1;
					strngs[79]=(wchar_t*)malloc(l*sizeof(wchar_t));wcscpy(strngs[79],L"Auto rename in future");					
				l=(int)wcslen(L"Skip in future")+1;
					strngs[80]=(wchar_t*)malloc(l*sizeof(wchar_t));wcscpy(strngs[80],L"Skip in future");
				l=(int)wcslen(L"Overwrite in future")+1;
					strngs[81]=(wchar_t*)malloc(l*sizeof(wchar_t));wcscpy(strngs[81],L"Overwrite in future");
				l=(int)wcslen(L"Overwrite littlest in future")+1;
					strngs[82]=(wchar_t*)malloc(l*sizeof(wchar_t));wcscpy(strngs[82],L"Overwrite littlest in future");
				l=(int)wcslen(L"Overwrite latest")+1;
					strngs[83]=(wchar_t*)malloc(l*sizeof(wchar_t));wcscpy(strngs[83],L"Overwrite latest");				
				l=(int)wcslen(L"Overwrite oldest")+1;
					strngs[84]=(wchar_t*)malloc(l*sizeof(wchar_t));wcscpy(strngs[84],L"Overwrite oldest");				
				l=(int)wcslen(L"Overwrite biggest")+1;
					strngs[85]=(wchar_t*)malloc(l*sizeof(wchar_t));wcscpy(strngs[85],L"Overwrite biggest");				
				l=(int)wcslen(L"Skip")+1;
					strngs[86]=(wchar_t*)malloc(l*sizeof(wchar_t));wcscpy(strngs[86],L"Skip");				
				l=(int)wcslen(L"Overwrite")+1;
					strngs[87]=(wchar_t*)malloc(l*sizeof(wchar_t));wcscpy(strngs[87],L"Overwrite");
				l=(int)wcslen(L"Overwrite littlest")+1;
					strngs[88]=(wchar_t*)malloc(l*sizeof(wchar_t));wcscpy(strngs[88],L"Overwrite littlest");
				l=(int)wcslen(L"This file already exist in disk ...")+1;
					strngs[89]=(wchar_t*)malloc(l*sizeof(wchar_t));wcscpy(strngs[89],L"This file already exist in disk ...");
				l=(int)wcslen(L"Enter password, please:")+1;
					strngs[90]=(wchar_t*)malloc(l*sizeof(wchar_t));wcscpy(strngs[90],L"Enter password, please:");
				l=(int)wcslen(L"Error creating file in disk.")+1;
					strngs[91]=(wchar_t*)malloc(l*sizeof(wchar_t));wcscpy(strngs[91],L"Error creating file in disk.");
				l=(int)wcslen(L"Sino-Zip archiver plugin options")+1;
					strngs[92]=(wchar_t*)malloc(l*sizeof(wchar_t));wcscpy(strngs[92],L"Sino-Zip archiver plugin options.");
				l=(int)wcslen(L"Authors:")+1;
					strngs[93]=(wchar_t*)malloc(l*sizeof(wchar_t));wcscpy(strngs[93],L"Authors:");
				l=(int)wcslen(L"Builded for SINO:")+1;
					strngs[94]=(wchar_t*)malloc(l*sizeof(wchar_t));wcscpy(strngs[94],L"Builded for SINO:");
			}
			break;
		case DLL_THREAD_ATTACH:
			break;
		case DLL_THREAD_DETACH:
			break;
		case DLL_PROCESS_DETACH:
			if(strngs)
			{	for(i=0; i<MAX_STRINGS; i++)
					free(strngs[i]);
				free(strngs);
				FreeFindData();
				saveOpt();
				strngs=NULL;
			}
			break;
	}
	return TRUE;
}