#define _CRT_SECURE_NO_WARNINGS
#define FOPEN_FUNC(filename, mode) fopen64(filename, mode)
#define FTELLO_FUNC(stream) ftello64(stream)
#define FSEEKO_FUNC(stream, offset, origin) fseeko64(stream, offset, origin)

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <errno.h>
#include <fcntl.h>

#include <direct.h>
#include <io.h>
#include "zip.h"
#include "unzip.h"

#define USEWIN32IOAPI
#include "iowin32.h"


unsigned __int64* ZipTimeToUInt64(tm_unz *tm)
{
static unsigned __int64 t;
	SYSTEMTIME st={	tm->tm_year,
					tm->tm_mon,
					tm->tm_mday,//of week
					tm->tm_mday,
					tm->tm_hour,
					tm->tm_min,
					tm->tm_sec,
					tm->tm_sec };//millisecond
	FILETIME ft;SystemTimeToFileTime(&st,&ft);
	t=(unsigned __int64)ft.dwHighDateTime<<32 | (unsigned __int64)ft.dwLowDateTime;
	return &t;
}

FILETIME* ZipTimeToFileTime(tm_unz *tm)
{
static FILETIME t;
	SYSTEMTIME st={	tm->tm_year,
					tm->tm_mon,
					tm->tm_mday,//of week
					tm->tm_mday,
					tm->tm_hour,
					tm->tm_min,
					tm->tm_sec,
					tm->tm_sec };//millisecond
	SystemTimeToFileTime(&st,&t);
	return &t;
}

unsigned __int64* ZipFileTimeToUint64(unsigned int filedate,
									  unsigned int filetime,
									  tm_unz *tmunzp)
{
    //uLong year = (uLong)ptm->tm_year;
    //if (year>=1980)
    //    year-=1980;
    //else if (year>=80)
    //    year-=80;
    //return
    //  (uLong) (((ptm->tm_mday) + (32 * (ptm->tm_mon+1)) + (512 * year)) << 16) |
    //    ((ptm->tm_sec/2) + (32* ptm->tm_min) + (2048 * (uLong)ptm->tm_hour));
	tmunzp->tm_mday = (uInt) (filedate&0x1f);
	tmunzp->tm_mon  = (uInt) ((((filedate)&0x1E0)/0x20)-1);
	tmunzp->tm_year = (uInt) (((filedate&0x0FE00)/0x0200) + 1980) ;
	tmunzp->tm_hour = (uInt) ((filetime &0xF800)/0x800);
	tmunzp->tm_min  = (uInt) ((filetime&0x7E0)/0x20) ;
	tmunzp->tm_sec  = (uInt) (2*(filetime&0x1f)) ; 
	return ZipTimeToUInt64(tmunzp);
}

uLong filetime(wchar_t *f, tm_zip *tmzip,uLong *dt)
             /* name of file to get info on */
             /* return value: access, modific. and creation times */
             /* dostime */
{
	int ret = 0;
	FILETIME ftLocal;
	HANDLE hFind;
	WIN32_FIND_DATA ff32;

	hFind = FindFirstFile((wchar_t*)f,&ff32);
	if (hFind != INVALID_HANDLE_VALUE)
	{	FileTimeToLocalFileTime(&(ff32.ftLastWriteTime),&ftLocal);
		FileTimeToDosDateTime(&ftLocal,(LPWORD)dt+1,(LPWORD)dt);
		FindClose(hFind);
		ret = 1;
	}
	return ret;
}

/*int check_exist_file(const wchar_t *filename)
{
	FILE* ftestexist;
    int ret = 1;
    ftestexist = FOPEN_FUNC(filename,L"rb");
    if(ftestexist==NULL)
        ret = 0;
    else
        fclose(ftestexist);
    return ret;
}*/

/*void do_banner()
{
    printf("MiniZip 1.1, demo of zLib + MiniZip64 package, written by Gilles Vollant\n");
    printf("more info on MiniZip at http://www.winimage.com/zLibDll/minizip.html\n\n");
}

void do_help()
{
    printf("Usage : minizip [-o] [-a] [-0 to -9] [-p password] [-j] file.zip [files_to_add]\n\n" \
           "  -o  Overwrite existing file.zip\n" \
           "  -a  Append to existing file.zip\n" \
           "  -0  Store only\n" \
           "  -1  Compress faster\n" \
           "  -9  Compress better\n\n" \
           "  -j  exclude path. store only the file name.\n\n");
}*/

/* calculate the CRC32 of a file,
   because to encrypt a file, we need known the CRC32 of the file before */
int getFileCrc(const wchar_t* fullPathAndName,void*buf,unsigned long size_buf,unsigned long* result_crc)
{
	unsigned long calculate_crc=0;
	int err=ZIP_OK;
	FILE * fin = FOPEN_FUNC((wchar_t*)fullPathAndName,L"rb");

	unsigned long size_read = 0;
	unsigned long total_read = 0;
	if(fin==NULL)
	{
		err = ZIP_ERRNO;
	}

	if(err == ZIP_OK)
	{	do
		{
			err = ZIP_OK;
			size_read = (int)fread(buf,1,size_buf,fin);
			if (size_read < size_buf)
			if (feof(fin)==0)
				err = ZIP_ERRNO;

			if (size_read>0)
				calculate_crc = crc32(calculate_crc,(const Bytef*)buf,size_read);
			total_read += size_read;

		} while ((err == ZIP_OK) && (size_read>0));
	}

	if (fin)
        fclose(fin);

    *result_crc=calculate_crc;
    return err;
}

int MyGetFileCrcAndSize(const wchar_t* fullPathAndName,void*buf,
						unsigned long size_buf,unsigned long* result_crc,
						unsigned __int64 *getSize)
{
	unsigned long calculate_crc=0;
	int err=ZIP_OK;
	FILE * fin = FOPEN_FUNC(fullPathAndName,L"rb");

	unsigned long size_read = 0;
	*getSize = 0;
	if(fin==NULL)
		err = ZIP_ERRNO;

	if(err == ZIP_OK)
	{	do
		{	err = ZIP_OK;
			size_read = (int)fread(buf,1,size_buf,fin);
			if (size_read < size_buf)
			if (feof(fin)==0)
				err = ZIP_ERRNO;

			if (size_read>0)
			{	calculate_crc = crc32(calculate_crc,(const Bytef*)buf,size_read);
				(*getSize) += size_read;
			}

		} while ((err == ZIP_OK) && (size_read>0));
	}

	if (fin)
        fclose(fin);

    *result_crc=calculate_crc;
    return err;
}

int isLargeFile(const wchar_t* filename)
{
	int largeFile = 0;
	ZPOS64_T pos = 0;
	FILE* pFile = FOPEN_FUNC((wchar_t*)filename, L"rb");

	if(pFile != NULL)
	{	int n = FSEEKO_FUNC(pFile, 0, SEEK_END);
		pos = FTELLO_FUNC(pFile);
        //printf("File : %s is %lld bytes\n", filename, pos);

		if(pos >= 0xffffffff)
			largeFile = 1;

		fclose(pFile);
	}

	return largeFile;
}

__int64 getFileSize(const wchar_t* filename)
{
  ZPOS64_T pos = 0;
  FILE* pFile = FOPEN_FUNC(filename, L"rb");

  if(pFile != NULL)
  {
    int n = FSEEKO_FUNC(pFile, 0, SEEK_END);
    pos = FTELLO_FUNC(pFile);

                //printf("File : %s is %lld bytes\n", filename, pos);

    fclose(pFile);
  }

 return (__int64)pos;
}

void msg0(DWORD e,LPTSTR msg1)
{ 
    // Retrieve the system error message for the last-error code

    LPVOID lpMsgBuf;
    LPVOID lpDisplayBuf;
	DWORD dw = (e==(DWORD)(-1))?GetLastError():e;

    FormatMessageA(
        FORMAT_MESSAGE_ALLOCATE_BUFFER | 
        FORMAT_MESSAGE_FROM_SYSTEM |
        FORMAT_MESSAGE_IGNORE_INSERTS,
        NULL,
        dw,
        MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
        (LPSTR) &lpMsgBuf,
        0, NULL );

    // Display the error message and exit the process

    lpDisplayBuf = (LPVOID)LocalAlloc(LMEM_ZEROINIT, 
        (lstrlen((LPCTSTR)lpMsgBuf)+40)*sizeof(TCHAR)); 
    sprintf_s(lpDisplayBuf, 
        LocalSize(lpDisplayBuf),
        "Failed with error %d: %s",
        dw, lpMsgBuf); 
    MessageBoxA(NULL, lpDisplayBuf, (LPCSTR)msg1, MB_OK|MB_ICONWARNING|MB_SYSTEMMODAL); 


    LocalFree(lpMsgBuf);
    LocalFree(lpDisplayBuf);
    //ExitProcess(dw); 
}

void msg(HWND prnt,DWORD e,LPTSTR lpszFunction,LPTSTR msg1)
{ 
    // Retrieve the system error message for the last-error code

    LPVOID lpMsgBuf;
    LPVOID lpDisplayBuf;
	DWORD dw = (e==(DWORD)(-1))?GetLastError():e;

    FormatMessageA(
        FORMAT_MESSAGE_ALLOCATE_BUFFER | 
        FORMAT_MESSAGE_FROM_SYSTEM |
        FORMAT_MESSAGE_IGNORE_INSERTS,
        NULL,
        dw,
        MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
        (LPSTR) &lpMsgBuf,
        0, NULL );

    // Display the error message and exit the process

    lpDisplayBuf = (LPVOID)LocalAlloc(LMEM_ZEROINIT, 
        (lstrlen((LPCTSTR)lpMsgBuf)+lstrlen((LPCTSTR)lpszFunction)+40)*sizeof(TCHAR)); 
    sprintf_s(lpDisplayBuf, 
        LocalSize(lpDisplayBuf),
        "%s failed with error %d: %s",
        lpszFunction, dw, lpMsgBuf); 
    MessageBoxA(prnt, lpDisplayBuf, (LPCSTR)msg1, MB_OK|MB_ICONWARNING|MB_SYSTEMMODAL); 


    LocalFree(lpMsgBuf);
    LocalFree(lpDisplayBuf);
    //ExitProcess(dw); 
}

void msgWA(DWORD e,LPWSTR lpszFunction,LPTSTR msg1)
{ 
    // Retrieve the system error message for the last-error code
char lpszFunctionA[MAX_PATH];
    LPVOID lpMsgBuf;
    LPVOID lpDisplayBuf;
	DWORD dw = (e==(DWORD)(-1))?GetLastError():e;

    FormatMessageA(
        FORMAT_MESSAGE_ALLOCATE_BUFFER | 
        FORMAT_MESSAGE_FROM_SYSTEM |
        FORMAT_MESSAGE_IGNORE_INSERTS,
        NULL,
        dw,
        MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
        (LPSTR)&lpMsgBuf,
        0, NULL );

    // Display the error message and exit the process
	WideCharToMultiByte(CP_OEMCP,0,lpszFunction,-1,lpszFunctionA,MAX_PATH-1,NULL,NULL);
    lpDisplayBuf = (LPVOID)LocalAlloc(LMEM_ZEROINIT, 
        (lstrlen((LPCTSTR)lpMsgBuf)+wcslen(lpszFunction)+40)*sizeof(TCHAR)); 
    sprintf_s(lpDisplayBuf, 
        LocalSize(lpDisplayBuf),
        "%s failed with error %d: %s", 
        lpszFunctionA, dw, lpMsgBuf); 
    MessageBoxA(NULL, lpDisplayBuf, (LPCSTR)msg1, MB_OK|MB_ICONWARNING|MB_SYSTEMMODAL); 


    LocalFree(lpMsgBuf);
    LocalFree(lpDisplayBuf);
    //ExitProcess(dw); 
}

void msgWW(DWORD e,LPWSTR lpszFunction,LPWSTR msg1)
{LPVOID lpMsgBuf;LPVOID lpDisplayBuf;
 DWORD dw = (e==(DWORD)(-1))?GetLastError():e;

    FormatMessageW(
        FORMAT_MESSAGE_ALLOCATE_BUFFER | 
        FORMAT_MESSAGE_FROM_SYSTEM |
        FORMAT_MESSAGE_IGNORE_INSERTS,
        NULL,
        dw,
        MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
        (LPWSTR) &lpMsgBuf,
        0, NULL );

    // Display the error message and exit the process
    lpDisplayBuf = (LPVOID)LocalAlloc(LMEM_ZEROINIT, 
        (wcslen(lpMsgBuf)+wcslen(lpszFunction)+40)*sizeof(WCHAR)); 
    swprintf(lpDisplayBuf,
        L"%s failed with error %d: %s",
        lpszFunction, dw, lpMsgBuf); 
    MessageBoxW(NULL, (LPCWSTR)lpDisplayBuf, msg1, MB_OK|MB_ICONWARNING|MB_SYSTEMMODAL); 


    LocalFree(lpMsgBuf);
    LocalFree(lpDisplayBuf);
    //ExitProcess(dw); 
}

int zstrstr_slash(char *st1,char *st2)
{
	while((*st1) || (*st2))
	{	if(0==(*st2))
			break;//ret true;
		if(0==(*st1))
			return 0;//ret true;
		if((*st1) != (*st2))
		{	if('\\' != (*st1) &&'/' != (*st1))
			if('\\' != (*st2) &&'/' != (*st2))
				return 0;
		}
		++st1;
		++st2;
	}
	return 1;
}

char* zstrrchr2_excl_end(char *st,char ch1,char ch2)
{
char *pend,*pst=st;
	while(*pst)++pst;
	pend=pst-1;

	while(pst>st)
	{	if(ch1==(*pst) || ch2==(*pst))
		{	if(pst==pend)
			{	if(ch1!=(*pend) && ch2!=(*pend))
					return pst;				
			}
			else return pst;
		}
		--pst;
	}
	return pst;
}