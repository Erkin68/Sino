//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by mzlib32.rc
//
#define IDD_DIALOG_OPTIONS              103
#define IDR_SFX_EXE                     104
#define IDC_STATIC1                     21570
#define IDC_STATIC2                     21571
#define IDC_STATIC3                     21572
#define IDC_STATIC5                     21573
#define IDC_STATIC4                     21574
#define IDC_STATIC6                     21575
#define IDC_STATIC7                     21576
#define IDC_STATIC8                     21577
#define IDC_STATIC9                     21578
#define IDC_STATIC10                    21579
#define IDC_STATIC11                    21580
#define IDC_STATIC12                    21581
#define IDC_STATIC13                    21582
#define IDC_STATIC14                    21583
#define IDC_STATIC15                    21584
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        306
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1034
#define _APS_NEXT_SYMED_VALUE           307
#endif
#endif
