//1-global namespaceda turishi shart:
#include "Plugins_CPP.h"
#include "resource.h"
#include "strsafe.h"
#include "..\..\..\Operations\MyShell\MyShell.h"



extern "C" {
extern wchar_t **strngs;
extern HMODULE plgnDllInst;
extern int  plgId;
extern int	MyStringCpySlashA(char*,int,char*);
extern BOOL strstrslashA(char*,char*);
extern void msg(HWND,DWORD,LPTSTR,LPTSTR);

extern int readheader(chmfile*);
extern int readhsectable(chmfile*);
extern int read_chm_dir(chmfile*);
extern int readcontsecs(chmfile*);
extern int chm_getfile(chmfile*,char*,ulong*,ubyte**);
extern BOOL FindDir(chmfile*,int,char*,int);

INT_PTR CALLBACK ExstngActnDlgProc(HWND,UINT,WPARAM,LPARAM);

typedef void (*UnpackProgressRoutine_t)(unsigned __int64,unsigned __int64,wchar_t*);

checkFileInSelctn_t checkFileInSelctn;
excldFileFrSelctn_t excldFileFrSelctn;
getFileInfoFromSelection_t getFileInfoFromSelection;
prgrssRout_t prgrssRout;
showDlgOverwriteExistFile_t showDlgOverwriteExistFile;
saveOptions_t saveOptions;
readOptions_t readOptions;
addItemToPanelList_t addItemToPanelList;


__declspec (dllexport) BOOL Close$4(PluginObj *plg)
{
	if(PluginObj::unpack==plg->packType)//plg->unexef)
	{	CloseHandle(plg->unchmf->cf);
		for(int i=0; i<plg->unchmf->cs->nentries; i++)
		{	if(plg->unchmf->cs->entry[i].cache)
				free(plg->unchmf->cs->entry[i].cache);
		}
		free(plg->unchmf->cs);
		free(plg->unchmf->dir);
	}
	else if(PluginObj::pack==plg->packType)//plg->exef)
	{	CloseHandle(plg->chmf);		
		for(int i=0; i<plg->unchmf->cs->nentries; i++)
		{	if(plg->unchmf->cs->entry[i].cache)
				free(plg->unchmf->cs->entry[i].cache);
		}
		free(plg->unchmf->cs);
		free(plg->unchmf->dir);
	}
	free(plg);
	return TRUE;
}

__declspec (dllexport) int GetPluginType()
{
	return 3;
}

__declspec (dllexport) const wchar_t* GetPluginDescription()
{
	return strngs[23];//"Sino chm-plugin version 1.1";
}

__declspec (dllexport) const wchar_t* GetPluginName()
{
	return strngs[0];
}

__declspec (dllexport) const wchar_t *GetArchExtnsn()
{
	return L"chm";
}

__declspec (dllexport) BOOL CreateDir$24(PluginObj *plg,wchar_t *FullPathAndName,wchar_t *RelatedPathAndName,
										 wchar_t *password,int compress_level,BOOL bExcldPath)
{
	return TRUE;
}

__declspec (dllexport) BOOL RenameDir$12(PluginObj *plg,wchar_t *FName,wchar_t *FNewName)
{
	return TRUE;
}

__declspec (dllexport) BOOL DeleteDir$8(PluginObj *plg,wchar_t *FName)
{
	return TRUE;
}

void saveOpt()
{	
	//saveOptions(plgId,&item,sizeof(item));
}

__declspec (dllexport) void SetId$4(int id)
{
	plgId = id;
	//readOptions(id,&item,sizeof(item));
}

__declspec (dllexport) VOID SetCallbacks$4xxx(LPVOID frstCallback,...)
{
va_list args;
	va_start(args, frstCallback);//1
	checkFileInSelctn = (checkFileInSelctn_t)frstCallback;//2
	excldFileFrSelctn = (excldFileFrSelctn_t)va_arg(args, LPVOID);//3
	getFileInfoFromSelection = (getFileInfoFromSelection_t)va_arg(args, LPVOID);//4
	prgrssRout = (prgrssRout_t)va_arg(args, LPVOID);//5
	showDlgOverwriteExistFile = (showDlgOverwriteExistFile_t)va_arg(args, LPVOID);//6
	saveOptions = (saveOptions_t)va_arg(args, LPVOID);//7
	readOptions = (readOptions_t)va_arg(args, LPVOID);//8
	addItemToPanelList = (addItemToPanelList_t)va_arg(args, LPVOID);//9
va_end (args);
}

BOOL IsThisValidChmFile(HANDLE hFile)
{
DWORD rd;
	unsigned __int32 itsf;ReadFile(hFile,&itsf,sizeof(__int32),&rd,NULL);
	if(rd!=sizeof(__int32) || itsf!=0x46535449)
		return FALSE;
	unsigned __int32 version;ReadFile(hFile,&version,sizeof(__int32),&rd,NULL);
	if(rd!=sizeof(__int32))
		return FALSE;
	unsigned __int32 headerSize;ReadFile(hFile,&headerSize,sizeof(__int32),&rd,NULL);
	if(rd!=sizeof(__int32))
		return FALSE;
	if(headerSize != 0x60)
		return FALSE;
	unsigned __int32 unknown1; ReadFile(hFile,&unknown1,sizeof(__int32),&rd,NULL);
	if(rd!=sizeof(__int32))
		return FALSE;
	if (unknown1 != 0 && unknown1 != 1) // it's 0 in one .sll file
		return FALSE;
	ReadFile(hFile,&unknown1,sizeof(__int32),&rd,NULL);
	ReadFile(hFile,&unknown1,sizeof(__int32),&rd,NULL);
	DWORD Guid[8];ReadFile(hFile,Guid,8*sizeof(DWORD),&rd,NULL);
	if(Guid[0]!=0x7C01FD10) return FALSE;
	if(Guid[1]!=0x11d07baa) return FALSE;
	if(Guid[2]!=0xa0000c9e) return FALSE;
	if(Guid[3]!=0xece622c9) return FALSE;
	if(Guid[4]!=0x7c01fd11) return FALSE;
	if(Guid[5]!=0x11d07baa) return FALSE;
	if(Guid[6]!=0xa0000c9e) return FALSE;
	if(Guid[7]!=0xece622c9) return FALSE;
	return TRUE;
}

__declspec (dllexport) LPVOID Open$12(wchar_t *name,BOOL bCreateNew,LPVOID host)
{
int nameLn;PluginObj *plg;
HANDLE h=CreateFile(name,GENERIC_WRITE,FILE_SHARE_WRITE,NULL,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,NULL);
	if( INVALID_HANDLE_VALUE==h)return NULL;
	if(!IsThisValidChmFile(h)) {CloseHandle(h);return NULL;}
	plg=(PluginObj*)malloc(sizeof(PluginObj));
	if(!plg)
	{	msg(NULL,0,strngs[2],name);
		return NULL;
	}
	plg->host = host;
    plg->unchmf = (chmfile*)calloc(1, sizeof(chmfile));
	plg->unchmf->cf = h;
    readheader(plg->unchmf);
    readhsectable(plg->unchmf);
    read_chm_dir(plg->unchmf);
    readcontsecs(plg->unchmf);
	nameLn = MyStringCpy(plg->chmFileName,MAX_PATH-1,name);
	/*plg->bOvwrtLtst 	= 0;
	plg->bOvwrtOldst	= 0;
	plg->bOvwrtBigst	= 0;
	plg->bRename	   	= 0;
	plg->bSkip	   		= 0;
	plg->bOvwrt     	= 0;
	plg->bOvwrtLtlst	= 0;
	plg->bOvwrtLtstAll	= 0;
	plg->bOvwrtOldstAll	= 0;
	plg->bOvwrtBigstAll	= 0;
	plg->bRenameAll		= 0;
	plg->bSkipAll		= 0;
	plg->bOvwrtAll		= 0;
	plg->bOvwrtLtlstAll	= 0;*/
	plg->bools=0;
	plg->packType=PluginObj::pack;//Close uchun;
	return plg;
}

__declspec (dllexport) LPVOID OpenForUnpacking$8(wchar_t *name,LPVOID host)//host - CArc;
{
int nameLn;PluginObj *plg;
HANDLE h=CreateFile(name,GENERIC_READ,FILE_SHARE_READ,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);
	if( INVALID_HANDLE_VALUE==h)return NULL;
	if(!IsThisValidChmFile(h)) {CloseHandle(h);return NULL;}

	plg=(PluginObj*)malloc(sizeof(PluginObj));
	if(!plg)
	{	msg(NULL,0,strngs[2]/*"Err.opening zip file."*/,name);//"error %d with zipfile in unzGetGlobalInfo \n",err);
		return NULL;
	}
	plg->host = host;
    plg->unchmf = (chmfile*)calloc(1, sizeof(chmfile));
	plg->unchmf->cf = h;
    readheader(plg->unchmf);
    readhsectable(plg->unchmf);
    read_chm_dir(plg->unchmf);
    readcontsecs(plg->unchmf);

	nameLn=MyStringCpy(plg->unchmFileName,MAX_PATH-1,name);
	/*plg->bOvwrtLtst 	= 0;
	plg->bOvwrtOldst	= 0;
	plg->bOvwrtBigst	= 0;
	plg->bRename	   	= 0;
	plg->bSkip	   		= 0;
	plg->bOvwrt     	= 0;
	plg->bOvwrtLtlst	= 0;
	plg->bOvwrtLtstAll	= 0;
	plg->bOvwrtOldstAll	= 0;
	plg->bOvwrtBigstAll	= 0;
	plg->bRenameAll		= 0;
	plg->bSkipAll		= 0;
	plg->bOvwrtAll		= 0;
	plg->bOvwrtLtlstAll	= 0;*/
	plg->bools=0;
	plg->packType=PluginObj::unpack;//Close uchun;

/*	if(plg->unchmf->ch.unk_guid1.guid1!=0x7C01FD10)
	if(plg->unchmf->ch.unk_guid1.guid2[0]!=0x7BAA)
	if(plg->unchmf->ch.unk_guid1.guid2[1]!=0x11D0)
	if(plg->unchmf->ch.unk_guid1.guid3[0]!=0x9e)
	if(plg->unchmf->ch.unk_guid1.guid3[1]!=0x0c)
	if(plg->unchmf->ch.unk_guid1.guid3[2]!=0x00)
	if(plg->unchmf->ch.unk_guid1.guid3[3]!=0xa0)
	if(plg->unchmf->ch.unk_guid1.guid3[4]!=0xc9)
	if(plg->unchmf->ch.unk_guid1.guid3[5]!=0x22)
	if(plg->unchmf->ch.unk_guid1.guid3[6]!=0xe6)
	if(plg->unchmf->ch.unk_guid1.guid3[7]!=0xec)

	if(plg->unchmf->ch.unk_guid2.guid1!=0x7C01FD11)
	if(plg->unchmf->ch.unk_guid2.guid2[0]!=0x7BAA)
	if(plg->unchmf->ch.unk_guid2.guid2[1]!=0x11D0)
	if(plg->unchmf->ch.unk_guid2.guid3[0]!=0x9e)
	if(plg->unchmf->ch.unk_guid2.guid3[1]!=0x0c)
	if(plg->unchmf->ch.unk_guid2.guid3[2]!=0x00)
	if(plg->unchmf->ch.unk_guid2.guid3[3]!=0xa0)
	if(plg->unchmf->ch.unk_guid2.guid3[4]!=0xc9)
	if(plg->unchmf->ch.unk_guid2.guid3[5]!=0x22)
	if(plg->unchmf->ch.unk_guid2.guid3[6]!=0xe6)
	if(plg->unchmf->ch.unk_guid2.guid3[7]!=0xec)*/

    return plg;
}

__declspec (dllexport) BOOL Add$24(PluginObj *plg,wchar_t *FullPathAndName,wchar_t *RelatedPathAndName,
								   wchar_t *password,int compress_level,BOOL bExcldPath)
{
//	Close$4(plg);
//	hUpdRes = BeginUpdateResource(plg->exeFileName,FALSE);
//	prelext=strrchr(RelatedPathAndName,'\\');
//	if(prelext)++prelext;
//	else prelext=RelatedPathAndName;
//	r=UpdateResource(hUpdRes,RT_RCDATA,prelext,lid,buf,sz);
//	EndUpdateResource(hUpdRes,FALSE);
//	Open$12(plg->chmFileName,FALSE,plg->host);
//	free(buf);
	return TRUE;
}

__declspec (dllexport) BOOL RebuildCheckExistings$8(PluginObj *plg,wchar_t *password)
{
	return TRUE;
}

__declspec (dllexport) BOOL RenameFile$12(PluginObj *plg,wchar_t *FName,wchar_t *FNewName)
{
//	Close$4(plg);
//	hUpdRes = BeginUpdateResource(plg->exeFileName,FALSE);
//	r=UpdateResource(hUpdRes,GetResNameLPCTSTR(iResType),iRes?MAKEINTRESOURCE(iRes):pResName,lid,NULL,0);
//	if(*FNewName=='#')iRes = atoi(FNewName+1);
//	r|=UpdateResource(hUpdRes,GetResNameLPCTSTR(iResType),iRes?MAKEINTRESOURCE(iRes):FNewName,lid,buf,sz);
//	EndUpdateResource(hUpdRes,FALSE);
//	Open$12(plg->chmFileName,FALSE,plg->host);
//	free(buf);
	return TRUE;
}

__declspec (dllexport) BOOL DeleteFile$8(PluginObj *plg,wchar_t *FName)
{
/*	Close$4(plg);

DWORD rd;HANDLE f;
int namelen;char *rel;ulong length;ubyte *outbuf;
int dirlen=MyStringLength(arjDirAndName,MAX_PATH);
char *pd=strrchr(destDirName,'\\');
	if(pd)*pd=0;
	for(int i=0; i<plg->unchmf->dir->nentries; i++)
	{	if(plg->unchmf->dir->entry[i].name[0] == '/')
		{	namelen = strlen(plg->unchmf->dir->entry[i].name);
			if(namelen == 1) continue;// skip the slash
			rel = plg->unchmf->dir->entry[i].name + 1;
			if(!strstrslash(rel,arjDirAndName)) continue;
			if('\\'!=rel[dirlen])
			if('/'!=rel[dirlen])
			if(0!=rel[dirlen])
				continue;
			f=mfilecrdir(plg,prntDlg,destDirName,rel,bCancel);
			if(!f)continue;
			chm_getfile(plg->unchmf, plg->unchmf->dir->entry[i].name, &length, &outbuf);
			WriteFile(f,outbuf,length,&rd,NULL);
			if(outbuf)free(outbuf);
			CloseHandle(f);
	}	}
	if(pd)*pd='\\';
	return TRUE;

	Open$12(plg->chmFileName,FALSE,plg->host);*/
	return TRUE;
}

__declspec (dllexport) BOOL EnumDirectory$8(PluginObj *plg, wchar_t *DirNameW)
{
WIN32_FIND_DATA ff;wchar_t tmp[MAX_PATH];
int namelen;char dirname[MAX_PATH],DirName[MAX_PATH],*rel;
int iEndSlash=0,DirNameLn=WideCharToMultiByte(AreFileApisANSI()?CP_ACP:CP_OEMCP,0,DirNameW,-1,DirName,MAX_PATH,NULL,NULL);
if(DirNameLn)--DirNameLn;

	if('\\'==DirName[DirNameLn-1] || '/'==DirName[DirNameLn-1]){--DirNameLn;iEndSlash=1;}
	ff.nFileSizeHigh=0;
	for(int i=0; i<plg->unchmf->dir->nentries; i++)
	{	if(plg->unchmf->dir->entry[i].name[0] == '/')
		{	namelen = (int)strlen(plg->unchmf->dir->entry[i].name);
			if(namelen == 1) continue; /* skip the slash */
			rel = plg->unchmf->dir->entry[i].name + 1;
			if(plg->unchmf->dir->entry[i].name[namelen-1] == '/')
			{	MyStringCpyA(dirname,namelen-1,rel);//strncpy(dirname, rel, namelen-1);//-2 edi
				dirname[namelen-1] = 0;//-2 edi
			}
			else MyStringCpyA(dirname,MAX_PATH,rel);//strcpy(dirname, rel);
			ff.nFileSizeLow=plg->unchmf->dir->entry[i].length;

			if(0==(*DirName))//root dir;
			{	char *pnm=strchr(dirname,'\\');char *pnk=strchr(dirname,'/');
				if(pnm && pnk){if(pnk>pnm)pnm=pnk;}
				else if(!pnm) pnm = pnk;
				if(pnm)//find directory:
				{	if(FindDir(plg->unchmf,i-1,dirname,(int)(pnm-&dirname[0]))) continue;
					ff.dwFileAttributes=FILE_ATTRIBUTE_DIRECTORY;
					*pnm = 0;
					MultiByteToWideChar(AreFileApisANSI()?CP_ACP:CP_OEMCP,MB_PRECOMPOSED,dirname,-1,tmp,MAX_PATH-1);
					addItemToPanelList(plg->host,tmp,&ff);//dirname
					//*pnm = '\\';
				}
				else
				{	ff.dwFileAttributes=0;
					MultiByteToWideChar(AreFileApisANSI()?CP_ACP:CP_OEMCP,MB_PRECOMPOSED,dirname,-1,tmp,MAX_PATH-1);
					addItemToPanelList(plg->host,tmp,&ff);//dirname
			}	}
			else
			{	char *pnm,*pnk;
				if(namelen-1<=DirNameLn+iEndSlash) continue;
				if(!MyStrCmpNA(dirname,DirName,DirNameLn)) continue;
				pnm=strchr(&dirname[0]+DirNameLn+iEndSlash,'\\');pnk=strchr(&dirname[0]+DirNameLn+iEndSlash,'/');
				if(pnm && pnk){if(pnk>pnm)pnm=pnk;}
				else if(!pnm) pnm = pnk;

				if(pnm)//find directory:
				{	if(FindDir(plg->unchmf,i,dirname,(int)(pnm-&dirname[0]))) continue;
					ff.dwFileAttributes=FILE_ATTRIBUTE_DIRECTORY;
					*pnm = 0;
					MultiByteToWideChar(AreFileApisANSI()?CP_ACP:CP_OEMCP,MB_PRECOMPOSED,
										&dirname[0]+DirNameLn+iEndSlash,-1,tmp,MAX_PATH-1);
					addItemToPanelList(plg->host,tmp,&ff);//dirname[0]+DirNameLn+iEndSlash
					//*pnm = '\\';
				}
				else
				{	ff.dwFileAttributes=0;
					MultiByteToWideChar(AreFileApisANSI()?CP_ACP:CP_OEMCP,MB_PRECOMPOSED,
										&dirname[0]+DirNameLn+iEndSlash,-1,tmp,MAX_PATH-1);
					addItemToPanelList(plg->host,tmp,&ff);//&dirname[0]+DirNameLn+iEndSlash
	}	}	}	}
	return TRUE;
}

/*BOOL mdir(char *root,char *dirname)
{
char p[MAX_PATH]; int ln=MyStringCpy(p,MAX_PATH,root);
	p[ln]='\\';
	MyStringCpySlash(&p[ln+1],MAX_PATH-ln,dirname);
	return CreateDirectory(p,NULL);
}*/

HANDLE mfilecrdir(PluginObj *plg,HWND prntDlg,char *root,char *dirname,BOOL *bCancel)
{
HANDLE HF;WIN32_FIND_DATAA FF,ff;
char s[MAX_PATH],*p=&s[0]; int r,ln=MyStringCpyA(s,MAX_PATH,root);
	if(*dirname)
	{	s[ln]='\\';
		MyStringCpySlashA(&s[ln+1],MAX_PATH-ln,dirname);
	}
	while(p && (*p))
	{	p=strchr(p,'\\');
		if(p)
		{	//char c=*(++p);*p=0;
			//if(!IsDirExist(s))
			//	CreateDirectory(s,NULL);
			//*p=c;
			*p=0;
			if(!IsDirExistA(s))
				CreateDirectoryA(s,NULL);
			*p='\\';
			++p;
	}	}
	GetFileAttributesEx(plg->unchmFileName,GetFileExInfoStandard,&ff);

    HF = MyFindFirstFileEx((LPCTSTR)s,FindExInfoStandard,&FF,FindExSearchLimitToDirectories,NULL,0);
	if(INVALID_HANDLE_VALUE!=HF)
	{	FindClose(HF);
		if(FF.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)
			return 0;
		
		//if(IDNO==MessageBox(prntDlg,s,"File is already exist,overwrite?",MB_YESNO))
		//	return NULL;
		LPVOID par[3]={s,s,&ff};
		if(plg->bOvwrtLtstAll)
		{	
OvLts:		if(1==CmpFILETIMEs(&ff.ftCreationTime,&FF.ftCreationTime))
				goto Cr;
			return 0;
		}
		else if(plg->bOvwrtOldstAll)
		{	
OvOld:		if(-1==CmpFILETIMEs(&ff.ftCreationTime,&FF.ftCreationTime))
				goto Cr;
			return 0;
		}
		else if(plg->bOvwrtBigstAll)
		{	unsigned __int64 szf,szF;
OvBg:		szf = ((unsigned __int64)ff.nFileSizeHigh << 32) | (unsigned __int64)ff.nFileSizeLow;
			szF = ((unsigned __int64)FF.nFileSizeHigh  << 32) | (unsigned __int64)FF.nFileSizeLow;
			if(szf < szF)
				goto Cr;
			return 0;//go to next rec;
		}
		else if(plg->bRenameAll)
		{	char RenName[MAX_PATH],sAdd[32],*pExt;int iMyCopyRenameFileEx;
Renm:		pExt = (char*)strrchr(s,'.');
			iMyCopyRenameFileEx=0;
			if(pExt) memcpy(RenName,s,((char*)pExt) - ((char*)s));
			else MyStringCpyA(RenName,MAX_PATH-1,(char*)s);
			do
			{	++iMyCopyRenameFileEx;
				StringCchPrintfA(sAdd,32,"_%d",iMyCopyRenameFileEx);
				MyStringCatA(RenName,MAX_PATH-1,sAdd);
				if(pExt) MyStringCatA(RenName,MAX_PATH-1,pExt);
			} while(IsFileExistA(RenName));
		}
		else if(plg->bSkipAll)  return 0;
		else if(plg->bOvwrtAll) goto Cr;
		else if(plg->bOvwrtLtlstAll)
		{	unsigned __int64 szf,szF;
OvLtl:		szf = ((unsigned __int64)ff.nFileSizeHigh << 32) | (unsigned __int64)ff.nFileSizeLow;
			szF = ((unsigned __int64)FF.nFileSizeHigh  << 32) | (unsigned __int64)FF.nFileSizeLow;
			if(szf > szF)
				goto Cr;
			return 0;//go to next rec;
		}//else:
		wchar_t s[MAX_PATH];GetModuleFileName(NULL,s,MAX_PATH);
		HMODULE hm;wchar_t *p=wcsrchr(s,'\\');if(p)
#ifdef _WIN64
		{	wcscpy(p+1,L"MyShell64.dll");
			hm=LoadLibrary(s);
		}else hm=LoadLibrary(L"MyShell64.dll");
#else
		{	wcscpy(p+1,L"MyShell.dll");
			hm=LoadLibrary(s);
		}else hm=LoadLibrary(L"MyShell.dll");
#endif
		if(!hm)return FALSE;
		r=(int)DialogBoxParam(hm/*plgnDllInst*/,MAKEINTRESOURCE(IDD_DIALOG_EXIST_ACTION),prntDlg,ExstngActnDlgProc,(LPARAM)par);
		switch(r)
		{	case -1://idcancel;
				*bCancel = TRUE;
				return NULL;
			case 1://IDC_BUTTON_OVERWRITE_LATEST
				plg->bOvwrtLtst=1;
				goto OvLts;
			case 2://IDC_BUTTON_OVERWRITE_OLDEST:
				plg->bOvwrtOldst=1;
				goto OvOld;
			case 3://IDC_BUTTON_OVERWRITE_BIGGEST:
				plg->bOvwrtBigst=1;
				goto OvBg;
			case 4://IDC_BUTTON_RENAME:
				plg->bRename=1;
				goto Renm;
			case 5://IDC_BUTTON_SKIP:
				plg->bSkip=1;
				return 0;
			case 6://IDC_BUTTON_OVERWRITE:
				plg->bOvwrt=1;
				goto Cr;
			case 7://IDC_BUTTON_OVERWRITE_LITTLEST:
				plg->bOvwrtLtlst=1;
				goto OvLtl;


			case 11://IDC_BUTTON_OVERWRITE_LATEST with check box
				plg->bOvwrtLtstAll=1;
				goto OvLts;
			case 12://IDC_BUTTON_OVERWRITE_OLDEST: with check box
				plg->bOvwrtOldstAll=1;
				goto OvOld;
			case 13://IDC_BUTTON_OVERWRITE_BIGGEST: with check box
				plg->bOvwrtBigstAll=1;
				goto OvBg;
			case 14://IDC_BUTTON_RENAME: with check box
				plg->bRenameAll=1;
				goto Renm;
			case 15://IDC_BUTTON_SKIP: with check box
				plg->bSkipAll=1;
				return 0;
			case 16://IDC_BUTTON_OVERWRITE: with check box
				plg->bOvwrtAll=1;
				goto Cr;
			case 17://IDC_BUTTON_OVERWRITE_LITTLEST: with check box
				plg->bOvwrtLtlstAll=1;
				goto OvLtl;
	}	}
	//else
Cr:
	return CreateFileA(s,GENERIC_WRITE,FILE_SHARE_WRITE,NULL,OPEN_ALWAYS,FILE_ATTRIBUTE_NORMAL,NULL);
}

__declspec (dllexport) BOOL Unpack$28(HWND prntDlg,PluginObj *plg,wchar_t *destDirNameW,wchar_t *arjDirAndNameW,
									  BOOL* bCancel,UnpackProgressRoutine_t lpprgs,__int32 *bOverwriteBits)
{
DWORD rd;HANDLE f;char arjDirAndName[MAX_PATH],destDirName[MAX_PATH];
int namelen;char *rel;ulong length;ubyte *outbuf;
int dirlen=WideCharToMultiByte(AreFileApisANSI()?CP_ACP:CP_OEMCP,0,arjDirAndNameW,-1,arjDirAndName,MAX_PATH,NULL,NULL);
if(dirlen)--dirlen;
WideCharToMultiByte(AreFileApisANSI()?CP_ACP:CP_OEMCP,0,destDirNameW,-1,destDirName,MAX_PATH,NULL,NULL);

char *pd=strrchr(destDirName,'\\');
	if(pd)*pd=0;
	for(int i=0; i<plg->unchmf->dir->nentries; i++)
	{	if(plg->unchmf->dir->entry[i].name[0] == '/')
		{	namelen = (int)strlen(plg->unchmf->dir->entry[i].name);
			if(namelen == 1) continue; /* skip the slash */
			rel = plg->unchmf->dir->entry[i].name + 1;
			if(!strstrslashA(rel,arjDirAndName)) continue;
			if('\\'!=rel[dirlen])
			if('/'!=rel[dirlen])
			if(0!=rel[dirlen])
				continue;
			f=mfilecrdir(plg,prntDlg,destDirName,rel,bCancel);
			if(!f)continue;
			chm_getfile(plg->unchmf, plg->unchmf->dir->entry[i].name, &length, &outbuf);
			WriteFile(f,outbuf,length,&rd,NULL);
			if(outbuf)free(outbuf);
			CloseHandle(f);
			lpprgs(rd,rd,destDirNameW);
	}	}
	if(pd)*pd='\\';
	return TRUE;
}

__declspec (dllexport) int GetTotalCryptMethods()
{
	return 1;
}

__declspec (dllexport) const wchar_t* GetCryptDescription$4(int cryptNum)
{
	switch(cryptNum)
	{	case 0:default:
			return L"Sino chm-32 version of crypting code";
	}
	return L"";
}

INT_PTR CALLBACK ExstngActnDlgProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
static HFONT hf=0;
static int hfRef=0;//obshiy hf, dinamik uchun emas:
static HBRUSH br=0;
static HBRUSH brHtBk=0;
static int endDialogCodeToWM_DESTROY;
int width,left,height,top;FILETIME ft;SYSTEMTIME st;
char s[MAX_PATH];LPVOID *pars;//UINT uStyle;
RECT r;HDC dc;//LPDRAWITEMSTRUCT lpdis;
WIN32_FIND_DATA ff;HANDLE h;
UNREFERENCED_PARAMETER(lParam);
	switch (message)
	{
	case WM_INITDIALOG:
		GetWindowRect(hDlg, &r);
		width = r.right - r.left;
		height = r.bottom - r.top;
		left=(GetSystemMetrics(SM_CXSCREEN) - width )/2;
		top =(GetSystemMetrics(SM_CYSCREEN) - height)/2;
		MoveWindow(hDlg, left, top+20, width, height, TRUE);
		SetWindowText(hDlg,strngs[21]);
		SetDlgItemText(hDlg,IDC_STATIC8,strngs[3]);//"Existing file in disk:"
		SetDlgItemText(hDlg,IDC_STATIC5,strngs[4]);//"File in archive:"
		SetDlgItemText(hDlg,IDC_STATIC1,strngs[5]);//"Size in bytes:"
		SetDlgItemText(hDlg,IDC_STATIC3,strngs[5]);//"Size in bytes:"
		SetDlgItemText(hDlg,IDC_STATIC2,strngs[6]);//"Write time:"
		SetDlgItemText(hDlg,IDC_STATIC4,strngs[6]);//"Write time:"
		SetDlgItemText(hDlg,IDC_STATIC7,strngs[7]);//"Size in bytes:"
		SetDlgItemText(hDlg,IDC_STATIC6,strngs[8]);//"Rename"
		SetDlgItemText(hDlg,IDC_CHECK_OVERWRITE_LATEST_AUTO,strngs[22]);//"Overwrite latest in future"
		SetDlgItemText(hDlg,IDC_CHECK_OVERWRITE_OLDEST_AUTO,strngs[9]);//"Overwrite oldest in future"
		SetDlgItemText(hDlg,IDC_CHECK_OVERWRITE_BIGGEST_AUTO,strngs[10]);//"Overwrite biggest in future"
		SetDlgItemText(hDlg,IDC_CHECK_RENAME_AUTO,strngs[11]);//"Auto rename in future"
		SetDlgItemText(hDlg,IDC_CHECK_SKIP_AUTO,strngs[12]);//"Skip in future"		 
		SetDlgItemText(hDlg,IDC_CHECK_OVERWRITE_AUTO,strngs[13]);//"Overwrite in future"		 
		SetDlgItemText(hDlg,IDC_CHECK_OVERWRITE_BIGGEST_AUTO2,strngs[14]);//"Overwrite littlest in future"
		SetDlgItemText(hDlg,IDC_BUTTON_OVERWRITE_LATEST,strngs[15]);//"Overwrite latest"
		SetDlgItemText(hDlg,IDC_BUTTON_OVERWRITE_OLDEST,strngs[16]);//"Overwrite oldest"
		SetDlgItemText(hDlg,IDC_BUTTON_OVERWRITE_BIGGEST,strngs[17]);//"Overwrite biggest"
		SetDlgItemText(hDlg,IDC_BUTTON_RENAME,strngs[8]);//"Rename"
		SetDlgItemText(hDlg,IDC_BUTTON_SKIP,strngs[18]);//"Skip"
		SetDlgItemText(hDlg,IDC_BUTTON_OVERWRITE,strngs[19]);//"Overwrite"
		SetDlgItemText(hDlg,IDC_BUTTON_OVERWRITE_LITTLEST,strngs[20]);//"Overwrite littlest"
		SetDlgItemText(hDlg,IDCANCEL,strngs[1]);//"Cancel"
		pars=(LPVOID*)lParam;
		SetDlgItemTextA(hDlg,IDC_EDIT_EXST_NAME,(char*)pars[0]);
		SetDlgItemTextA(hDlg,IDC_EDIT_INZIP_NAME,(char*)pars[1]);
		StringCchPrintfA(s,MAX_PATH-1,"%d",(unsigned __int64)(((WIN32_FIND_DATA*)pars[2])->nFileSizeHigh) << 32 | 
										  ((WIN32_FIND_DATA*)pars[2])->nFileSizeLow);
		SetDlgItemTextA(hDlg,IDC_EDIT_INZIP_SIZE,s);
		if(FileTimeToLocalFileTime(&((WIN32_FIND_DATA*)pars[2])->ftCreationTime,&ft) != 0)
		{	if(FileTimeToSystemTime(&ft, &st) != 0)
			{	StringCchPrintfA(s,MAX_PATH-1,"%d.%d.%d  %d:%d:%d",
								st.wDay,st.wMonth,st.wYear,
								st.wHour,st.wMinute,st.wSecond);
				SetDlgItemTextA(hDlg,IDC_EDIT_INZIP_WR_TIME,s);
		}	}

		h = MyFindFirstFileEx((LPCTSTR)pars[0],FindExInfoStandard,&ff,FindExSearchLimitToDirectories,NULL,0);
		if(INVALID_HANDLE_VALUE!=h)
		{	FindClose(h);
			if(!(FILE_ATTRIBUTE_DIRECTORY & ff.dwFileAttributes))
			{	StringCchPrintfA(s,MAX_PATH-1,"%d",(unsigned __int64)(ff.nFileSizeHigh) << 32 | ff.nFileSizeLow);
				SetDlgItemTextA(hDlg,IDC_EDIT_EXST_SIZE,s);
				if(FileTimeToLocalFileTime(&ff.ftCreationTime,&ft) != 0)
				{	if(FileTimeToSystemTime(&ft, &st) != 0)
					{	StringCchPrintfA(s,MAX_PATH-1,"%d.%d.%d  %d:%d:%d",
										st.wDay,st.wMonth,st.wYear,
										st.wHour,st.wMinute,st.wSecond);
						SetDlgItemTextA(hDlg,IDC_EDIT_EXST_WR_TIME,s);
		}	}	}	}
		SendMessage(hDlg,WM_USER+1,0,0);
		return TRUE;
	case WM_USER+1://hf obshiy uchun, dinamik o'zgartirish uchun emas:
		if(0==hfRef)
		{	LOGFONT lf;InitLOGFONT(&lf);
			hf = CreateFontIndirect(&lf);
			br = CreateSolidBrush(RGB(0x40,0x21,0x17));//0xc9,0x81,0x93));
			brHtBk = CreateSolidBrush(RGB(0x64,0x79,0x65));
		}
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_EXST_NAME),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_EXST_SIZE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_EXST_WR_TIME),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_INZIP_NAME),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_INZIP_SIZE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_INZIP_WR_TIME),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_RENAME),WM_SETFONT,(WPARAM)hf,TRUE);

		SendMessage(GetDlgItem(hDlg,IDC_STATIC8),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_STATIC5),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_STATIC1),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_STATIC3),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_STATIC2),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_STATIC4),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_STATIC7),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_STATIC6),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_OVERWRITE_LATEST_AUTO),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_OVERWRITE_OLDEST_AUTO),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_OVERWRITE_BIGGEST_AUTO),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_RENAME_AUTO),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_SKIP_AUTO),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_OVERWRITE_AUTO),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_OVERWRITE_BIGGEST_AUTO2),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_BUTTON_OVERWRITE_LATEST),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_BUTTON_OVERWRITE_OLDEST),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_BUTTON_OVERWRITE_BIGGEST),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_BUTTON_RENAME),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_BUTTON_SKIP),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_BUTTON_OVERWRITE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_BUTTON_OVERWRITE_LITTLEST),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDCANCEL),WM_SETFONT,(WPARAM)hf,TRUE);
		++hfRef;
		return TRUE;
	case WM_CTLCOLORSTATIC:
	case WM_CTLCOLORDLG:dc = (HDC)wParam;
		SetTextColor(dc,RGB(0xea,0xe0,0xff));
		SetBkColor(dc,RGB(0x40,0x21,0x17));
		return (INT_PTR)br;
	case WM_CTLCOLOREDIT:dc = (HDC)wParam;
		SetTextColor(dc,RGB(0xea,0xe0,0xff));
		SetBkColor(dc,RGB(0x40,0x21,0x17));
		return (INT_PTR)br;
	case WM_CTLCOLORBTN:dc=(HDC)wParam;
		SetTextColor(dc,RGB(0xd0,0xe0,0xff));
		SetBkColor(dc,RGB(0x64,0x79,0x65));
		return (INT_PTR)brHtBk;
/*	case WM_DRAWITEM:
		lpdis = (LPDRAWITEMSTRUCT)lParam;
		GetWindowTextA(lpdis->hwndItem,s,64);
		uStyle = DFCS_BUTTONPUSH;
		r = lpdis->rcItem;
		if(lpdis->itemState & ODS_SELECTED)
		{	uStyle |= DFCS_PUSHED|DFCS_TRANSPARENT;
			r.left+=2;r.top+=2;
		}
		DrawFrameControl(lpdis->hDC, &lpdis->rcItem, DFC_BUTTON, uStyle);
		if(lpdis->itemState & ODS_SELECTED)
			{r.left+=1;r.top+=1;r.bottom-=2;r.right-=3;}
		else
			{r.left+=1;r.top+=2;r.bottom-=3;r.right-=3;}
		FillRect(lpdis->hDC,&r,brHtBk);//DrawText(lpdis->hDC,"                                                  ",50,&rc,DT_SINGLELINE|DT_VCENTER|DT_INTERNAL|DT_LEFT);
		if(lpdis->itemState & ODS_SELECTED)
			{r.left-=1;r.top-=1;r.bottom+=3;r.right+=3;}
		else
			{r.left-=1;r.top-=2;r.bottom+=2;r.right+=3;}
		DrawTextA(lpdis->hDC,s,MyStringLengthA(s,64),&r,DT_SINGLELINE|DT_VCENTER|DT_CENTER);
		return FALSE;*/
	case WM_DESTROY:
		if(--hfRef<1)
		{	DeleteObject(hf);
			DeleteObject(br);
			DeleteObject(brHtBk);
		}
		return 0;
	case WM_COMMAND://int r;
		switch(LOWORD(wParam))
		{	case IDC_BUTTON_OVERWRITE_LATEST:		
				EndDialog(hDlg,(BST_CHECKED!=SendMessage(GetDlgItem(hDlg,
												IDC_CHECK_OVERWRITE_LATEST_AUTO),BM_GETCHECK,0,0))?1:11);
				return (INT_PTR)TRUE;
			case IDC_BUTTON_OVERWRITE_OLDEST:
				EndDialog(hDlg,(BST_CHECKED!=SendMessage(GetDlgItem(hDlg,
												IDC_CHECK_OVERWRITE_OLDEST_AUTO),BM_GETCHECK,0,0))?2:12);
				return (INT_PTR)TRUE;
			case IDC_BUTTON_OVERWRITE_BIGGEST:
				EndDialog(hDlg,(BST_CHECKED!=SendMessage(GetDlgItem(hDlg,
												IDC_CHECK_OVERWRITE_BIGGEST_AUTO),BM_GETCHECK,0,0))?3:13);
				return (INT_PTR)TRUE;				
			case IDC_BUTTON_RENAME:
				EndDialog(hDlg,(BST_CHECKED!=SendMessage(GetDlgItem(hDlg,
												IDC_CHECK_RENAME_AUTO),BM_GETCHECK,0,0))?4:14);
				return (INT_PTR)TRUE;				
			case IDC_BUTTON_SKIP:
				EndDialog(hDlg,(BST_CHECKED!=SendMessage(GetDlgItem(hDlg,
												IDC_CHECK_SKIP_AUTO),BM_GETCHECK,0,0))?5:15);
				return (INT_PTR)TRUE;				
			case IDC_BUTTON_OVERWRITE:
				EndDialog(hDlg,(BST_CHECKED!=SendMessage(GetDlgItem(hDlg,
												IDC_CHECK_OVERWRITE_AUTO),BM_GETCHECK,0,0))?6:16);
				return (INT_PTR)TRUE;				
			case IDC_BUTTON_OVERWRITE_LITTLEST:
				EndDialog(hDlg,(BST_CHECKED!=SendMessage(GetDlgItem(hDlg,
												IDC_BUTTON_OVERWRITE_LITTLEST),BM_GETCHECK,0,0))?7:17);
				return (INT_PTR)TRUE;				
			case IDCANCEL:
				EndDialog(hDlg, -1);
				return (INT_PTR)TRUE;
		}
		break;
	}
	return (INT_PTR)FALSE;
}

}//extern "C"