#pragma comment(lib,"shlwapi.lib")


#include "windows.h"
#include "strsafe.h"
#include "resource.h"
#include "commctrl.h"
#include "shlobj.h"
#include "RegClean.h"
#include "shlwapi.h"
#include "..\..\..\Operations\MyShell\MyShell.h"





BOOL CorrectDoubleBackSlash(WCHAR *sRoot,WCHAR *subRoot,WCHAR *sValue)
{
HKEY	kPrnt,k;
TCHAR   achClass[4*MAX_PATH] = {0};	// buffer for class name 
TCHAR   achValue[4*MAX_PATH] = {0};	// buffer for class name 
DWORD   cchClassName = 4*MAX_PATH;	// size of class string 
DWORD   cbValueType = 4*MAX_PATH;	// size of class string 
DWORD   cSubKeys=0;					// number of subkeys 
DWORD    cbMaxSubKey;				// longest subkey size 
DWORD    cchMaxClass;				// longest class string 
DWORD    cValues;					// number of values for key 
DWORD    cchMaxValue;				// longest value name 
DWORD    cbMaxValueData;			// longest value data 
DWORD    cbSecurityDescriptor;		// size of security descriptor 
FILETIME ftLastWriteTime;			// last write time 
DWORD	 retCode; 
WCHAR    st[4*MAX_PATH];
int ln = MyStringCpy(st,4*MAX_PATH-1,sValue);
WCHAR  *p=wcsstr(st,L"\\\\");
	if(!p)return TRUE;

	if(wcsstr(sRoot,L"HKEY_LOCAL_MACHINE"))
		kPrnt = HKEY_LOCAL_MACHINE;
	else if(wcsstr(sRoot,L"HKEY_CLASSES_ROOT"))
		kPrnt = HKEY_CLASSES_ROOT;
	else if(wcsstr(sRoot,L"HKEY_CURRENT_USER"))
		kPrnt = HKEY_CURRENT_USER;
	else if(wcsstr(sRoot,L"HKEY_CURRENT_CONFIG"))
		kPrnt = HKEY_CURRENT_CONFIG;
	else if(wcsstr(sRoot,L"HKEY_USERS"))
		kPrnt = HKEY_USERS;

	retCode = RegOpenKeyEx(kPrnt,subRoot,0,KEY_READ|KEY_SET_VALUE,&k);
	if(ERROR_SUCCESS!=retCode)
		return TRUE;

	RegQueryInfoKey(
        k,						 // key handle 
        achClass,                // buffer for class name 
        &cchClassName,           // size of class string 
        NULL,                    // reserved 
        &cSubKeys,               // number of subkeys 
        &cbMaxSubKey,            // longest subkey size 
        &cchMaxClass,            // longest class string 
        &cValues,                // number of values for this key 
        &cchMaxValue,            // longest value name 
        &cbMaxValueData,         // longest value data 
        &cbSecurityDescriptor,   // security descriptor 
        &ftLastWriteTime);       // last write time 

	if(cValues)
    {  	retCode=FALSE;
		for(DWORD i=0; i<cValues; i++) 
        {	Progress(100);cchClassName=4*MAX_PATH;
            retCode = RegEnumValue(k, i,
                     achClass, 
                     &cchClassName, 
                     NULL, 
                     NULL, 
                     (LPBYTE)achValue, 
                     &cbValueType); 
            if(retCode == ERROR_SUCCESS) 
			{	if(0==_wcsnicmp(achValue,st,ln))
				{	for(;*(p+1);++p)
						*p=*(p+1);
					retCode=RegSetValueEx(k,NULL,NULL,REG_SZ,(BYTE*)st,ln-1);
					if(ERROR_SUCCESS!=retCode && cValues<2)
						retCode=RegSetValueEx(kPrnt,subRoot,NULL,REG_SZ,(BYTE*)st,ln-1);
					break;
	}	}	}	}
	RegCloseKey(k);
	if(ERROR_SUCCESS!=retCode)
		return FALSE;
	return TRUE;
}

BOOL DeleteRegEntry1(WCHAR *sRoot,WCHAR *subRoot,WCHAR *sValue)
{
HKEY	kPrnt,k;
TCHAR   achClass[4*MAX_PATH] = {0};	// buffer for class name 
TCHAR   achValue[4*MAX_PATH] = {0};	// buffer for class name 
DWORD   cchClassName = 4*MAX_PATH;	// size of class string 
DWORD   cbValueType = 4*MAX_PATH;	// size of class string 
DWORD   cSubKeys=0;					// number of subkeys 
DWORD	 retCode; 
WCHAR    st[4*MAX_PATH];
int ln = MyStringCpy(st,4*MAX_PATH-1,subRoot);
WCHAR  *p=wcschr(st,'\\');

	if(wcsstr(sRoot,L"HKEY_LOCAL_MACHINE"))
		kPrnt = HKEY_LOCAL_MACHINE;
	else if(wcsstr(sRoot,L"HKEY_CLASSES_ROOT"))
		kPrnt = HKEY_CLASSES_ROOT;
	else if(wcsstr(sRoot,L"HKEY_CURRENT_USER"))
		kPrnt = HKEY_CURRENT_USER;
	else if(wcsstr(sRoot,L"HKEY_CURRENT_CONFIG"))
		kPrnt = HKEY_CURRENT_CONFIG;
	else if(wcsstr(sRoot,L"HKEY_USERS"))
		kPrnt = HKEY_USERS;

	if(!p)
		retCode = RegDeleteKey(kPrnt,st);
	else
	{	retCode = RegOpenKeyEx(kPrnt,st,0,KEY_READ|KEY_SET_VALUE,&k);
		if(ERROR_SUCCESS!=retCode)
			return FALSE;
		retCode=SHDeleteKey(k,sValue);
		RegCloseKey(k);
	}	
	if(ERROR_SUCCESS==retCode)
		return TRUE;

	return FALSE;
}

BOOL DeletePathEntry(WCHAR *sRoot,WCHAR *subRoot,WCHAR *sValue)
{
HKEY	kPrnt,k;
TCHAR   achClass[4*MAX_PATH] = {0};	// buffer for class name 
TCHAR   achValue[4*MAX_PATH] = {0};	// buffer for class name 
DWORD   cchClassName = 4*MAX_PATH;	// size of class string 
DWORD   cbValueType = 4*MAX_PATH;	// size of class string 
DWORD   cSubKeys=0;					// number of subkeys 
DWORD	 retCode; 
WCHAR    st[4*MAX_PATH];
int ln = MyStringCpy(st,4*MAX_PATH-1,subRoot);
WCHAR  *p=wcschr(st,'\\');

	if(wcsstr(sRoot,L"HKEY_LOCAL_MACHINE"))
		kPrnt = HKEY_LOCAL_MACHINE;
	else if(wcsstr(sRoot,L"HKEY_CLASSES_ROOT"))
		kPrnt = HKEY_CLASSES_ROOT;
	else if(wcsstr(sRoot,L"HKEY_CURRENT_USER"))
		kPrnt = HKEY_CURRENT_USER;
	else if(wcsstr(sRoot,L"HKEY_CURRENT_CONFIG"))
		kPrnt = HKEY_CURRENT_CONFIG;
	else if(wcsstr(sRoot,L"HKEY_USERS"))
		kPrnt = HKEY_USERS;

	if(!p)
		retCode = RegDeleteKey(kPrnt,st);
	else
	{	retCode = RegOpenKeyEx(kPrnt,st,0,KEY_READ|KEY_SET_VALUE,&k);
		if(ERROR_SUCCESS!=retCode)
			return FALSE;
		retCode=SHDeleteValue(k,sValue,NULL);
		if(ERROR_SUCCESS!=retCode)
		{	WCHAR* p=wcschr(st,'\\');
			if(p)*p=0;
			retCode = SHDeleteKey(kPrnt,st);
		}
		RegCloseKey(k);
	}	
	if(ERROR_SUCCESS==retCode)
		return TRUE;

	return FALSE;
}

BOOL DeleteUninstall(WCHAR *sRoot,WCHAR *subRoot,WCHAR *sValue)
{
HKEY	kPrnt,k;
TCHAR   achClass[4*MAX_PATH] = {0};	// buffer for class name 
TCHAR   achValue[4*MAX_PATH] = {0};	// buffer for class name 
DWORD   cchClassName = 4*MAX_PATH;	// size of class string 
DWORD   cbValueType = 4*MAX_PATH;	// size of class string 
DWORD   cSubKeys=0;					// number of subkeys 
DWORD	 retCode; 
WCHAR    st[4*MAX_PATH];
int ln = MyStringCpy(st,4*MAX_PATH-1,subRoot);
WCHAR  *p=wcschr(st,'\\');

	if(wcsstr(sRoot,L"HKEY_LOCAL_MACHINE"))
		kPrnt = HKEY_LOCAL_MACHINE;
	else if(wcsstr(sRoot,L"HKEY_CLASSES_ROOT"))
		kPrnt = HKEY_CLASSES_ROOT;
	else if(wcsstr(sRoot,L"HKEY_CURRENT_USER"))
		kPrnt = HKEY_CURRENT_USER;
	else if(wcsstr(sRoot,L"HKEY_CURRENT_CONFIG"))
		kPrnt = HKEY_CURRENT_CONFIG;
	else if(wcsstr(sRoot,L"HKEY_USERS"))
		kPrnt = HKEY_USERS;

	if(!p)
		retCode = RegDeleteKey(kPrnt,st);
	else
	{	retCode = RegOpenKeyEx(kPrnt,st,0,KEY_READ|KEY_SET_VALUE,&k);
		if(ERROR_SUCCESS!=retCode)
			return FALSE;
		retCode=RegDeleteValue(k,sValue);
		if(ERROR_SUCCESS!=retCode)
			retCode=SHDeleteValue(kPrnt,st,sValue);
		RegCloseKey(k);
	}	
	if(ERROR_SUCCESS==retCode)
		return TRUE;

	return FALSE;
}

BOOL DeleteRegClsidEntry(WCHAR *sRoot,WCHAR *subRoot,WCHAR *sValue)
{
HKEY	kPrnt,k;
TCHAR   achClass[4*MAX_PATH] = {0};	// buffer for class name 
TCHAR   achValue[4*MAX_PATH] = {0};	// buffer for class name 
DWORD   cchClassName = 4*MAX_PATH;	// size of class string 
DWORD   cbValueType = 4*MAX_PATH;	// size of class string 
DWORD   cSubKeys=0;					// number of subkeys 
DWORD	 retCode; 
WCHAR    st[4*MAX_PATH];
int ln = MyStringCpy(st,4*MAX_PATH-1,subRoot);
WCHAR  *p=wcschr(st,'\\');

	if(wcsstr(sRoot,L"HKEY_LOCAL_MACHINE"))
		kPrnt = HKEY_LOCAL_MACHINE;
	else if(wcsstr(sRoot,L"HKEY_CLASSES_ROOT"))
		kPrnt = HKEY_CLASSES_ROOT;
	else if(wcsstr(sRoot,L"HKEY_CURRENT_USER"))
		kPrnt = HKEY_CURRENT_USER;
	else if(wcsstr(sRoot,L"HKEY_CURRENT_CONFIG"))
		kPrnt = HKEY_CURRENT_CONFIG;
	else if(wcsstr(sRoot,L"HKEY_USERS"))
		kPrnt = HKEY_USERS;

	if(!p)
		retCode = RegDeleteKey(kPrnt,st);
	else
	{	retCode = RegOpenKeyEx(kPrnt,st,0,KEY_READ|KEY_SET_VALUE,&k);
		if(ERROR_SUCCESS!=retCode)
		{	if(2==retCode)
			{	if(kPrnt == HKEY_CLASSES_ROOT)
				{   WCHAR *p = wcschr(st,'\\');
					if(p)*p=0;
					retCode=SHDeleteKey(kPrnt,st);
					if(ERROR_SUCCESS==retCode)
						return TRUE;
			}	}
			WCHAR *p = wcschr(st,'\\');
			if(p)
			{	*p=0;
				//retCode = RegOpenKeyEx(kPrnt,st,0,KEY_READ|KEY_SET_VALUE,&k);
				//if(ERROR_SUCCESS!=retCode)
				//	return FALSE;
				retCode=SHDeleteKey(kPrnt,st);
				if(ERROR_SUCCESS==retCode)
					return TRUE;
			}
			return FALSE;
		}
		retCode=SHDeleteKey(k,sValue);
		RegCloseKey(k);
		if(2==retCode)//not exist
		{	if(kPrnt == HKEY_CLASSES_ROOT)
			{   WCHAR *p = wcschr(st,'\\');
				if(p)*p=0;
				retCode=SHDeleteKey(kPrnt,st);
	}	}	}
	if(ERROR_SUCCESS==retCode)
		return TRUE;
	return FALSE;
}

BOOL CorrectError(int iIt,int errNum)
{LVITEM lvItem;
WCHAR sValue[4*MAX_PATH];
WCHAR sRoot[64];
WCHAR sSubRoot[4*MAX_PATH];
 lvItem.mask = LVIF_TEXT;
 lvItem.iItem = iIt;

 lvItem.iSubItem = 0;
 lvItem.cchTextMax = 4*MAX_PATH;
 lvItem.pszText = sValue;
 SendMessage(hWndTree, LVM_GETITEM, 0, (LPARAM)&lvItem);

 lvItem.iSubItem = 3;
 lvItem.cchTextMax = 64;
 lvItem.pszText = sRoot;
 SendMessage(hWndTree, LVM_GETITEM, 0, (LPARAM)&lvItem);

 lvItem.iSubItem = 4;
 lvItem.cchTextMax = 4*MAX_PATH;
 lvItem.pszText = sSubRoot;
 SendMessage(hWndTree, LVM_GETITEM, 0, (LPARAM)&lvItem);


 if(5==errNum)
	 return CorrectDoubleBackSlash(sRoot,sSubRoot,sValue);
 else if(0==errNum)
	return DeleteRegEntry1(sRoot,sSubRoot,sValue);
 else if(4==errNum)
	return DeleteRegClsidEntry(sRoot,sSubRoot,sValue);
 else if(1==errNum)
	 return DeletePathEntry(sRoot,sSubRoot,sValue);
 else if(2==errNum)
	 return DeleteUninstall(sRoot,sSubRoot,sValue);
 return FALSE;
}

VOID BeginCorrectingThrd()
{WCHAR s[32];LVITEM lvItem;
lvItem.mask = LVIF_TEXT|LVIF_STATE;
lvItem.stateMask = LVIS_SELECTED; 
lvItem.cchTextMax = 32;
lvItem.pszText = s;
lvItem.iSubItem = 1;
int iOsechka=0;

	iStopEndExit=0;

	while(iOsechka<(int)SendMessage(hWndTree,LVM_GETITEMCOUNT,0,0))
	{	lvItem.iItem = iOsechka;
		SendMessage(hWndTree, LVM_GETITEM, 0, (LPARAM)&lvItem);

		if(1==iStopEndExit || 3==iStopEndExit)
			break;

		if(lvItem.state & LVIS_SELECTED)
		{	if(CorrectError(lvItem.iItem,(s[0]-'0')-1))
				ListView_DeleteItem(hWndTree,lvItem.iItem);
			else
				++iOsechka;
	}	}
	iStopEndExit = 2;
}