#include "windows.h"
#include "commctrl.h"

extern HINSTANCE hInst;
extern HWND hWnd,hWndTreeConf,hWndEditStatus,
			hWndProgress,hWndTree,hWndBtnCorrect,hWndBtnExit,hWndBtnStop;
extern HFONT fnt;
extern int language,iStopEndExit;

extern WCHAR rootPathForOutput[64];
extern WCHAR subPathForOutput[4*MAX_PATH];
extern int subPathForOutputLn;
extern WCHAR errValue[4*MAX_PATH];

HTREEITEM AddItemToTree(HWND,LPWSTR,int,int,BOOL);
VOID BeginSearchThrd();
VOID MessageProcess();
BOOL Progress(int);
BOOL AddNotExistingRegEntryToLV(WCHAR*,WCHAR*,WCHAR*,WCHAR*,WCHAR*);
BOOL AddNotExistingRegEntryToLV2(WCHAR*,WCHAR*,WCHAR*,WCHAR*);
BOOL SearchForCorrectCLSID();
BOOL SearchForCorrectOpenWith();
BOOL SearchForCorrectUninstall();
BOOL IsFileSystem(WCHAR*);
VOID BeginCorrectingThrd();