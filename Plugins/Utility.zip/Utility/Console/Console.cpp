#include "windows.h"
#include "strsafe.h"
#include "resource.h"
#include "..\..\..\Operations\MyShell\ComboToDisk.h"
#include "..\..\..\Operations\MyShell\MyButtonC++.h"
#include "..\..\..\Operations\MyShell\MyShell.h"


wchar_t CmndLine[MAX_PATH]=L"";
bool bEchoOnOff(0),bUnicode(0),bAutorunOnOff(0),bExtendedOnOff(0);
int fontColor(-1),backColor(-1),instNum(1);
HINSTANCE hInst;
CBToDisk cmdArgCB,instNumCB;
/*typedef struct TCmdArgs
{
wchar_t cmndLine[MAX_PATH];
HWND	prnt;
int     fontColor;
int     backColor;
bool    bEchoOnOff;
bool    bAutorunOnOff;
bool    bUnicode;
bool    bExtendedOnOff;
} CmdArgs;*/

int CallCommandConsole(int);
INT_PTR CALLBACK AskCmdArgDlg(HWND,UINT,WPARAM,LPARAM);


int APIENTRY WinMain(HINSTANCE hInstance,HINSTANCE hPrevInstance,LPSTR lpCmdLine,int nCmdShow)
{
	hInst = hInstance;
wchar_t pth[MAX_PATH],sysPath[MAX_PATH];int nNumArgs=0;
    LPWSTR *p=CommandLineToArgvW(GetCommandLineW(),&nNumArgs);
	//MessageBox(NULL,p[0],L"",MB_OK);
	int ln=MyStringCpy(pth,MAX_PATH-1,p[1]);
	if('*'==pth[ln-1])
		pth[--ln]=0;
	if('\\'==pth[ln-1])
		pth[--ln]=0;
	if(!IsDirExist(pth))
	{wchar_t *p=wcsrchr(pth,'\\');
	 if(p)*p=0;
	}
	if(!IsDirExist(pth))pth[0]=0;

	ln=GetSystemDirectory(sysPath,MAX_PATH-1);
	if(!ln)	return 0;
	if(sysPath[ln-1]!='\\')
		sysPath[ln++]='\\';
	ln+=MyStringCpy(&sysPath[ln],MAX_PATH-1-ln,L"cmd.exe");
	WIN32_FIND_DATA ff;HANDLE hf = FindFirstFile(sysPath,&ff);
	if(INVALID_HANDLE_VALUE==hf)return 0;
	FindClose(hf);
	if(!DialogBox(hInst,MAKEINTRESOURCE(IDD_DIALOG_CMD_ARG),NULL,AskCmdArgDlg))
		return 0;
wchar_t cmndLine[MAX_PATH];
	ln=0;
	cmndLine[ln++] = ' ';
	cmndLine[ln++] = '/';
	cmndLine[ln++] = bUnicode ? 'U' : 'A';
	if(bEchoOnOff)
	{	cmndLine[ln++] = ' '; 
		cmndLine[ln++] = '/'; 
		cmndLine[ln++] = 'Q';
	}
	if(bAutorunOnOff)
	{	cmndLine[ln++] = ' '; 
		cmndLine[ln++] = '/'; 
		cmndLine[ln++] = 'D';
	}
	if(fontColor>-1 || backColor>-1)
	{	if(backColor<0)backColor=0;
		if(fontColor<0)fontColor=0;
		cmndLine[ln++] = ' '; 
		cmndLine[ln++] = '/'; 
		cmndLine[ln++] = 'T';
		cmndLine[ln++] = ':'; 
		if(backColor < 10) cmndLine[ln++] = backColor + '0'; 
		else  					  cmndLine[ln++] = backColor + 'A'; 
		if(fontColor < 10) cmndLine[ln++] = fontColor + '0'; 
		else					  cmndLine[ln++] = fontColor + 'A'; 
		cmndLine[ln++] = ' '; 
	}
	if(bExtendedOnOff)
	{	cmndLine[ln++] = ' '; 
		cmndLine[ln++] = '/'; 
		cmndLine[ln++] = 'E';
		cmndLine[ln++] = ':'; 
		cmndLine[ln++] = 'O'; 
		cmndLine[ln++] = 'F'; 
		cmndLine[ln++] = 'F'; 
	}
	if(CmndLine[0])
	{	cmndLine[ln++] = ' '; 
		cmndLine[ln++] = '/'; 
		cmndLine[ln++] = 'K';
		MyStringCpy(&cmndLine[ln],MAX_PATH-ln-1,CmndLine);
	}
	else cmndLine[ln]=0;


	//ShellExecute(hWnd,L"open",sysPath,cmndLine,pth,SW_SHOWDEFAULT);
	
	
	PROCESS_INFORMATION pi;STARTUPINFO si;ZeroMemory(&si,sizeof(si));si.cb=sizeof(si);
	//si.dwX = si.dwY = si.dwXSize = si.dwYSize = CW_USEDEFAULT;
	//si.dwFillAttribute = BACKGROUND_INTENSITY|FOREGROUND_BLUE;
	si.wShowWindow = SW_SHOWDEFAULT;
	si.dwFlags = STARTF_USESHOWWINDOW;//|STARTF_USEFILLATTRIBUTE;//| STARTF_USESIZE | STARTF_USECOUNTCHARS;
	for(int i=0; i<instNum; i++)
	{BOOL r =CreateProcess(sysPath,cmndLine,NULL,NULL,FALSE,CREATE_NEW_CONSOLE,NULL,pth[0]?pth:NULL,&si,&pi);
	 if(0==r)r=GetLastError();
	}
 	return TRUE;//r;
}

INT_PTR CALLBACK AskCmdArgDlg(HWND hDlg,UINT message,WPARAM wParam,LPARAM lParam)
{wchar_t s[MAX_PATH];
	UNREFERENCED_PARAMETER(lParam);
	switch(message)
	{
	case WM_INITDIALOG:RECT r;int width,height,left,top;
		GetWindowRect(hDlg,&r);
		width = r.right - r.left;
		height = r.bottom - r.top;
		left=(GetSystemMetrics(SM_CXSCREEN) - width )/2;
		top = (int)(0.38*(GetSystemMetrics(SM_CYSCREEN) - height));
		MoveWindow(hDlg, left, top+20, width, height, TRUE);

		SendMessage(GetDlgItem(hDlg,IDC_COMBO_BCK_COLOR),CB_ADDSTRING,0,(LPARAM)L"0-black");
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_BCK_COLOR),CB_ADDSTRING,0,(LPARAM)L"1-blue");
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_BCK_COLOR),CB_ADDSTRING,0,(LPARAM)L"2-green");
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_BCK_COLOR),CB_ADDSTRING,0,(LPARAM)L"3-sky-blue");
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_BCK_COLOR),CB_ADDSTRING,0,(LPARAM)L"4-red");
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_BCK_COLOR),CB_ADDSTRING,0,(LPARAM)L"5-violet");
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_BCK_COLOR),CB_ADDSTRING,0,(LPARAM)L"6-yellow");
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_BCK_COLOR),CB_ADDSTRING,0,(LPARAM)L"7-white");
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_BCK_COLOR),CB_ADDSTRING,0,(LPARAM)L"8-gray");
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_BCK_COLOR),CB_ADDSTRING,0,(LPARAM)L"9-light-blue");
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_BCK_COLOR),CB_ADDSTRING,0,(LPARAM)L"A-light-green");
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_BCK_COLOR),CB_ADDSTRING,0,(LPARAM)L"B-light-blue");
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_BCK_COLOR),CB_ADDSTRING,0,(LPARAM)L"C-light-red");
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_BCK_COLOR),CB_ADDSTRING,0,(LPARAM)L"D-light-violet");
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_BCK_COLOR),CB_ADDSTRING,0,(LPARAM)L"E-light-yellow");
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_BCK_COLOR),CB_ADDSTRING,0,(LPARAM)L"F-light-white");

		SendMessage(GetDlgItem(hDlg,IDC_COMBO_FONT_COLOR),CB_ADDSTRING,0,(LPARAM)L"0-black");
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_FONT_COLOR),CB_ADDSTRING,0,(LPARAM)L"1-blue");
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_FONT_COLOR),CB_ADDSTRING,0,(LPARAM)L"2-green");
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_FONT_COLOR),CB_ADDSTRING,0,(LPARAM)L"3-sky-blue");
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_FONT_COLOR),CB_ADDSTRING,0,(LPARAM)L"4-red");
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_FONT_COLOR),CB_ADDSTRING,0,(LPARAM)L"5-violet");
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_FONT_COLOR),CB_ADDSTRING,0,(LPARAM)L"6-yellow");
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_FONT_COLOR),CB_ADDSTRING,0,(LPARAM)L"7-white");
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_FONT_COLOR),CB_ADDSTRING,0,(LPARAM)L"8-gray");
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_FONT_COLOR),CB_ADDSTRING,0,(LPARAM)L"9-light-blue");
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_FONT_COLOR),CB_ADDSTRING,0,(LPARAM)L"A-light-green");
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_FONT_COLOR),CB_ADDSTRING,0,(LPARAM)L"B-light-blue");
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_FONT_COLOR),CB_ADDSTRING,0,(LPARAM)L"C-light-red");
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_FONT_COLOR),CB_ADDSTRING,0,(LPARAM)L"D-light-violet");
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_FONT_COLOR),CB_ADDSTRING,0,(LPARAM)L"E-light-yellow");
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_FONT_COLOR),CB_ADDSTRING,0,(LPARAM)L"F-light-white");
		//MyButtonFrRCBtn(hDlg,IDOK,0);
		//MyButtonFrRCBtn(hDlg,IDCANCEL,0);
		cmdArgCB.Read(L"console.cb:stream",GetDlgItem(hDlg,IDC_EDIT_CMD_ARG),35,260);
		instNumCB.Read(L"console.cb:stream1",GetDlgItem(hDlg,IDC_COMBO_INST_NUM),35,260);
		return TRUE;
	case WM_DESTROY:
		cmdArgCB.Save(L"console.cb:stream",GetDlgItem(hDlg,IDC_EDIT_CMD_ARG),35);
		instNumCB.Save(L"console.cb:stream1",GetDlgItem(hDlg,IDC_COMBO_INST_NUM),35);
		return 0;
	case WM_COMMAND:
		switch(LOWORD(wParam))
		{	case IDOK://overwrite
				CBToDisk::GetCBEditText(GetDlgItem(hDlg,IDC_EDIT_CMD_ARG),CmndLine,MAX_PATH-1);
				instNumCB.GetCBEditText(GetDlgItem(hDlg,IDC_COMBO_INST_NUM),s,MAX_PATH);
				if(s[0])
				{instNumCB.AddToCB(GetDlgItem(hDlg,IDC_COMBO_INST_NUM),s,TRUE);
				 instNum=_wtoi(s);
				 if(instNum<1)instNum=1;
				 else if(instNum>500)instNum=500;
				}

				backColor = (int)SendMessage(GetDlgItem(hDlg,IDC_COMBO_BCK_COLOR),CB_GETCURSEL,0,0);
				fontColor = (int)SendMessage(GetDlgItem(hDlg,IDC_COMBO_FONT_COLOR),CB_GETCURSEL,0,0);
				bEchoOnOff = (BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_ECHO),BM_GETCHECK,0,0)) ? TRUE : FALSE;
				bUnicode = (BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_UNICODE),BM_GETCHECK,0,0)) ? TRUE : FALSE;
				bAutorunOnOff = (BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_AUTORUN),BM_GETCHECK,0,0)) ? TRUE : FALSE;
				bExtendedOnOff = (BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_EXTENDED),BM_GETCHECK,0,0)) ? TRUE : FALSE;

				EndDialog(hDlg,1);
				return (INT_PTR)TRUE;
			case IDCANCEL:
				EndDialog(hDlg,0);
				return (INT_PTR)TRUE;
			case IDC_CHECK_ECHO:
				bEchoOnOff = (BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_ECHO),BM_GETCHECK,0,0)) ? TRUE : FALSE;
				return 0;
			case IDC_CHECK_UNICODE:
				bUnicode = (BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_UNICODE),BM_GETCHECK,0,0)) ? TRUE : FALSE;
				return 0;
			case IDC_CHECK_AUTORUN:
				bAutorunOnOff = (BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_AUTORUN),BM_GETCHECK,0,0)) ? TRUE : FALSE;
				return 0;
			case IDC_CHECK_EXTENDED:
				bExtendedOnOff = (BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_EXTENDED),BM_GETCHECK,0,0)) ? TRUE : FALSE;
				return 0;
			case IDC_COMBO_BCK_COLOR:
				backColor = (int)SendMessage(GetDlgItem(hDlg,IDC_COMBO_BCK_COLOR),CB_GETCURSEL,0,0);
				return (INT_PTR)FALSE;
			case IDC_COMBO_FONT_COLOR:
				fontColor = (int)SendMessage(GetDlgItem(hDlg,IDC_COMBO_FONT_COLOR),CB_GETCURSEL,0,0);
				return 0;
			case IDC_EDIT_CMD_ARG:
				if(CBN_KILLFOCUS==HIWORD(wParam))
				{cmdArgCB.GetCBEditText(GetDlgItem(hDlg,IDC_EDIT_CMD_ARG),s,MAX_PATH);
				 if(s[0])cmdArgCB.AddToCB(GetDlgItem(hDlg,IDC_EDIT_CMD_ARG),s,TRUE);
				}	
				return 0;
			case IDC_COMBO_INST_NUM:
				if(CBN_KILLFOCUS==HIWORD(wParam))
				{instNumCB.GetCBEditText(GetDlgItem(hDlg,IDC_COMBO_INST_NUM),s,MAX_PATH);
				 if(s[0])
				 {instNumCB.AddToCB(GetDlgItem(hDlg,IDC_COMBO_INST_NUM),s,TRUE);
				  instNum=_wtoi(s);
				  if(instNum<1)instNum=1;
				  else if(instNum>500)instNum=500;
				}}
				return 0;
		}
		break;
	}
	return (INT_PTR)FALSE;
}