#include "windows.h"
#include "commctrl.h"

extern HINSTANCE hInst;
extern HWND hWnd,hWndToEmptyDir,hWndToSearchDir,hWndFileExtFilters,hWndEditStatus,
			hWndProgress,hWndTree,hWndBtnBrowse,hWndBtnAddToDir,hWndBtnAddToDir1,
			hWndBtnAddToExt,hWndBtnDelete,hWndBtnExit,hWndBtnSearch;
extern HFONT fnt;
extern int language,iStopEndExit;

extern WCHAR rootPathForOutput[64];
extern WCHAR subPathForOutput[4*MAX_PATH];
extern int subPathForOutputLn;
extern WCHAR errValue[4*MAX_PATH];


extern UINT logDrType[32],logDrSpace[32],logDrFrSpace[32];
extern WCHAR logDrDescrptn[32][128];
extern WCHAR logDrLabels[32][2],logDrNames[32][2];
extern int totLogDiskDrives,logDrMediaType[32];

HTREEITEM AddItemToTree(HWND,LPWSTR,int,int,BOOL);
VOID BeginSearchThrd();
VOID MessageProcess();
BOOL Progress(int);
BOOL AddNotExistingRegEntryToLV(WCHAR*,WCHAR*,WCHAR*,WCHAR*,WCHAR*);
BOOL AddNotExistingRegEntryToLV2(WCHAR*,WCHAR*,WCHAR*,WCHAR*);
BOOL SearchForCorrectCLSID();
BOOL SearchForCorrectOpenWith();
BOOL SearchForCorrectUninstall();
BOOL IsFileSystem(WCHAR*);
BOOL DeleteRegEntry1(WCHAR *sRoot,WCHAR *subRoot,WCHAR *sValue);
BOOL DeleteRegClsidEntry(WCHAR *sRoot,WCHAR *subRoot,WCHAR *sValue);
BOOL DeletePathEntry(WCHAR *sRoot,WCHAR *subRoot,WCHAR *sValue);
BOOL DeleteUninstall(WCHAR *sRoot,WCHAR *subRoot,WCHAR *sValue);

BOOL CheckFileFilter(WCHAR*);

int BuildLogicalDrives();
VOID BeginDeletingThrd();

//CSIDL_BITBUCKET
//CSIDL_COMMON_TEMPLATES
//CSIDL_COOKIES
//CSIDL_INTERNET_CACHE
//GetTempPath