//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by UndelNTFS.rc
//
#define IDR_SINOSTRING1                 105
#define IDI_ICON2                       106
#define IDR_MENU1                       107
#define IDD_DIALOG1                     108
#define IDC_STATIC1                     21570
#define IDC_STATIC2                     21571
#define IDC_STATIC3                     21572
#define IDC_STATIC4                     21574
#define ID_FILE_EXIT                    40001
#define IDM_FILE                        40002
#define IDM_EXIT                        40003
#define ID_HELP40004                    40004
#define IDM_ABOUT                       40005

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        109
#define _APS_NEXT_COMMAND_VALUE         40006
#define _APS_NEXT_CONTROL_VALUE         1012
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
