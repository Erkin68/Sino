#include "windows.h"
#include "commctrl.h"

extern HINSTANCE hInst;
extern HWND hWnd,hWndSearchPath,hWndInformEdit,hWndBtnBrowseForPath,
			hWndProgress,hWndTree,hWndBtnUndelete,hWndBtnExit,hWndBtnStop;
extern HFONT fnt;
extern int language,iStopEndExit;
extern wchar_t FilePathForSearch[MAX_PATH];
extern WCHAR TemporaryVolumeFilePathAndName[];
extern "C" {extern HANDLE hVolume;extern PUCHAR bitmap;}

BOOL BeginSearchThrd(HWND,wchar_t*);
BOOL RecoverFile(ULONG,LPCWSTR);
BOOL BeginRecoveryThrd(HWND,wchar_t*);
VOID AddStrToMultilineEdit(wchar_t*,HWND h=hWndInformEdit);
VOID AddStrToMultilineEditA(char*,HWND h=hWndInformEdit);
HTREEITEM AddItemToTree(HWND,LPWSTR,int,int);

BOOL RunningAsAdministrator();

extern "C" {BOOL LoadNTProces();}
