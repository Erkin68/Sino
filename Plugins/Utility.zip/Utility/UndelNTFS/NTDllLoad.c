#include "..\..\Auxilary\MenuUtility\FileDefrag\SFDefrag\zenwin\ntndk.h"
//#include "UndelNTFS.h"

extern HANDLE hVolume;

NTSTATUS (WINAPI * pRtlInitUnicodeString)(PUNICODE_STRING, PCWSTR);
NTSTATUS (WINAPI * pNtCreateFile)(PHANDLE, ACCESS_MASK, POBJECT_ATTRIBUTES, PIO_STATUS_BLOCK, PLARGE_INTEGER, ULONG, ULONG, ULONG, ULONG, PVOID, ULONG);
NTSTATUS (WINAPI * pNtCreateEvent)(PHANDLE, ACCESS_MASK, POBJECT_ATTRIBUTES, EVENT_TYPE, BOOLEAN);
NTSTATUS (WINAPI * pNtQueryDirectoryFile)(HANDLE, HANDLE, PIO_APC_ROUTINE, PVOID, PIO_STATUS_BLOCK, PVOID, ULONG, FILE_INFORMATION_CLASS, BOOLEAN, PUNICODE_STRING, BOOLEAN);
NTSTATUS (WINAPI * pNtWaitForSingleObject)(HANDLE, BOOLEAN, PLARGE_INTEGER);
NTSTATUS (WINAPI * pRtlUnicodeStringToAnsiString)(PANSI_STRING, PCUNICODE_STRING, BOOLEAN);
NTSTATUS (WINAPI * pNtClose)(HANDLE);

BOOL LoadNTProces()
{
/*	HMODULE hModule = LoadLibrary(L"Ntdll.dll");
	if(!hModule)return FALSE;
	pRtlInitUnicodeString = (NTSTATUS (WINAPI *)(PUNICODE_STRING, PCWSTR)) GetProcAddress (hModule, "RtlInitUnicodeString");
	pNtCreateFile = (NTSTATUS (WINAPI *)(PHANDLE, ACCESS_MASK, POBJECT_ATTRIBUTES, PIO_STATUS_BLOCK, PLARGE_INTEGER, ULONG, ULONG, ULONG, ULONG, PVOID, ULONG)) GetProcAddress (hModule, "NtCreateFile");
	pNtCreateEvent = (NTSTATUS (WINAPI *)(PHANDLE, ACCESS_MASK, POBJECT_ATTRIBUTES, EVENT_TYPE, BOOLEAN)) GetProcAddress (hModule, "NtCreateEvent");
	pNtQueryDirectoryFile = (NTSTATUS (WINAPI *)(HANDLE, HANDLE, PIO_APC_ROUTINE, PVOID, PIO_STATUS_BLOCK, PVOID, ULONG, FILE_INFORMATION_CLASS, BOOLEAN, PUNICODE_STRING, BOOLEAN)) GetProcAddress (hModule, "NtQueryDirectoryFile");
	pNtWaitForSingleObject = (NTSTATUS (WINAPI *)(HANDLE, BOOLEAN, PLARGE_INTEGER)) GetProcAddress (hModule, "NtWaitForSingleObject");
	pRtlUnicodeStringToAnsiString = (NTSTATUS (WINAPI *)(PANSI_STRING, PCUNICODE_STRING, BOOLEAN)) GetProcAddress (hModule, "RtlUnicodeStringToAnsiString");
	pNtClose = (NTSTATUS (WINAPI *)(HANDLE)) GetProcAddress (hModule, "NtClose");

	if((!pRtlInitUnicodeString) || (!pNtCreateFile) || (!pNtCreateEvent) || (!pNtQueryDirectoryFile) ||
		(!pNtWaitForSingleObject) || (!pRtlUnicodeStringToAnsiString) || (!pNtClose))
	{	FreeLibrary(hModule);
		return FALSE;
	}
*/	return TRUE;
}

/*HANDLE TryNtCreatefILE(wchar_t *fName)
{
UNICODE_STRING RootDirectoryName;
OBJECT_ATTRIBUTES RootDirectoryAttributes;
IO_STATUS_BLOCK Iosb;
HANDLE hFile;

	if(((pRtlInitUnicodeString)(&RootDirectoryName, fName))!= STATUS_SUCCESS)
		return 0;
	
	//InitializeObjectAttributes(&RootDirectoryAttributes, &RootDirectoryName, OBJ_CASE_INSENSITIVE, 0, 0);
	InitializeObjectAttributes(&RootDirectoryAttributes, &RootDirectoryName, OBJ_CASE_INSENSITIVE|OBJ_KERNEL_HANDLE, 0, 0);
	
	if(((pNtCreateFile)(&hFile,
						GENERIC_READ|GENERIC_WRITE|FILE_EXECUTE,
						&RootDirectoryAttributes,
						&Iosb,
						0,
						FILE_READ_DATA,//FILE_ATTRIBUTE_DIRECTORY,
						FILE_SHARE_READ,// | FILE_SHARE_WRITE | FILE_SHARE_DELETE,
						FILE_OPEN,
						FILE_ATTRIBUTE_SYSTEM,//OPEN_EXISTING,//FILE_DIRECTORY_FILE, OPEN_PAGING_FILE
						0, 0)) != STATUS_SUCCESS)
		return 0;
	return hFile;
}

VOID CloseNtCrF(HANDLE FileHandle)
{
	((pNtClose)(FileHandle));
}*/
#define LLINVALID ((ULONGLONG) -1)
BOOL AnalyzeDeletetedFileBitmapOfVolume(ULONGLONG *lcnfr,ULONGLONG *lcncnt)
{
ULONGLONG i,start,sztoend,MN,bisy_rgn_start=LLINVALID;
size_t bitmapsize,bitmapbytes=(size_t)lcncnt;//65535 * 8 = 524280 ta claster;
BITMAP_DESCRIPTOR *Bitmap;
unsigned char bitshift[] = { 1, 2, 4, 8, 16, 32, 64, 128 };//bit shifting array for efficient processing of the bitmap
IO_STATUS_BLOCK iosb;
NTSTATUS status;
int percent[2],oldpercent[2];

  bitmapsize = bitmapbytes + 2 * sizeof(ULONGLONG);

  //allocate memory
  Bitmap = (BITMAP_DESCRIPTOR*)malloc(bitmapsize);
  Bitmap->StartLcn = *lcnfr;
 
  //1.Volyumini oxiri qayergacha boradi;
  memset(Bitmap,0,bitmapsize);
  status = NtFsControlFile( hVolume,NULL,NULL,0,&iosb,FSCTL_GET_VOLUME_BITMAP,
							lcnfr,sizeof(ULONGLONG),Bitmap,32);
  if(0x80000005==status)//NT_SUCCESS(status))
  {	NtWaitForSingleObject(hVolume,FALSE,NULL);
	status = iosb.Status;
  }
  if(status != STATUS_SUCCESS && status != STATUS_BUFFER_OVERFLOW)
  {	//wsprintf(hStatText,strngs[14],fileNameForVolLetter,*lcnfr);
	//SetWindowText(hStat,hStatText);
	goto End;
  }

  if(Bitmap->ClustersToEndOfVol > bitmapbytes * 8)
	sztoend = Bitmap->ClustersToEndOfVol - bitmapbytes * 8;
  else
  {	//wsprintf(hStatText,strngs[15],fileNameForVolLetter,*lcnfr,bitmap->StartLcn+bitmap->ClustersToEndOfVol);
	//SetWindowText(hStat,hStatText);
	goto End;
  }

  start = *lcnfr;
  percent[0]=0;oldpercent[0]=-1;
  while(start < *lcnfr)
  {	//memset(bitmap,0,bitmapsize);
    Bitmap->StartLcn = start;
	status = NtFsControlFile(hVolume,NULL,NULL,0,&iosb,FSCTL_GET_VOLUME_BITMAP,
							 &start,sizeof(ULONGLONG),Bitmap,bitmapsize);
	if(0x80000005==status)//NT_SUCCESS(status))
	{	NtWaitForSingleObject(hVolume,FALSE,NULL);
		status = iosb.Status;
	}
	if(status != STATUS_SUCCESS && status != STATUS_BUFFER_OVERFLOW)
	{	//wsprintf(hStatText,strngs[16],fileNameForVolLetter,start);
		//SetWindowText(hStat,hStatText);
		goto End;
	}

	percent[0] = (int)(100*(*lcnfr+sztoend-start)/sztoend);
	if(oldpercent[0]!=percent[0])
	{	//wsprintf(hStatText,strngs[17]/*L"%s:get volume bitmap,%d %c posted ..."*/,fileNameForVolLetter,percent[0],'%');
		//SetWindowText(hStat,hStatText);
	}
	oldpercent[0]=percent[0];

	MN = min(Bitmap->ClustersToEndOfVol, 8 * bitmapbytes);
	oldpercent[1]=-1;
	for(i=MN-1; i>=0; i--)//for(i=0; i<MN; i++)
	{ if(!(Bitmap->Map[i/8] & bitshift[i%8]))//cluster is free
	  { 
	  }
	  else
	  { if(bisy_rgn_start == LLINVALID)
		{	bisy_rgn_start = start + i;//wsprintf(hStatText,L"\nbisy_rgn_start: %I64u",bisy_rgn_start);OutputDebugStringW(hStatText);
	  } }
	  percent[1] = (int)(100-100*i/MN);//percent[1] = 100*i/MN;
	  if(percent[1]!=oldpercent[1])
	  {	//wsprintf(hStatText,strngs[19]/*L"%s:get volume bitmap,%d %c posted,analyze %d %c ..."*/,
		//	     fileNameForVolLetter,percent[0],L'%',percent[1],L'%');
		//SetWindowText(hStat,hStatText);
	  }
	  oldpercent[1]=percent[1];
	  if(0==i)break;//i int emas, 0dan keyin ham davom etib ketmasligi uchun;
	}
	start += bitmapbytes * 8;
	Bitmap->StartLcn = start;
  }
End:
  free(Bitmap);
  return 0;
}