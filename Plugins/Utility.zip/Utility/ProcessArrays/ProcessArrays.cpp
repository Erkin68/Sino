#include "windows.h"
#include "strsafe.h"
#include "resource.h"
#include "..\..\..\Operations\MyShell\ComboToDisk.h"
#include "..\..\..\Operations\MyShell\MyButtonC++.h"
#include "..\..\..\Operations\MyShell\MyShell.h"

HINSTANCE hInst;
CBToDisk processNamesCB,processNumsCB,inPosCB,cmndLineCB;

INT_PTR CALLBACK mainDlgProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	UNREFERENCED_PARAMETER(lParam);
	switch (message)
	{
	case WM_INITDIALOG:RECT r;int width,height,left,top;
		GetWindowRect(hDlg,&r);
		width = r.right - r.left;
		height = r.bottom - r.top;
		left=(GetSystemMetrics(SM_CXSCREEN) - width )/2;
		top = (int)(0.38*(GetSystemMetrics(SM_CYSCREEN) - height));
		MoveWindow(hDlg, left, top+20, width, height, TRUE);
		//SetWindowText(hDlg,strngs[21]);
		//SetDlgItemText(hDlg,IDC_STATIC8,strngs[3]);//"Existing file in disk:"

		EnableWindow(GetDlgItem(hDlg,IDC_COMBO_INSERT_INST_NUM),FALSE);
		processNamesCB.Read(L"prarry.cb:stream",GetDlgItem(hDlg,IDC_COMBO_NAMES),30,260);
		processNumsCB.Read(L"prarry.cb:stream1",GetDlgItem(hDlg,IDC_COMBO_NUMS),30,260);
		inPosCB.Read(L"prarry.cb:stream2",GetDlgItem(hDlg,IDC_COMBO_INSERT_INST_NUM),30,260);			
		cmndLineCB.Read(L"prarry.cb:stream3",GetDlgItem(hDlg,IDC_COMBO_ARGS),30,260);			

		//MyButtonFrRCBtn(hDlg,IDOK,0);
		//MyButtonFrRCBtn(hDlg,IDCANCEL,0);
		//MyButtonFrRCBtn(hDlg,IDC_BUTTON_BROWSE,0);
		return (INT_PTR)TRUE;

	case WM_COMMAND:
		switch(LOWORD(wParam))
		{	case IDC_BUTTON_BROWSE:OPENFILENAME ofn;wchar_t s[MAX_PATH];s[0]=0;ZeroMemory(&ofn, sizeof(ofn));
				ofn.lStructSize=sizeof(ofn);ofn.hwndOwner = hDlg;ofn.lpstrFile = s;ofn.nMaxFile = MAX_PATH;
				ofn.lpstrFilter = L"All *.exe files \0*.exe\0All *.bat files\0*.bat\0All *.com files\0*.com\0All *.* files\0*.*\0";
				ofn.nFilterIndex = 1;ofn.lpstrTitle  = L"Process file allocation ...";
				ofn.lpstrFileTitle = L"Process arrays.";
				ofn.Flags = OFN_PATHMUSTEXIST | OFN_FILEMUSTEXIST | OFN_HIDEREADONLY |OFN_EXTENSIONDIFFERENT;
				if(GetOpenFileName(&ofn))
				{	processNamesCB.AddToCB(GetDlgItem(hDlg,IDC_COMBO_NAMES),s,TRUE);
				}
			return 0;
			case IDOK:
				processNumsCB.GetCBEditText(GetDlgItem(hDlg,IDC_COMBO_NUMS),s,MAX_PATH);
				int iPr;iPr=_wtoi(s);
				if(iPr<0)iPr=0;
				if(iPr>500)
				{	MessageBox(hDlg,L"Running above 500 processes are not permitted.",L"Error...",MB_OK);
					return 0;
				}wchar_t prPath[MAX_PATH];
				processNamesCB.GetCBEditText(GetDlgItem(hDlg,IDC_COMBO_NAMES),prPath,MAX_PATH);
				wchar_t args[MAX_PATH];args[0]=' ';
				for(int i=0; i<iPr; ++i)
				{cmndLineCB.GetCBEditText(GetDlgItem(hDlg,IDC_COMBO_ARGS),args,MAX_PATH);
				 if(BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK100),BM_GETCHECK,0,0))
				 {processNumsCB.GetCBEditText(GetDlgItem(hDlg,IDC_COMBO_INSERT_INST_NUM),s,MAX_PATH);
				  int iInsToArgPos;iInsToArgPos=_wtoi(s)-1;
				  if(iInsToArgPos<0)iInsToArgPos=0;
				  int ln;ln=MyStringLength(args,MAX_PATH-1);
				  if(iInsToArgPos>ln)iInsToArgPos=ln;
				  wchar_t tmp[MAX_PATH+2];MyStringCpy(tmp,iInsToArgPos,args);
				  StringCchPrintf(&tmp[iInsToArgPos],MAX_PATH+2-iInsToArgPos,L"%d",i+1);
				  ln=MyStringLength(tmp,MAX_PATH+2);
				  MyStringCpy(&tmp[ln],MAX_PATH-ln,&args[iInsToArgPos]);
				  MyStringCpy(args,MAX_PATH,tmp);
				 }//if(IDYES!=MessageBox(hDlg,args,prPath,MB_YESNO))return 0;
				 STARTUPINFO si;ZeroMemory(&si,sizeof(si));si.cb=sizeof(si);PROCESS_INFORMATION pi;
				 if(0==CreateProcess(prPath,args,NULL,NULL,FALSE,0,NULL,NULL,&si,&pi))
				  ShellExecute(hDlg,L"open",prPath,args,NULL,SW_SHOW);
				}
				//**************************
				processNamesCB.Save(L"prarry.cb:stream",GetDlgItem(hDlg,IDC_COMBO_NAMES),30);
				processNumsCB.Save(L"prarry.cb:stream1",GetDlgItem(hDlg,IDC_COMBO_NUMS),30);
				inPosCB.Save(L"prarry.cb:stream2",GetDlgItem(hDlg,IDC_COMBO_INSERT_INST_NUM),30);
				cmndLineCB.GetCBEditText(GetDlgItem(hDlg,IDC_COMBO_ARGS),s,MAX_PATH);
				if(s[0])inPosCB.AddToCB(GetDlgItem(hDlg,IDC_COMBO_ARGS),s,TRUE);
				cmndLineCB.Save(L"prarry.cb:stream3",GetDlgItem(hDlg,IDC_COMBO_ARGS),30);			
				EndDialog(hDlg, LOWORD(wParam));
			return (INT_PTR)TRUE;
			case IDCANCEL:
				EndDialog(hDlg, LOWORD(wParam));
			return (INT_PTR)TRUE;
			case IDC_COMBO_NAMES:
			 if(CBN_EDITCHANGE==HIWORD(wParam))
			 {//processNamesCB.GetCBEditText(GetDlgItem(hDlg,IDC_COMBO_NAMES),s,MAX_PATH);
			  //processNamesCB.AddToCB(GetDlgItem(hDlg,IDC_COMBO_NAMES),s,TRUE);
			 }
			return 0;
			case IDC_COMBO_NUMS:
			 if(CBN_KILLFOCUS==HIWORD(wParam))
			 {processNumsCB.GetCBEditText(GetDlgItem(hDlg,IDC_COMBO_NUMS),s,MAX_PATH);
			  if(s[0])processNumsCB.AddToCB(GetDlgItem(hDlg,IDC_COMBO_NUMS),s,TRUE);
			 }				 
			return 0;
			case IDC_COMBO_ARGS:
			return 0;
			case IDC_COMBO_INSERT_INST_NUM:
			 if(CBN_KILLFOCUS==HIWORD(wParam))
			 {inPosCB.GetCBEditText(GetDlgItem(hDlg,IDC_COMBO_INSERT_INST_NUM),s,MAX_PATH);
			  if(s[0])inPosCB.AddToCB(GetDlgItem(hDlg,IDC_COMBO_INSERT_INST_NUM),s,TRUE);
			 }				 
			return 0;
			case IDC_CHECK100:
			 BOOL bchk=(BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK100),BM_GETCHECK,0,0)?TRUE:FALSE);
			 EnableWindow(GetDlgItem(hDlg,IDC_COMBO_INSERT_INST_NUM),bchk);
			return 0;
		}
		return 0;
		case WM_DESTROY:
		return 0;
	}
	return (INT_PTR)FALSE;
}

int APIENTRY WinMain(HINSTANCE hInstance,HINSTANCE hPrevInstance,LPSTR lpCmdLine,int nCmdShow)
{
	hInst = hInstance;
	return (int)DialogBox(hInst,MAKEINTRESOURCE(IDD_DIALOG_MAIN),NULL,mainDlgProc);
}