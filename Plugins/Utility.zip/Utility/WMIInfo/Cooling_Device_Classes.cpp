#define _WIN32_DCOM
#include <iostream>
using namespace std;
#include <comdef.h>
#include "commctrl.h"
#include <Wbemidl.h>
#include "WMIInfo.h"

# pragma comment(lib, "wbemuuid.lib")


extern HWND hWndTree;

LVITEM item = {LVIF_TEXT|LVIF_PARAM|LVIF_STATE,0,0,0,NULL,0,0,0,0,0,0};
VARIANT vtProp;wchar_t s[MAX_PATH];
IWbemClassObject *pclsObj;

VOID GetBool(wchar_t *prop)
{	item.pszText = prop;
	item.iSubItem = 0;
	SendMessage(hWndTree, LVM_INSERTITEM, (WPARAM)0, (LPARAM)&item);
	item.iSubItem = 1;
	item.pszText = s;
	if(pclsObj)
	if(S_OK==pclsObj->Get(prop, 0, &vtProp, 0, 0))
	{	if(VT_NULL!=vtProp.vt)
		{	wsprintf(s,true==(bool)vtProp.bstrVal?L"true":L"false");
			SendMessage(hWndTree, LVM_SETITEMTEXT, (WPARAM)0, (LPARAM)&item);
			VariantClear(&vtProp);
			return;
	}	}
	wsprintf(s,L"Boolean value, not defined ...");
	SendMessage(hWndTree, LVM_SETITEMTEXT, (WPARAM)0, (LPARAM)&item);
}

VOID GetDec(wchar_t *prop)
{	item.pszText = prop;
	item.iSubItem = 0;
	SendMessage(hWndTree, LVM_INSERTITEM, (WPARAM)0, (LPARAM)&item);
	item.iSubItem = 1;
	item.pszText = s;
	if(pclsObj)
	if(S_OK==pclsObj->Get(prop, 0, &vtProp, 0, 0))
	{	if(VT_NULL!=vtProp.vt)
		{	wsprintf(s,L"%d",vtProp.bstrVal);
			SendMessage(hWndTree, LVM_SETITEMTEXT, (WPARAM)0, (LPARAM)&item);
			VariantClear(&vtProp);
			return;
	}	}
	wsprintf(s,L"Dec. value, not defined ...");
	SendMessage(hWndTree, LVM_SETITEMTEXT, (WPARAM)0, (LPARAM)&item);
}

VOID GetChar(wchar_t *prop)
{	item.pszText = prop;
	item.iSubItem = 0;
	SendMessage(hWndTree, LVM_INSERTITEM, (WPARAM)0, (LPARAM)&item);
	item.iSubItem = 1;
	item.pszText = s;
	if(pclsObj)
	if(S_OK==pclsObj->Get(prop, 0, &vtProp, 0, 0))
	{	if(VT_NULL!=vtProp.vt)
		{	wsprintf(s,L"%c",vtProp.cVal);
			SendMessage(hWndTree, LVM_SETITEMTEXT, (WPARAM)0, (LPARAM)&item);
			VariantClear(&vtProp);
			return;
	}	}
	wsprintf(s,L"Dec. value, not defined ...");
	SendMessage(hWndTree, LVM_SETITEMTEXT, (WPARAM)0, (LPARAM)&item);
}

VOID GetDecArg1(wchar_t *prop,wchar_t *arg1)
{	item.pszText = prop;
	item.iSubItem = 0;
	SendMessage(hWndTree, LVM_INSERTITEM, (WPARAM)0, (LPARAM)&item);
	item.iSubItem = 1;
	item.pszText = s;
	if(pclsObj)
	if(S_OK==pclsObj->Get(prop, 0, &vtProp, 0, 0))
	{	if(VT_NULL!=vtProp.vt)
		{	wsprintf(s,L"%d %s",vtProp.bstrVal,arg1);
			SendMessage(hWndTree, LVM_SETITEMTEXT, (WPARAM)0, (LPARAM)&item);
			VariantClear(&vtProp);
			return;
	}	}
	wsprintf(s,L"Dec. value, not defined ...");
	SendMessage(hWndTree, LVM_SETITEMTEXT, (WPARAM)0, (LPARAM)&item);
}

VOID GetDecX64(wchar_t *prop)
{	item.pszText = prop;
	item.iSubItem = 0;
	SendMessage(hWndTree, LVM_INSERTITEM, (WPARAM)0, (LPARAM)&item);
	item.iSubItem = 1;
	item.pszText = s;
	if(pclsObj)
	if(S_OK==pclsObj->Get(prop, 0, &vtProp, 0, 0))
	{	if(VT_NULL!=vtProp.vt)
		{	wsprintf(s,L"0x%016x",vtProp.bstrVal);
			SendMessage(hWndTree, LVM_SETITEMTEXT, (WPARAM)0, (LPARAM)&item);
			VariantClear(&vtProp);
			return;
	}	}
	wsprintf(s,L"Dec. value, not defined ...");
	SendMessage(hWndTree, LVM_SETITEMTEXT, (WPARAM)0, (LPARAM)&item);
}

VOID GetStr(wchar_t *prop)
{	item.pszText = prop;
	item.iSubItem = 0;
	SendMessage(hWndTree, LVM_INSERTITEM, (WPARAM)0, (LPARAM)&item);
	item.iSubItem = 1;
	item.pszText = s;
	if(pclsObj)
	if(S_OK==pclsObj->Get(prop, 0, &vtProp, 0, 0))
	{	if(VT_NULL!=vtProp.vt)
		{	wsprintf(s,L"%s",vtProp.bstrVal);
			SendMessage(hWndTree, LVM_SETITEMTEXT, (WPARAM)0, (LPARAM)&item);
			VariantClear(&vtProp);
			return;
	}	}
	wsprintf(s,L"String value, not defined ...");
	SendMessage(hWndTree, LVM_SETITEMTEXT, (WPARAM)0, (LPARAM)&item);
}

VOID GetDatetime(wchar_t *prop)
{	item.pszText = prop;
	item.iSubItem = 0;
	SendMessage(hWndTree, LVM_INSERTITEM, (WPARAM)0, (LPARAM)&item);
	item.iSubItem = 1;
	item.pszText = s;
	if(pclsObj)
	if(S_OK==pclsObj->Get(prop, 0, &vtProp, 0, 0))
	{	if(VT_NULL!=vtProp.vt)
		{	wsprintf(s,L"%s",vtProp.bstrVal);
			SendMessage(hWndTree, LVM_SETITEMTEXT, (WPARAM)0, (LPARAM)&item);
			VariantClear(&vtProp);
			return;
	}	}
	wsprintf(s,L"String value, not defined ...");
	SendMessage(hWndTree, LVM_SETITEMTEXT, (WPARAM)0, (LPARAM)&item);
}

VOID GetDecArray(wchar_t *prop)
{	if(pclsObj)
	if(S_OK==pclsObj->Get(prop, 0, &vtProp, 0, 0))
	{	if(VT_NULL!=vtProp.vt)
		{	int cnt = vtProp.parray->cbElements;
			if(cnt)
			{	unsigned __int16 **p = (unsigned __int16**)vtProp.parray->pvData;
				for(int i=cnt-1; i>-1; i--)
				{	if(!IsBadReadPtr(p[i],4))
					{	item.pszText = prop;
						item.iSubItem = 0;
						SendMessage(hWndTree, LVM_INSERTITEM, (WPARAM)0, (LPARAM)&item);
						item.iSubItem = 1;
						item.pszText = s;
						wsprintf(s,L"(%d): %d",i+1,p[i]);
						SendMessage(hWndTree, LVM_SETITEMTEXT, (WPARAM)0, (LPARAM)&item);
				}	}
				VariantClear(&vtProp);
				return;
	}	}	}
	item.pszText = prop;
	item.iSubItem = 0;
	SendMessage(hWndTree, LVM_INSERTITEM, (WPARAM)0, (LPARAM)&item);
	wsprintf(s,L"Dec. array values, not defined ...");
	SendMessage(hWndTree, LVM_SETITEMTEXT, (WPARAM)0, (LPARAM)&item);
}

VOID GetReal(wchar_t *prop)
{	item.pszText = prop;
	item.iSubItem = 0;
	SendMessage(hWndTree, LVM_INSERTITEM, (WPARAM)0, (LPARAM)&item);
	item.iSubItem = 1;
	item.pszText = s;
	if(pclsObj)
	if(S_OK==pclsObj->Get(prop, 0, &vtProp, 0, 0))
	{	if(VT_NULL!=vtProp.vt)
		{	wsprintf(s,L"%f",vtProp.bstrVal);
			SendMessage(hWndTree, LVM_SETITEMTEXT, (WPARAM)0, (LPARAM)&item);
			VariantClear(&vtProp);
			return;
	}	}
	wsprintf(s,L"Dec. value, not defined ...");
	SendMessage(hWndTree, LVM_SETITEMTEXT, (WPARAM)0, (LPARAM)&item);
}

VOID GetStrArray(wchar_t *prop)
{	if(pclsObj)
	if(S_OK==pclsObj->Get(prop, 0, &vtProp, 0, 0))
	{	if(VT_NULL!=vtProp.vt)
		{	int cnt = vtProp.parray->cbElements;
			if(cnt)
			{	wchar_t **p = (wchar_t**)vtProp.parray->pvData;
				for(int i=cnt-1; i>-1; i--)
				{	if(!IsBadStringPtr(p[i],4))
					{	item.pszText = prop;
						item.iSubItem = 0;
						SendMessage(hWndTree, LVM_INSERTITEM, (WPARAM)0, (LPARAM)&item);
						item.iSubItem = 1;
						item.pszText = s;
						wsprintf(s,L"(%d) %s",i+1,p[i]);
						SendMessage(hWndTree, LVM_SETITEMTEXT, (WPARAM)0, (LPARAM)&item);
				}	}
				VariantClear(&vtProp);
				return;
	}	}	}
	item.pszText = prop;
	item.iSubItem = 0;
	SendMessage(hWndTree, LVM_INSERTITEM, (WPARAM)0, (LPARAM)&item);
	wsprintf(s,L"Dec. array values, not defined ...");
	SendMessage(hWndTree, LVM_SETITEMTEXT, (WPARAM)0, (LPARAM)&item);
}

VOID WMI_Cooling_Device_Classes_Win32_Fan()
{   HRESULT hres;
    hres =  CoInitializeEx(0, COINIT_MULTITHREADED); 
    if(FAILED(hres))
        return;
    hres =  CoInitializeSecurity(
        NULL, 
        -1,                          // COM authentication
        NULL,                        // Authentication services
        NULL,                        // Reserved
        RPC_C_AUTHN_LEVEL_DEFAULT,   // Default authentication 
        RPC_C_IMP_LEVEL_IMPERSONATE, // Default Impersonation  
        NULL,                        // Authentication info
        EOAC_NONE,                   // Additional capabilities 
        NULL                         // Reserved
        );
    if (FAILED(hres))
    {	CoUninitialize();
        return;                      // Program has failed.
    }
    IWbemLocator *pLoc = NULL;
    hres = CoCreateInstance(
        CLSID_WbemLocator,             
        0, 
        CLSCTX_INPROC_SERVER, 
        IID_IWbemLocator, (LPVOID *) &pLoc);
    if (FAILED(hres))
    {   CoUninitialize();
        return;						// Program has failed.
    }
    IWbemServices *pSvc = NULL;
    hres = pLoc->ConnectServer(
         _bstr_t(L"ROOT\\CIMV2"), // Object path of WMI namespace
         NULL,                    // User name. NULL = current user
         NULL,                    // User password. NULL = current
         0,                       // Locale. NULL indicates current
         NULL,                    // Security flags.
         0,                       // Authority (e.g. Kerberos)
         0,                       // Context object 
         &pSvc                    // pointer to IWbemServices proxy
         );
    
    if (FAILED(hres))
    {   pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    hres = CoSetProxyBlanket(
       pSvc,                        // Indicates the proxy to set
       RPC_C_AUTHN_WINNT,           // RPC_C_AUTHN_xxx
       RPC_C_AUTHZ_NONE,            // RPC_C_AUTHZ_xxx
       NULL,                        // Server principal name 
       RPC_C_AUTHN_LEVEL_CALL,      // RPC_C_AUTHN_LEVEL_xxx 
       RPC_C_IMP_LEVEL_IMPERSONATE, // RPC_C_IMP_LEVEL_xxx
       NULL,                        // client identity
       EOAC_NONE                    // proxy capabilities 
    );
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    IEnumWbemClassObject* pEnumerator = NULL;
    hres = pSvc->ExecQuery(
        bstr_t("WQL"), 
        bstr_t("SELECT * FROM Win32_Fan"),
        WBEM_FLAG_FORWARD_ONLY | WBEM_FLAG_RETURN_IMMEDIATELY, 
        NULL,
        &pEnumerator);
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();
        CoUninitialize();
        return;						// Program has failed.
    }
    pclsObj=0;
    ULONG uReturn = 0;
    while (pEnumerator)
    {  HRESULT hr = pEnumerator->Next(WBEM_INFINITE, 1, &pclsObj, &uReturn);
        //if(0 == uReturn)
		//   break;
		
		GetBool(L"ActiveCooling");
		GetDec(L"Availability");
		GetStr(L"Caption");
		GetConfigManagerErrorCode(L"ConfigManagerErrorCode");
		GetBool(L"ConfigManagerUserConfig");
		GetStr(L"CreationClassName");
		GetStr(L"Description");
		GetDec(L"DesiredSpeed");
		GetStr(L"DeviceID");
		GetBool(L"ErrorCleared");
		GetStr(L"ErrorDescription");
		GetStr(L"InstallDate");
		GetDec(L"LastErrorCode");
		GetStr(L"Name");
		GetStr(L"PNPDeviceID");
		GetDecArray(L"PowerManagementCapabilities");
 		GetBool(L"PowerManagementSupported");
		GetStr(L"Status");
		GetStr(L"StatusInfo");
		GetDec(L"SystemCreationClassName");
		GetDec(L"SystemName");
 		GetBool(L"VariableSpeed");

		item.pszText = L"";
		item.iSubItem = 0;
		SendMessage(hWndTree, LVM_INSERTITEM, (WPARAM)0, (LPARAM)&item);

        if(0 == uReturn)
		   break;
	}
    if(pSvc)pSvc->Release();
    if(pLoc)pLoc->Release();
    if(pEnumerator)pEnumerator->Release();
    if(pclsObj)pclsObj->Release();
    CoUninitialize();
}

VOID WMI_Cooling_Device_Classes_Win32_HeatPipe()
{   HRESULT hres;
    hres =  CoInitializeEx(0, COINIT_MULTITHREADED); 
    if(FAILED(hres))
        return;
    hres =  CoInitializeSecurity(
        NULL, 
        -1,                          // COM authentication
        NULL,                        // Authentication services
        NULL,                        // Reserved
        RPC_C_AUTHN_LEVEL_DEFAULT,   // Default authentication 
        RPC_C_IMP_LEVEL_IMPERSONATE, // Default Impersonation  
        NULL,                        // Authentication info
        EOAC_NONE,                   // Additional capabilities 
        NULL                         // Reserved
        );
    if (FAILED(hres))
    {	CoUninitialize();
        return;                      // Program has failed.
    }
    IWbemLocator *pLoc = NULL;
    hres = CoCreateInstance(
        CLSID_WbemLocator,             
        0, 
        CLSCTX_INPROC_SERVER, 
        IID_IWbemLocator, (LPVOID *) &pLoc);
    if (FAILED(hres))
    {   CoUninitialize();
        return;						// Program has failed.
    }
    IWbemServices *pSvc = NULL;
    hres = pLoc->ConnectServer(
         _bstr_t(L"ROOT\\CIMV2"), // Object path of WMI namespace
         NULL,                    // User name. NULL = current user
         NULL,                    // User password. NULL = current
         0,                       // Locale. NULL indicates current
         NULL,                    // Security flags.
         0,                       // Authority (e.g. Kerberos)
         0,                       // Context object 
         &pSvc                    // pointer to IWbemServices proxy
         );
    
    if (FAILED(hres))
    {   pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    hres = CoSetProxyBlanket(
       pSvc,                        // Indicates the proxy to set
       RPC_C_AUTHN_WINNT,           // RPC_C_AUTHN_xxx
       RPC_C_AUTHZ_NONE,            // RPC_C_AUTHZ_xxx
       NULL,                        // Server principal name 
       RPC_C_AUTHN_LEVEL_CALL,      // RPC_C_AUTHN_LEVEL_xxx 
       RPC_C_IMP_LEVEL_IMPERSONATE, // RPC_C_IMP_LEVEL_xxx
       NULL,                        // client identity
       EOAC_NONE                    // proxy capabilities 
    );
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    IEnumWbemClassObject* pEnumerator = NULL;
    hres = pSvc->ExecQuery(
        bstr_t("WQL"), 
        bstr_t("SELECT * FROM Win32_HeatPipe"),
        WBEM_FLAG_FORWARD_ONLY | WBEM_FLAG_RETURN_IMMEDIATELY, 
        NULL,
        &pEnumerator);
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();
        CoUninitialize();
        return;						// Program has failed.
    }
    pclsObj=0;
    ULONG uReturn = 0;
    while (pEnumerator)
    {  HRESULT hr = pEnumerator->Next(WBEM_INFINITE, 1, &pclsObj, &uReturn);
        //if(0 == uReturn)
		//   break;
		
		GetBool(L"ActiveCooling");
		GetDec(L"Availability");
		GetStr(L"Caption");
		GetConfigManagerErrorCode(L"ConfigManagerErrorCode");
		GetBool(L"ConfigManagerUserConfig");
		GetStr(L"CreationClassName");
		GetStr(L"Description");
		GetStr(L"DeviceID");
		GetBool(L"ErrorCleared");
		GetStr(L"ErrorDescription");
		GetStr(L"InstallDate");
		GetDec(L"LastErrorCode");
		GetStr(L"Name");
		GetStr(L"PNPDeviceID");
		GetDecArray(L"PowerManagementCapabilities");
 		GetBool(L"PowerManagementSupported");
		GetStr(L"Status");
		GetDec(L"StatusInfo");
		GetDec(L"SystemCreationClassName");
		GetDec(L"SystemName");

		item.pszText = L"";
		item.iSubItem = 0;
		SendMessage(hWndTree, LVM_INSERTITEM, (WPARAM)0, (LPARAM)&item);

		if(0 == uReturn)
		   break;
	}
    if(pSvc)pSvc->Release();
    if(pLoc)pLoc->Release();
    if(pEnumerator)pEnumerator->Release();
    if(pclsObj)pclsObj->Release();
    CoUninitialize();
}

VOID WMI_Cooling_Device_Classes_Win32_Refrigeration()
{   HRESULT hres;
    hres =  CoInitializeEx(0, COINIT_MULTITHREADED); 
    if(FAILED(hres))
        return;
    hres =  CoInitializeSecurity(
        NULL, 
        -1,                          // COM authentication
        NULL,                        // Authentication services
        NULL,                        // Reserved
        RPC_C_AUTHN_LEVEL_DEFAULT,   // Default authentication 
        RPC_C_IMP_LEVEL_IMPERSONATE, // Default Impersonation  
        NULL,                        // Authentication info
        EOAC_NONE,                   // Additional capabilities 
        NULL                         // Reserved
        );
    if (FAILED(hres))
    {	CoUninitialize();
        return;                      // Program has failed.
    }
    IWbemLocator *pLoc = NULL;
    hres = CoCreateInstance(
        CLSID_WbemLocator,             
        0, 
        CLSCTX_INPROC_SERVER, 
        IID_IWbemLocator, (LPVOID *) &pLoc);
    if (FAILED(hres))
    {   CoUninitialize();
        return;						// Program has failed.
    }
    IWbemServices *pSvc = NULL;
    hres = pLoc->ConnectServer(
         _bstr_t(L"ROOT\\CIMV2"), // Object path of WMI namespace
         NULL,                    // User name. NULL = current user
         NULL,                    // User password. NULL = current
         0,                       // Locale. NULL indicates current
         NULL,                    // Security flags.
         0,                       // Authority (e.g. Kerberos)
         0,                       // Context object 
         &pSvc                    // pointer to IWbemServices proxy
         );
    
    if (FAILED(hres))
    {   pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    hres = CoSetProxyBlanket(
       pSvc,                        // Indicates the proxy to set
       RPC_C_AUTHN_WINNT,           // RPC_C_AUTHN_xxx
       RPC_C_AUTHZ_NONE,            // RPC_C_AUTHZ_xxx
       NULL,                        // Server principal name 
       RPC_C_AUTHN_LEVEL_CALL,      // RPC_C_AUTHN_LEVEL_xxx 
       RPC_C_IMP_LEVEL_IMPERSONATE, // RPC_C_IMP_LEVEL_xxx
       NULL,                        // client identity
       EOAC_NONE                    // proxy capabilities 
    );
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    IEnumWbemClassObject* pEnumerator = NULL;
    hres = pSvc->ExecQuery(
        bstr_t("WQL"), 
        bstr_t("SELECT * FROM Win32_Refrigeration"),
        WBEM_FLAG_FORWARD_ONLY | WBEM_FLAG_RETURN_IMMEDIATELY, 
        NULL,
        &pEnumerator);
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();
        CoUninitialize();
        return;						// Program has failed.
    }
    pclsObj=0;
    ULONG uReturn = 0;
    while (pEnumerator)
    {  HRESULT hr = pEnumerator->Next(WBEM_INFINITE, 1, &pclsObj, &uReturn);
        //if(0 == uReturn)
		//   break;
		
		GetBool(L"ActiveCooling");
		GetDec(L"Availability");
		GetStr(L"Caption");
		GetConfigManagerErrorCode(L"ConfigManagerErrorCode");
		GetBool(L"ConfigManagerUserConfig");
		GetStr(L"CreationClassName");
		GetStr(L"Description");
		GetStr(L"DeviceID");
		GetBool(L"ErrorCleared");
		GetStr(L"ErrorDescription");
		GetStr(L"InstallDate");
		GetDec(L"LastErrorCode");
		GetStr(L"Name");
		GetStr(L"PNPDeviceID");
		GetDecArray(L"PowerManagementCapabilities");
 		GetBool(L"PowerManagementSupported");
		GetStr(L"Status");
		GetDec(L"StatusInfo");
		GetDec(L"SystemCreationClassName");
		GetDec(L"SystemName");

		item.pszText = L"";
		item.iSubItem = 0;
		SendMessage(hWndTree, LVM_INSERTITEM, (WPARAM)0, (LPARAM)&item);

		if(0 == uReturn)
		   break;
	}
    if(pSvc)pSvc->Release();
    if(pLoc)pLoc->Release();
    if(pEnumerator)pEnumerator->Release();
    if(pclsObj)pclsObj->Release();
    CoUninitialize();
}

VOID WMI_Cooling_Device_Classes_Win32_TemperatureProbe()
{   HRESULT hres;
    hres =  CoInitializeEx(0, COINIT_MULTITHREADED); 
    if(FAILED(hres))
        return;
    hres =  CoInitializeSecurity(
        NULL, 
        -1,                          // COM authentication
        NULL,                        // Authentication services
        NULL,                        // Reserved
        RPC_C_AUTHN_LEVEL_DEFAULT,   // Default authentication 
        RPC_C_IMP_LEVEL_IMPERSONATE, // Default Impersonation  
        NULL,                        // Authentication info
        EOAC_NONE,                   // Additional capabilities 
        NULL                         // Reserved
        );
    if (FAILED(hres))
    {	CoUninitialize();
        return;                      // Program has failed.
    }
    IWbemLocator *pLoc = NULL;
    hres = CoCreateInstance(
        CLSID_WbemLocator,             
        0, 
        CLSCTX_INPROC_SERVER, 
        IID_IWbemLocator, (LPVOID *) &pLoc);
    if (FAILED(hres))
    {   CoUninitialize();
        return;						// Program has failed.
    }
    IWbemServices *pSvc = NULL;
    hres = pLoc->ConnectServer(
         _bstr_t(L"ROOT\\CIMV2"), // Object path of WMI namespace
         NULL,                    // User name. NULL = current user
         NULL,                    // User password. NULL = current
         0,                       // Locale. NULL indicates current
         NULL,                    // Security flags.
         0,                       // Authority (e.g. Kerberos)
         0,                       // Context object 
         &pSvc                    // pointer to IWbemServices proxy
         );
    
    if (FAILED(hres))
    {   pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    hres = CoSetProxyBlanket(
       pSvc,                        // Indicates the proxy to set
       RPC_C_AUTHN_WINNT,           // RPC_C_AUTHN_xxx
       RPC_C_AUTHZ_NONE,            // RPC_C_AUTHZ_xxx
       NULL,                        // Server principal name 
       RPC_C_AUTHN_LEVEL_CALL,      // RPC_C_AUTHN_LEVEL_xxx 
       RPC_C_IMP_LEVEL_IMPERSONATE, // RPC_C_IMP_LEVEL_xxx
       NULL,                        // client identity
       EOAC_NONE                    // proxy capabilities 
    );
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    IEnumWbemClassObject* pEnumerator = NULL;
    hres = pSvc->ExecQuery(
        bstr_t("WQL"), 
        bstr_t("SELECT * FROM Win32_TemperatureProbe"),//CIM_TemperatureSensor"),
        WBEM_FLAG_FORWARD_ONLY | WBEM_FLAG_RETURN_IMMEDIATELY, 
        NULL,
        &pEnumerator);
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();
        CoUninitialize();
        return;						// Program has failed.
    }
    pclsObj=0;
    ULONG uReturn = 0;
    while (pEnumerator)
    {  HRESULT hr = pEnumerator->Next(WBEM_INFINITE, 1, &pclsObj, &uReturn);
		//if(0 == uReturn)
		//   break;
		
		GetDec(L"Accuracy");
		GetDec(L"Availability");
		GetStr(L"Caption");
		GetConfigManagerErrorCode(L"ConfigManagerErrorCode");
		GetBool(L"ConfigManagerUserConfig");
		GetStr(L"CreationClassName");
		GetDec(L"CurrentReading");
		GetStr(L"Description");
		GetStr(L"DeviceID");
		GetBool(L"ErrorCleared");
		GetStr(L"ErrorDescription");
		GetStr(L"InstallDate");
		GetBool(L"IsLinear");
		GetDec(L"LastErrorCode");
		GetDec(L"LowerThresholdCritical");
		GetDec(L"LowerThresholdFatal");
		GetDec(L"LowerThresholdNonCritical");
		GetDec(L"MaxReadable");
		GetDec(L"MinReadable");
		GetStr(L"Name");
		GetDec(L"NominalReading");
		GetDec(L"NormalMax");
		GetDec(L"NormalMin");
		GetStr(L"PNPDeviceID");
		GetDecArray(L"PowerManagementCapabilities");
		GetBool(L"PowerManagementSupported");
		GetDec(L"Resolution");
		GetStr(L"Status");
		GetDec(L"StatusInfo");
		GetStr(L"SystemCreationClassName");
		GetStr(L"SystemName");
		GetDec(L"Tolerance");
		GetDec(L"UpperThresholdCritical");
		GetDec(L"UpperThresholdFatal");
		GetDec(L"UpperThresholdNonCritical");

		item.pszText = L"";
		item.iSubItem = 0;
		SendMessage(hWndTree, LVM_INSERTITEM, (WPARAM)0, (LPARAM)&item);

		if(0 == uReturn)
		   break;
	}
    if(pSvc)pSvc->Release();
    if(pLoc)pLoc->Release();
    if(pEnumerator)pEnumerator->Release();
    if(pclsObj)pclsObj->Release();
    CoUninitialize();
}