#define _WIN32_DCOM
#include <iostream>
using namespace std;
#include <comdef.h>
#include "WMIInfo.h"


# pragma comment(lib, "wbemuuid.lib")


extern HWND hWndTree;

VOID WMI_Motherboard_Classes_Win32_PotsModem()
{   HRESULT hres;
    hres =  CoInitializeEx(0, COINIT_MULTITHREADED); 
    if(FAILED(hres))
        return;
    hres =  CoInitializeSecurity(
        NULL, 
        -1,                          // COM authentication
        NULL,                        // Authentication services
        NULL,                        // Reserved
        RPC_C_AUTHN_LEVEL_DEFAULT,   // Default authentication 
        RPC_C_IMP_LEVEL_IMPERSONATE, // Default Impersonation  
        NULL,                        // Authentication info
        EOAC_NONE,                   // Additional capabilities 
        NULL                         // Reserved
        );
    if (FAILED(hres))
    {	CoUninitialize();
        return;                      // Program has failed.
    }
    IWbemLocator *pLoc = NULL;
    hres = CoCreateInstance(
        CLSID_WbemLocator,             
        0, 
        CLSCTX_INPROC_SERVER, 
        IID_IWbemLocator, (LPVOID *) &pLoc);
    if (FAILED(hres))
    {   CoUninitialize();
        return;						// Program has failed.
    }
    IWbemServices *pSvc = NULL;
    hres = pLoc->ConnectServer(
         _bstr_t(L"ROOT\\CIMV2"), // Object path of WMI namespace
         NULL,                    // User name. NULL = current user
         NULL,                    // User password. NULL = current
         0,                       // Locale. NULL indicates current
         NULL,                    // Security flags.
         0,                       // Authority (e.g. Kerberos)
         0,                       // Context object 
         &pSvc                    // pointer to IWbemServices proxy
         );
    
    if (FAILED(hres))
    {   pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    hres = CoSetProxyBlanket(
       pSvc,                        // Indicates the proxy to set
       RPC_C_AUTHN_WINNT,           // RPC_C_AUTHN_xxx
       RPC_C_AUTHZ_NONE,            // RPC_C_AUTHZ_xxx
       NULL,                        // Server principal name 
       RPC_C_AUTHN_LEVEL_CALL,      // RPC_C_AUTHN_LEVEL_xxx 
       RPC_C_IMP_LEVEL_IMPERSONATE, // RPC_C_IMP_LEVEL_xxx
       NULL,                        // client identity
       EOAC_NONE                    // proxy capabilities 
    );
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    IEnumWbemClassObject* pEnumerator = NULL;
    hres = pSvc->ExecQuery(
        bstr_t("WQL"), 
        bstr_t("SELECT * FROM Win32_PotsModem"),
        WBEM_FLAG_FORWARD_ONLY | WBEM_FLAG_RETURN_IMMEDIATELY, 
        NULL,
        &pEnumerator);
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();
        CoUninitialize();
        return;						// Program has failed.
    }
    pclsObj=0;
    ULONG uReturn = 0;
    while (pEnumerator)
    {	HRESULT hr = pEnumerator->Next(WBEM_INFINITE, 1, &pclsObj, &uReturn);
		//if(0 == uReturn)
		//  break;

		GetStr(L"VoiceSwitchFeature");
		GetStr(L"Tone");
		GetDatetime(L"TimeOfLastReset");
		GetStr(L"Terminator");
		GetStr(L"SystemName");
		GetStr(L"SystemCreationClassName");
		GetBool(L"SupportsSynchronousConnect");
		GetBool(L"SupportsCallback");
		GetStr(L"StringFormat");
		GetDec(L"StatusInfo");
		GetStr(L"Status");
		GetStr(L"SpeakerVolumeMed");
		GetStr(L"SpeakerVolumeLow");
		GetDec(L"SpeakerVolumeInfo");
		GetStr(L"SpeakerVolumeHigh");
		GetStr(L"SpeakerModeSetup");
		GetStr(L"SpeakerModeOn");
		GetStr(L"SpeakerModeOff");
		GetStr(L"SpeakerModeDial");
		GetDec(L"RingsBeforeAnswer");
		GetStr(L"ResponsesKeyName");
		GetStr(L"Reset");
		GetStr(L"Pulse");
		GetStr(L"ProviderName");
		GetDecArray(L"Properties");
		GetStr(L"Prefix");
		GetBool(L"PowerManagementSupported");
		GetDecArray(L"PowerManagementCapabilities");
		GetStr(L"PortSubClass");
		GetStr(L"PNPDeviceID");
		GetStr(L"Name");
		GetDec(L"ModulationScheme");
		GetStr(L"ModulationCCITT");
		GetStr(L"ModulationBell");
		GetStr(L"ModemInfSection");
		GetStr(L"ModemInfPath");
		GetStr(L"Model");
		GetDec(L"MaxNumberOfPasswords");
		GetDec(L"MaxBaudRateToSerialPort");
		GetDec(L"MaxBaudRateToPhone");
		GetDec(L"LastErrorCode");
		GetDatetime(L"InstallDate");
		GetDec(L"Index");
		GetDec(L"InactivityTimeout");
		GetStr(L"ErrorControlOn");
		GetStr(L"ErrorDescription");
		GetStr(L"FlowControlHard");
		GetStr(L"FlowControlOff");
		GetStr(L"FlowControlSoft");
		GetStr(L"InactivityScale");
		GetStr(L"ErrorControlOff");
		GetDec(L"ErrorControlInfo");
		GetStr(L"ErrorControlForced");
		GetBool(L"ErrorCleared");
		GetDatetime(L"DriverDate");
		GetDec(L"DialType");
		GetStr(L"DeviceType");
		GetStr(L"DeviceLoader");
		GetStr(L"DeviceID");
		GetStr(L"Description");
		GetDecArray(L"Default");
		GetDecArray(L"DCB");
		GetStrArray(L"CurrentPasswords");
		GetStr(L"CreationClassName");
		GetStr(L"CountrySelected");
		GetStrArray(L"CountriesSupported");
		GetStr(L"ConfigurationDialog");
		GetBool(L"ConfigManagerUserConfig");
		GetDec(L"ConfigManagerErrorCode");
		GetStr(L"CompressionOn");
		GetStr(L"CompressionOff");
		GetDec(L"CompressionInfo");
		GetStr(L"CompatibilityFlags");
		GetStr(L"Caption");
		GetStr(L"BlindOn");
		GetStr(L"BlindOff");		
		GetDec(L"Availability");
		GetStr(L"AttachedTo");
		GetDec(L"AnswerMode");
   
		item.pszText = L"";
		item.iSubItem = 0;
		SendMessage(hWndTree, LVM_INSERTITEM, (WPARAM)0, (LPARAM)&item);

		if(0 == uReturn)
		  break;
	}
    if(pSvc)pSvc->Release();
    if(pLoc)pLoc->Release();
    if(pEnumerator)pEnumerator->Release();
    if(pclsObj)pclsObj->Release();
    CoUninitialize();
}

VOID WMI_Motherboard_Classes_Win32_POTSModemToSerialPort()
{   HRESULT hres;
    hres =  CoInitializeEx(0, COINIT_MULTITHREADED); 
    if(FAILED(hres))
        return;
    hres =  CoInitializeSecurity(
        NULL, 
        -1,                          // COM authentication
        NULL,                        // Authentication services
        NULL,                        // Reserved
        RPC_C_AUTHN_LEVEL_DEFAULT,   // Default authentication 
        RPC_C_IMP_LEVEL_IMPERSONATE, // Default Impersonation  
        NULL,                        // Authentication info
        EOAC_NONE,                   // Additional capabilities 
        NULL                         // Reserved
        );
    if (FAILED(hres))
    {	CoUninitialize();
        return;                      // Program has failed.
    }
    IWbemLocator *pLoc = NULL;
    hres = CoCreateInstance(
        CLSID_WbemLocator,             
        0, 
        CLSCTX_INPROC_SERVER, 
        IID_IWbemLocator, (LPVOID *) &pLoc);
    if (FAILED(hres))
    {   CoUninitialize();
        return;						// Program has failed.
    }
    IWbemServices *pSvc = NULL;
    hres = pLoc->ConnectServer(
         _bstr_t(L"ROOT\\CIMV2"), // Object path of WMI namespace
         NULL,                    // User name. NULL = current user
         NULL,                    // User password. NULL = current
         0,                       // Locale. NULL indicates current
         NULL,                    // Security flags.
         0,                       // Authority (e.g. Kerberos)
         0,                       // Context object 
         &pSvc                    // pointer to IWbemServices proxy
         );
    
    if (FAILED(hres))
    {   pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    hres = CoSetProxyBlanket(
       pSvc,                        // Indicates the proxy to set
       RPC_C_AUTHN_WINNT,           // RPC_C_AUTHN_xxx
       RPC_C_AUTHZ_NONE,            // RPC_C_AUTHZ_xxx
       NULL,                        // Server principal name 
       RPC_C_AUTHN_LEVEL_CALL,      // RPC_C_AUTHN_LEVEL_xxx 
       RPC_C_IMP_LEVEL_IMPERSONATE, // RPC_C_IMP_LEVEL_xxx
       NULL,                        // client identity
       EOAC_NONE                    // proxy capabilities 
    );
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    IEnumWbemClassObject* pEnumerator = NULL;
    hres = pSvc->ExecQuery(
        bstr_t("WQL"), 
        bstr_t("SELECT * FROM Win32_POTSModemToSerialPort"),
        WBEM_FLAG_FORWARD_ONLY | WBEM_FLAG_RETURN_IMMEDIATELY, 
        NULL,
        &pEnumerator);
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();
        CoUninitialize();
        return;						// Program has failed.
    }
    pclsObj=0;
    ULONG uReturn = 0;
    while (pEnumerator)
    {	HRESULT hr = pEnumerator->Next(WBEM_INFINITE, 1, &pclsObj, &uReturn);
		//if(0 == uReturn)
		//  break;

		GetDec(L"NumberOfSoftResets");
		GetDec(L"NumberOfHardResets");
		GetDec(L"NegotiatedSpeed");
		GetDec(L"NegotiatedDataWidth");
		GetStr(L"Dependent");//Win32_POTSModem ref Dependent;
		GetStr(L"Antecedent");//Win32_SerialPort ref Antecedent;
		GetDec(L"AccessState");
   
		item.pszText = L"";
		item.iSubItem = 0;
		SendMessage(hWndTree, LVM_INSERTITEM, (WPARAM)0, (LPARAM)&item);

		if(0 == uReturn)
		  break;
	}
    if(pSvc)pSvc->Release();
    if(pLoc)pLoc->Release();
    if(pEnumerator)pEnumerator->Release();
    if(pclsObj)pclsObj->Release();
    CoUninitialize();
}