#define _WIN32_DCOM
#include <iostream>
using namespace std;
#include <comdef.h>
#include "WMIInfo.h"


# pragma comment(lib, "wbemuuid.lib")


extern HWND hWndTree;


VOID WMI_Motherboard_Classes_Win32_NetworkAdapter()
{   HRESULT hres;
    hres =  CoInitializeEx(0, COINIT_MULTITHREADED); 
    if(FAILED(hres))
        return;
    hres =  CoInitializeSecurity(
        NULL, 
        -1,                          // COM authentication
        NULL,                        // Authentication services
        NULL,                        // Reserved
        RPC_C_AUTHN_LEVEL_DEFAULT,   // Default authentication 
        RPC_C_IMP_LEVEL_IMPERSONATE, // Default Impersonation  
        NULL,                        // Authentication info
        EOAC_NONE,                   // Additional capabilities 
        NULL                         // Reserved
        );
    if (FAILED(hres))
    {	CoUninitialize();
        return;                      // Program has failed.
    }
    IWbemLocator *pLoc = NULL;
    hres = CoCreateInstance(
        CLSID_WbemLocator,             
        0, 
        CLSCTX_INPROC_SERVER, 
        IID_IWbemLocator, (LPVOID *) &pLoc);
    if (FAILED(hres))
    {   CoUninitialize();
        return;						// Program has failed.
    }
    IWbemServices *pSvc = NULL;
    hres = pLoc->ConnectServer(
         _bstr_t(L"ROOT\\CIMV2"), // Object path of WMI namespace
         NULL,                    // User name. NULL = current user
         NULL,                    // User password. NULL = current
         0,                       // Locale. NULL indicates current
         NULL,                    // Security flags.
         0,                       // Authority (e.g. Kerberos)
         0,                       // Context object 
         &pSvc                    // pointer to IWbemServices proxy
         );
    
    if (FAILED(hres))
    {   pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    hres = CoSetProxyBlanket(
       pSvc,                        // Indicates the proxy to set
       RPC_C_AUTHN_WINNT,           // RPC_C_AUTHN_xxx
       RPC_C_AUTHZ_NONE,            // RPC_C_AUTHZ_xxx
       NULL,                        // Server principal name 
       RPC_C_AUTHN_LEVEL_CALL,      // RPC_C_AUTHN_LEVEL_xxx 
       RPC_C_IMP_LEVEL_IMPERSONATE, // RPC_C_IMP_LEVEL_xxx
       NULL,                        // client identity
       EOAC_NONE                    // proxy capabilities 
    );
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    IEnumWbemClassObject* pEnumerator = NULL;
    hres = pSvc->ExecQuery(
        bstr_t("WQL"), 
        bstr_t("SELECT * FROM Win32_NetworkAdapter"),
        WBEM_FLAG_FORWARD_ONLY | WBEM_FLAG_RETURN_IMMEDIATELY, 
        NULL,
        &pEnumerator);
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();
        CoUninitialize();
        return;						// Program has failed.
    }
    pclsObj=0;
    ULONG uReturn = 0;
    while (pEnumerator)
    {	HRESULT hr = pEnumerator->Next(WBEM_INFINITE, 1, &pclsObj, &uReturn);
		//if(0 == uReturn)
		//  break;

		GetDatetime(L"TimeOfLastReset");
		GetStr(L"SystemName");
		GetStr(L"SystemCreationClassName");
		GetDec(L"StatusInfo");
		GetStr(L"Status");
		GetDec(L"Speed");
		GetStr(L"ServiceName");
		GetStr(L"ProductName");
		GetBool(L"PowerManagementSupported");
		GetDecArray(L"PowerManagementCapabilities");
		GetStr(L"PNPDeviceID");
		GetBool(L"PhysicalAdapter");
		GetStr(L"PermanentAddress");
		GetStrArray(L"NetworkAddresses");
		GetBool(L"NetEnabled");
		GetDec(L"NetConnectionStatus");
		GetStr(L"NetConnectionID");
		GetStr(L"Name");
		GetDec(L"MaxSpeed");
		GetDec(L"MaxNumberControlled");
		GetStr(L"Manufacturer");
		GetStr(L"MACAddress");
		GetDec(L"LastErrorCode");
		GetDec(L"InterfaceIndex");
		GetBool(L"Installed");
		GetDatetime(L"InstallDate");
		GetDec(L"Index");
		GetStr(L"GUID");
		GetStr(L"ErrorDescription");
		GetBool(L"ErrorCleared");
		GetStr(L"DeviceID");
		GetStr(L"Description");
		GetStr(L"CreationClassName");
		GetBool(L"ConfigManagerUserConfig");
		GetDec(L"ConfigManagerErrorCode");
		GetStr(L"Caption");
		GetCacheMemoryAvailability(L"Availability");
		GetBool(L"AutoSense");
		GetDec(L"AdapterTypeID");
		GetStr(L"AdapterType");

		item.pszText = L"";
		item.iSubItem = 0;
		SendMessage(hWndTree, LVM_INSERTITEM, (WPARAM)0, (LPARAM)&item);

		if(0 == uReturn)
		  break;
	}
    if(pSvc)pSvc->Release();
    if(pLoc)pLoc->Release();
    if(pEnumerator)pEnumerator->Release();
    if(pclsObj)pclsObj->Release();
    CoUninitialize();
}

VOID WMI_Motherboard_Classes_Win32_NetworkAdapterConfiguration()
{   HRESULT hres;
    hres =  CoInitializeEx(0, COINIT_MULTITHREADED); 
    if(FAILED(hres))
        return;
    hres =  CoInitializeSecurity(
        NULL, 
        -1,                          // COM authentication
        NULL,                        // Authentication services
        NULL,                        // Reserved
        RPC_C_AUTHN_LEVEL_DEFAULT,   // Default authentication 
        RPC_C_IMP_LEVEL_IMPERSONATE, // Default Impersonation  
        NULL,                        // Authentication info
        EOAC_NONE,                   // Additional capabilities 
        NULL                         // Reserved
        );
    if (FAILED(hres))
    {	CoUninitialize();
        return;                      // Program has failed.
    }
    IWbemLocator *pLoc = NULL;
    hres = CoCreateInstance(
        CLSID_WbemLocator,             
        0, 
        CLSCTX_INPROC_SERVER, 
        IID_IWbemLocator, (LPVOID *) &pLoc);
    if (FAILED(hres))
    {   CoUninitialize();
        return;						// Program has failed.
    }
    IWbemServices *pSvc = NULL;
    hres = pLoc->ConnectServer(
         _bstr_t(L"ROOT\\CIMV2"), // Object path of WMI namespace
         NULL,                    // User name. NULL = current user
         NULL,                    // User password. NULL = current
         0,                       // Locale. NULL indicates current
         NULL,                    // Security flags.
         0,                       // Authority (e.g. Kerberos)
         0,                       // Context object 
         &pSvc                    // pointer to IWbemServices proxy
         );
    
    if (FAILED(hres))
    {   pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    hres = CoSetProxyBlanket(
       pSvc,                        // Indicates the proxy to set
       RPC_C_AUTHN_WINNT,           // RPC_C_AUTHN_xxx
       RPC_C_AUTHZ_NONE,            // RPC_C_AUTHZ_xxx
       NULL,                        // Server principal name 
       RPC_C_AUTHN_LEVEL_CALL,      // RPC_C_AUTHN_LEVEL_xxx 
       RPC_C_IMP_LEVEL_IMPERSONATE, // RPC_C_IMP_LEVEL_xxx
       NULL,                        // client identity
       EOAC_NONE                    // proxy capabilities 
    );
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    IEnumWbemClassObject* pEnumerator = NULL;
    hres = pSvc->ExecQuery(
        bstr_t("WQL"), 
        bstr_t("SELECT * FROM Win32_NetworkAdapterConfiguration"),
        WBEM_FLAG_FORWARD_ONLY | WBEM_FLAG_RETURN_IMMEDIATELY, 
        NULL,
        &pEnumerator);
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();
        CoUninitialize();
        return;						// Program has failed.
    }
    pclsObj=0;
    ULONG uReturn = 0;
    while (pEnumerator)
    {	HRESULT hr = pEnumerator->Next(WBEM_INFINITE, 1, &pclsObj, &uReturn);
		//if(0 == uReturn)
		//  break;

		GetStr(L"WINSSecondaryServer");
		GetStr(L"WINSScopeID");
		GetStr(L"WINSPrimaryServer");
		GetStr(L"WINSHostLookupFile");
		GetBool(L"WINSEnableLMHostsLookup");
		GetDec(L"TcpWindowSize");
		GetBool(L"TcpUseRFC1122UrgentPointer");
		GetDec(L"TcpNumConnections");
		GetDec(L"TcpMaxDataRetransmissions");
		GetDec(L"TcpMaxConnectRetransmissions");
		GetDec(L"TcpipNetbiosOptions");
		GetStr(L"SettingID");
		GetStr(L"ServiceName");
		GetBool(L"PMTUDiscoveryEnabled");
		GetBool(L"PMTUBHDetectEnabled");
		GetDec(L"NumForwardPackets");
		GetDec(L"MTU");
		GetStr(L"MACAddress");
		GetDec(L"KeepAliveTime");
		GetDec(L"KeepAliveInterval");
		GetStr(L"IPXVirtualNetNumber");
		GetStrArray(L"IPXNetworkNumber");
		GetDec(L"IPXMediaType");
		GetDecArray(L"IPXFrameType");
		GetBool(L"IPXEnabled");
		GetStr(L"IPXAddress");
		GetBool(L"IPUseZeroBroadcast");
		GetStrArray(L"IPSubnet");
		GetStrArray(L"IPSecPermitUDPPorts");
		GetStrArray(L"IPSecPermitTCPPorts");
		GetStrArray(L"IPSecPermitIPProtocols");
		GetBool(L"IPPortSecurityEnabled");
		GetBool(L"IPFilterSecurityEnabled");
		GetBool(L"IPEnabled");
		GetDec(L"IPConnectionMetric");
		GetStrArray(L"IPAddress");
		GetDec(L"InterfaceIndex");
		GetDec(L"Index");
		GetChar(L"IGMPLevel");
		GetDecArray(L"GatewayCostMetric");
		GetBool(L"FullDNSRegistrationEnabled");
		GetDec(L"ForwardBufferMemory");
		GetBool(L"DomainDNSRegistrationEnabled");
		GetStrArray(L"DNSServerSearchOrder");
		GetStr(L"DNSHostName");
		GetBool(L"DNSEnabledForWINSResolution");
		GetStrArray(L"DNSDomainSuffixSearchOrder");
		GetStr(L"DNSDomain");
		GetStr(L"DHCPServer");
		GetDatetime(L"DHCPLeaseObtained");
		GetDatetime(L"DHCPLeaseExpires");
		GetBool(L"DHCPEnabled");
		GetStr(L"Description");
		GetChar(L"DefaultTTL");
		GetChar(L"DefaultTOS");
		GetStrArray(L"DefaultIPGateway");
		GetBool(L"DeadGWDetectEnabled");
		GetStr(L"DatabasePath");
		GetStr(L"Caption");
		GetBool(L"ArpUseEtherSNAP");
		GetBool(L"ArpAlwaysSourceRoute");

		item.pszText = L"";
		item.iSubItem = 0;
		SendMessage(hWndTree, LVM_INSERTITEM, (WPARAM)0, (LPARAM)&item);

		if(0 == uReturn)
		  break;
	}
    if(pSvc)pSvc->Release();
    if(pLoc)pLoc->Release();
    if(pEnumerator)pEnumerator->Release();
    if(pclsObj)pclsObj->Release();
    CoUninitialize();
}

VOID WMI_Motherboard_Classes_Win32_NetworkAdapterSetting()
{   HRESULT hres;
    hres =  CoInitializeEx(0, COINIT_MULTITHREADED); 
    if(FAILED(hres))
        return;
    hres =  CoInitializeSecurity(
        NULL, 
        -1,                          // COM authentication
        NULL,                        // Authentication services
        NULL,                        // Reserved
        RPC_C_AUTHN_LEVEL_DEFAULT,   // Default authentication 
        RPC_C_IMP_LEVEL_IMPERSONATE, // Default Impersonation  
        NULL,                        // Authentication info
        EOAC_NONE,                   // Additional capabilities 
        NULL                         // Reserved
        );
    if (FAILED(hres))
    {	CoUninitialize();
        return;                      // Program has failed.
    }
    IWbemLocator *pLoc = NULL;
    hres = CoCreateInstance(
        CLSID_WbemLocator,             
        0, 
        CLSCTX_INPROC_SERVER, 
        IID_IWbemLocator, (LPVOID *) &pLoc);
    if (FAILED(hres))
    {   CoUninitialize();
        return;						// Program has failed.
    }
    IWbemServices *pSvc = NULL;
    hres = pLoc->ConnectServer(
         _bstr_t(L"ROOT\\CIMV2"), // Object path of WMI namespace
         NULL,                    // User name. NULL = current user
         NULL,                    // User password. NULL = current
         0,                       // Locale. NULL indicates current
         NULL,                    // Security flags.
         0,                       // Authority (e.g. Kerberos)
         0,                       // Context object 
         &pSvc                    // pointer to IWbemServices proxy
         );
    
    if (FAILED(hres))
    {   pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    hres = CoSetProxyBlanket(
       pSvc,                        // Indicates the proxy to set
       RPC_C_AUTHN_WINNT,           // RPC_C_AUTHN_xxx
       RPC_C_AUTHZ_NONE,            // RPC_C_AUTHZ_xxx
       NULL,                        // Server principal name 
       RPC_C_AUTHN_LEVEL_CALL,      // RPC_C_AUTHN_LEVEL_xxx 
       RPC_C_IMP_LEVEL_IMPERSONATE, // RPC_C_IMP_LEVEL_xxx
       NULL,                        // client identity
       EOAC_NONE                    // proxy capabilities 
    );
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    IEnumWbemClassObject* pEnumerator = NULL;
    hres = pSvc->ExecQuery(
        bstr_t("WQL"), 
        bstr_t("SELECT * FROM Win32_NetworkAdapterSetting"),
        WBEM_FLAG_FORWARD_ONLY | WBEM_FLAG_RETURN_IMMEDIATELY, 
        NULL,
        &pEnumerator);
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();
        CoUninitialize();
        return;						// Program has failed.
    }
    pclsObj=0;
    ULONG uReturn = 0;
    while (pEnumerator)
    {	HRESULT hr = pEnumerator->Next(WBEM_INFINITE, 1, &pclsObj, &uReturn);
		//if(0 == uReturn)
		//  break;

		GetStr(L"Setting");//Win32_NetworkAdapterConfiguration ref Setting;
		GetStr(L"Element");//Win32_NetworkAdapter ref Element;

		item.pszText = L"";
		item.iSubItem = 0;
		SendMessage(hWndTree, LVM_INSERTITEM, (WPARAM)0, (LPARAM)&item);

		if(0 == uReturn)
		  break;
	}
    if(pSvc)pSvc->Release();
    if(pLoc)pLoc->Release();
    if(pEnumerator)pEnumerator->Release();
    if(pclsObj)pclsObj->Release();
    CoUninitialize();
}