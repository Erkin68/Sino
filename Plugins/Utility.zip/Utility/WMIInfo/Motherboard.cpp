#define _WIN32_DCOM
#include <iostream>
using namespace std;
#include <comdef.h>
#include "WMIInfo.h"


# pragma comment(lib, "wbemuuid.lib")


extern HWND hWndTree;


VOID WMI_Motherboard_Classes_Win32_1394Controller()
{   HRESULT hres;
    hres =  CoInitializeEx(0, COINIT_MULTITHREADED); 
    if(FAILED(hres))
        return;
    hres =  CoInitializeSecurity(
        NULL, 
        -1,                          // COM authentication
        NULL,                        // Authentication services
        NULL,                        // Reserved
        RPC_C_AUTHN_LEVEL_DEFAULT,   // Default authentication 
        RPC_C_IMP_LEVEL_IMPERSONATE, // Default Impersonation  
        NULL,                        // Authentication info
        EOAC_NONE,                   // Additional capabilities 
        NULL                         // Reserved
        );
    if (FAILED(hres))
    {	CoUninitialize();
        return;                      // Program has failed.
    }
    IWbemLocator *pLoc = NULL;
    hres = CoCreateInstance(
        CLSID_WbemLocator,             
        0, 
        CLSCTX_INPROC_SERVER, 
        IID_IWbemLocator, (LPVOID *) &pLoc);
    if (FAILED(hres))
    {   CoUninitialize();
        return;						// Program has failed.
    }
    IWbemServices *pSvc = NULL;
    hres = pLoc->ConnectServer(
         _bstr_t(L"ROOT\\CIMV2"), // Object path of WMI namespace
         NULL,                    // User name. NULL = current user
         NULL,                    // User password. NULL = current
         0,                       // Locale. NULL indicates current
         NULL,                    // Security flags.
         0,                       // Authority (e.g. Kerberos)
         0,                       // Context object 
         &pSvc                    // pointer to IWbemServices proxy
         );
    
    if (FAILED(hres))
    {   pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    hres = CoSetProxyBlanket(
       pSvc,                        // Indicates the proxy to set
       RPC_C_AUTHN_WINNT,           // RPC_C_AUTHN_xxx
       RPC_C_AUTHZ_NONE,            // RPC_C_AUTHZ_xxx
       NULL,                        // Server principal name 
       RPC_C_AUTHN_LEVEL_CALL,      // RPC_C_AUTHN_LEVEL_xxx 
       RPC_C_IMP_LEVEL_IMPERSONATE, // RPC_C_IMP_LEVEL_xxx
       NULL,                        // client identity
       EOAC_NONE                    // proxy capabilities 
    );
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    IEnumWbemClassObject* pEnumerator = NULL;
    hres = pSvc->ExecQuery(
        bstr_t("WQL"), 
        bstr_t("SELECT * FROM Win32_1394Controller"),
        WBEM_FLAG_FORWARD_ONLY | WBEM_FLAG_RETURN_IMMEDIATELY, 
        NULL,
        &pEnumerator);
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();
        CoUninitialize();
        return;						// Program has failed.
    }
    pclsObj=0;
    ULONG uReturn = 0;
    while (pEnumerator)
    {	HRESULT hr = pEnumerator->Next(WBEM_INFINITE, 1, &pclsObj, &uReturn);
		//if(0 == uReturn)
		//  break;

		GetStr(L"TimeOfLastReset");
		GetStr(L"SystemName");
		GetStr(L"SystemCreationClassName");
		GetDec(L"StatusInfo");
		GetStr(L"Status");
		GetDec(L"ProtocolSupported");
		GetBool(L"PowerManagementSupported");
		GetDecArray(L"PowerManagementCapabilities");
		GetStr(L"PNPDeviceID");
		GetStr(L"Name");
		GetDec(L"MaxNumberControlled");
		GetStr(L"Manufacturer");
		GetDec(L"LastErrorCode");
		GetStr(L"InstallDate");
		GetStr(L"ErrorDescription");
		GetBool(L"ErrorCleared");
		GetStr(L"DeviceID");
		GetStr(L"Description");
		GetStr(L"CreationClassName");
		GetBool(L"ConfigManagerUserConfig");
		GetConfigManagerErrorCode(L"ConfigManagerErrorCode");
		GetStr(L"Caption");
		GetStr(L"Availability");

		item.pszText = L"";
		item.iSubItem = 0;
		SendMessage(hWndTree, LVM_INSERTITEM, (WPARAM)0, (LPARAM)&item);

		if(0 == uReturn)
		  break;
	}
    if(pSvc)pSvc->Release();
    if(pLoc)pLoc->Release();
    if(pEnumerator)pEnumerator->Release();
    if(pclsObj)pclsObj->Release();
    CoUninitialize();
}

VOID WMI_Motherboard_Classes_Win32_1394ControllerDevice()
{   HRESULT hres;
    hres =  CoInitializeEx(0, COINIT_MULTITHREADED); 
    if(FAILED(hres))
        return;
    hres =  CoInitializeSecurity(
        NULL, 
        -1,                          // COM authentication
        NULL,                        // Authentication services
        NULL,                        // Reserved
        RPC_C_AUTHN_LEVEL_DEFAULT,   // Default authentication 
        RPC_C_IMP_LEVEL_IMPERSONATE, // Default Impersonation  
        NULL,                        // Authentication info
        EOAC_NONE,                   // Additional capabilities 
        NULL                         // Reserved
        );
    if (FAILED(hres))
    {	CoUninitialize();
        return;                      // Program has failed.
    }
    IWbemLocator *pLoc = NULL;
    hres = CoCreateInstance(
        CLSID_WbemLocator,             
        0, 
        CLSCTX_INPROC_SERVER, 
        IID_IWbemLocator, (LPVOID *) &pLoc);
    if (FAILED(hres))
    {   CoUninitialize();
        return;						// Program has failed.
    }
    IWbemServices *pSvc = NULL;
    hres = pLoc->ConnectServer(
         _bstr_t(L"ROOT\\CIMV2"), // Object path of WMI namespace
         NULL,                    // User name. NULL = current user
         NULL,                    // User password. NULL = current
         0,                       // Locale. NULL indicates current
         NULL,                    // Security flags.
         0,                       // Authority (e.g. Kerberos)
         0,                       // Context object 
         &pSvc                    // pointer to IWbemServices proxy
         );
    
    if (FAILED(hres))
    {   pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    hres = CoSetProxyBlanket(
       pSvc,                        // Indicates the proxy to set
       RPC_C_AUTHN_WINNT,           // RPC_C_AUTHN_xxx
       RPC_C_AUTHZ_NONE,            // RPC_C_AUTHZ_xxx
       NULL,                        // Server principal name 
       RPC_C_AUTHN_LEVEL_CALL,      // RPC_C_AUTHN_LEVEL_xxx 
       RPC_C_IMP_LEVEL_IMPERSONATE, // RPC_C_IMP_LEVEL_xxx
       NULL,                        // client identity
       EOAC_NONE                    // proxy capabilities 
    );
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    IEnumWbemClassObject* pEnumerator = NULL;
    hres = pSvc->ExecQuery(
        bstr_t("WQL"), 
        bstr_t("SELECT * FROM Win32_1394ControllerDevice"),
        WBEM_FLAG_FORWARD_ONLY | WBEM_FLAG_RETURN_IMMEDIATELY, 
        NULL,
        &pEnumerator);
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();
        CoUninitialize();
        return;						// Program has failed.
    }
    pclsObj=0;
    ULONG uReturn = 0;
    while (pEnumerator)
    {	HRESULT hr = pEnumerator->Next(WBEM_INFINITE, 1, &pclsObj, &uReturn);
		//if(0 == uReturn)
		//  break;

		GetDec(L"NumberOfSoftResets");
		GetDec(L"NumberOfHardResets");
		GetDec(L"NegotiatedSpeed");
		GetDec(L"NegotiatedDataWidth");
		GetStr(L"Dependent");//CIM_LogicalDevice ref Dependent;		
		GetStr(L"Antecedent");//Win32_1394Controller ref Antecedent;
		GetDec(L"AccessState");

		item.pszText = L"";
		item.iSubItem = 0;
		SendMessage(hWndTree, LVM_INSERTITEM, (WPARAM)0, (LPARAM)&item);

		if(0 == uReturn)
		  break;
	}
    if(pSvc)pSvc->Release();
    if(pLoc)pLoc->Release();
    if(pEnumerator)pEnumerator->Release();
    if(pclsObj)pclsObj->Release();
    CoUninitialize();
}

VOID WMI_Motherboard_Classes_Win32_AllocatedResource()
{   HRESULT hres;
    hres =  CoInitializeEx(0, COINIT_MULTITHREADED); 
    if(FAILED(hres))
        return;
    hres =  CoInitializeSecurity(
        NULL, 
        -1,                          // COM authentication
        NULL,                        // Authentication services
        NULL,                        // Reserved
        RPC_C_AUTHN_LEVEL_DEFAULT,   // Default authentication 
        RPC_C_IMP_LEVEL_IMPERSONATE, // Default Impersonation  
        NULL,                        // Authentication info
        EOAC_NONE,                   // Additional capabilities 
        NULL                         // Reserved
        );
    if (FAILED(hres))
    {	CoUninitialize();
        return;                      // Program has failed.
    }
    IWbemLocator *pLoc = NULL;
    hres = CoCreateInstance(
        CLSID_WbemLocator,             
        0, 
        CLSCTX_INPROC_SERVER, 
        IID_IWbemLocator, (LPVOID *) &pLoc);
    if (FAILED(hres))
    {   CoUninitialize();
        return;						// Program has failed.
    }
    IWbemServices *pSvc = NULL;
    hres = pLoc->ConnectServer(
         _bstr_t(L"ROOT\\CIMV2"), // Object path of WMI namespace
         NULL,                    // User name. NULL = current user
         NULL,                    // User password. NULL = current
         0,                       // Locale. NULL indicates current
         NULL,                    // Security flags.
         0,                       // Authority (e.g. Kerberos)
         0,                       // Context object 
         &pSvc                    // pointer to IWbemServices proxy
         );
    
    if (FAILED(hres))
    {   pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    hres = CoSetProxyBlanket(
       pSvc,                        // Indicates the proxy to set
       RPC_C_AUTHN_WINNT,           // RPC_C_AUTHN_xxx
       RPC_C_AUTHZ_NONE,            // RPC_C_AUTHZ_xxx
       NULL,                        // Server principal name 
       RPC_C_AUTHN_LEVEL_CALL,      // RPC_C_AUTHN_LEVEL_xxx 
       RPC_C_IMP_LEVEL_IMPERSONATE, // RPC_C_IMP_LEVEL_xxx
       NULL,                        // client identity
       EOAC_NONE                    // proxy capabilities 
    );
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    IEnumWbemClassObject* pEnumerator = NULL;
    hres = pSvc->ExecQuery(
        bstr_t("WQL"), 
        bstr_t("SELECT * FROM Win32_AllocatedResource"),
        WBEM_FLAG_FORWARD_ONLY | WBEM_FLAG_RETURN_IMMEDIATELY, 
        NULL,
        &pEnumerator);
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();
        CoUninitialize();
        return;						// Program has failed.
    }
    pclsObj=0;
    ULONG uReturn = 0;
    while (pEnumerator)
    {	HRESULT hr = pEnumerator->Next(WBEM_INFINITE, 1, &pclsObj, &uReturn);
		//if(0 == uReturn)
		//  break;

		GetStr(L"Antecedent");//CIM_SystemResource ref Antecedent;		
		GetStr(L"Dependent");//CIM_LogicalDevice ref Dependent;

		item.pszText = L"";
		item.iSubItem = 0;
		SendMessage(hWndTree, LVM_INSERTITEM, (WPARAM)0, (LPARAM)&item);

		if(0 == uReturn)
		  break;
	}
    if(pSvc)pSvc->Release();
    if(pLoc)pLoc->Release();
    if(pEnumerator)pEnumerator->Release();
    if(pclsObj)pclsObj->Release();
    CoUninitialize();
}

VOID WMI_Motherboard_Classes_Win32_AssociatedProcessorMemory()
{   HRESULT hres;
    hres =  CoInitializeEx(0, COINIT_MULTITHREADED); 
    if(FAILED(hres))
        return;
    hres =  CoInitializeSecurity(
        NULL, 
        -1,                          // COM authentication
        NULL,                        // Authentication services
        NULL,                        // Reserved
        RPC_C_AUTHN_LEVEL_DEFAULT,   // Default authentication 
        RPC_C_IMP_LEVEL_IMPERSONATE, // Default Impersonation  
        NULL,                        // Authentication info
        EOAC_NONE,                   // Additional capabilities 
        NULL                         // Reserved
        );
    if (FAILED(hres))
    {	CoUninitialize();
        return;                      // Program has failed.
    }
    IWbemLocator *pLoc = NULL;
    hres = CoCreateInstance(
        CLSID_WbemLocator,             
        0, 
        CLSCTX_INPROC_SERVER, 
        IID_IWbemLocator, (LPVOID *) &pLoc);
    if (FAILED(hres))
    {   CoUninitialize();
        return;						// Program has failed.
    }
    IWbemServices *pSvc = NULL;
    hres = pLoc->ConnectServer(
         _bstr_t(L"ROOT\\CIMV2"), // Object path of WMI namespace
         NULL,                    // User name. NULL = current user
         NULL,                    // User password. NULL = current
         0,                       // Locale. NULL indicates current
         NULL,                    // Security flags.
         0,                       // Authority (e.g. Kerberos)
         0,                       // Context object 
         &pSvc                    // pointer to IWbemServices proxy
         );
    
    if (FAILED(hres))
    {   pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    hres = CoSetProxyBlanket(
       pSvc,                        // Indicates the proxy to set
       RPC_C_AUTHN_WINNT,           // RPC_C_AUTHN_xxx
       RPC_C_AUTHZ_NONE,            // RPC_C_AUTHZ_xxx
       NULL,                        // Server principal name 
       RPC_C_AUTHN_LEVEL_CALL,      // RPC_C_AUTHN_LEVEL_xxx 
       RPC_C_IMP_LEVEL_IMPERSONATE, // RPC_C_IMP_LEVEL_xxx
       NULL,                        // client identity
       EOAC_NONE                    // proxy capabilities 
    );
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    IEnumWbemClassObject* pEnumerator = NULL;
    hres = pSvc->ExecQuery(
        bstr_t("WQL"), 
        bstr_t("SELECT * FROM Win32_AssociatedProcessorMemory"),
        WBEM_FLAG_FORWARD_ONLY | WBEM_FLAG_RETURN_IMMEDIATELY, 
        NULL,
        &pEnumerator);
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();
        CoUninitialize();
        return;						// Program has failed.
    }
    pclsObj=0;
    ULONG uReturn = 0;
    while (pEnumerator)
    {	HRESULT hr = pEnumerator->Next(WBEM_INFINITE, 1, &pclsObj, &uReturn);
		//if(0 == uReturn)
		//  break;

		GetStr(L"Antecedent");//Win32_CacheMemory ref Antecedent		
		GetDec(L"BusSpeed");
		GetStr(L"Dependent");//Win32_Processor ref Dependent;

		item.pszText = L"";
		item.iSubItem = 0;
		SendMessage(hWndTree, LVM_INSERTITEM, (WPARAM)0, (LPARAM)&item);

		if(0 == uReturn)
		  break;
	}
    if(pSvc)pSvc->Release();
    if(pLoc)pLoc->Release();
    if(pEnumerator)pEnumerator->Release();
    if(pclsObj)pclsObj->Release();
    CoUninitialize();
}

VOID WMI_Motherboard_Classes_Win32_BaseBoard()
{   HRESULT hres;
    hres =  CoInitializeEx(0, COINIT_MULTITHREADED); 
    if(FAILED(hres))
        return;
    hres =  CoInitializeSecurity(
        NULL, 
        -1,                          // COM authentication
        NULL,                        // Authentication services
        NULL,                        // Reserved
        RPC_C_AUTHN_LEVEL_DEFAULT,   // Default authentication 
        RPC_C_IMP_LEVEL_IMPERSONATE, // Default Impersonation  
        NULL,                        // Authentication info
        EOAC_NONE,                   // Additional capabilities 
        NULL                         // Reserved
        );
    if (FAILED(hres))
    {	CoUninitialize();
        return;                      // Program has failed.
    }
    IWbemLocator *pLoc = NULL;
    hres = CoCreateInstance(
        CLSID_WbemLocator,             
        0, 
        CLSCTX_INPROC_SERVER, 
        IID_IWbemLocator, (LPVOID *) &pLoc);
    if (FAILED(hres))
    {   CoUninitialize();
        return;						// Program has failed.
    }
    IWbemServices *pSvc = NULL;
    hres = pLoc->ConnectServer(
         _bstr_t(L"ROOT\\CIMV2"), // Object path of WMI namespace
         NULL,                    // User name. NULL = current user
         NULL,                    // User password. NULL = current
         0,                       // Locale. NULL indicates current
         NULL,                    // Security flags.
         0,                       // Authority (e.g. Kerberos)
         0,                       // Context object 
         &pSvc                    // pointer to IWbemServices proxy
         );
    
    if (FAILED(hres))
    {   pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    hres = CoSetProxyBlanket(
       pSvc,                        // Indicates the proxy to set
       RPC_C_AUTHN_WINNT,           // RPC_C_AUTHN_xxx
       RPC_C_AUTHZ_NONE,            // RPC_C_AUTHZ_xxx
       NULL,                        // Server principal name 
       RPC_C_AUTHN_LEVEL_CALL,      // RPC_C_AUTHN_LEVEL_xxx 
       RPC_C_IMP_LEVEL_IMPERSONATE, // RPC_C_IMP_LEVEL_xxx
       NULL,                        // client identity
       EOAC_NONE                    // proxy capabilities 
    );
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    IEnumWbemClassObject* pEnumerator = NULL;
    hres = pSvc->ExecQuery(
        bstr_t("WQL"), 
        bstr_t("SELECT * FROM Win32_BaseBoard"),
        WBEM_FLAG_FORWARD_ONLY | WBEM_FLAG_RETURN_IMMEDIATELY, 
        NULL,
        &pEnumerator);
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();
        CoUninitialize();
        return;						// Program has failed.
    }
    pclsObj=0;
    ULONG uReturn = 0;
    while (pEnumerator)
    {	HRESULT hr = pEnumerator->Next(WBEM_INFINITE, 1, &pclsObj, &uReturn);
		//if(0 == uReturn)
		//  break;

		GetReal(L"Width");
		GetReal(L"Weight");
		GetStr(L"Version");
		GetStr(L"Tag");
		GetStr(L"Status");
		GetBool(L"SpecialRequirements");
		GetStr(L"SlotLayout");
		GetStr(L"SKU");
		GetStr(L"SerialNumber");
		GetBool(L"RequiresDaughterBoard");
		GetStr(L"RequirementsDescription");
		GetBool(L"Replaceable");
		GetBool(L"Removable");
		GetStr(L"Product");
		GetBool(L"PoweredOn");
		GetStr(L"PartNumber");
		GetStr(L"OtherIdentifyingInfo");
		GetStr(L"Name");
		GetStr(L"Model");
		GetStr(L"Manufacturer");
		GetStr(L"InstallDate");
		GetBool(L"HotSwappable");
		GetBool(L"HostingBoard");
		GetReal(L"Height");
		GetStr(L"Description");
		GetReal(L"Depth");
		GetStr(L"CreationClassName");
		GetStrArray(L"ConfigOptions");
		GetStr(L"Caption");

		item.pszText = L"";
		item.iSubItem = 0;
		SendMessage(hWndTree, LVM_INSERTITEM, (WPARAM)0, (LPARAM)&item);

		if(0 == uReturn)
		  break;
	}
    if(pSvc)pSvc->Release();
    if(pLoc)pLoc->Release();
    if(pEnumerator)pEnumerator->Release();
    if(pclsObj)pclsObj->Release();
    CoUninitialize();
}

VOID WMI_Motherboard_Classes_Win32_BIOS()
{   HRESULT hres;
    hres =  CoInitializeEx(0, COINIT_MULTITHREADED); 
    if(FAILED(hres))
        return;
    hres =  CoInitializeSecurity(
        NULL, 
        -1,                          // COM authentication
        NULL,                        // Authentication services
        NULL,                        // Reserved
        RPC_C_AUTHN_LEVEL_DEFAULT,   // Default authentication 
        RPC_C_IMP_LEVEL_IMPERSONATE, // Default Impersonation  
        NULL,                        // Authentication info
        EOAC_NONE,                   // Additional capabilities 
        NULL                         // Reserved
        );
    if (FAILED(hres))
    {	CoUninitialize();
        return;                      // Program has failed.
    }
    IWbemLocator *pLoc = NULL;
    hres = CoCreateInstance(
        CLSID_WbemLocator,             
        0, 
        CLSCTX_INPROC_SERVER, 
        IID_IWbemLocator, (LPVOID *) &pLoc);
    if (FAILED(hres))
    {   CoUninitialize();
        return;						// Program has failed.
    }
    IWbemServices *pSvc = NULL;
    hres = pLoc->ConnectServer(
         _bstr_t(L"ROOT\\CIMV2"), // Object path of WMI namespace
         NULL,                    // User name. NULL = current user
         NULL,                    // User password. NULL = current
         0,                       // Locale. NULL indicates current
         NULL,                    // Security flags.
         0,                       // Authority (e.g. Kerberos)
         0,                       // Context object 
         &pSvc                    // pointer to IWbemServices proxy
         );
    
    if (FAILED(hres))
    {   pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    hres = CoSetProxyBlanket(
       pSvc,                        // Indicates the proxy to set
       RPC_C_AUTHN_WINNT,           // RPC_C_AUTHN_xxx
       RPC_C_AUTHZ_NONE,            // RPC_C_AUTHZ_xxx
       NULL,                        // Server principal name 
       RPC_C_AUTHN_LEVEL_CALL,      // RPC_C_AUTHN_LEVEL_xxx 
       RPC_C_IMP_LEVEL_IMPERSONATE, // RPC_C_IMP_LEVEL_xxx
       NULL,                        // client identity
       EOAC_NONE                    // proxy capabilities 
    );
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    IEnumWbemClassObject* pEnumerator = NULL;
    hres = pSvc->ExecQuery(
        bstr_t("WQL"), 
        bstr_t("SELECT * FROM Win32_BIOS"),
        WBEM_FLAG_FORWARD_ONLY | WBEM_FLAG_RETURN_IMMEDIATELY, 
        NULL,
        &pEnumerator);
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();
        CoUninitialize();
        return;						// Program has failed.
    }
    pclsObj=0;
    ULONG uReturn = 0;
    while (pEnumerator)
    {	HRESULT hr = pEnumerator->Next(WBEM_INFINITE, 1, &pclsObj, &uReturn);
		//if(0 == uReturn)
		//  break;

		GetStr(L"Version");
		GetDec(L"TargetOperatingSystem");
		GetStr(L"Status");
		GetDec(L"SoftwareElementState");
		GetStr(L"SoftwareElementID");
		GetBool(L"SMBIOSPresent");
		GetDec(L"SMBIOSMinorVersion");
		GetDec(L"SMBIOSMajorVersion");
		GetStr(L"SMBIOSBIOSVersion");
		GetStr(L"SerialNumber");
		GetDatetime(L"ReleaseDate");
		GetBool(L"PrimaryBIOS");
		GetStr(L"OtherTargetOS");
		GetStr(L"Name");
		GetStr(L"Manufacturer");
		GetStrArray(L"ListOfLanguages");
		GetStr(L"LanguageEdition");
		GetDatetime(L"InstallDate");
		GetDec(L"InstallableLanguages");
		GetStr(L"IdentificationCode");
		GetStr(L"Description");
		GetStr(L"CurrentLanguage");
		GetStr(L"CodeSet");
		GetStr(L"Caption");
		GetStr(L"BuildNumber");
		GetStrArray(L"BIOSVersion");
		GetDecArray(L"BiosCharacteristics");

		item.pszText = L"";
		item.iSubItem = 0;
		SendMessage(hWndTree, LVM_INSERTITEM, (WPARAM)0, (LPARAM)&item);

		if(0 == uReturn)
		  break;
	}
    if(pSvc)pSvc->Release();
    if(pLoc)pLoc->Release();
    if(pEnumerator)pEnumerator->Release();
    if(pclsObj)pclsObj->Release();
    CoUninitialize();
}

VOID GetBusType(wchar_t *prop)
{	wchar_t s[64];
	item.pszText = prop;
	item.iSubItem = 0;
	SendMessage(hWndTree, LVM_INSERTITEM, (WPARAM)0, (LPARAM)&item);
	item.iSubItem = 1;
	item.pszText = s;
	if(pclsObj)
	if(S_OK==pclsObj->Get(prop, 0, &vtProp, 0, 0))
	{	if(VT_NULL!=vtProp.vt)
		{	switch((int)vtProp.bstrVal)
			{	case -1:
					wsprintf(s,L"-1: Undefined");
				break;
				case 0:
					wsprintf(s,L"0: Internal");
				break;
				case 1:
					wsprintf(s,L"1: ISA");
				break;
				case 2:
					wsprintf(s,L"2: EISA");
				break;
				case 3:
					wsprintf(s,L"3: MicroChannel");
				break;
				case 4:
					wsprintf(s,L"4: TurboChannel");
				break;
				case 5:
					wsprintf(s,L"5: PCI Bus");
				break;
				case 6:
					wsprintf(s,L"6: VME Bus");
				break;
				case 7:
					wsprintf(s,L"7: NuBus");
				break;
				case 8:
					wsprintf(s,L"8: PCMCIA Bus");
				break;
				case 9:
					wsprintf(s,L"9: C Bus");
				break;
				case 10:
					wsprintf(s,L"10: MPI Bus");
				break;
				case 11:
					wsprintf(s,L"11: MPSA Bus");
				break;
				case 12:
					wsprintf(s,L"12: Internal Processor");
				break;
				case 13:
					wsprintf(s,L"13: Internal Power Bus");
				break;
				case 14:
					wsprintf(s,L"14: PNP ISA Bus");
				break;
				case 15:
					wsprintf(s,L"15: PNP Bus ");
				break;
				case 16:
					wsprintf(s,L"16: Maximum Interface Type");
				break;
				default:
					wsprintf(s,L"");
				break;
			}
			SendMessage(hWndTree, LVM_SETITEMTEXT, (WPARAM)0, (LPARAM)&item);
			VariantClear(&vtProp);
			return;
	}	}
	wsprintf(s,L"Dec. value, not defined ...");
	SendMessage(hWndTree, LVM_SETITEMTEXT, (WPARAM)0, (LPARAM)&item);
}

VOID WMI_Motherboard_Classes_Win32_Bus()
{   HRESULT hres;
    hres =  CoInitializeEx(0, COINIT_MULTITHREADED); 
    if(FAILED(hres))
        return;
    hres =  CoInitializeSecurity(
        NULL, 
        -1,                          // COM authentication
        NULL,                        // Authentication services
        NULL,                        // Reserved
        RPC_C_AUTHN_LEVEL_DEFAULT,   // Default authentication 
        RPC_C_IMP_LEVEL_IMPERSONATE, // Default Impersonation  
        NULL,                        // Authentication info
        EOAC_NONE,                   // Additional capabilities 
        NULL                         // Reserved
        );
    if (FAILED(hres))
    {	CoUninitialize();
        return;                      // Program has failed.
    }
    IWbemLocator *pLoc = NULL;
    hres = CoCreateInstance(
        CLSID_WbemLocator,             
        0, 
        CLSCTX_INPROC_SERVER, 
        IID_IWbemLocator, (LPVOID *) &pLoc);
    if (FAILED(hres))
    {   CoUninitialize();
        return;						// Program has failed.
    }
    IWbemServices *pSvc = NULL;
    hres = pLoc->ConnectServer(
         _bstr_t(L"ROOT\\CIMV2"), // Object path of WMI namespace
         NULL,                    // User name. NULL = current user
         NULL,                    // User password. NULL = current
         0,                       // Locale. NULL indicates current
         NULL,                    // Security flags.
         0,                       // Authority (e.g. Kerberos)
         0,                       // Context object 
         &pSvc                    // pointer to IWbemServices proxy
         );
    
    if (FAILED(hres))
    {   pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    hres = CoSetProxyBlanket(
       pSvc,                        // Indicates the proxy to set
       RPC_C_AUTHN_WINNT,           // RPC_C_AUTHN_xxx
       RPC_C_AUTHZ_NONE,            // RPC_C_AUTHZ_xxx
       NULL,                        // Server principal name 
       RPC_C_AUTHN_LEVEL_CALL,      // RPC_C_AUTHN_LEVEL_xxx 
       RPC_C_IMP_LEVEL_IMPERSONATE, // RPC_C_IMP_LEVEL_xxx
       NULL,                        // client identity
       EOAC_NONE                    // proxy capabilities 
    );
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    IEnumWbemClassObject* pEnumerator = NULL;
    hres = pSvc->ExecQuery(
        bstr_t("WQL"), 
        bstr_t("SELECT * FROM Win32_Bus"),
        WBEM_FLAG_FORWARD_ONLY | WBEM_FLAG_RETURN_IMMEDIATELY, 
        NULL,
        &pEnumerator);
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();
        CoUninitialize();
        return;						// Program has failed.
    }
    pclsObj=0;
    ULONG uReturn = 0;
    while (pEnumerator)
    {	HRESULT hr = pEnumerator->Next(WBEM_INFINITE, 1, &pclsObj, &uReturn);
		//if(0 == uReturn)
		//  break;

		GetStr(L"SystemName");
		GetStr(L"SystemCreationClassName");
		GetDec(L"StatusInfo");
		GetStr(L"Status");
		GetBool(L"PowerManagementSupported");
		GetDecArray(L"PowerManagementCapabilities");
		GetStr(L"PNPDeviceID");
		GetStr(L"Name");
		GetDec(L"LastErrorCode");
		GetStr(L"InstallDate");
		GetStr(L"ErrorDescription");
		GetBool(L"ErrorCleared");
		GetStr(L"DeviceID");
		GetStr(L"Description");
		GetStr(L"CreationClassName");
		GetBool(L"ConfigManagerUserConfig");
		GetConfigManagerErrorCode(L"ConfigManagerErrorCode");
		GetStr(L"Caption");
		GetBusType(L"BusType");
		GetDec(L"BusNum");
		GetDec(L"Availability");

		item.pszText = L"";
		item.iSubItem = 0;
		SendMessage(hWndTree, LVM_INSERTITEM, (WPARAM)0, (LPARAM)&item);

		if(0 == uReturn)
		  break;
	}
    if(pSvc)pSvc->Release();
    if(pLoc)pLoc->Release();
    if(pEnumerator)pEnumerator->Release();
    if(pclsObj)pclsObj->Release();
    CoUninitialize();
}

VOID GetCacheMemoryAssociativity(wchar_t *prop)
{	wchar_t s[64];
	item.pszText = prop;
	item.iSubItem = 0;
	SendMessage(hWndTree, LVM_INSERTITEM, (WPARAM)0, (LPARAM)&item);
	item.iSubItem = 1;
	item.pszText = s;
	if(pclsObj)
	if(S_OK==pclsObj->Get(prop, 0, &vtProp, 0, 0))
	{	if(VT_NULL!=vtProp.vt)
		{	switch((int)vtProp.bstrVal)
			{	case 1:
					wsprintf(s,L"1: Other");
				break;
				case 2:
					wsprintf(s,L"2: Unknown");
				break;
				case 3:
					wsprintf(s,L"3: Direct Mapped");
				break;
				case 4:
					wsprintf(s,L"4: 2-way Set-Associative");
				break;
				case 5:
					wsprintf(s,L"5: 4-way Set-Associative");
				break;
				case 6:
					wsprintf(s,L"6: Fully Associative");
				break;
				case 7:
					wsprintf(s,L"7: Windows Server 2003 and Windows XP:  8-way Set-Associative");
				break;
				case 8:
					wsprintf(s,L"8: PCMCIA Bus");
				break;
				case 9:
					wsprintf(s,L"9: Windows Server 2003 and Windows XP:  16-way Set-Associative");
				break;
				default:
					wsprintf(s,L"");
				break;
			}
			SendMessage(hWndTree, LVM_SETITEMTEXT, (WPARAM)0, (LPARAM)&item);
			VariantClear(&vtProp);
			return;
	}	}
	wsprintf(s,L"Dec. value, not defined ...");
	SendMessage(hWndTree, LVM_SETITEMTEXT, (WPARAM)0, (LPARAM)&item);
}

VOID GetCacheMemoryAvailability(wchar_t *prop)
{	wchar_t s[64];
	item.pszText = prop;
	item.iSubItem = 0;
	SendMessage(hWndTree, LVM_INSERTITEM, (WPARAM)0, (LPARAM)&item);
	item.iSubItem = 1;
	item.pszText = s;
	if(pclsObj)
	if(S_OK==pclsObj->Get(prop, 0, &vtProp, 0, 0))
	{	if(VT_NULL!=vtProp.vt)
		{	switch((int)vtProp.bstrVal)
			{	case 1:
					wsprintf(s,L"1: Other");
				break;
				case 2:
					wsprintf(s,L"2: Unknown");
				break;
				case 3:
					wsprintf(s,L"3: Running or Full Power");
				break;
				case 4:
					wsprintf(s,L"4: Warning");
				break;
				case 5:
					wsprintf(s,L"5: In Test");
				break;
				case 6:
					wsprintf(s,L"6: Not Applicable");
				break;
				case 7:
					wsprintf(s,L"7: Power Off");
				break;
				case 8:
					wsprintf(s,L"8: Off Line");
				break;
				case 9:
					wsprintf(s,L"9: Off Duty");
				break;
				case 10:
					wsprintf(s,L"10: Degraded");
				break;
				case 11:
					wsprintf(s,L"11: Not Installed");
				break;
				case 12:
					wsprintf(s,L"12: Install Error");
				break;
				case 13:
					wsprintf(s,L"13: Power Save - Unknown.The device is known to be in a power save mode, but its exact status is unknown.");
				break;
				case 14:
					wsprintf(s,L"14: Power Save - Low.Power Mode The device is in a power save state but still functioning, and may exhibit degraded performance.");
				break;
				case 15:
					wsprintf(s,L"15: Power Save - Standby.The device is not functioning, but could be brought to full power quickly.");
				break;
				case 16:
					wsprintf(s,L"16: Power Cycle");
				break;
				case 17:
					wsprintf(s,L"17: Power Save - Warning.The device is in a warning state, though also in a power save mode.");
				break;
				default:
					wsprintf(s,L"");
				break;
			}
			SendMessage(hWndTree, LVM_SETITEMTEXT, (WPARAM)0, (LPARAM)&item);
			VariantClear(&vtProp);
			return;
	}	}
	wsprintf(s,L"Dec. value, not defined ...");
	SendMessage(hWndTree, LVM_SETITEMTEXT, (WPARAM)0, (LPARAM)&item);
}

VOID GetCacheMemoryCacheType(wchar_t *prop)
{	wchar_t s[64];
	item.pszText = prop;
	item.iSubItem = 0;
	SendMessage(hWndTree, LVM_INSERTITEM, (WPARAM)0, (LPARAM)&item);
	item.iSubItem = 1;
	item.pszText = s;
	if(pclsObj)
	if(S_OK==pclsObj->Get(prop, 0, &vtProp, 0, 0))
	{	if(VT_NULL!=vtProp.vt)
		{	switch((int)vtProp.bstrVal)
			{	case 1:
					wsprintf(s,L"1: Other");
				break;
				case 2:
					wsprintf(s,L"2: Unknown");
				break;
				case 3:
					wsprintf(s,L"3: Instruction");
				break;
				case 4:
					wsprintf(s,L"4: Data");
				break;
				case 5:
					wsprintf(s,L"5: Unified");
				break;
				default:
					wsprintf(s,L"");
				break;
			}
			SendMessage(hWndTree, LVM_SETITEMTEXT, (WPARAM)0, (LPARAM)&item);
			VariantClear(&vtProp);
			return;
	}	}
	wsprintf(s,L"Dec. value, not defined ...");
	SendMessage(hWndTree, LVM_SETITEMTEXT, (WPARAM)0, (LPARAM)&item);
}

VOID GetCacheMemoryErrorCorrectType(wchar_t *prop)
{	wchar_t s[64];
	item.pszText = prop;
	item.iSubItem = 0;
	SendMessage(hWndTree, LVM_INSERTITEM, (WPARAM)0, (LPARAM)&item);
	item.iSubItem = 1;
	item.pszText = s;
	if(pclsObj)
	if(S_OK==pclsObj->Get(prop, 0, &vtProp, 0, 0))
	{	if(VT_NULL!=vtProp.vt)
		{	switch((int)vtProp.bstrVal)
			{	case 0:
					wsprintf(s,L"1: Reserved");
				break;
				case 1:
					wsprintf(s,L"1: Other");
				break;
				case 2:
					wsprintf(s,L"2: Unknown");
				break;
				case 3:
					wsprintf(s,L"3: None");
				break;
				case 4:
					wsprintf(s,L"4: Parity");
				break;
				case 5:
					wsprintf(s,L"5: Single-Bit ECC");
				break;
				case 6:
					wsprintf(s,L"6: Multi-Bit ECC");
				break;
				default:
					wsprintf(s,L"");
				break;
			}
			SendMessage(hWndTree, LVM_SETITEMTEXT, (WPARAM)0, (LPARAM)&item);
			VariantClear(&vtProp);
			return;
	}	}
	wsprintf(s,L"Dec. value, not defined ...");
	SendMessage(hWndTree, LVM_SETITEMTEXT, (WPARAM)0, (LPARAM)&item);
}

VOID GetCacheMemoryLevel(wchar_t *prop)
{	wchar_t s[64];
	item.pszText = prop;
	item.iSubItem = 0;
	SendMessage(hWndTree, LVM_INSERTITEM, (WPARAM)0, (LPARAM)&item);
	item.iSubItem = 1;
	item.pszText = s;
	if(pclsObj)
	if(S_OK==pclsObj->Get(prop, 0, &vtProp, 0, 0))
	{	if(VT_NULL!=vtProp.vt)
		{	switch((int)vtProp.bstrVal)
			{	case 1:
					wsprintf(s,L"1: Other");
				break;
				case 2:
					wsprintf(s,L"2: Unknown");
				break;
				case 3:
					wsprintf(s,L"3: Primary");
				break;
				case 4:
					wsprintf(s,L"4: Secondary");
				break;
				case 5:
					wsprintf(s,L"5: Tertiary");
				break;
				case 6:
					wsprintf(s,L"6: Windows Server 2003 and Windows XP:  Not Applicable");
				break;
				default:
					wsprintf(s,L"");
				break;
			}
			SendMessage(hWndTree, LVM_SETITEMTEXT, (WPARAM)0, (LPARAM)&item);
			VariantClear(&vtProp);
			return;
	}	}
	wsprintf(s,L"Dec. value, not defined ...");
	SendMessage(hWndTree, LVM_SETITEMTEXT, (WPARAM)0, (LPARAM)&item);
}

VOID GetCacheMemoryStatusInfo(wchar_t *prop)
{	wchar_t s[64];
	item.pszText = prop;
	item.iSubItem = 0;
	SendMessage(hWndTree, LVM_INSERTITEM, (WPARAM)0, (LPARAM)&item);
	item.iSubItem = 1;
	item.pszText = s;
	if(pclsObj)
	if(S_OK==pclsObj->Get(prop, 0, &vtProp, 0, 0))
	{	if(VT_NULL!=vtProp.vt)
		{	switch((int)vtProp.bstrVal)
			{	case 1:
					wsprintf(s,L"1: Other");
				break;
				case 2:
					wsprintf(s,L"2: Unknown");
				break;
				case 3:
					wsprintf(s,L"3: Enabled");
				break;
				case 4:
					wsprintf(s,L"4: Disabled");
				break;
				case 5:
					wsprintf(s,L"5: Not Applicable");
				break;
				default:
					wsprintf(s,L"");
				break;
			}
			SendMessage(hWndTree, LVM_SETITEMTEXT, (WPARAM)0, (LPARAM)&item);
			VariantClear(&vtProp);
			return;
	}	}
	wsprintf(s,L"Dec. value, not defined ...");
	SendMessage(hWndTree, LVM_SETITEMTEXT, (WPARAM)0, (LPARAM)&item);
}

VOID GetCacheMemoryWritePolicy(wchar_t *prop)
{	wchar_t s[64];
	item.pszText = prop;
	item.iSubItem = 0;
	SendMessage(hWndTree, LVM_INSERTITEM, (WPARAM)0, (LPARAM)&item);
	item.iSubItem = 1;
	item.pszText = s;
	if(pclsObj)
	if(S_OK==pclsObj->Get(prop, 0, &vtProp, 0, 0))
	{	if(VT_NULL!=vtProp.vt)
		{	switch((int)vtProp.bstrVal)
			{	case 1:
					wsprintf(s,L"1: Other");
				break;
				case 2:
					wsprintf(s,L"2: Unknown");
				break;
				case 3:
					wsprintf(s,L"3: Write Back");
				break;
				case 4:
					wsprintf(s,L"4: Write Through");
				break;
				case 5:
					wsprintf(s,L"5: Varies with Address");
				break;
				case 6:
					wsprintf(s,L"6: Windows Server 2003 and Windows XP:  Determination Per I/O");
				break;
				default:
					wsprintf(s,L"");
				break;
			}
			SendMessage(hWndTree, LVM_SETITEMTEXT, (WPARAM)0, (LPARAM)&item);
			VariantClear(&vtProp);
			return;
	}	}
	wsprintf(s,L"Dec. value, not defined ...");
	SendMessage(hWndTree, LVM_SETITEMTEXT, (WPARAM)0, (LPARAM)&item);
}

VOID GetCacheMemoryLocation(wchar_t *prop)
{	wchar_t s[64];
	item.pszText = prop;
	item.iSubItem = 0;
	SendMessage(hWndTree, LVM_INSERTITEM, (WPARAM)0, (LPARAM)&item);
	item.iSubItem = 1;
	item.pszText = s;
	if(pclsObj)
	if(S_OK==pclsObj->Get(prop, 0, &vtProp, 0, 0))
	{	if(VT_NULL!=vtProp.vt)
		{	switch((int)vtProp.bstrVal)
			{	case 0:
					wsprintf(s,L"0: Internal");
				break;
				case 1:
					wsprintf(s,L"1: External");
				break;
				case 2:
					wsprintf(s,L"2: Reserved");
				break;
				case 3:
					wsprintf(s,L"3: Unknown");
				break;
				default:
					wsprintf(s,L"");
				break;
			}
			SendMessage(hWndTree, LVM_SETITEMTEXT, (WPARAM)0, (LPARAM)&item);
			VariantClear(&vtProp);
			return;
	}	}
	wsprintf(s,L"Dec. value, not defined ...");
	SendMessage(hWndTree, LVM_SETITEMTEXT, (WPARAM)0, (LPARAM)&item);
}

VOID WMI_Motherboard_Classes_Win32_CacheMemory()
{   HRESULT hres;
    hres =  CoInitializeEx(0, COINIT_MULTITHREADED); 
    if(FAILED(hres))
        return;
    hres =  CoInitializeSecurity(
        NULL, 
        -1,                          // COM authentication
        NULL,                        // Authentication services
        NULL,                        // Reserved
        RPC_C_AUTHN_LEVEL_DEFAULT,   // Default authentication 
        RPC_C_IMP_LEVEL_IMPERSONATE, // Default Impersonation  
        NULL,                        // Authentication info
        EOAC_NONE,                   // Additional capabilities 
        NULL                         // Reserved
        );
    if (FAILED(hres))
    {	CoUninitialize();
        return;                      // Program has failed.
    }
    IWbemLocator *pLoc = NULL;
    hres = CoCreateInstance(
        CLSID_WbemLocator,             
        0, 
        CLSCTX_INPROC_SERVER, 
        IID_IWbemLocator, (LPVOID *) &pLoc);
    if (FAILED(hres))
    {   CoUninitialize();
        return;						// Program has failed.
    }
    IWbemServices *pSvc = NULL;
    hres = pLoc->ConnectServer(
         _bstr_t(L"ROOT\\CIMV2"), // Object path of WMI namespace
         NULL,                    // User name. NULL = current user
         NULL,                    // User password. NULL = current
         0,                       // Locale. NULL indicates current
         NULL,                    // Security flags.
         0,                       // Authority (e.g. Kerberos)
         0,                       // Context object 
         &pSvc                    // pointer to IWbemServices proxy
         );
    
    if (FAILED(hres))
    {   pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    hres = CoSetProxyBlanket(
       pSvc,                        // Indicates the proxy to set
       RPC_C_AUTHN_WINNT,           // RPC_C_AUTHN_xxx
       RPC_C_AUTHZ_NONE,            // RPC_C_AUTHZ_xxx
       NULL,                        // Server principal name 
       RPC_C_AUTHN_LEVEL_CALL,      // RPC_C_AUTHN_LEVEL_xxx 
       RPC_C_IMP_LEVEL_IMPERSONATE, // RPC_C_IMP_LEVEL_xxx
       NULL,                        // client identity
       EOAC_NONE                    // proxy capabilities 
    );
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    IEnumWbemClassObject* pEnumerator = NULL;
    hres = pSvc->ExecQuery(
        bstr_t("WQL"), 
        bstr_t("SELECT * FROM Win32_CacheMemory"),
        WBEM_FLAG_FORWARD_ONLY | WBEM_FLAG_RETURN_IMMEDIATELY, 
        NULL,
        &pEnumerator);
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();
        CoUninitialize();
        return;						// Program has failed.
    }
    pclsObj=0;
    ULONG uReturn = 0;
    while (pEnumerator)
    {	HRESULT hr = pEnumerator->Next(WBEM_INFINITE, 1, &pclsObj, &uReturn);
		//if(0 == uReturn)
		//  break;

		GetCacheMemoryWritePolicy(L"WritePolicy");
		GetStr(L"SystemName");
		GetBool(L"SystemLevelAddress");
		GetStr(L"SystemCreationClassName");
		GetDecArray(L"SupportedSRAM");
		GetCacheMemoryStatusInfo(L"StatusInfo");
		GetStr(L"Status");
		GetDec(L"StartingAddress");
		GetDec(L"ReplacementPolicy");
		GetDec(L"ReadPolicy");
		GetStr(L"Purpose");
		GetBool(L"PowerManagementSupported");
		GetDecArray(L"PowerManagementCapabilities");
		GetStr(L"PNPDeviceID");
		GetStr(L"OtherErrorDescription");
		GetDec(L"NumberOfBlocks");
		GetStr(L"Name");
		GetDec(L"MaxCacheSize");
		GetCacheMemoryLocation(L"Location");
		GetDec(L"LineSize");
		GetCacheMemoryLevel(L"Level");
		GetDec(L"LastErrorCode");
		GetDec(L"InstalledSize");
		GetDatetime(L"InstallDate");
		GetDec(L"FlushTimer");
		GetDec(L"ErrorTransferSize");
		GetDatetime(L"ErrorTime");
		GetDec(L"ErrorResolution");
		GetStr(L"ErrorMethodology");
		GetDec(L"ErrorInfo");
		GetStr(L"ErrorDescription");
		GetDec(L"ErrorDataOrder");
		GetDecArray(L"ErrorData");
		GetCacheMemoryErrorCorrectType(L"ErrorCorrectType");
		GetBool(L"ErrorCleared");
		GetDec(L"ErrorAddress");
		GetDec(L"ErrorAccess");
		GetDec(L"EndingAddress");
		GetStr(L"DeviceID");
		GetStr(L"Description");
		GetDecArray(L"CurrentSRAM");
		GetStr(L"CreationClassName");
		GetBool(L"CorrectableError");
		GetBool(L"ConfigManagerUserConfig");
		GetConfigManagerErrorCode(L"ConfigManagerErrorCode");
		GetStr(L"Caption");
		GetCacheMemoryCacheType(L"CacheType");
		GetDec(L"CacheSpeed");
		GetDec(L"BlockSize");
		GetCacheMemoryAvailability(L"Availability");
		GetCacheMemoryAssociativity(L"Associativity");
		GetDecArray(L"AdditionalErrorData");
		GetDec(L"Access");

		item.pszText = L"";
		item.iSubItem = 0;
		SendMessage(hWndTree, LVM_INSERTITEM, (WPARAM)0, (LPARAM)&item);

		if(0 == uReturn)
		  break;
	}
    if(pSvc)pSvc->Release();
    if(pLoc)pLoc->Release();
    if(pEnumerator)pEnumerator->Release();
    if(pclsObj)pclsObj->Release();
    CoUninitialize();
}

VOID WMI_Motherboard_Classes_Win32_ControllerHasHub()
{   HRESULT hres;
    hres =  CoInitializeEx(0, COINIT_MULTITHREADED); 
    if(FAILED(hres))
        return;
    hres =  CoInitializeSecurity(
        NULL, 
        -1,                          // COM authentication
        NULL,                        // Authentication services
        NULL,                        // Reserved
        RPC_C_AUTHN_LEVEL_DEFAULT,   // Default authentication 
        RPC_C_IMP_LEVEL_IMPERSONATE, // Default Impersonation  
        NULL,                        // Authentication info
        EOAC_NONE,                   // Additional capabilities 
        NULL                         // Reserved
        );
    if (FAILED(hres))
    {	CoUninitialize();
        return;                      // Program has failed.
    }
    IWbemLocator *pLoc = NULL;
    hres = CoCreateInstance(
        CLSID_WbemLocator,             
        0, 
        CLSCTX_INPROC_SERVER, 
        IID_IWbemLocator, (LPVOID *) &pLoc);
    if (FAILED(hres))
    {   CoUninitialize();
        return;						// Program has failed.
    }
    IWbemServices *pSvc = NULL;
    hres = pLoc->ConnectServer(
         _bstr_t(L"ROOT\\CIMV2"), // Object path of WMI namespace
         NULL,                    // User name. NULL = current user
         NULL,                    // User password. NULL = current
         0,                       // Locale. NULL indicates current
         NULL,                    // Security flags.
         0,                       // Authority (e.g. Kerberos)
         0,                       // Context object 
         &pSvc                    // pointer to IWbemServices proxy
         );
    
    if (FAILED(hres))
    {   pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    hres = CoSetProxyBlanket(
       pSvc,                        // Indicates the proxy to set
       RPC_C_AUTHN_WINNT,           // RPC_C_AUTHN_xxx
       RPC_C_AUTHZ_NONE,            // RPC_C_AUTHZ_xxx
       NULL,                        // Server principal name 
       RPC_C_AUTHN_LEVEL_CALL,      // RPC_C_AUTHN_LEVEL_xxx 
       RPC_C_IMP_LEVEL_IMPERSONATE, // RPC_C_IMP_LEVEL_xxx
       NULL,                        // client identity
       EOAC_NONE                    // proxy capabilities 
    );
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    IEnumWbemClassObject* pEnumerator = NULL;
    hres = pSvc->ExecQuery(
        bstr_t("WQL"), 
        bstr_t("SELECT * FROM Win32_ControllerHasHub"),
        WBEM_FLAG_FORWARD_ONLY | WBEM_FLAG_RETURN_IMMEDIATELY, 
        NULL,
        &pEnumerator);
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();
        CoUninitialize();
        return;						// Program has failed.
    }
    pclsObj=0;
    ULONG uReturn = 0;
    while (pEnumerator)
    {	HRESULT hr = pEnumerator->Next(WBEM_INFINITE, 1, &pclsObj, &uReturn);
		//if(0 == uReturn)
		//  break;

		GetDec(L"NumberOfSoftResets");
		GetDec(L"NumberOfHardResets");
		GetDec(L"NegotiatedSpeed");
		GetDec(L"NegotiatedDataWidth");
		GetStr(L"Dependent");//Win32_USBHub ref Dependent;
		GetStr(L"Antecedent");//Win32_USBController ref Antecedent;
		GetDec(L"AccessState");

		item.pszText = L"";
		item.iSubItem = 0;
		SendMessage(hWndTree, LVM_INSERTITEM, (WPARAM)0, (LPARAM)&item);

		if(0 == uReturn)
		  break;
	}
    if(pSvc)pSvc->Release();
    if(pLoc)pLoc->Release();
    if(pEnumerator)pEnumerator->Release();
    if(pclsObj)pclsObj->Release();
    CoUninitialize();
}

VOID WMI_Motherboard_Classes_Win32_DeviceBus()
{   HRESULT hres;
    hres =  CoInitializeEx(0, COINIT_MULTITHREADED); 
    if(FAILED(hres))
        return;
    hres =  CoInitializeSecurity(
        NULL, 
        -1,                          // COM authentication
        NULL,                        // Authentication services
        NULL,                        // Reserved
        RPC_C_AUTHN_LEVEL_DEFAULT,   // Default authentication 
        RPC_C_IMP_LEVEL_IMPERSONATE, // Default Impersonation  
        NULL,                        // Authentication info
        EOAC_NONE,                   // Additional capabilities 
        NULL                         // Reserved
        );
    if (FAILED(hres))
    {	CoUninitialize();
        return;                      // Program has failed.
    }
    IWbemLocator *pLoc = NULL;
    hres = CoCreateInstance(
        CLSID_WbemLocator,             
        0, 
        CLSCTX_INPROC_SERVER, 
        IID_IWbemLocator, (LPVOID *) &pLoc);
    if (FAILED(hres))
    {   CoUninitialize();
        return;						// Program has failed.
    }
    IWbemServices *pSvc = NULL;
    hres = pLoc->ConnectServer(
         _bstr_t(L"ROOT\\CIMV2"), // Object path of WMI namespace
         NULL,                    // User name. NULL = current user
         NULL,                    // User password. NULL = current
         0,                       // Locale. NULL indicates current
         NULL,                    // Security flags.
         0,                       // Authority (e.g. Kerberos)
         0,                       // Context object 
         &pSvc                    // pointer to IWbemServices proxy
         );
    
    if (FAILED(hres))
    {   pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    hres = CoSetProxyBlanket(
       pSvc,                        // Indicates the proxy to set
       RPC_C_AUTHN_WINNT,           // RPC_C_AUTHN_xxx
       RPC_C_AUTHZ_NONE,            // RPC_C_AUTHZ_xxx
       NULL,                        // Server principal name 
       RPC_C_AUTHN_LEVEL_CALL,      // RPC_C_AUTHN_LEVEL_xxx 
       RPC_C_IMP_LEVEL_IMPERSONATE, // RPC_C_IMP_LEVEL_xxx
       NULL,                        // client identity
       EOAC_NONE                    // proxy capabilities 
    );
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    IEnumWbemClassObject* pEnumerator = NULL;
    hres = pSvc->ExecQuery(
        bstr_t("WQL"), 
        bstr_t("SELECT * FROM Win32_DeviceBus"),
        WBEM_FLAG_FORWARD_ONLY | WBEM_FLAG_RETURN_IMMEDIATELY, 
        NULL,
        &pEnumerator);
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();
        CoUninitialize();
        return;						// Program has failed.
    }
    pclsObj=0;
    ULONG uReturn = 0;
    while (pEnumerator)
    {	HRESULT hr = pEnumerator->Next(WBEM_INFINITE, 1, &pclsObj, &uReturn);
		//if(0 == uReturn)
		//  break;

		GetStr(L"Antecedent");//Win32_Bus ref Antecedent;
		GetStr(L"Dependent");//CIM_LogicalDevice ref Dependent;

		item.pszText = L"";
		item.iSubItem = 0;
		SendMessage(hWndTree, LVM_INSERTITEM, (WPARAM)0, (LPARAM)&item);

		if(0 == uReturn)
		  break;
	}
    if(pSvc)pSvc->Release();
    if(pLoc)pLoc->Release();
    if(pEnumerator)pEnumerator->Release();
    if(pclsObj)pclsObj->Release();
    CoUninitialize();
}

VOID WMI_Motherboard_Classes_Win32_DeviceMemoryAddress()
{   HRESULT hres;
    hres =  CoInitializeEx(0, COINIT_MULTITHREADED); 
    if(FAILED(hres))
        return;
    hres =  CoInitializeSecurity(
        NULL, 
        -1,                          // COM authentication
        NULL,                        // Authentication services
        NULL,                        // Reserved
        RPC_C_AUTHN_LEVEL_DEFAULT,   // Default authentication 
        RPC_C_IMP_LEVEL_IMPERSONATE, // Default Impersonation  
        NULL,                        // Authentication info
        EOAC_NONE,                   // Additional capabilities 
        NULL                         // Reserved
        );
    if (FAILED(hres))
    {	CoUninitialize();
        return;                      // Program has failed.
    }
    IWbemLocator *pLoc = NULL;
    hres = CoCreateInstance(
        CLSID_WbemLocator,             
        0, 
        CLSCTX_INPROC_SERVER, 
        IID_IWbemLocator, (LPVOID *) &pLoc);
    if (FAILED(hres))
    {   CoUninitialize();
        return;						// Program has failed.
    }
    IWbemServices *pSvc = NULL;
    hres = pLoc->ConnectServer(
         _bstr_t(L"ROOT\\CIMV2"), // Object path of WMI namespace
         NULL,                    // User name. NULL = current user
         NULL,                    // User password. NULL = current
         0,                       // Locale. NULL indicates current
         NULL,                    // Security flags.
         0,                       // Authority (e.g. Kerberos)
         0,                       // Context object 
         &pSvc                    // pointer to IWbemServices proxy
         );
    
    if (FAILED(hres))
    {   pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    hres = CoSetProxyBlanket(
       pSvc,                        // Indicates the proxy to set
       RPC_C_AUTHN_WINNT,           // RPC_C_AUTHN_xxx
       RPC_C_AUTHZ_NONE,            // RPC_C_AUTHZ_xxx
       NULL,                        // Server principal name 
       RPC_C_AUTHN_LEVEL_CALL,      // RPC_C_AUTHN_LEVEL_xxx 
       RPC_C_IMP_LEVEL_IMPERSONATE, // RPC_C_IMP_LEVEL_xxx
       NULL,                        // client identity
       EOAC_NONE                    // proxy capabilities 
    );
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    IEnumWbemClassObject* pEnumerator = NULL;
    hres = pSvc->ExecQuery(
        bstr_t("WQL"), 
        bstr_t("SELECT * FROM Win32_DeviceMemoryAddress"),
        WBEM_FLAG_FORWARD_ONLY | WBEM_FLAG_RETURN_IMMEDIATELY, 
        NULL,
        &pEnumerator);
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();
        CoUninitialize();
        return;						// Program has failed.
    }
    pclsObj=0;
    ULONG uReturn = 0;
    while (pEnumerator)
    {	HRESULT hr = pEnumerator->Next(WBEM_INFINITE, 1, &pclsObj, &uReturn);
		//if(0 == uReturn)
		//  break;

		GetStr(L"Status");
		GetDec(L"StartingAddress");
		GetStr(L"Name");
		GetStr(L"MemoryType");
		GetDatetime(L"InstallDate");
		GetDec(L"EndingAddress");
		GetStr(L"Description");
		GetStr(L"CSName");
		GetStr(L"CSCreationClassName");
		GetStr(L"CreationClassName");
		GetStr(L"Caption");

		item.pszText = L"";
		item.iSubItem = 0;
		SendMessage(hWndTree, LVM_INSERTITEM, (WPARAM)0, (LPARAM)&item);

		if(0 == uReturn)
		  break;
	}
    if(pSvc)pSvc->Release();
    if(pLoc)pLoc->Release();
    if(pEnumerator)pEnumerator->Release();
    if(pclsObj)pclsObj->Release();
    CoUninitialize();
}

VOID WMI_Motherboard_Classes_Win32_DeviceSettings()
{   HRESULT hres;
    hres =  CoInitializeEx(0, COINIT_MULTITHREADED); 
    if(FAILED(hres))
        return;
    hres =  CoInitializeSecurity(
        NULL, 
        -1,                          // COM authentication
        NULL,                        // Authentication services
        NULL,                        // Reserved
        RPC_C_AUTHN_LEVEL_DEFAULT,   // Default authentication 
        RPC_C_IMP_LEVEL_IMPERSONATE, // Default Impersonation  
        NULL,                        // Authentication info
        EOAC_NONE,                   // Additional capabilities 
        NULL                         // Reserved
        );
    if (FAILED(hres))
    {	CoUninitialize();
        return;                      // Program has failed.
    }
    IWbemLocator *pLoc = NULL;
    hres = CoCreateInstance(
        CLSID_WbemLocator,             
        0, 
        CLSCTX_INPROC_SERVER, 
        IID_IWbemLocator, (LPVOID *) &pLoc);
    if (FAILED(hres))
    {   CoUninitialize();
        return;						// Program has failed.
    }
    IWbemServices *pSvc = NULL;
    hres = pLoc->ConnectServer(
         _bstr_t(L"ROOT\\CIMV2"), // Object path of WMI namespace
         NULL,                    // User name. NULL = current user
         NULL,                    // User password. NULL = current
         0,                       // Locale. NULL indicates current
         NULL,                    // Security flags.
         0,                       // Authority (e.g. Kerberos)
         0,                       // Context object 
         &pSvc                    // pointer to IWbemServices proxy
         );
    
    if (FAILED(hres))
    {   pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    hres = CoSetProxyBlanket(
       pSvc,                        // Indicates the proxy to set
       RPC_C_AUTHN_WINNT,           // RPC_C_AUTHN_xxx
       RPC_C_AUTHZ_NONE,            // RPC_C_AUTHZ_xxx
       NULL,                        // Server principal name 
       RPC_C_AUTHN_LEVEL_CALL,      // RPC_C_AUTHN_LEVEL_xxx 
       RPC_C_IMP_LEVEL_IMPERSONATE, // RPC_C_IMP_LEVEL_xxx
       NULL,                        // client identity
       EOAC_NONE                    // proxy capabilities 
    );
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    IEnumWbemClassObject* pEnumerator = NULL;
    hres = pSvc->ExecQuery(
        bstr_t("WQL"), 
        bstr_t("SELECT * FROM Win32_DeviceSettings"),
        WBEM_FLAG_FORWARD_ONLY | WBEM_FLAG_RETURN_IMMEDIATELY, 
        NULL,
        &pEnumerator);
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();
        CoUninitialize();
        return;						// Program has failed.
    }
    pclsObj=0;
    ULONG uReturn = 0;
    while (pEnumerator)
    {	HRESULT hr = pEnumerator->Next(WBEM_INFINITE, 1, &pclsObj, &uReturn);
		//if(0 == uReturn)
		//  break;

		GetStr(L"Element");//CIM_LogicalDevice ref Element;
		GetStr(L"Setting");//CIM_Setting ref Setting;

		item.pszText = L"";
		item.iSubItem = 0;
		SendMessage(hWndTree, LVM_INSERTITEM, (WPARAM)0, (LPARAM)&item);

		if(0 == uReturn)
		  break;
	}
    if(pSvc)pSvc->Release();
    if(pLoc)pLoc->Release();
    if(pEnumerator)pEnumerator->Release();
    if(pclsObj)pclsObj->Release();
    CoUninitialize();
}

VOID GetDMAAvailability(wchar_t *prop)
{	wchar_t s[64];
	item.pszText = prop;
	item.iSubItem = 0;
	SendMessage(hWndTree, LVM_INSERTITEM, (WPARAM)0, (LPARAM)&item);
	item.iSubItem = 1;
	item.pszText = s;
	if(pclsObj)
	if(S_OK==pclsObj->Get(prop, 0, &vtProp, 0, 0))
	{	if(VT_NULL!=vtProp.vt)
		{	switch((int)vtProp.bstrVal)
			{	case 1:
					wsprintf(s,L"1: Other");
				break;
				case 2:
					wsprintf(s,L"2: Unknown");
				break;
				case 3:
					wsprintf(s,L"3: Available");
				break;
				case 4:
					wsprintf(s,L"4: In Use or Not Available");
				break;
				case 5:
					wsprintf(s,L"5: In Use and Available or Shareable");
				break;
				default:
					wsprintf(s,L"");
				break;
			}
			SendMessage(hWndTree, LVM_SETITEMTEXT, (WPARAM)0, (LPARAM)&item);
			VariantClear(&vtProp);
			return;
	}	}
	wsprintf(s,L"Dec. value, not defined ...");
	SendMessage(hWndTree, LVM_SETITEMTEXT, (WPARAM)0, (LPARAM)&item);
}

VOID GetDMAByteMode(wchar_t *prop)
{	wchar_t s[64];
	item.pszText = prop;
	item.iSubItem = 0;
	SendMessage(hWndTree, LVM_INSERTITEM, (WPARAM)0, (LPARAM)&item);
	item.iSubItem = 1;
	item.pszText = s;
	if(pclsObj)
	if(S_OK==pclsObj->Get(prop, 0, &vtProp, 0, 0))
	{	if(VT_NULL!=vtProp.vt)
		{	switch((int)vtProp.bstrVal)
			{	case 1:
					wsprintf(s,L"1: Other");
				break;
				case 2:
					wsprintf(s,L"2: Unknown");
				break;
				case 3:
					wsprintf(s,L"3: Does not execute in \"count by byte\" mode");
				break;
				case 4:
					wsprintf(s,L"4: Execute in \"count by byte\" mode");
				break;
				default:
					wsprintf(s,L"");
				break;
			}
			SendMessage(hWndTree, LVM_SETITEMTEXT, (WPARAM)0, (LPARAM)&item);
			VariantClear(&vtProp);
			return;
	}	}
	wsprintf(s,L"Dec. value, not defined ...");
	SendMessage(hWndTree, LVM_SETITEMTEXT, (WPARAM)0, (LPARAM)&item);
}

VOID GetDMAChannelTiming(wchar_t *prop)
{	wchar_t s[64];
	item.pszText = prop;
	item.iSubItem = 0;
	SendMessage(hWndTree, LVM_INSERTITEM, (WPARAM)0, (LPARAM)&item);
	item.iSubItem = 1;
	item.pszText = s;
	if(pclsObj)
	if(S_OK==pclsObj->Get(prop, 0, &vtProp, 0, 0))
	{	if(VT_NULL!=vtProp.vt)
		{	switch((int)vtProp.bstrVal)
			{	case 1:
					wsprintf(s,L"1: Other");
				break;
				case 2:
					wsprintf(s,L"2: Unknown");
				break;
				case 3:
					wsprintf(s,L"3: ISA Compatible");
				break;
				case 4:
					wsprintf(s,L"4: Type A");
				break;
				case 5:
					wsprintf(s,L"5: Type B");
				break;
				case 6:
					wsprintf(s,L"6: Type F");
				break;
				default:
					wsprintf(s,L"");
				break;
			}
			SendMessage(hWndTree, LVM_SETITEMTEXT, (WPARAM)0, (LPARAM)&item);
			VariantClear(&vtProp);
			return;
	}	}
	wsprintf(s,L"Dec. value, not defined ...");
	SendMessage(hWndTree, LVM_SETITEMTEXT, (WPARAM)0, (LPARAM)&item);
}

VOID GetDMATypeCTiming(wchar_t *prop)
{	wchar_t s[64];
	item.pszText = prop;
	item.iSubItem = 0;
	SendMessage(hWndTree, LVM_INSERTITEM, (WPARAM)0, (LPARAM)&item);
	item.iSubItem = 1;
	item.pszText = s;
	if(pclsObj)
	if(S_OK==pclsObj->Get(prop, 0, &vtProp, 0, 0))
	{	if(VT_NULL!=vtProp.vt)
		{	switch((int)vtProp.bstrVal)
			{	case 1:
					wsprintf(s,L"1: Other");
				break;
				case 2:
					wsprintf(s,L"2: Unknown");
				break;
				case 3:
					wsprintf(s,L"3: ISA Compatible");
				break;
				case 4:
					wsprintf(s,L"4: Not Supported");
				break;
				case 5:
					wsprintf(s,L"5: Supported");
				break;
				default:
					wsprintf(s,L"");
				break;
			}
			SendMessage(hWndTree, LVM_SETITEMTEXT, (WPARAM)0, (LPARAM)&item);
			VariantClear(&vtProp);
			return;
	}	}
	wsprintf(s,L"Dec. value, not defined ...");
	SendMessage(hWndTree, LVM_SETITEMTEXT, (WPARAM)0, (LPARAM)&item);
}

VOID GetDMAWordMode(wchar_t *prop)
{	wchar_t s[64];
	item.pszText = prop;
	item.iSubItem = 0;
	SendMessage(hWndTree, LVM_INSERTITEM, (WPARAM)0, (LPARAM)&item);
	item.iSubItem = 1;
	item.pszText = s;
	if(pclsObj)
	if(S_OK==pclsObj->Get(prop, 0, &vtProp, 0, 0))
	{	if(VT_NULL!=vtProp.vt)
		{	switch((int)vtProp.bstrVal)
			{	case 1:
					wsprintf(s,L"1: Other");
				break;
				case 2:
					wsprintf(s,L"2: Unknown");
				break;
				case 3:
					wsprintf(s,L"3: Does not execute in \"count by word\" mode");
				break;
				case 4:
					wsprintf(s,L"4: Execute in \"count by word\" mode");
				break;
				default:
					wsprintf(s,L"");
				break;
			}
			SendMessage(hWndTree, LVM_SETITEMTEXT, (WPARAM)0, (LPARAM)&item);
			VariantClear(&vtProp);
			return;
	}	}
	wsprintf(s,L"Dec. value, not defined ...");
	SendMessage(hWndTree, LVM_SETITEMTEXT, (WPARAM)0, (LPARAM)&item);
}

VOID WMI_Motherboard_Classes_Win32_DMAChannel()
{   HRESULT hres;
    hres =  CoInitializeEx(0, COINIT_MULTITHREADED); 
    if(FAILED(hres))
        return;
    hres =  CoInitializeSecurity(
        NULL, 
        -1,                          // COM authentication
        NULL,                        // Authentication services
        NULL,                        // Reserved
        RPC_C_AUTHN_LEVEL_DEFAULT,   // Default authentication 
        RPC_C_IMP_LEVEL_IMPERSONATE, // Default Impersonation  
        NULL,                        // Authentication info
        EOAC_NONE,                   // Additional capabilities 
        NULL                         // Reserved
        );
    if (FAILED(hres))
    {	CoUninitialize();
        return;                      // Program has failed.
    }
    IWbemLocator *pLoc = NULL;
    hres = CoCreateInstance(
        CLSID_WbemLocator,             
        0, 
        CLSCTX_INPROC_SERVER, 
        IID_IWbemLocator, (LPVOID *) &pLoc);
    if (FAILED(hres))
    {   CoUninitialize();
        return;						// Program has failed.
    }
    IWbemServices *pSvc = NULL;
    hres = pLoc->ConnectServer(
         _bstr_t(L"ROOT\\CIMV2"), // Object path of WMI namespace
         NULL,                    // User name. NULL = current user
         NULL,                    // User password. NULL = current
         0,                       // Locale. NULL indicates current
         NULL,                    // Security flags.
         0,                       // Authority (e.g. Kerberos)
         0,                       // Context object 
         &pSvc                    // pointer to IWbemServices proxy
         );
    
    if (FAILED(hres))
    {   pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    hres = CoSetProxyBlanket(
       pSvc,                        // Indicates the proxy to set
       RPC_C_AUTHN_WINNT,           // RPC_C_AUTHN_xxx
       RPC_C_AUTHZ_NONE,            // RPC_C_AUTHZ_xxx
       NULL,                        // Server principal name 
       RPC_C_AUTHN_LEVEL_CALL,      // RPC_C_AUTHN_LEVEL_xxx 
       RPC_C_IMP_LEVEL_IMPERSONATE, // RPC_C_IMP_LEVEL_xxx
       NULL,                        // client identity
       EOAC_NONE                    // proxy capabilities 
    );
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    IEnumWbemClassObject* pEnumerator = NULL;
    hres = pSvc->ExecQuery(
        bstr_t("WQL"), 
        bstr_t("SELECT * FROM Win32_DMAChannel"),
        WBEM_FLAG_FORWARD_ONLY | WBEM_FLAG_RETURN_IMMEDIATELY, 
        NULL,
        &pEnumerator);
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();
        CoUninitialize();
        return;						// Program has failed.
    }
    pclsObj=0;
    ULONG uReturn = 0;
    while (pEnumerator)
    {	HRESULT hr = pEnumerator->Next(WBEM_INFINITE, 1, &pclsObj, &uReturn);
		//if(0 == uReturn)
		//  break;

		GetDMAWordMode(L"WordMode");
		GetDMATypeCTiming(L"TypeCTiming");
		GetDecArray(L"TransferWidths");
		GetStr(L"Status");
		GetDec(L"Port");
		GetStr(L"Name");
		GetDec(L"MaxTransferSize");
		GetDatetime(L"InstallDate");
		GetDec(L"DMAChannel");
		GetStr(L"Description");
		GetStr(L"CSName");
		GetStr(L"CSCreationClassName");
		GetStr(L"CreationClassName");
		GetDMAChannelTiming(L"ChannelTiming");
		GetStr(L"Caption");
		GetDMAByteMode(L"ByteMode");
		GetBool(L"BurstMode");
		GetDMAAvailability(L"Availability");
		GetDec(L"AddressSize");

		item.pszText = L"";
		item.iSubItem = 0;
		SendMessage(hWndTree, LVM_INSERTITEM, (WPARAM)0, (LPARAM)&item);

		if(0 == uReturn)
		  break;
	}
    if(pSvc)pSvc->Release();
    if(pLoc)pLoc->Release();
    if(pEnumerator)pEnumerator->Release();
    if(pclsObj)pclsObj->Release();
    CoUninitialize();
}

VOID WMI_Motherboard_Classes_Win32_FloppyController()
{   HRESULT hres;
    hres =  CoInitializeEx(0, COINIT_MULTITHREADED); 
    if(FAILED(hres))
        return;
    hres =  CoInitializeSecurity(
        NULL, 
        -1,                          // COM authentication
        NULL,                        // Authentication services
        NULL,                        // Reserved
        RPC_C_AUTHN_LEVEL_DEFAULT,   // Default authentication 
        RPC_C_IMP_LEVEL_IMPERSONATE, // Default Impersonation  
        NULL,                        // Authentication info
        EOAC_NONE,                   // Additional capabilities 
        NULL                         // Reserved
        );
    if (FAILED(hres))
    {	CoUninitialize();
        return;                      // Program has failed.
    }
    IWbemLocator *pLoc = NULL;
    hres = CoCreateInstance(
        CLSID_WbemLocator,             
        0, 
        CLSCTX_INPROC_SERVER, 
        IID_IWbemLocator, (LPVOID *) &pLoc);
    if (FAILED(hres))
    {   CoUninitialize();
        return;						// Program has failed.
    }
    IWbemServices *pSvc = NULL;
    hres = pLoc->ConnectServer(
         _bstr_t(L"ROOT\\CIMV2"), // Object path of WMI namespace
         NULL,                    // User name. NULL = current user
         NULL,                    // User password. NULL = current
         0,                       // Locale. NULL indicates current
         NULL,                    // Security flags.
         0,                       // Authority (e.g. Kerberos)
         0,                       // Context object 
         &pSvc                    // pointer to IWbemServices proxy
         );
    
    if (FAILED(hres))
    {   pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    hres = CoSetProxyBlanket(
       pSvc,                        // Indicates the proxy to set
       RPC_C_AUTHN_WINNT,           // RPC_C_AUTHN_xxx
       RPC_C_AUTHZ_NONE,            // RPC_C_AUTHZ_xxx
       NULL,                        // Server principal name 
       RPC_C_AUTHN_LEVEL_CALL,      // RPC_C_AUTHN_LEVEL_xxx 
       RPC_C_IMP_LEVEL_IMPERSONATE, // RPC_C_IMP_LEVEL_xxx
       NULL,                        // client identity
       EOAC_NONE                    // proxy capabilities 
    );
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    IEnumWbemClassObject* pEnumerator = NULL;
    hres = pSvc->ExecQuery(
        bstr_t("WQL"), 
        bstr_t("SELECT * FROM Win32_FloppyController"),
        WBEM_FLAG_FORWARD_ONLY | WBEM_FLAG_RETURN_IMMEDIATELY, 
        NULL,
        &pEnumerator);
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();
        CoUninitialize();
        return;						// Program has failed.
    }
    pclsObj=0;
    ULONG uReturn = 0;
    while (pEnumerator)
    {	HRESULT hr = pEnumerator->Next(WBEM_INFINITE, 1, &pclsObj, &uReturn);
		//if(0 == uReturn)
		//  break;

		GetDatetime(L"TimeOfLastReset");
		GetStr(L"SystemName");
		GetStr(L"SystemCreationClassName");
		GetDec(L"StatusInfo");
		GetStr(L"Status");
		GetDec(L"ProtocolSupported");
		GetBool(L"PowerManagementSupported");
		GetDecArray(L"PowerManagementCapabilities");
		GetStr(L"PNPDeviceID");
		GetStr(L"Name");
		GetDec(L"MaxNumberControlled");
		GetStr(L"Manufacturer");
		GetDec(L"LastErrorCode");
		GetDatetime(L"InstallDate");
		GetStr(L"ErrorDescription");
		GetBool(L"ErrorCleared");
		GetStr(L"DeviceID");
		GetStr(L"Description");
		GetStr(L"CreationClassName");
		GetBool(L"ConfigManagerUserConfig");
		GetConfigManagerErrorCode(L"ConfigManagerErrorCode");
		GetStr(L"Caption");
		GetDec(L"Availability");

		item.pszText = L"";
		item.iSubItem = 0;
		SendMessage(hWndTree, LVM_INSERTITEM, (WPARAM)0, (LPARAM)&item);

		if(0 == uReturn)
		  break;
	}
    if(pSvc)pSvc->Release();
    if(pLoc)pLoc->Release();
    if(pEnumerator)pEnumerator->Release();
    if(pclsObj)pclsObj->Release();
    CoUninitialize();
}

VOID WMI_Motherboard_Classes_Win32_IDEController()
{   HRESULT hres;
    hres =  CoInitializeEx(0, COINIT_MULTITHREADED); 
    if(FAILED(hres))
        return;
    hres =  CoInitializeSecurity(
        NULL, 
        -1,                          // COM authentication
        NULL,                        // Authentication services
        NULL,                        // Reserved
        RPC_C_AUTHN_LEVEL_DEFAULT,   // Default authentication 
        RPC_C_IMP_LEVEL_IMPERSONATE, // Default Impersonation  
        NULL,                        // Authentication info
        EOAC_NONE,                   // Additional capabilities 
        NULL                         // Reserved
        );
    if (FAILED(hres))
    {	CoUninitialize();
        return;                      // Program has failed.
    }
    IWbemLocator *pLoc = NULL;
    hres = CoCreateInstance(
        CLSID_WbemLocator,             
        0, 
        CLSCTX_INPROC_SERVER, 
        IID_IWbemLocator, (LPVOID *) &pLoc);
    if (FAILED(hres))
    {   CoUninitialize();
        return;						// Program has failed.
    }
    IWbemServices *pSvc = NULL;
    hres = pLoc->ConnectServer(
         _bstr_t(L"ROOT\\CIMV2"), // Object path of WMI namespace
         NULL,                    // User name. NULL = current user
         NULL,                    // User password. NULL = current
         0,                       // Locale. NULL indicates current
         NULL,                    // Security flags.
         0,                       // Authority (e.g. Kerberos)
         0,                       // Context object 
         &pSvc                    // pointer to IWbemServices proxy
         );
    
    if (FAILED(hres))
    {   pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    hres = CoSetProxyBlanket(
       pSvc,                        // Indicates the proxy to set
       RPC_C_AUTHN_WINNT,           // RPC_C_AUTHN_xxx
       RPC_C_AUTHZ_NONE,            // RPC_C_AUTHZ_xxx
       NULL,                        // Server principal name 
       RPC_C_AUTHN_LEVEL_CALL,      // RPC_C_AUTHN_LEVEL_xxx 
       RPC_C_IMP_LEVEL_IMPERSONATE, // RPC_C_IMP_LEVEL_xxx
       NULL,                        // client identity
       EOAC_NONE                    // proxy capabilities 
    );
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    IEnumWbemClassObject* pEnumerator = NULL;
    hres = pSvc->ExecQuery(
        bstr_t("WQL"), 
        bstr_t("SELECT * FROM Win32_IDEController"),
        WBEM_FLAG_FORWARD_ONLY | WBEM_FLAG_RETURN_IMMEDIATELY, 
        NULL,
        &pEnumerator);
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();
        CoUninitialize();
        return;						// Program has failed.
    }
    pclsObj=0;
    ULONG uReturn = 0;
    while (pEnumerator)
    {	HRESULT hr = pEnumerator->Next(WBEM_INFINITE, 1, &pclsObj, &uReturn);
		//if(0 == uReturn)
		//  break;

		GetDatetime(L"TimeOfLastReset");
		GetStr(L"SystemName");
		GetStr(L"SystemCreationClassName");
		GetDec(L"StatusInfo");
		GetStr(L"Status");
		GetDec(L"ProtocolSupported");
		GetBool(L"PowerManagementSupported");
		GetDecArray(L"PowerManagementCapabilities");
		GetStr(L"PNPDeviceID");
		GetStr(L"Name");
		GetDec(L"MaxNumberControlled");
		GetStr(L"Manufacturer");
		GetDec(L"LastErrorCode");
		GetDatetime(L"InstallDate");
		GetStr(L"ErrorDescription");
		GetBool(L"ErrorCleared");
		GetStr(L"DeviceID");
		GetStr(L"Description");
		GetStr(L"CreationClassName");
		GetBool(L"ConfigManagerUserConfig");
		GetConfigManagerErrorCode(L"ConfigManagerErrorCode");
		GetStr(L"Caption");
		GetDec(L"Availability");

		item.pszText = L"";
		item.iSubItem = 0;
		SendMessage(hWndTree, LVM_INSERTITEM, (WPARAM)0, (LPARAM)&item);

		if(0 == uReturn)
		  break;
	}
    if(pSvc)pSvc->Release();
    if(pLoc)pLoc->Release();
    if(pEnumerator)pEnumerator->Release();
    if(pclsObj)pclsObj->Release();
    CoUninitialize();
}

VOID WMI_Motherboard_Classes_Win32_IDEControllerDevice()
{   HRESULT hres;
    hres =  CoInitializeEx(0, COINIT_MULTITHREADED); 
    if(FAILED(hres))
        return;
    hres =  CoInitializeSecurity(
        NULL, 
        -1,                          // COM authentication
        NULL,                        // Authentication services
        NULL,                        // Reserved
        RPC_C_AUTHN_LEVEL_DEFAULT,   // Default authentication 
        RPC_C_IMP_LEVEL_IMPERSONATE, // Default Impersonation  
        NULL,                        // Authentication info
        EOAC_NONE,                   // Additional capabilities 
        NULL                         // Reserved
        );
    if (FAILED(hres))
    {	CoUninitialize();
        return;                      // Program has failed.
    }
    IWbemLocator *pLoc = NULL;
    hres = CoCreateInstance(
        CLSID_WbemLocator,             
        0, 
        CLSCTX_INPROC_SERVER, 
        IID_IWbemLocator, (LPVOID *) &pLoc);
    if (FAILED(hres))
    {   CoUninitialize();
        return;						// Program has failed.
    }
    IWbemServices *pSvc = NULL;
    hres = pLoc->ConnectServer(
         _bstr_t(L"ROOT\\CIMV2"), // Object path of WMI namespace
         NULL,                    // User name. NULL = current user
         NULL,                    // User password. NULL = current
         0,                       // Locale. NULL indicates current
         NULL,                    // Security flags.
         0,                       // Authority (e.g. Kerberos)
         0,                       // Context object 
         &pSvc                    // pointer to IWbemServices proxy
         );
    
    if (FAILED(hres))
    {   pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    hres = CoSetProxyBlanket(
       pSvc,                        // Indicates the proxy to set
       RPC_C_AUTHN_WINNT,           // RPC_C_AUTHN_xxx
       RPC_C_AUTHZ_NONE,            // RPC_C_AUTHZ_xxx
       NULL,                        // Server principal name 
       RPC_C_AUTHN_LEVEL_CALL,      // RPC_C_AUTHN_LEVEL_xxx 
       RPC_C_IMP_LEVEL_IMPERSONATE, // RPC_C_IMP_LEVEL_xxx
       NULL,                        // client identity
       EOAC_NONE                    // proxy capabilities 
    );
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    IEnumWbemClassObject* pEnumerator = NULL;
    hres = pSvc->ExecQuery(
        bstr_t("WQL"), 
        bstr_t("SELECT * FROM Win32_IDEControllerDevice"),
        WBEM_FLAG_FORWARD_ONLY | WBEM_FLAG_RETURN_IMMEDIATELY, 
        NULL,
        &pEnumerator);
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();
        CoUninitialize();
        return;						// Program has failed.
    }
    pclsObj=0;
    ULONG uReturn = 0;
    while (pEnumerator)
    {	HRESULT hr = pEnumerator->Next(WBEM_INFINITE, 1, &pclsObj, &uReturn);
		//if(0 == uReturn)
		//  break;

		GetDec(L"NumberOfSoftResets");
		GetDec(L"NumberOfHardResets");
		GetDec(L"NegotiatedSpeed");
		GetDec(L"NegotiatedDataWidth");
		GetStr(L"Dependent");//CIM_LogicalDevice ref Dependent;
		GetStr(L"Antecedent");//Win32_IDEController ref Antecedent;
		GetDec(L"AccessState");

		item.pszText = L"";
		item.iSubItem = 0;
		SendMessage(hWndTree, LVM_INSERTITEM, (WPARAM)0, (LPARAM)&item);

		if(0 == uReturn)
		  break;
	}
    if(pSvc)pSvc->Release();
    if(pLoc)pLoc->Release();
    if(pEnumerator)pEnumerator->Release();
    if(pclsObj)pclsObj->Release();
    CoUninitialize();
}

VOID WMI_Motherboard_Classes_Win32_InfraredDevice()
{   HRESULT hres;
    hres =  CoInitializeEx(0, COINIT_MULTITHREADED); 
    if(FAILED(hres))
        return;
    hres =  CoInitializeSecurity(
        NULL, 
        -1,                          // COM authentication
        NULL,                        // Authentication services
        NULL,                        // Reserved
        RPC_C_AUTHN_LEVEL_DEFAULT,   // Default authentication 
        RPC_C_IMP_LEVEL_IMPERSONATE, // Default Impersonation  
        NULL,                        // Authentication info
        EOAC_NONE,                   // Additional capabilities 
        NULL                         // Reserved
        );
    if (FAILED(hres))
    {	CoUninitialize();
        return;                      // Program has failed.
    }
    IWbemLocator *pLoc = NULL;
    hres = CoCreateInstance(
        CLSID_WbemLocator,             
        0, 
        CLSCTX_INPROC_SERVER, 
        IID_IWbemLocator, (LPVOID *) &pLoc);
    if (FAILED(hres))
    {   CoUninitialize();
        return;						// Program has failed.
    }
    IWbemServices *pSvc = NULL;
    hres = pLoc->ConnectServer(
         _bstr_t(L"ROOT\\CIMV2"), // Object path of WMI namespace
         NULL,                    // User name. NULL = current user
         NULL,                    // User password. NULL = current
         0,                       // Locale. NULL indicates current
         NULL,                    // Security flags.
         0,                       // Authority (e.g. Kerberos)
         0,                       // Context object 
         &pSvc                    // pointer to IWbemServices proxy
         );
    
    if (FAILED(hres))
    {   pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    hres = CoSetProxyBlanket(
       pSvc,                        // Indicates the proxy to set
       RPC_C_AUTHN_WINNT,           // RPC_C_AUTHN_xxx
       RPC_C_AUTHZ_NONE,            // RPC_C_AUTHZ_xxx
       NULL,                        // Server principal name 
       RPC_C_AUTHN_LEVEL_CALL,      // RPC_C_AUTHN_LEVEL_xxx 
       RPC_C_IMP_LEVEL_IMPERSONATE, // RPC_C_IMP_LEVEL_xxx
       NULL,                        // client identity
       EOAC_NONE                    // proxy capabilities 
    );
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    IEnumWbemClassObject* pEnumerator = NULL;
    hres = pSvc->ExecQuery(
        bstr_t("WQL"), 
        bstr_t("SELECT * FROM Win32_InfraredDevice"),
        WBEM_FLAG_FORWARD_ONLY | WBEM_FLAG_RETURN_IMMEDIATELY, 
        NULL,
        &pEnumerator);
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();
        CoUninitialize();
        return;						// Program has failed.
    }
    pclsObj=0;
    ULONG uReturn = 0;
    while (pEnumerator)
    {	HRESULT hr = pEnumerator->Next(WBEM_INFINITE, 1, &pclsObj, &uReturn);
		//if(0 == uReturn)
		//  break;

		GetDatetime(L"TimeOfLastReset");
		GetStr(L"SystemName");
		GetStr(L"SystemCreationClassName");
		GetDec(L"StatusInfo");
		GetStr(L"Status");
		GetDec(L"ProtocolSupported");
		GetBool(L"PowerManagementSupported");
		GetDecArray(L"PowerManagementCapabilities");
		GetStr(L"PNPDeviceID");
		GetStr(L"Name");
		GetDec(L"MaxNumberControlled");
		GetStr(L"Manufacturer");
		GetDec(L"LastErrorCode");
		GetDatetime(L"InstallDate");
		GetStr(L"ErrorDescription");
		GetBool(L"ErrorCleared");
		GetStr(L"DeviceID");
		GetStr(L"Description");
		GetStr(L"CreationClassName");
		GetBool(L"ConfigManagerUserConfig");
		GetConfigManagerErrorCode(L"ConfigManagerErrorCode");
		GetStr(L"Caption");
		GetDec(L"Availability");

		item.pszText = L"";
		item.iSubItem = 0;
		SendMessage(hWndTree, LVM_INSERTITEM, (WPARAM)0, (LPARAM)&item);

		if(0 == uReturn)
		  break;
	}
    if(pSvc)pSvc->Release();
    if(pLoc)pLoc->Release();
    if(pEnumerator)pEnumerator->Release();
    if(pclsObj)pclsObj->Release();
    CoUninitialize();
}

VOID GetIRQAvailability(wchar_t *prop)
{	wchar_t s[64];
	item.pszText = prop;
	item.iSubItem = 0;
	SendMessage(hWndTree, LVM_INSERTITEM, (WPARAM)0, (LPARAM)&item);
	item.iSubItem = 1;
	item.pszText = s;
	if(pclsObj)
	if(S_OK==pclsObj->Get(prop, 0, &vtProp, 0, 0))
	{	if(VT_NULL!=vtProp.vt)
		{	switch((int)vtProp.bstrVal)
			{	case 0:
					wsprintf(s,L"0: Other");
				break;
				case 1:
					wsprintf(s,L"1: Unknown");
				break;
				case 2:
					wsprintf(s,L"2: Available");
				break;
				case 3:
					wsprintf(s,L"3: In Use or Not Available");
				break;
				case 4:
					wsprintf(s,L"4: In Use and Available or Shareable");
				break;
				default:
					wsprintf(s,L"");
				break;
			}
			SendMessage(hWndTree, LVM_SETITEMTEXT, (WPARAM)0, (LPARAM)&item);
			VariantClear(&vtProp);
			return;
	}	}
	wsprintf(s,L"Dec. value, not defined ...");
	SendMessage(hWndTree, LVM_SETITEMTEXT, (WPARAM)0, (LPARAM)&item);
}

VOID GetIRQTriggerLevel(wchar_t *prop)
{	wchar_t s[64];
	item.pszText = prop;
	item.iSubItem = 0;
	SendMessage(hWndTree, LVM_INSERTITEM, (WPARAM)0, (LPARAM)&item);
	item.iSubItem = 1;
	item.pszText = s;
	if(pclsObj)
	if(S_OK==pclsObj->Get(prop, 0, &vtProp, 0, 0))
	{	if(VT_NULL!=vtProp.vt)
		{	switch((int)vtProp.bstrVal)
			{	case 1:
					wsprintf(s,L"1: Other");
				break;
				case 2:
					wsprintf(s,L"2: Unknown");
				break;
				case 3:
					wsprintf(s,L"3: Active Low");
				break;
				case 4:
					wsprintf(s,L"4: Active High");
				break;
				default:
					wsprintf(s,L"");
				break;
			}
			SendMessage(hWndTree, LVM_SETITEMTEXT, (WPARAM)0, (LPARAM)&item);
			VariantClear(&vtProp);
			return;
	}	}
	wsprintf(s,L"Dec. value, not defined ...");
	SendMessage(hWndTree, LVM_SETITEMTEXT, (WPARAM)0, (LPARAM)&item);
}

VOID GetIRQTriggerType(wchar_t *prop)
{	wchar_t s[64];
	item.pszText = prop;
	item.iSubItem = 0;
	SendMessage(hWndTree, LVM_INSERTITEM, (WPARAM)0, (LPARAM)&item);
	item.iSubItem = 1;
	item.pszText = s;
	if(pclsObj)
	if(S_OK==pclsObj->Get(prop, 0, &vtProp, 0, 0))
	{	if(VT_NULL!=vtProp.vt)
		{	switch((int)vtProp.bstrVal)
			{	case 1:
					wsprintf(s,L"1: Other");
				break;
				case 2:
					wsprintf(s,L"2: Unknown");
				break;
				case 3:
					wsprintf(s,L"3: Level");
				break;
				case 4:
					wsprintf(s,L"4: Edge");
				break;
				default:
					wsprintf(s,L"");
				break;
			}
			SendMessage(hWndTree, LVM_SETITEMTEXT, (WPARAM)0, (LPARAM)&item);
			VariantClear(&vtProp);
			return;
	}	}
	wsprintf(s,L"Dec. value, not defined ...");
	SendMessage(hWndTree, LVM_SETITEMTEXT, (WPARAM)0, (LPARAM)&item);
}

VOID WMI_Motherboard_Classes_Win32_IRQResource()
{   HRESULT hres;
    hres =  CoInitializeEx(0, COINIT_MULTITHREADED); 
    if(FAILED(hres))
        return;
    hres =  CoInitializeSecurity(
        NULL, 
        -1,                          // COM authentication
        NULL,                        // Authentication services
        NULL,                        // Reserved
        RPC_C_AUTHN_LEVEL_DEFAULT,   // Default authentication 
        RPC_C_IMP_LEVEL_IMPERSONATE, // Default Impersonation  
        NULL,                        // Authentication info
        EOAC_NONE,                   // Additional capabilities 
        NULL                         // Reserved
        );
    if (FAILED(hres))
    {	CoUninitialize();
        return;                      // Program has failed.
    }
    IWbemLocator *pLoc = NULL;
    hres = CoCreateInstance(
        CLSID_WbemLocator,             
        0, 
        CLSCTX_INPROC_SERVER, 
        IID_IWbemLocator, (LPVOID *) &pLoc);
    if (FAILED(hres))
    {   CoUninitialize();
        return;						// Program has failed.
    }
    IWbemServices *pSvc = NULL;
    hres = pLoc->ConnectServer(
         _bstr_t(L"ROOT\\CIMV2"), // Object path of WMI namespace
         NULL,                    // User name. NULL = current user
         NULL,                    // User password. NULL = current
         0,                       // Locale. NULL indicates current
         NULL,                    // Security flags.
         0,                       // Authority (e.g. Kerberos)
         0,                       // Context object 
         &pSvc                    // pointer to IWbemServices proxy
         );
    
    if (FAILED(hres))
    {   pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    hres = CoSetProxyBlanket(
       pSvc,                        // Indicates the proxy to set
       RPC_C_AUTHN_WINNT,           // RPC_C_AUTHN_xxx
       RPC_C_AUTHZ_NONE,            // RPC_C_AUTHZ_xxx
       NULL,                        // Server principal name 
       RPC_C_AUTHN_LEVEL_CALL,      // RPC_C_AUTHN_LEVEL_xxx 
       RPC_C_IMP_LEVEL_IMPERSONATE, // RPC_C_IMP_LEVEL_xxx
       NULL,                        // client identity
       EOAC_NONE                    // proxy capabilities 
    );
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    IEnumWbemClassObject* pEnumerator = NULL;
    hres = pSvc->ExecQuery(
        bstr_t("WQL"), 
        bstr_t("SELECT * FROM Win32_IRQResource"),
        WBEM_FLAG_FORWARD_ONLY | WBEM_FLAG_RETURN_IMMEDIATELY, 
        NULL,
        &pEnumerator);
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();
        CoUninitialize();
        return;						// Program has failed.
    }
    pclsObj=0;
    ULONG uReturn = 0;
    while (pEnumerator)
    {	HRESULT hr = pEnumerator->Next(WBEM_INFINITE, 1, &pclsObj, &uReturn);
		//if(0 == uReturn)
		//  break;

		GetDec(L"Vector");
		GetIRQTriggerType(L"TriggerType");
		GetIRQTriggerLevel(L"TriggerLevel");
		GetStr(L"Status");
		GetBool(L"Shareable");
		GetStr(L"Name");
		GetDec(L"IRQNumber");
		GetDatetime(L"InstallDate");
		GetBool(L"Hardware");
		GetStr(L"Description");
		GetStr(L"CSName");
		GetStr(L"CSCreationClassName");
		GetStr(L"CreationClassName");
		GetStr(L"Caption");
		GetIRQAvailability(L"Availability");

		item.pszText = L"";
		item.iSubItem = 0;
		SendMessage(hWndTree, LVM_INSERTITEM, (WPARAM)0, (LPARAM)&item);

		if(0 == uReturn)
		  break;
	}
    if(pSvc)pSvc->Release();
    if(pLoc)pLoc->Release();
    if(pEnumerator)pEnumerator->Release();
    if(pclsObj)pclsObj->Release();
    CoUninitialize();
}

VOID WMI_Motherboard_Classes_Win32_MemoryArray()
{   HRESULT hres;
    hres =  CoInitializeEx(0, COINIT_MULTITHREADED); 
    if(FAILED(hres))
        return;
    hres =  CoInitializeSecurity(
        NULL, 
        -1,                          // COM authentication
        NULL,                        // Authentication services
        NULL,                        // Reserved
        RPC_C_AUTHN_LEVEL_DEFAULT,   // Default authentication 
        RPC_C_IMP_LEVEL_IMPERSONATE, // Default Impersonation  
        NULL,                        // Authentication info
        EOAC_NONE,                   // Additional capabilities 
        NULL                         // Reserved
        );
    if (FAILED(hres))
    {	CoUninitialize();
        return;                      // Program has failed.
    }
    IWbemLocator *pLoc = NULL;
    hres = CoCreateInstance(
        CLSID_WbemLocator,             
        0, 
        CLSCTX_INPROC_SERVER, 
        IID_IWbemLocator, (LPVOID *) &pLoc);
    if (FAILED(hres))
    {   CoUninitialize();
        return;						// Program has failed.
    }
    IWbemServices *pSvc = NULL;
    hres = pLoc->ConnectServer(
         _bstr_t(L"ROOT\\CIMV2"), // Object path of WMI namespace
         NULL,                    // User name. NULL = current user
         NULL,                    // User password. NULL = current
         0,                       // Locale. NULL indicates current
         NULL,                    // Security flags.
         0,                       // Authority (e.g. Kerberos)
         0,                       // Context object 
         &pSvc                    // pointer to IWbemServices proxy
         );
    
    if (FAILED(hres))
    {   pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    hres = CoSetProxyBlanket(
       pSvc,                        // Indicates the proxy to set
       RPC_C_AUTHN_WINNT,           // RPC_C_AUTHN_xxx
       RPC_C_AUTHZ_NONE,            // RPC_C_AUTHZ_xxx
       NULL,                        // Server principal name 
       RPC_C_AUTHN_LEVEL_CALL,      // RPC_C_AUTHN_LEVEL_xxx 
       RPC_C_IMP_LEVEL_IMPERSONATE, // RPC_C_IMP_LEVEL_xxx
       NULL,                        // client identity
       EOAC_NONE                    // proxy capabilities 
    );
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    IEnumWbemClassObject* pEnumerator = NULL;
    hres = pSvc->ExecQuery(
        bstr_t("WQL"), 
        bstr_t("SELECT * FROM Win32_MemoryArray"),
        WBEM_FLAG_FORWARD_ONLY | WBEM_FLAG_RETURN_IMMEDIATELY, 
        NULL,
        &pEnumerator);
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();
        CoUninitialize();
        return;						// Program has failed.
    }
    pclsObj=0;
    ULONG uReturn = 0;
    while (pEnumerator)
    {	HRESULT hr = pEnumerator->Next(WBEM_INFINITE, 1, &pclsObj, &uReturn);
		//if(0 == uReturn)
		//  break;

		GetStr(L"SystemName");
		GetBool(L"SystemLevelAddress");
		GetStr(L"SystemCreationClassName");
		GetDec(L"StatusInfo");
		GetStr(L"Status");
		GetDecX64(L"StartingAddress");
		GetStr(L"Purpose");
		GetBool(L"PowerManagementSupported");
		GetDecArray(L"PowerManagementCapabilities");
		GetStr(L"PNPDeviceID");
		GetStr(L"OtherErrorDescription");
		GetDec(L"NumberOfBlocks");
		GetStr(L"Name");
		GetDec(L"LastErrorCode");
		GetDatetime(L"InstallDate");
		GetDec(L"ErrorTransferSize");
		GetDatetime(L"ErrorTime");
		GetDec(L"ErrorResolution");
		GetStr(L"ErrorMethodology");
		GetDec(L"ErrorInfo");
		GetDec(L"ErrorGranularity");
		GetStr(L"ErrorDescription");
		GetDec(L"ErrorDataOrder");
		GetDecArray(L"ErrorData");
		GetBool(L"ErrorCleared");
		GetDecX64(L"ErrorAddress");
		GetDec(L"ErrorAccess");
		GetDecX64(L"EndingAddress");
		GetStr(L"DeviceID");
		GetStr(L"Description");
		GetStr(L"CreationClassName");
		GetBool(L"CorrectableError");
		GetBool(L"ConfigManagerUserConfig");
		GetConfigManagerErrorCode(L"ConfigManagerErrorCode");
		GetStr(L"Caption");
		GetDec(L"BlockSize");
		GetDec(L"Availability");
		GetDecArray(L"AdditionalErrorData");
		GetDec(L"Access");

		item.pszText = L"";
		item.iSubItem = 0;
		SendMessage(hWndTree, LVM_INSERTITEM, (WPARAM)0, (LPARAM)&item);

		if(0 == uReturn)
		  break;
	}
    if(pSvc)pSvc->Release();
    if(pLoc)pLoc->Release();
    if(pEnumerator)pEnumerator->Release();
    if(pclsObj)pclsObj->Release();
    CoUninitialize();
}

VOID WMI_Motherboard_Classes_Win32_MemoryArrayLocation()
{   HRESULT hres;
    hres =  CoInitializeEx(0, COINIT_MULTITHREADED); 
    if(FAILED(hres))
        return;
    hres =  CoInitializeSecurity(
        NULL, 
        -1,                          // COM authentication
        NULL,                        // Authentication services
        NULL,                        // Reserved
        RPC_C_AUTHN_LEVEL_DEFAULT,   // Default authentication 
        RPC_C_IMP_LEVEL_IMPERSONATE, // Default Impersonation  
        NULL,                        // Authentication info
        EOAC_NONE,                   // Additional capabilities 
        NULL                         // Reserved
        );
    if (FAILED(hres))
    {	CoUninitialize();
        return;                      // Program has failed.
    }
    IWbemLocator *pLoc = NULL;
    hres = CoCreateInstance(
        CLSID_WbemLocator,             
        0, 
        CLSCTX_INPROC_SERVER, 
        IID_IWbemLocator, (LPVOID *) &pLoc);
    if (FAILED(hres))
    {   CoUninitialize();
        return;						// Program has failed.
    }
    IWbemServices *pSvc = NULL;
    hres = pLoc->ConnectServer(
         _bstr_t(L"ROOT\\CIMV2"), // Object path of WMI namespace
         NULL,                    // User name. NULL = current user
         NULL,                    // User password. NULL = current
         0,                       // Locale. NULL indicates current
         NULL,                    // Security flags.
         0,                       // Authority (e.g. Kerberos)
         0,                       // Context object 
         &pSvc                    // pointer to IWbemServices proxy
         );
    
    if (FAILED(hres))
    {   pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    hres = CoSetProxyBlanket(
       pSvc,                        // Indicates the proxy to set
       RPC_C_AUTHN_WINNT,           // RPC_C_AUTHN_xxx
       RPC_C_AUTHZ_NONE,            // RPC_C_AUTHZ_xxx
       NULL,                        // Server principal name 
       RPC_C_AUTHN_LEVEL_CALL,      // RPC_C_AUTHN_LEVEL_xxx 
       RPC_C_IMP_LEVEL_IMPERSONATE, // RPC_C_IMP_LEVEL_xxx
       NULL,                        // client identity
       EOAC_NONE                    // proxy capabilities 
    );
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    IEnumWbemClassObject* pEnumerator = NULL;
    hres = pSvc->ExecQuery(
        bstr_t("WQL"), 
        bstr_t("SELECT * FROM Win32_MemoryArrayLocation"),
        WBEM_FLAG_FORWARD_ONLY | WBEM_FLAG_RETURN_IMMEDIATELY, 
        NULL,
        &pEnumerator);
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();
        CoUninitialize();
        return;						// Program has failed.
    }
    pclsObj=0;
    ULONG uReturn = 0;
    while (pEnumerator)
    {	HRESULT hr = pEnumerator->Next(WBEM_INFINITE, 1, &pclsObj, &uReturn);
		//if(0 == uReturn)
		//  break;

		GetStr(L"Antecedent");//Win32_PhysicalMemoryArray ref Antecedent;
		GetStr(L"Dependent");//Win32_MemoryArray ref Dependent;

		item.pszText = L"";
		item.iSubItem = 0;
		SendMessage(hWndTree, LVM_INSERTITEM, (WPARAM)0, (LPARAM)&item);

		if(0 == uReturn)
		  break;
	}
    if(pSvc)pSvc->Release();
    if(pLoc)pLoc->Release();
    if(pEnumerator)pEnumerator->Release();
    if(pclsObj)pclsObj->Release();
    CoUninitialize();
}

VOID WMI_Motherboard_Classes_Win32_MemoryDevice()
{   HRESULT hres;
    hres =  CoInitializeEx(0, COINIT_MULTITHREADED); 
    if(FAILED(hres))
        return;
    hres =  CoInitializeSecurity(
        NULL, 
        -1,                          // COM authentication
        NULL,                        // Authentication services
        NULL,                        // Reserved
        RPC_C_AUTHN_LEVEL_DEFAULT,   // Default authentication 
        RPC_C_IMP_LEVEL_IMPERSONATE, // Default Impersonation  
        NULL,                        // Authentication info
        EOAC_NONE,                   // Additional capabilities 
        NULL                         // Reserved
        );
    if (FAILED(hres))
    {	CoUninitialize();
        return;                      // Program has failed.
    }
    IWbemLocator *pLoc = NULL;
    hres = CoCreateInstance(
        CLSID_WbemLocator,             
        0, 
        CLSCTX_INPROC_SERVER, 
        IID_IWbemLocator, (LPVOID *) &pLoc);
    if (FAILED(hres))
    {   CoUninitialize();
        return;						// Program has failed.
    }
    IWbemServices *pSvc = NULL;
    hres = pLoc->ConnectServer(
         _bstr_t(L"ROOT\\CIMV2"), // Object path of WMI namespace
         NULL,                    // User name. NULL = current user
         NULL,                    // User password. NULL = current
         0,                       // Locale. NULL indicates current
         NULL,                    // Security flags.
         0,                       // Authority (e.g. Kerberos)
         0,                       // Context object 
         &pSvc                    // pointer to IWbemServices proxy
         );
    
    if (FAILED(hres))
    {   pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    hres = CoSetProxyBlanket(
       pSvc,                        // Indicates the proxy to set
       RPC_C_AUTHN_WINNT,           // RPC_C_AUTHN_xxx
       RPC_C_AUTHZ_NONE,            // RPC_C_AUTHZ_xxx
       NULL,                        // Server principal name 
       RPC_C_AUTHN_LEVEL_CALL,      // RPC_C_AUTHN_LEVEL_xxx 
       RPC_C_IMP_LEVEL_IMPERSONATE, // RPC_C_IMP_LEVEL_xxx
       NULL,                        // client identity
       EOAC_NONE                    // proxy capabilities 
    );
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    IEnumWbemClassObject* pEnumerator = NULL;
    hres = pSvc->ExecQuery(
        bstr_t("WQL"), 
        bstr_t("SELECT * FROM Win32_MemoryDevice"),
        WBEM_FLAG_FORWARD_ONLY | WBEM_FLAG_RETURN_IMMEDIATELY, 
        NULL,
        &pEnumerator);
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();
        CoUninitialize();
        return;						// Program has failed.
    }
    pclsObj=0;
    ULONG uReturn = 0;
    while (pEnumerator)
    {	HRESULT hr = pEnumerator->Next(WBEM_INFINITE, 1, &pclsObj, &uReturn);
		//if(0 == uReturn)
		//  break;

		GetStr(L"SystemName");
		GetBool(L"SystemLevelAddress");
		GetStr(L"SystemCreationClassName");
		GetDec(L"StatusInfo");
		GetStr(L"Status");
		GetDecX64(L"StartingAddress");
		GetStr(L"Purpose");
		GetBool(L"PowerManagementSupported");
		GetDecArray(L"PowerManagementCapabilities");
		GetStr(L"PNPDeviceID");
		GetStr(L"OtherErrorDescription");
		GetDec(L"NumberOfBlocks");
		GetStr(L"Name");
		GetDec(L"LastErrorCode");
		GetDatetime(L"InstallDate");
		GetDec(L"ErrorTransferSize");
		GetDatetime(L"ErrorTime");
		GetDec(L"ErrorResolution");
		GetStr(L"ErrorMethodology");
		GetDec(L"ErrorInfo");
		GetDec(L"ErrorGranularity");
		GetStr(L"ErrorDescription");
		GetDec(L"ErrorDataOrder");
		GetDecArray(L"ErrorData");
		GetBool(L"ErrorCleared");
		GetDecX64(L"ErrorAddress");
		GetDec(L"ErrorAccess");
		GetDecX64(L"EndingAddress");
		GetStr(L"DeviceID");
		GetStr(L"Description");
		GetStr(L"CreationClassName");
		GetBool(L"CorrectableError");
		GetBool(L"ConfigManagerUserConfig");
		GetConfigManagerErrorCode(L"ConfigManagerErrorCode");
		GetStr(L"Caption");
		GetDec(L"BlockSize");
		GetDec(L"Availability");
		GetDecArray(L"AdditionalErrorData");
		GetDec(L"Access");

		item.pszText = L"";
		item.iSubItem = 0;
		SendMessage(hWndTree, LVM_INSERTITEM, (WPARAM)0, (LPARAM)&item);

		if(0 == uReturn)
		  break;
	}
    if(pSvc)pSvc->Release();
    if(pLoc)pLoc->Release();
    if(pEnumerator)pEnumerator->Release();
    if(pclsObj)pclsObj->Release();
    CoUninitialize();
}

VOID WMI_Motherboard_Classes_Win32_MemoryDeviceArray()
{   HRESULT hres;
    hres =  CoInitializeEx(0, COINIT_MULTITHREADED); 
    if(FAILED(hres))
        return;
    hres =  CoInitializeSecurity(
        NULL, 
        -1,                          // COM authentication
        NULL,                        // Authentication services
        NULL,                        // Reserved
        RPC_C_AUTHN_LEVEL_DEFAULT,   // Default authentication 
        RPC_C_IMP_LEVEL_IMPERSONATE, // Default Impersonation  
        NULL,                        // Authentication info
        EOAC_NONE,                   // Additional capabilities 
        NULL                         // Reserved
        );
    if (FAILED(hres))
    {	CoUninitialize();
        return;                      // Program has failed.
    }
    IWbemLocator *pLoc = NULL;
    hres = CoCreateInstance(
        CLSID_WbemLocator,             
        0, 
        CLSCTX_INPROC_SERVER, 
        IID_IWbemLocator, (LPVOID *) &pLoc);
    if (FAILED(hres))
    {   CoUninitialize();
        return;						// Program has failed.
    }
    IWbemServices *pSvc = NULL;
    hres = pLoc->ConnectServer(
         _bstr_t(L"ROOT\\CIMV2"), // Object path of WMI namespace
         NULL,                    // User name. NULL = current user
         NULL,                    // User password. NULL = current
         0,                       // Locale. NULL indicates current
         NULL,                    // Security flags.
         0,                       // Authority (e.g. Kerberos)
         0,                       // Context object 
         &pSvc                    // pointer to IWbemServices proxy
         );
    
    if (FAILED(hres))
    {   pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    hres = CoSetProxyBlanket(
       pSvc,                        // Indicates the proxy to set
       RPC_C_AUTHN_WINNT,           // RPC_C_AUTHN_xxx
       RPC_C_AUTHZ_NONE,            // RPC_C_AUTHZ_xxx
       NULL,                        // Server principal name 
       RPC_C_AUTHN_LEVEL_CALL,      // RPC_C_AUTHN_LEVEL_xxx 
       RPC_C_IMP_LEVEL_IMPERSONATE, // RPC_C_IMP_LEVEL_xxx
       NULL,                        // client identity
       EOAC_NONE                    // proxy capabilities 
    );
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    IEnumWbemClassObject* pEnumerator = NULL;
    hres = pSvc->ExecQuery(
        bstr_t("WQL"), 
        bstr_t("SELECT * FROM Win32_MemoryDeviceArray"),
        WBEM_FLAG_FORWARD_ONLY | WBEM_FLAG_RETURN_IMMEDIATELY, 
        NULL,
        &pEnumerator);
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();
        CoUninitialize();
        return;						// Program has failed.
    }
    pclsObj=0;
    ULONG uReturn = 0;
    while (pEnumerator)
    {	HRESULT hr = pEnumerator->Next(WBEM_INFINITE, 1, &pclsObj, &uReturn);
		//if(0 == uReturn)
		//  break;

		GetStr(L"GroupComponent");//Win32_MemoryArray ref GroupComponent;
		GetStr(L"PartComponent");//Win32_MemoryDevice ref PartComponent;

		item.pszText = L"";
		item.iSubItem = 0;
		SendMessage(hWndTree, LVM_INSERTITEM, (WPARAM)0, (LPARAM)&item);

		if(0 == uReturn)
		  break;
	}
    if(pSvc)pSvc->Release();
    if(pLoc)pLoc->Release();
    if(pEnumerator)pEnumerator->Release();
    if(pclsObj)pclsObj->Release();
    CoUninitialize();
}

VOID WMI_Motherboard_Classes_Win32_MemoryDeviceLocation()
{   HRESULT hres;
    hres =  CoInitializeEx(0, COINIT_MULTITHREADED); 
    if(FAILED(hres))
        return;
    hres =  CoInitializeSecurity(
        NULL, 
        -1,                          // COM authentication
        NULL,                        // Authentication services
        NULL,                        // Reserved
        RPC_C_AUTHN_LEVEL_DEFAULT,   // Default authentication 
        RPC_C_IMP_LEVEL_IMPERSONATE, // Default Impersonation  
        NULL,                        // Authentication info
        EOAC_NONE,                   // Additional capabilities 
        NULL                         // Reserved
        );
    if (FAILED(hres))
    {	CoUninitialize();
        return;                      // Program has failed.
    }
    IWbemLocator *pLoc = NULL;
    hres = CoCreateInstance(
        CLSID_WbemLocator,             
        0, 
        CLSCTX_INPROC_SERVER, 
        IID_IWbemLocator, (LPVOID *) &pLoc);
    if (FAILED(hres))
    {   CoUninitialize();
        return;						// Program has failed.
    }
    IWbemServices *pSvc = NULL;
    hres = pLoc->ConnectServer(
         _bstr_t(L"ROOT\\CIMV2"), // Object path of WMI namespace
         NULL,                    // User name. NULL = current user
         NULL,                    // User password. NULL = current
         0,                       // Locale. NULL indicates current
         NULL,                    // Security flags.
         0,                       // Authority (e.g. Kerberos)
         0,                       // Context object 
         &pSvc                    // pointer to IWbemServices proxy
         );
    
    if (FAILED(hres))
    {   pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    hres = CoSetProxyBlanket(
       pSvc,                        // Indicates the proxy to set
       RPC_C_AUTHN_WINNT,           // RPC_C_AUTHN_xxx
       RPC_C_AUTHZ_NONE,            // RPC_C_AUTHZ_xxx
       NULL,                        // Server principal name 
       RPC_C_AUTHN_LEVEL_CALL,      // RPC_C_AUTHN_LEVEL_xxx 
       RPC_C_IMP_LEVEL_IMPERSONATE, // RPC_C_IMP_LEVEL_xxx
       NULL,                        // client identity
       EOAC_NONE                    // proxy capabilities 
    );
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    IEnumWbemClassObject* pEnumerator = NULL;
    hres = pSvc->ExecQuery(
        bstr_t("WQL"), 
        bstr_t("SELECT * FROM Win32_MemoryDeviceLocation"),
        WBEM_FLAG_FORWARD_ONLY | WBEM_FLAG_RETURN_IMMEDIATELY, 
        NULL,
        &pEnumerator);
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();
        CoUninitialize();
        return;						// Program has failed.
    }
    pclsObj=0;
    ULONG uReturn = 0;
    while (pEnumerator)
    {	HRESULT hr = pEnumerator->Next(WBEM_INFINITE, 1, &pclsObj, &uReturn);
		//if(0 == uReturn)
		//  break;

		GetStr(L"Antecedent");//Win32_PhysicalMemory ref Antecedent;
		GetStr(L"Dependent");//Win32_MemoryDevice ref Dependent;

		item.pszText = L"";
		item.iSubItem = 0;
		SendMessage(hWndTree, LVM_INSERTITEM, (WPARAM)0, (LPARAM)&item);

		if(0 == uReturn)
		  break;
	}
    if(pSvc)pSvc->Release();
    if(pLoc)pLoc->Release();
    if(pEnumerator)pEnumerator->Release();
    if(pclsObj)pclsObj->Release();
    CoUninitialize();
}

VOID WMI_Motherboard_Classes_Win32_MotherboardDevice()
{   HRESULT hres;
    hres =  CoInitializeEx(0, COINIT_MULTITHREADED); 
    if(FAILED(hres))
        return;
    hres =  CoInitializeSecurity(
        NULL, 
        -1,                          // COM authentication
        NULL,                        // Authentication services
        NULL,                        // Reserved
        RPC_C_AUTHN_LEVEL_DEFAULT,   // Default authentication 
        RPC_C_IMP_LEVEL_IMPERSONATE, // Default Impersonation  
        NULL,                        // Authentication info
        EOAC_NONE,                   // Additional capabilities 
        NULL                         // Reserved
        );
    if (FAILED(hres))
    {	CoUninitialize();
        return;                      // Program has failed.
    }
    IWbemLocator *pLoc = NULL;
    hres = CoCreateInstance(
        CLSID_WbemLocator,             
        0, 
        CLSCTX_INPROC_SERVER, 
        IID_IWbemLocator, (LPVOID *) &pLoc);
    if (FAILED(hres))
    {   CoUninitialize();
        return;						// Program has failed.
    }
    IWbemServices *pSvc = NULL;
    hres = pLoc->ConnectServer(
         _bstr_t(L"ROOT\\CIMV2"), // Object path of WMI namespace
         NULL,                    // User name. NULL = current user
         NULL,                    // User password. NULL = current
         0,                       // Locale. NULL indicates current
         NULL,                    // Security flags.
         0,                       // Authority (e.g. Kerberos)
         0,                       // Context object 
         &pSvc                    // pointer to IWbemServices proxy
         );
    
    if (FAILED(hres))
    {   pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    hres = CoSetProxyBlanket(
       pSvc,                        // Indicates the proxy to set
       RPC_C_AUTHN_WINNT,           // RPC_C_AUTHN_xxx
       RPC_C_AUTHZ_NONE,            // RPC_C_AUTHZ_xxx
       NULL,                        // Server principal name 
       RPC_C_AUTHN_LEVEL_CALL,      // RPC_C_AUTHN_LEVEL_xxx 
       RPC_C_IMP_LEVEL_IMPERSONATE, // RPC_C_IMP_LEVEL_xxx
       NULL,                        // client identity
       EOAC_NONE                    // proxy capabilities 
    );
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    IEnumWbemClassObject* pEnumerator = NULL;
    hres = pSvc->ExecQuery(
        bstr_t("WQL"), 
        bstr_t("SELECT * FROM Win32_MotherboardDevice"),
        WBEM_FLAG_FORWARD_ONLY | WBEM_FLAG_RETURN_IMMEDIATELY, 
        NULL,
        &pEnumerator);
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();
        CoUninitialize();
        return;						// Program has failed.
    }
    pclsObj=0;
    ULONG uReturn = 0;
    while (pEnumerator)
    {	HRESULT hr = pEnumerator->Next(WBEM_INFINITE, 1, &pclsObj, &uReturn);
		//if(0 == uReturn)
		//  break;

		GetStr(L"SystemName");
		GetStr(L"SystemCreationClassName");
		GetDec(L"StatusInfo");
		GetStr(L"Status");
		GetStr(L"SecondaryBusType");
		GetStr(L"RevisionNumber");
		GetStr(L"PrimaryBusType");
		GetBool(L"PowerManagementSupported");
		GetDecArray(L"PowerManagementCapabilities");
		GetStr(L"PNPDeviceID");
		GetStr(L"Name");
		GetDec(L"LastErrorCode");
		GetDatetime(L"InstallDate");
		GetStr(L"ErrorDescription");
		GetBool(L"ErrorCleared");
		GetStr(L"DeviceID");
		GetStr(L"Description");
		GetStr(L"CreationClassName");
		GetBool(L"ConfigManagerUserConfig");
		GetConfigManagerErrorCode(L"ConfigManagerErrorCode");
		GetStr(L"Caption");
		GetCacheMemoryAvailability(L"Availability");

		item.pszText = L"";
		item.iSubItem = 0;
		SendMessage(hWndTree, LVM_INSERTITEM, (WPARAM)0, (LPARAM)&item);

		if(0 == uReturn)
		  break;
	}
    if(pSvc)pSvc->Release();
    if(pLoc)pLoc->Release();
    if(pEnumerator)pEnumerator->Release();
    if(pclsObj)pclsObj->Release();
    CoUninitialize();
}

VOID WMI_Motherboard_Classes_Win32_OnBoardDevice()
{   HRESULT hres;
    hres =  CoInitializeEx(0, COINIT_MULTITHREADED); 
    if(FAILED(hres))
        return;
    hres =  CoInitializeSecurity(
        NULL, 
        -1,                          // COM authentication
        NULL,                        // Authentication services
        NULL,                        // Reserved
        RPC_C_AUTHN_LEVEL_DEFAULT,   // Default authentication 
        RPC_C_IMP_LEVEL_IMPERSONATE, // Default Impersonation  
        NULL,                        // Authentication info
        EOAC_NONE,                   // Additional capabilities 
        NULL                         // Reserved
        );
    if (FAILED(hres))
    {	CoUninitialize();
        return;                      // Program has failed.
    }
    IWbemLocator *pLoc = NULL;
    hres = CoCreateInstance(
        CLSID_WbemLocator,             
        0, 
        CLSCTX_INPROC_SERVER, 
        IID_IWbemLocator, (LPVOID *) &pLoc);
    if (FAILED(hres))
    {   CoUninitialize();
        return;						// Program has failed.
    }
    IWbemServices *pSvc = NULL;
    hres = pLoc->ConnectServer(
         _bstr_t(L"ROOT\\CIMV2"), // Object path of WMI namespace
         NULL,                    // User name. NULL = current user
         NULL,                    // User password. NULL = current
         0,                       // Locale. NULL indicates current
         NULL,                    // Security flags.
         0,                       // Authority (e.g. Kerberos)
         0,                       // Context object 
         &pSvc                    // pointer to IWbemServices proxy
         );
    
    if (FAILED(hres))
    {   pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    hres = CoSetProxyBlanket(
       pSvc,                        // Indicates the proxy to set
       RPC_C_AUTHN_WINNT,           // RPC_C_AUTHN_xxx
       RPC_C_AUTHZ_NONE,            // RPC_C_AUTHZ_xxx
       NULL,                        // Server principal name 
       RPC_C_AUTHN_LEVEL_CALL,      // RPC_C_AUTHN_LEVEL_xxx 
       RPC_C_IMP_LEVEL_IMPERSONATE, // RPC_C_IMP_LEVEL_xxx
       NULL,                        // client identity
       EOAC_NONE                    // proxy capabilities 
    );
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    IEnumWbemClassObject* pEnumerator = NULL;
    hres = pSvc->ExecQuery(
        bstr_t("WQL"), 
        bstr_t("SELECT * FROM Win32_OnBoardDevice"),
        WBEM_FLAG_FORWARD_ONLY | WBEM_FLAG_RETURN_IMMEDIATELY, 
        NULL,
        &pEnumerator);
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();
        CoUninitialize();
        return;						// Program has failed.
    }
    pclsObj=0;
    ULONG uReturn = 0;
    while (pEnumerator)
    {	HRESULT hr = pEnumerator->Next(WBEM_INFINITE, 1, &pclsObj, &uReturn);
		//if(0 == uReturn)
		//  break;

		GetStr(L"Version");
		GetStr(L"Tag");
		GetStr(L"Status");
		GetStr(L"SKU");
		GetStr(L"SerialNumber");
		GetBool(L"Replaceable");
		GetBool(L"Removable");
		GetBool(L"PoweredOn");
		GetStr(L"PartNumber");
		GetStr(L"OtherIdentifyingInfo");
		GetStr(L"Name");
		GetStr(L"Model");
		GetStr(L"Manufacturer");
		GetDatetime(L"InstallDate");
		GetBool(L"HotSwappable");
		GetBool(L"Enabled");
		GetDec(L"DeviceType");
		GetStr(L"Description");
		GetStr(L"CreationClassName");
		GetStr(L"Caption");

		item.pszText = L"";
		item.iSubItem = 0;
		SendMessage(hWndTree, LVM_INSERTITEM, (WPARAM)0, (LPARAM)&item);

		if(0 == uReturn)
		  break;
	}
    if(pSvc)pSvc->Release();
    if(pLoc)pLoc->Release();
    if(pEnumerator)pEnumerator->Release();
    if(pclsObj)pclsObj->Release();
    CoUninitialize();
}

VOID WMI_Motherboard_Classes_Win32_ParallelPort()
{   HRESULT hres;
    hres =  CoInitializeEx(0, COINIT_MULTITHREADED); 
    if(FAILED(hres))
        return;
    hres =  CoInitializeSecurity(
        NULL, 
        -1,                          // COM authentication
        NULL,                        // Authentication services
        NULL,                        // Reserved
        RPC_C_AUTHN_LEVEL_DEFAULT,   // Default authentication 
        RPC_C_IMP_LEVEL_IMPERSONATE, // Default Impersonation  
        NULL,                        // Authentication info
        EOAC_NONE,                   // Additional capabilities 
        NULL                         // Reserved
        );
    if (FAILED(hres))
    {	CoUninitialize();
        return;                      // Program has failed.
    }
    IWbemLocator *pLoc = NULL;
    hres = CoCreateInstance(
        CLSID_WbemLocator,             
        0, 
        CLSCTX_INPROC_SERVER, 
        IID_IWbemLocator, (LPVOID *) &pLoc);
    if (FAILED(hres))
    {   CoUninitialize();
        return;						// Program has failed.
    }
    IWbemServices *pSvc = NULL;
    hres = pLoc->ConnectServer(
         _bstr_t(L"ROOT\\CIMV2"), // Object path of WMI namespace
         NULL,                    // User name. NULL = current user
         NULL,                    // User password. NULL = current
         0,                       // Locale. NULL indicates current
         NULL,                    // Security flags.
         0,                       // Authority (e.g. Kerberos)
         0,                       // Context object 
         &pSvc                    // pointer to IWbemServices proxy
         );
    
    if (FAILED(hres))
    {   pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    hres = CoSetProxyBlanket(
       pSvc,                        // Indicates the proxy to set
       RPC_C_AUTHN_WINNT,           // RPC_C_AUTHN_xxx
       RPC_C_AUTHZ_NONE,            // RPC_C_AUTHZ_xxx
       NULL,                        // Server principal name 
       RPC_C_AUTHN_LEVEL_CALL,      // RPC_C_AUTHN_LEVEL_xxx 
       RPC_C_IMP_LEVEL_IMPERSONATE, // RPC_C_IMP_LEVEL_xxx
       NULL,                        // client identity
       EOAC_NONE                    // proxy capabilities 
    );
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    IEnumWbemClassObject* pEnumerator = NULL;
    hres = pSvc->ExecQuery(
        bstr_t("WQL"), 
        bstr_t("SELECT * FROM Win32_ParallelPort"),
        WBEM_FLAG_FORWARD_ONLY | WBEM_FLAG_RETURN_IMMEDIATELY, 
        NULL,
        &pEnumerator);
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();
        CoUninitialize();
        return;						// Program has failed.
    }
    pclsObj=0;
    ULONG uReturn = 0;
    while (pEnumerator)
    {	HRESULT hr = pEnumerator->Next(WBEM_INFINITE, 1, &pclsObj, &uReturn);
		//if(0 == uReturn)
		//  break;

		GetDatetime(L"TimeOfLastReset");
		GetStr(L"SystemName");
		GetStr(L"SystemCreationClassName");
		GetDec(L"StatusInfo");
		GetStr(L"Status");
		GetDec(L"ProtocolSupported");
		GetBool(L"PowerManagementSupported");
		GetDecArray(L"PowerManagementCapabilities");
		GetStr(L"PNPDeviceID");
		GetBool(L"OSAutoDiscovered");
		GetStr(L"Name");
		GetDec(L"MaxNumberControlled");
		GetDec(L"LastErrorCode");
		GetDatetime(L"InstallDate");
		GetStr(L"ErrorDescription");
		GetBool(L"ErrorCleared");
		GetBool(L"DMASupport");
		GetStr(L"DeviceID");
		GetStr(L"Description");
		GetStr(L"CreationClassName");
		GetBool(L"ConfigManagerUserConfig");
		GetConfigManagerErrorCode(L"ConfigManagerErrorCode");
		GetStr(L"Caption");
		GetStrArray(L"CapabilityDescriptions");
		GetDecArray(L"Capabilities");
		GetCacheMemoryAvailability(L"Availability");

		item.pszText = L"";
		item.iSubItem = 0;
		SendMessage(hWndTree, LVM_INSERTITEM, (WPARAM)0, (LPARAM)&item);

		if(0 == uReturn)
		  break;
	}
    if(pSvc)pSvc->Release();
    if(pLoc)pLoc->Release();
    if(pEnumerator)pEnumerator->Release();
    if(pclsObj)pclsObj->Release();
    CoUninitialize();
}

VOID WMI_Motherboard_Classes_Win32_PCMCIAController()
{   HRESULT hres;
    hres =  CoInitializeEx(0, COINIT_MULTITHREADED); 
    if(FAILED(hres))
        return;
    hres =  CoInitializeSecurity(
        NULL, 
        -1,                          // COM authentication
        NULL,                        // Authentication services
        NULL,                        // Reserved
        RPC_C_AUTHN_LEVEL_DEFAULT,   // Default authentication 
        RPC_C_IMP_LEVEL_IMPERSONATE, // Default Impersonation  
        NULL,                        // Authentication info
        EOAC_NONE,                   // Additional capabilities 
        NULL                         // Reserved
        );
    if (FAILED(hres))
    {	CoUninitialize();
        return;                      // Program has failed.
    }
    IWbemLocator *pLoc = NULL;
    hres = CoCreateInstance(
        CLSID_WbemLocator,             
        0, 
        CLSCTX_INPROC_SERVER, 
        IID_IWbemLocator, (LPVOID *) &pLoc);
    if (FAILED(hres))
    {   CoUninitialize();
        return;						// Program has failed.
    }
    IWbemServices *pSvc = NULL;
    hres = pLoc->ConnectServer(
         _bstr_t(L"ROOT\\CIMV2"), // Object path of WMI namespace
         NULL,                    // User name. NULL = current user
         NULL,                    // User password. NULL = current
         0,                       // Locale. NULL indicates current
         NULL,                    // Security flags.
         0,                       // Authority (e.g. Kerberos)
         0,                       // Context object 
         &pSvc                    // pointer to IWbemServices proxy
         );
    
    if (FAILED(hres))
    {   pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    hres = CoSetProxyBlanket(
       pSvc,                        // Indicates the proxy to set
       RPC_C_AUTHN_WINNT,           // RPC_C_AUTHN_xxx
       RPC_C_AUTHZ_NONE,            // RPC_C_AUTHZ_xxx
       NULL,                        // Server principal name 
       RPC_C_AUTHN_LEVEL_CALL,      // RPC_C_AUTHN_LEVEL_xxx 
       RPC_C_IMP_LEVEL_IMPERSONATE, // RPC_C_IMP_LEVEL_xxx
       NULL,                        // client identity
       EOAC_NONE                    // proxy capabilities 
    );
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    IEnumWbemClassObject* pEnumerator = NULL;
    hres = pSvc->ExecQuery(
        bstr_t("WQL"), 
        bstr_t("SELECT * FROM Win32_PCMCIAController"),
        WBEM_FLAG_FORWARD_ONLY | WBEM_FLAG_RETURN_IMMEDIATELY, 
        NULL,
        &pEnumerator);
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();
        CoUninitialize();
        return;						// Program has failed.
    }
    pclsObj=0;
    ULONG uReturn = 0;
    while (pEnumerator)
    {	HRESULT hr = pEnumerator->Next(WBEM_INFINITE, 1, &pclsObj, &uReturn);
		//if(0 == uReturn)
		//  break;

		GetDatetime(L"TimeOfLastReset");
		GetStr(L"SystemName");
		GetStr(L"SystemCreationClassName");
		GetDec(L"StatusInfo");
		GetStr(L"Status");
		GetDec(L"ProtocolSupported");
		GetBool(L"PowerManagementSupported");
		GetDecArray(L"PowerManagementCapabilities");
		GetStr(L"PNPDeviceID");
		GetStr(L"Name");
		GetDec(L"MaxNumberControlled");
		GetStr(L"Manufacturer");
		GetDec(L"LastErrorCode");
		GetDatetime(L"InstallDate");
		GetStr(L"ErrorDescription");
		GetBool(L"ErrorCleared");
		GetStr(L"DeviceID");
		GetStr(L"Description");
		GetStr(L"CreationClassName");
		GetBool(L"ConfigManagerUserConfig");
		GetConfigManagerErrorCode(L"ConfigManagerErrorCode");
		GetStr(L"Caption");
		GetCacheMemoryAvailability(L"Availability");

		item.pszText = L"";
		item.iSubItem = 0;
		SendMessage(hWndTree, LVM_INSERTITEM, (WPARAM)0, (LPARAM)&item);

		if(0 == uReturn)
		  break;
	}
    if(pSvc)pSvc->Release();
    if(pLoc)pLoc->Release();
    if(pEnumerator)pEnumerator->Release();
    if(pclsObj)pclsObj->Release();
    CoUninitialize();
}

VOID GetPhysMemFormFactor(wchar_t *prop)
{	wchar_t s[64];
	item.pszText = prop;
	item.iSubItem = 0;
	SendMessage(hWndTree, LVM_INSERTITEM, (WPARAM)0, (LPARAM)&item);
	item.iSubItem = 1;
	item.pszText = s;
	if(pclsObj)
	if(S_OK==pclsObj->Get(prop, 0, &vtProp, 0, 0))
	{	if(VT_NULL!=vtProp.vt)
		{	switch((int)vtProp.bstrVal)
			{	case 0:
					wsprintf(s,L"0: Unknown");
				break;
				case 1:
					wsprintf(s,L"1: Other");
				break;
				case 2:
					wsprintf(s,L"2: SIP");
				break;
				case 3:
					wsprintf(s,L"3: DIP");
				break;
				case 4:
					wsprintf(s,L"4: ZIP");
				break;
				case 5:
					wsprintf(s,L"5: SOJ");
				break;
				case 6:
					wsprintf(s,L"6: Proprietary");
				break;
				case 7:
					wsprintf(s,L"7: SIMM");
				break;
				case 8:
					wsprintf(s,L"8: DIMM");
				break;
				case 9:
					wsprintf(s,L"9: TSOP");
				break;
				case 10:
					wsprintf(s,L"10: PGA");
				break;
				case 11:
					wsprintf(s,L"11: RIMM");
				break;
				case 12:
					wsprintf(s,L"12: SODIMM");
				break;
				case 13:
					wsprintf(s,L"13: SRIMM");
				break;
				case 14:
					wsprintf(s,L"14: SMD");
				break;
				case 15:
					wsprintf(s,L"15: SSMP");
				break;
				case 16:
					wsprintf(s,L"16: QFP");
				break;
				case 17:
					wsprintf(s,L"17: TQFP");
				break;
				case 18:
					wsprintf(s,L"18: SOIC");
				break;
				case 19:
					wsprintf(s,L"19: LCC");
				break;
				case 20:
					wsprintf(s,L"20: PLCC");
				break;
				case 21:
					wsprintf(s,L"21: BGA");
				break;
				case 22:
					wsprintf(s,L"22: FPBGA");
				break;
				case 23:
					wsprintf(s,L"23: LGA");
				break;
				default:
					wsprintf(s,L"");
				break;
			}
			SendMessage(hWndTree, LVM_SETITEMTEXT, (WPARAM)0, (LPARAM)&item);
			VariantClear(&vtProp);
			return;
	}	}
	wsprintf(s,L"Dec. value, not defined ...");
	SendMessage(hWndTree, LVM_SETITEMTEXT, (WPARAM)0, (LPARAM)&item);
}

VOID GetPhysMemType(wchar_t *prop)
{	wchar_t s[64];
	item.pszText = prop;
	item.iSubItem = 0;
	SendMessage(hWndTree, LVM_INSERTITEM, (WPARAM)0, (LPARAM)&item);
	item.iSubItem = 1;
	item.pszText = s;
	if(pclsObj)
	if(S_OK==pclsObj->Get(prop, 0, &vtProp, 0, 0))
	{	if(VT_NULL!=vtProp.vt)
		{	switch((int)vtProp.bstrVal)
			{	case 0:
					wsprintf(s,L"0: Unknown");
				break;
				case 1:
					wsprintf(s,L"1: Other");
				break;
				case 2:
					wsprintf(s,L"2: DRAM");
				break;
				case 3:
					wsprintf(s,L"3: Synchronous DRAM");
				break;
				case 4:
					wsprintf(s,L"4: Cache DRAM");
				break;
				case 5:
					wsprintf(s,L"5: EDO");
				break;
				case 6:
					wsprintf(s,L"6: EDRAM");
				break;
				case 7:
					wsprintf(s,L"7: VRAM");
				break;
				case 8:
					wsprintf(s,L"8: SRAM");
				break;
				case 9:
					wsprintf(s,L"9: RAM");
				break;
				case 10:
					wsprintf(s,L"10: ROM");
				break;
				case 11:
					wsprintf(s,L"11: Flash");
				break;
				case 12:
					wsprintf(s,L"12: EEPROM");
				break;
				case 13:
					wsprintf(s,L"13: FEPROM");
				break;
				case 14:
					wsprintf(s,L"14: EPROM");
				break;
				case 15:
					wsprintf(s,L"15: CDRAM");
				break;
				case 16:
					wsprintf(s,L"16: 3DRAM");
				break;
				case 17:
					wsprintf(s,L"17: SDRAM");
				break;
				case 18:
					wsprintf(s,L"18: SGRAM");
				break;
				case 19:
					wsprintf(s,L"19: RDRAM");
				break;
				case 20:
					wsprintf(s,L"20: DDR");
				break;
				case 21:
					wsprintf(s,L"21: DDR-2");
				break;
				case 22:
					wsprintf(s,L"22: DDR-3");
				break;
				default:
					wsprintf(s,L"");
				break;
			}
			SendMessage(hWndTree, LVM_SETITEMTEXT, (WPARAM)0, (LPARAM)&item);
			VariantClear(&vtProp);
			return;
	}	}
	wsprintf(s,L"Dec. value, not defined ...");
	SendMessage(hWndTree, LVM_SETITEMTEXT, (WPARAM)0, (LPARAM)&item);
}

VOID GetPhysMemTypeDetail(wchar_t *prop)
{	wchar_t s[64];
	item.pszText = prop;
	item.iSubItem = 0;
	SendMessage(hWndTree, LVM_INSERTITEM, (WPARAM)0, (LPARAM)&item);
	item.iSubItem = 1;
	item.pszText = s;
	if(pclsObj)
	if(S_OK==pclsObj->Get(prop, 0, &vtProp, 0, 0))
	{	if(VT_NULL!=vtProp.vt)
		{	switch((int)vtProp.bstrVal)
			{	case 1:
					wsprintf(s,L"1: Reserved");
				break;
				case 2:
					wsprintf(s,L"2: Other");
				break;
				case 3:
					wsprintf(s,L"3: Unknown");
				break;
				case 4:
					wsprintf(s,L"4: Fast-paged");
				break;
				case 5:
					wsprintf(s,L"5: Static column");
				break;
				case 6:
					wsprintf(s,L"6: Pseudo-static");
				break;
				case 7:
					wsprintf(s,L"7: RAMBUS");
				break;
				case 8:
					wsprintf(s,L"8: Synchronous");
				break;
				case 9:
					wsprintf(s,L"9: CMOS");
				break;
				case 10:
					wsprintf(s,L"10: EDO");
				break;
				case 11:
					wsprintf(s,L"11: Window DRAM");
				break;
				case 12:
					wsprintf(s,L"12: Cache DRAM");
				break;
				case 13:
					wsprintf(s,L"13: Nonvolatile");
				break;
				default:
					wsprintf(s,L"");
				break;
			}
			SendMessage(hWndTree, LVM_SETITEMTEXT, (WPARAM)0, (LPARAM)&item);
			VariantClear(&vtProp);
			return;
	}	}
	wsprintf(s,L"Dec. value, not defined ...");
	SendMessage(hWndTree, LVM_SETITEMTEXT, (WPARAM)0, (LPARAM)&item);
}

VOID WMI_Motherboard_Classes_Win32_PhysicalMemory()
{   HRESULT hres;
    hres =  CoInitializeEx(0, COINIT_MULTITHREADED); 
    if(FAILED(hres))
        return;
    hres =  CoInitializeSecurity(
        NULL, 
        -1,                          // COM authentication
        NULL,                        // Authentication services
        NULL,                        // Reserved
        RPC_C_AUTHN_LEVEL_DEFAULT,   // Default authentication 
        RPC_C_IMP_LEVEL_IMPERSONATE, // Default Impersonation  
        NULL,                        // Authentication info
        EOAC_NONE,                   // Additional capabilities 
        NULL                         // Reserved
        );
    if (FAILED(hres))
    {	CoUninitialize();
        return;                      // Program has failed.
    }
    IWbemLocator *pLoc = NULL;
    hres = CoCreateInstance(
        CLSID_WbemLocator,             
        0, 
        CLSCTX_INPROC_SERVER, 
        IID_IWbemLocator, (LPVOID *) &pLoc);
    if (FAILED(hres))
    {   CoUninitialize();
        return;						// Program has failed.
    }
    IWbemServices *pSvc = NULL;
    hres = pLoc->ConnectServer(
         _bstr_t(L"ROOT\\CIMV2"), // Object path of WMI namespace
         NULL,                    // User name. NULL = current user
         NULL,                    // User password. NULL = current
         0,                       // Locale. NULL indicates current
         NULL,                    // Security flags.
         0,                       // Authority (e.g. Kerberos)
         0,                       // Context object 
         &pSvc                    // pointer to IWbemServices proxy
         );
    
    if (FAILED(hres))
    {   pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    hres = CoSetProxyBlanket(
       pSvc,                        // Indicates the proxy to set
       RPC_C_AUTHN_WINNT,           // RPC_C_AUTHN_xxx
       RPC_C_AUTHZ_NONE,            // RPC_C_AUTHZ_xxx
       NULL,                        // Server principal name 
       RPC_C_AUTHN_LEVEL_CALL,      // RPC_C_AUTHN_LEVEL_xxx 
       RPC_C_IMP_LEVEL_IMPERSONATE, // RPC_C_IMP_LEVEL_xxx
       NULL,                        // client identity
       EOAC_NONE                    // proxy capabilities 
    );
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    IEnumWbemClassObject* pEnumerator = NULL;
    hres = pSvc->ExecQuery(
        bstr_t("WQL"), 
        bstr_t("SELECT * FROM Win32_PhysicalMemory"),
        WBEM_FLAG_FORWARD_ONLY | WBEM_FLAG_RETURN_IMMEDIATELY, 
        NULL,
        &pEnumerator);
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();
        CoUninitialize();
        return;						// Program has failed.
    }
    pclsObj=0;
    ULONG uReturn = 0;
    while (pEnumerator)
    {	HRESULT hr = pEnumerator->Next(WBEM_INFINITE, 1, &pclsObj, &uReturn);
		//if(0 == uReturn)
		//  break;

		GetStr(L"Version");
		GetPhysMemTypeDetail(L"TypeDetail");
		GetDecArg1(L"TotalWidth",L"bits");
		GetStr(L"Tag");
		GetStr(L"Status");
		GetDecArg1(L"Speed",L"nanoseconds");
		GetStr(L"SKU");
		GetStr(L"SerialNumber");
		GetBool(L"Replaceable");
		GetBool(L"Removable");
		GetBool(L"PoweredOn");
		GetDec(L"PositionInRow");
		GetStr(L"PartNumber");
		GetStr(L"OtherIdentifyingInfo");
		GetStr(L"Name");
		GetStr(L"Model");
		GetPhysMemType(L"MemoryType");
		GetStr(L"Manufacturer");
		GetDec(L"InterleavePosition");
		GetDec(L"InterleaveDataDepth");
		GetDatetime(L"InstallDate");
		GetBool(L"HotSwappable");
		GetPhysMemFormFactor(L"FormFactor");
		GetStr(L"DeviceLocator");
		GetStr(L"Description");
		GetDecArg1(L"DataWidth",L"bits");
		GetStr(L"CreationClassName");
		GetStr(L"Caption");
		GetDec(L"Capacity");
		GetStr(L"BankLabel");

		item.pszText = L"";
		item.iSubItem = 0;
		SendMessage(hWndTree, LVM_INSERTITEM, (WPARAM)0, (LPARAM)&item);

		if(0 == uReturn)
		  break;
	}
    if(pSvc)pSvc->Release();
    if(pLoc)pLoc->Release();
    if(pEnumerator)pEnumerator->Release();
    if(pclsObj)pclsObj->Release();
    CoUninitialize();
}

VOID GetPhysMemArrLocation(wchar_t *prop)
{	wchar_t s[64];
	item.pszText = prop;
	item.iSubItem = 0;
	SendMessage(hWndTree, LVM_INSERTITEM, (WPARAM)0, (LPARAM)&item);
	item.iSubItem = 1;
	item.pszText = s;
	if(pclsObj)
	if(S_OK==pclsObj->Get(prop, 0, &vtProp, 0, 0))
	{	if(VT_NULL!=vtProp.vt)
		{	switch((int)vtProp.bstrVal)
			{	case 0:
					wsprintf(s,L"0: Reserved");
				break;
				case 1:
					wsprintf(s,L"1: Other");
				break;
				case 2:
					wsprintf(s,L"2: Unknown");
				break;
				case 3:
					wsprintf(s,L"3: System board or motherboard");
				break;
				case 4:
					wsprintf(s,L"4: ISA add-on card");
				break;
				case 5:
					wsprintf(s,L"5: EISA add-on card");
				break;
				case 6:
					wsprintf(s,L"6: PCI add-on card");
				break;
				case 7:
					wsprintf(s,L"7: MCA add-on card");
				break;
				case 8:
					wsprintf(s,L"8: PCMCIA add-on card");
				break;
				case 9:
					wsprintf(s,L"9: Proprietary add-on card");
				break;
				case 10:
					wsprintf(s,L"10: NuBus");
				break;
				case 11:
					wsprintf(s,L"11: PC-98/C20 add-on card");
				break;
				case 12:
					wsprintf(s,L"12: PC-98/C24 add-on card");
				break;
				case 13:
					wsprintf(s,L"13: PC-98/E add-on card");
				break;
				case 14:
					wsprintf(s,L"14: PC-98/Local bus add-on card");
				break;
				default:
					wsprintf(s,L"");
				break;
			}
			SendMessage(hWndTree, LVM_SETITEMTEXT, (WPARAM)0, (LPARAM)&item);
			VariantClear(&vtProp);
			return;
	}	}
	wsprintf(s,L"Dec. value, not defined ...");
	SendMessage(hWndTree, LVM_SETITEMTEXT, (WPARAM)0, (LPARAM)&item);
}

VOID GetPhysMemArrErrCorr(wchar_t *prop)
{	wchar_t s[64];
	item.pszText = prop;
	item.iSubItem = 0;
	SendMessage(hWndTree, LVM_INSERTITEM, (WPARAM)0, (LPARAM)&item);
	item.iSubItem = 1;
	item.pszText = s;
	if(pclsObj)
	if(S_OK==pclsObj->Get(prop, 0, &vtProp, 0, 0))
	{	if(VT_NULL!=vtProp.vt)
		{	switch((int)vtProp.bstrVal)
			{	case 0:
					wsprintf(s,L"0: Reserved");
				break;
				case 1:
					wsprintf(s,L"1: Other");
				break;
				case 2:
					wsprintf(s,L"2: Unknown");
				break;
				case 3:
					wsprintf(s,L"3: None");
				break;
				case 4:
					wsprintf(s,L"4: Parity");
				break;
				case 5:
					wsprintf(s,L"5: Single-bit ECC");
				break;
				case 6:
					wsprintf(s,L"6: Multi-bit ECC");
				break;
				case 7:
					wsprintf(s,L"7: CRC");
				break;
				default:
					wsprintf(s,L"");
				break;
			}
			SendMessage(hWndTree, LVM_SETITEMTEXT, (WPARAM)0, (LPARAM)&item);
			VariantClear(&vtProp);
			return;
	}	}
	wsprintf(s,L"Dec. value, not defined ...");
	SendMessage(hWndTree, LVM_SETITEMTEXT, (WPARAM)0, (LPARAM)&item);
}

VOID GetPhysMemArrUse(wchar_t *prop)
{	wchar_t s[64];
	item.pszText = prop;
	item.iSubItem = 0;
	SendMessage(hWndTree, LVM_INSERTITEM, (WPARAM)0, (LPARAM)&item);
	item.iSubItem = 1;
	item.pszText = s;
	if(pclsObj)
	if(S_OK==pclsObj->Get(prop, 0, &vtProp, 0, 0))
	{	if(VT_NULL!=vtProp.vt)
		{	switch((int)vtProp.bstrVal)
			{	case 0:
					wsprintf(s,L"0: Reserved");
				break;
				case 1:
					wsprintf(s,L"1: Other");
				break;
				case 2:
					wsprintf(s,L"2: Unknown");
				break;
				case 3:
					wsprintf(s,L"3: System memory");
				break;
				case 4:
					wsprintf(s,L"4: Video memory");
				break;
				case 5:
					wsprintf(s,L"5: Flash memory");
				break;
				case 6:
					wsprintf(s,L"6: Nonvolatile RAM");
				break;
				case 7:
					wsprintf(s,L"7: Cache memory");
				break;
				default:
					wsprintf(s,L"");
				break;
			}
			SendMessage(hWndTree, LVM_SETITEMTEXT, (WPARAM)0, (LPARAM)&item);
			VariantClear(&vtProp);
			return;
	}	}
	wsprintf(s,L"Dec. value, not defined ...");
	SendMessage(hWndTree, LVM_SETITEMTEXT, (WPARAM)0, (LPARAM)&item);
}

VOID WMI_Motherboard_Classes_Win32_PhysicalMemoryArray()
{   HRESULT hres;
    hres =  CoInitializeEx(0, COINIT_MULTITHREADED); 
    if(FAILED(hres))
        return;
    hres =  CoInitializeSecurity(
        NULL, 
        -1,                          // COM authentication
        NULL,                        // Authentication services
        NULL,                        // Reserved
        RPC_C_AUTHN_LEVEL_DEFAULT,   // Default authentication 
        RPC_C_IMP_LEVEL_IMPERSONATE, // Default Impersonation  
        NULL,                        // Authentication info
        EOAC_NONE,                   // Additional capabilities 
        NULL                         // Reserved
        );
    if (FAILED(hres))
    {	CoUninitialize();
        return;                      // Program has failed.
    }
    IWbemLocator *pLoc = NULL;
    hres = CoCreateInstance(
        CLSID_WbemLocator,             
        0, 
        CLSCTX_INPROC_SERVER, 
        IID_IWbemLocator, (LPVOID *) &pLoc);
    if (FAILED(hres))
    {   CoUninitialize();
        return;						// Program has failed.
    }
    IWbemServices *pSvc = NULL;
    hres = pLoc->ConnectServer(
         _bstr_t(L"ROOT\\CIMV2"), // Object path of WMI namespace
         NULL,                    // User name. NULL = current user
         NULL,                    // User password. NULL = current
         0,                       // Locale. NULL indicates current
         NULL,                    // Security flags.
         0,                       // Authority (e.g. Kerberos)
         0,                       // Context object 
         &pSvc                    // pointer to IWbemServices proxy
         );
    
    if (FAILED(hres))
    {   pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    hres = CoSetProxyBlanket(
       pSvc,                        // Indicates the proxy to set
       RPC_C_AUTHN_WINNT,           // RPC_C_AUTHN_xxx
       RPC_C_AUTHZ_NONE,            // RPC_C_AUTHZ_xxx
       NULL,                        // Server principal name 
       RPC_C_AUTHN_LEVEL_CALL,      // RPC_C_AUTHN_LEVEL_xxx 
       RPC_C_IMP_LEVEL_IMPERSONATE, // RPC_C_IMP_LEVEL_xxx
       NULL,                        // client identity
       EOAC_NONE                    // proxy capabilities 
    );
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    IEnumWbemClassObject* pEnumerator = NULL;
    hres = pSvc->ExecQuery(
        bstr_t("WQL"), 
        bstr_t("SELECT * FROM Win32_PhysicalMemoryArray"),
        WBEM_FLAG_FORWARD_ONLY | WBEM_FLAG_RETURN_IMMEDIATELY, 
        NULL,
        &pEnumerator);
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();
        CoUninitialize();
        return;						// Program has failed.
    }
    pclsObj=0;
    ULONG uReturn = 0;
    while (pEnumerator)
    {	HRESULT hr = pEnumerator->Next(WBEM_INFINITE, 1, &pclsObj, &uReturn);
		//if(0 == uReturn)
		//  break;

		GetReal(L"Width");
		GetReal(L"Weight");
		GetStr(L"Version");
		GetPhysMemArrUse(L"Use");
		GetStr(L"Tag");
		GetStr(L"Status");
		GetStr(L"SKU");
		GetStr(L"SerialNumber");
		GetBool(L"Replaceable");
		GetBool(L"Removable");
		GetBool(L"PoweredOn");
		GetStr(L"PartNumber");
		GetStr(L"OtherIdentifyingInfo");
		GetStr(L"Name");
		GetStr(L"Model");
		GetPhysMemArrErrCorr(L"MemoryErrorCorrection");
		GetDecArg1(L"MemoryDevices",L"slots or sockets");
		GetDecArg1(L"MaxCapacity",L"bytes");
		GetStr(L"Manufacturer");
		GetPhysMemArrLocation(L"Location");
		GetDatetime(L"InstallDate");
		GetBool(L"HotSwappable");
		GetReal(L"Height");
		GetStr(L"Description");
		GetReal(L"Depth");
		GetStr(L"CreationClassName");
		GetStr(L"Caption");

		item.pszText = L"";
		item.iSubItem = 0;
		SendMessage(hWndTree, LVM_INSERTITEM, (WPARAM)0, (LPARAM)&item);

		if(0 == uReturn)
		  break;
	}
    if(pSvc)pSvc->Release();
    if(pLoc)pLoc->Release();
    if(pEnumerator)pEnumerator->Release();
    if(pclsObj)pclsObj->Release();
    CoUninitialize();
}

VOID WMI_Motherboard_Classes_Win32_PhysicalMemoryLocation()
{   HRESULT hres;
    hres =  CoInitializeEx(0, COINIT_MULTITHREADED); 
    if(FAILED(hres))
        return;
    hres =  CoInitializeSecurity(
        NULL, 
        -1,                          // COM authentication
        NULL,                        // Authentication services
        NULL,                        // Reserved
        RPC_C_AUTHN_LEVEL_DEFAULT,   // Default authentication 
        RPC_C_IMP_LEVEL_IMPERSONATE, // Default Impersonation  
        NULL,                        // Authentication info
        EOAC_NONE,                   // Additional capabilities 
        NULL                         // Reserved
        );
    if (FAILED(hres))
    {	CoUninitialize();
        return;                      // Program has failed.
    }
    IWbemLocator *pLoc = NULL;
    hres = CoCreateInstance(
        CLSID_WbemLocator,             
        0, 
        CLSCTX_INPROC_SERVER, 
        IID_IWbemLocator, (LPVOID *) &pLoc);
    if (FAILED(hres))
    {   CoUninitialize();
        return;						// Program has failed.
    }
    IWbemServices *pSvc = NULL;
    hres = pLoc->ConnectServer(
         _bstr_t(L"ROOT\\CIMV2"), // Object path of WMI namespace
         NULL,                    // User name. NULL = current user
         NULL,                    // User password. NULL = current
         0,                       // Locale. NULL indicates current
         NULL,                    // Security flags.
         0,                       // Authority (e.g. Kerberos)
         0,                       // Context object 
         &pSvc                    // pointer to IWbemServices proxy
         );
    
    if (FAILED(hres))
    {   pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    hres = CoSetProxyBlanket(
       pSvc,                        // Indicates the proxy to set
       RPC_C_AUTHN_WINNT,           // RPC_C_AUTHN_xxx
       RPC_C_AUTHZ_NONE,            // RPC_C_AUTHZ_xxx
       NULL,                        // Server principal name 
       RPC_C_AUTHN_LEVEL_CALL,      // RPC_C_AUTHN_LEVEL_xxx 
       RPC_C_IMP_LEVEL_IMPERSONATE, // RPC_C_IMP_LEVEL_xxx
       NULL,                        // client identity
       EOAC_NONE                    // proxy capabilities 
    );
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    IEnumWbemClassObject* pEnumerator = NULL;
    hres = pSvc->ExecQuery(
        bstr_t("WQL"), 
        bstr_t("SELECT * FROM Win32_PhysicalMemoryLocation"),
        WBEM_FLAG_FORWARD_ONLY | WBEM_FLAG_RETURN_IMMEDIATELY, 
        NULL,
        &pEnumerator);
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();
        CoUninitialize();
        return;						// Program has failed.
    }
    pclsObj=0;
    ULONG uReturn = 0;
    while (pEnumerator)
    {	HRESULT hr = pEnumerator->Next(WBEM_INFINITE, 1, &pclsObj, &uReturn);
		//if(0 == uReturn)
		//  break;

		GetStr(L"GroupComponent");//Win32_PhysicalMemoryArray ref GroupComponent;
		GetStr(L"LocationWithinContainer");
		GetStr(L"PartComponent");//Win32_PhysicalMemory ref PartComponent;

		item.pszText = L"";
		item.iSubItem = 0;
		SendMessage(hWndTree, LVM_INSERTITEM, (WPARAM)0, (LPARAM)&item);

		if(0 == uReturn)
		  break;
	}
    if(pSvc)pSvc->Release();
    if(pLoc)pLoc->Release();
    if(pEnumerator)pEnumerator->Release();
    if(pclsObj)pclsObj->Release();
    CoUninitialize();
}

VOID WMI_Motherboard_Classes_Win32_PnPAllocatedResource()
{   HRESULT hres;
    hres =  CoInitializeEx(0, COINIT_MULTITHREADED); 
    if(FAILED(hres))
        return;
    hres =  CoInitializeSecurity(
        NULL, 
        -1,                          // COM authentication
        NULL,                        // Authentication services
        NULL,                        // Reserved
        RPC_C_AUTHN_LEVEL_DEFAULT,   // Default authentication 
        RPC_C_IMP_LEVEL_IMPERSONATE, // Default Impersonation  
        NULL,                        // Authentication info
        EOAC_NONE,                   // Additional capabilities 
        NULL                         // Reserved
        );
    if (FAILED(hres))
    {	CoUninitialize();
        return;                      // Program has failed.
    }
    IWbemLocator *pLoc = NULL;
    hres = CoCreateInstance(
        CLSID_WbemLocator,             
        0, 
        CLSCTX_INPROC_SERVER, 
        IID_IWbemLocator, (LPVOID *) &pLoc);
    if (FAILED(hres))
    {   CoUninitialize();
        return;						// Program has failed.
    }
    IWbemServices *pSvc = NULL;
    hres = pLoc->ConnectServer(
         _bstr_t(L"ROOT\\CIMV2"), // Object path of WMI namespace
         NULL,                    // User name. NULL = current user
         NULL,                    // User password. NULL = current
         0,                       // Locale. NULL indicates current
         NULL,                    // Security flags.
         0,                       // Authority (e.g. Kerberos)
         0,                       // Context object 
         &pSvc                    // pointer to IWbemServices proxy
         );
    
    if (FAILED(hres))
    {   pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    hres = CoSetProxyBlanket(
       pSvc,                        // Indicates the proxy to set
       RPC_C_AUTHN_WINNT,           // RPC_C_AUTHN_xxx
       RPC_C_AUTHZ_NONE,            // RPC_C_AUTHZ_xxx
       NULL,                        // Server principal name 
       RPC_C_AUTHN_LEVEL_CALL,      // RPC_C_AUTHN_LEVEL_xxx 
       RPC_C_IMP_LEVEL_IMPERSONATE, // RPC_C_IMP_LEVEL_xxx
       NULL,                        // client identity
       EOAC_NONE                    // proxy capabilities 
    );
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    IEnumWbemClassObject* pEnumerator = NULL;
    hres = pSvc->ExecQuery(
        bstr_t("WQL"), 
        bstr_t("SELECT * FROM Win32_PnPAllocatedResource"),
        WBEM_FLAG_FORWARD_ONLY | WBEM_FLAG_RETURN_IMMEDIATELY, 
        NULL,
        &pEnumerator);
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();
        CoUninitialize();
        return;						// Program has failed.
    }
    pclsObj=0;
    ULONG uReturn = 0;
    while (pEnumerator)
    {	HRESULT hr = pEnumerator->Next(WBEM_INFINITE, 1, &pclsObj, &uReturn);
		//if(0 == uReturn)
		//  break;

		GetStr(L"Antecedent");//CIM_SystemResource ref Antecedent;
		GetStr(L"Dependent");//Win32_PnPEntity ref Dependent;

		item.pszText = L"";
		item.iSubItem = 0;
		SendMessage(hWndTree, LVM_INSERTITEM, (WPARAM)0, (LPARAM)&item);

		if(0 == uReturn)
		  break;
	}
    if(pSvc)pSvc->Release();
    if(pLoc)pLoc->Release();
    if(pEnumerator)pEnumerator->Release();
    if(pclsObj)pclsObj->Release();
    CoUninitialize();
}

VOID WMI_Motherboard_Classes_Win32_PnPDevice()
{   HRESULT hres;
    hres =  CoInitializeEx(0, COINIT_MULTITHREADED); 
    if(FAILED(hres))
        return;
    hres =  CoInitializeSecurity(
        NULL, 
        -1,                          // COM authentication
        NULL,                        // Authentication services
        NULL,                        // Reserved
        RPC_C_AUTHN_LEVEL_DEFAULT,   // Default authentication 
        RPC_C_IMP_LEVEL_IMPERSONATE, // Default Impersonation  
        NULL,                        // Authentication info
        EOAC_NONE,                   // Additional capabilities 
        NULL                         // Reserved
        );
    if (FAILED(hres))
    {	CoUninitialize();
        return;                      // Program has failed.
    }
    IWbemLocator *pLoc = NULL;
    hres = CoCreateInstance(
        CLSID_WbemLocator,             
        0, 
        CLSCTX_INPROC_SERVER, 
        IID_IWbemLocator, (LPVOID *) &pLoc);
    if (FAILED(hres))
    {   CoUninitialize();
        return;						// Program has failed.
    }
    IWbemServices *pSvc = NULL;
    hres = pLoc->ConnectServer(
         _bstr_t(L"ROOT\\CIMV2"), // Object path of WMI namespace
         NULL,                    // User name. NULL = current user
         NULL,                    // User password. NULL = current
         0,                       // Locale. NULL indicates current
         NULL,                    // Security flags.
         0,                       // Authority (e.g. Kerberos)
         0,                       // Context object 
         &pSvc                    // pointer to IWbemServices proxy
         );
    
    if (FAILED(hres))
    {   pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    hres = CoSetProxyBlanket(
       pSvc,                        // Indicates the proxy to set
       RPC_C_AUTHN_WINNT,           // RPC_C_AUTHN_xxx
       RPC_C_AUTHZ_NONE,            // RPC_C_AUTHZ_xxx
       NULL,                        // Server principal name 
       RPC_C_AUTHN_LEVEL_CALL,      // RPC_C_AUTHN_LEVEL_xxx 
       RPC_C_IMP_LEVEL_IMPERSONATE, // RPC_C_IMP_LEVEL_xxx
       NULL,                        // client identity
       EOAC_NONE                    // proxy capabilities 
    );
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    IEnumWbemClassObject* pEnumerator = NULL;
    hres = pSvc->ExecQuery(
        bstr_t("WQL"), 
        bstr_t("SELECT * FROM Win32_PnPDevice"),
        WBEM_FLAG_FORWARD_ONLY | WBEM_FLAG_RETURN_IMMEDIATELY, 
        NULL,
        &pEnumerator);
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();
        CoUninitialize();
        return;						// Program has failed.
    }
    pclsObj=0;
    ULONG uReturn = 0;
    while (pEnumerator)
    {	HRESULT hr = pEnumerator->Next(WBEM_INFINITE, 1, &pclsObj, &uReturn);
		//if(0 == uReturn)
		//  break;

		GetStr(L"SameElement");//CIM_LogicalDevice ref SameElement;
		GetStr(L"SystemElement");//Win32_PnPEntity ref SystemElement;

		item.pszText = L"";
		item.iSubItem = 0;
		SendMessage(hWndTree, LVM_INSERTITEM, (WPARAM)0, (LPARAM)&item);

		if(0 == uReturn)
		  break;
	}
    if(pSvc)pSvc->Release();
    if(pLoc)pLoc->Release();
    if(pEnumerator)pEnumerator->Release();
    if(pclsObj)pclsObj->Release();
    CoUninitialize();
}

VOID WMI_Motherboard_Classes_Win32_PnPEntity()
{   HRESULT hres;
    hres =  CoInitializeEx(0, COINIT_MULTITHREADED); 
    if(FAILED(hres))
        return;
    hres =  CoInitializeSecurity(
        NULL, 
        -1,                          // COM authentication
        NULL,                        // Authentication services
        NULL,                        // Reserved
        RPC_C_AUTHN_LEVEL_DEFAULT,   // Default authentication 
        RPC_C_IMP_LEVEL_IMPERSONATE, // Default Impersonation  
        NULL,                        // Authentication info
        EOAC_NONE,                   // Additional capabilities 
        NULL                         // Reserved
        );
    if (FAILED(hres))
    {	CoUninitialize();
        return;                      // Program has failed.
    }
    IWbemLocator *pLoc = NULL;
    hres = CoCreateInstance(
        CLSID_WbemLocator,             
        0, 
        CLSCTX_INPROC_SERVER, 
        IID_IWbemLocator, (LPVOID *) &pLoc);
    if (FAILED(hres))
    {   CoUninitialize();
        return;						// Program has failed.
    }
    IWbemServices *pSvc = NULL;
    hres = pLoc->ConnectServer(
         _bstr_t(L"ROOT\\CIMV2"), // Object path of WMI namespace
         NULL,                    // User name. NULL = current user
         NULL,                    // User password. NULL = current
         0,                       // Locale. NULL indicates current
         NULL,                    // Security flags.
         0,                       // Authority (e.g. Kerberos)
         0,                       // Context object 
         &pSvc                    // pointer to IWbemServices proxy
         );
    
    if (FAILED(hres))
    {   pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    hres = CoSetProxyBlanket(
       pSvc,                        // Indicates the proxy to set
       RPC_C_AUTHN_WINNT,           // RPC_C_AUTHN_xxx
       RPC_C_AUTHZ_NONE,            // RPC_C_AUTHZ_xxx
       NULL,                        // Server principal name 
       RPC_C_AUTHN_LEVEL_CALL,      // RPC_C_AUTHN_LEVEL_xxx 
       RPC_C_IMP_LEVEL_IMPERSONATE, // RPC_C_IMP_LEVEL_xxx
       NULL,                        // client identity
       EOAC_NONE                    // proxy capabilities 
    );
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    IEnumWbemClassObject* pEnumerator = NULL;
    hres = pSvc->ExecQuery(
        bstr_t("WQL"), 
        bstr_t("SELECT * FROM Win32_PnPEntity"),
        WBEM_FLAG_FORWARD_ONLY | WBEM_FLAG_RETURN_IMMEDIATELY, 
        NULL,
        &pEnumerator);
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();
        CoUninitialize();
        return;						// Program has failed.
    }
    pclsObj=0;
    ULONG uReturn = 0;
    while (pEnumerator)
    {	HRESULT hr = pEnumerator->Next(WBEM_INFINITE, 1, &pclsObj, &uReturn);
		//if(0 == uReturn)
		//  break;

		GetStr(L"SystemName");
		GetStr(L"SystemCreationClassName");
		GetDec(L"StatusInfo");
		GetStr(L"Status");
		GetStr(L"Service");
		GetBool(L"PowerManagementSupported");
		GetDecArray(L"PowerManagementCapabilities");
		GetStr(L"PNPDeviceID");
		GetStr(L"Name");
		GetStr(L"Manufacturer");
		GetDec(L"LastErrorCode");
		GetDatetime(L"InstallDate");
		GetStrArray(L"HardwareID");
		GetStr(L"ErrorDescription");
		GetBool(L"ErrorCleared");
		GetStr(L"DeviceID");
		GetStr(L"Description");
		GetStr(L"CreationClassName");
		GetBool(L"ConfigManagerUserConfig");
		GetConfigManagerErrorCode(L"ConfigManagerErrorCode");
		GetStrArray(L"CompatibleID");
		GetStr(L"ClassGuid");
		GetStr(L"Caption");
		GetCacheMemoryAvailability(L"Availability");

		item.pszText = L"";
		item.iSubItem = 0;
		SendMessage(hWndTree, LVM_INSERTITEM, (WPARAM)0, (LPARAM)&item);

		if(0 == uReturn)
		  break;
	}
    if(pSvc)pSvc->Release();
    if(pLoc)pLoc->Release();
    if(pEnumerator)pEnumerator->Release();
    if(pclsObj)pclsObj->Release();
    CoUninitialize();
}

VOID GetPortType(wchar_t *prop)
{	wchar_t s[64];
	item.pszText = prop;
	item.iSubItem = 0;
	SendMessage(hWndTree, LVM_INSERTITEM, (WPARAM)0, (LPARAM)&item);
	item.iSubItem = 1;
	item.pszText = s;
	if(pclsObj)
	if(S_OK==pclsObj->Get(prop, 0, &vtProp, 0, 0))
	{	if(VT_NULL!=vtProp.vt)
		{	switch((int)vtProp.bstrVal)
			{	case 0:
					wsprintf(s,L"0: None");
				break;
				case 1:
					wsprintf(s,L"1: Parallel Port XT/AT Compatible");
				break;
				case 2:
					wsprintf(s,L"2: Parallel Port PS/2");
				break;
				case 3:
					wsprintf(s,L"3: Parallel Port ECP");
				break;
				case 4:
					wsprintf(s,L"4: Parallel Port EPP");
				break;
				case 5:
					wsprintf(s,L"5: Parallel Port ECP/EPP");
				break;
				case 6:
					wsprintf(s,L"6: Serial Port XT/AT Compatible");
				break;
				case 7:
					wsprintf(s,L"7: Serial Port 16450 Compatible");
				break;
				case 8:
					wsprintf(s,L"8: Serial Port 16550 Compatible");
				break;
				case 9:
					wsprintf(s,L"9: Serial Port 16550A Compatible");
				break;
				case 10:
					wsprintf(s,L"10: SCSI Port");
				break;
				case 11:
					wsprintf(s,L"11: MIDI Port");
				break;
				case 12:
					wsprintf(s,L"12: Joy Stick Port");
				break;
				case 13:
					wsprintf(s,L"13: Keyboard Port");
				break;
				case 14:
					wsprintf(s,L"14: Mouse Port");
				break;
				case 15:
					wsprintf(s,L"15: SSA SCSI");
				break;
				case 16:
					wsprintf(s,L"16: USB");
				break;
				case 17:
					wsprintf(s,L"17: FireWire (IEEE P1394)");
				break;
				case 18:
					wsprintf(s,L"18: PCMCIA Type II");
				break;
				case 19:
					wsprintf(s,L":19 PCMCIA Type II");
				break;
				case 20:
					wsprintf(s,L"20: PCMCIA Type III");
				break;
				case 21:
					wsprintf(s,L"21: CardBus");
				break;
				case 22:
					wsprintf(s,L"22: Access Bus Port");
				break;
				case 23:
					wsprintf(s,L"23: SCSI II");
				break;
				case 24:
					wsprintf(s,L"24: SCSI Wide");
				break;
				case 25:
					wsprintf(s,L"25: PC-98");
				break;
				case 26:
					wsprintf(s,L"26: PC-98-Hireso");
				break;
				case 27:
					wsprintf(s,L"27: PC-H98");
				break;
				case 28:
					wsprintf(s,L"28: Video Port");
				break;
				case 29:
					wsprintf(s,L"29: Audio Port");
				break;
				case 30:
					wsprintf(s,L"30: Modem Port");
				break;
				case 31:
					wsprintf(s,L"31: Network Port");
				break;
				case 32:
					wsprintf(s,L"32: 8251 Compatible");
				break;
				case 33:
					wsprintf(s,L"33: 8251 FIFO Compatible");
				break;
				default:
					wsprintf(s,L"");
				break;
			}
			SendMessage(hWndTree, LVM_SETITEMTEXT, (WPARAM)0, (LPARAM)&item);
			VariantClear(&vtProp);
			return;
	}	}
	wsprintf(s,L"Dec. value, not defined ...");
	SendMessage(hWndTree, LVM_SETITEMTEXT, (WPARAM)0, (LPARAM)&item);
}

VOID WMI_Motherboard_Classes_Win32_PortConnector()
{   HRESULT hres;
    hres =  CoInitializeEx(0, COINIT_MULTITHREADED); 
    if(FAILED(hres))
        return;
    hres =  CoInitializeSecurity(
        NULL, 
        -1,                          // COM authentication
        NULL,                        // Authentication services
        NULL,                        // Reserved
        RPC_C_AUTHN_LEVEL_DEFAULT,   // Default authentication 
        RPC_C_IMP_LEVEL_IMPERSONATE, // Default Impersonation  
        NULL,                        // Authentication info
        EOAC_NONE,                   // Additional capabilities 
        NULL                         // Reserved
        );
    if (FAILED(hres))
    {	CoUninitialize();
        return;                      // Program has failed.
    }
    IWbemLocator *pLoc = NULL;
    hres = CoCreateInstance(
        CLSID_WbemLocator,             
        0, 
        CLSCTX_INPROC_SERVER, 
        IID_IWbemLocator, (LPVOID *) &pLoc);
    if (FAILED(hres))
    {   CoUninitialize();
        return;						// Program has failed.
    }
    IWbemServices *pSvc = NULL;
    hres = pLoc->ConnectServer(
         _bstr_t(L"ROOT\\CIMV2"), // Object path of WMI namespace
         NULL,                    // User name. NULL = current user
         NULL,                    // User password. NULL = current
         0,                       // Locale. NULL indicates current
         NULL,                    // Security flags.
         0,                       // Authority (e.g. Kerberos)
         0,                       // Context object 
         &pSvc                    // pointer to IWbemServices proxy
         );
    
    if (FAILED(hres))
    {   pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    hres = CoSetProxyBlanket(
       pSvc,                        // Indicates the proxy to set
       RPC_C_AUTHN_WINNT,           // RPC_C_AUTHN_xxx
       RPC_C_AUTHZ_NONE,            // RPC_C_AUTHZ_xxx
       NULL,                        // Server principal name 
       RPC_C_AUTHN_LEVEL_CALL,      // RPC_C_AUTHN_LEVEL_xxx 
       RPC_C_IMP_LEVEL_IMPERSONATE, // RPC_C_IMP_LEVEL_xxx
       NULL,                        // client identity
       EOAC_NONE                    // proxy capabilities 
    );
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    IEnumWbemClassObject* pEnumerator = NULL;
    hres = pSvc->ExecQuery(
        bstr_t("WQL"), 
        bstr_t("SELECT * FROM Win32_PortConnector"),
        WBEM_FLAG_FORWARD_ONLY | WBEM_FLAG_RETURN_IMMEDIATELY, 
        NULL,
        &pEnumerator);
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();
        CoUninitialize();
        return;						// Program has failed.
    }
    pclsObj=0;
    ULONG uReturn = 0;
    while (pEnumerator)
    {	HRESULT hr = pEnumerator->Next(WBEM_INFINITE, 1, &pclsObj, &uReturn);
		//if(0 == uReturn)
		//  break;

		GetStr(L"Version");
		GetStr(L"Tag");
		GetStr(L"Status");
		GetStr(L"SKU");
		GetStr(L"SerialNumber");
		GetBool(L"PoweredOn");
		GetPortType(L"PortType");
		GetStr(L"PartNumber");
		GetStr(L"OtherIdentifyingInfo");
		GetStr(L"Name");
		GetStr(L"Model");
		GetStr(L"Manufacturer");
		GetStr(L"InternalReferenceDesignator");
		GetDatetime(L"InstallDate");
		GetStr(L"ExternalReferenceDesignator");
		GetStr(L"Description");
		GetStr(L"CreationClassName");
		GetDecArray(L"ConnectorType");
		GetStr(L"ConnectorPinout");
		GetStr(L"Caption");

		item.pszText = L"";
		item.iSubItem = 0;
		SendMessage(hWndTree, LVM_INSERTITEM, (WPARAM)0, (LPARAM)&item);

		if(0 == uReturn)
		  break;
	}
    if(pSvc)pSvc->Release();
    if(pLoc)pLoc->Release();
    if(pEnumerator)pEnumerator->Release();
    if(pclsObj)pclsObj->Release();
    CoUninitialize();
}

VOID WMI_Motherboard_Classes_Win32_PortResource()
{   HRESULT hres;
    hres =  CoInitializeEx(0, COINIT_MULTITHREADED); 
    if(FAILED(hres))
        return;
    hres =  CoInitializeSecurity(
        NULL, 
        -1,                          // COM authentication
        NULL,                        // Authentication services
        NULL,                        // Reserved
        RPC_C_AUTHN_LEVEL_DEFAULT,   // Default authentication 
        RPC_C_IMP_LEVEL_IMPERSONATE, // Default Impersonation  
        NULL,                        // Authentication info
        EOAC_NONE,                   // Additional capabilities 
        NULL                         // Reserved
        );
    if (FAILED(hres))
    {	CoUninitialize();
        return;                      // Program has failed.
    }
    IWbemLocator *pLoc = NULL;
    hres = CoCreateInstance(
        CLSID_WbemLocator,             
        0, 
        CLSCTX_INPROC_SERVER, 
        IID_IWbemLocator, (LPVOID *) &pLoc);
    if (FAILED(hres))
    {   CoUninitialize();
        return;						// Program has failed.
    }
    IWbemServices *pSvc = NULL;
    hres = pLoc->ConnectServer(
         _bstr_t(L"ROOT\\CIMV2"), // Object path of WMI namespace
         NULL,                    // User name. NULL = current user
         NULL,                    // User password. NULL = current
         0,                       // Locale. NULL indicates current
         NULL,                    // Security flags.
         0,                       // Authority (e.g. Kerberos)
         0,                       // Context object 
         &pSvc                    // pointer to IWbemServices proxy
         );
    
    if (FAILED(hres))
    {   pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    hres = CoSetProxyBlanket(
       pSvc,                        // Indicates the proxy to set
       RPC_C_AUTHN_WINNT,           // RPC_C_AUTHN_xxx
       RPC_C_AUTHZ_NONE,            // RPC_C_AUTHZ_xxx
       NULL,                        // Server principal name 
       RPC_C_AUTHN_LEVEL_CALL,      // RPC_C_AUTHN_LEVEL_xxx 
       RPC_C_IMP_LEVEL_IMPERSONATE, // RPC_C_IMP_LEVEL_xxx
       NULL,                        // client identity
       EOAC_NONE                    // proxy capabilities 
    );
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    IEnumWbemClassObject* pEnumerator = NULL;
    hres = pSvc->ExecQuery(
        bstr_t("WQL"), 
        bstr_t("SELECT * FROM Win32_PortResource"),
        WBEM_FLAG_FORWARD_ONLY | WBEM_FLAG_RETURN_IMMEDIATELY, 
        NULL,
        &pEnumerator);
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();
        CoUninitialize();
        return;						// Program has failed.
    }
    pclsObj=0;
    ULONG uReturn = 0;
    while (pEnumerator)
    {	HRESULT hr = pEnumerator->Next(WBEM_INFINITE, 1, &pclsObj, &uReturn);
		//if(0 == uReturn)
		//  break;

		GetStr(L"Status");
		GetDecX64(L"StartingAddress");
		GetStr(L"Name");
		GetDatetime(L"InstallDate");
		GetDecX64(L"EndingAddress");
		GetStr(L"Description");
		GetStr(L"CSName");
		GetStr(L"CSCreationClassName");
		GetStr(L"CreationClassName");
		GetStr(L"Caption");
		GetStr(L"Caption");
		GetBool(L"Alias");

		item.pszText = L"";
		item.iSubItem = 0;
		SendMessage(hWndTree, LVM_INSERTITEM, (WPARAM)0, (LPARAM)&item);

		if(0 == uReturn)
		  break;
	}
    if(pSvc)pSvc->Release();
    if(pLoc)pLoc->Release();
    if(pEnumerator)pEnumerator->Release();
    if(pclsObj)pclsObj->Release();
    CoUninitialize();
}

VOID GetCPUArhit(wchar_t *prop)
{	wchar_t s[64];
	item.pszText = prop;
	item.iSubItem = 0;
	SendMessage(hWndTree, LVM_INSERTITEM, (WPARAM)0, (LPARAM)&item);
	item.iSubItem = 1;
	item.pszText = s;
	if(pclsObj)
	if(S_OK==pclsObj->Get(prop, 0, &vtProp, 0, 0))
	{	if(VT_NULL!=vtProp.vt)
		{	switch((int)vtProp.bstrVal)
			{	case 0:
					wsprintf(s,L"0: x86");
				break;
				case 1:
					wsprintf(s,L"1: MIPS");
				break;
				case 2:
					wsprintf(s,L"2: Alpha");
				break;
				case 3:
					wsprintf(s,L"3: PowerPC");
				break;
				case 6:
					wsprintf(s,L"6: Intel Itanium Processor Family (IPF)");
				break;
				case 9:
					wsprintf(s,L"9: x64");
				break;
				default:
					wsprintf(s,L"");
				break;
			}
			SendMessage(hWndTree, LVM_SETITEMTEXT, (WPARAM)0, (LPARAM)&item);
			VariantClear(&vtProp);
			return;
	}	}
	wsprintf(s,L"Dec. value, not defined ...");
	SendMessage(hWndTree, LVM_SETITEMTEXT, (WPARAM)0, (LPARAM)&item);
}

VOID GetCPUStatus(wchar_t *prop)
{	wchar_t s[64];
	item.pszText = prop;
	item.iSubItem = 0;
	SendMessage(hWndTree, LVM_INSERTITEM, (WPARAM)0, (LPARAM)&item);
	item.iSubItem = 1;
	item.pszText = s;
	if(pclsObj)
	if(S_OK==pclsObj->Get(prop, 0, &vtProp, 0, 0))
	{	if(VT_NULL!=vtProp.vt)
		{	switch((int)vtProp.bstrVal)
			{	case 0:
					wsprintf(s,L"0: Unknown");
				break;
				case 1:
					wsprintf(s,L"1: CPU Enabled");
				break;
				case 2:
					wsprintf(s,L"2: CPU Disabled by User via BIOS Setup");
				break;
				case 3:
					wsprintf(s,L"3: CPU Disabled by BIOS (POST Error)");
				break;
				case 4:
					wsprintf(s,L"4: CPU Is Idle");
				break;
				case 5:
				case 6:
					wsprintf(s,L"5: Reserved");
				break;
				case 7:
					wsprintf(s,L"7: Other");
				break;
				default:
					wsprintf(s,L"");
				break;
			}
			SendMessage(hWndTree, LVM_SETITEMTEXT, (WPARAM)0, (LPARAM)&item);
			VariantClear(&vtProp);
			return;
	}	}
	wsprintf(s,L"Dec. value, not defined ...");
	SendMessage(hWndTree, LVM_SETITEMTEXT, (WPARAM)0, (LPARAM)&item);
}

VOID GetCPUFamily(wchar_t *prop)
{	wchar_t s[64];
	item.pszText = prop;
	item.iSubItem = 0;
	SendMessage(hWndTree, LVM_INSERTITEM, (WPARAM)0, (LPARAM)&item);
	item.iSubItem = 1;
	item.pszText = s;
	if(pclsObj)
	if(S_OK==pclsObj->Get(prop, 0, &vtProp, 0, 0))
	{	if(VT_NULL!=vtProp.vt)
		{	switch((int)vtProp.bstrVal)
			{	case 0:
					wsprintf(s,L"0: Other");
				break;
				case 1:
					wsprintf(s,L"1: Unknown");
				break;
				case 2:
					wsprintf(s,L"2: 8086");
				break;
				case 3:
					wsprintf(s,L"3: 80286");
				break;
				case 4:
					wsprintf(s,L"4: Intel386� Processor");
				break;
				case 5:
				case 6:
					wsprintf(s,L"5: Intel486� Processor");
				break;
				case 7:
					wsprintf(s,L"7: 8087");
				break;
				case 8:
					wsprintf(s,L"8: 80287");
				break;
				case 9:
					wsprintf(s,L"9: 80387");
				break;
				case 10:
					wsprintf(s,L"10: 80487");
				break;
				case 11:
					wsprintf(s,L"11: Pentium Brand");
				break;
				case 12:
					wsprintf(s,L"12: Pentium Pro");
				break;
				case 13:
					wsprintf(s,L"13: Pentium II");
				break;
				case 14:
					wsprintf(s,L"14: Pentium Processor with MMX� Technology");
				break;
				case 15:
					wsprintf(s,L"15: Celeron�");
				break;
				case 16:
					wsprintf(s,L"16: Pentium II Xeon�");
				break;
				case 17:
					wsprintf(s,L"17: Pentium III");
				break;
				case 18:
					wsprintf(s,L"18: M1 Family");
				break;
				case 19:
					wsprintf(s,L"19: M2 Family");
				break;
				case 24:
					wsprintf(s,L"24: AMD Duron� Processor Family");
				break;
				case 25:
					wsprintf(s,L"25: K5 Family");
				break;
				case 26:
					wsprintf(s,L"26: K6 Family");
				break;
				case 27:
					wsprintf(s,L"27: K6-2");
				break;
				case 28:
					wsprintf(s,L"28: K6-3");
				break;
				case 29:
					wsprintf(s,L"29: AMD Athlon� Processor Family");
				break;
				case 30:
					wsprintf(s,L"30: AMD2900 Family");
				break;
				case 31:
					wsprintf(s,L"31: K6-2+");
				break;
				case 32:
					wsprintf(s,L"32: Power PC Family");
				break;
				case 33:
					wsprintf(s,L"33: Power PC 601");
				break;
				case 34:
					wsprintf(s,L"34: Power PC 603");
				break;
				case 35:
					wsprintf(s,L"35: Power PC 603+");
				break;
				case 36:
					wsprintf(s,L"36: Power PC 604");
				break;
				case 37:
					wsprintf(s,L"37: Power PC 620");
				break;
				case 38:
					wsprintf(s,L"38: Power PC X704");
				break;
				case 39:
					wsprintf(s,L"39: Power PC 750");
				break;
				case 48:
					wsprintf(s,L"48: Alpha Family");
				break;
				case 49:
					wsprintf(s,L"49: Alpha 21064");
				break;
				case 50:
					wsprintf(s,L"50: Alpha 21066");
				break;
				case 51:
					wsprintf(s,L"51: Alpha 21164");
				break;
				case 52:
					wsprintf(s,L"52: Alpha 21164PC");
				break;
				case 53:
					wsprintf(s,L"53: Alpha 21164a");
				break;
				case 54:
					wsprintf(s,L"54: Alpha 21264");
				break;
				case 55:
					wsprintf(s,L"55: Alpha 21364");
				break;
				case 64:
					wsprintf(s,L"64: MIPS Family");
				break;
				case 65:
					wsprintf(s,L"65: MIPS R4000");
				break;
				case 66:
					wsprintf(s,L"66: MIPS R4200");
				break;
				case 67:
					wsprintf(s,L"67: MIPS R4400");
				break;
				case 68:
					wsprintf(s,L"68: MIPS R4600");
				break;
				case 69:
					wsprintf(s,L"69: MIPS R10000");
				break;
				case 80:
					wsprintf(s,L"80: SPARC Family");
				break;
				case 81:
					wsprintf(s,L"81: SuperSPARC");
				break;
				case 82:
					wsprintf(s,L"82: microSPARC II");
				break;
				case 83:
					wsprintf(s,L"83: microSPARC IIep");
				break;
				case 84:
					wsprintf(s,L"84: UltraSPARC");
				break;
				case 85:
					wsprintf(s,L"85: UltraSPARC II");
				break;
				case 86:
					wsprintf(s,L"86: UltraSPARC IIi");
				break;
				case 87:
					wsprintf(s,L"87: UltraSPARC III");
				break;
				case 88:
					wsprintf(s,L"88: UltraSPARC IIIi");
				break;
				case 96:
					wsprintf(s,L"96: 68040");
				break;
				case 97:
					wsprintf(s,L"97: 68xxx Family");
				break;
				case 98:
					wsprintf(s,L"98: 68000");
				break;
				case 99:
					wsprintf(s,L"99: 68010");
				break;
				case 100:
					wsprintf(s,L"100: 68020");
				break;
				case 101:
					wsprintf(s,L"101: 68030");
				break;
				case 112:
					wsprintf(s,L"112: Hobbit Family");
				break;
				case 120:
					wsprintf(s,L"120: Crusoe� TM5000 Family");
				break;
				case 121:
					wsprintf(s,L"121: Crusoe� TM3000 Family");
				break;
				case 122:
					wsprintf(s,L"122: Efficeon� TM8000 Family");
				break;
				case 128:
					wsprintf(s,L"128: Weitek");
				break;
				case 130:
					wsprintf(s,L"130: Itanium� Processor");
				break;
				case 131:
					wsprintf(s,L"131: AMD Athlon� 64 Processor Famiily");
				break;
				case 132:
					wsprintf(s,L"132: AMD Opteron� Processor Family");
				break;
				case 144:
					wsprintf(s,L"144: PA-RISC Family");
				break;
				case 145:
					wsprintf(s,L"145: PA-RISC 8500");
				break;
				case 146:
					wsprintf(s,L"146: PA-RISC 8000");
				break;
				case 147:
					wsprintf(s,L": PA-RISC 7300LC");
				break;
				case 148:
					wsprintf(s,L"148: PA-RISC 7200");
				break;
				case 149:
					wsprintf(s,L"149: PA-RISC 7100LC");
				break;
				case 150:
					wsprintf(s,L"150: PA-RISC 7100");
				break;
				case 160:
					wsprintf(s,L"160: V30 Family");
				break;
				case 176:
					wsprintf(s,L"176: Pentium III Xeon� Processor");
				break;
				case 177:
					wsprintf(s,L"177: Pentium III Processor with Intel SpeedStep� Technology");
				break;
				case 178:
					wsprintf(s,L"178: Pentium 4");
				break;
				case 179:
					wsprintf(s,L"179: Intel Xeon�");
				break;
				case 180:
					wsprintf(s,L"180: AS400 Family");
				break;
				case 181:
					wsprintf(s,L"181: Intel Xeon� Processor MP");
				break;
				case 182:
					wsprintf(s,L"182: AMD Athlon� XP Family");
				break;
				case 183:
					wsprintf(s,L"183: AMD Athlon� MP Family");
				break;
				case 184:
					wsprintf(s,L"184: Intel Itanium 2");
				break;
				case 185:
					wsprintf(s,L"185: Intel Pentium M Processor");
				break;
				case 190:
					wsprintf(s,L"190: K7");
				break;
				case 200:
					wsprintf(s,L"200: IBM390 Family");
				break;
				case 201:
					wsprintf(s,L"201: G4");
				break;
				case 202:
					wsprintf(s,L"202: G5");
				break;
				case 203:
					wsprintf(s,L"203: G6");
				break;
				case 204:
					wsprintf(s,L"204: z/Architecture Base");
				break;
				case 250:
					wsprintf(s,L"250: i860");
				break;
				case 251:
					wsprintf(s,L"251: i960");
				break;
				case 260:
					wsprintf(s,L"260: SH-3");
				break;
				case 261:
					wsprintf(s,L"261: SH-4");
				break;
				case 280:
					wsprintf(s,L"280: ARM");
				break;
				case 281:
					wsprintf(s,L"281: StrongARM");
				break;
				case 300:
					wsprintf(s,L"300: 6x86");
				break;
				case 301:
					wsprintf(s,L"301: MediaGX");
				break;
				case 302:
					wsprintf(s,L"302: MII");
				break;
				case 320:
					wsprintf(s,L"320: WinChip");
				break;
				case 350:
					wsprintf(s,L"350: DSP");
				break;
				case 500:
					wsprintf(s,L"500: Video Processor");
				break;
				default:
					wsprintf(s,L"");
				break;
			}
			SendMessage(hWndTree, LVM_SETITEMTEXT, (WPARAM)0, (LPARAM)&item);
			VariantClear(&vtProp);
			return;
	}	}
	wsprintf(s,L"Dec. value, not defined ...");
	SendMessage(hWndTree, LVM_SETITEMTEXT, (WPARAM)0, (LPARAM)&item);
}

VOID GetCPUType(wchar_t *prop)
{	wchar_t s[64];
	item.pszText = prop;
	item.iSubItem = 0;
	SendMessage(hWndTree, LVM_INSERTITEM, (WPARAM)0, (LPARAM)&item);
	item.iSubItem = 1;
	item.pszText = s;
	if(pclsObj)
	if(S_OK==pclsObj->Get(prop, 0, &vtProp, 0, 0))
	{	if(VT_NULL!=vtProp.vt)
		{	switch((int)vtProp.bstrVal)
			{	case 1:
					wsprintf(s,L"1: Other");
				break;
				case 2:
					wsprintf(s,L"2: Unknown");
				break;
				case 3:
					wsprintf(s,L"3: Central Processor");
				break;
				case 4:
					wsprintf(s,L"4: Math Processor");
				break;
				case 5:
					wsprintf(s,L"5: DSP Processor");
				break;
				case 6:
					wsprintf(s,L"6: Video Processor");
				break;
				default:
					wsprintf(s,L"");
				break;
			}
			SendMessage(hWndTree, LVM_SETITEMTEXT, (WPARAM)0, (LPARAM)&item);
			VariantClear(&vtProp);
			return;
	}	}
	wsprintf(s,L"Dec. value, not defined ...");
	SendMessage(hWndTree, LVM_SETITEMTEXT, (WPARAM)0, (LPARAM)&item);
}

VOID GetCPUStatusInfo(wchar_t *prop)
{	wchar_t s[64];
	item.pszText = prop;
	item.iSubItem = 0;
	SendMessage(hWndTree, LVM_INSERTITEM, (WPARAM)0, (LPARAM)&item);
	item.iSubItem = 1;
	item.pszText = s;
	if(pclsObj)
	if(S_OK==pclsObj->Get(prop, 0, &vtProp, 0, 0))
	{	if(VT_NULL!=vtProp.vt)
		{	switch((int)vtProp.bstrVal)
			{	case 1:
					wsprintf(s,L"1: Other");
				break;
				case 2:
					wsprintf(s,L"2: Unknown");
				break;
				case 3:
					wsprintf(s,L"3: Enabled");
				break;
				case 4:
					wsprintf(s,L"4: Disabled");
				break;
				case 5:
					wsprintf(s,L"5: Not Applicable");
				break;
				default:
					wsprintf(s,L"");
				break;
			}
			SendMessage(hWndTree, LVM_SETITEMTEXT, (WPARAM)0, (LPARAM)&item);
			VariantClear(&vtProp);
			return;
	}	}
	wsprintf(s,L"Dec. value, not defined ...");
	SendMessage(hWndTree, LVM_SETITEMTEXT, (WPARAM)0, (LPARAM)&item);
}

VOID GetCPUUpgradeMethod(wchar_t *prop)
{	wchar_t s[64];
	item.pszText = prop;
	item.iSubItem = 0;
	SendMessage(hWndTree, LVM_INSERTITEM, (WPARAM)0, (LPARAM)&item);
	item.iSubItem = 1;
	item.pszText = s;
	if(pclsObj)
	if(S_OK==pclsObj->Get(prop, 0, &vtProp, 0, 0))
	{	if(VT_NULL!=vtProp.vt)
		{	switch((int)vtProp.bstrVal)
			{	case 1:
					wsprintf(s,L"1: Other");
				break;
				case 2:
					wsprintf(s,L"2: Unknown");
				break;
				case 3:
					wsprintf(s,L"3: Daughter Board");
				break;
				case 4:
					wsprintf(s,L"4: ZIF Socket");
				break;
				case 5:
					wsprintf(s,L"5: Replacement or Piggy Back");
				break;
				case 6:
					wsprintf(s,L"6: None");
				break;
				case 7:
					wsprintf(s,L"7: LIF Socket");
				break;
				case 8:
					wsprintf(s,L"8: Slot 1");
				break;
				case 9:
					wsprintf(s,L"9: Slot 2");
				break;
				case 10:
					wsprintf(s,L"10: 370 Pin Socket");
				break;
				case 11:
					wsprintf(s,L"11: Slot A");
				break;
				case 12:
					wsprintf(s,L"12: Slot M");
				break;
				case 13:
					wsprintf(s,L"13: Socket 423");
				break;
				case 14:
					wsprintf(s,L"14: Socket A (Socket 462)");
				break;
				case 15:
					wsprintf(s,L"15: Socket 478");
				break;
				case 16:
					wsprintf(s,L"16: Socket 754");
				break;
				case 17:
					wsprintf(s,L"17: Socket 940");
				break;
				case 18:
					wsprintf(s,L"18: Socket 939");
				break;
				default:
					wsprintf(s,L"");
				break;
			}
			SendMessage(hWndTree, LVM_SETITEMTEXT, (WPARAM)0, (LPARAM)&item);
			VariantClear(&vtProp);
			return;
	}	}
	wsprintf(s,L"Dec. value, not defined ...");
	SendMessage(hWndTree, LVM_SETITEMTEXT, (WPARAM)0, (LPARAM)&item);
}

VOID GetCPUVoltageCaps(wchar_t *prop)
{	wchar_t s[64];
	item.pszText = prop;
	item.iSubItem = 0;
	SendMessage(hWndTree, LVM_INSERTITEM, (WPARAM)0, (LPARAM)&item);
	item.iSubItem = 1;
	item.pszText = s;
	if(pclsObj)
	if(S_OK==pclsObj->Get(prop, 0, &vtProp, 0, 0))
	{	if(VT_NULL!=vtProp.vt)
		{	switch((int)vtProp.bstrVal)
			{	case 1:
					wsprintf(s,L"1: 5 volts");
				break;
				case 2:
					wsprintf(s,L"2: 3.3 volts");
				break;
				case 4:
					wsprintf(s,L"4: 2.9 volts");
				break;
				default:
					wsprintf(s,L"");
				break;
			}
			SendMessage(hWndTree, LVM_SETITEMTEXT, (WPARAM)0, (LPARAM)&item);
			VariantClear(&vtProp);
			return;
	}	}
	wsprintf(s,L"Dec. value, not defined ...");
	SendMessage(hWndTree, LVM_SETITEMTEXT, (WPARAM)0, (LPARAM)&item);
}

VOID WMI_Motherboard_Classes_Win32_Processor()
{   HRESULT hres;
    hres =  CoInitializeEx(0, COINIT_MULTITHREADED); 
    if(FAILED(hres))
        return;
    hres =  CoInitializeSecurity(
        NULL, 
        -1,                          // COM authentication
        NULL,                        // Authentication services
        NULL,                        // Reserved
        RPC_C_AUTHN_LEVEL_DEFAULT,   // Default authentication 
        RPC_C_IMP_LEVEL_IMPERSONATE, // Default Impersonation  
        NULL,                        // Authentication info
        EOAC_NONE,                   // Additional capabilities 
        NULL                         // Reserved
        );
    if (FAILED(hres))
    {	CoUninitialize();
        return;                      // Program has failed.
    }
    IWbemLocator *pLoc = NULL;
    hres = CoCreateInstance(
        CLSID_WbemLocator,             
        0, 
        CLSCTX_INPROC_SERVER, 
        IID_IWbemLocator, (LPVOID *) &pLoc);
    if (FAILED(hres))
    {   CoUninitialize();
        return;						// Program has failed.
    }
    IWbemServices *pSvc = NULL;
    hres = pLoc->ConnectServer(
         _bstr_t(L"ROOT\\CIMV2"), // Object path of WMI namespace
         NULL,                    // User name. NULL = current user
         NULL,                    // User password. NULL = current
         0,                       // Locale. NULL indicates current
         NULL,                    // Security flags.
         0,                       // Authority (e.g. Kerberos)
         0,                       // Context object 
         &pSvc                    // pointer to IWbemServices proxy
         );
    
    if (FAILED(hres))
    {   pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    hres = CoSetProxyBlanket(
       pSvc,                        // Indicates the proxy to set
       RPC_C_AUTHN_WINNT,           // RPC_C_AUTHN_xxx
       RPC_C_AUTHZ_NONE,            // RPC_C_AUTHZ_xxx
       NULL,                        // Server principal name 
       RPC_C_AUTHN_LEVEL_CALL,      // RPC_C_AUTHN_LEVEL_xxx 
       RPC_C_IMP_LEVEL_IMPERSONATE, // RPC_C_IMP_LEVEL_xxx
       NULL,                        // client identity
       EOAC_NONE                    // proxy capabilities 
    );
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    IEnumWbemClassObject* pEnumerator = NULL;
    hres = pSvc->ExecQuery(
        bstr_t("WQL"), 
        bstr_t("SELECT * FROM Win32_Processor"),
        WBEM_FLAG_FORWARD_ONLY | WBEM_FLAG_RETURN_IMMEDIATELY, 
        NULL,
        &pEnumerator);
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();
        CoUninitialize();
        return;						// Program has failed.
    }
    pclsObj=0;
    ULONG uReturn = 0;
    while (pEnumerator)
    {	HRESULT hr = pEnumerator->Next(WBEM_INFINITE, 1, &pclsObj, &uReturn);
		//if(0 == uReturn)
		//  break;

 		GetCPUVoltageCaps(L"VoltageCaps");
		GetStr(L"Version");
		GetCPUUpgradeMethod(L"UpgradeMethod");
		GetStr(L"UniqueId");
		GetStr(L"SystemName");
		GetStr(L"SystemCreationClassName");
		GetStr(L"Stepping");
 		GetCPUStatusInfo(L"StatusInfo");
		GetStr(L"Status");
 		GetStr(L"SocketDesignation");
 		GetStr(L"Role");
		GetDec(L"Revision");
		GetCPUType(L"ProcessorType");
		GetStr(L"ProcessorId");
 		GetBool(L"PowerManagementSupported");
 		GetDecArray(L"PowerManagementCapabilities");
		GetStr(L"PNPDeviceID");
		GetStr(L"OtherFamilyDescription");
		GetDec(L"NumberOfLogicalProcessors");
		GetDec(L"NumberOfCores");
		GetStr(L"Name");
		GetDecArg1(L"MaxClockSpeed",L"MegaHertz");
		GetStr(L"Manufacturer");
		GetDecArg1(L"LoadPercentage",L"Percent");
		GetDec(L"Level");
		GetDec(L"LastErrorCode");
		GetDecArg1(L"L3CacheSpeed",L"MegaHertz");
		GetDecArg1(L"L3CacheSize",L"Kilobytes");
		GetDecArg1(L"L2CacheSpeed",L"MegaHertz");
		GetDecArg1(L"L2CacheSize",L"Kilobytes");
		GetDatetime(L"InstallDate");
		GetCPUFamily(L"Family");
		GetDecArg1(L"ExtClock",L"MHz");
		GetStr(L"ErrorDescription");
		GetBool(L"ErrorCleared");
		GetStr(L"DeviceID");
		GetStr(L"Description");
		GetDecArg1(L"DataWidth",L"bits");
		GetDec(L"CurrentVoltage");
		GetDecArg1(L"CurrentClockSpeed",L"MHz");
		GetStr(L"CreationClassName");
		GetCPUStatus(L"CpuStatus");
		GetBool(L"ConfigManagerUserConfig");
		GetConfigManagerErrorCode(L"ConfigManagerErrorCode");
		GetStr(L"Caption");
		GetCacheMemoryAvailability(L"Availability");
		GetCPUArhit(L"Architecture");
		GetDecArg1(L"AddressWidth",L"bits");

		item.pszText = L"";
		item.iSubItem = 0;
		SendMessage(hWndTree, LVM_INSERTITEM, (WPARAM)0, (LPARAM)&item);

		if(0 == uReturn)
		  break;
	}
    if(pSvc)pSvc->Release();
    if(pLoc)pLoc->Release();
    if(pEnumerator)pEnumerator->Release();
    if(pclsObj)pclsObj->Release();
    CoUninitialize();
}

VOID WMI_Motherboard_Classes_Win32_SCSIController()
{   HRESULT hres;
    hres =  CoInitializeEx(0, COINIT_MULTITHREADED); 
    if(FAILED(hres))
        return;
    hres =  CoInitializeSecurity(
        NULL, 
        -1,                          // COM authentication
        NULL,                        // Authentication services
        NULL,                        // Reserved
        RPC_C_AUTHN_LEVEL_DEFAULT,   // Default authentication 
        RPC_C_IMP_LEVEL_IMPERSONATE, // Default Impersonation  
        NULL,                        // Authentication info
        EOAC_NONE,                   // Additional capabilities 
        NULL                         // Reserved
        );
    if (FAILED(hres))
    {	CoUninitialize();
        return;                      // Program has failed.
    }
    IWbemLocator *pLoc = NULL;
    hres = CoCreateInstance(
        CLSID_WbemLocator,             
        0, 
        CLSCTX_INPROC_SERVER, 
        IID_IWbemLocator, (LPVOID *) &pLoc);
    if (FAILED(hres))
    {   CoUninitialize();
        return;						// Program has failed.
    }
    IWbemServices *pSvc = NULL;
    hres = pLoc->ConnectServer(
         _bstr_t(L"ROOT\\CIMV2"), // Object path of WMI namespace
         NULL,                    // User name. NULL = current user
         NULL,                    // User password. NULL = current
         0,                       // Locale. NULL indicates current
         NULL,                    // Security flags.
         0,                       // Authority (e.g. Kerberos)
         0,                       // Context object 
         &pSvc                    // pointer to IWbemServices proxy
         );
    
    if (FAILED(hres))
    {   pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    hres = CoSetProxyBlanket(
       pSvc,                        // Indicates the proxy to set
       RPC_C_AUTHN_WINNT,           // RPC_C_AUTHN_xxx
       RPC_C_AUTHZ_NONE,            // RPC_C_AUTHZ_xxx
       NULL,                        // Server principal name 
       RPC_C_AUTHN_LEVEL_CALL,      // RPC_C_AUTHN_LEVEL_xxx 
       RPC_C_IMP_LEVEL_IMPERSONATE, // RPC_C_IMP_LEVEL_xxx
       NULL,                        // client identity
       EOAC_NONE                    // proxy capabilities 
    );
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    IEnumWbemClassObject* pEnumerator = NULL;
    hres = pSvc->ExecQuery(
        bstr_t("WQL"), 
        bstr_t("SELECT * FROM Win32_SCSIController"),
        WBEM_FLAG_FORWARD_ONLY | WBEM_FLAG_RETURN_IMMEDIATELY, 
        NULL,
        &pEnumerator);
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();
        CoUninitialize();
        return;						// Program has failed.
    }
    pclsObj=0;
    ULONG uReturn = 0;
    while (pEnumerator)
    {	HRESULT hr = pEnumerator->Next(WBEM_INFINITE, 1, &pclsObj, &uReturn);
		//if(0 == uReturn)
		//  break;

		GetDatetime(L"TimeOfLastReset");
		GetStr(L"SystemName");
		GetStr(L"SystemCreationClassName");
		GetCPUStatusInfo(L"StatusInfo");
		GetStr(L"Status");
		GetDec(L"ProtocolSupported");
		GetDec(L"ProtectionManagement");
		GetBool(L"PowerManagementSupported");
 		GetDecArray(L"PowerManagementCapabilities");
		GetStr(L"PNPDeviceID");
		GetStr(L"Name");
		GetDecArg1(L"MaxTransferRate",L"bits per second");
		GetDec(L"MaxNumberControlled");
		GetDecArg1(L"MaxDataWidth",L"bits");
		GetStr(L"Manufacturer");
		GetDec(L"LastErrorCode");
		GetDatetime(L"InstallDate");
		GetDec(L"Index");
		GetStr(L"HardwareVersion");
		GetStr(L"ErrorDescription");
		GetBool(L"ErrorCleared");
		GetStr(L"DriverName");
		GetStr(L"DeviceMap");
		GetStr(L"DeviceID");
		GetStr(L"Description");
		GetStr(L"CreationClassName");
		GetDec(L"ControllerTimeouts");
		GetBool(L"ConfigManagerUserConfig");
		GetConfigManagerErrorCode(L"ConfigManagerErrorCode");
		GetStr(L"Caption");
		GetCPUArhit(L"Architecture");
		GetCacheMemoryAvailability(L"Availability");

		item.pszText = L"";
		item.iSubItem = 0;
		SendMessage(hWndTree, LVM_INSERTITEM, (WPARAM)0, (LPARAM)&item);

		if(0 == uReturn)
		  break;
	}
    if(pSvc)pSvc->Release();
    if(pLoc)pLoc->Release();
    if(pEnumerator)pEnumerator->Release();
    if(pclsObj)pclsObj->Release();
    CoUninitialize();
}

VOID WMI_Motherboard_Classes_Win32_SCSIControllerDevice()
{   HRESULT hres;
    hres =  CoInitializeEx(0, COINIT_MULTITHREADED); 
    if(FAILED(hres))
        return;
    hres =  CoInitializeSecurity(
        NULL, 
        -1,                          // COM authentication
        NULL,                        // Authentication services
        NULL,                        // Reserved
        RPC_C_AUTHN_LEVEL_DEFAULT,   // Default authentication 
        RPC_C_IMP_LEVEL_IMPERSONATE, // Default Impersonation  
        NULL,                        // Authentication info
        EOAC_NONE,                   // Additional capabilities 
        NULL                         // Reserved
        );
    if (FAILED(hres))
    {	CoUninitialize();
        return;                      // Program has failed.
    }
    IWbemLocator *pLoc = NULL;
    hres = CoCreateInstance(
        CLSID_WbemLocator,             
        0, 
        CLSCTX_INPROC_SERVER, 
        IID_IWbemLocator, (LPVOID *) &pLoc);
    if (FAILED(hres))
    {   CoUninitialize();
        return;						// Program has failed.
    }
    IWbemServices *pSvc = NULL;
    hres = pLoc->ConnectServer(
         _bstr_t(L"ROOT\\CIMV2"), // Object path of WMI namespace
         NULL,                    // User name. NULL = current user
         NULL,                    // User password. NULL = current
         0,                       // Locale. NULL indicates current
         NULL,                    // Security flags.
         0,                       // Authority (e.g. Kerberos)
         0,                       // Context object 
         &pSvc                    // pointer to IWbemServices proxy
         );
    
    if (FAILED(hres))
    {   pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    hres = CoSetProxyBlanket(
       pSvc,                        // Indicates the proxy to set
       RPC_C_AUTHN_WINNT,           // RPC_C_AUTHN_xxx
       RPC_C_AUTHZ_NONE,            // RPC_C_AUTHZ_xxx
       NULL,                        // Server principal name 
       RPC_C_AUTHN_LEVEL_CALL,      // RPC_C_AUTHN_LEVEL_xxx 
       RPC_C_IMP_LEVEL_IMPERSONATE, // RPC_C_IMP_LEVEL_xxx
       NULL,                        // client identity
       EOAC_NONE                    // proxy capabilities 
    );
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    IEnumWbemClassObject* pEnumerator = NULL;
    hres = pSvc->ExecQuery(
        bstr_t("WQL"), 
        bstr_t("SELECT * FROM Win32_SCSIControllerDevice"),
        WBEM_FLAG_FORWARD_ONLY | WBEM_FLAG_RETURN_IMMEDIATELY, 
        NULL,
        &pEnumerator);
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();
        CoUninitialize();
        return;						// Program has failed.
    }
    pclsObj=0;
    ULONG uReturn = 0;
    while (pEnumerator)
    {	HRESULT hr = pEnumerator->Next(WBEM_INFINITE, 1, &pclsObj, &uReturn);
		//if(0 == uReturn)
		//  break;

		GetDec(L"NumberOfSoftResets");
		GetDec(L"NumberOfHardResets");
		GetDec(L"NegotiatedSpeed");
		GetDec(L"NegotiatedDataWidth");
		GetStr(L"Dependent");//CIM_LogicalDevice ref Dependent;
		GetStr(L"Antecedent");//Win32_SCSIController ref Antecedent;
		GetDec(L"AccessState");

		item.pszText = L"";
		item.iSubItem = 0;
		SendMessage(hWndTree, LVM_INSERTITEM, (WPARAM)0, (LPARAM)&item);

		if(0 == uReturn)
		  break;
	}
    if(pSvc)pSvc->Release();
    if(pLoc)pLoc->Release();
    if(pEnumerator)pEnumerator->Release();
    if(pclsObj)pclsObj->Release();
    CoUninitialize();
}

VOID WMI_Motherboard_Classes_Win32_SerialPort()
{   HRESULT hres;
    hres =  CoInitializeEx(0, COINIT_MULTITHREADED); 
    if(FAILED(hres))
        return;
    hres =  CoInitializeSecurity(
        NULL, 
        -1,                          // COM authentication
        NULL,                        // Authentication services
        NULL,                        // Reserved
        RPC_C_AUTHN_LEVEL_DEFAULT,   // Default authentication 
        RPC_C_IMP_LEVEL_IMPERSONATE, // Default Impersonation  
        NULL,                        // Authentication info
        EOAC_NONE,                   // Additional capabilities 
        NULL                         // Reserved
        );
    if (FAILED(hres))
    {	CoUninitialize();
        return;                      // Program has failed.
    }
    IWbemLocator *pLoc = NULL;
    hres = CoCreateInstance(
        CLSID_WbemLocator,             
        0, 
        CLSCTX_INPROC_SERVER, 
        IID_IWbemLocator, (LPVOID *) &pLoc);
    if (FAILED(hres))
    {   CoUninitialize();
        return;						// Program has failed.
    }
    IWbemServices *pSvc = NULL;
    hres = pLoc->ConnectServer(
         _bstr_t(L"ROOT\\CIMV2"), // Object path of WMI namespace
         NULL,                    // User name. NULL = current user
         NULL,                    // User password. NULL = current
         0,                       // Locale. NULL indicates current
         NULL,                    // Security flags.
         0,                       // Authority (e.g. Kerberos)
         0,                       // Context object 
         &pSvc                    // pointer to IWbemServices proxy
         );
    
    if (FAILED(hres))
    {   pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    hres = CoSetProxyBlanket(
       pSvc,                        // Indicates the proxy to set
       RPC_C_AUTHN_WINNT,           // RPC_C_AUTHN_xxx
       RPC_C_AUTHZ_NONE,            // RPC_C_AUTHZ_xxx
       NULL,                        // Server principal name 
       RPC_C_AUTHN_LEVEL_CALL,      // RPC_C_AUTHN_LEVEL_xxx 
       RPC_C_IMP_LEVEL_IMPERSONATE, // RPC_C_IMP_LEVEL_xxx
       NULL,                        // client identity
       EOAC_NONE                    // proxy capabilities 
    );
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    IEnumWbemClassObject* pEnumerator = NULL;
    hres = pSvc->ExecQuery(
        bstr_t("WQL"), 
        bstr_t("SELECT * FROM Win32_SerialPort"),
        WBEM_FLAG_FORWARD_ONLY | WBEM_FLAG_RETURN_IMMEDIATELY, 
        NULL,
        &pEnumerator);
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();
        CoUninitialize();
        return;						// Program has failed.
    }
    pclsObj=0;
    ULONG uReturn = 0;
    while (pEnumerator)
    {	HRESULT hr = pEnumerator->Next(WBEM_INFINITE, 1, &pclsObj, &uReturn);
		//if(0 == uReturn)
		//  break;

		GetDatetime(L"TimeOfLastReset");
		GetStr(L"SystemName");
		GetStr(L"SystemCreationClassName");
		GetBool(L"SupportsXOnXOffSet");
		GetBool(L"SupportsXOnXOff");
		GetBool(L"SupportsSpecialCharacters");
		GetBool(L"SupportsRTSCTS");
		GetBool(L"SupportsRLSD");
		GetBool(L"SupportsParityCheck");
		GetBool(L"SupportsIntTimeouts");
		GetBool(L"SupportsElapsedTimeouts");
		GetBool(L"SupportsDTRDSR");
		GetBool(L"Supports16BitMode");
		GetDec(L"StatusInfo");
		GetStr(L"Status");
		GetBool(L"SettableStopBits");
		GetBool(L"SettableRLSD");
		GetBool(L"SettableParityCheck");
		GetBool(L"SettableParity");
		GetBool(L"SettableFlowControl");
		GetBool(L"SettableDataBits");
		GetBool(L"SettableBaudRate");
		GetStr(L"ProviderType");
		GetDec(L"ProtocolSupported");
		GetBool(L"PowerManagementSupported");
		GetDecArray(L"PowerManagementCapabilities");
		GetStr(L"PNPDeviceID");
		GetBool(L"OSAutoDiscovered");
		GetStr(L"Name");
		GetDec(L"MaxNumberControlled");
		GetDec(L"MaximumOutputBufferSize");
		GetDec(L"MaximumInputBufferSize");
		GetDecArg1(L"MaxBaudRate",L"Bits per second");
		GetDec(L"LastErrorCode");
		GetDatetime(L"InstallDate");
		GetStr(L"ErrorDescription");
		GetBool(L"ErrorCleared");
		GetStr(L"DeviceID");
		GetStr(L"Description");
		GetStr(L"CreationClassName");
		GetBool(L"BinConfigManagerUserConfigary");
		GetConfigManagerErrorCode(L"ConfigManagerErrorCode");
		GetStr(L"Caption");
		GetStrArray(L"CapabilityDescriptions");
		GetDecArray(L"Capabilities");
		GetBool(L"Binary");
		GetCacheMemoryAvailability(L"Availability");

		item.pszText = L"";
		item.iSubItem = 0;
		SendMessage(hWndTree, LVM_INSERTITEM, (WPARAM)0, (LPARAM)&item);

		if(0 == uReturn)
		  break;
	}
    if(pSvc)pSvc->Release();
    if(pLoc)pLoc->Release();
    if(pEnumerator)pEnumerator->Release();
    if(pclsObj)pclsObj->Release();
    CoUninitialize();
}

VOID WMI_Motherboard_Classes_Win32_SerialPortConfiguration()
{   HRESULT hres;
    hres =  CoInitializeEx(0, COINIT_MULTITHREADED); 
    if(FAILED(hres))
        return;
    hres =  CoInitializeSecurity(
        NULL, 
        -1,                          // COM authentication
        NULL,                        // Authentication services
        NULL,                        // Reserved
        RPC_C_AUTHN_LEVEL_DEFAULT,   // Default authentication 
        RPC_C_IMP_LEVEL_IMPERSONATE, // Default Impersonation  
        NULL,                        // Authentication info
        EOAC_NONE,                   // Additional capabilities 
        NULL                         // Reserved
        );
    if (FAILED(hres))
    {	CoUninitialize();
        return;                      // Program has failed.
    }
    IWbemLocator *pLoc = NULL;
    hres = CoCreateInstance(
        CLSID_WbemLocator,             
        0, 
        CLSCTX_INPROC_SERVER, 
        IID_IWbemLocator, (LPVOID *) &pLoc);
    if (FAILED(hres))
    {   CoUninitialize();
        return;						// Program has failed.
    }
    IWbemServices *pSvc = NULL;
    hres = pLoc->ConnectServer(
         _bstr_t(L"ROOT\\CIMV2"), // Object path of WMI namespace
         NULL,                    // User name. NULL = current user
         NULL,                    // User password. NULL = current
         0,                       // Locale. NULL indicates current
         NULL,                    // Security flags.
         0,                       // Authority (e.g. Kerberos)
         0,                       // Context object 
         &pSvc                    // pointer to IWbemServices proxy
         );
    
    if (FAILED(hres))
    {   pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    hres = CoSetProxyBlanket(
       pSvc,                        // Indicates the proxy to set
       RPC_C_AUTHN_WINNT,           // RPC_C_AUTHN_xxx
       RPC_C_AUTHZ_NONE,            // RPC_C_AUTHZ_xxx
       NULL,                        // Server principal name 
       RPC_C_AUTHN_LEVEL_CALL,      // RPC_C_AUTHN_LEVEL_xxx 
       RPC_C_IMP_LEVEL_IMPERSONATE, // RPC_C_IMP_LEVEL_xxx
       NULL,                        // client identity
       EOAC_NONE                    // proxy capabilities 
    );
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    IEnumWbemClassObject* pEnumerator = NULL;
    hres = pSvc->ExecQuery(
        bstr_t("WQL"), 
        bstr_t("SELECT * FROM Win32_SerialPortConfiguration"),
        WBEM_FLAG_FORWARD_ONLY | WBEM_FLAG_RETURN_IMMEDIATELY, 
        NULL,
        &pEnumerator);
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();
        CoUninitialize();
        return;						// Program has failed.
    }
    pclsObj=0;
    ULONG uReturn = 0;
    while (pEnumerator)
    {	HRESULT hr = pEnumerator->Next(WBEM_INFINITE, 1, &pclsObj, &uReturn);
		//if(0 == uReturn)
		//  break;

		GetDec(L"XOnXOffOutFlowControl");
		GetDec(L"XOnXOffInFlowControl");
		GetDec(L"XOnXMitThreshold");
		GetDec(L"XOnCharacter");
		GetDec(L"XOffXMitThreshold");
		GetDec(L"XOffCharacter");
		GetStr(L"StopBits");
		GetStr(L"SettingID");
		GetStr(L"RTSFlowControlType");
		GetBool(L"ParityCheckEnabled");
		GetStr(L"Parity");
		GetStr(L"Name");
		GetBool(L"IsBusy");
		GetDec(L"EventCharacter");
		GetBool(L"ErrorReplacementEnabled");
		GetDec(L"ErrorReplaceCharacter");
		GetDec(L"EOFCharacter");
		GetStr(L"DTRFlowControlType");
		GetBool(L"DSRSensitivity");
		GetBool(L"DSROutflowControl");
		GetBool(L"DiscardNULLBytes");
		GetStr(L"Description");
		GetBool(L"CTSOutflowControl");
		GetBool(L"ContinueXMitOnXOff");
		GetStr(L"Caption");
		GetDec(L"BitsPerByte");
		GetBool(L"BinaryModeEnabled");
		GetDecArg1(L"BaudRate",L"bits per second");
		GetBool(L"AbortReadWriteOnError");

		item.pszText = L"";
		item.iSubItem = 0;
		SendMessage(hWndTree, LVM_INSERTITEM, (WPARAM)0, (LPARAM)&item);

		if(0 == uReturn)
		  break;
	}
    if(pSvc)pSvc->Release();
    if(pLoc)pLoc->Release();
    if(pEnumerator)pEnumerator->Release();
    if(pclsObj)pclsObj->Release();
    CoUninitialize();
}

VOID WMI_Motherboard_Classes_Win32_SerialPortSetting()
{   HRESULT hres;
    hres =  CoInitializeEx(0, COINIT_MULTITHREADED); 
    if(FAILED(hres))
        return;
    hres =  CoInitializeSecurity(
        NULL, 
        -1,                          // COM authentication
        NULL,                        // Authentication services
        NULL,                        // Reserved
        RPC_C_AUTHN_LEVEL_DEFAULT,   // Default authentication 
        RPC_C_IMP_LEVEL_IMPERSONATE, // Default Impersonation  
        NULL,                        // Authentication info
        EOAC_NONE,                   // Additional capabilities 
        NULL                         // Reserved
        );
    if (FAILED(hres))
    {	CoUninitialize();
        return;                      // Program has failed.
    }
    IWbemLocator *pLoc = NULL;
    hres = CoCreateInstance(
        CLSID_WbemLocator,             
        0, 
        CLSCTX_INPROC_SERVER, 
        IID_IWbemLocator, (LPVOID *) &pLoc);
    if (FAILED(hres))
    {   CoUninitialize();
        return;						// Program has failed.
    }
    IWbemServices *pSvc = NULL;
    hres = pLoc->ConnectServer(
         _bstr_t(L"ROOT\\CIMV2"), // Object path of WMI namespace
         NULL,                    // User name. NULL = current user
         NULL,                    // User password. NULL = current
         0,                       // Locale. NULL indicates current
         NULL,                    // Security flags.
         0,                       // Authority (e.g. Kerberos)
         0,                       // Context object 
         &pSvc                    // pointer to IWbemServices proxy
         );
    
    if (FAILED(hres))
    {   pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    hres = CoSetProxyBlanket(
       pSvc,                        // Indicates the proxy to set
       RPC_C_AUTHN_WINNT,           // RPC_C_AUTHN_xxx
       RPC_C_AUTHZ_NONE,            // RPC_C_AUTHZ_xxx
       NULL,                        // Server principal name 
       RPC_C_AUTHN_LEVEL_CALL,      // RPC_C_AUTHN_LEVEL_xxx 
       RPC_C_IMP_LEVEL_IMPERSONATE, // RPC_C_IMP_LEVEL_xxx
       NULL,                        // client identity
       EOAC_NONE                    // proxy capabilities 
    );
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    IEnumWbemClassObject* pEnumerator = NULL;
    hres = pSvc->ExecQuery(
        bstr_t("WQL"), 
        bstr_t("SELECT * FROM Win32_SerialPortSetting"),
        WBEM_FLAG_FORWARD_ONLY | WBEM_FLAG_RETURN_IMMEDIATELY, 
        NULL,
        &pEnumerator);
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();
        CoUninitialize();
        return;						// Program has failed.
    }
    pclsObj=0;
    ULONG uReturn = 0;
    while (pEnumerator)
    {	HRESULT hr = pEnumerator->Next(WBEM_INFINITE, 1, &pclsObj, &uReturn);
		//if(0 == uReturn)
		//  break;

		GetStr(L"Setting");//Win32_SerialPortConfiguration ref Setting;
		GetStr(L"Element");//Win32_SerialPort ref Element;

		item.pszText = L"";
		item.iSubItem = 0;
		SendMessage(hWndTree, LVM_INSERTITEM, (WPARAM)0, (LPARAM)&item);

		if(0 == uReturn)
		  break;
	}
    if(pSvc)pSvc->Release();
    if(pLoc)pLoc->Release();
    if(pEnumerator)pEnumerator->Release();
    if(pclsObj)pclsObj->Release();
    CoUninitialize();
}

VOID GetSMBBiosAccess(wchar_t *prop)
{	wchar_t s[64];
	item.pszText = prop;
	item.iSubItem = 0;
	SendMessage(hWndTree, LVM_INSERTITEM, (WPARAM)0, (LPARAM)&item);
	item.iSubItem = 1;
	item.pszText = s;
	if(pclsObj)
	if(S_OK==pclsObj->Get(prop, 0, &vtProp, 0, 0))
	{	if(VT_NULL!=vtProp.vt)
		{	switch((int)vtProp.bstrVal)
			{	case 0:
					wsprintf(s,L"0: Unknown");
				break;
				case 1:
					wsprintf(s,L"1: Readable");
				break;
				case 2:
					wsprintf(s,L"2: Writable");
				break;
				case 3:
					wsprintf(s,L"3: Read/Write Supported");
				break;
				case 4:
					wsprintf(s,L"4: Write Once");
				break;
				default:
					wsprintf(s,L"");
				break;
			}
			SendMessage(hWndTree, LVM_SETITEMTEXT, (WPARAM)0, (LPARAM)&item);
			VariantClear(&vtProp);
			return;
	}	}
	wsprintf(s,L"Dec. value, not defined ...");
	SendMessage(hWndTree, LVM_SETITEMTEXT, (WPARAM)0, (LPARAM)&item);
}

VOID WMI_Motherboard_Classes_Win32_SMBIOSMemory()
{   HRESULT hres;
    hres =  CoInitializeEx(0, COINIT_MULTITHREADED); 
    if(FAILED(hres))
        return;
    hres =  CoInitializeSecurity(
        NULL, 
        -1,                          // COM authentication
        NULL,                        // Authentication services
        NULL,                        // Reserved
        RPC_C_AUTHN_LEVEL_DEFAULT,   // Default authentication 
        RPC_C_IMP_LEVEL_IMPERSONATE, // Default Impersonation  
        NULL,                        // Authentication info
        EOAC_NONE,                   // Additional capabilities 
        NULL                         // Reserved
        );
    if (FAILED(hres))
    {	CoUninitialize();
        return;                      // Program has failed.
    }
    IWbemLocator *pLoc = NULL;
    hres = CoCreateInstance(
        CLSID_WbemLocator,             
        0, 
        CLSCTX_INPROC_SERVER, 
        IID_IWbemLocator, (LPVOID *) &pLoc);
    if (FAILED(hres))
    {   CoUninitialize();
        return;						// Program has failed.
    }
    IWbemServices *pSvc = NULL;
    hres = pLoc->ConnectServer(
         _bstr_t(L"ROOT\\CIMV2"), // Object path of WMI namespace
         NULL,                    // User name. NULL = current user
         NULL,                    // User password. NULL = current
         0,                       // Locale. NULL indicates current
         NULL,                    // Security flags.
         0,                       // Authority (e.g. Kerberos)
         0,                       // Context object 
         &pSvc                    // pointer to IWbemServices proxy
         );
    
    if (FAILED(hres))
    {   pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    hres = CoSetProxyBlanket(
       pSvc,                        // Indicates the proxy to set
       RPC_C_AUTHN_WINNT,           // RPC_C_AUTHN_xxx
       RPC_C_AUTHZ_NONE,            // RPC_C_AUTHZ_xxx
       NULL,                        // Server principal name 
       RPC_C_AUTHN_LEVEL_CALL,      // RPC_C_AUTHN_LEVEL_xxx 
       RPC_C_IMP_LEVEL_IMPERSONATE, // RPC_C_IMP_LEVEL_xxx
       NULL,                        // client identity
       EOAC_NONE                    // proxy capabilities 
    );
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    IEnumWbemClassObject* pEnumerator = NULL;
    hres = pSvc->ExecQuery(
        bstr_t("WQL"), 
        bstr_t("SELECT * FROM Win32_SMBIOSMemory"),
        WBEM_FLAG_FORWARD_ONLY | WBEM_FLAG_RETURN_IMMEDIATELY, 
        NULL,
        &pEnumerator);
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();
        CoUninitialize();
        return;						// Program has failed.
    }
    pclsObj=0;
    ULONG uReturn = 0;
    while (pEnumerator)
    {	HRESULT hr = pEnumerator->Next(WBEM_INFINITE, 1, &pclsObj, &uReturn);
		//if(0 == uReturn)
		//  break;

		GetStr(L"SystemName");
		GetBool(L"SystemLevelAddress");
		GetStr(L"SystemCreationClassName");
		GetDec(L"StatusInfo");
		GetStr(L"Status");
		GetDecX64(L"StartingAddress");
		GetStr(L"Purpose");
		GetBool(L"PowerManagementSupported");
		GetDecArray(L"PowerManagementCapabilities");
		GetStr(L"PNPDeviceID");
		GetStr(L"OtherErrorDescription");
		GetDec(L"NumberOfBlocks");
		GetStr(L"Name");
		GetDec(L"LastErrorCode");
		GetDatetime(L"InstallDate");
		GetDec(L"ErrorTransferSize");
		GetDatetime(L"ErrorTime");
		GetDec(L"ErrorResolution");
		GetStr(L"ErrorMethodology");
		GetDec(L"ErrorInfo");
		GetStr(L"ErrorDescription");
		GetDec(L"ErrorDataOrder");
		GetDecArray(L"ErrorData");
		GetBool(L"ErrorCleared");
		GetDecX64(L"ErrorAddress");
		GetDec(L"ErrorAccess");
		GetDecX64(L"EndingAddress");
		GetStr(L"DeviceID");
		GetStr(L"Description");
		GetStr(L"CreationClassName");
		GetBool(L"CorrectableError");
		GetBool(L"ConfigManagerUserConfig");
		GetConfigManagerErrorCode(L"ConfigManagerErrorCode");
		GetStr(L"Caption");
		GetDec(L"BlockSize");
		GetCacheMemoryAvailability(L"Availability");
		GetDecArray(L"AdditionalErrorData");
		GetSMBBiosAccess(L"Access");

		item.pszText = L"";
		item.iSubItem = 0;
		SendMessage(hWndTree, LVM_INSERTITEM, (WPARAM)0, (LPARAM)&item);

		if(0 == uReturn)
		  break;
	}
    if(pSvc)pSvc->Release();
    if(pLoc)pLoc->Release();
    if(pEnumerator)pEnumerator->Release();
    if(pclsObj)pclsObj->Release();
    CoUninitialize();
}

VOID WMI_Motherboard_Classes_Win32_SoundDevice()
{   HRESULT hres;
    hres =  CoInitializeEx(0, COINIT_MULTITHREADED); 
    if(FAILED(hres))
        return;
    hres =  CoInitializeSecurity(
        NULL, 
        -1,                          // COM authentication
        NULL,                        // Authentication services
        NULL,                        // Reserved
        RPC_C_AUTHN_LEVEL_DEFAULT,   // Default authentication 
        RPC_C_IMP_LEVEL_IMPERSONATE, // Default Impersonation  
        NULL,                        // Authentication info
        EOAC_NONE,                   // Additional capabilities 
        NULL                         // Reserved
        );
    if (FAILED(hres))
    {	CoUninitialize();
        return;                      // Program has failed.
    }
    IWbemLocator *pLoc = NULL;
    hres = CoCreateInstance(
        CLSID_WbemLocator,             
        0, 
        CLSCTX_INPROC_SERVER, 
        IID_IWbemLocator, (LPVOID *) &pLoc);
    if (FAILED(hres))
    {   CoUninitialize();
        return;						// Program has failed.
    }
    IWbemServices *pSvc = NULL;
    hres = pLoc->ConnectServer(
         _bstr_t(L"ROOT\\CIMV2"), // Object path of WMI namespace
         NULL,                    // User name. NULL = current user
         NULL,                    // User password. NULL = current
         0,                       // Locale. NULL indicates current
         NULL,                    // Security flags.
         0,                       // Authority (e.g. Kerberos)
         0,                       // Context object 
         &pSvc                    // pointer to IWbemServices proxy
         );
    
    if (FAILED(hres))
    {   pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    hres = CoSetProxyBlanket(
       pSvc,                        // Indicates the proxy to set
       RPC_C_AUTHN_WINNT,           // RPC_C_AUTHN_xxx
       RPC_C_AUTHZ_NONE,            // RPC_C_AUTHZ_xxx
       NULL,                        // Server principal name 
       RPC_C_AUTHN_LEVEL_CALL,      // RPC_C_AUTHN_LEVEL_xxx 
       RPC_C_IMP_LEVEL_IMPERSONATE, // RPC_C_IMP_LEVEL_xxx
       NULL,                        // client identity
       EOAC_NONE                    // proxy capabilities 
    );
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    IEnumWbemClassObject* pEnumerator = NULL;
    hres = pSvc->ExecQuery(
        bstr_t("WQL"), 
        bstr_t("SELECT * FROM Win32_SoundDevice"),
        WBEM_FLAG_FORWARD_ONLY | WBEM_FLAG_RETURN_IMMEDIATELY, 
        NULL,
        &pEnumerator);
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();
        CoUninitialize();
        return;						// Program has failed.
    }
    pclsObj=0;
    ULONG uReturn = 0;
    while (pEnumerator)
    {	HRESULT hr = pEnumerator->Next(WBEM_INFINITE, 1, &pclsObj, &uReturn);
		//if(0 == uReturn)
		//  break;

		GetStr(L"SystemName");
		GetStr(L"SystemCreationClassName");
		GetDec(L"StatusInfo");
		GetStr(L"Status");
		GetStr(L"ProductName");
		GetBool(L"PowerManagementSupported");
		GetDecArray(L"PowerManagementCapabilities");
		GetStr(L"PNPDeviceID");
		GetStr(L"Name");
		GetDec(L"MPU401Address");
		GetStr(L"Manufacturer");
		GetDec(L"LastErrorCode");
		GetDatetime(L"InstallDate");
		GetStr(L"ErrorDescription");
		GetBool(L"ErrorCleared");
		GetDecArg1(L"DMABufferSize",L"Kilobytes");
		GetStr(L"DeviceID");
		GetStr(L"Description");
		GetStr(L"CreationClassName");
		GetBool(L"ConfigManagerUserConfig");
		GetConfigManagerErrorCode(L"ConfigManagerErrorCode");
		GetStr(L"Caption");
		GetCacheMemoryAvailability(L"Availability");

		item.pszText = L"";
		item.iSubItem = 0;
		SendMessage(hWndTree, LVM_INSERTITEM, (WPARAM)0, (LPARAM)&item);

		if(0 == uReturn)
		  break;
	}
    if(pSvc)pSvc->Release();
    if(pLoc)pLoc->Release();
    if(pEnumerator)pEnumerator->Release();
    if(pclsObj)pclsObj->Release();
    CoUninitialize();
}

VOID WMI_Motherboard_Classes_Win32_SystemBIOS()
{   HRESULT hres;
    hres =  CoInitializeEx(0, COINIT_MULTITHREADED); 
    if(FAILED(hres))
        return;
    hres =  CoInitializeSecurity(
        NULL, 
        -1,                          // COM authentication
        NULL,                        // Authentication services
        NULL,                        // Reserved
        RPC_C_AUTHN_LEVEL_DEFAULT,   // Default authentication 
        RPC_C_IMP_LEVEL_IMPERSONATE, // Default Impersonation  
        NULL,                        // Authentication info
        EOAC_NONE,                   // Additional capabilities 
        NULL                         // Reserved
        );
    if (FAILED(hres))
    {	CoUninitialize();
        return;                      // Program has failed.
    }
    IWbemLocator *pLoc = NULL;
    hres = CoCreateInstance(
        CLSID_WbemLocator,             
        0, 
        CLSCTX_INPROC_SERVER, 
        IID_IWbemLocator, (LPVOID *) &pLoc);
    if (FAILED(hres))
    {   CoUninitialize();
        return;						// Program has failed.
    }
    IWbemServices *pSvc = NULL;
    hres = pLoc->ConnectServer(
         _bstr_t(L"ROOT\\CIMV2"), // Object path of WMI namespace
         NULL,                    // User name. NULL = current user
         NULL,                    // User password. NULL = current
         0,                       // Locale. NULL indicates current
         NULL,                    // Security flags.
         0,                       // Authority (e.g. Kerberos)
         0,                       // Context object 
         &pSvc                    // pointer to IWbemServices proxy
         );
    
    if (FAILED(hres))
    {   pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    hres = CoSetProxyBlanket(
       pSvc,                        // Indicates the proxy to set
       RPC_C_AUTHN_WINNT,           // RPC_C_AUTHN_xxx
       RPC_C_AUTHZ_NONE,            // RPC_C_AUTHZ_xxx
       NULL,                        // Server principal name 
       RPC_C_AUTHN_LEVEL_CALL,      // RPC_C_AUTHN_LEVEL_xxx 
       RPC_C_IMP_LEVEL_IMPERSONATE, // RPC_C_IMP_LEVEL_xxx
       NULL,                        // client identity
       EOAC_NONE                    // proxy capabilities 
    );
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    IEnumWbemClassObject* pEnumerator = NULL;
    hres = pSvc->ExecQuery(
        bstr_t("WQL"), 
        bstr_t("SELECT * FROM Win32_SystemBIOS"),
        WBEM_FLAG_FORWARD_ONLY | WBEM_FLAG_RETURN_IMMEDIATELY, 
        NULL,
        &pEnumerator);
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();
        CoUninitialize();
        return;						// Program has failed.
    }
    pclsObj=0;
    ULONG uReturn = 0;
    while (pEnumerator)
    {	HRESULT hr = pEnumerator->Next(WBEM_INFINITE, 1, &pclsObj, &uReturn);
		//if(0 == uReturn)
		//  break;

		GetStr(L"PartComponent");//Win32_BIOS ref PartComponent;
		GetStr(L"GroupComponent");//Win32_ComputerSystem ref GroupComponent;

		item.pszText = L"";
		item.iSubItem = 0;
		SendMessage(hWndTree, LVM_INSERTITEM, (WPARAM)0, (LPARAM)&item);

		if(0 == uReturn)
		  break;
	}
    if(pSvc)pSvc->Release();
    if(pLoc)pLoc->Release();
    if(pEnumerator)pEnumerator->Release();
    if(pclsObj)pclsObj->Release();
    CoUninitialize();
}

VOID WMI_Motherboard_Classes_Win32_SystemDriverPNPEntity()
{   HRESULT hres;
    hres =  CoInitializeEx(0, COINIT_MULTITHREADED); 
    if(FAILED(hres))
        return;
    hres =  CoInitializeSecurity(
        NULL, 
        -1,                          // COM authentication
        NULL,                        // Authentication services
        NULL,                        // Reserved
        RPC_C_AUTHN_LEVEL_DEFAULT,   // Default authentication 
        RPC_C_IMP_LEVEL_IMPERSONATE, // Default Impersonation  
        NULL,                        // Authentication info
        EOAC_NONE,                   // Additional capabilities 
        NULL                         // Reserved
        );
    if (FAILED(hres))
    {	CoUninitialize();
        return;                      // Program has failed.
    }
    IWbemLocator *pLoc = NULL;
    hres = CoCreateInstance(
        CLSID_WbemLocator,             
        0, 
        CLSCTX_INPROC_SERVER, 
        IID_IWbemLocator, (LPVOID *) &pLoc);
    if (FAILED(hres))
    {   CoUninitialize();
        return;						// Program has failed.
    }
    IWbemServices *pSvc = NULL;
    hres = pLoc->ConnectServer(
         _bstr_t(L"ROOT\\CIMV2"), // Object path of WMI namespace
         NULL,                    // User name. NULL = current user
         NULL,                    // User password. NULL = current
         0,                       // Locale. NULL indicates current
         NULL,                    // Security flags.
         0,                       // Authority (e.g. Kerberos)
         0,                       // Context object 
         &pSvc                    // pointer to IWbemServices proxy
         );
    
    if (FAILED(hres))
    {   pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    hres = CoSetProxyBlanket(
       pSvc,                        // Indicates the proxy to set
       RPC_C_AUTHN_WINNT,           // RPC_C_AUTHN_xxx
       RPC_C_AUTHZ_NONE,            // RPC_C_AUTHZ_xxx
       NULL,                        // Server principal name 
       RPC_C_AUTHN_LEVEL_CALL,      // RPC_C_AUTHN_LEVEL_xxx 
       RPC_C_IMP_LEVEL_IMPERSONATE, // RPC_C_IMP_LEVEL_xxx
       NULL,                        // client identity
       EOAC_NONE                    // proxy capabilities 
    );
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    IEnumWbemClassObject* pEnumerator = NULL;
    hres = pSvc->ExecQuery(
        bstr_t("WQL"), 
        bstr_t("SELECT * FROM Win32_SystemDriverPNPEntity"),
        WBEM_FLAG_FORWARD_ONLY | WBEM_FLAG_RETURN_IMMEDIATELY, 
        NULL,
        &pEnumerator);
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();
        CoUninitialize();
        return;						// Program has failed.
    }
    pclsObj=0;
    ULONG uReturn = 0;
    while (pEnumerator)
    {	HRESULT hr = pEnumerator->Next(WBEM_INFINITE, 1, &pclsObj, &uReturn);
		//if(0 == uReturn)
		//  break;

		GetStr(L"Dependent");//Win32_SystemDriver ref Dependent;
		GetStr(L"Antecedent");//Win32_PNPEntity ref Antecedent;

		item.pszText = L"";
		item.iSubItem = 0;
		SendMessage(hWndTree, LVM_INSERTITEM, (WPARAM)0, (LPARAM)&item);

		if(0 == uReturn)
		  break;
	}
    if(pSvc)pSvc->Release();
    if(pLoc)pLoc->Release();
    if(pEnumerator)pEnumerator->Release();
    if(pclsObj)pclsObj->Release();
    CoUninitialize();
}

VOID GetSysEncSecurityStatus(wchar_t *prop)
{	wchar_t s[64];
	item.pszText = prop;
	item.iSubItem = 0;
	SendMessage(hWndTree, LVM_INSERTITEM, (WPARAM)0, (LPARAM)&item);
	item.iSubItem = 1;
	item.pszText = s;
	if(pclsObj)
	if(S_OK==pclsObj->Get(prop, 0, &vtProp, 0, 0))
	{	if(VT_NULL!=vtProp.vt)
		{	switch((int)vtProp.bstrVal)
			{	case 1:
					wsprintf(s,L"1: Other");
				break;
				case 2:
					wsprintf(s,L"2: Unknown");
				break;
				case 3:
					wsprintf(s,L"3: None");
				break;
				case 4:
					wsprintf(s,L"4: External Interface Locked Out");
				break;
				case 5:
					wsprintf(s,L"5: External Interface Enabled");
				break;
				default:
					wsprintf(s,L"");
				break;
			}
			SendMessage(hWndTree, LVM_SETITEMTEXT, (WPARAM)0, (LPARAM)&item);
			VariantClear(&vtProp);
			return;
	}	}
	wsprintf(s,L"Dec. value, not defined ...");
	SendMessage(hWndTree, LVM_SETITEMTEXT, (WPARAM)0, (LPARAM)&item);
}

VOID WMI_Motherboard_Classes_Win32_SystemEnclosure()
{   HRESULT hres;
    hres =  CoInitializeEx(0, COINIT_MULTITHREADED); 
    if(FAILED(hres))
        return;
    hres =  CoInitializeSecurity(
        NULL, 
        -1,                          // COM authentication
        NULL,                        // Authentication services
        NULL,                        // Reserved
        RPC_C_AUTHN_LEVEL_DEFAULT,   // Default authentication 
        RPC_C_IMP_LEVEL_IMPERSONATE, // Default Impersonation  
        NULL,                        // Authentication info
        EOAC_NONE,                   // Additional capabilities 
        NULL                         // Reserved
        );
    if (FAILED(hres))
    {	CoUninitialize();
        return;                      // Program has failed.
    }
    IWbemLocator *pLoc = NULL;
    hres = CoCreateInstance(
        CLSID_WbemLocator,             
        0, 
        CLSCTX_INPROC_SERVER, 
        IID_IWbemLocator, (LPVOID *) &pLoc);
    if (FAILED(hres))
    {   CoUninitialize();
        return;						// Program has failed.
    }
    IWbemServices *pSvc = NULL;
    hres = pLoc->ConnectServer(
         _bstr_t(L"ROOT\\CIMV2"), // Object path of WMI namespace
         NULL,                    // User name. NULL = current user
         NULL,                    // User password. NULL = current
         0,                       // Locale. NULL indicates current
         NULL,                    // Security flags.
         0,                       // Authority (e.g. Kerberos)
         0,                       // Context object 
         &pSvc                    // pointer to IWbemServices proxy
         );
    
    if (FAILED(hres))
    {   pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    hres = CoSetProxyBlanket(
       pSvc,                        // Indicates the proxy to set
       RPC_C_AUTHN_WINNT,           // RPC_C_AUTHN_xxx
       RPC_C_AUTHZ_NONE,            // RPC_C_AUTHZ_xxx
       NULL,                        // Server principal name 
       RPC_C_AUTHN_LEVEL_CALL,      // RPC_C_AUTHN_LEVEL_xxx 
       RPC_C_IMP_LEVEL_IMPERSONATE, // RPC_C_IMP_LEVEL_xxx
       NULL,                        // client identity
       EOAC_NONE                    // proxy capabilities 
    );
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    IEnumWbemClassObject* pEnumerator = NULL;
    hres = pSvc->ExecQuery(
        bstr_t("WQL"), 
        bstr_t("SELECT * FROM Win32_SystemEnclosure"),
        WBEM_FLAG_FORWARD_ONLY | WBEM_FLAG_RETURN_IMMEDIATELY, 
        NULL,
        &pEnumerator);
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();
        CoUninitialize();
        return;						// Program has failed.
    }
    pclsObj=0;
    ULONG uReturn = 0;
    while (pEnumerator)
    {	HRESULT hr = pEnumerator->Next(WBEM_INFINITE, 1, &pclsObj, &uReturn);
		//if(0 == uReturn)
		//  break;

		GetReal(L"Width");
		GetReal(L"Weight");
		GetBool(L"VisibleAlarm");
		GetStr(L"Version");
		GetStrArray(L"TypeDescriptions");
		GetStr(L"Tag");
		GetStr(L"Status");
		GetStr(L"SMBIOSAssetTag");
		GetStr(L"SKU");
		GetDecArray(L"ServicePhilosophy");
		GetStrArray(L"ServiceDescriptions");
		GetStr(L"SerialNumber");
		GetSysEncSecurityStatus(L"SecurityStatus");
		GetDec(L"SecurityBreach");
		GetBool(L"Replaceable");
		GetBool(L"Removable");
		GetBool(L"PoweredOn");
		GetStr(L"PartNumber");
		GetStr(L"OtherIdentifyingInfo");
		GetDec(L"NumberOfPowerCords");
		GetStr(L"Name");
		GetStr(L"Model");
		GetStr(L"Manufacturer");
		GetBool(L"LockPresent");
		GetDatetime(L"InstallDate");
		GetBool(L"HotSwappable");
		GetReal(L"Height");
		GetDec(L"HeatGeneration");
		GetStr(L"Description");
		GetReal(L"Depth");
		GetDec(L"CurrentRequiredOrProduced");
		GetStr(L"CreationClassName");
		GetDecArray(L"ChassisTypes");
		GetStr(L"Caption");
		GetStr(L"CableManagementStrategy");
		GetStr(L"BreachDescription");
		GetBool(L"AudibleAlarm");

		item.pszText = L"";
		item.iSubItem = 0;
		SendMessage(hWndTree, LVM_INSERTITEM, (WPARAM)0, (LPARAM)&item);

		if(0 == uReturn)
		  break;
	}
    if(pSvc)pSvc->Release();
    if(pLoc)pLoc->Release();
    if(pEnumerator)pEnumerator->Release();
    if(pclsObj)pclsObj->Release();
    CoUninitialize();
}

VOID WMI_Motherboard_Classes_Win32_SystemMemoryResource()
{   HRESULT hres;
    hres =  CoInitializeEx(0, COINIT_MULTITHREADED); 
    if(FAILED(hres))
        return;
    hres =  CoInitializeSecurity(
        NULL, 
        -1,                          // COM authentication
        NULL,                        // Authentication services
        NULL,                        // Reserved
        RPC_C_AUTHN_LEVEL_DEFAULT,   // Default authentication 
        RPC_C_IMP_LEVEL_IMPERSONATE, // Default Impersonation  
        NULL,                        // Authentication info
        EOAC_NONE,                   // Additional capabilities 
        NULL                         // Reserved
        );
    if (FAILED(hres))
    {	CoUninitialize();
        return;                      // Program has failed.
    }
    IWbemLocator *pLoc = NULL;
    hres = CoCreateInstance(
        CLSID_WbemLocator,             
        0, 
        CLSCTX_INPROC_SERVER, 
        IID_IWbemLocator, (LPVOID *) &pLoc);
    if (FAILED(hres))
    {   CoUninitialize();
        return;						// Program has failed.
    }
    IWbemServices *pSvc = NULL;
    hres = pLoc->ConnectServer(
         _bstr_t(L"ROOT\\CIMV2"), // Object path of WMI namespace
         NULL,                    // User name. NULL = current user
         NULL,                    // User password. NULL = current
         0,                       // Locale. NULL indicates current
         NULL,                    // Security flags.
         0,                       // Authority (e.g. Kerberos)
         0,                       // Context object 
         &pSvc                    // pointer to IWbemServices proxy
         );
    
    if (FAILED(hres))
    {   pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    hres = CoSetProxyBlanket(
       pSvc,                        // Indicates the proxy to set
       RPC_C_AUTHN_WINNT,           // RPC_C_AUTHN_xxx
       RPC_C_AUTHZ_NONE,            // RPC_C_AUTHZ_xxx
       NULL,                        // Server principal name 
       RPC_C_AUTHN_LEVEL_CALL,      // RPC_C_AUTHN_LEVEL_xxx 
       RPC_C_IMP_LEVEL_IMPERSONATE, // RPC_C_IMP_LEVEL_xxx
       NULL,                        // client identity
       EOAC_NONE                    // proxy capabilities 
    );
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    IEnumWbemClassObject* pEnumerator = NULL;
    hres = pSvc->ExecQuery(
        bstr_t("WQL"), 
        bstr_t("SELECT * FROM Win32_SystemMemoryResource"),
        WBEM_FLAG_FORWARD_ONLY | WBEM_FLAG_RETURN_IMMEDIATELY, 
        NULL,
        &pEnumerator);
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();
        CoUninitialize();
        return;						// Program has failed.
    }
    pclsObj=0;
    ULONG uReturn = 0;
    while (pEnumerator)
    {	HRESULT hr = pEnumerator->Next(WBEM_INFINITE, 1, &pclsObj, &uReturn);
		//if(0 == uReturn)
		//  break;

		GetStr(L"Status");
		GetDecX64(L"StartingAddress");
		GetStr(L"Name");
		GetDatetime(L"InstallDate");
		GetDecX64(L"EndingAddress");
		GetStr(L"Description");
		GetStr(L"CSName");
		GetStr(L"CSCreationClassName");
		GetStr(L"CreationClassName");
		GetStr(L"Caption");

		item.pszText = L"";
		item.iSubItem = 0;
		SendMessage(hWndTree, LVM_INSERTITEM, (WPARAM)0, (LPARAM)&item);

		if(0 == uReturn)
		  break;
	}
    if(pSvc)pSvc->Release();
    if(pLoc)pLoc->Release();
    if(pEnumerator)pEnumerator->Release();
    if(pclsObj)pclsObj->Release();
    CoUninitialize();
}

VOID GetSysSlotMaxDataWidth(wchar_t *prop)
{	wchar_t s[64];
	item.pszText = prop;
	item.iSubItem = 0;
	SendMessage(hWndTree, LVM_INSERTITEM, (WPARAM)0, (LPARAM)&item);
	item.iSubItem = 1;
	item.pszText = s;
	if(pclsObj)
	if(S_OK==pclsObj->Get(prop, 0, &vtProp, 0, 0))
	{	if(VT_NULL!=vtProp.vt)
		{	switch((int)vtProp.bstrVal)
			{	case 0:
					wsprintf(s,L"0: 8 bit");
				break;
				case 1:
					wsprintf(s,L"1: 16 bit");
				break;
				case 2:
					wsprintf(s,L"2: 32 bit");
				break;
				case 3:
					wsprintf(s,L"3: 64 bit");
				break;
				case 4:
					wsprintf(s,L"4: 128 bit");
				break;
				default:
					wsprintf(s,L"");
				break;
			}
			SendMessage(hWndTree, LVM_SETITEMTEXT, (WPARAM)0, (LPARAM)&item);
			VariantClear(&vtProp);
			return;
	}	}
	wsprintf(s,L"Dec. value, not defined ...");
	SendMessage(hWndTree, LVM_SETITEMTEXT, (WPARAM)0, (LPARAM)&item);
}

VOID GetSysSlotCrntUse(wchar_t *prop)
{	wchar_t s[64];
	item.pszText = prop;
	item.iSubItem = 0;
	SendMessage(hWndTree, LVM_INSERTITEM, (WPARAM)0, (LPARAM)&item);
	item.iSubItem = 1;
	item.pszText = s;
	if(pclsObj)
	if(S_OK==pclsObj->Get(prop, 0, &vtProp, 0, 0))
	{	if(VT_NULL!=vtProp.vt)
		{	switch((int)vtProp.bstrVal)
			{	case 0:
					wsprintf(s,L"0: Reserved");
				break;
				case 1:
					wsprintf(s,L"1: Other");
				break;
				case 2:
					wsprintf(s,L"2: Unknown");
				break;
				case 3:
					wsprintf(s,L"3: Available");
				break;
				case 4:
					wsprintf(s,L"4: In Use");
				break;
				default:
					wsprintf(s,L"");
				break;
			}
			SendMessage(hWndTree, LVM_SETITEMTEXT, (WPARAM)0, (LPARAM)&item);
			VariantClear(&vtProp);
			return;
	}	}
	wsprintf(s,L"Dec. value, not defined ...");
	SendMessage(hWndTree, LVM_SETITEMTEXT, (WPARAM)0, (LPARAM)&item);
}

VOID WMI_Motherboard_Classes_Win32_SystemSlot()
{   HRESULT hres;
    hres =  CoInitializeEx(0, COINIT_MULTITHREADED); 
    if(FAILED(hres))
        return;
    hres =  CoInitializeSecurity(
        NULL, 
        -1,                          // COM authentication
        NULL,                        // Authentication services
        NULL,                        // Reserved
        RPC_C_AUTHN_LEVEL_DEFAULT,   // Default authentication 
        RPC_C_IMP_LEVEL_IMPERSONATE, // Default Impersonation  
        NULL,                        // Authentication info
        EOAC_NONE,                   // Additional capabilities 
        NULL                         // Reserved
        );
    if (FAILED(hres))
    {	CoUninitialize();
        return;                      // Program has failed.
    }
    IWbemLocator *pLoc = NULL;
    hres = CoCreateInstance(
        CLSID_WbemLocator,             
        0, 
        CLSCTX_INPROC_SERVER, 
        IID_IWbemLocator, (LPVOID *) &pLoc);
    if (FAILED(hres))
    {   CoUninitialize();
        return;						// Program has failed.
    }
    IWbemServices *pSvc = NULL;
    hres = pLoc->ConnectServer(
         _bstr_t(L"ROOT\\CIMV2"), // Object path of WMI namespace
         NULL,                    // User name. NULL = current user
         NULL,                    // User password. NULL = current
         0,                       // Locale. NULL indicates current
         NULL,                    // Security flags.
         0,                       // Authority (e.g. Kerberos)
         0,                       // Context object 
         &pSvc                    // pointer to IWbemServices proxy
         );
    
    if (FAILED(hres))
    {   pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    hres = CoSetProxyBlanket(
       pSvc,                        // Indicates the proxy to set
       RPC_C_AUTHN_WINNT,           // RPC_C_AUTHN_xxx
       RPC_C_AUTHZ_NONE,            // RPC_C_AUTHZ_xxx
       NULL,                        // Server principal name 
       RPC_C_AUTHN_LEVEL_CALL,      // RPC_C_AUTHN_LEVEL_xxx 
       RPC_C_IMP_LEVEL_IMPERSONATE, // RPC_C_IMP_LEVEL_xxx
       NULL,                        // client identity
       EOAC_NONE                    // proxy capabilities 
    );
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    IEnumWbemClassObject* pEnumerator = NULL;
    hres = pSvc->ExecQuery(
        bstr_t("WQL"), 
        bstr_t("SELECT * FROM Win32_SystemSlot"),
        WBEM_FLAG_FORWARD_ONLY | WBEM_FLAG_RETURN_IMMEDIATELY, 
        NULL,
        &pEnumerator);
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();
        CoUninitialize();
        return;						// Program has failed.
    }
    pclsObj=0;
    ULONG uReturn = 0;
    while (pEnumerator)
    {	HRESULT hr = pEnumerator->Next(WBEM_INFINITE, 1, &pclsObj, &uReturn);
		//if(0 == uReturn)
		//  break;

		GetDecArray(L"VppMixedVoltageSupport");
		GetStr(L"Version");
		GetDecArray(L"VccMixedVoltageSupport");
		GetDec(L"ThermalRating");
		GetStr(L"Tag");
		GetBool(L"SupportsHotPlug");
		GetStr(L"Status");
		GetBool(L"SpecialPurpose");
		GetStr(L"SlotDesignation");
		GetStr(L"SKU");
		GetBool(L"Shared");
		GetStr(L"SerialNumber");
		GetStr(L"PurposeDescription");
		GetBool(L"PoweredOn");
		GetBool(L"PMESignal");
		GetStr(L"PartNumber");
		GetStr(L"OtherIdentifyingInfo");
		GetDec(L"Number");
		GetStr(L"Name");
		GetStr(L"Model");
		GetSysSlotMaxDataWidth(L"MaxDataWidth");
		GetStr(L"Manufacturer");
		GetReal(L"LengthAllowed");
		GetDatetime(L"InstallDate");
		GetReal(L"HeightAllowed");
		GetStr(L"Description");
		GetSysSlotCrntUse(L"CurrentUsage");
		GetStr(L"CreationClassName");
		GetDecArray(L"ConnectorType");
		GetStr(L"ConnectorPinout");
		GetStr(L"Caption");

		item.pszText = L"";
		item.iSubItem = 0;
		SendMessage(hWndTree, LVM_INSERTITEM, (WPARAM)0, (LPARAM)&item);

		if(0 == uReturn)
		  break;
	}
    if(pSvc)pSvc->Release();
    if(pLoc)pLoc->Release();
    if(pEnumerator)pEnumerator->Release();
    if(pclsObj)pclsObj->Release();
    CoUninitialize();
}

VOID GetUSBCntrlrProtocolSupported(wchar_t *prop)
{	wchar_t s[64];
	item.pszText = prop;
	item.iSubItem = 0;
	SendMessage(hWndTree, LVM_INSERTITEM, (WPARAM)0, (LPARAM)&item);
	item.iSubItem = 1;
	item.pszText = s;
	if(pclsObj)
	if(S_OK==pclsObj->Get(prop, 0, &vtProp, 0, 0))
	{	if(VT_NULL!=vtProp.vt)
		{	switch((int)vtProp.bstrVal)
			{	case 1: wsprintf(s,L"1: Other");break;
				case 2: wsprintf(s,L"2: Unknown");break;
				case 3:  wsprintf(s,L"3: EISA");break;
				case 4:  wsprintf(s,L"4: ISA");break;
				case 5:  wsprintf(s,L"5: PCI");break;
				case 6:  wsprintf(s,L"6: ATA or ATAPI");break;
				case 7:  wsprintf(s,L"7: Flexible Diskette");break;
				case 8:  wsprintf(s,L"8: 1496");break;
				case 9:  wsprintf(s,L"9: SCSI Parallel Interface");break;
				case 10: wsprintf(s,L"10: SCSI Fibre Channel Protocol");break;
				case 11: wsprintf(s,L"11: SCSI Serial Bus Protocol");break;
				case 12: wsprintf(s,L"12: SCSI Serial Bus Protocol-2 (1394)");break;
				case 13: wsprintf(s,L"13: SCSI Serial Storage Architecture");break;
				case 14: wsprintf(s,L"14: VESA");break;
				case 15: wsprintf(s,L"15: PCMCIA");break;
				case 16: wsprintf(s,L"16: Universal Serial Bus");break;
				case 17: wsprintf(s,L"17: Parallel Protocol");break;
				case 18: wsprintf(s,L"18: ESCON");break;
				case 19: wsprintf(s,L"19: Diagnostic");break;
				case 20: wsprintf(s,L"20: I2C");break;
				case 21: wsprintf(s,L"21: Power");break;
				case 22: wsprintf(s,L"22: HIPPI");break;
				case 23: wsprintf(s,L"23: MultiBus");break;
				case 24: wsprintf(s,L"24: VME");break;
				case 25: wsprintf(s,L"25: IPI");break;
				case 26: wsprintf(s,L"26: IEEE-488");break;
				case 27: wsprintf(s,L"27: RS232");break;
				case 28: wsprintf(s,L"28: IEEE 802.3 10BASE5");break;
				case 29: wsprintf(s,L"29: IEEE 802.3 10BASE2");break;
				case 30: wsprintf(s,L"30: IEEE 802.3 1BASE5");break;
				case 31: wsprintf(s,L"31: IEEE 802.3 10BROAD36");break;
				case 32: wsprintf(s,L"32: IEEE 802.3 100BASEVG");break;
				case 33: wsprintf(s,L"33: IEEE 802.5 Token-Ring");break;
				case 34: wsprintf(s,L"34: ANSI X3T9.5 FDDI");break;
				case 35: wsprintf(s,L"35: MCA");break;
				case 36: wsprintf(s,L"36: ESDI");break;
				case 37: wsprintf(s,L"37: IDE");break;
				case 38: wsprintf(s,L"38: CMD");break;
				case 39: wsprintf(s,L"39: ST506");break;
				case 40: wsprintf(s,L"40: DSSI");break;
				case 41: wsprintf(s,L"41: QIC2");break;
				case 42: wsprintf(s,L"42: Enhanced ATA/IDE");break;
				case 43: wsprintf(s,L"43: AGP");break;
				case 44: wsprintf(s,L"44: TWIRP (two-way infrared)");break;
				case 45: wsprintf(s,L"45: FIR (fast infrared)");break;
				case 46: wsprintf(s,L"46: SIR (serial infrared)");break;
				case 47: wsprintf(s,L"47: IrBus");break;
				default: 
					wsprintf(s,L"");
				break;
			}
			SendMessage(hWndTree, LVM_SETITEMTEXT, (WPARAM)0, (LPARAM)&item);
			VariantClear(&vtProp);
			return;
	}	}
	wsprintf(s,L"Dec. value, not defined ...");
	SendMessage(hWndTree, LVM_SETITEMTEXT, (WPARAM)0, (LPARAM)&item);
}

VOID WMI_Motherboard_Classes_Win32_USBController()
{   HRESULT hres;
    hres =  CoInitializeEx(0, COINIT_MULTITHREADED); 
    if(FAILED(hres))
        return;
    hres =  CoInitializeSecurity(
        NULL, 
        -1,                          // COM authentication
        NULL,                        // Authentication services
        NULL,                        // Reserved
        RPC_C_AUTHN_LEVEL_DEFAULT,   // Default authentication 
        RPC_C_IMP_LEVEL_IMPERSONATE, // Default Impersonation  
        NULL,                        // Authentication info
        EOAC_NONE,                   // Additional capabilities 
        NULL                         // Reserved
        );
    if (FAILED(hres))
    {	CoUninitialize();
        return;                      // Program has failed.
    }
    IWbemLocator *pLoc = NULL;
    hres = CoCreateInstance(
        CLSID_WbemLocator,             
        0, 
        CLSCTX_INPROC_SERVER, 
        IID_IWbemLocator, (LPVOID *) &pLoc);
    if (FAILED(hres))
    {   CoUninitialize();
        return;						// Program has failed.
    }
    IWbemServices *pSvc = NULL;
    hres = pLoc->ConnectServer(
         _bstr_t(L"ROOT\\CIMV2"), // Object path of WMI namespace
         NULL,                    // User name. NULL = current user
         NULL,                    // User password. NULL = current
         0,                       // Locale. NULL indicates current
         NULL,                    // Security flags.
         0,                       // Authority (e.g. Kerberos)
         0,                       // Context object 
         &pSvc                    // pointer to IWbemServices proxy
         );
    
    if (FAILED(hres))
    {   pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    hres = CoSetProxyBlanket(
       pSvc,                        // Indicates the proxy to set
       RPC_C_AUTHN_WINNT,           // RPC_C_AUTHN_xxx
       RPC_C_AUTHZ_NONE,            // RPC_C_AUTHZ_xxx
       NULL,                        // Server principal name 
       RPC_C_AUTHN_LEVEL_CALL,      // RPC_C_AUTHN_LEVEL_xxx 
       RPC_C_IMP_LEVEL_IMPERSONATE, // RPC_C_IMP_LEVEL_xxx
       NULL,                        // client identity
       EOAC_NONE                    // proxy capabilities 
    );
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    IEnumWbemClassObject* pEnumerator = NULL;
    hres = pSvc->ExecQuery(
        bstr_t("WQL"), 
        bstr_t("SELECT * FROM Win32_USBController"),
        WBEM_FLAG_FORWARD_ONLY | WBEM_FLAG_RETURN_IMMEDIATELY, 
        NULL,
        &pEnumerator);
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();
        CoUninitialize();
        return;						// Program has failed.
    }
    pclsObj=0;
    ULONG uReturn = 0;
    while (pEnumerator)
    {	HRESULT hr = pEnumerator->Next(WBEM_INFINITE, 1, &pclsObj, &uReturn);
		//if(0 == uReturn)
		//  break;

		GetDatetime(L"TimeOfLastReset");
		GetStr(L"SystemName");
		GetStr(L"SystemCreationClassName");
		GetDec(L"StatusInfo");
		GetStr(L"Status");
		GetUSBCntrlrProtocolSupported(L"ProtocolSupported");
		GetBool(L"PowerManagementSupported");
		GetDecArray(L"PowerManagementCapabilities");
		GetStr(L"PNPDeviceID");
		GetStr(L"Name");
		GetDec(L"MaxNumberControlled");
		GetStr(L"Manufacturer");
		GetDec(L"LastErrorCode");
		GetDatetime(L"InstallDate");
		GetStr(L"ErrorDescription");
		GetBool(L"ErrorCleared");
		GetStr(L"DeviceID");
		GetStr(L"Description");
		GetStr(L"CreationClassName");
		GetBool(L"ConfigManagerUserConfig");
		GetConfigManagerErrorCode(L"ConfigManagerErrorCode");
		GetStr(L"Caption");
		GetCacheMemoryAvailability(L"Availability");

		item.pszText = L"";
		item.iSubItem = 0;
		SendMessage(hWndTree, LVM_INSERTITEM, (WPARAM)0, (LPARAM)&item);

		if(0 == uReturn)
		  break;
	}
    if(pSvc)pSvc->Release();
    if(pLoc)pLoc->Release();
    if(pEnumerator)pEnumerator->Release();
    if(pclsObj)pclsObj->Release();
    CoUninitialize();
}

VOID GetUSBCntlrAccessState(wchar_t *prop)
{	wchar_t s[64];
	item.pszText = prop;
	item.iSubItem = 0;
	SendMessage(hWndTree, LVM_INSERTITEM, (WPARAM)0, (LPARAM)&item);
	item.iSubItem = 1;
	item.pszText = s;
	if(pclsObj)
	if(S_OK==pclsObj->Get(prop, 0, &vtProp, 0, 0))
	{	if(VT_NULL!=vtProp.vt)
		{	switch((int)vtProp.bstrVal)
			{	case 0: wsprintf(s,L"0: Unknown");break;
				case 1: wsprintf(s,L"1: Active");break;
				case 2: wsprintf(s,L"2: Inactive");break;
				default: 
					wsprintf(s,L"");
				break;
			}
			SendMessage(hWndTree, LVM_SETITEMTEXT, (WPARAM)0, (LPARAM)&item);
			VariantClear(&vtProp);
			return;
	}	}
	wsprintf(s,L"Dec. value, not defined ...");
	SendMessage(hWndTree, LVM_SETITEMTEXT, (WPARAM)0, (LPARAM)&item);
}

VOID WMI_Motherboard_Classes_Win32_USBControllerDevice()
{   HRESULT hres;
    hres =  CoInitializeEx(0, COINIT_MULTITHREADED); 
    if(FAILED(hres))
        return;
    hres =  CoInitializeSecurity(
        NULL, 
        -1,                          // COM authentication
        NULL,                        // Authentication services
        NULL,                        // Reserved
        RPC_C_AUTHN_LEVEL_DEFAULT,   // Default authentication 
        RPC_C_IMP_LEVEL_IMPERSONATE, // Default Impersonation  
        NULL,                        // Authentication info
        EOAC_NONE,                   // Additional capabilities 
        NULL                         // Reserved
        );
    if (FAILED(hres))
    {	CoUninitialize();
        return;                      // Program has failed.
    }
    IWbemLocator *pLoc = NULL;
    hres = CoCreateInstance(
        CLSID_WbemLocator,             
        0, 
        CLSCTX_INPROC_SERVER, 
        IID_IWbemLocator, (LPVOID *) &pLoc);
    if (FAILED(hres))
    {   CoUninitialize();
        return;						// Program has failed.
    }
    IWbemServices *pSvc = NULL;
    hres = pLoc->ConnectServer(
         _bstr_t(L"ROOT\\CIMV2"), // Object path of WMI namespace
         NULL,                    // User name. NULL = current user
         NULL,                    // User password. NULL = current
         0,                       // Locale. NULL indicates current
         NULL,                    // Security flags.
         0,                       // Authority (e.g. Kerberos)
         0,                       // Context object 
         &pSvc                    // pointer to IWbemServices proxy
         );
    
    if (FAILED(hres))
    {   pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    hres = CoSetProxyBlanket(
       pSvc,                        // Indicates the proxy to set
       RPC_C_AUTHN_WINNT,           // RPC_C_AUTHN_xxx
       RPC_C_AUTHZ_NONE,            // RPC_C_AUTHZ_xxx
       NULL,                        // Server principal name 
       RPC_C_AUTHN_LEVEL_CALL,      // RPC_C_AUTHN_LEVEL_xxx 
       RPC_C_IMP_LEVEL_IMPERSONATE, // RPC_C_IMP_LEVEL_xxx
       NULL,                        // client identity
       EOAC_NONE                    // proxy capabilities 
    );
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    IEnumWbemClassObject* pEnumerator = NULL;
    hres = pSvc->ExecQuery(
        bstr_t("WQL"), 
        bstr_t("SELECT * FROM Win32_USBControllerDevice"),
        WBEM_FLAG_FORWARD_ONLY | WBEM_FLAG_RETURN_IMMEDIATELY, 
        NULL,
        &pEnumerator);
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();
        CoUninitialize();
        return;						// Program has failed.
    }
    pclsObj=0;
    ULONG uReturn = 0;
    while (pEnumerator)
    {	HRESULT hr = pEnumerator->Next(WBEM_INFINITE, 1, &pclsObj, &uReturn);
		//if(0 == uReturn)
		//  break;

		GetDec(L"NumberOfSoftResets");
		GetDec(L"NumberOfHardResets");
		GetDec(L"NegotiatedSpeed");
		GetDec(L"NegotiatedDataWidth");
		GetStr(L"Dependent");//CIM_LogicalDevice ref Dependent;
		GetStr(L"Antecedent");//CIM_USBController ref Antecedent;
		GetUSBCntlrAccessState(L"AccessState");

		item.pszText = L"";
		item.iSubItem = 0;
		SendMessage(hWndTree, LVM_INSERTITEM, (WPARAM)0, (LPARAM)&item);

		if(0 == uReturn)
		  break;
	}
    if(pSvc)pSvc->Release();
    if(pLoc)pLoc->Release();
    if(pEnumerator)pEnumerator->Release();
    if(pclsObj)pclsObj->Release();
    CoUninitialize();
}

VOID WMI_Motherboard_Classes_Win32_USBHub()
{   HRESULT hres;
    hres =  CoInitializeEx(0, COINIT_MULTITHREADED); 
    if(FAILED(hres))
        return;
    hres =  CoInitializeSecurity(
        NULL, 
        -1,                          // COM authentication
        NULL,                        // Authentication services
        NULL,                        // Reserved
        RPC_C_AUTHN_LEVEL_DEFAULT,   // Default authentication 
        RPC_C_IMP_LEVEL_IMPERSONATE, // Default Impersonation  
        NULL,                        // Authentication info
        EOAC_NONE,                   // Additional capabilities 
        NULL                         // Reserved
        );
    if (FAILED(hres))
    {	CoUninitialize();
        return;                      // Program has failed.
    }
    IWbemLocator *pLoc = NULL;
    hres = CoCreateInstance(
        CLSID_WbemLocator,             
        0, 
        CLSCTX_INPROC_SERVER, 
        IID_IWbemLocator, (LPVOID *) &pLoc);
    if (FAILED(hres))
    {   CoUninitialize();
        return;						// Program has failed.
    }
    IWbemServices *pSvc = NULL;
    hres = pLoc->ConnectServer(
         _bstr_t(L"ROOT\\CIMV2"), // Object path of WMI namespace
         NULL,                    // User name. NULL = current user
         NULL,                    // User password. NULL = current
         0,                       // Locale. NULL indicates current
         NULL,                    // Security flags.
         0,                       // Authority (e.g. Kerberos)
         0,                       // Context object 
         &pSvc                    // pointer to IWbemServices proxy
         );
    
    if (FAILED(hres))
    {   pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    hres = CoSetProxyBlanket(
       pSvc,                        // Indicates the proxy to set
       RPC_C_AUTHN_WINNT,           // RPC_C_AUTHN_xxx
       RPC_C_AUTHZ_NONE,            // RPC_C_AUTHZ_xxx
       NULL,                        // Server principal name 
       RPC_C_AUTHN_LEVEL_CALL,      // RPC_C_AUTHN_LEVEL_xxx 
       RPC_C_IMP_LEVEL_IMPERSONATE, // RPC_C_IMP_LEVEL_xxx
       NULL,                        // client identity
       EOAC_NONE                    // proxy capabilities 
    );
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    IEnumWbemClassObject* pEnumerator = NULL;
    hres = pSvc->ExecQuery(
        bstr_t("WQL"), 
        bstr_t("SELECT * FROM Win32_USBHub"),
        WBEM_FLAG_FORWARD_ONLY | WBEM_FLAG_RETURN_IMMEDIATELY, 
        NULL,
        &pEnumerator);
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();
        CoUninitialize();
        return;						// Program has failed.
    }
    pclsObj=0;
    ULONG uReturn = 0;
    while (pEnumerator)
    {	HRESULT hr = pEnumerator->Next(WBEM_INFINITE, 1, &pclsObj, &uReturn);
		//if(0 == uReturn)
		//  break;

		GetDec(L"USBVersion");
		GetStr(L"SystemName");
		GetStr(L"SystemCreationClassName");
		GetChar(L"SubclassCode");
		GetDec(L"StatusInfo");
		GetStr(L"Status");
		GetChar(L"ProtocolCode");
		GetBool(L"PowerManagementSupported");
		GetDecArray(L"PowerManagementCapabilities");
		GetStr(L"PNPDeviceID");
		GetChar(L"NumberOfPorts");
		GetChar(L"NumberOfConfigs");
		GetStr(L"Name");
		GetDec(L"LastErrorCode");
		GetDatetime(L"InstallDate");
		GetBool(L"GangSwitched");
		GetStr(L"ErrorDescription");
		GetBool(L"ErrorCleared");
		GetStr(L"DeviceID");
		GetStr(L"Description");
		GetChar(L"CurrentConfigValue");
		GetChar(L"CurrentAlternativeSettings");
		GetStr(L"CreationClassName");
		GetBool(L"ConfigManagerUserCode");
		GetConfigManagerErrorCode(L"ConfigManagerErrorCode");
		GetChar(L"ClassCode");
		GetStr(L"Caption");
		GetCacheMemoryAvailability(L"Availability");

		item.pszText = L"";
		item.iSubItem = 0;
		SendMessage(hWndTree, LVM_INSERTITEM, (WPARAM)0, (LPARAM)&item);

		if(0 == uReturn)
		  break;
	}
    if(pSvc)pSvc->Release();
    if(pLoc)pLoc->Release();
    if(pEnumerator)pEnumerator->Release();
    if(pclsObj)pclsObj->Release();
    CoUninitialize();
}