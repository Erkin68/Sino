#include "windows.h"
#include "commctrl.h"
#include <Wbemidl.h>

extern HINSTANCE hInst;
extern HWND hWnd,hWndTreeConf,hWndTree;
extern HFONT fnt;
extern int language;

HTREEITEM AddItemToTree(HWND,LPWSTR,int,int,BOOL);
VOID MessageProcess();

extern VARIANT vtProp;
extern LVITEM item;
extern IWbemClassObject *pclsObj;
VOID GetBool(wchar_t*);
VOID GetChar(wchar_t*);
VOID GetDec(wchar_t*);
VOID GetDecArg1(wchar_t*,wchar_t*);
VOID GetDecX64(wchar_t*);
VOID GetReal(wchar_t*);
VOID GetStr(wchar_t*);
VOID GetDecArray(wchar_t*);
VOID GetStrArray(wchar_t*);
VOID GetDatetime(wchar_t*);

VOID GetConfigManagerErrorCode(wchar_t*);
VOID GetCacheMemoryAvailability(wchar_t*);

VOID WMI_Cooling_Device_Classes_Win32_Fan();
VOID WMI_Cooling_Device_Classes_Win32_HeatPipe();
VOID WMI_Cooling_Device_Classes_Win32_Refrigeration();
VOID WMI_Cooling_Device_Classes_Win32_TemperatureProbe();

VOID WMI_Input_Device_Classes_Win32_Keyboard();
VOID WMI_Input_Device_Classes_Win32_PointingDevice();

VOID WMI_Mass_Storage_Classes_Win32_AutochkSetting();
VOID WMI_Mass_Storage_Classes_Win32_CDROMDrive();
VOID WMI_Mass_Storage_Classes_Win32_DiskDrive();
VOID WMI_Mass_Storage_Classes_Win32_FloppyDrive();
VOID WMI_Mass_Storage_Classes_Win32_PhysicalMedia();
VOID WMI_Mass_Storage_Classes_Win32_TapeDrive();

VOID WMI_Motherboard_Classes_Win32_1394Controller();
VOID WMI_Motherboard_Classes_Win32_1394ControllerDevice();
VOID WMI_Motherboard_Classes_Win32_AllocatedResource();
VOID WMI_Motherboard_Classes_Win32_AssociatedProcessorMemory();
VOID WMI_Motherboard_Classes_Win32_BaseBoard();
VOID WMI_Motherboard_Classes_Win32_BIOS();
VOID WMI_Motherboard_Classes_Win32_Bus();
VOID WMI_Motherboard_Classes_Win32_CacheMemory();
VOID WMI_Motherboard_Classes_Win32_ControllerHasHub();
VOID WMI_Motherboard_Classes_Win32_DeviceBus();
VOID WMI_Motherboard_Classes_Win32_DeviceMemoryAddress();
VOID WMI_Motherboard_Classes_Win32_DeviceSettings();
VOID WMI_Motherboard_Classes_Win32_DMAChannel();
VOID WMI_Motherboard_Classes_Win32_FloppyController();
VOID WMI_Motherboard_Classes_Win32_IDEController();
VOID WMI_Motherboard_Classes_Win32_IDEControllerDevice();
VOID WMI_Motherboard_Classes_Win32_InfraredDevice();
VOID WMI_Motherboard_Classes_Win32_IRQResource();
VOID WMI_Motherboard_Classes_Win32_MemoryArray();
VOID WMI_Motherboard_Classes_Win32_MemoryArrayLocation();
VOID WMI_Motherboard_Classes_Win32_MemoryDevice();
VOID WMI_Motherboard_Classes_Win32_MemoryDeviceArray();
VOID WMI_Motherboard_Classes_Win32_MemoryDeviceLocation();
VOID WMI_Motherboard_Classes_Win32_MotherboardDevice();
VOID WMI_Motherboard_Classes_Win32_OnBoardDevice();
VOID WMI_Motherboard_Classes_Win32_ParallelPort();
VOID WMI_Motherboard_Classes_Win32_PCMCIAController();
VOID WMI_Motherboard_Classes_Win32_PhysicalMemory();
VOID WMI_Motherboard_Classes_Win32_PhysicalMemoryArray();
VOID WMI_Motherboard_Classes_Win32_PhysicalMemoryLocation();
VOID WMI_Motherboard_Classes_Win32_PnPAllocatedResource();
VOID WMI_Motherboard_Classes_Win32_PnPDevice();
VOID WMI_Motherboard_Classes_Win32_PnPEntity();
VOID WMI_Motherboard_Classes_Win32_PortConnector();
VOID WMI_Motherboard_Classes_Win32_PortResource();
VOID WMI_Motherboard_Classes_Win32_Processor();
VOID WMI_Motherboard_Classes_Win32_SCSIController();
VOID WMI_Motherboard_Classes_Win32_SCSIControllerDevice();
VOID WMI_Motherboard_Classes_Win32_SerialPort();
VOID WMI_Motherboard_Classes_Win32_SerialPortConfiguration();
VOID WMI_Motherboard_Classes_Win32_SerialPortSetting();
VOID WMI_Motherboard_Classes_Win32_SMBIOSMemory();
VOID WMI_Motherboard_Classes_Win32_SoundDevice();
VOID WMI_Motherboard_Classes_Win32_SystemBIOS();
VOID WMI_Motherboard_Classes_Win32_SystemDriverPNPEntity();
VOID WMI_Motherboard_Classes_Win32_SystemEnclosure();
VOID WMI_Motherboard_Classes_Win32_SystemMemoryResource();
VOID WMI_Motherboard_Classes_Win32_SystemSlot();
VOID WMI_Motherboard_Classes_Win32_USBController();
VOID WMI_Motherboard_Classes_Win32_USBControllerDevice();
VOID WMI_Motherboard_Classes_Win32_USBHub();
VOID WMI_Motherboard_Classes_Win32_NetworkAdapter();
VOID WMI_Motherboard_Classes_Win32_NetworkAdapterConfiguration();
VOID WMI_Motherboard_Classes_Win32_NetworkAdapterSetting();

VOID WMI_Motherboard_Classes_Win32_AssociatedBattery();
VOID WMI_Motherboard_Classes_Win32_Battery();
VOID WMI_Motherboard_Classes_Win32_CurrentProbe();
VOID WMI_Motherboard_Classes_Win32_PortableBattery();
VOID WMI_Motherboard_Classes_Win32_PowerManagementEvent();
VOID WMI_Motherboard_Classes_Win32_UninterruptiblePowerSupply();
VOID WMI_Motherboard_Classes_Win32_VoltageProbe();

VOID WMI_Motherboard_Classes_Win32_DriverForDevice();
VOID WMI_Motherboard_Classes_Win32_Printer();
VOID WMI_Motherboard_Classes_Win32_PrinterConfiguration();
VOID WMI_Motherboard_Classes_Win32_PrinterController();
VOID WMI_Motherboard_Classes_Win32_PrinterDriver();
VOID WMI_Motherboard_Classes_Win32_PrinterDriverDll();
VOID WMI_Motherboard_Classes_Win32_PrinterSetting();
VOID WMI_Motherboard_Classes_Win32_PrintJob();
VOID WMI_Motherboard_Classes_Win32_TCPIPPrinterPort();
VOID WMI_Motherboard_Classes_Win32_PotsModem();
VOID WMI_Motherboard_Classes_Win32_POTSModemToSerialPort();

VOID WMI_Motherboard_Classes_Win32_DesktopMonitor();
VOID WMI_Motherboard_Classes_Win32_DisplayConfiguration();
VOID WMI_Motherboard_Classes_Win32_DisplayControllerConfiguration();
VOID WMI_Motherboard_Classes_Win32_VideoConfiguration();
VOID WMI_Motherboard_Classes_Win32_VideoController();
VOID WMI_Motherboard_Classes_Win32_VideoSettings();