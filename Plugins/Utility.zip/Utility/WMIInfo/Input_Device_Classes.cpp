#define _WIN32_DCOM
#include <iostream>
using namespace std;
#include <comdef.h>
#include "WMIInfo.h"

# pragma comment(lib, "wbemuuid.lib")


extern HWND hWndTree;


VOID GetConfigManagerErrorCode(wchar_t *prop)
{	wchar_t s[128];
	item.pszText = prop;
	item.iSubItem = 0;
	SendMessage(hWndTree, LVM_INSERTITEM, (WPARAM)0, (LPARAM)&item);
	item.iSubItem = 1;
	item.pszText = s;
	if(pclsObj)
	if(S_OK==pclsObj->Get(prop, 0, &vtProp, 0, 0))
	{	if(VT_NULL!=vtProp.vt)
		{	switch((int)vtProp.bstrVal)
			{	case 0:
					wsprintf(s,L"0: Device is working properly.");
				break;
				case 1:
					wsprintf(s,L"1: Device is not configured correctly.");
				break;
				case 2:
					wsprintf(s,L"2: Windows cannot load the driver for this device.");
				break;
				case 3:
					wsprintf(s,L"3: Driver for this device might be corrupted, or the system may be low on memory or other resources.");
				break;
				case 4:
					wsprintf(s,L"4: Device is not working properly. One of its drivers or the registry might be corrupted.");
				break;
				case 5:
					wsprintf(s,L"5: Driver for the device requires a resource that Windows cannot manage.");
				break;
				case 6:
					wsprintf(s,L"6: Boot configuration for the device conflicts with other devices.");
				break;
				case 7:
					wsprintf(s,L"7: Cannot filter.");
				break;
				case 8:
					wsprintf(s,L"8: Driver loader for the device is missing.");
				break;
				case 9:
					wsprintf(s,L"9: Device is not working properly. The controlling firmware is incorrectly reporting the resources for the device.");
				break;
				case 10:
					wsprintf(s,L"10: Device cannot start.");
				break;
				case 11:
					wsprintf(s,L"11: Device failed.");
				break;
				case 12:
					wsprintf(s,L"12: Device cannot find enough free resources to use.");
				break;
				case 13:
					wsprintf(s,L"13: Windows cannot verify the device's resources.");
				break;
				case 14:
					wsprintf(s,L"14: Device cannot work properly until the computer is restarted.");
				break;
				case 15:
					wsprintf(s,L"15: Device is not working properly due to a possible re-enumeration problem.");
				break;
				case 16:
					wsprintf(s,L"16: Windows cannot identify all of the resources that the device uses.");
				break;
				case 17:
					wsprintf(s,L"17: Device is requesting an unknown resource type.");
				break;
				case 18:
					wsprintf(s,L"18: Device drivers must be reinstalled.");
				break;
				case 19:
					wsprintf(s,L"19: Failure using the VxD loader.");
				break;
				case 20:
					wsprintf(s,L"20: Registry might be corrupted.");
				break;
				case 21:
					wsprintf(s,L"21: System failure. If changing the device driver is ineffective, see the hardware documentation. Windows is removing the device.");
				break;
				case 22:
					wsprintf(s,L"22: Device is disabled.");
				break;
				case 23:
					wsprintf(s,L"23: System failure. If changing the device driver is ineffective, see the hardware documentation.");
				break;
				case 24:
					wsprintf(s,L"24: Device is not present, not working properly, or does not have all of its drivers installed.");
				break;
				case 25:
					wsprintf(s,L"25: Windows is still setting up the device.");
				break;
				case 26:
					wsprintf(s,L"26: Windows is still setting up the device.");
				break;
				case 27:
					wsprintf(s,L"27: Device does not have valid log configuration.");
				break;
				case 28:
					wsprintf(s,L"28: Device drivers are not installed.");
				break;
				case 29:
					wsprintf(s,L"29: Device is disabled. The device firmware did not provide the required resources.");
				break;
				case 30:
					wsprintf(s,L"30: Device is using an IRQ resource that another device is using.");
				break;
				case 31:
					wsprintf(s,L"30: Device is not working properly. Windows cannot load the required device drivers.");
				break;
				default:
					wsprintf(s,L"");
				break;
			}
			SendMessage(hWndTree, LVM_SETITEMTEXT, (WPARAM)0, (LPARAM)&item);
			VariantClear(&vtProp);
			return;
	}	}
	wsprintf(s,L"Dec. value, not defined ...");
	SendMessage(hWndTree, LVM_SETITEMTEXT, (WPARAM)0, (LPARAM)&item);
}

VOID WMI_Input_Device_Classes_Win32_Keyboard()
{   HRESULT hres;
    hres =  CoInitializeEx(0, COINIT_MULTITHREADED); 
    if(FAILED(hres))
        return;
    hres =  CoInitializeSecurity(
        NULL, 
        -1,                          // COM authentication
        NULL,                        // Authentication services
        NULL,                        // Reserved
        RPC_C_AUTHN_LEVEL_DEFAULT,   // Default authentication 
        RPC_C_IMP_LEVEL_IMPERSONATE, // Default Impersonation  
        NULL,                        // Authentication info
        EOAC_NONE,                   // Additional capabilities 
        NULL                         // Reserved
        );
    if (FAILED(hres))
    {	CoUninitialize();
        return;                      // Program has failed.
    }
    IWbemLocator *pLoc = NULL;
    hres = CoCreateInstance(
        CLSID_WbemLocator,             
        0, 
        CLSCTX_INPROC_SERVER, 
        IID_IWbemLocator, (LPVOID *) &pLoc);
    if (FAILED(hres))
    {   CoUninitialize();
        return;						// Program has failed.
    }
    IWbemServices *pSvc = NULL;
    hres = pLoc->ConnectServer(
         _bstr_t(L"ROOT\\CIMV2"), // Object path of WMI namespace
         NULL,                    // User name. NULL = current user
         NULL,                    // User password. NULL = current
         0,                       // Locale. NULL indicates current
         NULL,                    // Security flags.
         0,                       // Authority (e.g. Kerberos)
         0,                       // Context object 
         &pSvc                    // pointer to IWbemServices proxy
         );
    
    if (FAILED(hres))
    {   pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    hres = CoSetProxyBlanket(
       pSvc,                        // Indicates the proxy to set
       RPC_C_AUTHN_WINNT,           // RPC_C_AUTHN_xxx
       RPC_C_AUTHZ_NONE,            // RPC_C_AUTHZ_xxx
       NULL,                        // Server principal name 
       RPC_C_AUTHN_LEVEL_CALL,      // RPC_C_AUTHN_LEVEL_xxx 
       RPC_C_IMP_LEVEL_IMPERSONATE, // RPC_C_IMP_LEVEL_xxx
       NULL,                        // client identity
       EOAC_NONE                    // proxy capabilities 
    );
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    IEnumWbemClassObject* pEnumerator = NULL;
    hres = pSvc->ExecQuery(
        bstr_t("WQL"), 
        bstr_t("SELECT * FROM Win32_Keyboard"),
        WBEM_FLAG_FORWARD_ONLY | WBEM_FLAG_RETURN_IMMEDIATELY, 
        NULL,
        &pEnumerator);
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();
        CoUninitialize();
        return;						// Program has failed.
    }
    pclsObj=0;
    ULONG uReturn = 0;
    while (pEnumerator)
    {	HRESULT hr = pEnumerator->Next(WBEM_INFINITE, 1, &pclsObj, &uReturn);
		//if(0 == uReturn)
		//  break;
		
		GetStr(L"SystemName");
		GetStr(L"SystemCreationClassName");
		GetDec(L"StatusInfo");
		GetStr(L"Status");
 		GetBool(L"PowerManagementSupported");
		GetDecArray(L"PowerManagementCapabilities");
		GetStr(L"PNPDeviceID");
		GetDec(L"Password");
		GetDec(L"NumberOfFunctionKeys");
		GetStr(L"Name");
		GetStr(L"Layout");
		GetDec(L"LastErrorCode");
		GetBool(L"IsLocked");
		GetStr(L"InstallDate");
		GetBool(L"ErrorCleared");
		GetStr(L"DeviceID");
		GetStr(L"Description");
		GetConfigManagerErrorCode(L"ConfigManagerErrorCode");
		GetStr(L"CreationClassName");
		GetBool(L"ConfigManagerUserConfig");
		GetStr(L"Caption");
		GetDec(L"Availability");

		item.pszText = L"";
		item.iSubItem = 0;
		SendMessage(hWndTree, LVM_INSERTITEM, (WPARAM)0, (LPARAM)&item);

		if(0 == uReturn)
		  break;
	}
    if(pSvc)pSvc->Release();
    if(pLoc)pLoc->Release();
    if(pEnumerator)pEnumerator->Release();
    if(pclsObj)pclsObj->Release();
    CoUninitialize();
}

VOID GetPointType(wchar_t *prop)
{	wchar_t s[64];
	item.pszText = prop;
	item.iSubItem = 0;
	SendMessage(hWndTree, LVM_INSERTITEM, (WPARAM)0, (LPARAM)&item);
	item.iSubItem = 1;
	item.pszText = s;
	if(pclsObj)
	if(S_OK==pclsObj->Get(prop, 0, &vtProp, 0, 0))
	{	if(VT_NULL!=vtProp.vt)
		{	switch((int)vtProp.bstrVal)
			{	case 1:
					wsprintf(s,L"1: Other.");
				break;
				case 2:
					wsprintf(s,L"2: Unknown.");
				break;
				case 3:
					wsprintf(s,L"3: Mouse.");
				break;
				case 4:
					wsprintf(s,L"4: Track Ball.");
				break;
				case 5:
					wsprintf(s,L"5: Track Point.");
				break;
				case 6:
					wsprintf(s,L"6: Glide Point.");
				break;
				case 7:
					wsprintf(s,L"7: Touch Pad.");
				break;
				case 8:
					wsprintf(s,L"8: Touch Screen.");
				break;
				case 9:
					wsprintf(s,L"9: Mouse - Optical Sensor.");
				break;
				default:
					wsprintf(s,L"");
				break;
			}
			SendMessage(hWndTree, LVM_SETITEMTEXT, (WPARAM)0, (LPARAM)&item);
			VariantClear(&vtProp);
			return;
	}	}
	wsprintf(s,L"Dec. value, not defined ...");
	SendMessage(hWndTree, LVM_SETITEMTEXT, (WPARAM)0, (LPARAM)&item);
}

VOID WMI_Input_Device_Classes_Win32_PointingDevice()
{   HRESULT hres;
    hres =  CoInitializeEx(0, COINIT_MULTITHREADED); 
    if(FAILED(hres))
        return;
    hres =  CoInitializeSecurity(
        NULL, 
        -1,                          // COM authentication
        NULL,                        // Authentication services
        NULL,                        // Reserved
        RPC_C_AUTHN_LEVEL_DEFAULT,   // Default authentication 
        RPC_C_IMP_LEVEL_IMPERSONATE, // Default Impersonation  
        NULL,                        // Authentication info
        EOAC_NONE,                   // Additional capabilities 
        NULL                         // Reserved
        );
    if (FAILED(hres))
    {	CoUninitialize();
        return;                      // Program has failed.
    }
    IWbemLocator *pLoc = NULL;
    hres = CoCreateInstance(
        CLSID_WbemLocator,             
        0, 
        CLSCTX_INPROC_SERVER, 
        IID_IWbemLocator, (LPVOID *) &pLoc);
    if (FAILED(hres))
    {   CoUninitialize();
        return;						// Program has failed.
    }
    IWbemServices *pSvc = NULL;
    hres = pLoc->ConnectServer(
         _bstr_t(L"ROOT\\CIMV2"), // Object path of WMI namespace
         NULL,                    // User name. NULL = current user
         NULL,                    // User password. NULL = current
         0,                       // Locale. NULL indicates current
         NULL,                    // Security flags.
         0,                       // Authority (e.g. Kerberos)
         0,                       // Context object 
         &pSvc                    // pointer to IWbemServices proxy
         );
    
    if (FAILED(hres))
    {   pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    hres = CoSetProxyBlanket(
       pSvc,                        // Indicates the proxy to set
       RPC_C_AUTHN_WINNT,           // RPC_C_AUTHN_xxx
       RPC_C_AUTHZ_NONE,            // RPC_C_AUTHZ_xxx
       NULL,                        // Server principal name 
       RPC_C_AUTHN_LEVEL_CALL,      // RPC_C_AUTHN_LEVEL_xxx 
       RPC_C_IMP_LEVEL_IMPERSONATE, // RPC_C_IMP_LEVEL_xxx
       NULL,                        // client identity
       EOAC_NONE                    // proxy capabilities 
    );
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    IEnumWbemClassObject* pEnumerator = NULL;
    hres = pSvc->ExecQuery(
        bstr_t("WQL"), 
        bstr_t("SELECT * FROM Win32_PointingDevice"),
        WBEM_FLAG_FORWARD_ONLY | WBEM_FLAG_RETURN_IMMEDIATELY, 
        NULL,
        &pEnumerator);
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();
        CoUninitialize();
        return;						// Program has failed.
    }
    pclsObj=0;
    ULONG uReturn = 0;
    while (pEnumerator)
    {	HRESULT hr = pEnumerator->Next(WBEM_INFINITE, 1, &pclsObj, &uReturn);
        //if(0 == uReturn)
		//   break;
		
		GetStr(L"SystemName");
 		GetStr(L"SystemCreationClassName");
		GetDec(L"Synch");
		GetDec(L"StatusInfo");
		GetStr(L"Status");
		GetDec(L"SampleRate");
		GetDec(L"Resolution");
		GetDec(L"QuadSpeedThreshold");
		GetBool(L"PowerManagementSupported");
		GetDecArray(L"PowerManagementCapabilities");
		GetPointType(L"PointingType");
		GetStr(L"PNPDeviceID");
		GetChar(L"NumberOfButtons");
		GetStr(L"Name");
		GetStr(L"Manufacturer");
		GetDec(L"LastErrorCode");
		GetBool(L"IsLocked");
		GetStr(L"InstallDate");
		GetStr(L"InfSection");
		GetStr(L"InfFileName");
		GetStr(L"HardwareType");
		GetDec(L"Handedness");
		GetStr(L"ErrorDescription");
		GetBool(L"ErrorCleared");
		GetDec(L"DoubleSpeedThreshold");
		GetDec(L"DeviceInterface");
		GetStr(L"DeviceID");
		GetStr(L"Description");
		GetStr(L"CreationClassName");
		GetBool(L"ConfigManagerUserConfig");
		GetConfigManagerErrorCode(L"ConfigManagerErrorCode");
		GetStr(L"Caption");
		GetDec(L"Availability");

		item.pszText = L"";
		item.iSubItem = 0;
		SendMessage(hWndTree, LVM_INSERTITEM, (WPARAM)0, (LPARAM)&item);

		if(0 == uReturn)
		  break;
	}
    if(pSvc)pSvc->Release();
    if(pLoc)pLoc->Release();
    if(pEnumerator)pEnumerator->Release();
    if(pclsObj)pclsObj->Release();
    CoUninitialize();
}