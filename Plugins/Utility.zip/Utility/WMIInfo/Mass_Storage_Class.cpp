#define _WIN32_DCOM
#include <iostream>
using namespace std;
#include <comdef.h>
#include "WMIInfo.h"

# pragma comment(lib, "wbemuuid.lib")


extern HWND hWndTree;


VOID WMI_Mass_Storage_Classes_Win32_AutochkSetting()
{   HRESULT hres;
    hres =  CoInitializeEx(0, COINIT_MULTITHREADED); 
    if(FAILED(hres))
        return;
    hres =  CoInitializeSecurity(
        NULL, 
        -1,                          // COM authentication
        NULL,                        // Authentication services
        NULL,                        // Reserved
        RPC_C_AUTHN_LEVEL_DEFAULT,   // Default authentication 
        RPC_C_IMP_LEVEL_IMPERSONATE, // Default Impersonation  
        NULL,                        // Authentication info
        EOAC_NONE,                   // Additional capabilities 
        NULL                         // Reserved
        );
    if (FAILED(hres))
    {	CoUninitialize();
        return;                      // Program has failed.
    }
    IWbemLocator *pLoc = NULL;
    hres = CoCreateInstance(
        CLSID_WbemLocator,             
        0, 
        CLSCTX_INPROC_SERVER, 
        IID_IWbemLocator, (LPVOID *) &pLoc);
    if (FAILED(hres))
    {   CoUninitialize();
        return;						// Program has failed.
    }
    IWbemServices *pSvc = NULL;
    hres = pLoc->ConnectServer(
         _bstr_t(L"ROOT\\CIMV2"), // Object path of WMI namespace
         NULL,                    // User name. NULL = current user
         NULL,                    // User password. NULL = current
         0,                       // Locale. NULL indicates current
         NULL,                    // Security flags.
         0,                       // Authority (e.g. Kerberos)
         0,                       // Context object 
         &pSvc                    // pointer to IWbemServices proxy
         );
    
    if (FAILED(hres))
    {   pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    hres = CoSetProxyBlanket(
       pSvc,                        // Indicates the proxy to set
       RPC_C_AUTHN_WINNT,           // RPC_C_AUTHN_xxx
       RPC_C_AUTHZ_NONE,            // RPC_C_AUTHZ_xxx
       NULL,                        // Server principal name 
       RPC_C_AUTHN_LEVEL_CALL,      // RPC_C_AUTHN_LEVEL_xxx 
       RPC_C_IMP_LEVEL_IMPERSONATE, // RPC_C_IMP_LEVEL_xxx
       NULL,                        // client identity
       EOAC_NONE                    // proxy capabilities 
    );
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    IEnumWbemClassObject* pEnumerator = NULL;
    hres = pSvc->ExecQuery(
        bstr_t("WQL"), 
        bstr_t("SELECT * FROM Win32_AutochkSetting"),
        WBEM_FLAG_FORWARD_ONLY | WBEM_FLAG_RETURN_IMMEDIATELY, 
        NULL,
        &pEnumerator);
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();
        CoUninitialize();
        return;						// Program has failed.
    }
    pclsObj=0;
    ULONG uReturn = 0;
    while (pEnumerator)
    {	HRESULT hr = pEnumerator->Next(WBEM_INFINITE, 1, &pclsObj, &uReturn);
		//if(0 == uReturn)
		//  break;

		GetDec(L"UserInputDelay");
		GetStr(L"SettingID");
		GetStr(L"Description");
		GetStr(L"Caption");

		item.pszText = L"";
		item.iSubItem = 0;
		SendMessage(hWndTree, LVM_INSERTITEM, (WPARAM)0, (LPARAM)&item);

		if(0 == uReturn)
		  break;
	}
    if(pSvc)pSvc->Release();
    if(pLoc)pLoc->Release();
    if(pEnumerator)pEnumerator->Release();
    if(pclsObj)pclsObj->Release();
    CoUninitialize();
}

VOID WMI_Mass_Storage_Classes_Win32_CDROMDrive()
{   HRESULT hres;
    hres =  CoInitializeEx(0, COINIT_MULTITHREADED); 
    if(FAILED(hres))
        return;
    hres =  CoInitializeSecurity(
        NULL, 
        -1,                          // COM authentication
        NULL,                        // Authentication services
        NULL,                        // Reserved
        RPC_C_AUTHN_LEVEL_DEFAULT,   // Default authentication 
        RPC_C_IMP_LEVEL_IMPERSONATE, // Default Impersonation  
        NULL,                        // Authentication info
        EOAC_NONE,                   // Additional capabilities 
        NULL                         // Reserved
        );
    if (FAILED(hres))
    {	CoUninitialize();
        return;                      // Program has failed.
    }
    IWbemLocator *pLoc = NULL;
    hres = CoCreateInstance(
        CLSID_WbemLocator,             
        0, 
        CLSCTX_INPROC_SERVER, 
        IID_IWbemLocator, (LPVOID *) &pLoc);
    if (FAILED(hres))
    {   CoUninitialize();
        return;						// Program has failed.
    }
    IWbemServices *pSvc = NULL;
    hres = pLoc->ConnectServer(
         _bstr_t(L"ROOT\\CIMV2"), // Object path of WMI namespace
         NULL,                    // User name. NULL = current user
         NULL,                    // User password. NULL = current
         0,                       // Locale. NULL indicates current
         NULL,                    // Security flags.
         0,                       // Authority (e.g. Kerberos)
         0,                       // Context object 
         &pSvc                    // pointer to IWbemServices proxy
         );
    
    if (FAILED(hres))
    {   pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    hres = CoSetProxyBlanket(
       pSvc,                        // Indicates the proxy to set
       RPC_C_AUTHN_WINNT,           // RPC_C_AUTHN_xxx
       RPC_C_AUTHZ_NONE,            // RPC_C_AUTHZ_xxx
       NULL,                        // Server principal name 
       RPC_C_AUTHN_LEVEL_CALL,      // RPC_C_AUTHN_LEVEL_xxx 
       RPC_C_IMP_LEVEL_IMPERSONATE, // RPC_C_IMP_LEVEL_xxx
       NULL,                        // client identity
       EOAC_NONE                    // proxy capabilities 
    );
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    IEnumWbemClassObject* pEnumerator = NULL;
    hres = pSvc->ExecQuery(
        bstr_t("WQL"), 
        bstr_t("SELECT * FROM Win32_CDROMDrive"),
        WBEM_FLAG_FORWARD_ONLY | WBEM_FLAG_RETURN_IMMEDIATELY, 
        NULL,
        &pEnumerator);
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();
        CoUninitialize();
        return;						// Program has failed.
    }
    pclsObj=0;
    ULONG uReturn = 0;
    while (pEnumerator)
    {	HRESULT hr = pEnumerator->Next(WBEM_INFINITE, 1, &pclsObj, &uReturn);
        //if(0 == uReturn)
		//   break;
	
		GetStr(L"VolumeSerialNumber");
		GetStr(L"VolumeName");
		GetReal(L"TransferRate");
		GetStr(L"SystemName");
		GetStr(L"SystemCreationClassName");
		GetDec(L"StatusInfo");
		GetStr(L"Status");
		GetDec(L"Size");
		GetDec(L"SerialNumber");
		GetDec(L"SCSITargetId");
		GetDec(L"SCSIPort");
		GetDec(L"SCSILogicalUnit");
		GetDec(L"SCSIBus");
		GetStr(L"RevisionLevel");
		GetBool(L"PowerManagementSupported");
		GetDecArray(L"PowerManagementCapabilities");
		GetStr(L"PNPDeviceID");
		GetDec(L"NumberOfMediaSupported");
		GetBool(L"NeedsCleaning");
		GetStr(L"Name");
		GetDec(L"MinBlockSize");
		GetStr(L"MfrAssignedRevisionLevel");
		GetStr(L"MediaType");
		GetBool(L"MediaLoaded");
		GetDec(L"MaxMediaSize");
		GetDec(L"MaximumComponentLength");
		GetDec(L"MaxBlockSize");
		GetStr(L"Manufacturer");
		GetDec(L"LastErrorCode");
		GetStr(L"InstallDate");
		GetStr(L"Id");
		GetDec(L"FileSystemFlagsEx");
		GetDec(L"FileSystemFlags");
		GetStr(L"ErrorMethodology");
		GetStr(L"ErrorDescription");
		GetBool(L"ErrorCleared");
		GetBool(L"DriveIntegrity");
		GetStr(L"Drive");
		GetStr(L"DeviceID");
		GetStr(L"Description");
		GetDec(L"DefaultBlockSize");
		GetStr(L"CreationClassName");
		GetBool(L"ConfigManagerUserConfig");
		GetConfigManagerErrorCode(L"ConfigManagerErrorCode");
		GetStr(L"CompressionMethod");
		GetStr(L"Caption");
		GetStrArray(L"CapabilityDescriptions");
		GetDecArray(L"Capabilities");
		GetDec(L"Availability");

		item.pszText = L"";
		item.iSubItem = 0;
		SendMessage(hWndTree, LVM_INSERTITEM, (WPARAM)0, (LPARAM)&item);

		if(0 == uReturn)
		  break;
	}
    if(pSvc)pSvc->Release();
    if(pLoc)pLoc->Release();
    if(pEnumerator)pEnumerator->Release();
    if(pclsObj)pclsObj->Release();
    CoUninitialize();
}

VOID WMI_Mass_Storage_Classes_Win32_DiskDrive()
{   HRESULT hres;
    hres =  CoInitializeEx(0, COINIT_MULTITHREADED); 
    if(FAILED(hres))
        return;
    hres =  CoInitializeSecurity(
        NULL, 
        -1,                          // COM authentication
        NULL,                        // Authentication services
        NULL,                        // Reserved
        RPC_C_AUTHN_LEVEL_DEFAULT,   // Default authentication 
        RPC_C_IMP_LEVEL_IMPERSONATE, // Default Impersonation  
        NULL,                        // Authentication info
        EOAC_NONE,                   // Additional capabilities 
        NULL                         // Reserved
        );
    if (FAILED(hres))
    {	CoUninitialize();
        return;                      // Program has failed.
    }
    IWbemLocator *pLoc = NULL;
    hres = CoCreateInstance(
        CLSID_WbemLocator,             
        0, 
        CLSCTX_INPROC_SERVER, 
        IID_IWbemLocator, (LPVOID *) &pLoc);
    if (FAILED(hres))
    {   CoUninitialize();
        return;						// Program has failed.
    }
    IWbemServices *pSvc = NULL;
    hres = pLoc->ConnectServer(
         _bstr_t(L"ROOT\\CIMV2"), // Object path of WMI namespace
         NULL,                    // User name. NULL = current user
         NULL,                    // User password. NULL = current
         0,                       // Locale. NULL indicates current
         NULL,                    // Security flags.
         0,                       // Authority (e.g. Kerberos)
         0,                       // Context object 
         &pSvc                    // pointer to IWbemServices proxy
         );
    
    if (FAILED(hres))
    {   pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    hres = CoSetProxyBlanket(
       pSvc,                        // Indicates the proxy to set
       RPC_C_AUTHN_WINNT,           // RPC_C_AUTHN_xxx
       RPC_C_AUTHZ_NONE,            // RPC_C_AUTHZ_xxx
       NULL,                        // Server principal name 
       RPC_C_AUTHN_LEVEL_CALL,      // RPC_C_AUTHN_LEVEL_xxx 
       RPC_C_IMP_LEVEL_IMPERSONATE, // RPC_C_IMP_LEVEL_xxx
       NULL,                        // client identity
       EOAC_NONE                    // proxy capabilities 
    );
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    IEnumWbemClassObject* pEnumerator = NULL;
    hres = pSvc->ExecQuery(
        bstr_t("WQL"), 
        bstr_t("SELECT * FROM Win32_DiskDrive"),
        WBEM_FLAG_FORWARD_ONLY | WBEM_FLAG_RETURN_IMMEDIATELY, 
        NULL,
        &pEnumerator);
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();
        CoUninitialize();
        return;						// Program has failed.
    }
    pclsObj=0;
    ULONG uReturn = 0;
    while (pEnumerator)
    {	HRESULT hr = pEnumerator->Next(WBEM_INFINITE, 1, &pclsObj, &uReturn);
        //if(0 == uReturn)
		//   break;
	
		GetDec(L"TracksPerCylinder");
		GetDec(L"TotalTracks");
		GetDec(L"TotalSectors");
		GetDec(L"TotalHeads");
		GetDec(L"TotalCylinders");
		GetStr(L"SystemName");
		GetStr(L"SystemCreationClassName");
		GetDec(L"StatusInfo");
		GetStr(L"Status");
		GetDec(L"Size");
		GetDec(L"Signature");
		GetDec(L"SerialNumber");
		GetDec(L"SectorsPerTrack");
		GetDec(L"SCSITargetId");
		GetDec(L"SCSIPort");
		GetDec(L"SCSILogicalUnit");
		GetDec(L"SCSIBus");
		GetBool(L"PowerManagementSupported");
		GetDecArray(L"PowerManagementCapabilities");
		GetStr(L"PNPDeviceID");
		GetDec(L"Partitions");
		GetDec(L"NumberOfMediaSupported");
		GetBool(L"NeedsCleaning");
		GetStr(L"Name");
		GetStr(L"Model");
		GetDec(L"MinBlockSize");
		GetStr(L"MediaType");
		GetBool(L"MediaLoaded");
		GetDec(L"MaxMediaSize");
		GetDec(L"MaxBlockSize");
		GetStr(L"Manufacturer");
		GetDec(L"LastErrorCode");
		GetStr(L"InterfaceType");
		GetStr(L"InstallDate");
		GetDec(L"Index");
		GetStr(L"FirmwareRevision");
		GetStr(L"ErrorMethodology");
		GetStr(L"ErrorDescription");
		GetBool(L"ErrorCleared");
		GetStr(L"DeviceID");
		GetStr(L"Description");
		GetDec(L"DefaultBlockSize");
		GetStr(L"CreationClassName");
		GetBool(L"ConfigManagerUserConfig");
		GetConfigManagerErrorCode(L"ConfigManagerErrorCode");
		GetStr(L"CompressionMethod");
		GetStr(L"Caption");
		GetStrArray(L"CapabilityDescriptions");
		GetDecArray(L"Capabilities");
		GetDec(L"BytesPerSector");
		GetDec(L"Availability");

		item.pszText = L"";
		item.iSubItem = 0;
		SendMessage(hWndTree, LVM_INSERTITEM, (WPARAM)0, (LPARAM)&item);

		if(0 == uReturn)
		  break;
	}
    if(pSvc)pSvc->Release();
    if(pLoc)pLoc->Release();
    if(pEnumerator)pEnumerator->Release();
    if(pclsObj)pclsObj->Release();
    CoUninitialize();
}

VOID WMI_Mass_Storage_Classes_Win32_FloppyDrive()
{   HRESULT hres;
    hres =  CoInitializeEx(0, COINIT_MULTITHREADED); 
    if(FAILED(hres))
        return;
    hres =  CoInitializeSecurity(
        NULL, 
        -1,                          // COM authentication
        NULL,                        // Authentication services
        NULL,                        // Reserved
        RPC_C_AUTHN_LEVEL_DEFAULT,   // Default authentication 
        RPC_C_IMP_LEVEL_IMPERSONATE, // Default Impersonation  
        NULL,                        // Authentication info
        EOAC_NONE,                   // Additional capabilities 
        NULL                         // Reserved
        );
    if (FAILED(hres))
    {	CoUninitialize();
        return;                      // Program has failed.
    }
    IWbemLocator *pLoc = NULL;
    hres = CoCreateInstance(
        CLSID_WbemLocator,             
        0, 
        CLSCTX_INPROC_SERVER, 
        IID_IWbemLocator, (LPVOID *) &pLoc);
    if (FAILED(hres))
    {   CoUninitialize();
        return;						// Program has failed.
    }
    IWbemServices *pSvc = NULL;
    hres = pLoc->ConnectServer(
         _bstr_t(L"ROOT\\CIMV2"), // Object path of WMI namespace
         NULL,                    // User name. NULL = current user
         NULL,                    // User password. NULL = current
         0,                       // Locale. NULL indicates current
         NULL,                    // Security flags.
         0,                       // Authority (e.g. Kerberos)
         0,                       // Context object 
         &pSvc                    // pointer to IWbemServices proxy
         );
    
    if (FAILED(hres))
    {   pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    hres = CoSetProxyBlanket(
       pSvc,                        // Indicates the proxy to set
       RPC_C_AUTHN_WINNT,           // RPC_C_AUTHN_xxx
       RPC_C_AUTHZ_NONE,            // RPC_C_AUTHZ_xxx
       NULL,                        // Server principal name 
       RPC_C_AUTHN_LEVEL_CALL,      // RPC_C_AUTHN_LEVEL_xxx 
       RPC_C_IMP_LEVEL_IMPERSONATE, // RPC_C_IMP_LEVEL_xxx
       NULL,                        // client identity
       EOAC_NONE                    // proxy capabilities 
    );
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    IEnumWbemClassObject* pEnumerator = NULL;
    hres = pSvc->ExecQuery(
        bstr_t("WQL"), 
        bstr_t("SELECT * FROM Win32_FloppyDrive"),
        WBEM_FLAG_FORWARD_ONLY | WBEM_FLAG_RETURN_IMMEDIATELY, 
        NULL,
        &pEnumerator);
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();
        CoUninitialize();
        return;						// Program has failed.
    }
    pclsObj=0;
    ULONG uReturn = 0;
    while (pEnumerator)
    {	HRESULT hr = pEnumerator->Next(WBEM_INFINITE, 1, &pclsObj, &uReturn);
        //if(0 == uReturn)
		//   break;
	
		GetStr(L"SystemName");
		GetStr(L"SystemCreationClassName");
		GetDec(L"StatusInfo");
		GetStr(L"Status");
		GetBool(L"PowerManagementSupported");
		GetDecArray(L"PowerManagementCapabilities");
		GetStr(L"PNPDeviceID");
		GetDec(L"NumberOfMediaSupported");
		GetBool(L"NeedsCleaning");
		GetStr(L"Name");
		GetDec(L"MinBlockSize");
		GetDec(L"MaxMediaSize");
		GetDec(L"MaxBlockSize");
		GetStr(L"Manufacturer");
		GetDec(L"LastErrorCode");
		GetStr(L"InstallDate");
		GetStr(L"ErrorMethodology");
		GetStr(L"ErrorDescription");
		GetBool(L"ErrorCleared");
		GetStr(L"DeviceID");
		GetStr(L"Description");
		GetDec(L"DefaultBlockSize");
		GetStr(L"CreationClassName");
		GetBool(L"ConfigManagerUserConfig");
		GetConfigManagerErrorCode(L"ConfigManagerErrorCode");
		GetStr(L"CompressionMethod");
		GetStr(L"Caption");
		GetStrArray(L"CapabilityDescriptions");
		GetDecArray(L"Capabilities");
		GetDec(L"Availability");

		item.pszText = L"";
		item.iSubItem = 0;
		SendMessage(hWndTree, LVM_INSERTITEM, (WPARAM)0, (LPARAM)&item);

		if(0 == uReturn)
		  break;
	}
    if(pSvc)pSvc->Release();
    if(pLoc)pLoc->Release();
    if(pEnumerator)pEnumerator->Release();
    if(pclsObj)pclsObj->Release();
    CoUninitialize();
}

VOID WMI_Mass_Storage_Classes_Win32_PhysicalMedia()
{   HRESULT hres;
    hres =  CoInitializeEx(0, COINIT_MULTITHREADED); 
    if(FAILED(hres))
        return;
    hres =  CoInitializeSecurity(
        NULL, 
        -1,                          // COM authentication
        NULL,                        // Authentication services
        NULL,                        // Reserved
        RPC_C_AUTHN_LEVEL_DEFAULT,   // Default authentication 
        RPC_C_IMP_LEVEL_IMPERSONATE, // Default Impersonation  
        NULL,                        // Authentication info
        EOAC_NONE,                   // Additional capabilities 
        NULL                         // Reserved
        );
    if (FAILED(hres))
    {	CoUninitialize();
        return;                      // Program has failed.
    }
    IWbemLocator *pLoc = NULL;
    hres = CoCreateInstance(
        CLSID_WbemLocator,             
        0, 
        CLSCTX_INPROC_SERVER, 
        IID_IWbemLocator, (LPVOID *) &pLoc);
    if (FAILED(hres))
    {   CoUninitialize();
        return;						// Program has failed.
    }
    IWbemServices *pSvc = NULL;
    hres = pLoc->ConnectServer(
         _bstr_t(L"ROOT\\CIMV2"), // Object path of WMI namespace
         NULL,                    // User name. NULL = current user
         NULL,                    // User password. NULL = current
         0,                       // Locale. NULL indicates current
         NULL,                    // Security flags.
         0,                       // Authority (e.g. Kerberos)
         0,                       // Context object 
         &pSvc                    // pointer to IWbemServices proxy
         );
    
    if (FAILED(hres))
    {   pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    hres = CoSetProxyBlanket(
       pSvc,                        // Indicates the proxy to set
       RPC_C_AUTHN_WINNT,           // RPC_C_AUTHN_xxx
       RPC_C_AUTHZ_NONE,            // RPC_C_AUTHZ_xxx
       NULL,                        // Server principal name 
       RPC_C_AUTHN_LEVEL_CALL,      // RPC_C_AUTHN_LEVEL_xxx 
       RPC_C_IMP_LEVEL_IMPERSONATE, // RPC_C_IMP_LEVEL_xxx
       NULL,                        // client identity
       EOAC_NONE                    // proxy capabilities 
    );
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    IEnumWbemClassObject* pEnumerator = NULL;
    hres = pSvc->ExecQuery(
        bstr_t("WQL"), 
        bstr_t("SELECT * FROM Win32_PhysicalMedia"),
        WBEM_FLAG_FORWARD_ONLY | WBEM_FLAG_RETURN_IMMEDIATELY, 
        NULL,
        &pEnumerator);
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();
        CoUninitialize();
        return;						// Program has failed.
    }
    pclsObj=0;
    ULONG uReturn = 0;
    while (pEnumerator)
    {	HRESULT hr = pEnumerator->Next(WBEM_INFINITE, 1, &pclsObj, &uReturn);
        //if(0 == uReturn)
		//   break;
	
		GetBool(L"CleanerMedia");
		GetBool(L"WriteProtectOn");
		GetStr(L"MediaDescription");
		GetDec(L"MediaType");
		GetDec(L"Capacity");
		GetBool(L"HotSwappable");
		GetBool(L"Replaceable");
		GetBool(L"Removable");
		GetBool(L"PoweredOn");
		GetStr(L"OtherIdentifyingInfo");
		GetStr(L"PartNumber");
		GetStr(L"Version");
		GetStr(L"Tag");
		GetStr(L"SerialNumber");
		GetStr(L"SKU");
		GetStr(L"Model");
		GetStr(L"Manufacturer");
		GetStr(L"CreationClassName");
		GetStr(L"Status");
		GetStr(L"Name");
		GetStr(L"InstallDate");
		GetStr(L"Description");
		GetStr(L"Caption");

		item.pszText = L"";
		item.iSubItem = 0;
		SendMessage(hWndTree, LVM_INSERTITEM, (WPARAM)0, (LPARAM)&item);

		if(0 == uReturn)
		  break;
	}
    if(pSvc)pSvc->Release();
    if(pLoc)pLoc->Release();
    if(pEnumerator)pEnumerator->Release();
    if(pclsObj)pclsObj->Release();
    CoUninitialize();
}

VOID WMI_Mass_Storage_Classes_Win32_TapeDrive()
{   HRESULT hres;
    hres =  CoInitializeEx(0, COINIT_MULTITHREADED); 
    if(FAILED(hres))
        return;
    hres =  CoInitializeSecurity(
        NULL, 
        -1,                          // COM authentication
        NULL,                        // Authentication services
        NULL,                        // Reserved
        RPC_C_AUTHN_LEVEL_DEFAULT,   // Default authentication 
        RPC_C_IMP_LEVEL_IMPERSONATE, // Default Impersonation  
        NULL,                        // Authentication info
        EOAC_NONE,                   // Additional capabilities 
        NULL                         // Reserved
        );
    if (FAILED(hres))
    {	CoUninitialize();
        return;                      // Program has failed.
    }
    IWbemLocator *pLoc = NULL;
    hres = CoCreateInstance(
        CLSID_WbemLocator,             
        0, 
        CLSCTX_INPROC_SERVER, 
        IID_IWbemLocator, (LPVOID *) &pLoc);
    if (FAILED(hres))
    {   CoUninitialize();
        return;						// Program has failed.
    }
    IWbemServices *pSvc = NULL;
    hres = pLoc->ConnectServer(
         _bstr_t(L"ROOT\\CIMV2"), // Object path of WMI namespace
         NULL,                    // User name. NULL = current user
         NULL,                    // User password. NULL = current
         0,                       // Locale. NULL indicates current
         NULL,                    // Security flags.
         0,                       // Authority (e.g. Kerberos)
         0,                       // Context object 
         &pSvc                    // pointer to IWbemServices proxy
         );
    
    if (FAILED(hres))
    {   pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    hres = CoSetProxyBlanket(
       pSvc,                        // Indicates the proxy to set
       RPC_C_AUTHN_WINNT,           // RPC_C_AUTHN_xxx
       RPC_C_AUTHZ_NONE,            // RPC_C_AUTHZ_xxx
       NULL,                        // Server principal name 
       RPC_C_AUTHN_LEVEL_CALL,      // RPC_C_AUTHN_LEVEL_xxx 
       RPC_C_IMP_LEVEL_IMPERSONATE, // RPC_C_IMP_LEVEL_xxx
       NULL,                        // client identity
       EOAC_NONE                    // proxy capabilities 
    );
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();     
        CoUninitialize();
        return;						// Program has failed.
    }
    IEnumWbemClassObject* pEnumerator = NULL;
    hres = pSvc->ExecQuery(
        bstr_t("WQL"), 
        bstr_t("SELECT * FROM Win32_TapeDrive"),
        WBEM_FLAG_FORWARD_ONLY | WBEM_FLAG_RETURN_IMMEDIATELY, 
        NULL,
        &pEnumerator);
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();
        CoUninitialize();
        return;						// Program has failed.
    }
    pclsObj=0;
    ULONG uReturn = 0;
    while (pEnumerator)
    {	HRESULT hr = pEnumerator->Next(WBEM_INFINITE, 1, &pclsObj, &uReturn);
        //if(0 == uReturn)
		//   break;
	
		GetStr(L"SystemName");
		GetStr(L"SystemCreationClassName");
		GetDec(L"StatusInfo");
		GetStr(L"Status");
		GetDec(L"ReportSetMarks");
		GetBool(L"PowerManagementSupported");
		GetDecArray(L"PowerManagementCapabilities");
		GetStr(L"PNPDeviceID");
		GetDec(L"Padding");
		GetDec(L"NumberOfMediaSupported");
		GetBool(L"NeedsCleaning");
		GetStr(L"Name");
		GetDec(L"MinBlockSize");
		GetStr(L"MediaType");
		GetDec(L"MaxPartitionCount");
		GetDec(L"MaxMediaSize");
		GetDec(L"MaxBlockSize");
		GetStr(L"Manufacturer");
		GetDec(L"LastErrorCode");
		GetStr(L"InstallDate");
		GetStr(L"Id");
		GetDec(L"FeaturesLow");
		GetDec(L"FeaturesHigh");
		GetStr(L"ErrorMethodology");
		GetStr(L"ErrorDescription");
		GetBool(L"ErrorCleared");
		GetDec(L"EOTWarningZoneSize");
		GetDec(L"ECC");
		GetStr(L"DeviceID");
		GetStr(L"Description");
		GetDec(L"DefaultBlockSize");
		GetStr(L"CreationClassName");
		GetBool(L"ConfigManagerUserConfig");
		GetConfigManagerErrorCode(L"ConfigManagerErrorCode");
		GetStr(L"CompressionMethod");
		GetDec(L"Compression");
		GetStr(L"Caption");
		GetStrArray(L"CapabilityDescriptions");
		GetDecArray(L"Capabilities");
		GetDec(L"Availability");

		item.pszText = L"";
		item.iSubItem = 0;
		SendMessage(hWndTree, LVM_INSERTITEM, (WPARAM)0, (LPARAM)&item);

		if(0 == uReturn)
		  break;
	}
    if(pSvc)pSvc->Release();
    if(pLoc)pLoc->Release();
    if(pEnumerator)pEnumerator->Release();
    if(pclsObj)pclsObj->Release();
    CoUninitialize();
}