#include "windows.h"
#include "strsafe.h"
#include "shlobj.h"
#include "Sddl.h"
#include "resource.h"
#include "..\..\..\Operations\MyShell\ComboToDisk.h"
#include "..\..\..\Operations\MyShell\MyButtonC++.h"
#include "..\..\..\Operations\MyShell\MyShell.h"


HINSTANCE hInst;
CBToDisk nameCB,rootCB;
wchar_t name[MAX_PATH]=L"",root[MAX_PATH]=L"";

INT_PTR CALLBACK CreateFolderDlgProc(HWND,UINT,WPARAM,LPARAM);
BOOL CreateMyDACL(SECURITY_ATTRIBUTES*);


int APIENTRY WinMain(HINSTANCE hInstance,HINSTANCE hPrevInstance,LPSTR lpCmdLine,int nCmdShow)
{
	return (int)DialogBox(hInst,MAKEINTRESOURCE(IDD_DIALOG_CREATE_FOLDER),NULL,CreateFolderDlgProc);
}

INT_PTR CALLBACK CreateFolderDlgProc(HWND hDlg,UINT message,WPARAM wParam,LPARAM lParam)
{	UNREFERENCED_PARAMETER(lParam);
	switch(message)
	{
	case WM_INITDIALOG:RECT r;int width,height,left,top;
		GetWindowRect(hDlg,&r);
		width = r.right - r.left;
		height = r.bottom - r.top;
		left=(GetSystemMetrics(SM_CXSCREEN) - width )/2;
		top = (int)(0.38*(GetSystemMetrics(SM_CYSCREEN) - height));
		MoveWindow(hDlg, left, top+20, width, height, TRUE);

		//MyButtonFrRCBtn(hDlg,IDOK,0);
		//MyButtonFrRCBtn(hDlg,IDCANCEL,0);
		//MyButtonFrRCBtn(hDlg,IDC_BUTTON_BROWSE,0);
		nameCB.Read(L"crfolder.cb:stream",GetDlgItem(hDlg,IDC_COMBO_NAME),35,260);
		rootCB.Read(L"crfolder.cb:stream1",GetDlgItem(hDlg,IDC_COMBO_ROOT),35,260);

		int nNumArgs,l;nNumArgs=0;
		//p=CommandLineToArgvW(GetCommandLineW(),&nNumArgs);
		l=MyStringCpy(root,MAX_PATH,GetCommandLineW());//p[0]);
		//MessageBox(hDlg,GetCommandLineW(),L"",MB_OK);
		if(l)
		{if('*'==root[l-1] && '\\'==root[l-2])
		 {root[l-2]=0;
		  if(IsDirExist(root))
		  {SendMessage(GetDlgItem(hDlg,IDC_COMBO_ROOT),CB_INSERTSTRING,0,(LPARAM)root);
		   SendMessage(GetDlgItem(hDlg,IDC_COMBO_ROOT),CB_SETCURSEL,0,0);
		  }
		  else goto R;
		 }
		 else
		 {R:wchar_t *p;p=wcsrchr(root,'\\');if(p)*p=0;
		  if(IsDirExist(root))
		  {SendMessage(GetDlgItem(hDlg,IDC_COMBO_ROOT),CB_INSERTSTRING,0,(LPARAM)root);
		   SendMessage(GetDlgItem(hDlg,IDC_COMBO_ROOT),CB_SETCURSEL,0,0);
	    }}}	

	    SendMessage(GetDlgItem(hDlg,IDC_COMBO_ATTRIBUTE),CB_INSERTSTRING,-1,(LPARAM)L"FILE_ATTRIBUTE_ARCHIVE");
	    SendMessage(GetDlgItem(hDlg,IDC_COMBO_ATTRIBUTE),CB_INSERTSTRING,-1,(LPARAM)L"FILE_ATTRIBUTE_HIDDEN");
	    SendMessage(GetDlgItem(hDlg,IDC_COMBO_ATTRIBUTE),CB_INSERTSTRING,-1,(LPARAM)L"FILE_ATTRIBUTE_NORMAL");
	    SendMessage(GetDlgItem(hDlg,IDC_COMBO_ATTRIBUTE),CB_INSERTSTRING,-1,(LPARAM)L"FILE_ATTRIBUTE_NOT_CONTENT_INDEXED");
	    SendMessage(GetDlgItem(hDlg,IDC_COMBO_ATTRIBUTE),CB_INSERTSTRING,-1,(LPARAM)L"FILE_ATTRIBUTE_OFFLINE");
	    SendMessage(GetDlgItem(hDlg,IDC_COMBO_ATTRIBUTE),CB_INSERTSTRING,-1,(LPARAM)L"FILE_ATTRIBUTE_READONLY");
	    SendMessage(GetDlgItem(hDlg,IDC_COMBO_ATTRIBUTE),CB_INSERTSTRING,-1,(LPARAM)L"FILE_ATTRIBUTE_SYSTEM");
	    SendMessage(GetDlgItem(hDlg,IDC_COMBO_ATTRIBUTE),CB_INSERTSTRING,-1,(LPARAM)L"FILE_ATTRIBUTE_TEMPORARY");
		return TRUE;
	case WM_DESTROY:
		nameCB.Save(L"crfolder.cb:stream",GetDlgItem(hDlg,IDC_COMBO_NAME),35);
		rootCB.Save(L"crfolder.cb:stream1",GetDlgItem(hDlg,IDC_COMBO_ROOT),35);
		return 0;
	case WM_COMMAND:
		switch(LOWORD(wParam))
		{	case IDOK://overwrite
				nameCB.GetCBEditText(GetDlgItem(hDlg,IDC_COMBO_NAME),name,MAX_PATH);
				if(name[0])nameCB.AddToCB(GetDlgItem(hDlg,IDC_COMBO_NAME),name,TRUE);
				rootCB.GetCBEditText(GetDlgItem(hDlg,IDC_COMBO_ROOT),root,MAX_PATH);
				if(root[0])rootCB.AddToCB(GetDlgItem(hDlg,IDC_COMBO_ROOT),root,TRUE);
				if(!IsDirExist(root))
				{	MessageBox(hDlg,L"Not existing directory:",root,MB_OK);
					return 0;
				}
				l=MyStringLength(root,MAX_PATH);
				if('*'==root[l-1] && '\\'==root[l-2]){root[l-1]=0;--l;}
				else if(root[l-1]!='\\'){root[l++]='\\';root[l]=0;}
				int ln;ln=MyStringCpy(&root[l],MAX_PATH-l,name);

				wchar_t ch[4];ch[0]=' ';ch[1]=0;
				for(int i=0; i<ln; ++i)
				{	if('<'==name[i])ch[0]='<';else if('>'==name[i])ch[0]='>';else if(':'==name[i])ch[0]=':';
					else if('"'==name[i])ch[0]='"';else if('/'==name[i])ch[0]='/';else if('|'==name[i])ch[0]='|';
					else if('?'==name[i])ch[0]='?';else if('*'==name[i])ch[0]='*';
					if(ch[0]!=' ')
					{	MessageBox(hDlg,ch,L"Directory name cannot contain character:",MB_OK);
						return FALSE;
				}	}

				if(!CreateDirectory(root,NULL))
				{SECURITY_ATTRIBUTES sa;sa.nLength=sizeof(SECURITY_ATTRIBUTES);sa.bInheritHandle=FALSE;
				 if(CreateMyDACL(&sa))
				 {BOOL r=CreateDirectory(root, &sa);
				  LocalFree(sa.lpSecurityDescriptor);
				  if(!r)
				  {MessageBox(hDlg,L"Err. Don't create directory:",root,MB_OK);
				   return 0;
			    }}}
				top=(int)SendMessage(GetDlgItem(hDlg,IDC_COMBO_ATTRIBUTE),CB_GETCURSEL,0,0);
				if(CB_ERR!=top)
				{switch(top)
				 {case 0:SetFileAttributes(root,FILE_ATTRIBUTE_ARCHIVE);break;
				  case 1:SetFileAttributes(root,FILE_ATTRIBUTE_HIDDEN);break;
				  case 2:SetFileAttributes(root,FILE_ATTRIBUTE_NORMAL);break;
				  case 3:SetFileAttributes(root,FILE_ATTRIBUTE_NOT_CONTENT_INDEXED);break;
				  case 4:SetFileAttributes(root,FILE_ATTRIBUTE_OFFLINE);break;
				  case 5:SetFileAttributes(root,FILE_ATTRIBUTE_READONLY);break;
				  case 6:SetFileAttributes(root,FILE_ATTRIBUTE_SYSTEM);break;
				  case 7:SetFileAttributes(root,FILE_ATTRIBUTE_TEMPORARY);break;
				}}
				EndDialog(hDlg,1);
				return (INT_PTR)TRUE;
			case IDCANCEL:
				EndDialog(hDlg,0);
				return (INT_PTR)TRUE;
			case IDC_BUTTON_BROWSE:BROWSEINFOW bi;
				rootCB.GetCBEditText(GetDlgItem(hDlg,IDC_COMBO_ROOT),root,MAX_PATH);
				bi.hwndOwner = hDlg;bi.pszDisplayName = root;
				bi.lpszTitle = L"Browse for root folder path ...";bi.ulFlags = BIF_NONEWFOLDERBUTTON|
					BIF_DONTGOBELOWDOMAIN|BIF_NEWDIALOGSTYLE|BIF_NOTRANSLATETARGETS|BIF_RETURNFSANCESTORS;
				bi.lpfn = NULL;LPITEMIDLIST pidlRoot;pidlRoot = NULL;bi.pidlRoot = pidlRoot;
				LPITEMIDLIST pidlSelected;pidlSelected = SHBrowseForFolder(&bi);
				if(pidlRoot)CoTaskMemFree(pidlRoot);
				if(pidlSelected)
				{	SHGetPathFromIDList(pidlSelected,root);
					rootCB.AddToCB(GetDlgItem(hDlg,IDC_COMBO_ROOT),root,TRUE);
					SendMessage(GetDlgItem(hDlg,IDC_COMBO_ROOT),CB_SETCURSEL,0,0);
					CoTaskMemFree(pidlSelected);
				}
				return 0;
		}
		break;
	}
	return (INT_PTR)FALSE;
}

// CreateMyDACL.
//    Create a security descriptor that contains the DACL 
//    you want.
//    This function uses SDDL to make Deny and Allow ACEs.
//
// Parameter:
//    SECURITY_ATTRIBUTES * pSA
//    Pointer to a SECURITY_ATTRIBUTES structure. It is your
//    responsibility to properly initialize the 
//    structure and to free the structure's 
//    lpSecurityDescriptor member when you have
//    finished using it. To free the structure's 
//    lpSecurityDescriptor member, call the 
//    LocalFree function.
// 
// Return value:
//    FALSE if the address to the structure is NULL. 
//    Otherwise, this function returns the value from the
//    ConvertStringSecurityDescriptorToSecurityDescriptor 
//    function.
BOOL CreateMyDACL(SECURITY_ATTRIBUTES * pSA)
{
     // Define the SDDL for the DACL. This example sets 
     // the following access:
     //     Built-in guests are denied all access.
     //     Anonymous logon is denied all access.
     //     Authenticated users are allowed 
     //     read/write/execute access.
     //     Administrators are allowed full control.
     // Modify these values as needed to generate the proper
     // DACL for your application. 
     TCHAR * szSD = TEXT("D:")       // Discretionary ACL
        TEXT("(D;OICI;GA;;;BG)")     // Deny access to 
                                     // built-in guests
        TEXT("(D;OICI;GA;;;AN)")     // Deny access to 
                                     // anonymous logon
        TEXT("(A;OICI;GRGWGX;;;AU)") // Allow 
                                     // read/write/execute 
                                     // to authenticated 
                                     // users
        TEXT("(A;OICI;GA;;;BA)");    // Allow full control 
                                     // to administrators

    if (NULL == pSA)
        return FALSE;

     return ConvertStringSecurityDescriptorToSecurityDescriptor(
                szSD,
                SDDL_REVISION_1,
                &(pSA->lpSecurityDescriptor),
                NULL);
}