//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by CreateFolder.rc
//
#define IDR_SINOSTRING1                 105
#define IDI_ICON2                       106
#define IDD_DIALOG_CREATE_FOLDER        1001
#define IDC_COMBO_ROOT                  1002
#define IDC_COMBO_NAME                  1003
#define IDC_COMBO_ATTRIBUTE             1004
#define IDC_CHECK_ECHO                  1005
#define IDC_CHECK_UNICODE               1006
#define IDC_CHECK_EXTENDED              1007
#define IDC_CHECK_AUTORUN               1008
#define IDC_COMBO_INST_NUM              1008
#define IDC_BUTTON_BROWSE               1009

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        107
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1010
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
