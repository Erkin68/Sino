#include "zipviewer.h"
#include "..\..\..\Operations\MyShell\MyShell.h"

wchar_t zfName[MAX_PATH]=L"";//"D:\\Install\\7600.16385.1.zip";//Microsoft Office 2007.zip";


SetCallbacks$4xxx_t SetCallbacks$4xxx=NULL;
OpenForUnpacking$8_t OpenForUnpacking$8=NULL;
EnumDirectory$8_t EnumDirectory$8=NULL;
FullEnum$4_t FullEnum$4=NULL;
Close$4_t Close$4=NULL;

LPVOID plgnInst=0;
unsigned __int64 totSz,arjSz,iFolders,iFiles;

enum
{	calcCmprsn,
	itemGetInfo
}state=calcCmprsn;


int calcCmprsnCallback(wchar_t*,WIN32_FIND_DATAW*);

int CALLBACK checkFileInSelctn(LPVOID,wchar_t*){return -1;}
VOID CALLBACK excldFileFrSelctn(LPVOID,int,int){}
BOOL CALLBACK getFileInfoFromSelection(LPVOID,int,WIN32_FIND_DATA*){return TRUE;}
DWORD CALLBACK prgrssRout(	LPVOID,unsigned __int64*,unsigned __int64*,unsigned __int64*,unsigned __int64*){return PROGRESS_CONTINUE;}
int CALLBACK showDlgOverwriteExistFile(LPVOID*,int,wchar_t*,unsigned __int64*fileSzInArch,FILETIME*,WIN32_FIND_DATAW*){return 0;}
BOOL CALLBACK readOptions(int,VOID*,int){return TRUE;}
BOOL CALLBACK saveOptions(int,VOID*,int){return TRUE;}
int CALLBACK addItemToPanelList(LPVOID arc,wchar_t* name, WIN32_FIND_DATAW* ffdata)
{	switch(state)
	{case calcCmprsn:
	 case itemGetInfo:
	  return calcCmprsnCallback(name,ffdata);
	}
	return TRUE;
}

BOOL LoadZipLib()
{wchar_t *p,s[MAX_PATH];GetModuleFileName(NULL,s,MAX_PATH);
 for(int i=0; i<2; i++){p=wcsrchr(s,'\\');if(p)*p=0;}
#ifdef _WIN64
#ifdef _DEBUG
 *p++='\\';MyStringCpy(p,MAX_PATH,L"Archive\\zip\\mzlib64dbg.dll");
#else
 *p++='\\';MyStringCpy(p,MAX_PATH,L"Archive\\zip\\mzlib64rel.dll");
#endif
#else
 *p++='\\';MyStringCpy(p,MAX_PATH,L"Archive\\zip\\mzlib32rel.dll");
#endif
 HMODULE h=LoadLibrary(s);
 if(!h)return FALSE;
 SetCallbacks$4xxx=(SetCallbacks$4xxx_t)GetProcAddress(h,"SetCallbacks$4xxx");
 OpenForUnpacking$8=(OpenForUnpacking$8_t)GetProcAddress(h,"OpenForUnpacking$8");
 EnumDirectory$8=(EnumDirectory$8_t)GetProcAddress(h,"EnumDirectory$8");
 FullEnum$4=(FullEnum$4_t)GetProcAddress(h,"FullEnum$4");
 Close$4=(Close$4_t)GetProcAddress(h,"Close$4");
 SetCallbacks$4xxx(	checkFileInSelctn,
					excldFileFrSelctn,
					getFileInfoFromSelection,
					prgrssRout,
					showDlgOverwriteExistFile,
					saveOptions,
					readOptions,
					addItemToPanelList);
 return TRUE;
}

VOID getZipInfo()
{	state=calcCmprsn;
	AddToStatus1(zfName);
	FILE *f=_wfopen(zfName,L"rb");
	if(!f){AddToStatus1(L"File not opened.");return;}
	fseek(f,0,SEEK_END);
	fpos_t fPos;fgetpos(f,&fPos);
	arjSz = fPos;fclose(f);
	AddToStatus1(L"Get file size... Successfully finished.");
	plgnInst=OpenForUnpacking$8(zfName,NULL);
	if(!plgnInst){AddToStatus1(L"File not opened via unpacker...");return;}
	AddToStatus1(L"File opened via unpacker... Successfully finished.");
	totSz = iFolders = iFiles = 0;
	FreeStatus();
	FullEnum$4(plgnInst);//EnumDirectory$8(plgnInst,crntPthInArj);
	Close$4(plgnInst);
	int prgPos = 0;if(arjSz)prgPos = 1000*arjSz / totSz;
	if(prgPos>=1000)prgPos=1000;
	wchar_t s[32];wsprintf(s,L"%4d %s;",prgPos/10,"%");
	AddToStatus2(L"Compression level:              ",s);
	wsprintf(s,L"%d bytes;",arjSz);
	AddToStatus2(L"Archive size:                          ",s);
	wsprintf(s,L"%d bytes;",totSz);
	AddToStatus2(L"Total size of files in archive: ",s);
	wsprintf(s,L"%d;",iFolders);
	AddToStatus2(L"Folders:                                  ",s);
	wsprintf(s,L"%d;",iFiles);
	AddToStatus2(L"Files:                                      ",s);		
	state=itemGetInfo;
}

VOID getZipItemInfo(wchar_t *dst,wchar_t *fullPath)
{	FILE *f=_wfopen(zfName,L"rb");
	plgnInst=OpenForUnpacking$8(zfName,NULL);
	totSz=0;
	EnumDirectory$8(plgnInst,fullPath);
	Close$4(plgnInst);
	wsprintf(dst,L"Size: %d bytes",totSz);
}

int calcCmprsnCallback(wchar_t *name,WIN32_FIND_DATAW *pff)
{	if(pff->dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)
	{//AddToStatus1(L"     Directory.");
	 if(state==calcCmprsn)
	 {AddToTree(name,0);
	  ++iFolders;
	 }
	 return 0;
	}
	unsigned __int64 sz = (pff->nFileSizeHigh<<32) + pff->nFileSizeLow;
	totSz += sz;
	if(state==calcCmprsn)
	{int prgPos = 0;if(arjSz)prgPos = 1000*arjSz / totSz;
	 if(prgPos>=1000)prgPos=1000;
     SendMessage(hWndPrgrs,PBM_SETPOS,(WPARAM)prgPos,0); 
	 AddToTree(name,1);
	++iFiles;
	}
	return 0;
}