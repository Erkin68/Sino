#include "windows.h"
#include "commctrl.h"
#include <Wbemidl.h>

extern HINSTANCE hInst;
extern HWND hWnd,hWndPrgrs,hWndTree,hWndStatus;
extern HFONT fnt;
extern int language;
extern wchar_t zfName[MAX_PATH];

VOID MessageProcess();

VOID FreeStatus();
VOID AddToStatus1(wchar_t*);
VOID AddToStatus2(wchar_t*,wchar_t*);
VOID AddToStatus3(wchar_t*,wchar_t*,wchar_t*);
VOID AddToTree(LPWSTR,int);


extern unsigned __int64 totSz;

//extern mzlib32.lib
typedef VOID (*SetCallbacks$4xxx_t)(LPVOID,...);
typedef LPVOID (*OpenForUnpacking$8_t)(wchar_t*,LPVOID);
typedef BOOL (*EnumDirectory$8_t)(LPVOID,wchar_t*);
typedef BOOL (*FullEnum$4_t)(LPVOID);
typedef BOOL (*Close$4_t)(LPVOID);


BOOL LoadZipLib();
VOID getZipInfo();
VOID getZipItemInfo(wchar_t*,wchar_t*);
