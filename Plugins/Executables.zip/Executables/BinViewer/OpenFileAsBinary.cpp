#include "BinViewer.h"
#include "..\..\..\Operations\Myshell\MyShell.h"



HANDLE hFile=0,hFileMap=0;
LPVOID pFileBase=0;
DWORD nFileSizeHigh,nFileSizeLow;

BOOL OpenBinaryFile()
{
BY_HANDLE_FILE_INFORMATION fibh;

	if(0==FilePathForSearch[0])return FALSE;
    hFile = CreateFile(FilePathForSearch, GENERIC_READ, FILE_SHARE_READ, NULL,
                       OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, (HANDLE)0);                    
    if(hFile == INVALID_HANDLE_VALUE)
        return FALSE;

	if(!GetFileInformationByHandle(hFile,&fibh))
	{	CloseHandle(hFile);
		return FALSE;
	}
	nFileSizeHigh = fibh.nFileSizeHigh;
	nFileSizeLow = fibh.nFileSizeLow;
	sz = (((u64)nFileSizeHigh) << 32) | nFileSizeLow;

    hFileMap = CreateFileMapping(hFile, NULL, PAGE_READONLY, 0, 0,NULL);
    if(hFileMap == 0)
	{	CloseHandle(hFile);
		hFile = 0;
		return FALSE;
	}

    pFileBase = (PCHAR)MapViewOfFile(hFileMap,FILE_MAP_READ,0,0,0);
    if(pFileBase==0)
	{	CloseHandle(hFileMap);
		CloseHandle(hFile);
		hFileMap = 0;
		hFile = 0;
		return FALSE;
	}

    //if(IsBadReadPtr(pNTHdr, sizeof(IMAGE_NT_HEADERS)))return;

	return TRUE;
}

BOOL CloseFileMap()
{	if(pFileBase)
		UnmapViewOfFile(pFileBase);
	pFileBase = 0;
	if(hFileMap)
		CloseHandle(hFileMap);
	hFileMap = 0;
	if(hFile)
		CloseHandle(hFile);
	hFile = 0;
	return TRUE;
}