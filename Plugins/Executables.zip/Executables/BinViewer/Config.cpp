#pragma warning(disable:4996)

#include "BinViewer.h"
#include "stdio.h"




BOOL SaveConfig()
{
wchar_t *p,s[MAX_PATH];FILE *f;int l=GetModuleFileName(NULL,s,MAX_PATH);
	p=wcsrchr(s,'\\');if(!p)p=&s[l];else++p;
	wcscpy(p,L"BinVw.cnf");
	f=_wfopen(s,L"wb");
	if(!f)//default settings:
	 return FALSE;
	fwrite(&xSpaceAddr,sizeof(xSpaceAddr),1,f);
	fwrite(&xSpaceBin,sizeof(xSpaceBin),1,f);
	fwrite(&ySpaceBin,sizeof(ySpaceBin),1,f);
	fwrite(&xSpaceText,sizeof(xSpaceText),1,f);
	fwrite(&perCentOfAddr,sizeof(perCentOfAddr),1,f);
	fwrite(&perCentOfBin,sizeof(perCentOfBin),1,f);
	fwrite(&perCentOfText,sizeof(perCentOfText),1,f);
	fwrite(&textColorText,sizeof(textColorText),1,f);
	fwrite(&backColorText,sizeof(backColorText),1,f);
	fwrite(&addrFillZero,sizeof(addrFillZero),1,f);
	fwrite(&addrFmt,sizeof(addrFmt),1,f);
	fwrite(&addrFmtDesc,sizeof(addrFmtDesc),1,f);
	fwrite(&addrMaxWidth8,sizeof(addrMaxWidth8),1,f);
	fwrite(&addrMaxWidth10,sizeof(addrMaxWidth10),1,f);
	fwrite(&addrMaxWidth16,sizeof(addrMaxWidth16),1,f);
	fwrite(&textColorAddr,sizeof(textColorAddr),1,f);
	fwrite(&backColorAddr,sizeof(backColorAddr),1,f);
	fwrite(&textColorBin,sizeof(textColorBin),1,f);
	fwrite(&backColorBin,sizeof(backColorBin),1,f);
	fwrite(&binFmt,sizeof(binFmt),1,f);
	fwrite(&binFmtDesc,sizeof(binFmtDesc),1,f);
	fwrite(&textColorText,sizeof(textColorText),1,f);
	fwrite(&backColorText,sizeof(backColorText),1,f);
	fwrite(&textFmt,sizeof(textFmt),1,f);
	fwrite(&textFmtDesc,sizeof(textFmtDesc),1,f);
	fwrite(&addrLogFont,sizeof(addrLogFont),1,f);
	fwrite(&binLogFont,sizeof(binLogFont),1,f);
	fwrite(&bAddrShowRowNum,sizeof(bAddrShowRowNum),1,f);
	fclose(f);
	return TRUE;
}

BOOL ReadConfig()
{
wchar_t *p,s[MAX_PATH];FILE *f;int l=GetModuleFileName(NULL,s,MAX_PATH);
	p=wcsrchr(s,'\\');if(!p)p=&s[l];else++p;
	wcscpy(p,L"BinVw.cnf");
	f=_wfopen(s,L"rb");
	if(!f)
	{	InitLogFont(&addrLogFont);
		InitLogFont(&binLogFont);
		return FALSE;
	}
	fread(&xSpaceAddr,sizeof(xSpaceAddr),1,f);
	fread(&xSpaceBin,sizeof(xSpaceBin),1,f);
	fread(&ySpaceBin,sizeof(ySpaceBin),1,f);
	fread(&xSpaceText,sizeof(xSpaceText),1,f);
	fread(&perCentOfAddr,sizeof(perCentOfAddr),1,f);
	fread(&perCentOfBin,sizeof(perCentOfBin),1,f);
	fread(&perCentOfText,sizeof(perCentOfText),1,f);
	fread(&textColorText,sizeof(textColorText),1,f);
	fread(&backColorText,sizeof(backColorText),1,f);
	fread(&addrFillZero,sizeof(addrFillZero),1,f);
	fread(&addrFmt,sizeof(addrFmt),1,f);
	fread(&addrFmtDesc,sizeof(addrFmtDesc),1,f);
	fread(&addrMaxWidth8,sizeof(addrMaxWidth8),1,f);
	fread(&addrMaxWidth10,sizeof(addrMaxWidth10),1,f);
	fread(&addrMaxWidth16,sizeof(addrMaxWidth16),1,f);
	fread(&textColorAddr,sizeof(textColorAddr),1,f);
	fread(&backColorAddr,sizeof(backColorAddr),1,f);
	fread(&textColorBin,sizeof(textColorBin),1,f);
	fread(&backColorBin,sizeof(backColorBin),1,f);
	fread(&binFmt,sizeof(binFmt),1,f);
	fread(&binFmtDesc,sizeof(binFmtDesc),1,f);
	fread(&textColorText,sizeof(textColorText),1,f);
	fread(&backColorText,sizeof(backColorText),1,f);
	fread(&textFmt,sizeof(textFmt),1,f);
	fread(&textFmtDesc,sizeof(textFmtDesc),1,f);
	fread(&addrLogFont,sizeof(addrLogFont),1,f);
	fread(&binLogFont,sizeof(binLogFont),1,f);
	fread(&bAddrShowRowNum,sizeof(bAddrShowRowNum),1,f);
	fclose(f);
	return TRUE;
}
