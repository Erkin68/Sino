#include "BinViewer.h"
#include "strsafe.h"



COLORREF textColorBin=RGB(0xde,0xf7,0xf8),backColorBin=RGB(95,54,201);
HFONT fntBin;
LOGFONT binLogFont;
HBRUSH binBackBrsh;

int xSpaceBin=30,ySpaceBin=30;
SIZE widthOfHexChar;

UINT binFmt=DT_CENTER|DT_VCENTER,binFmtDesc=16;

VOID FormatCharToBin(wchar_t*,u8);


VOID DrawBin(HDC hDC,RECT *rDC)
{wchar_t s[2*MAX_PATH],sfmt[32];

 RECT rc={perCentOfAddr*rDC->right/100+1,0,(perCentOfAddr+perCentOfBin)*rDC->right/100-1,rDC->bottom};
 FillRect(hDC,&rc,binBackBrsh);
 
 rc.left=perCentOfAddr*rDC->right/100+1;
 rc.right = (perCentOfAddr+perCentOfBin)*rDC->right/100;//rc.left + xSpaceBin;
 rc.top=0;
 rc.bottom=ySpaceBin;

 SetBkColor(hDC,backColorBin);
 SetTextColor(hDC,textColorBin);
 HFONT oldFnt=(HFONT)SelectObject(hDC,fntBin);

 GetTextExtentExPoint(hDC,L"B",1,1,NULL,NULL,&widthOfHexChar);

 INT *dists;
 switch(binFmtDesc)
 {	case 2:
		//StringCchPrintf(sfmt,MAX_PATH-1,L"%s02o",L"%");
		dists=(INT*)malloc((8*nViewColumns+1)*sizeof(INT));
		for(int i=0; i<nViewColumns; i++)
		{	dists[8*i]=widthOfHexChar.cx;
			dists[8*i+1]=widthOfHexChar.cx;
			dists[8*i+2]=widthOfHexChar.cx;
			dists[8*i+3]=widthOfHexChar.cx;
			dists[8*i+4]=widthOfHexChar.cx;
			dists[8*i+5]=widthOfHexChar.cx;
			dists[8*i+6]=widthOfHexChar.cx;
			dists[8*i+7]=(xSpaceBin>7*widthOfHexChar.cx)?(xSpaceBin-7*widthOfHexChar.cx):1;
		}
		break;
 	case 8:
		StringCchPrintf(sfmt,MAX_PATH-1,L"%s03o",L"%");
		dists=(INT*)malloc((3*nViewColumns+1)*sizeof(INT));
		for(int i=0; i<nViewColumns; i++)
		{	dists[3*i]=widthOfHexChar.cx;
			dists[3*i+1]=widthOfHexChar.cx;
			dists[3*i+2]=(xSpaceBin>2*widthOfHexChar.cx)?(xSpaceBin-2*widthOfHexChar.cx):1;
		}
		break;
	case 10:
		StringCchPrintf(sfmt,MAX_PATH-1,L"%s03u",L"%");
		dists=(INT*)malloc((3*nViewColumns+1)*sizeof(INT));
		for(int i=0; i<nViewColumns; i++)
		{	dists[3*i]=widthOfHexChar.cx;
			dists[3*i+1]=widthOfHexChar.cx;
			dists[3*i+2]=(xSpaceBin>2*widthOfHexChar.cx)?(xSpaceBin-2*widthOfHexChar.cx):1;
		}
		break;
	case 16:
		StringCchPrintf(sfmt,MAX_PATH-1,L"%s02X",L"%");
		dists=(INT*)malloc((2*nViewColumns+1)*sizeof(INT));
		for(int i=0; i<nViewColumns; i++)
		{	dists[2*i]=widthOfHexChar.cx;
			dists[2*i+1]=xSpaceBin>widthOfHexChar.cx?(xSpaceBin-widthOfHexChar.cx):1;
		}
		break;
 }

 u8 *p = (u8*)pFileBase+iAddressView;
 u64 iiAddress=iAddressView;

 for(int row=0; row<nViewRows; ++row)
 {	/*for(int colmn=0; colmn<nViewColumns; ++colmn)
	{	if(++iiAddress>sz)
			break;
		if(2==binFmtDesc)
			FormatCharToBin(s,*p);
		else
			StringCchPrintf(s,MAX_PATH-1,sfmt,*p);
		DrawText(hDC,s,-1,&rc,binFmt);
		rc.left += xSpaceBin;
		rc.right += xSpaceBin;
		++p;
 	}
	rc.left = perCentOfAddr*rDC->right/100+1;
	rc.right = rc.left + xSpaceBin;*/
	int colmn;
	for(colmn=0; colmn<nViewColumns; ++colmn)
	{	if(++iiAddress>sz)
			break;
		if(2==binFmtDesc)
		{	if(4*colmn<MAX_PATH)//8*colmn<2*MAX_PATH
				FormatCharToBin(&s[8*colmn],*p);
		}
		else if(8==binFmtDesc || 10==binFmtDesc)
		{	if(3*colmn<2*MAX_PATH)
				StringCchPrintf(&s[3*colmn],4,sfmt,*p);
		}
		else// if(16==binFmtDesc)
		{	if(colmn<MAX_PATH)//2*colmn<2*MAX_PATH
				StringCchPrintf(&s[2*colmn],3,sfmt,*p);
		}
		++p;
 	}
	if(2==binFmtDesc)
	{	int ln = 8*colmn;if(ln>2*MAX_PATH)ln=2*MAX_PATH;
		ExtTextOut(hDC,rc.left,rc.top,ETO_OPAQUE|ETO_CLIPPED,&rc,s,ln,dists);
	}
	else if(8==binFmtDesc || 10==binFmtDesc)
	{	int ln = 3*colmn;if(ln>2*MAX_PATH)ln=2*MAX_PATH;
		ExtTextOut(hDC,rc.left,rc.top,ETO_OPAQUE|ETO_CLIPPED,&rc,s,ln,dists);
	}
	else// if(16==binFmtDesc)
	{	int ln = 2*colmn;if(ln>2*MAX_PATH)ln=2*MAX_PATH;
		ExtTextOut(hDC,rc.left,rc.top,ETO_OPAQUE|ETO_CLIPPED,&rc,s,ln,dists);
	}
	rc.top += ySpaceBin;
	rc.bottom += ySpaceBin;
 }
 SelectObject(hDC,oldFnt);
 free(dists);
}

VOID FormatCharToBin(wchar_t *s,u8 c)
{	for(int i=0; i<8; ++i)
	{	int t=(c>>(7-i)) & 1;
		*s++ = t>0?'1':'0';
	}*s=0;
}