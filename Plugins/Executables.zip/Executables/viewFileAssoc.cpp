#pragma warning(disable:4996)

#include "windows.h"
#include "strsafe.h"
#include "shlobj.h"
#include "shlwapi.h"
#include "viewFileAssoc.h"
#include "..\..\resource.h"
#include "..\..\Config.h"
#include "..\..\Operations\MyErrors.h"
#include "..\..\Operations\Execution.h"
#include "..\..\Operations\MyShell\MyShell.h"
//#include "..\..\Operations\MyShell\MyButtonC++.h"
#include "..\..\Operations\MyShell\ComboToDisk.h"



extern HINSTANCE hInst;

namespace viewFileAssoc
{
int iPlgns=0,iMaxPlgns=0;
exctblPlgn *plgns=NULL;

CBToDisk tmpCB;

Record defaRecrd;

//conf:

bool bUseExecutableInReset[3]={true,true,true};
bool bCrtConsPrcss[3]={false,false,false};
bool bSetParamsInCmndLn[3]={false,false,false};
bool bUseStdSize[3]={true,true,true};
bool bUseDefaForAll[3]={false,false,false};;
int  stdXPos[3]={-1,-1,-1};
int  stdYPos[3]={-1,-1,-1};
int  stdW[3]={-1,-1,-1};
int  stdH[3]={-1,-1,-1};
int  stdViewRoutFuncType[3]={0,0,0};
int  stdViewRoutPrtyClss[3]={0,0,0};

void OnExtensionLBChanging(HWND,int);
int AddIfNotInExtensionListInLB(wchar_t*,HWND);
BOOL GetExtParams(wchar_t*,wchar_t*,wchar_t*,wchar_t*);
LRESULT CALLBACK WhichAssocPlgnDlgProc(HWND,UINT,WPARAM,LPARAM);

BOOL Execute(HWND prnt,wchar_t *pathAndName,int typeOfExecute)
{
wchar_t defDir[MAX_PATH];MyStringCpy(defDir,MAX_PATH,pathAndName);
wchar_t *p=wcsrchr(defDir,'\\');if(p)*p=0;
	p=wcsrchr(pathAndName,'.');

wchar_t pathAndNameAndSrchFltr[2*MAX_PATH];
	int ln=MyStringCpy(pathAndNameAndSrchFltr,MAX_PATH,pathAndName);
	if(typeOfExecute<2 && fSearchViaF7::srchFrFileFltr[0])
	{	pathAndNameAndSrchFltr[ln++]=' ';
		MyStringCpy(&pathAndNameAndSrchFltr[ln],MAX_PATH,fSearchViaF7::srchFrFileFltr);	
	}

	if(bUseDefaForAll[typeOfExecute] || (!p))
	 return defaRecrd.ExecuteInd(prnt,pathAndNameAndSrchFltr,p,typeOfExecute);

	int iRec=Record::FindRecFrExt(p+1);
	if(iRec<0)
	 return defaRecrd.ExecuteInd(prnt,pathAndNameAndSrchFltr,p+1,typeOfExecute);

	return Record::recs[iRec].ExecuteInd(prnt,pathAndNameAndSrchFltr,p+1,typeOfExecute);
}

BOOL QuickView(wchar_t* filePathAndName)
{	wchar_t *p=wcsrchr(filePathAndName,'.');
	if(!p)return FALSE;
	int iRec=Record::FindRecFrExt(p+1);
	if(iRec>-1)
	 return Record::recs[iRec].QuickView(filePathAndName);
	return FALSE;
}

wchar_t* findExactExt(wchar_t *src,wchar_t *findStr,int findStrLn)
{	wchar_t *p = src;
	do
	{	p = wcsstr(p,findStr);//_wcslwr(p) , O'zi plaginlarning ext i to lowerda ekan;
		if(p)
		{	if(*(p+findStrLn)==';' || *(p+findStrLn)==0)
				return p;
			p = p+findStrLn;
	}	}
	while(p);
	return p;
}

//11.05.14.Avvalgi versiyasida har 3tip plagin uchun umumiy 1xil plaginalr raqamini qaytarardi.Bu xato.To'g'riladim:
int FindPlgnFrmFileExtnsn(wchar_t *extnsn,int typeOfExecute,int *plgnTypeNum)//0-view,1-edit,2-execute
{wchar_t ext[32],*pext=_wcslwr(extnsn);int extLn=MyStringCpy(ext,31,pext);
	if(extLn<-1)return -1;
	int plgnCnt=-1;//************************** 11.05.2014y;
	for(int p=0; p<iPlgns; ++p)
	{if(plgns[p].exeType!=typeOfExecute)continue;
		++plgnCnt;
	 pext = findExactExt(plgns[p].extns,ext,extLn);
	 if(!pext)continue;
	 //oxiri g'ujmon bo'lishi ham mumkin;
	 //if((*(pext+extLn)) && (*(pext+extLn)!=';'))continue;
	 *plgnTypeNum = plgnCnt;
	 return p;
	}
	*plgnTypeNum=-1;
	return -1;
}

int FindPlgnTypeNum(int toPlgnNum,int exType)
{	int t=-1;
	for(int j=0; j<=toPlgnNum; ++j)
	{if(exType==plgns[j].exeType)
		++t;
	}
	return t>-1?t:0;
}

LRESULT CALLBACK WhichAssocPlgnDlgProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
int i;LPVOID *par=(LPVOID*)GetWindowLongPtr(hDlg,GWLP_USERDATA);
	switch(message)
	{	case WM_INITDIALOG:RECT rc;
			SetWindowLongPtr(hDlg,GWLP_USERDATA,lParam);
			GetWindowRect(hDlg, &rc);
			int width,left,height,top;
			width = rc.right - rc.left;
			left = conf::wndLeft + (conf::wndWidth - width)/2;
			height = rc.bottom - rc.top;
			top = conf::wndTop + (conf::wndHeight - height)/2;
			MoveWindow(hDlg, left, top+20, width, height, TRUE);
			par=(LPVOID*)lParam;
			SetDlgItemText(hDlg,IDC_EDIT1,(wchar_t*)par[0]);
			SetDlgItemText(hDlg,IDC_EDIT2,((int)par[1])==0?L"view":L"edit");
			for(i=0; i<iPlgns; ++i)
			{	if((int)par[1]==plgns[i].exeType)
					SendMessage(GetDlgItem(hDlg,IDC_COMBO_CUSTOM),CB_ADDSTRING,0,(LPARAM)plgns[i].path);
			}
			SendMessage(GetDlgItem(hDlg,IDC_COMBO_CUSTOM),CB_SETCURSEL,0,0);
			//MyButtonFrRCBtn(hDlg,IDOK,conf::Dlg.iBtnsType);
			//MyButtonFrRCBtn(hDlg,IDCANCEL,conf::Dlg.iBtnsType);
			break;
		case WM_COMMAND:
			switch(LOWORD(wParam))
			{	//case IDC_COMBO_CUSTOM:
				//	break;
				case IDOK:
					int r;r=(int)SendMessage(GetDlgItem(hDlg,IDC_COMBO_CUSTOM),CB_GETCURSEL,0,0);
					int j,plgnTypeNum;plgnTypeNum=-1;
					if(CB_ERR!=r)for(j=0; j<iPlgns; ++j)
					{	if((int)par[1]==plgns[j].exeType)
						{	if(++plgnTypeNum==r)
								break;
					}	}
					EndDialog(hDlg,r!=CB_ERR?j:0);
					break;
				case IDCANCEL:
					EndDialog(hDlg,-1);
					break;
			}
			break;
	}
	return FALSE;
}

VOID SetTotalCntInDlg(HWND hDlg)
{wchar_t s[16];int i=(int)SendMessage(GetDlgItem(hDlg,IDC_COMBO_VIEW_FILE_ASSOC_EXT),CB_GETCOUNT,0,0);
	if(CB_ERR!=i)
	{StringCchPrintf(s,16,L"%d",i);
	 SetDlgItemText(hDlg,IDC_EDIT_TOTAL_EXTENSIONS,s);
}	}

VOID ClearAuxCntrls(HWND hDlg)
{	SendMessage(GetDlgItem(hDlg,IDC_COMBO_TYPE_OF_ASSOCIATIONS),CB_SETCURSEL,-1,0);
    SendMessage(GetDlgItem(hDlg,IDC_COMBO_SINO_VIEW_EXECUT_PLUGINS),CB_SETCURSEL,-1,0);
    SendMessage(GetDlgItem(hDlg,IDC_COMBO_SINO_VIEW_REGISTRY_EXECUT),CB_SETCURSEL,-1,0);
    SendMessage(GetDlgItem(hDlg,IDC_COMBO_USER_DEFINED),CB_SETCURSEL,-1,0);
	SetDlgItemText(hDlg,IDC_EDIT_DATA1,L"");
	SetDlgItemText(hDlg,IDC_EDIT_DATA2,L"");
	SetDlgItemText(hDlg,IDC_EDIT_DATA3,L"");
}

LRESULT CALLBACK confDlgProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
wchar_t s[MAX_PATH];
int i,l,iExeType=(int)GetWindowLongPtr(hDlg,GWLP_USERDATA);
	switch(message)
	{	case WM_INITDIALOG:
			//LoadString(hInst,IDS_STRINGSW_14,s,MAX_PATH);
			//SetWindowText(hDlg,s);
			//MyButtonFrRCBtn(hDlg,IDOK,0);
			SetWindowLongPtr(hDlg,GWLP_USERDATA,lParam);
			LoadString(hInst,IDS_STRINGSW_297,s,MAX_PATH-1);
			SendMessage(GetDlgItem(hDlg,IDC_COMBO_TYPE_OF_ASSOCIATIONS),CB_ADDSTRING,0,(LPARAM)s);//L"From Windows registry.");
			LoadString(hInst,IDS_STRINGSW_298,s,MAX_PATH-1);
			SendMessage(GetDlgItem(hDlg,IDC_COMBO_TYPE_OF_ASSOCIATIONS),CB_ADDSTRING,0,(LPARAM)s);//L"From Sino viewers list.");
			LoadString(hInst,IDS_STRINGSW_299,s,MAX_PATH-1);
			SendMessage(GetDlgItem(hDlg,IDC_COMBO_TYPE_OF_ASSOCIATIONS),CB_ADDSTRING,0,(LPARAM)s);//L"User defined.");
			iExeType=(int)lParam;	
			for(i=0; i<iPlgns; ++i)
			{	if(iExeType!=plgns[i].exeType)continue;
				l=MyStringCpy(s,MAX_PATH,plgns[i].extns);
				s[l++] = ' ';
				l=MyStringCpy(&s[l],MAX_PATH-l-1,plgns[i].path);
				SendMessage(GetDlgItem(hDlg,IDC_COMBO_SINO_VIEW_EXECUT_PLUGINS),CB_ADDSTRING,0,(LPARAM)s);
			}
			LoadString(hInst,IDS_STRINGSW_296,s,MAX_PATH);//"File associations/View:"
			SetWindowText(hDlg,s);
			LoadString(hInst,IDS_STRINGSW_300,s,MAX_PATH);//"File extensions:"
			SetDlgItemText(hDlg,IDC_STATIC1,s);
			LoadString(hInst,IDS_STRINGSW_301,s,MAX_PATH);//"Total:"
			SetDlgItemText(hDlg,IDC_STATIC2,s);
			LoadString(hInst,IDS_STRINGSW_302,s,MAX_PATH);//"Type of associations:"
			SetDlgItemText(hDlg,IDC_STATIC3,s);
			LoadString(hInst,IDS_STRINGSW_303,s,MAX_PATH);//"Add extension"
			SetDlgItemText(hDlg,IDC_BUTTON_ADD_EXT,s);
			LoadString(hInst,IDS_STRINGSW_304,s,MAX_PATH);//"Extension data from registry:"
			SetDlgItemText(hDlg,IDC_STATIC6,s);
			LoadString(hInst,IDS_STRINGSW_305,s,MAX_PATH);//"Sino view-executable plugins:"
			SetDlgItemText(hDlg,IDC_STATIC7,s);
			LoadString(hInst,IDS_STRINGSW_306,s,MAX_PATH);//"Registry view-executables:"
			SetDlgItemText(hDlg,IDC_STATIC8,s);
			LoadString(hInst,IDS_STRINGSW_307,s,MAX_PATH);//"Path of the user defined viewer:"
			SetDlgItemText(hDlg,IDC_STATIC5,s);
			LoadString(hInst,IDS_STRINGSW_308,s,MAX_PATH);//"Delete from list"
			SetDlgItemText(hDlg,IDC_BUTTON_DELETE,s);
			LoadString(hInst,IDS_STRINGSW_45,s,MAX_PATH);//"Browse"
			SetDlgItemText(hDlg,IDC_BUTTON_BROWSE_VIEWER,s);
			LoadString(hInst,IDS_STRINGSW_309,s,MAX_PATH);//"Standard view routine params:"
			SetDlgItemText(hDlg,IDC_STATIC9,s);
			LoadString(hInst,IDS_STRINGSW_310,s,MAX_PATH);//"Use console process"
			SetDlgItemText(hDlg,IDC_CHECK_STD_PARAMS_USE_CONSOLE,s);
			LoadString(hInst,IDS_STRINGSW_311,s,MAX_PATH);//"Set command line in path string"
			SetDlgItemText(hDlg,IDC_CHECK_STD_PARAMS_USE_CMND_LINE,s);
			LoadString(hInst,IDS_STRINGSW_312,s,MAX_PATH);//"Use std.sizes:"
			SetDlgItemText(hDlg,IDC_CHECK_STD_PARAMS_USE_STD_SIZES,s);
			LoadString(hInst,IDS_STRINGSW_313,s,MAX_PATH);//"Scrn.Xpos:"
			SetDlgItemText(hDlg,IDC_STATIC10,s);
			LoadString(hInst,IDS_STRINGSW_314,s,MAX_PATH);//"Scrn.Ypos:"
			SetDlgItemText(hDlg,IDC_STATIC11,s);
			LoadString(hInst,IDS_STRINGSW_315,s,MAX_PATH);//"Scrn.Width:"
			SetDlgItemText(hDlg,IDC_STATIC12,s);
			LoadString(hInst,IDS_STRINGSW_316,s,MAX_PATH);//"Scrn.Height:"
			SetDlgItemText(hDlg,IDC_STATIC13,s);
			LoadString(hInst,IDS_STRINGSW_317,s,MAX_PATH);//"Reset extension list"
			SetDlgItemText(hDlg,IDC_BUTTON_RESET,s);
			LoadString(hInst,IDS_STRINGSW_41,s,MAX_PATH);//"OK"
			SetDlgItemText(hDlg,IDOK,s);
			LoadString(hInst,IDS_STRINGSW_13,s,MAX_PATH);//"Cancel"
			SetDlgItemText(hDlg,IDCANCEL,s);

			SendMessage(GetDlgItem(hDlg,IDC_COMBO_STD_PARAMS_CALL_FUNC),CB_ADDSTRING,0,(LPARAM)L"use ShellExecute");
			SendMessage(GetDlgItem(hDlg,IDC_COMBO_STD_PARAMS_CALL_FUNC),CB_ADDSTRING,0,(LPARAM)L"use ShellExecuteEx");
			SendMessage(GetDlgItem(hDlg,IDC_COMBO_STD_PARAMS_CALL_FUNC),CB_ADDSTRING,0,(LPARAM)L"use CreateProcess");
			SendMessage(GetDlgItem(hDlg,IDC_COMBO_STD_PARAMS_CALL_FUNC),CB_ADDSTRING,0,(LPARAM)L"use CreateProcessEx");

			SendMessage(GetDlgItem(hDlg,IDC_COMBO_STD_PARAMS_PRIORITY_CLASS),CB_ADDSTRING,0,(LPARAM)L"ABOVE_NORMAL_PRIORITY_CLASS");
			SendMessage(GetDlgItem(hDlg,IDC_COMBO_STD_PARAMS_PRIORITY_CLASS),CB_ADDSTRING,0,(LPARAM)L"BELOW_NORMAL_PRIORITY_CLASS");
			SendMessage(GetDlgItem(hDlg,IDC_COMBO_STD_PARAMS_PRIORITY_CLASS),CB_ADDSTRING,0,(LPARAM)L"HIGH_PRIORITY_CLASS");
			SendMessage(GetDlgItem(hDlg,IDC_COMBO_STD_PARAMS_PRIORITY_CLASS),CB_ADDSTRING,0,(LPARAM)L"IDLE_PRIORITY_CLASS");
			SendMessage(GetDlgItem(hDlg,IDC_COMBO_STD_PARAMS_PRIORITY_CLASS),CB_ADDSTRING,0,(LPARAM)L"NORMAL_PRIORITY_CLASS");
			SendMessage(GetDlgItem(hDlg,IDC_COMBO_STD_PARAMS_PRIORITY_CLASS),CB_ADDSTRING,0,(LPARAM)L"REALTIME_PRIORITY_CLASS");

			/*MyButtonFrRCBtn(hDlg,IDC_BUTTON_ADD_EXT,conf::Dlg.iBtnsType);
			MyButtonFrRCBtn(hDlg,IDC_BUTTON_DELETE,conf::Dlg.iBtnsType);
			MyButtonFrRCBtn(hDlg,IDC_BUTTON_BROWSE_VIEWER,conf::Dlg.iBtnsType);
			MyButtonFrRCBtn(hDlg,IDC_BUTTON_RESET,conf::Dlg.iBtnsType);
			MyButtonFrRCBtn(hDlg,IDOK,conf::Dlg.iBtnsType);
			MyButtonFrRCBtn(hDlg,IDCANCEL,conf::Dlg.iBtnsType);
			MyButtonFrRCBtn(hDlg,IDC_BUTTON1,conf::Dlg.iBtnsType);
			MyButtonFrRCBtn(hDlg,IDC_BUTTON2,conf::Dlg.iBtnsType);
			MyButtonFrRCBtn(hDlg,IDC_BUTTON3,conf::Dlg.iBtnsType);
			MyButtonFrRCBtn(hDlg,IDC_BUTTON_DELETE_ALL_CUSTOM,conf::Dlg.iBtnsType);
			*/
			Record::FillToDlg(hDlg,iExeType);
			SetTotalCntInDlg(hDlg);
			
			int hot;hot=panel[Panel::iActivePanel].GetHot();
			if(hot>0)
			{	wchar_t *ex=panel[Panel::iActivePanel].GetItem(hot)->GetExt()+1;
				if(ex && ex[0])
				{	SendMessage(GetDlgItem(hDlg,IDC_COMBO_VIEW_FILE_ASSOC_EXT),CB_SELECTSTRING,0,(LPARAM)ex);
					/*HWND hCmb=GetDlgItem(hDlg,IDC_COMBO_VIEW_FILE_ASSOC_EXT);
					int l=SendMessage(hCmb,CB_GETCOUNT,0,0);
					for(int k=0; k<l; ++k)
					{	if(CB_ERR!=SendMessage(hCmb,CB_GETLBTEXT,k,(LPARAM)s))
						{	if(0==wcscmp(s,ex))
							{	SendMessage(hCmb,CB_SETCURSEL,k,0);
								break;
					}	}	}*/
			}	}
			break;
		case WM_COMMAND:
			switch(LOWORD(wParam))
			{	case IDC_COMBO_VIEW_FILE_ASSOC_EXT:
					if(CBN_SELCHANGE==HIWORD(wParam))
						OnExtensionLBChanging(hDlg,iExeType);
					else if(CBN_EDITCHANGE==HIWORD(wParam))
					{tmpCB.GetCBEditText(GetDlgItem(hDlg,IDC_COMBO_VIEW_FILE_ASSOC_EXT),s,MAX_PATH);
					 int sel=(int)SendMessage(GetDlgItem(hDlg,IDC_COMBO_VIEW_FILE_ASSOC_EXT),CB_FINDSTRING,0,(LPARAM)s);
					 if(sel!=CB_ERR)
					  Record::recs[sel].Output(hDlg,iExeType);
					 else ClearAuxCntrls(hDlg);
					}
					break;
				case IDC_COMBO_STD_PARAMS_CALL_FUNC:
					if(CBN_SELCHANGE==HIWORD(wParam))
					 stdViewRoutFuncType[iExeType]=(int)SendMessage(GetDlgItem(hDlg,IDC_COMBO_USER_DEFINED),CB_GETCURSEL,0,0);
					break;
				case IDC_COMBO_STD_PARAMS_PRIORITY_CLASS:
					if(CBN_SELCHANGE==HIWORD(wParam))
					 stdViewRoutPrtyClss[iExeType]=(int)SendMessage(GetDlgItem(hDlg,IDC_COMBO_STD_PARAMS_PRIORITY_CLASS),CB_GETCURSEL,0,0);
					break;
				case IDC_CHECK_STD_PARAMS_USE_CONSOLE:
					bCrtConsPrcss[iExeType] = (BST_CHECKED==SendMessage(
													GetDlgItem(hDlg,IDC_CHECK_STD_PARAMS_USE_CONSOLE),
													BM_GETCHECK,0,0)) ? true:false;
					break;
				case IDC_CHECK_STD_PARAMS_USE_CMND_LINE:
					bSetParamsInCmndLn[iExeType] = (BST_CHECKED==SendMessage(
													GetDlgItem(hDlg,IDC_CHECK_STD_PARAMS_USE_CMND_LINE),
													BM_GETCHECK,0,0)) ? true:false;
					break;
				case IDC_CHECK_STD_PARAMS_USE_STD_SIZES:
					bUseStdSize[iExeType] = (BST_CHECKED==SendMessage(
													GetDlgItem(hDlg,IDC_CHECK_STD_PARAMS_USE_STD_SIZES),
													BM_GETCHECK,0,0)) ? true:false;
					break;
				case IDC_CHECK1:
					bUseDefaForAll[iExeType] = (BST_CHECKED==SendMessage(
													GetDlgItem(hDlg,IDC_CHECK1),
													BM_GETCHECK,0,0)) ? true:false;
					break;
				case IDC_CHECK_USE_SINO_EXECUTABLE:
					bUseExecutableInReset[iExeType] = (BST_CHECKED==SendMessage(
													GetDlgItem(hDlg,IDC_CHECK_USE_SINO_EXECUTABLE),
													BM_GETCHECK,0,0)) ? true:false;
					break;
				case IDC_EDIT_STD_X:
					GetDlgItemText(hDlg,IDC_EDIT_STD_X,s,MAX_PATH);
					stdXPos[iExeType]=_wtoi(s);
					break;
				case IDC_EDIT_STD_Y:
					GetDlgItemText(hDlg,IDC_EDIT_STD_Y,s,MAX_PATH);
					stdYPos[iExeType]=_wtoi(s);
					break;
				case IDC_EDIT_STD_W:
					GetDlgItemText(hDlg,IDC_EDIT_STD_W,s,MAX_PATH);
					stdW[iExeType]=_wtoi(s);
					break;
				case IDC_EDIT_STD_H:
					GetDlgItemText(hDlg,IDC_EDIT_STD_H,s,MAX_PATH);
					stdH[iExeType]=_wtoi(s);
					break;
				case IDC_BUTTON_DELETE:
					int sel;sel=(int)SendMessage(GetDlgItem(hDlg,IDC_COMBO_VIEW_FILE_ASSOC_EXT),CB_GETCURSEL,0,0);
				    if(CB_ERR!=sel)
					{SendMessage(GetDlgItem(hDlg,IDC_COMBO_VIEW_FILE_ASSOC_EXT),CB_DELETESTRING,sel,0);
 					 Record::Erase(sel);
					 SetTotalCntInDlg(hDlg);
					 ClearAuxCntrls(hDlg);
					}
					break;
				case IDOK:
					//WriteConfig();
					EndDialog(hDlg,0);
					break;
				case IDCANCEL:
					EndDialog(hDlg,0);
					break;
				case IDC_BUTTON_RESET:
					Record::Save();
					Record::FreeRecords();
					SendMessage(GetDlgItem(hDlg,IDC_COMBO_VIEW_FILE_ASSOC_EXT),CB_RESETCONTENT,0,0);
					SendMessage(GetDlgItem(hDlg,IDC_COMBO_SINO_VIEW_REGISTRY_EXECUT),CB_RESETCONTENT,0,0);
					Record::FillFrReg();
					Record::AddFrSinoEx(iExeType);
					Record::ReadAppend(iExeType);
					Record::FillToDlg(hDlg,iExeType);
					Record::recs[0].Output(hDlg,iExeType);
					SetTotalCntInDlg(hDlg);
					SendMessage(GetDlgItem(hDlg,IDC_COMBO_VIEW_FILE_ASSOC_EXT),CB_SETCURSEL,0,0);
					break;
				case IDC_BUTTON_BROWSE_VIEWER:
					OPENFILENAME of;
					memset(&of,0,sizeof(OPENFILENAME));
					of.lStructSize      = sizeof(OPENFILENAME);
					of.Flags            = OFN_EXPLORER|OFN_FILEMUSTEXIST;
					of.nMaxFile			= MAX_PATH;
					of.hwndOwner        = hDlg;
					of.lpstrFile        = s;s[0]=0;
					of.lpstrFilter = L"All *.exe files \0*.exe\0All *.bat files\0*.bat\0All files\0*.*\0";
					of.lpstrTitle  = L"Get user defined view module ...";
					of.lpstrFileTitle   = L"View executable configuration.";
					if(GetOpenFileName(&of))
					{	SendMessage(GetDlgItem(hDlg,IDC_COMBO_USER_DEFINED),CB_ADDSTRING,0,(LPARAM)s);
						SendMessage(GetDlgItem(hDlg,IDC_COMBO_USER_DEFINED),CB_SETCURSEL,
							SendMessage(GetDlgItem(hDlg,IDC_COMBO_USER_DEFINED),CB_GETCOUNT,0,0)-1,0);
					}
					break;
				case IDC_BUTTON_ADD_EXT:
					s[0]=0;tmpCB.GetCBEditText(GetDlgItem(hDlg,IDC_COMBO_VIEW_FILE_ASSOC_EXT),s,MAX_PATH);
					if(s[0])
					{int cnt=AddIfNotInExtensionListInLB(s,hDlg);
					 if(cnt>-1)
					 {SendMessage(GetDlgItem(hDlg,IDC_COMBO_VIEW_FILE_ASSOC_EXT),CB_SETCURSEL,cnt,0);
					  Record::Add(s,NULL,NULL,0,iExeType);
					}}
					SetTotalCntInDlg(hDlg);
					break;
				case IDC_BUTTON1:
					defaRecrd.Output(hDlg,iExeType);
					break;
				case IDC_BUTTON2:
					defaRecrd.Input(hDlg,iExeType);
					break;
				case IDC_BUTTON3:
					sel=(int)SendMessage(GetDlgItem(hDlg,IDC_COMBO_VIEW_FILE_ASSOC_EXT),CB_GETCURSEL,0,0);
					if(sel!=CB_ERR)
						Record::recs[sel].Input(hDlg,iExeType);
					break;
				case IDC_BUTTON_DELETE_ALL_CUSTOM://Get from regystry:
					sel=(int)SendMessage(GetDlgItem(hDlg,IDC_COMBO_VIEW_FILE_ASSOC_EXT),CB_GETCURSEL,0,0);
					if(sel!=CB_ERR)
					{wchar_t extDescp[MAX_PATH],extType[MAX_PATH],prgDescp[MAX_PATH];
					 wchar_t ex[32]=L".";MyStringCpy(&ex[1],31,Record::recs[sel].extensn);
					 if(GetExtParams(ex,extDescp,extType,prgDescp))
					 {Record::recs[sel].Change(Record::recs[sel].extensn,prgDescp,extDescp,0,iExeType);
					  Record::recs[sel].Output(hDlg,iExeType);
					}}
					break;
			}
			break;
	}
	return FALSE;
}
//Faqat openga ochadur;
BOOL GetExtParams(wchar_t *ext,wchar_t *extDescp,wchar_t *extType,wchar_t *prgDescp)
{
HKEY k,kCmnd=NULL; LONG r; DWORD sz=MAX_PATH; wchar_t buf[520];

	r = RegOpenKeyEx(HKEY_CLASSES_ROOT,ext,0,KEY_QUERY_VALUE,&k);
	if(ERROR_SUCCESS!=r) return FALSE;

	sz = MAX_PATH;
	r = RegQueryValueEx(k,NULL,NULL,NULL,(LPBYTE)buf,&sz);
	if(ERROR_SUCCESS!=r)
	{	RegCloseKey(k);
		return FALSE;
	}
	RegCloseKey(k);
	MyStringCpy(extDescp,MAX_PATH,buf);

	r = RegOpenKeyEx(HKEY_CLASSES_ROOT,(LPWSTR)buf,0,KEY_QUERY_VALUE,&k);
	if(ERROR_SUCCESS!=r)
	{	RegCloseKey(k);
		return FALSE;
	}

	r = RegQueryValueEx(k,NULL,NULL,NULL,NULL,&sz);
	if(ERROR_SUCCESS!=r || sz>=MAX_PATH)
	{	RegCloseKey(k);
		return FALSE;
	}
	r = RegQueryValueEx(k,NULL,NULL,NULL,(LPBYTE)buf,&sz);
	if(ERROR_SUCCESS!=r)
	{	RegCloseKey(k);
		return FALSE;
	}
	MyStringCpy(extType,MAX_PATH,buf);

	r = RegOpenKeyEx(k,L"Shell\\Open\\Command",0,KEY_QUERY_VALUE,&kCmnd);
	if(ERROR_SUCCESS!=r)
	{	RegCloseKey(k);
		MyStringCpy(extType,5,L"NULL");
		return TRUE;
	}

	r = RegQueryValueEx(kCmnd,NULL,NULL,NULL,NULL,&sz);
	if(ERROR_SUCCESS!=r || sz>=MAX_PATH)
	{	RegCloseKey(k);
		return FALSE;
	}
	r = RegQueryValueEx(kCmnd,NULL,NULL,NULL,(LPBYTE)buf,&sz);
	if(ERROR_SUCCESS!=r)
	{	RegCloseKey(kCmnd);
		RegCloseKey(k);
		MyStringCpy(extType,5,L"NULL");
		return TRUE;
	}
	buf[sz/sizeof(wchar_t)]=0;
	wchar_t *p = &buf[0];
	while('"'==*p)++p;
	wchar_t *pp = wcschr(p,'"');
	if(pp)*pp=0;

	wchar_t s[MAX_PATH],ls[MAX_PATH];
	int l=ExpandEnvironmentStrings(p,s,MAX_PATH);
	
	for(int i=l-2; i>1; --i)
	{if(GetLongPathName(s,ls,MAX_PATH))break;
	 s[i]=0;
	}

	p = wcsstr(ls,L":\\");
    if(!p)MyStringCpy(prgDescp,5,L"NULL");
	else
	{	//p = wcschr(p,' ');
		//if(p)*p=0;
		MyStringCpy(prgDescp,MAX_PATH,ls);
	} 

	RegCloseKey(kCmnd);
	RegCloseKey(k);

//	SHFILEINFO si;
//	SHGetFileInfo(ext,0,&si,sizeof(si),SHGFI_EXETYPE);
	return TRUE;
}

/*void SetExtensionRegParams(wchar_t *s,HWND hDlg)
{
wchar_t ext[MAX_PATH]=L".";MyStringCpy(&ext[1],MAX_PATH-2,s);
HKEY k,kCmnd=NULL; LONG r; DWORD sz=520; wchar_t buf[520];

	r = RegOpenKeyEx(HKEY_CLASSES_ROOT,ext,0,KEY_QUERY_VALUE,&k);
	if(ERROR_SUCCESS!=r)
	{Fin:SetDlgItemText(hDlg,IDC_EDIT_DATA1,L"");
		 SetDlgItemText(hDlg,IDC_EDIT_DATA2,L"");
		 SetDlgItemText(hDlg,IDC_EDIT_DATA3,L"");
		 SendMessage(GetDlgItem(hDlg,IDC_COMBO_SINO_VIEW_REGISTRY_EXECUT),CB_SETCURSEL,-1,0);
		 return;
	}

	sz = 520;
	r = RegQueryValueEx(k,NULL,NULL,NULL,(LPBYTE)buf,&sz);
	if(ERROR_SUCCESS!=r)
	{	RegCloseKey(k);
		goto Fin;
	}
	RegCloseKey(k);
	SetDlgItemText(hDlg,IDC_EDIT_DATA1,buf);//MyStringCpy(extDescp,520,buf);

	r = RegOpenKeyEx(HKEY_CLASSES_ROOT,(LPWSTR)buf,0,KEY_QUERY_VALUE,&k);
	if(ERROR_SUCCESS!=r)
	{	RegCloseKey(k);
		goto Fin;
	}

	r = RegQueryValueEx(k,NULL,NULL,NULL,NULL,&sz);
	if(ERROR_SUCCESS!=r || sz>=MAX_PATH)
	{	RegCloseKey(k);
		goto Fin;
	}
	r = RegQueryValueEx(k,NULL,NULL,NULL,(LPBYTE)buf,&sz);
	if(ERROR_SUCCESS!=r)
	{	RegCloseKey(k);
		goto Fin;
	}
	SetDlgItemText(hDlg,IDC_EDIT_DATA2,buf);//MyStringCpy(extType,520,buf);

	r = RegOpenKeyEx(k,L"Shell\\Open\\Command",0,KEY_QUERY_VALUE,&kCmnd);
	if(ERROR_SUCCESS!=r)
	{	RegCloseKey(k);
		SetDlgItemText(hDlg,IDC_EDIT_DATA2,L"");//MyStringCpy(extType,5,L"NULL");
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_SINO_VIEW_REGISTRY_EXECUT),CB_SETCURSEL,-1,0);
		return;
	}

	r = RegQueryValueEx(kCmnd,NULL,NULL,NULL,NULL,&sz);
	if(ERROR_SUCCESS!=r || sz>=MAX_PATH)
	{	RegCloseKey(k);
		goto Fin;
	}
	r = RegQueryValueEx(kCmnd,NULL,NULL,NULL,(LPBYTE)buf,&sz);
	if(ERROR_SUCCESS!=r)
	{	RegCloseKey(kCmnd);
		RegCloseKey(k);
		SetDlgItemText(hDlg,IDC_EDIT_DATA2,L"");//MyStringCpy(extType,5,L"NULL");
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_SINO_VIEW_REGISTRY_EXECUT),CB_SETCURSEL,-1,0);
		return;
	}
	wchar_t *p = &buf[0];
	while('"'==*p)++p;
	wchar_t *pp = wcschr(p,'"');
	if(pp)*pp=0;
	wchar_t ss[MAX_PATH];
	ExpandEnvironmentStrings(p,ss,MAX_PATH);
	p = wcsstr(ss,L":\\");
	if(!p)
	{	SetDlgItemText(hDlg,IDC_EDIT_DATA3,L"");//MyStringCpy(prgDescp,5,L"NULL");
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_SINO_VIEW_REGISTRY_EXECUT),CB_SETCURSEL,-1,0);
	}
	else
	{	//p = wcschr(p,' ');
		//if(p)*p=0;
		SetDlgItemText(hDlg,IDC_EDIT_DATA3,ss);//MyStringCpy(prgDescp,260,s);
		int cnt=(int)SendMessage(GetDlgItem(hDlg,IDC_COMBO_SINO_VIEW_REGISTRY_EXECUT),CB_GETCOUNT,0,0);
		for(int c=0; c<cnt; ++c)
		{	wchar_t txt[MAX_PATH];
			SendMessage(GetDlgItem(hDlg,IDC_COMBO_SINO_VIEW_REGISTRY_EXECUT),CB_GETLBTEXT,c,(LPARAM)txt);
			if(wcsstr(txt,ss))
			{	SendMessage(GetDlgItem(hDlg,IDC_COMBO_SINO_VIEW_REGISTRY_EXECUT),CB_SETCURSEL,c,0);
				break;
	}	}	}

	RegCloseKey(kCmnd);
	RegCloseKey(k);
}*/

void OnExtensionLBChanging(HWND hDlg,int exeType)
{wchar_t s[MAX_PATH];int l,recNum;
HWND hCmb=GetDlgItem(hDlg,IDC_COMBO_VIEW_FILE_ASSOC_EXT);
int sel=(int)SendMessage(hCmb,CB_GETCURSEL,0,0);
	if(CB_ERR==sel)return;
	l=(int)SendMessage(hCmb,CB_GETLBTEXT,sel,(LPARAM)s);
	if(CB_ERR==l)return;
	if(l<1)return;
	recNum=Record::FindRecFrExt(s);
	if(recNum<0)
	{Not:SendMessage(GetDlgItem(hDlg,IDC_COMBO_TYPE_OF_ASSOCIATIONS),CB_SETCURSEL,-1,0);//unselect;
	 SetDlgItemText(hDlg,IDC_EDIT_DATA1,L"");
	 SetDlgItemText(hDlg,IDC_EDIT_DATA2,L"");
	 SetDlgItemText(hDlg,IDC_EDIT_DATA3,L"");
	 SendMessage(GetDlgItem(hDlg,IDC_COMBO_SINO_VIEW_EXECUT_PLUGINS),CB_SETCURSEL,-1,0);
	 SendMessage(GetDlgItem(hDlg,IDC_COMBO_SINO_VIEW_REGISTRY_EXECUT),CB_SETCURSEL,-1,0);
	 SendMessage(GetDlgItem(hDlg,IDC_COMBO_USER_DEFINED),CB_SETCURSEL,-1,0);
	 return;
	}
	if(!Record::recs[recNum].Output(hDlg,exeType))goto Not;
}

VOID ListDirLoadExctblPlugins(HWND hWnd,wchar_t *path)
{
WIN32_FIND_DATA ff;
HANDLE hf = INVALID_HANDLE_VALUE;
wchar_t s[MAX_PATH];
	int l=MyStringCpy(s,MAX_PATH-1,path);
	if(MyStringRemoveLastCharCheckPre(s,MAX_PATH-1,'*','\\'))
		--l;

	hf = MyFindFirstFileEx(path,FindExInfoStandard,&ff,FindExSearchLimitToDirectories,NULL,0);
	do
	{	if(INVALID_HANDLE_VALUE==hf) return;
		if(FILE_ATTRIBUTE_DIRECTORY & ff.dwFileAttributes)//if(IsDirectory(path, &ff, FALSE))
		{	if(IsCrntOrPrntDirAttrb(ff.cFileName))
			{	int n=MyStringCpy(&s[l],MAX_PATH-1,ff.cFileName);
				MyStringCpy(&s[l+n],MAX_PATH-1-l,L"\\*");
				ListDirLoadExctblPlugins(hWnd,s);
		}	}
		else
			TryLoadPlugin(hWnd,s,ff.cFileName,l);
	}
	while(FindNextFile(hf, &ff));
	FindClose(hf);
}

VOID FreePlugins()//CArch::~CArch ga qara, ochiq qolib ketgan arxivlar qoladur;
{
	for(int p=0; p<iPlgns; p++)
	{	free(plgns[p].path);
		free(plgns[p].extns);
		free(plgns[p].pExtns);
		free(plgns[p].ExtnsLns);
	}
	if(plgns)free(plgns);
	plgns=0;
	Record::Save();
	Record::FreeRecords();
	iPlgns=iMaxPlgns=0;
}

VOID LoadPlugins(HWND wnd)
{
	iPlgns=0;
	wchar_t *vrtPnlPlgPth = MyStringAddModulePath(L"Plugins\\Executables\\*");
	ListDirLoadExctblPlugins(wnd,vrtPnlPlgPth);
	Record::Init();
}

VOID TryLoadPlugin(HWND hWnd,wchar_t *pth,wchar_t* name,int l)
{HMODULE hm=0;
	if(iPlgns>conf::Dlg.totalAllovedArchvr * 25)
	{	Err::msg(hWnd,0,L"There are any executable plugins(above 500), ignore others...");
		return;
	}

	MyStringCpy(&pth[l],MAX_PATH-1,name);

#ifdef _WIN64
	if(wcsstr(pth,L"notepad++.exe"))
	{	hm = LoadLibraryEx(pth,NULL,LOAD_LIBRARY_AS_DATAFILE);
		if(!hm)
			return;
		goto skp;
	}
#endif
	
	if(!Execution::IsThisValidExeFile(pth))
		return;

skp:

BEGIN_TRY

	if(!hm)
		hm = LoadLibrary(pth);
	if(!hm)
		return;

	HRSRC rs = FindResource(hm,L"GET_SINO_EXECUTABLE_PLUGIN_TYPE",L"SINOSTRING");
	if(!rs)
	{Fin:FreeLibrary(hm);
		return;
	}
	HGLOBAL glr = LoadResource(hm,rs);
	if(!glr) goto Fin;
	LPVOID pres = LockResource(glr);
	if(!pres)goto Fin;

	int tp = -1;
	if(wcsstr((wchar_t*)pres,L"view") || strstr((char*)pres,"view"))
		tp = 0;
	else if(wcsstr((wchar_t*)pres,L"edit") || strstr((char*)pres,"edit"))
		tp = 1;
	else if(wcsstr((wchar_t*)pres,L"execute") || strstr((char*)pres,"execute"))
		tp = 2;
	if(-1==tp)goto Fin;
	int kLoop=0;
Loop:
	rs = FindResource(hm,L"GET_EXTENSIONS",L"SINOSTRING");
	if(!rs)goto Fin;
	int resSz=SizeofResource(hm,rs);
	glr = LoadResource(hm,rs);
	if(!glr) goto Fin;
	pres = LockResource(glr);
	if(!pres)goto Fin;

	if(iPlgns>iMaxPlgns-1)
	{	iMaxPlgns += 15;
		if(!plgns)plgns = (exctblPlgn*)malloc(iMaxPlgns*sizeof(exctblPlgn));
		else plgns = (exctblPlgn*)realloc(plgns,iMaxPlgns*sizeof(exctblPlgn));
	}

	plgns[iPlgns].exeType = (tExctblPlgn::tExeType)tp;
	wchar_t *p,mpth[MAX_PATH];GetModuleFileName(NULL,mpth,MAX_PATH);
	p = wcsrchr(mpth,'\\');
	if(p)*(p+1)=0;
	p = wcsstr(pth,mpth);
	if(p)p=&pth[MyStringLength(mpth,MAX_PATH)];
	else p = pth;

	int ln = 1+MyStringLength(p,MAX_PATH);//pth
	plgns[iPlgns].path = (wchar_t*)malloc(2*ln);
	MyStringCpy(plgns[iPlgns].path,ln,p);//pth

	char *pa = CharNextA((LPCSTR)pres);
	if(pa-(char*)pres<2)
	{	plgns[iPlgns].extns = (wchar_t*)malloc(2*resSz+2);
		MultiByteToWideChar(AreFileApisANSI()?CP_ACP:CP_OEMCP,MB_PRECOMPOSED,(LPCSTR)pres,resSz,plgns[iPlgns].extns,resSz);
		for(int i=0; i<resSz; ++i)
			plgns[iPlgns].extns[i] = towlower(plgns[iPlgns].extns[i]);
	}
	else
	{	plgns[iPlgns].extns = (wchar_t*)malloc(resSz+2);
		//MyStringCpy(plgns[iPlgns].extns,resSz/2,(wchar_t*)pres);
		for(int i=0; i<resSz; ++i)
			plgns[iPlgns].extns[i] = towlower(((wchar_t*)pres)[i]);
	}
	plgns[iPlgns].extns[resSz]=0;

	//Nechta ext borligiyu, qaysi ekanligi:
	plgns[iPlgns].iNumExtns = 0;
	for(ln=0; ln<resSz; ++ln)
	{if(';'==plgns[iPlgns].extns[ln])
	  ++plgns[iPlgns].iNumExtns;
	}
	if(';'!=plgns[iPlgns].extns[resSz-1])
	  ++plgns[iPlgns].iNumExtns;
	plgns[iPlgns].pExtns=(wchar_t**)malloc(sizeof(wchar_t*)*plgns[iPlgns].iNumExtns);
	plgns[iPlgns].ExtnsLns=(int*)malloc(sizeof(int)*plgns[iPlgns].iNumExtns);

	int iBgn=0,iCnt=0;
	for(ln=0; ln<resSz; ++ln)
	{if(';'==plgns[iPlgns].extns[ln])
	 {plgns[iPlgns].pExtns[iCnt]=&plgns[iPlgns].extns[iBgn];
	  plgns[iPlgns].ExtnsLns[iCnt]=ln-iBgn;
	  ++iCnt;iBgn=ln+1;
	}}
	if(';'!=plgns[iPlgns].extns[resSz-1])
	{plgns[iPlgns].pExtns[iCnt]=&plgns[iPlgns].extns[iBgn];
	 plgns[iPlgns].ExtnsLns[iCnt]=ln-iBgn;
	}
	
	++iPlgns;

//Yana 1 marta tekshiraylikchi:
	if(kLoop++<1)
	{	int tp1 = -1;
		if(tp!=0 && (wcsstr((wchar_t*)pres,L"view") || strstr((char*)pres,"view")))
			tp1 = 0;
		else if(tp!=1 && (wcsstr((wchar_t*)pres,L"edit") || strstr((char*)pres,"edit")))
			tp1 = 1;
		else if(tp!=2 && (wcsstr((wchar_t*)pres,L"execute") || strstr((char*)pres,"execute")))
			tp1 = 2;
		if(-1!=tp1 && tp1 != tp)
		{	tp=tp1;
			goto Loop;
	}	}


	FreeLibrary(hm);
END_TRY
{
	Err::msg1(NULL,0,pth,L"Err.loading executable plgn.");
}}

int AddIfNotInExtensionListInLB(wchar_t *s,HWND hDlg)
{int iExist=-1;
wchar_t S[MAX_PATH],*ps=&S[0],*oldP=ps;
	HWND hCmb1=GetDlgItem(hDlg,IDC_COMBO_VIEW_FILE_ASSOC_EXT);
	int l=(int)SendMessage(hCmb1,CB_GETCOUNT,0,0);
	for(wchar_t *p=s; *oldP; ++p)
	{	*ps=*p;
		if(';'==(*ps) || 0==(*ps))
		{	*ps = 0;
			ps = &S[0];
			//check in LB:
			for(int k=0; k<l; ++k)
			{	wchar_t t[MAX_PATH];
				if(CB_ERR!=SendMessage(hCmb1,CB_GETLBTEXT,k,(LPARAM)t))
				{	if(0==wcscmp(S,t))
						{iExist=k;break;}
			}	}
			if(iExist<0)
			{	SendMessage(hCmb1,CB_INSERTSTRING,-1,(LPARAM)S);
				iExist = l;
		}	}
		else ++ps;
		oldP = p;
	}
	return iExist;
}

BOOL ViewWithPlugins(HWND prnt,wchar_t *pathAndName)
{LPVOID par[2]={(LPVOID)pathAndName,(LPVOID)0};
int iAssPlgn=(int)DialogBoxParam(hInst,MAKEINTRESOURCE(IDD_DIALOG_WHICH_ASSOC_PLGN),
							prnt,(DLGPROC)WhichAssocPlgnDlgProc,(LPARAM)&par[0]);
  if(iAssPlgn<0)return FALSE;
  //wchar_t sinoExe[MAX_PATH];GetModuleFileName(NULL,sinoExe,MAX_PATH);
  //wchar_t *p=wcsrchr(sinoExe,'\\');
  //if(p)*p=0;
  //return Execution::exePERoot(MyStringAddModulePath(plgns[iAssPlgn].path),pathAndName,sinoExe);
  return 0<Execution::exePESplitCmndLine(MyStringAddModulePath(plgns[iAssPlgn].path),pathAndName,conf::modulePath);
}

BOOL EditWithPlugins(HWND prnt,wchar_t *pathAndName)
{LPVOID par[2]={(LPVOID)pathAndName,(LPVOID)1};
int iAssPlgn=(int)DialogBoxParam(hInst,MAKEINTRESOURCE(IDD_DIALOG_WHICH_ASSOC_PLGN),
							prnt,(DLGPROC)WhichAssocPlgnDlgProc,(LPARAM)&par[0]);
  if(iAssPlgn<0)return FALSE;
  wchar_t sinoExe[MAX_PATH];GetModuleFileName(NULL,sinoExe,MAX_PATH);
  wchar_t *p=wcsrchr(sinoExe,'\\');
  if(p)*p=0;
  //return Execution::exePE(MyStringAddModulePath(plgns[iAssPlgn].path),pathAndName);
  return Execution::exePEPutSpaceToCmndLine(MyStringAddModulePath(plgns[iAssPlgn].path),pathAndName,sinoExe);
}

typedef HRESULT (__stdcall *SHOpenWithDialog_t)(HWND,const OPENASINFO*);
BOOL ViewWithOpen(HWND prnt,wchar_t *pathAndName)
{SHOpenWithDialog_t mySHOpenWithDialog;
 HMODULE hm = LoadLibrary(L"Shell32.dll");
 if(!hm)goto XP_OS;
 mySHOpenWithDialog = (SHOpenWithDialog_t)GetProcAddress(hm,"SHOpenWithDialog");
 if(!mySHOpenWithDialog)goto XP_OS;
	
 OPENASINFO oa;oa.pcszFile=pathAndName;oa.pcszClass=NULL;
 oa.oaifInFlags=OAIF_FORCE_REGISTRATION|OAIF_REGISTER_EXT|OAIF_EXEC;
 return (S_OK==mySHOpenWithDialog(prnt,&oa)?TRUE:FALSE);

XP_OS:
 wchar_t pars[MAX_PATH+32]=L"shell32.dll,OpenAs_RunDLL ";
 MyStringCpy(&pars[26],MAX_PATH-6,pathAndName);
 ShellExecute(prnt,L"open",L"rundll32.exe",pars,NULL,SW_SHOWNORMAL);
 return TRUE;
}

BOOL ViewWithBrowse(HWND prnt,wchar_t *pathAndName)
{	OPENFILENAME of;wchar_t s[2*MAX_PATH];
	memset(&of,0,sizeof(OPENFILENAME));
	of.lStructSize      = sizeof(OPENFILENAME);
	of.Flags            = OFN_EXPLORER|OFN_FILEMUSTEXIST;
	of.nMaxFile			= MAX_PATH;
	of.hwndOwner        = prnt;
	of.lpstrFile        = s;s[0]=0;
	of.lpstrFilter = L"All *.exe files \0*.exe\0All *.bat files\0*.bat\0All files\0*.*\0";
	of.lpstrTitle  = L"Get user defined view module ...";
	of.lpstrFileTitle   = L"View executable configuration.";
	if(GetOpenFileName(&of))
	{	//int l=MyStringLength(s,MAX_PATH);
		//s[l++]=' ';
		//MyStringCpy(&s[l],MAX_PATH,pathAndName);
		return Execution::exePE(s,pathAndName);
	}
	return FALSE;
}

//******** Buffer operations : **************************
//******** Buffer operations : **************************
//******** Buffer operations : **************************
//******** Buffer operations : **************************
//******** Buffer operations : **************************
//******** Buffer operations : **************************
//******** Buffer operations : **************************
//******** Buffer operations : **************************
//******** Buffer operations : **************************
Record *Record::recs=NULL;
int Record::iNumRecords=0;

Record::Record():extensn(0),execTrdId(0)
{for(int i=0; i<3; ++i)
 {path[i]=0;
  desc[i]=0;
  type[i]=fromReg; 
  iSinoExPlgnNum[i]=0;
  iSinoExPlgnTypeNum[i]=0;
}}
Record::~Record()
{}

VOID Record::FreeRecords()
{if(recs)
 {	for(int i=0; i<iNumRecords; ++i)
	{	if(recs[i].extensn)free(recs[i].extensn);
		for(int k=0; k<3; ++k)
		{if(recs[i].path[k])free(recs[i].path[k]);
		 if(recs[i].desc[k])free(recs[i].desc[k]);
		 recs[i].path[k]=0;
		 recs[i].desc[k]=0;
		}
		recs[i].extensn=0;
	}
	free(recs);
	recs=NULL;
 }iNumRecords=0;
}

VOID Record::AddFrSinoEx(int exType)//Reg dan o'qigandan keyin berilgani uchun,1 ta ext ga 1ta path to'g'ri kelgan;
{if(bUseExecutableInReset[exType])
 {if(recs)
  {for(int i=0; i<iNumRecords; ++i)
   {if(recs[i].extensn)
    {int iSinoExPlgTypeNum,iSinoExPlgNum=FindPlgnFrmFileExtnsn(recs[i].extensn,exType,&iSinoExPlgTypeNum);
	 if(iSinoExPlgNum>-1)
	 {recs[i].type[exType]=frPlgns;
	  recs[i].iSinoExPlgnNum[exType]=iSinoExPlgNum;
	  recs[i].iSinoExPlgnTypeNum[exType]=iSinoExPlgTypeNum;
  }}}}
  //Endi sino plgnlari ichidan recda yozilmaganlari ham bo'lishi mumkin ekan:
  for(int spl=0; spl<iPlgns; ++spl)
  {if(exType==plgns[spl].exeType)
   {for(int k=0; k<plgns[spl].iNumExtns; ++k)
	{//if(4==spl && 43==k)
	 //	Beep(0,0);    
	 wchar_t ext[64];int ln=MyStringCpy(ext,plgns[spl].ExtnsLns[k],plgns[spl].pExtns[k]);
	 BOOL bExistInRecs=FALSE;
	 for(int i=0;  i<iNumRecords; ++i)
	 {if(!_wcsnicmp(recs[i].extensn,ext,ln))
	   {bExistInRecs=TRUE;break;}
	 }if(!bExistInRecs)
	 {AddNew(ext,NULL,NULL,exType,frPlgns);
	  recs[iNumRecords-1].iSinoExPlgnNum[plgns[spl].exeType]=spl;
	  recs[iNumRecords-1].iSinoExPlgnTypeNum[plgns[spl].exeType]=FindPlgnTypeNum(spl,exType);
}}}}}}

int Record::FindRecord(wchar_t *ext)
{int extln=MyStringLength(ext,MAX_PATH);
 if(extln<1)return -1;
 for(int i=0; i<iNumRecords; ++i)
 {if(0==_wcsnicmp(recs[i].extensn,ext,extln))
   return i;
 }
 return -1;
}

BOOL Record::ExecuteInd(HWND prnt,wchar_t *pathAndName,wchar_t *pext,int typeOfExecute)
{
 if(!pext)//defa:
 {if(bUseDefaForAll[typeOfExecute])
  {if(Execution::exePEPutSpaceToCmndLine(path[typeOfExecute],pathAndName,conf::modulePath))
 	return TRUE;
  }
Shll:
  HINSTANCE hShll=ShellExecute(prnt,0==typeOfExecute?L"open":L"edit",pathAndName,NULL,NULL,SW_SHOW);
  if(32<(int)hShll)return TRUE;
  
  if(':'==pathAndName[0] && ':'==pathAndName[1] && '{'==pathAndName[2] && '-'==pathAndName[11] &&
	 '-'==pathAndName[16] && '-'==pathAndName[21] && '-'==pathAndName[26] && '}'==pathAndName[39])
  { //IShellFolder *psfDeskTop;if(S_OK!=SHGetDesktopFolder(&psfDeskTop))return FALSE;
	//PIDLIST_RELATIVE ppidl;ULONG pchEaten,attrb=SFGAO_REMOVABLE;
    //psfDeskTop->ParseDisplayName(0,0,pathAndName,&pchEaten,&ppidl,&attrb);
	//psfDeskTop->Release();
    //OFSTRUCT ff;
	//HANDLE h=CreateFile(L"GT-S7262\\Phone\\App\\Piano",0,0,0,0,0,0);//HFILE h=OpenFile("GT-S7262\\Phone\\App\\Piano",&ff,0);
	//Beep(0,0);
  }

//TryExecuteWithoutExt:
  LPVOID par[2]={(LPVOID)pathAndName,(LPVOID)typeOfExecute};
  int iAssPlgn=(int)DialogBoxParam(hInst,MAKEINTRESOURCE(IDD_DIALOG_WHICH_ASSOC_PLGN),
							  prnt,(DLGPROC)WhichAssocPlgnDlgProc,(LPARAM)&par[0]);
  if(iAssPlgn<0)return FALSE;
  return Execution::exePEPutSpaceToCmndLine(MyStringAddModulePath(plgns[iAssPlgn].path),pathAndName,conf::modulePath);
  //return Execution::exePE(MyStringAddModulePath(plgns[iAssPlgn].path),pathAndName);
 }
 //else:
 if(0==type[typeOfExecute])
 {//if(Execution::exePESplitCmndLine(path[typeOfExecute],pathAndName,path[typeOfExecute]))
St:ShellExecute(NULL,L"open",pathAndName,NULL,NULL,SW_SHOW);
  return TRUE;
  //goto Shell;
 }
 if(1==type[typeOfExecute])
 {if(!plgns[iSinoExPlgnNum[typeOfExecute]].path)goto St;
  if(0==plgns[iSinoExPlgnNum[typeOfExecute]].path[0])goto St;
  if(!IsFileExist(MyStringAddModulePath(plgns[iSinoExPlgnNum[typeOfExecute]].path)))goto St;
  execTrdId = Execution::exePESplitCmndLine(MyStringAddModulePath(plgns[iSinoExPlgnNum[typeOfExecute]].path),pathAndName,conf::modulePath);
  if(execTrdId)
  	  return TRUE;
  goto Shll;
 }
 if(2==type[typeOfExecute])
 {if(Execution::exePEPutSpaceToCmndLine(path[typeOfExecute],pathAndName,path[typeOfExecute]))
   return TRUE;
  goto Shll;
 }
 return FALSE;
}

BOOL Record::FillToDlg(HWND hDlg,int type)
{HWND hcb=GetDlgItem(hDlg,IDC_COMBO_VIEW_FILE_ASSOC_EXT);
 if(!hcb)return FALSE;
 for(int i=0; i<iNumRecords; ++i)
 {SendMessage(hcb,CB_INSERTSTRING,-1,(LPARAM)recs[i].extensn);
  //OutputDebugString(L"\n");
  //OutputDebugString(recs[i].extensn);
  //if(wcsstr(recs[i].extensn,L"mp4a"))
  //	  Beep(0,0);
  if(0==recs[i].type[0] && recs[i].path[0])
  {tmpCB.AddToCB(GetDlgItem(hDlg,IDC_COMBO_SINO_VIEW_REGISTRY_EXECUT),recs[i].path[0],0);
 }}
 wchar_t s[32];
 SendMessage(GetDlgItem(hDlg,IDC_CHECK_USE_SINO_EXECUTABLE),BM_SETCHECK,bUseExecutableInReset[type]?BST_CHECKED:BST_UNCHECKED,0);
 SendMessage(GetDlgItem(hDlg,IDC_CHECK_STD_PARAMS_USE_CONSOLE),BM_SETCHECK,bCrtConsPrcss[type]?BST_CHECKED:BST_UNCHECKED,0);
 SendMessage(GetDlgItem(hDlg,IDC_CHECK_STD_PARAMS_USE_CMND_LINE),BM_SETCHECK,bSetParamsInCmndLn[type]?BST_CHECKED:BST_UNCHECKED,0);
 SendMessage(GetDlgItem(hDlg,IDC_CHECK_STD_PARAMS_USE_STD_SIZES),BM_SETCHECK,bUseStdSize[type]?BST_CHECKED:BST_UNCHECKED,0);
 SendMessage(GetDlgItem(hDlg,IDC_CHECK1),BM_SETCHECK,bUseDefaForAll[type]?BST_CHECKED:BST_UNCHECKED,0);
 SendMessage(GetDlgItem(hDlg,IDC_COMBO_STD_PARAMS_CALL_FUNC),CB_SETCURSEL,stdViewRoutFuncType[type],0);
 SendMessage(GetDlgItem(hDlg,IDC_COMBO_STD_PARAMS_PRIORITY_CLASS),CB_SETCURSEL,stdViewRoutPrtyClss[type],0);

 _itow(stdXPos[type],s,10);SetDlgItemText(hDlg,IDC_EDIT_STD_X,s);
 _itow(stdYPos[type],s,10);SetDlgItemText(hDlg,IDC_EDIT_STD_Y,s);
 _itow(stdW[type],s,10);SetDlgItemText(hDlg,IDC_EDIT_STD_W,s);
 _itow(stdH[type],s,10);SetDlgItemText(hDlg,IDC_EDIT_STD_H,s);
 return TRUE;
}

int Record::FindRecFrExt(wchar_t *ext)
{int l=MyStringLength(ext,MAX_PATH);
 if(l<1)return -1;
 for(int i=0; i<iNumRecords; ++i)
 {if(0==_wcsnicmp(recs[i].extensn,ext,l))
   return i;
 }
 return -1;
}

BOOL Record::AddNew(wchar_t *ext,wchar_t *pth,wchar_t *desc,int exeType,int recType)
{//if(wcsstr(ext,L"bat"))
 // Beep(0,0); 
 if(recs)
  recs=(Record*)realloc(recs,(iNumRecords+1)*sizeof(Record));
 else
  recs=(Record*)malloc((iNumRecords+1)*sizeof(Record));
 recs[iNumRecords].Record::Record();
 int l=MyStringLength(pth,MAX_PATH);
 if(l)
 {recs[iNumRecords].path[recType]=(wchar_t*)malloc(l*sizeof(wchar_t)+2);
  MyStringCpy(recs[iNumRecords].path[recType],l,pth);
 }
 l=MyStringLength(ext,MAX_PATH);
 if(l)
 {recs[iNumRecords].extensn=(wchar_t*)malloc(sizeof(wchar_t)*l+2);
  MyStringCpy(recs[iNumRecords].extensn,l,ext);
 }
 l=MyStringLength(desc,MAX_PATH);
 if(l)
 {recs[iNumRecords].desc[recType]=(wchar_t*)malloc(l*sizeof(wchar_t)+2);
  MyStringCpy(recs[iNumRecords].desc[recType],l,desc);
 }
 recs[iNumRecords].type[exeType]=Record::Type(recType);
 ++iNumRecords;
 return TRUE;
}

BOOL Record::Change(wchar_t *ext,wchar_t *pth,wchar_t *dsc,int exType,int recType)
{int l=MyStringLength(ext,MAX_PATH);
 if(_wcsnicmp(extensn,ext,l))
  return FALSE;	
 l=MyStringLength(pth,MAX_PATH);
 if(l)
 {if(0==path[exType] || wcscmp(pth,path[exType]))
  {if(path[exType])path[exType]=(wchar_t*)realloc(path[exType],l*sizeof(wchar_t)+2);
   else path[exType]=(wchar_t*)malloc(l*sizeof(wchar_t)+2);
   MyStringCpy(path[exType],l,pth);
 }}else {if(path[exType])free(path[exType]);path[exType]=0;}
 l=MyStringLength(dsc,MAX_PATH);
 if(l)
 {if(0==desc[exType] || wcscmp(dsc,desc[exType]))
  {if(desc[exType])desc[exType]=(wchar_t*)realloc(desc[exType],l*sizeof(wchar_t)+2);
   else desc[exType]=(wchar_t*)malloc(l*sizeof(wchar_t)+2);
   MyStringCpy(desc[exType],l,dsc);
 }}else {if(desc[exType])free(desc[exType]);desc[exType]=0;}
 type[exType]=Record::Type(recType);
 if(1==type[exType])//Sino plgn
  iSinoExPlgnNum[exType]=FindPlgnFrmFileExtnsn(ext,exType,&iSinoExPlgnTypeNum[recType]);
 return TRUE;
}

int Record::Add(wchar_t *ext,wchar_t *pth,wchar_t *desc,int exeType,int recType)
{//if(wcsstr(ext,L"bat"))
 // Beep(0,0);
 int irec=FindRecFrExt(ext);
 if(irec<0)
 {AddNew(ext,pth,desc,exeType,recType);
  return iNumRecords-1;
 }
 recs[irec].Change(ext,pth,desc,exeType,recType);
 return irec;
}

BOOL Record::Init()//1-marta yuklanganda:
{
	FillFrReg();
	if(ReadAppend(-1)<0)
	{AddFrSinoEx(0);
	 AddFrSinoEx(1);
	}
	return TRUE;
}

int Record::FillFrReg()
{
wchar_t extDescp[MAX_PATH],extType[MAX_PATH],prgDescp[MAX_PATH];
	HKEY k;LONG r = RegOpenKeyEx(HKEY_CLASSES_ROOT,NULL,0,KEY_QUERY_VALUE,&k);
	if(ERROR_SUCCESS!=r) return FALSE;
int ik=0;wchar_t buf[MAX_PATH];DWORD bufSz=MAX_PATH,bufSz1;FILETIME ft;
	while(ERROR_SUCCESS==RegEnumKeyEx(k,ik++,buf,&bufSz,NULL,NULL,&bufSz1,&ft))
	{bufSz=MAX_PATH;
	 if('.'==buf[0])
	 {extType[0]=0;prgDescp[0]=0;
	  if(GetExtParams(buf,extDescp,extType,prgDescp))
	  {if(prgDescp)if(prgDescp[0])//if(extType[0])
	  {if('N'==prgDescp[0])if('U'==prgDescp[1])if('L'==prgDescp[2])if('L'==prgDescp[3])continue;
		Add(&buf[1],prgDescp,extType,0,0);
	}}}}
	RegCloseKey(k);
return 0;
}

int Record::ReadAppend(int exceptExecType)
{
FILE *f;if(_wfopen_s(&f,MyStringAddModulePath(L"Config\\viewAsso.cnf"),L"rb"))return -1;//,ccs=UNICODE
BOOL bSucc=FALSE;
//Config:
	if(EOF==fread(&bUseExecutableInReset[0],sizeof(bool)*3,1,f))goto End;
	if(EOF==fread(&bCrtConsPrcss[0],sizeof(bool)*3,1,f))goto End;
	if(EOF==fread(&bSetParamsInCmndLn[0],sizeof(bool)*3,1,f))goto End;
	if(EOF==fread(&bUseStdSize[0],sizeof(bool)*3,1,f))goto End;
	if(EOF==fread(&bUseDefaForAll[0],sizeof(bool)*3,1,f))goto End;
	if(EOF==fread(&stdViewRoutFuncType[0],sizeof(int)*3,1,f))goto End;
	if(EOF==fread(&stdViewRoutPrtyClss[0],sizeof(int)*3,1,f))goto End;
	if(EOF==fread(&stdXPos[0],sizeof(int)*3,1,f))goto End;
	if(EOF==fread(&stdYPos[0],sizeof(int)*3,1,f))goto End;
	if(EOF==fread(&stdW[0],sizeof(int)*3,1,f))goto End;
	if(EOF==fread(&stdH[0],sizeof(int)*3,1,f))goto End;
	
	defaRecrd.ReadInd(f);

	int numChanges;wchar_t EXT[MAX_PATH],PTH[MAX_PATH],DSC[MAX_PATH];int TP;
	if(EOF==fread(&numChanges,sizeof(int),1,f))goto End;
	for(int r=0; r<numChanges; ++r)
	{int l;EXT[0]=0;
	 //if(65==r)
	 //  Beep(0,0);
	 if(EOF==fread(&l,sizeof(int),1,f))goto End;
	 if(l>0)
	  if(EOF==fread(&EXT,l,sizeof(wchar_t),f))goto End;EXT[l]=0;
	 for(int t=0; t<3; ++t)
	 {DSC[0]=PTH[0]=0;
	  if(EOF==fread(&l,sizeof(int),1,f))goto End;
	  if(l>0)
	  {if(EOF==fread(&PTH[0],l,sizeof(wchar_t),f))
		goto End;PTH[l]=0;
	  }
	  if(EOF==fread(&TP,sizeof(int),1,f))goto End;
	  if(EOF==fread(&l,sizeof(int),1,f))goto End;
	  if(l>0)
	  {if(EOF==fread(&DSC,l,sizeof(wchar_t),f))
		goto End;
		DSC[l]=0;
	  }
	  int irec=-1;
	  if(exceptExecType<0 || exceptExecType!=t)
	  {irec=Record::Add(EXT,PTH,DSC,t,TP);
	  }
	  if(irec>-1 && 1==TP)//Sinoniki bo'lsa:
 	   recs[irec].iSinoExPlgnNum[t]=viewFileAssoc::FindPlgnFrmFileExtnsn(EXT,t,&recs[irec].iSinoExPlgnTypeNum[t]);
	}}
	bSucc=TRUE;
End:
	fclose(f);
	//stdBuf::CopyTypeToBuffer((int)0);
	return bSucc?iNumRecords:-1;
}

VOID Record::ReadInd(FILE *f)
{int l=0;wchar_t DSC[MAX_PATH];
 if(EOF==fread(&l,sizeof(int),1,f))return;
 if(l)
 {if(extensn)
   extensn=(wchar_t*)realloc(extensn,sizeof(wchar_t)*l+2);
  else
   extensn=(wchar_t*)malloc(sizeof(wchar_t)*l+2);
  if(EOF==fread(&extensn[0],sizeof(wchar_t),l,f))return;
 }
 //if(extensn && 'b'==extensn[0] && 'i'==extensn[1] && 'n'==extensn[2])
 //	 Beep(0,0);
 for(int t=0; t<3; ++t)
 {if(EOF==fread(&l,sizeof(int),1,f))return;
  if(l)
  {if(path)
	path[t]=(wchar_t*)realloc(path,sizeof(wchar_t)*l+2);
   else
    path[t]=(wchar_t*)malloc(sizeof(wchar_t)*l+2);
   if(EOF==fread(&path[t][0],sizeof(wchar_t),l,f))return;
  }
  if(EOF==fread(&type[t],sizeof(int),1,f))return;
  if(EOF==fread(&l,sizeof(int),1,f))return;
  if(type[t]>1)
  {if(desc)
	desc[t]=(wchar_t*)realloc(desc,sizeof(wchar_t)*l+2);
   else
    desc[t]=(wchar_t*)malloc(sizeof(wchar_t)*l+2);
   if(EOF==fread(&desc[t][0],sizeof(wchar_t),l,f))return;
  }
  else if(EOF==fread(&DSC[0],sizeof(wchar_t),l,f))return;
}}

VOID Record::SaveInd(FILE *f)
{int l;
 l=extensn?MyStringLength(extensn,MAX_PATH):0;
 fwrite(&l,sizeof(int),1,f);
 if(extensn)
  fwrite(&extensn[0],sizeof(wchar_t),l,f);	
 for(int t=0; t<3; ++t)
 {if(type[t]>1)
   l=path[t]?MyStringLength(path[t],MAX_PATH):0;
  else l=0;
  fwrite(&l,sizeof(int),1,f);
  if(l)//recs[r].path[t])
	fwrite(&path[t][0],sizeof(wchar_t),l,f);
  fwrite(&type[t],sizeof(int),1,f);
  if(type[t]>1)
   l=desc[t]?MyStringLength(desc[t],MAX_PATH):0;
  else l=0;
  fwrite(&l,sizeof(int),1,f);
  if(l)//recs[r].desc[t])
  fwrite(&desc[t][0],sizeof(wchar_t),l,f);
}}

int Record::Save()
{FILE *f;if(_wfopen_s(&f,MyStringAddModulePath(L"Config\\viewAsso.cnf"),L"wb"))
	return FALSE;//,ccs=UNICODE
	//Config:
	fwrite(&bUseExecutableInReset[0],sizeof(bool)*3,1,f);
	fwrite(&bCrtConsPrcss[0],sizeof(bool)*3,1,f);
	fwrite(&bSetParamsInCmndLn[0],sizeof(bool)*3,1,f);
	fwrite(&bUseStdSize[0],sizeof(bool)*3,1,f);
	fwrite(&bUseDefaForAll[0],sizeof(bool)*3,1,f);
	fwrite(&stdViewRoutFuncType[0],sizeof(int)*3,1,f);
	fwrite(&stdViewRoutPrtyClss[0],sizeof(int)*3,1,f);
	fwrite(&stdXPos[0],sizeof(int)*3,1,f);
	fwrite(&stdYPos[0],sizeof(int)*3,1,f);
	fwrite(&stdW[0],sizeof(int)*3,1,f);
	fwrite(&stdH[0],sizeof(int)*3,1,f);

	defaRecrd.SaveInd(f);

	int numChanges=0;
	for(int r=0; r<iNumRecords; ++r)
	{if(recs[r].type[0] || recs[r].type[1] || recs[r].type[2])
	  ++numChanges;
	}

	fwrite(&numChanges/*iNumRecords*/,sizeof(int),1,f);
	for(int r=0; r<iNumRecords; ++r)
	{if(recs[r].type[0] || recs[r].type[1] || recs[r].type[2])
	  recs[r].SaveInd(f);
	}
	fclose(f);
	return iNumRecords;
}

BOOL Record::Input(HWND hDlg,int exeType)
{int t=(int)SendMessage(GetDlgItem(hDlg,IDC_COMBO_TYPE_OF_ASSOCIATIONS),CB_GETCURSEL,0,0);
 int sinExtblSel=(int)SendMessage(GetDlgItem(hDlg,IDC_COMBO_SINO_VIEW_EXECUT_PLUGINS),CB_GETCURSEL,0,0);
 wchar_t sFrReg[MAX_PATH];tmpCB.GetCBEditText(GetDlgItem(hDlg,IDC_COMBO_SINO_VIEW_REGISTRY_EXECUT),sFrReg,MAX_PATH);
 wchar_t sFrSino[MAX_PATH];tmpCB.GetCBEditText(GetDlgItem(hDlg,IDC_COMBO_SINO_VIEW_EXECUT_PLUGINS),sFrSino,MAX_PATH);
 wchar_t sUsrDef[MAX_PATH];tmpCB.GetCBEditText(GetDlgItem(hDlg,IDC_COMBO_USER_DEFINED),sUsrDef,MAX_PATH);
    int oldType=type[exeType];
 	if(t!=CB_ERR)
	{if(t!=type[exeType])
	 type[exeType]=Record::Type(t);
	}	
	if(oldType!=type[exeType] && 0==type[exeType])
	{wchar_t prgDscp[MAX_PATH],ex[MAX_PATH],pth[MAX_PATH];
	 wchar_t exx[32]=L".";MyStringCpy(&exx[1],31,extensn);
	 if(GetExtParams(exx,ex,pth,prgDscp))
	 {Change(extensn,prgDscp,pth,type[exeType],exeType);
	}}
	else if(oldType!=type[exeType] && 1==type[exeType])//Fr sino plgn:
	{int cnt=(int)SendMessage(GetDlgItem(hDlg,IDC_COMBO_SINO_VIEW_EXECUT_PLUGINS),CB_GETCURSEL,0,0);
	 type[exeType]=(Record::Type)1;
	 iSinoExPlgnNum[exeType]=cnt;
	}
	else if(oldType!=type[exeType] && 2==type[exeType])//userdefined:
	{int cnt=0;if(sFrReg[0])++cnt;if(sFrSino[0])++cnt;if(sUsrDef)++cnt;
	 if(cnt>1)
	 {MessageBox(hDlg,L"from Registry/Plgns/User def. CB.",L"Select only 1 item:",MB_OK);
	  SendMessage(GetDlgItem(hDlg,IDC_COMBO_TYPE_OF_ASSOCIATIONS),CB_SETCURSEL,-1,0);
	  return FALSE;
	 }
	 if(sFrReg[0])
	  Change(extensn,sFrReg,desc[exeType],type[exeType],exeType);
	 else if(sFrSino[0])
	  Change(extensn,sFrSino,desc[exeType],type[exeType],exeType);
	 else if(sUsrDef[0])
	  Change(extensn,sUsrDef,desc[exeType],type[exeType],exeType);
	}
	return TRUE;
}

BOOL Record::Output(HWND hDlg,int exeType)
{
	if(0==type[exeType])
	{SendMessage(GetDlgItem(hDlg,IDC_COMBO_TYPE_OF_ASSOCIATIONS),CB_SETCURSEL,0,0);
	 //SetExtensionRegParams(s,hDlg);
	 SendMessage(GetDlgItem(hDlg,IDC_COMBO_SINO_VIEW_EXECUT_PLUGINS),CB_SETCURSEL,-1,0);
	 SendMessage(GetDlgItem(hDlg,IDC_COMBO_USER_DEFINED),CB_SETCURSEL,-1,0);
	 if(path[0] && path[0][0])SetDlgItemText(hDlg,IDC_EDIT_DATA1,path[0]);//11.05.2014.if(path[recType][0])SetDlgItemText(hDlg,IDC_EDIT_DATA1,path[recType]);
	 if(desc[0] && desc[0][0])SetDlgItemText(hDlg,IDC_EDIT_DATA2,desc[0]);//11.05.2014.if(desc[recType][0])SetDlgItemText(hDlg,IDC_EDIT_DATA2,desc[recType]);
	}
	else if(1==type[exeType])//aks holda agar Sino-executable b-sa:type>-1,aks holda userdefined:
	{SendMessage(GetDlgItem(hDlg,IDC_COMBO_TYPE_OF_ASSOCIATIONS),CB_SETCURSEL,1,0);
	 SetDlgItemText(hDlg,IDC_EDIT_DATA1,L"");
	 SetDlgItemText(hDlg,IDC_EDIT_DATA2,L"");
	 SetDlgItemText(hDlg,IDC_EDIT_DATA3,L"");
	 SendMessage(GetDlgItem(hDlg,IDC_COMBO_SINO_VIEW_EXECUT_PLUGINS),CB_SETCURSEL,iSinoExPlgnTypeNum[exeType],0);
	 SendMessage(GetDlgItem(hDlg,IDC_COMBO_SINO_VIEW_REGISTRY_EXECUT),CB_SETCURSEL,-1,0);
	 SendMessage(GetDlgItem(hDlg,IDC_COMBO_USER_DEFINED),CB_SETCURSEL,-1,0);
	}
	else if(2==type[exeType])//userdefined:
	{SendMessage(GetDlgItem(hDlg,IDC_COMBO_TYPE_OF_ASSOCIATIONS),CB_SETCURSEL,2,0);
	 SetDlgItemText(hDlg,IDC_EDIT_DATA1,L"");
	 SetDlgItemText(hDlg,IDC_EDIT_DATA2,L"");
	 SetDlgItemText(hDlg,IDC_EDIT_DATA3,L"");
	 SendMessage(GetDlgItem(hDlg,IDC_COMBO_SINO_VIEW_EXECUT_PLUGINS),CB_SETCURSEL,-1,0);
	 SendMessage(GetDlgItem(hDlg,IDC_COMBO_SINO_VIEW_REGISTRY_EXECUT),CB_SETCURSEL,-1,0);
	 int fs=(int)SendMessage(GetDlgItem(hDlg,IDC_COMBO_USER_DEFINED),CB_FINDSTRING,0,(LPARAM)path[exeType]);
	 if(fs!=CB_ERR)SendMessage(GetDlgItem(hDlg,IDC_COMBO_USER_DEFINED),CB_SETCURSEL,fs,0);
	 else tmpCB.AddToCB(GetDlgItem(hDlg,IDC_COMBO_USER_DEFINED),path[exeType],TRUE);
	}
	return TRUE;
}

BOOL Record::Erase(int i)
{for(int k=0; k<3; ++k)
 {if(recs[i].path[k])free(recs[i].path[k]);
  if(recs[i].desc[k])free(recs[i].desc[k]);
 }if(recs[i].extensn)free(recs[i].extensn);
 for(int fr=i; fr<iNumRecords-1; ++fr)
 {recs[fr].extensn=recs[fr+1].extensn;
  for(int k=0; k<3; ++k)
  {recs[fr].type[k]=recs[fr+1].type[k];
   recs[fr].iSinoExPlgnNum[k]=recs[fr+1].iSinoExPlgnNum[k];
   recs[fr].path[k]=recs[fr+1].path[k];
   recs[fr].desc[k]=recs[fr+1].desc[k];
   recs[fr].extensn[k]=recs[fr+1].extensn[k];
 }}
 --iNumRecords;
 return FALSE;
}

/*template<class T> void* CopyTypeToBuffer(T t)
{
int ln=sizeof(T);
	if(!buffer)
	{	maxBufferLen=ln<4096?4096:(2*ln);
		buffer = (char*)malloc(maxBufferLen);
		bufferLen = ln;
		memcpy(buffer,&t,ln);
		return (T*)&buffer[0];
	}
	//else:
	if(bufferLen+ln<maxBufferLen)
	{	memcpy(&buffer[bufferLen],&t,ln);
		bufferLen += ln;
		return (T*)&buffer[bufferLen-ln];
	}
	//else
	maxBufferLen += ln<4096?4096:(2*ln);
	buffer = (char*)realloc(buffer,maxBufferLen);
	memcpy(&buffer[bufferLen],&t,ln);
	bufferLen += ln;
	return (T*)&buffer[bufferLen-ln];
}*/

BOOL Record::QuickView(wchar_t *filePathAndName)
{int i;
 if(execTrdId!=0)
 {if(OpenClipboard(hWnd)) 
  {	EmptyClipboard();
    int ln=(int)wcslen(filePathAndName);
	HGLOBAL hglb = GlobalAlloc(0,2+2*ln);
    wchar_t* lpstr = (wchar_t*)GlobalLock(hglb);
	MyStringCpy(lpstr,ln,filePathAndName);
	GlobalUnlock(hglb); 
	HANDLE h=SetClipboardData(CF_TEXT,hglb);
	if(!h)i=GetLastError();
    BOOL b=CloseClipboard();
	if(!b) i=GetLastError();
	if(!PostThreadMessage(execTrdId,WM_USER,0,0))
	 execTrdId=0;//qaytib kirmasun;
 }}
 return FALSE;	
}

}//End of namespace;