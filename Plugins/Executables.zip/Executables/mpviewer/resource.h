//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by WMP.rc
//
#define IDD_WMP_DIALOG                  102
#define IDR_MAINFRAME                   128
#define IDR_MENU_MAIN                   130
#define IDD_DIALOG_ABOUT                131
#define IDC_STATIC_1					132
#define IDC_STATIC_2					133
#define IDC_STATIC_3					134
#define IDC_STATIC_4					135
#define IDC_PLAYER                      1001
#define ID_HELP_ABOUTTHIS               32772
#define ID_HELP_ABOUTWINDOWSMEDIAPLAYERACTIVEX 32773

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        132
#define _APS_NEXT_COMMAND_VALUE         32775
#define _APS_NEXT_CONTROL_VALUE         1002
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
