// WMP.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "WMP.h"
#include "WMPDlg.h"
#include "AboutDlg.h"
#include "..\..\..\Operations\MyShell\MyShell.h"



HINSTANCE hInst=0;
HWND hWnd=0;
int language=0;
wchar_t FilePathForSearch[MAX_PATH]=L"";

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CWMPApp

BEGIN_MESSAGE_MAP(CWMPApp, CWinApp)
	//{{AFX_MSG_MAP(CWMPApp)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG
	//ON_COMMAND(ID_HELP, CWinApp::OnHelp)
	//ON_COMMAND(ID_FILE_CLOSE, CWinApp::OnAppExit)
	ON_COMMAND(ID_FILE_CLOSE,(AFX_PMSG)&CWMPApp::OnCmdMsg)//&CWinApp::OnAppExit)
	ON_COMMAND(ID_FILE_OPEN,(AFX_PMSG)&CWMPApp::OnCmdMsg)
	ON_COMMAND(ID_HELP_ABOUTTHIS,(AFX_PMSG)&CWMPApp::OnCmdMsg)
	ON_MESSAGE(WM_USER,(LRESULT(__thiscall CWnd::*)(WPARAM,LPARAM))&CWMPApp::OnWM_USER_Msg)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CWMPApp construction

CWMPApp::CWMPApp()
{
	// TODO: add construction code here,
	// Place all significant initialization in InitInstance
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CWMPApp object

CWMPApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CWMPApp initialization
BOOL CWMPApp::InitInstance()
{
	AfxEnableControlContainer();

	// Standard initialization
	// If you are not using these features and wish to reduce the size
	//  of your final executable, you should remove from the following
	//  the specific initialization routines you do not need.

	hInst = m_hInstance;

	if(::GetModuleFileName(NULL,FilePathForSearch,MAX_PATH))
	{wchar_t *p=wcsrchr(FilePathForSearch,'\\');if(p){*p=0;p=wcsrchr(FilePathForSearch,'\\');
	 if(p){*p=0;p=wcsrchr(FilePathForSearch,'\\');if(p){
#ifdef _WIN64
	  {MyStringCpy(p+1,10,L"Sino64.exe");
#else
	  {MyStringCpy(p+1,8,L"Sino.exe");
#endif
	   HMODULE hm=LoadLibrary(FilePathForSearch);if(hm)
	   {FilePathForSearch[0]=0;LoadString(hm,1384,FilePathForSearch,MAX_PATH);//IDS_STRINGS_0
	    if(wcsstr(FilePathForSearch,L"��������"))language=1;else if(wcsstr(FilePathForSearch,L"Elementlar"))language=2;else if(wcsstr(FilePathForSearch,L"����������"))language=3;
	    FreeLibrary(hm);
	}}}}}}

	if(!m_lpCmdLine) return FALSE;
	if(0!=m_lpCmdLine[0]){// return FALSE;
	 //MultiByteToWideChar(AreFileApisANSI()?CP_ACP:CP_OEMCP,MB_PRECOMPOSED,(LPCSTR)m_lpCmdLine,-1,FilePathForSearch,MAX_PATH);
	 MyStringCpy(FilePathForSearch,MAX_PATH,m_lpCmdLine);
	}

	//ReadConfig();
	CWMPDlg dlg;
    m_pMainWnd = &dlg;
	hWnd=m_pMainWnd->m_hWnd;
	int nResponse = (int)dlg.DoModal();

	//SaveConfig();
	return FALSE;
}

BOOL CWMPApp::OnCmdMsg(UINT nID, int nCode, void* pExtra, AFX_CMDHANDLERINFO* pHandlerInfo)
{	//CAboutDlg dlgAbout;
	if(CN_COMMAND!=nCode)return FALSE;
	switch(nID)
	{	case ID_FILE_CLOSE:
			((CWMPDlg*)m_pMainWnd)->m_player.close();
			PostQuitMessage(0);
		return TRUE;
		case ID_FILE_OPEN:CFileDialog *fDlg;
			// TODO: Add your control notification handler code here
			fDlg=new CFileDialog(true);//������ ������ �����
			fDlg->m_ofn.lpstrTitle  = L"����� �����-�����";
			if(GetCurrentDirectory(MAX_PATH, FilePathForSearch))
			fDlg->m_ofn.lpstrFilter = L"(*.*)   - ��� �����\0*.*";
			if(fDlg->DoModal() != IDOK)//����� ������������ ������� ����� �����
				AfxMessageBox(L"����� ����� ������� �������������");
			else
				GetShortPathName(fDlg->m_ofn.lpstrFile, FilePathForSearch, MAX_PATH);
			((CWMPDlg*)m_pMainWnd)->m_player.SetUrl(FilePathForSearch);
		return TRUE;
		case ID_HELP_ABOUTTHIS:CAboutDlg *dlgAbout;
			dlgAbout = new CAboutDlg();
			dlgAbout->DoModal();
		return TRUE;
		case ID_HELP_ABOUTWINDOWSMEDIAPLAYERACTIVEX://POINT pt;
			//GetCursorPos(&pt);
			//((CWMPDlg*)m_pMainWnd)->m_player.PostMessageW(WM_RBUTTONDOWN,MK_RBUTTON,MAKELONG(100,100));
			//((CWMPDlg*)m_pMainWnd)->m_player.accHitTest(100,100,NULL);
			//VARIANT varChild;varChild.lVal = CHILDID_SELF;
			//((CWMPDlg*)m_pMainWnd)->m_player.accDoDefaultAction(varChild);
			//((CWMPDlg*)m_pMainWnd)->m_player.BindProperty(1,this->m_pActiveWnd);
			//((CWMPDlg*)m_pMainWnd)->m_player.DrawMenuBar();
			//((CWMPDlg*)m_pMainWnd)->m_player.GetMenu()->CreatePopupMenu();
			//((CWMPDlg*)m_pMainWnd)->m_player.HtmlHelpW(0,15);//GetMenu()->CreatePopupMenu();
			//((CWMPDlg*)m_pMainWnd)->m_player.PrepareForHelp();
			//((CWMPDlg*)m_pMainWnd)->m_player.WinHelpW(0,1);
			//((CWMPDlg*)m_pMainWnd)->m_player.WinHelpInternal(0,1);
			ShellAbout(((CWMPDlg*)m_pMainWnd)->m_hWnd,L"Windows Media Player ActiveX",L"",NULL);
			//::WinHelp(((CWMPDlg*)m_pMainWnd)->m_hWnd,L"Windows Media Player ActiveX",HELP_WM_HELP,-1);
		return TRUE;
	}
	return FALSE;//CWinApp::OnCmdMsg(nID, nCode, pExtra, pHandlerInfo);
}

LRESULT CWMPApp::OnWM_USER_Msg(WPARAM wParam,LPARAM lParam)
{	int i=0;
	if(!IsClipboardFormatAvailable(CF_TEXT)) 
		return FALSE; 
	if(OpenClipboard(hWnd))
	{HGLOBAL hMem = GetClipboardData(CF_TEXT);
	 if(!hMem)i=GetLastError();
	 wchar_t* lpstr = (wchar_t*)GlobalLock(hMem);
	 if(IsFileExist(lpstr))
	 {	MyStringCpy(FilePathForSearch,MAX_PATH,lpstr);
	 }
	 GlobalUnlock(hMem);
	 CloseClipboard();
	 ((CWMPDlg*)m_pMainWnd)->m_player.SetUrl(FilePathForSearch);
    }
	return TRUE;
}