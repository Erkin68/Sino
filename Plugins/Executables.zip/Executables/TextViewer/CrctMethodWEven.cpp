#include "TextViewer.h"
#include "stdio.h"

u16 **linesStartsW=0;
u16 *pInMaxHorCharsW;
extern BOOL bOrderToCrctCalcing,bOrderToStopCrctCalcing;



VOID CalcCorrectScrollingWEven()
{	SendMessage(hPrgs,PBM_SETRANGE32,0,1000);
	SendMessage(hPrgs,PBM_SETPOS,0,0);
	SetWindowText(hStat,L"Calculating lines,scrolling info,even...");
	crctScrlSt=calcThread;
	bOrderToStopCrctCalcing=FALSE;
	iCrtScrlLines=iCrctScrlMaxHorChars=iCrctScrlMaxHorCharsWidth=0;
	int linesStartsSize = 1000;//1000 tadan oshirib boramiz;
	if(linesStartsW)linesStartsW=(u16**)realloc(linesStartsW,linesStartsSize*sizeof(u16*));
	else linesStartsW=(u16**)malloc(linesStartsSize*sizeof(u16*));

	//linesStartsW[iCrtScrlLines++]=(u16*)pFileBase;
	pInMaxHorCharsW = (u16*)pFileBase;

	u16 *p = pInMaxHorCharsW,*pp=p;
	int imx=0;
	for(u64 i=0; i<fileSize/2-1; ++i)
	{	if(++imx>0xff || CheckRetLineW(p))
		{	if(iCrtScrlLines>linesStartsSize-2)
			{	linesStartsSize+=1000;
				linesStartsW=(u16**)realloc(linesStartsW,linesStartsSize*sizeof(u16*));
			}
			linesStartsW[iCrtScrlLines++]=pp;
			s64 ss=(s64)(p-pp);
			if(ss>iCrctScrlMaxHorChars)
			{	iCrctScrlMaxHorChars=ss;
				pInMaxHorCharsW=pp;
			}
			pp=p+retLineChars[2];
			imx=0;
		}
		++p;
		if(0==i%1000)
		{	MessageProcess();
			if(fileSize>0)
				SendMessage(hPrgs,PBM_SETPOS,(WPARAM)(1000*i/fileSize),0);
		}
		if(bOrderToStopCrctCalcing)
		{	crctScrlSt=fast;
			SendMessage(hPrgs,PBM_SETPOS,1000,0);
			SetWindowText(hStat,L"Calculating lines,scrolling info emergency shutdowning.");
			return;
	}	}
	if(fileSize>0 && 0==iCrtScrlLines)
		linesStartsW[iCrtScrlLines++]=(u16*)pFileBase;
	HDC dc=GetDC(hWndText);SIZE sz;
	u16 *pBgn=pInMaxHorCharsW,*pEnd= pBgn+iCrctScrlMaxHorChars;
	if(pBgn==pEnd)pEnd=p;
	//iCrctScrlMaxHorCharsWidth=0 qiluvdik;
	int pr=0;SetWindowText(hStat,L"Calculating horizontal spacing...");
	while(pBgn<pEnd)
	{	int isz=(int)(pBgn+0xff<pEnd?0xff:pEnd-pBgn);//bayt ANSI uchun;
		GetTextExtentPoint32W(dc,(LPCWSTR)pBgn,isz,&sz);
		pBgn+=isz;iCrctScrlMaxHorCharsWidth+=sz.cx;
		SendMessage(hPrgs,PBM_SETPOS,(WPARAM)pr,0);
		if(++pr>1000)pr=0;
	}
	ReleaseDC(hWndText,dc);
	SetScrollInResizeCrct();
	SendMessage(hPrgs,PBM_SETPOS,1000,0);
	SetWindowText(hStat,L"Calculating lines,scrolling info finished.");
	iCrtScrlCrntLines=0;iAddressText=0;
	crctScrlSt=finished;
	SetCursor(hArrCursor);
}

VOID DrawTextsCrctW(HDC hDC,RECT *rDC,int *maxWidth,LPVOID* pNextPageTopAddress)
{RECT rc = *rDC;
 FillRect(hDC,&rc,textBackBrsh);
 
 rc.left += 2;
 rc.right -= 1;
 rc.top = 0;
 rc.bottom = ySpaceText-1;

 SetBkColor(hDC,backColorText);
 SetTextColor(hDC,textColorText);
 HFONT oldFnt=(HFONT)SelectObject(hDC,fntText);

 for(int row=0; row<nViewRows; ++row)
 {	s64 i = iCrtScrlCrntLines+row;
	if(i>iCrtScrlLines-1)break;
	u16 *pBgn = linesStartsW[i];
	u16 *pEnd = (i<iCrtScrlLines-1) ? linesStartsW[i+1] : ((u16*)((u8*)pFileBase+fileSize));
	s64 SLN=0,rowLen = (u64)(pEnd - pBgn);int rcBgn=0,iBgnPos=-1,iEndPos=-1;SIZE sz={0,0};
	for(int sln=0; sln<rowLen; sln++)
	{	if(SLN==xScroll && -1==iBgnPos)
		{	iBgnPos = sln;
			rcBgn = 0;
		}
		else if(SLN>xScroll && -1==iBgnPos)
		{	iBgnPos = sln-1;
			rcBgn = (int)(SLN-sz.cx-xScroll);
		}
		else if(SLN>xScroll+rc.right && -1==iEndPos)
		{	iEndPos = sln;
			break;
		}
		GetTextExtentPoint32W(hDC,(LPCWSTR)&pBgn[sln],1,&sz);
		SLN += sz.cx;
	}
	if(iBgnPos>-1)
	{	if(-1==iEndPos)
			iEndPos = (int)rowLen;
		ExtTextOutW(hDC,rc.left+rcBgn,rc.top,0,&rc,(LPCWSTR)&pBgn[iBgnPos],iEndPos-iBgnPos,NULL);
		//if(0==row)
		//{	char ss[32];sprintf(ss,"\nrcLeft: %d, chPos: %d",rc.left+rcBgn,iBgnPos);
		//	OutputDebugStringA(ss);
	}	//}
	rc.top += ySpaceText;
	rc.bottom = rc.top+ySpaceText-1;
 }
 SelectObject(hDC,oldFnt);
}

u64 CalcPosInDrawTextsCrctW(HDC hDC,RECT *rDC,int *xOut,int *yOut)
{RECT rc = *rDC;
 
 int cptX = *xOut;
 int cptY = *yOut;

 rc.left += 2;
 rc.right -= 1;
 rc.top = 0;
 rc.bottom = ySpaceText-1;

 HFONT oldFnt=(HFONT)SelectObject(hDC,fntText);
 int row,SLN=0,oldSLN=0,sln=0;u16 *pBgn;SIZE sz;u16 *pEnd;s64 i,rowLen;
 for(row=0; row<nViewRows; ++row)
 {	i = iCrtScrlCrntLines+row;
	if(i>iCrtScrlLines-1)break;
	pBgn = linesStartsW[i];
	pEnd = (i<iCrtScrlLines-1) ? linesStartsW[i+1] : ((u16*)((u8*)pFileBase+fileSize));
	SLN=0; rowLen = (u64)(pEnd - pBgn);int rcBgn=0,iBgnPos=-1,iEndPos=-1;sz.cx=sz.cy=0;
	if(rowLen==retLineChars[2] && CheckRetLineW(pBgn))
		rowLen = 0;
	else
	for(sln=0; sln<rowLen; sln++)
	{	if(SLN==xScroll && -1==iBgnPos)
		{	iBgnPos = sln;
			rcBgn = 0;
		}
		else if(SLN>xScroll && -1==iBgnPos)
		{	iBgnPos = sln-1;
			rcBgn = (int)(SLN-sz.cx-xScroll);
		}
		else if(SLN>xScroll+rc.right && -1==iEndPos)
		{	iEndPos = sln;
			break;
		}
		GetTextExtentPoint32W(hDC,(LPCWSTR)pBgn,sln+1,&sz);//GetTextExtentPoint32W(hDC,(LPCWSTR)&pBgn[sln],1,&sz);
		SLN = sz.cx;//SLN += sz.cx;
		if(rc.top<=cptY && rc.top+ySpaceText>=cptY)
		{	if(SLN>=cptX)//if(SLN-sz.cx-xScroll<=cptX && SLN-xScroll>=cptX)
				break;
		}
		oldSLN=SLN;
	}
	if(rc.top<=cptY && rc.top+ySpaceText>=cptY)
		break;
	rc.top += ySpaceText;
	rc.bottom = rc.top+ySpaceText-1;
 }
 SelectObject(hDC,oldFnt);
 if(rc.top<=cptY && rc.top+ySpaceText>=cptY)
	*xOut = oldSLN;//SLN-sz.cx;
 else *xOut = cptX;
 *yOut = rc.top;
static int oldXOut=0;
 if(0==rowLen)
	 *xOut = oldXOut;
 oldXOut = *xOut;
 return (u64)((u8*)(&pBgn[sln])-(u8*)pFileBase);
}