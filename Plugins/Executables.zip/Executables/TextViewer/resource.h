//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by TextViewer.rc
//
#define IDI_ICON2                       106
#define IDR_MENU1                       107
#define IDD_DIALOG_ABOUT                108
#define IDD_DIALOG_LINE_RETURNING       110
#define IDC_COMBO1                      112
#define IDC_EDIT1_TVWR                  113
#define IDC_EDIT2_TVWR                  114
#define IDC_EDIT3                       115
#define IDC_EDIT4                       116
#define IDC_STATIC1_TVWR                117
#define IDC_STATIC2_TVWR                118
#define IDC_STATIC3_TVWR                119
#define IDC_STATIC4_TVWR                120
#define IDM_EXIT                        121
#define IDM_ABOUT                       122
#define ID_TEXT_CHAR                    123
#define ID_TEXT_WIDECHAR                124
#define ID_FILE_SAVEAS                  125
#define ID_TEXT_FONT                    127
#define ID_TEXT_BACKCOLOR               128
#define ID_TEXT_TEXTCOLOR               129
#define ID_TEXT_ALIGNRIGHT              130
#define ID_TEXT_ALIGNCENTER             131
#define ID_TEXT_ALIGNLEFT               132
#define ID_TEXT_ALIGNVERTICALCENTER     133
#define ID_FILE_OPEN1                   134
#define ID_FILE_SAVE1                   135
#define ID_VIEW_FIND                    136
#define ID_TEXT_WIDECHARFROMODDPOSITION 137
#define ID_CLIPBOARD_COPYTEXT           138
#define ID_CONFIGURATION_LINERETURNING  139
#define ID_ENGINEMODE_FAST              140
#define ID_ENGINEMODE_CORRECT           141
#define IDD_DIALOG_LINE_HEIGHT          142
#define ID_TEXT_LINEHEIGHT              143
#define IDC_EDIT_LINE_HEIGHT            144
#define IDD_DIALOG_AUTO_DEF_SIZE        145
#define ID_AUTO_DEFININGWIDEOFCHAR      146
#define IDD_DIALOG_CLPBRD               147
#define ID_AUTO_FIRSTN                  148
#define IDC_STATIC_TEXT                 149
#define ID_ONLOADINGFILE_FILESIZEFORCORRECT 150
#define IDC_STATIC_BIN                  151
#define IDC_BUTTON_SAVE_CLPBRD_TO_FILE  152
#define IDC_CHECK_UNICODE               153
#define IDC_CHECK_ANSI                  154
#define IDC_CHECK_BIN                   155
#define IDC_EDIT_CHANGE_DBLE_ZERO       156
#define IDC_EDIT_CHANGE_DBLE_ZERO1      157
#define IDC_EDIT_TEXT                   158
#define IDC_EDIT_BIN                    159
#define ID_VIEW_FINDNEXT                160
#define IDC_EDIT_SEARCH_TEXT            161
#define IDC_EDIT_FIND_ADDRESS           163
#define IDC_STATICTXT1                  164
#define IDC_EDIT_FIND_LENGTH            165
#define IDC_STATICTXT2                  166
#define IDC_EDIT_FIND_CMNT              167
#define IDC_CHECK_WIDE_CHAR_FR_ODD_ADDRS 168
#define IDC_PROGRESS1                   169
#define IDC_CHECK_CHAR                  170
#define IDC_CHECK_WIDE_CHAR_FR_EVEN_ADDRS 171
#define IDC_CHECK_DOWN                  172
#define IDC_CHECK_UP                    173
#define IDC_CHECK_FROM_START            174
#define IDD_DIALOG_SEARCH               175

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        176
#define _APS_NEXT_COMMAND_VALUE         176
#define _APS_NEXT_CONTROL_VALUE         176
#define _APS_NEXT_SYMED_VALUE           176
#endif
#endif
