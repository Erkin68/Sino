#include "TextViewer.h"
#include "..\..\..\Operations\Myshell\MyShell.h"



HANDLE hFile=0,hFileMap=0;
LPVOID pFileBase=0;
LPVOID pNextPageTopAddress;
DWORD nFileSizeHigh,nFileSizeLow;

BOOL OpenTextFile()
{
BY_HANDLE_FILE_INFORMATION fibh;

	if(0==FilePathForSearch[0])return FALSE;

	//MessageBox(NULL,FilePathForSearch,L"1",MB_OK);

    hFile = CreateFile(FilePathForSearch,
					   GENERIC_READ, FILE_SHARE_READ, NULL,
                       OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, (HANDLE)0);                    
    if(hFile == INVALID_HANDLE_VALUE)
	{	if(' '==FilePathForSearch[0])
		{//MessageBox(NULL,FilePathForSearch,L"prob err",MB_OK);
		 hFile = CreateFile(&FilePathForSearch[1],
						   GENERIC_READ, FILE_SHARE_READ, NULL,
						   OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, (HANDLE)0);                    
		 if(hFile == INVALID_HANDLE_VALUE)
		 {//wchar_t s[260];wsprintf(s,L"err: %d",GetLastError());
		  //MessageBox(NULL,FilePathForSearch,s,MB_OK);
		  return FALSE;
	}	}}

	//MessageBox(NULL,FilePathForSearch,L"2",MB_OK);

	if(!GetFileInformationByHandle(hFile,&fibh))
	{	//wchar_t s[260];LARGE_INTEGER li;
		//MessageBox(NULL,FilePathForSearch,L"2 err",MB_OK);
		//if(!GetFileSizeEx(hFile,&li))
		//{
		 CloseHandle(hFile);
		 hFile = 0;
		 return FALSE;
		//}
		//nFileSizeHigh = li.HighPart;
		//nFileSizeLow = li.LowPart;
		//wsprintf(s,L"size, h: %d , l: %d",fibh.nFileSizeHigh,fibh.nFileSizeLow);
		//MessageBox(NULL,FilePathForSearch,s,MB_OK);
	}else {nFileSizeHigh = fibh.nFileSizeHigh;
		   nFileSizeLow = fibh.nFileSizeLow;
	}
	fileSize = (((u64)nFileSizeHigh) << 32) | nFileSizeLow;

	//MessageBox(NULL,FilePathForSearch,L"3",MB_OK);

    hFileMap = CreateFileMapping(hFile, NULL, PAGE_READONLY, 0, 0,NULL);
    if(hFileMap == 0)
	{	CloseHandle(hFile);
		hFile=0;
		return FALSE;
	}

	//MessageBox(NULL,FilePathForSearch,L"4",MB_OK);

    pFileBase = (PCHAR)MapViewOfFile(hFileMap,FILE_MAP_READ,0,0,0);
    if(pFileBase==0)
	{	if(hFileMap)CloseHandle(hFileMap);
		CloseHandle(hFile);
		hFile=0;hFileMap=0;
		return FALSE;
	}

	//MessageBox(NULL,FilePathForSearch,L"6",MB_OK);

    //if(IsBadReadPtr(pNTHdr, sizeof(IMAGE_NT_HEADERS)))return;

	return TRUE;
}

BOOL CloseFileMap()
{	if(pFileBase)
		UnmapViewOfFile(pFileBase);
	pFileBase = 0;
	if(hFileMap)
		CloseHandle(hFileMap);
	hFileMap = 0;
	if(hFile)
		CloseHandle(hFile);
	hFile = 0;
	return TRUE;
}