#pragma warning(disable:4996)

#include "TextViewer.h"
#include "stdio.h"




BOOL SaveConfig()
{
wchar_t *p,s[MAX_PATH];FILE *f;int l=GetModuleFileName(NULL,s,MAX_PATH);
	p=wcsrchr(s,'\\');if(!p)p=&s[l];else++p;
	wcscpy(p,L"TextVw.cnf");
	f=_wfopen(s,L"wb");
	if(!f)//default settings:
	 return FALSE;
	fwrite(&ySpaceText,sizeof(ySpaceText),1,f);
	fwrite(&xSpaceText,sizeof(xSpaceText),1,f);
	fwrite(&textColorText,sizeof(textColorText),1,f);
	fwrite(&backColorText,sizeof(backColorText),1,f);
	fwrite(&textColorText,sizeof(textColorText),1,f);
	fwrite(&backColorText,sizeof(backColorText),1,f);
	fwrite(&textFmt,sizeof(textFmt),1,f);
	fwrite(&textFmtDesc,sizeof(textFmtDesc),1,f);
	fwrite(&textLogFont,sizeof(textLogFont),1,f);
	fwrite(&retLineChars[0],3,1,f);
	fwrite(&bOrderToCrctCalcing,1,1,f);
	fwrite(&bAutoDef,1,1,f);
	fwrite(&iAutoSz,1,1,f);
	fwrite(&iAutoFileSz,1,1,f);
	fclose(f);
	return TRUE;
}

BOOL ReadConfig()
{
wchar_t *p,s[MAX_PATH];FILE *f;int l=GetModuleFileName(NULL,s,MAX_PATH);
	p=wcsrchr(s,'\\');if(!p)p=&s[l];else++p;
	wcscpy(p,L"TextVw.cnf");
	f=_wfopen(s,L"rb");
	if(!f)
	{	InitLogFont(&textLogFont);
		return FALSE;
	}
	fread(&ySpaceText,sizeof(ySpaceText),1,f);
	fread(&xSpaceText,sizeof(xSpaceText),1,f);
	fread(&textColorText,sizeof(textColorText),1,f);
	fread(&backColorText,sizeof(backColorText),1,f);
	fread(&textColorText,sizeof(textColorText),1,f);
	fread(&backColorText,sizeof(backColorText),1,f);
	fread(&textFmt,sizeof(textFmt),1,f);
	fread(&textFmtDesc,sizeof(textFmtDesc),1,f);
	fread(&textLogFont,sizeof(textLogFont),1,f);
	fread(&retLineChars[0],3,1,f);
	fread(&bOrderToCrctCalcing,1,1,f);
	if(0==bOrderToCrctCalcing)bOrderToCrctCalcing=FALSE;
	else bOrderToCrctCalcing=TRUE;
	fread(&bAutoDef,1,1,f);
	if(0==bAutoDef)bAutoDef=FALSE;
	else bAutoDef=TRUE;
	fread(&iAutoSz,1,1,f);
	fread(&iAutoFileSz,1,1,f);
	fclose(f);
	return TRUE;
}
