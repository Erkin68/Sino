#include "windows.h"


namespace viewFileAssoc
{

 extern BOOL Execute(HWND,wchar_t*,int);
 extern BOOL QuickView(wchar_t*);
 extern wchar_t* findExactExt(wchar_t*,wchar_t*,int);



typedef struct tExctblPlgn//Sino niki;
{
typedef enum tExeType
{	view=0,
	edit=1,
	//execute=3
} ExeType;
ExeType exeType;
wchar_t *extns;
wchar_t *path;
int iNumExtns;
int *ExtnsLns;
wchar_t **pExtns;
} exctblPlgn;
extern int iPlgns;
extern exctblPlgn *plgns;





class Record//Dopolitelniy user defined konfiguratsiya;
{	
public:

static VOID FreeRecords();
static int  FindRecord(wchar_t*);
static BOOL Init();
static int  FillFrReg();
static VOID AddFrSinoEx(int);
static int  Add(wchar_t*,wchar_t*,wchar_t*,int,int);
static BOOL AddNew(wchar_t*,wchar_t*,wchar_t*,int,int);
static int	FindRecFrExt(wchar_t*);
static BOOL FillToDlg(HWND,int);
static int  ReadAppend(int);
static int  Save();
static BOOL Erase(int);

static Record *recs;
static int iNumRecords;


	Record();
	~Record();

	BOOL Change(wchar_t*,wchar_t*,wchar_t*,int,int);
	int	 Output(HWND,int);
	BOOL Input(HWND,int);
	VOID ReadInd(FILE*);
	VOID SaveInd(FILE*);
	BOOL ExecuteInd(HWND,wchar_t*,wchar_t*,int);
	BOOL QuickView(wchar_t*);

	typedef enum TType
	{fromReg=0,
	 frPlgns=1,
	 userDef=2
	} Type;
	Type type[3];
	int iSinoExPlgnNum[3];
	int iSinoExPlgnTypeNum[3];//edit(view,exec)larning ham ichidan qaysi tartibligi;
	wchar_t *path[3];
	wchar_t *desc[3];
	wchar_t *extensn;
	DWORD execTrdId;
};


extern LRESULT CALLBACK confDlgProc(HWND,UINT,WPARAM,LPARAM);
extern VOID LoadPlugins(HWND);
extern VOID FreePlugins();
extern VOID TryLoadPlugin(HWND,wchar_t*,wchar_t*,int);
extern VOID ListDirLoadExctblPlugins(HWND,wchar_t*);
extern int  FindPlgnFrmFileExtnsn(wchar_t*,int,int*);

extern BOOL ViewWithPlugins(HWND,wchar_t*);
extern BOOL ViewWithOpen(HWND,wchar_t*);
extern BOOL ViewWithBrowse(HWND,wchar_t*);
extern BOOL EditWithPlugins(HWND,wchar_t*);

};