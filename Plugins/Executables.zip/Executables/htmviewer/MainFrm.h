// MainFrm.h : interface of the CMainFrame class
//


#pragma once

class CMainFrame : public CFrameWnd
{
	
protected: // create from serialization only
	CMainFrame();
	DECLARE_DYNCREATE(CMainFrame)

// Attributes
public:

// Operations
public:

// Overrides
public:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//virtual void OnActivate(UINT,CWnd*,BOOL);
	//virtual void OnKeyDown(UINT,UINT,UINT);
	//virtual void OnChar(UINT,UINT,UINT);
	//virtual void OnSysKeyDown(UINT,UINT,UINT);
	//virtual void OnHotKey(UINT,UINT,UINT);
	//virtual void OnLButtonDown(UINT,CPoint);
	//virtual int OnMouseActivate(CWnd*,UINT,UINT);
	//virtual BOOL OnCmdMsg(UINT,int,void*,AFX_CMDHANDLERINFO*);


// Implementation
public:
	virtual ~CMainFrame();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:  // control bar embedded members
	CStatusBar  m_wndStatusBar;
	CToolBar    m_wndToolBar;

// Generated message map functions
protected:
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	DECLARE_MESSAGE_MAP()
};

extern CMainFrame *pMainFrame;
