// htmviewerDoc.cpp : implementation of the ChtmviewerDoc class
//

#include "stdafx.h"
#include "htmviewer.h"

#include "htmviewerDoc.h"
#include "..\..\..\Operations\MyShell\MyShell.h"

extern wchar_t FilePathForSearch[MAX_PATH];


#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// ChtmviewerDoc

IMPLEMENT_DYNCREATE(ChtmviewerDoc, CDocument)

BEGIN_MESSAGE_MAP(ChtmviewerDoc, CDocument)
END_MESSAGE_MAP()


// ChtmviewerDoc construction/destruction

ChtmviewerDoc::ChtmviewerDoc()
{
	// TODO: add one-time construction code here
}

ChtmviewerDoc::~ChtmviewerDoc()
{
}

BOOL ChtmviewerDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}


BOOL ChtmviewerDoc::OnOpenDocument(LPCTSTR lpszPathName)
{
	if (!CDocument::OnOpenDocument(lpszPathName))
		return FALSE;
	MyStringCpy(FilePathForSearch,MAX_PATH,(wchar_t*)lpszPathName);
	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)
	return TRUE;
}


// ChtmviewerDoc serialization

void ChtmviewerDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}


// ChtmviewerDoc diagnostics

#ifdef _DEBUG
void ChtmviewerDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void ChtmviewerDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG


// ChtmviewerDoc commands
