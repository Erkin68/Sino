// htmviewerView.h : interface of the ChtmviewerView class
//


#pragma once


class ChtmviewerView  : public CHtmlView
{
protected: // create from serialization only
	ChtmviewerView();
	DECLARE_DYNCREATE(ChtmviewerView)

// Attributes
public:
	ChtmviewerDoc* GetDocument() const;

// Operations
public:

// Overrides
public:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
protected:
	virtual void OnInitialUpdate(); // called first time after construct
	virtual void OnDocumentComplete(LPCTSTR);
	//virtual void OnNavigateError(LPCTSTR,LPCTSTR,DWORD,BOOL*);

// Implementation
public:
	virtual ~ChtmviewerView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	DECLARE_MESSAGE_MAP()
};


extern HINSTANCE hInst;
extern HWND hWnd;
extern int language;
extern ChtmviewerView *pHtmView;
extern wchar_t FilePathForSearch[MAX_PATH];


#ifndef _DEBUG  // debug version in htmviewerView.cpp
inline ChtmviewerDoc* ChtmviewerView::GetDocument() const
   { return reinterpret_cast<ChtmviewerDoc*>(m_pDocument); }
#endif

