// htmviewerView.cpp : implementation of the ChtmviewerView class
//

#include "stdafx.h"
#include "htmviewer.h"

#include "htmviewerDoc.h"
#include "htmviewerView.h"
#include "MainFrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


ChtmviewerView *pHtmView=0;


// ChtmviewerView

IMPLEMENT_DYNCREATE(ChtmviewerView, CHtmlView)

BEGIN_MESSAGE_MAP(ChtmviewerView, CHtmlView)
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, &CHtmlView::OnFilePrint)
END_MESSAGE_MAP()

// ChtmviewerView construction/destruction

ChtmviewerView::ChtmviewerView()
{
	// TODO: add construction code here
	pHtmView = this;
}

ChtmviewerView::~ChtmviewerView()
{
}

BOOL ChtmviewerView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs
	return CHtmlView::PreCreateWindow(cs);
}

void ChtmviewerView::OnInitialUpdate()
{
	CHtmlView::OnInitialUpdate();
	SetSilent(1);
	Navigate2(FilePathForSearch,NULL,NULL);
}

//BOOL enumchlds(HWND hWnd,LPARAM lParam)
//{//wchar_t s[260];
//	HWND h=hWnd;
	//GetWindowText(h,s,260);
//	return TRUE;
//}
extern CMainFrame *pMainFrame;
void ChtmviewerView::OnDocumentComplete(LPCTSTR lpszURL)
{	if(wcsstr(FilePathForSearch,lpszURL))
	{	
		CComQIPtr<IOleInPlaceActiveObject> spInPlace = m_pBrowserApp;
		if(spInPlace)
		{	MSG msg;msg.message=WM_LBUTTONDOWN;msg.hwnd=this->m_hWnd;
			msg.pt.x=5;msg.pt.y=5;msg.wParam=MK_LBUTTON;msg.lParam=MAKELONG(5,5);
			spInPlace->TranslateAccelerator(&msg);
		}
		
		//CDocument* pDoc = pMainFrame->GetActiveDocument();
		//HACCEL hAccel=0; if(pDoc)hAccel = pDoc->GetDefaultAccelerator();
		//static BOOL bFirst=TRUE;
		//if(bFirst)
		//{	pMainFrame->OnMouseActivate(pMainFrame,1,513);
		//	bFirst=FALSE;
		//}		
		//::SendMessage(this->m_wndBrowser,WM_LBUTTONDOWN,MK_LBUTTON,MAKELONG(100,100));
		//POINT pt={100,100};
		//HWND h=ChildWindowFromPoint(pt)->m_hWnd;
		//::SendMessage(this->ChildWindowFromPoint(pt)->m_hWnd,WM_LBUTTONDOWN,MK_LBUTTON,MAKELONG(100,100));
		//::SendMessage(this->ChildWindowFromPoint(pt)->m_hWnd,WM_LBUTTONDOWN,MK_LBUTTON,MAKELONG(100,100));
		//Default();
		//EnumChildWindows(NULL,(WNDENUMPROC)enumchlds,0);
		//::SetFocus(WindowFromPoint(pt)->m_hWnd);
		//::SendMessage(WindowFromPoint(pt)->m_hWnd,WM_LBUTTONDOWN,MK_LBUTTON,MAKELONG(100,100));
		//keybd_event(VK_LBUTTON,0,KEYEVENTF_KEYUP,0);
		//this->ResizeParentToFit(0);
		//LRESULT lr;this->ReflectChildNotify(WM_LBUTTONDOWN,MK_LBUTTON,MAKELONG(100,100),&lr);
		//this->Refresh();SetForegroundWindow();
		//this->GetDocument()->SendInitialUpdate();
		//this->GetDocument()->BeginWaitCursor();
		//pMainFrame->OnXButtonDown(0,0,0);//ActivateTopParent();//ActivateFrame(-1);
		//PostMessage(WM_LBUTTONDOWN, 0, 0);
		//static HWND hst=0;
		//HWND h = ::GetFocus();
		//if(h)
		//	hst=h;
		//else 
		//	::SetFocus(this->m_hWnd);
		//BringWindowToTop();
		//this->Invalidate();
		//this->SetFullScreen(1);
		//this->BringWindowToTop();
}	}

/*void ChtmviewerView::OnNavigateError(LPCTSTR lpszURL,LPCTSTR lpszFrame,DWORD dwError,BOOL *pbCancel)
{
	*pbCancel=TRUE;
	CHtmlView::OnNavigateError(lpszURL,lpszFrame,dwError,pbCancel);
}*/
// ChtmviewerView printing


// ChtmviewerView diagnostics

#ifdef _DEBUG
void ChtmviewerView::AssertValid() const
{
	CHtmlView::AssertValid();
}

void ChtmviewerView::Dump(CDumpContext& dc) const
{
	CHtmlView::Dump(dc);
}

ChtmviewerDoc* ChtmviewerView::GetDocument() const // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(ChtmviewerDoc)));
	return (ChtmviewerDoc*)m_pDocument;
}
#endif //_DEBUG


// ChtmviewerView message handlers
