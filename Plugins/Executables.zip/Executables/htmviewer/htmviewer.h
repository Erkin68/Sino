// htmviewer.h : main header file for the htmviewer application
//
#pragma once

#ifndef __AFXWIN_H__
	#error "include 'stdafx.h' before including this file for PCH"
#endif

#include "resource.h"       // main symbols


// ChtmviewerApp:
// See htmviewer.cpp for the implementation of this class
//

class ChtmviewerApp : public CWinApp
{
public:
	ChtmviewerApp();


// Overrides
public:
	virtual BOOL InitInstance();

// Implementation
	virtual LRESULT OnWM_USER_Msg(WPARAM,LPARAM);

	afx_msg void OnAppAbout();
	afx_msg void OnAppPrev();

protected:
	//virtual void OnKeyDown(UINT,UINT,UINT);
	virtual BOOL OnIdle(LONG);


	DECLARE_MESSAGE_MAP()
};

extern ChtmviewerApp theApp;