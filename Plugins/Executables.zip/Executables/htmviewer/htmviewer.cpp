// htmviewer.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "htmviewer.h"
#include "MainFrm.h"

#include "htmviewerDoc.h"
#include "htmviewerView.h"

#include "..\..\..\Operations\MyShell\MyShell.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


HINSTANCE hInst=0;
HWND hWnd=0;
int language=0;
wchar_t FilePathForSearch[MAX_PATH]=L"";


// ChtmviewerApp

BEGIN_MESSAGE_MAP(ChtmviewerApp, CWinApp)
	ON_COMMAND(ID_APP_ABOUT, &ChtmviewerApp::OnAppAbout)
	ON_COMMAND(ID_FILE_OPEN, &CWinApp::OnFileOpen)
	ON_COMMAND(ID_FILE_PRINT_SETUP, &CWinApp::OnFilePrintSetup)
	ON_COMMAND(ID_APP_PREV, &ChtmviewerApp::OnAppPrev)
	ON_MESSAGE(WM_USER,(LRESULT(__thiscall CWnd::*)(WPARAM,LPARAM))&ChtmviewerApp::OnWM_USER_Msg)
	//ON_MESSAGE(WM_KEYDOWN,(LRESULT(__thiscall CWnd::*)(WPARAM,LPARAM))&ChtmviewerApp::OnKeyDown)
	//ON_THREAD_MESSAGE(WM_CHAR,(void(__thiscall CWinThread::*)(WPARAM,LPARAM))&ChtmviewerApp::OnKeyDown)
END_MESSAGE_MAP()


// ChtmviewerApp construction

ChtmviewerApp::ChtmviewerApp()
{
	// TODO: add construction code here,
	// Place all significant initialization in InitInstance
}


// The one and only ChtmviewerApp object

ChtmviewerApp theApp;


// ChtmviewerApp initialization

BOOL ChtmviewerApp::InitInstance()
{
	// InitCommonControlsEx() is required on Windows XP if an application
	// manifest specifies use of ComCtl32.dll version 6 or later to enable
	// visual styles.  Otherwise, any window creation will fail.
	INITCOMMONCONTROLSEX InitCtrls;
	InitCtrls.dwSize = sizeof(InitCtrls);
	// Set this to include all the common control classes you want to use
	// in your application.
	InitCtrls.dwICC = ICC_WIN95_CLASSES;
	InitCommonControlsEx(&InitCtrls);

	hInst = m_hInstance;

	if(::GetModuleFileName(NULL,FilePathForSearch,MAX_PATH))
	{wchar_t *p=wcsrchr(FilePathForSearch,'\\');if(p){*p=0;p=wcsrchr(FilePathForSearch,'\\');
	 if(p){*p=0;p=wcsrchr(FilePathForSearch,'\\');if(p){
#ifdef _WIN64
	  {MyStringCpy(p+1,10,L"Sino64.exe");
#else
	  {MyStringCpy(p+1,8,L"Sino.exe");
#endif
	   HMODULE hm=LoadLibrary(FilePathForSearch);if(hm)
	   {FilePathForSearch[0]=0;LoadString(hm,1384,FilePathForSearch,MAX_PATH);//IDS_STRINGS_0
	    if(wcsstr(FilePathForSearch,L"��������"))language=1;else if(wcsstr(FilePathForSearch,L"Elementlar"))language=2;else if(wcsstr(FilePathForSearch,L"����������"))language=3;
	    FreeLibrary(hm);
	}}}}}}

	if(!m_lpCmdLine) return FALSE;
	if(0!=m_lpCmdLine[0]){// return FALSE;
	 //MultiByteToWideChar(AreFileApisANSI()?CP_ACP:CP_OEMCP,MB_PRECOMPOSED,(LPCSTR)m_lpCmdLine,-1,FilePathForSearch,MAX_PATH);
	 MyStringCpy(FilePathForSearch,MAX_PATH,m_lpCmdLine);
	}

	CWinApp::InitInstance();

	// Initialize OLE libraries
	if (!AfxOleInit())
	{
		AfxMessageBox(IDP_OLE_INIT_FAILED);
		return FALSE;
	}
	AfxEnableControlContainer();
	// Standard initialization
	// If you are not using these features and wish to reduce the size
	// of your final executable, you should remove from the following
	// the specific initialization routines you do not need
	// Change the registry key under which our settings are stored
	// TODO: You should modify this string to be something appropriate
	// such as the name of your company or organization
	SetRegistryKey(_T("Local AppWizard-Generated Applications"));
	LoadStdProfileSettings(4);  // Load standard INI file options (including MRU)
	// Register the application's document templates.  Document templates
	//  serve as the connection between documents, frame windows and views
	CSingleDocTemplate* pDocTemplate;
	pDocTemplate = new CSingleDocTemplate(
		IDR_MAINFRAME,
		RUNTIME_CLASS(ChtmviewerDoc),
		RUNTIME_CLASS(CMainFrame),       // main SDI frame window
		RUNTIME_CLASS(ChtmviewerView));
	if (!pDocTemplate)
		return FALSE;
	AddDocTemplate(pDocTemplate);



	// Parse command line for standard shell commands, DDE, file open
	CCommandLineInfo cmdInfo;
	ParseCommandLine(cmdInfo);
	cmdInfo.m_strFileName = FilePathForSearch;

	// Dispatch commands specified on the command line.  Will return FALSE if
	// app was launched with /RegServer, /Register, /Unregserver or /Unregister.
	if (!ProcessShellCommand(cmdInfo))
		return FALSE;

	// The one and only window has been initialized, so show and update it
	m_pMainWnd->ShowWindow(SW_SHOW);
	m_pMainWnd->UpdateWindow();

	hWnd=m_pMainWnd->m_hWnd;

	// call DragAcceptFiles only if there's a suffix
	//  In an SDI app, this should occur after ProcessShellCommand
	return TRUE;
}



// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	enum { IDD = IDD_ABOUTBOX };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Implementation
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
END_MESSAGE_MAP()

// App command to run the dialog
void ChtmviewerApp::OnAppAbout()
{
	CAboutDlg aboutDlg;
	aboutDlg.DoModal();
}

void ChtmviewerApp::OnAppPrev()
{	if(IsFileExist(FilePathForSearch))
		pHtmView->Navigate2(FilePathForSearch,0,0);
}

LRESULT ChtmviewerApp::OnWM_USER_Msg(WPARAM wParam,LPARAM lParam)
{	int i=0;
	if(!IsClipboardFormatAvailable(CF_TEXT)) 
		return FALSE; 
	if(OpenClipboard(hWnd))
	{HGLOBAL hMem = GetClipboardData(CF_TEXT);
	 if(!hMem)i=GetLastError();
	 wchar_t* lpstr = (wchar_t*)GlobalLock(hMem);
	 if(IsFileExist(lpstr))
	 {	MyStringCpy(FilePathForSearch,MAX_PATH,lpstr);
	 }
	 GlobalUnlock(hMem);
	 CloseClipboard();
	 pHtmView->Navigate2(FilePathForSearch,0,0);
	}
	return TRUE;
}

/*void ChtmviewerApp::OnKeyDown(UINT nChar,UINT nRepCnt,UINT nFlags)
{	if(nChar==27)
	{	pHtmView->CloseWindow();
		PostQuitMessage(0);
}	}*/

BOOL ChtmviewerApp::OnIdle(LONG lCount)
{	SHORT sh = GetKeyState(VK_ESCAPE);
	/*static int i=0;
	char s[64];sprintf(s,"\n%d %x",++i,sh);
	OutputDebugStringA(s);*/
	if(0x8000 & sh)
	{	pHtmView->CloseWindow();
		PostQuitMessage(0);
	}return 1;
}
