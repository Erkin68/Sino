#pragma warning(disable:4996)

#include "windows.h"
#include "UtilityExe.h"
#include "..\..\resource.h"
#include "..\..\Config.h"
#include "..\..\Operations\MyErrors.h"
#include "..\..\Operations\Execution.h"
#include "..\..\Operations\MyShell\MyShell.h"
//#include "..\..\Operations\MyShell\MyButtonC++.h"

extern HINSTANCE hInst;

namespace UtilityExe
{
int iPlgns=0,iMaxPlgns=0;

utilityPlgn *plgns=NULL;

VOID ListDirLoadUtilities(HWND hWnd,wchar_t *path)
{
WIN32_FIND_DATA ff;
HANDLE hf = INVALID_HANDLE_VALUE;
wchar_t s[MAX_PATH];
	int l=MyStringCpy(s,MAX_PATH-1,path);
	if(MyStringRemoveLastCharCheckPre(s,MAX_PATH-1,'*','\\'))
		--l;

	hf = MyFindFirstFileEx(path,FindExInfoStandard,&ff,FindExSearchLimitToDirectories,NULL,0);
	int err=GetLastError();
	do
	{	if(INVALID_HANDLE_VALUE==hf) return;
		if(FILE_ATTRIBUTE_DIRECTORY & ff.dwFileAttributes)//if(IsDirectory(path, &ff, FALSE))
		{	if(IsCrntOrPrntDirAttrb(ff.cFileName))
			{	int n=MyStringCpy(&s[l],MAX_PATH-1,ff.cFileName);
				MyStringCpy(&s[l+n],MAX_PATH-1-l,L"\\*");
				ListDirLoadUtilities(hWnd,s);
		}	}
		else
			TryLoad(hWnd,s,ff.cFileName,l);
	}
	while(FindNextFile(hf, &ff));
	FindClose(hf);
}

VOID Free()//CArch::~CArch ga qara, ochiq qolib ketgan arxivlar qoladur;
{
	for(int p=0; p<iPlgns; p++)
	{	free(plgns[p].path);
		free(plgns[p].hint);
	}
	if(plgns)free(plgns);
	plgns=0;
	iPlgns=iMaxPlgns=0;
}

VOID Load(HWND wnd)
{
	iPlgns=0;
	wchar_t *utilityPth = MyStringAddModulePath(L"Plugins\\Utility\\*");
	ListDirLoadUtilities(wnd,utilityPth);
}

VOID TryLoad(HWND hWnd,wchar_t *pth,wchar_t* name,int l)
{
	if(iPlgns>conf::Dlg.totalAllovedArchvr * 25)
	{	Err::msg(hWnd,0,L"There are any executable utilties(above 500), ignore others...");
		return;
	}
	MyStringCpy(&pth[l],MAX_PATH-1,name);
	if(!Execution::IsThisValidExeFile(pth))
		return;

BEGIN_TRY

HMODULE hm = LoadLibraryEx(pth,NULL,LOAD_LIBRARY_AS_DATAFILE);
	if(!hm)return;
	HRSRC rs = FindResource(hm,L"SINO_EXECUTABLE_UTILITY",L"SINOSTRING");
	if(!rs)
	{Fin:FreeLibrary(hm);
		return;
	}
	if(iPlgns>iMaxPlgns-1)
	{	iMaxPlgns += 15;
		if(!plgns)plgns = (utilityPlgn*)malloc(iMaxPlgns*sizeof(utilityPlgn));
		else plgns = (utilityPlgn*)realloc(plgns,iMaxPlgns*sizeof(utilityPlgn));
	}
	int pathLn = MyStringLength(pth,MAX_PATH);
	plgns[iPlgns].path = (wchar_t*)malloc(2*pathLn+2);
	MyStringCpy(plgns[iPlgns].path,pathLn,pth);
	int resSz=SizeofResource(hm,rs);
	HGLOBAL glr = LoadResource(hm,rs);
	if(!glr) goto Fin;
	LPVOID pres = LockResource(glr);
	if(!pres)goto Fin;
	plgns[iPlgns].hint = (wchar_t*)malloc(2*resSz+2);
	MultiByteToWideChar(AreFileApisANSI()?CP_ACP:CP_OEMCP,MB_PRECOMPOSED,(LPCSTR)pres,resSz,plgns[iPlgns].hint,resSz);
	plgns[iPlgns].hint[resSz]=0;
	++iPlgns;
	FreeLibrary(hm);
END_TRY
{
	Err::msg1(NULL,0,pth,L"Err.loading executable utility.");
}}

}//end of namespace;
