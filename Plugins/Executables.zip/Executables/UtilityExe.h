#include "windows.h"


namespace UtilityExe
{
typedef struct tUtilityPlgn
{
wchar_t *path;
wchar_t *hint;
} utilityPlgn;
extern int iPlgns;
extern utilityPlgn *plgns;

	extern VOID Load(HWND);
	extern VOID Free();
	extern VOID TryLoad(HWND,wchar_t*,wchar_t*,int);
	extern VOID ListDirLoadUtilities(HWND,wchar_t*);

};