#ifndef _SEARCH_H__
#define _SEARCH_H__

#include "windows.h"



class CSearchPlgn;
class Panel;
namespace fSearchViaF7
{
	//Ob'yazatelniye:
	typedef	BOOL (*Add$24_t)(LPVOID,char*,char*,char*,int,BOOL);
	typedef VOID (*SetCallbacks$4xxx_t)(LPVOID,...);

	//Dopolnitelniye:
	typedef const char* (*GetPluginDescription_t)();
	typedef VOID (*ShowOptionDialog_t)();

	extern VOID FreePlugins();
	extern VOID LoadPlugins();
	extern VOID TryLoadPlugin(char*,char*);

	extern CSearchPlgn *plgns;
	extern int numPlugins;
}
using namespace fSearchViaF7;

class CSearch;
class CSearchPlgn
{
friend VOID archive::TryLoadPlugin(char*,char*);

//First public functns for calling from plugins:
static int   CALLBACK checkFileInSelctn(CArch*,char*);
static VOID  CALLBACK excldFileFrSelctn(CArch*,int,int);
static BOOL  CALLBACK getFileInfoFromSelection(CArch*,int,OUT WIN32_FIND_DATA*);
static DWORD CALLBACK prgrssRout(CArch*,unsigned __int64*,unsigned __int64*,unsigned __int64*,unsigned __int64*);
static int   CALLBACK showDlgOverwriteExistFile(CArch*,int,char*,unsigned __int64*,FILETIME*,WIN32_FIND_DATA*);
static BOOL  CALLBACK saveOptions(CArch*,VOID*,int);
static BOOL  CALLBACK readOptions(CArch*,VOID*,int);
static int   CALLBACK addItemToPanelList(CArch*,char*,WIN32_FIND_DATA*);

public:
	CSearchPlgn();
	~CSearchPlgn();
	//HMODULE hm;
	//int	dllSize;
	char pathAndName[MAX_PATH];
	int  type;
	BOOL bOpen;

	Add$24_t Add$24;
	CreateDir$24_t CreateDir$24;
	GetPluginType_t GetPluginType;
	SetCallbacks$4xxx_t SetCallbacks$4xxx;

	GetTotalCryptMethods_t GetTotalCryptMethods;
	GetPluginDescription_t GetPluginDescription;
	ShowOptionDialog_t ShowOptionDialog;
};

class CSearch
{
friend VOID CSearchPlgn::buildArchvThrdFnc(LPVOID);
friend INT_PTR CALLBACK AppndFileExistDlgProc(HWND,UINT,WPARAM,LPARAM);
friend INT_PTR CALLBACK fSearchViaF7::arcExstOvwrtQuestnDlgProc(HWND,UINT,WPARAM,LPARAM);

friend class Panel;
friend class FillManager;
friend class CSearchPlgn;
public:
		CSearch();
	       ~CSearch();

	BOOL	AddFile(int);
	BOOL	Close();
	BOOL	CreateDirectory(int);
	int	GetFilesInFolder(char*,ArcStack*);
	int	GetSelectedFilesCnt(int);
	int	GetSelectedFiles();

protected:
	HWND	 hDlg;
	BOOL	 bStop,bCancel;
	ArcStack *stack;
	DWORD	 thrId,beginTickTot,stopTickTot[2],beginTick,stopTick[2];
	BOOL	 bExcldPath,bDelAftArchiving,bSFXArchive;
	LPVOID   plgObj;
	int	 plgNum;
	int	 iCrntFileCopy,srcPanel,totFiles,nameLn;
};

#endif