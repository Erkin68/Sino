#include "..\..\sino.h"
#include "..\..\WindowsManagmentInstrumentation.h"
#include "..\..\Operations\MyErrors.h"
#include "..\..\Operations\Execution.h"
#include "..\..\Operations\MyShell\MyShell.h"
#include "..\..\Operations\MyShell\ComboToDisk.h"
#include "..\..\Plugins\Executables\ViewFileAssoc.h"
#include "..\..\Config.h"
#include "shlobj.h"
#include "Search.h"
#include "strsafe.h"
#include "Search.h"
#include "SelectViaPlus.h"
#include <malloc.h>
#include <Psapi.h>


namespace fSearchViaF7
{
int numPlugins;
CSearchPlgn *plgns=NULL;

wchar_t srchFrFileFltr[MAX_PATH]=L"";
int width,height;
int minWidth=580,minHeight=486,minHeightAftCrLB=638;
//Search	search;
int iCall = 0;//search.iCall
int iPanel=0;
BOOL bStop = TRUE;//search.bStop 
BOOL bRun = FALSE;//search.bRun 
SearchItem item;

VOID TryLoadPlugin(wchar_t *pth,wchar_t* name)
{//LoadLibrary da exception beradur;
	if(numPlugins>20)
	{	Err::msg(hWnd,0,(LPTSTR)"There are any archiver plugins(above 20), ignore others...");
		return;
	}

	MyStringCat(pth,MAX_PATH-1,name);

//HMODULE hm = LoadLibraryEx(pth,NULL,LOAD_LIBRARY_AS_IMAGE_RESOURCE);//LOAD_LIBRARY_AS_DATAFILE);
//	if(!hm)return;
//	FreeLibrary(hm);
//	char st[260]; char *p=strrchr(pth,'\\');if(p)*p=0;
//	if(32>(int)FindExecutable(name,pth,st)) return;


//	DWORD bt;
//	if(!GetBinaryType(pth,&bt))return;

	if(!Execution::IsThisValidDllFile(pth))
		return;

HMODULE hm = LoadLibraryExW(pth,NULL,DONT_RESOLVE_DLL_REFERENCES);

	if(!hm)
	{	Err::msg(hWnd,-1,pth);
		return;
	}
	GetPluginType_t GetPluginType = (GetPluginType_t)GetProcAddress(hm,"GetPluginType");
	if(!GetPluginType) goto Fall;
	QSearchFrList$8_t QSearchFrList$8 = (QSearchFrList$8_t)GetProcAddress(hm,"QSearchFrList$8");
	if(!QSearchFrList$8) goto Fall;
	ShowSearchDlg$8_t ShowSearchDlg$8 = (ShowSearchDlg$8_t)GetProcAddress(hm,"ShowSearchDlg$8");
	if(!ShowSearchDlg$8) goto Fall;
	SetCallbacks$4xxx_t SetCallbacks$4xxx = (SetCallbacks$4xxx_t)GetProcAddress(hm,"SetCallbacks$4xxx");
	if(!SetCallbacks$4xxx) goto Fall;
	GetPluginDescription_t GetPluginDescription = (GetPluginDescription_t)GetProcAddress(hm,"GetPluginDescription");
	if(!GetPluginDescription) goto Fall;
	SearchForContainText$12_t SearchForContainText$12 = (SearchForContainText$12_t)GetProcAddress(hm,"SearchForContainText$12");
	if(!SearchForContainText$12) goto Fall;
	SearchForContainTextW$12_t SearchForContainTextW$12 = (SearchForContainTextW$12_t)GetProcAddress(hm,"SearchForContainTextW$12");
	if(!SearchForContainTextW$12) goto Fall;
	SearchForNotContainText$12_t SearchForNotContainText$12 = (SearchForNotContainText$12_t)GetProcAddress(hm,"SearchForNotContainText$12");
	if(!SearchForNotContainText$12) goto Fall;
	SearchForNotContainTextW$12_t SearchForNotContainTextW$12 = (SearchForNotContainTextW$12_t)GetProcAddress(hm,"SearchForNotContainTextW$12");
	if(!SearchForNotContainTextW$12) goto Fall;
	SetId$4_t SetId$4 = (SetId$4_t)GetProcAddress(hm,"SetId$4");
	if(!SetId$4) goto Fall;
	ShowOptionDialog_t ShowOptionDialog = (ShowOptionDialog_t)GetProcAddress(hm,"ShowOptionDialog");
	if(!ShowOptionDialog) goto Fall;

	FreeLibrary(hm);
	hm = LoadLibrary(pth);//DllMain ni yuklasin, endi;
	GetPluginType = (GetPluginType_t)GetProcAddress(hm,"GetPluginType");
	QSearchFrList$8 = (QSearchFrList$8_t)GetProcAddress(hm,"QSearchFrList$8");
	ShowSearchDlg$8 = (ShowSearchDlg$8_t)GetProcAddress(hm,"ShowSearchDlg$8");
	SetCallbacks$4xxx = (SetCallbacks$4xxx_t)GetProcAddress(hm,"SetCallbacks$4xxx");
	GetPluginDescription = (GetPluginDescription_t)GetProcAddress(hm,"GetPluginDescription");
	SearchForContainText$12 = (SearchForContainText$12_t)GetProcAddress(hm,"SearchForContainText$12");
	SearchForContainTextW$12 = (SearchForContainTextW$12_t)GetProcAddress(hm,"SearchForContainTextW$12");
	SearchForNotContainText$12 = (SearchForNotContainText$12_t)GetProcAddress(hm,"SearchForNotContainText$12");
	SearchForNotContainTextW$12 = (SearchForNotContainTextW$12_t)GetProcAddress(hm,"SearchForNotContainTextW$12");
	SetId$4 = (SetId$4_t)GetProcAddress(hm,"SetId$4");
	ShowOptionDialog = (ShowOptionDialog_t)GetProcAddress(hm,"ShowOptionDialog");
	GetSrchFltr$8_t GetSrchFltr$8 = (GetSrchFltr$8_t)GetProcAddress(hm,"GetSrchFltr$8");

	int t=GetPluginType();
	if(100!=t)//�� ��������� ������:
	{		
Fall:	FreeLibrary(hm);
		return;
	}

	MODULEINFO mi;
	GetModuleInformation(GetCurrentProcess(),hm,&mi,sizeof(mi));

	/*for(int i=0; i<numPlugins; i++)
	{	//if(plgns[i].dllSize==mi.SizeOfImage)
		if(!strcmp(plgns[i].GetArchExtnsn(),GetArchExtnsn()))
			return;//goto Fall;
	}*/

	if(!plgns) plgns = (CSearchPlgn*)malloc((numPlugins+1)*sizeof(CSearchPlgn));
	else  plgns = (CSearchPlgn*)realloc(plgns,(numPlugins+1)*sizeof(CSearchPlgn));
	plgns[numPlugins].CSearchPlgn::CSearchPlgn();
	plgns[numPlugins].QSearchFrList$8 = QSearchFrList$8;
	plgns[numPlugins].ShowSearchDlg$8 = ShowSearchDlg$8;
	plgns[numPlugins].SearchForContainText$12 = SearchForContainText$12;
	plgns[numPlugins].SearchForContainTextW$12 = SearchForContainTextW$12;
	plgns[numPlugins].SearchForNotContainText$12 = SearchForNotContainText$12;
	plgns[numPlugins].SearchForNotContainTextW$12 = SearchForNotContainTextW$12;
	plgns[numPlugins].GetPluginType = GetPluginType;
	plgns[numPlugins].SetCallbacks$4xxx = SetCallbacks$4xxx;
	plgns[numPlugins].GetPluginDescription = GetPluginDescription;
	plgns[numPlugins].ShowOptionDialog = ShowOptionDialog;
	plgns[numPlugins].SetId$4 = SetId$4;
	plgns[numPlugins].GetSrchFltr$8 = GetSrchFltr$8;
	SetCallbacks$4xxx(	CSearchPlgn::saveOptions,
						CSearchPlgn::readOptions,
						CSearchPlgn::getPanelSelectedItemsNum,
						CSearchPlgn::getPanelItemPathAndName,
						CSearchPlgn::execF3View
						);
	plgns[numPlugins].hm = hm;
	MyStringCpy(plgns[numPlugins].pathAndName,MAX_PATH-1,pth);
	plgns[numPlugins].SetId$4(numPlugins);
	plgns[numPlugins].idNum = numPlugins;
	//plgns[numPlugins].dllSize = mi.SizeOfImage;
	if(conf::Dlg.crntSchplg<0)conf::Dlg.crntSchplg=numPlugins;
	if(wcsstr(pth,L"SinSch"))
	{	DWORD visz, sz=GetFileVersionInfoSize(pth,&visz);
		if(sz)
		{	wchar_t SubBlock[64];DWORD *infoptr;UINT uiVerSize;
			wchar_t *buf = (wchar_t*)malloc(sizeof(wchar_t)*sz); buf[0]=0;
			if(GetFileVersionInfo(pth, 0, sz, buf))
			{	struct LANGANDCODEPAGE 
				{	WORD wLanguage;
					WORD wCodePage;
				}*lpTranslate;
				VerQueryValue(buf,L"\\VarFileInfo\\Translation",(LPVOID*)&lpTranslate, &uiVerSize);
				StringCchPrintf(SubBlock,64,L"\\StringFileInfo\\%04x%04x\\InternalName",
								lpTranslate->wLanguage, lpTranslate->wCodePage);
				if(VerQueryValue(buf, SubBlock, (VOID**)&infoptr, &uiVerSize))
				{	if(0==wcscmp((wchar_t*)infoptr,L"sinsch32"))
						CSearchPlgn::myOwnPlgnNum = numPlugins;
			}	}
			free(buf);
	}	}
	plgns[numPlugins++].FreePlugin();
}

VOID ListAuxDirLoadPlugins(wchar_t *path)
{
wchar_t s[MAX_PATH];
WIN32_FIND_DATAW ff;
HANDLE hf = INVALID_HANDLE_VALUE;

	
	hf = MyFindFirstFileEx(path,FindExInfoStandard,&ff,FindExSearchLimitToDirectories,NULL,0);
	do
	{	if(INVALID_HANDLE_VALUE==hf) return;
		if(FILE_ATTRIBUTE_DIRECTORY & ff.dwFileAttributes)//if(IsDirectory(path, &ff, FALSE))
		{	if(IsCrntOrPrntDirAttrb(ff.cFileName))
			{	wchar_t s[MAX_PATH]; MyStringCpy(s,MAX_PATH-1,path);
				MyStringRemoveLastCharCheckPre(s,MAX_PATH-1,'*','\\');
				MyStringCat(s,MAX_PATH-1,ff.cFileName);
				MyStringCat(s,MAX_PATH-1,L"\\*");
				ListAuxDirLoadPlugins(s);
		}	}
		else
		{	MyStringCpy(s,MAX_PATH-1,path);
			MyStringRemoveLastCharCheckPre(s,MAX_PATH-1,'*','\\');
			//MyStringCat(s,MAX_PATH-1,ff.cFileName);
			TryLoadPlugin(s,ff.cFileName);
	}	}
	while(FindNextFile(hf, &ff));
	FindClose(hf);
}

VOID FreePlugins()//CArch::~CArch ga qara, ochiq qolib ketgan arxivlar qoladur;
{
	//free(plgns);
	//plgns=NULL;
	//numPlugins=0;
}

VOID LoadPlugins()
{
	numPlugins=0;
	wchar_t *auxPlgPth = MyStringAddModulePath(L"Plugins\\Auxilary\\*");
	ListAuxDirLoadPlugins(auxPlgPth);
}

VOID ShowSearchDlg$8(Panel *p)
{
	if(conf::Dlg.crntSchplg>-1)
	if(numPlugins>0)
	if(conf::Dlg.crntSchplg<numPlugins)
	{	CmnCntrl::ReleaseDragAndDrop();
		
		iPanel = (int)(p-&panel[0]);

		LPVOID buf;
		plgns[conf::Dlg.crntSchplg].LoadPlugin();
BEGIN_TRY
		buf=plgns[conf::Dlg.crntSchplg].ShowSearchDlg$8(p->GetHWND(),p->GetPath());
END_TRY
{		plgns[conf::Dlg.crntSchplg].FreePlugin();
		CmnCntrl::CreateDragAndDrop();
		return;
}
		if(plgns[conf::Dlg.crntSchplg].GetSrchFltr$8)
			plgns[conf::Dlg.crntSchplg].GetSrchFltr$8(&srchFrFileFltr[0],260);
		if(buf)
		{	if(1==*((int*)buf))
			{	buf = ((char*)buf)+sizeof(int);
				wchar_t pth[MAX_PATH];int l=MyStringCpy(pth,MAX_PATH,(wchar_t*)buf);
				wchar_t *pch=wcsrchr(pth,'\\');
				if(!pch)pch=&pth[l];else ++pch;
				l=(int)(pch-&pth[0]);
				*pch++='*';*pch=0;
				if(0==wcscmp(p->GetPath(),pth))
				{p->FreeSelection();
				 p->SetHot(p->FindItem(&((wchar_t*)buf)[l]),TRUE);
				}
				else
				{p->FreeMem();//search.panel->FreeSelection();
				 p->GetEntry()->Reset();
				 p->SetPath(pth,MAX_PATH,FALSE);
				 p->GetEntry()->SetPushEntryInStartup(pth);
				 p->FillDirectFolder();
				 p->GetEntry()->Push(pth,directFolder,0);
				 p->AdjustScrollity();
				 p->SetHot(0);
				 p->ClrScr();
				 p->Render();
				 p->SetHot(p->FindItem(wcsrchr((wchar_t*)buf,'\\')+1),TRUE);
			}}
			else
			{	p->FreeMem();//search.panel->FreeSelection();
				p->GetPath()[0] = 0;
				p->SetPathLn(0);
				p->GetEntry()->Push(p->GetPath(),rndPathList,0);
				p->FillRandomPathList(buf);
				p->AdjustScrollity();
				p->SetHot(0);
				p->ClrScr();
				p->Render();
		}	}

		plgns[conf::Dlg.crntSchplg].FreePlugin();

		CmnCntrl::CreateDragAndDrop();
}	}

BOOL SearchForContainText$12(wchar_t *rootPath,wchar_t *sub,WIN32_FIND_DATAW *pf)
{
	if(conf::Dlg.crntSchplg>-1)
	if(fSearchViaF7::numPlugins>0)
	if(conf::Dlg.crntSchplg<fSearchViaF7::numPlugins)
	{	plgns[conf::Dlg.crntSchplg].LoadPlugin();
		BOOL r;
BEGIN_TRY
		r=plgns[conf::Dlg.crntSchplg].SearchForContainText$12(rootPath,sub,pf);
END_TRY
{		plgns[conf::Dlg.crntSchplg].FreePlugin();
		return FALSE;
}
		plgns[conf::Dlg.crntSchplg].FreePlugin();
		return r;
	}
	return FALSE;
}

BOOL SearchForContainTextW$12(wchar_t *rootPath,wchar_t *sub,WIN32_FIND_DATAW *pf)
{
	if(conf::Dlg.crntSchplg>-1)
	if(fSearchViaF7::numPlugins>0)
	if(conf::Dlg.crntSchplg<fSearchViaF7::numPlugins)
	{	plgns[conf::Dlg.crntSchplg].LoadPlugin();
		BOOL r;
BEGIN_TRY
		r=plgns[conf::Dlg.crntSchplg].SearchForContainTextW$12(rootPath,sub,pf);
END_TRY
{		plgns[conf::Dlg.crntSchplg].FreePlugin();
		return FALSE;
}
		plgns[conf::Dlg.crntSchplg].FreePlugin();
		return r;
	}
	return FALSE;
}

BOOL SearchForNotContainText$12(wchar_t *rootPath,wchar_t *sub,WIN32_FIND_DATA *pf)
{
	if(conf::Dlg.crntSchplg>-1)
	if(fSearchViaF7::numPlugins>0)
	if(conf::Dlg.crntSchplg<fSearchViaF7::numPlugins)
	{	plgns[conf::Dlg.crntSchplg].LoadPlugin();
		BOOL r=plgns[conf::Dlg.crntSchplg].SearchForNotContainText$12(rootPath,sub,pf);
		plgns[conf::Dlg.crntSchplg].FreePlugin();
		return r;
	}
	return FALSE;
}

BOOL SearchForNotContainTextW$12(wchar_t *rootPath,wchar_t *sub,WIN32_FIND_DATA *pf)
{
	if(conf::Dlg.crntSchplg>-1)
	if(fSearchViaF7::numPlugins>0)
	if(conf::Dlg.crntSchplg<fSearchViaF7::numPlugins)
	{	plgns[conf::Dlg.crntSchplg].LoadPlugin();
		BOOL r=plgns[conf::Dlg.crntSchplg].SearchForNotContainTextW$12(rootPath,sub,pf);
		plgns[conf::Dlg.crntSchplg].FreePlugin();
		return r;
	}
	return FALSE;
}

void ResizeChilds1(HWND dlg, int w, int h)
{
	width = w; height = h;

	SetWindowPos(GetDlgItem(dlg,IDC_TAB_FILE_SEACH),HWND_BOTTOM,3,3,w-7,420,SWP_SHOWWINDOW);//MoveWindow(GetDlgItem(dlg,IDC_TAB_FILE_SEACH),3,3,w-7,420,TRUE);//3 3 370 260
	SetWindowPos(GetDlgItem(dlg,IDC_STATIC),HWND_TOP,w-170,5,47,14,SWP_SHOWWINDOW);//268 5 27 8
	SetWindowPos(GetDlgItem(dlg,IDC_COMBO_METHOD),HWND_TOP,w-116,1,114,12,SWP_SHOWWINDOW);//297 1 78 12

	//if(hResultsLB)
	//{	SetWindowPos(hInfoEdit,HWND_TOP,2,448,w-4,22,SWP_SHOWWINDOW);
	//	SetWindowPos(hResultsLB,HWND_TOP,2,472,w-4,h-minHeight+14,SWP_SHOWWINDOW);
	//}

	int id = TabCtrl_GetCurSel(GetDlgItem(dlg,IDC_TAB_FILE_SEACH));
	//if(0==id)
	//{
		//SetWindowPos(GetDlgItem(dlg,IDC_BUTTON_ADD_PATH),HWND_TOP,w-204,78,95,17,SWP_SHOWWINDOW);//210 46 77 13
		//SetWindowPos(GetDlgItem(dlg,IDC_BUTTON_ADD_DISK),HWND_TOP,w-106,78,95,17,SWP_SHOWWINDOW);//288 46 77 13

		SetWindowPos(GetDlgItem(dlg,IDC_COMBO_SEARCH_FOR_TEXT),HWND_TOP,7,138,w-14,12,id?SWP_HIDEWINDOW:SWP_SHOWWINDOW);//7 85 361 12
		SetWindowPos(GetDlgItem(dlg,IDC_COMBO_SEARCH_NOT_TEXT),HWND_TOP,7,268,w-14,12,id?SWP_HIDEWINDOW:SWP_SHOWWINDOW);
	
		SetWindowPos(GetDlgItem(dlg,IDC_COMBO_SEARCH_PATH),HWND_TOP,7,95,w-14,12,id?SWP_HIDEWINDOW:SWP_SHOWWINDOW);//7 59 361 12
	
		SetWindowPos(GetDlgItem(dlg,IDC_COMBO_SEARCH_NAME),HWND_TOP,7,50,w-14,12,
			id?SWP_HIDEWINDOW:SWP_SHOWWINDOW);//7 30 361 12
	//}

	/*IDCANCEL
	IDOK
	IDC_EDIT_ALTERNATIVE_FILE_NAME*/
}

VOID UpItem1(HWND prnt, int dlgItem, int y)
{
RECT r;POINT p[2];
HWND chld = GetDlgItem(prnt,dlgItem);
	GetWindowRect(chld,&r);
	p[0].x = r.left; p[0].y = r.top-y;
	p[1].x = r.right;p[1].y = r.bottom-y;
	ScreenToClient(prnt,&p[0]);
	ScreenToClient(prnt,&p[1]);
	int i=MoveWindow(chld,p[0].x,p[0].y,p[1].x-p[0].x,p[1].y-p[0].y,TRUE);
}

VOID AlignDayFrSpin1(HWND hDlg,WPARAM wParam,int idEdit,wchar_t* s)
{
	if(SB_THUMBPOSITION==LOWORD(wParam) || SB_THUMBTRACK==LOWORD(wParam))
	{	if(HIWORD(wParam)>50)
		{	if(GetDlgItemText(hDlg,idEdit,s,MAX_PATH))
			{	if(++s[1]>(s[0]<'3'?'9':'1'))
				{	s[1]=s[0]<'3'?'0':'1';
					if(++s[0]>'3')s[0]='3';
				}
				s[10]=0;s[2]=s[5]='.';
				SetDlgItemText(hDlg,idEdit,s);
		}	} else
		{	if(GetDlgItemText(hDlg,idEdit,s,MAX_PATH))
			{	if(--s[1]<(s[0]>'0'?'0':'1'))
				{	s[1]=s[0]>'0'?'9':'1';
					if(--s[0]<'0')s[0]='0';
				}
				s[10]=0;s[2]=s[5]='.';
				SetDlgItemText(hDlg,idEdit,s);
}	}	}	}

VOID AlignHourFrSpin1(HWND hDlg,WPARAM wParam,int idEdit,wchar_t* s)
{
	if(SB_THUMBPOSITION==LOWORD(wParam) || SB_THUMBTRACK==LOWORD(wParam))
	{	if(HIWORD(wParam)>50)
		{	if(GetDlgItemText(hDlg,idEdit,s,MAX_PATH))
			{	if(++s[1]>(s[0]<'2'?'9':'3'))
				{	s[1]=s[0]<'2'?'0':'3';
					if(++s[0]>'2')s[0]='2';
				}
				s[12]=0;s[2]=s[5]=s[8]='.';
				SetDlgItemText(hDlg,idEdit,s);
		}	} else
		{	if(GetDlgItemText(hDlg,idEdit,s,MAX_PATH))
			{	if(--s[1]<'0')
				{	s[1]=s[0]>'0'?'9':'0';
					if(--s[0]<'0')s[0]='0';
				}
				s[12]=0;s[2]=s[5]=s[8]='.';
				SetDlgItemText(hDlg,idEdit,s);
}	}	}	}

VOID AlignMilsFrSpin1(HWND hDlg,WPARAM wParam,int idEdit,wchar_t* s)
{
	if(SB_THUMBPOSITION==LOWORD(wParam) || SB_THUMBTRACK==LOWORD(wParam))
	{	if(HIWORD(wParam)>50)
		{	if(GetDlgItemText(hDlg,idEdit,s,MAX_PATH))
			{	if(++s[11]>'9')
				{	s[11]=(s[9]=='9'&&s[10]=='9')?'9':'0';
					if(++s[10]>'9')
					{	s[10]=s[9]<'9'?'0':'9';
						if(++s[9]>'9') s[9]='9';
				}	}
				s[12]=0;s[2]=s[5]=s[8]='.';
				SetDlgItemText(hDlg,idEdit,s);
		}	} else
		{	if(GetDlgItemText(hDlg,idEdit,s,MAX_PATH))
			{	if(--s[11]<'0')
				{	s[11]=(s[9]=='0'&&s[10]=='0')?'0':'9';
					if(--s[10]<'0')
					{	s[10]=s[9]>'0'?'9':'0';
						if(--s[9]<'0') s[9]='0';
				}	}
				s[12]=0;s[2]=s[5]=s[8]='.';
				SetDlgItemText(hDlg,idEdit,s);
}	}	}	}

VOID AlignMinFrSpin1(HWND hDlg,WPARAM wParam,int idEdit,wchar_t* s)
{
	if(SB_THUMBPOSITION==LOWORD(wParam) || SB_THUMBTRACK==LOWORD(wParam))
	{	if(HIWORD(wParam)>50)
		{	if(GetDlgItemText(hDlg,idEdit,s,MAX_PATH))
			{	if(++s[4]>(s[3]<'6'?'9':'0'))
				{	s[4]=s[3]<'5'?'0':'9';
					if(++s[3]>'5')s[3]='5';
				}
				s[12]=0;s[2]=s[5]=s[8]='.';
				SetDlgItemText(hDlg,idEdit,s);
		}	} else
		{	if(GetDlgItemText(hDlg,idEdit,s,MAX_PATH))
			{	if(--s[4]<'0')
				{	s[4]=s[3]>'0'?'9':'0';
					if(--s[3]<'0')s[3]='0';
				}
				s[12]=0;s[2]=s[5]=s[8]='.';
				SetDlgItemText(hDlg,idEdit,s);
}	}	}	}

VOID AlignMoonFrSpin1(HWND hDlg,WPARAM wParam,int idEdit,wchar_t* s)
{
	if(SB_THUMBPOSITION==LOWORD(wParam) || SB_THUMBTRACK==LOWORD(wParam))
	{	if(HIWORD(wParam)>50)
		{	if(GetDlgItemText(hDlg,idEdit,s,MAX_PATH))
			{	if(++s[4]>(s[3]<'1'?'9':'2'))
				{	s[4]=s[3]<'1'?'0':'2';
					if(++s[3]>'1')s[3]='1';
				}
				s[10]=0;s[2]=s[5]='.';
				SetDlgItemText(hDlg,idEdit,s);
		}	} else
		{	if(GetDlgItemText(hDlg,idEdit,s,MAX_PATH))
			{	if(--s[4]<(s[3]>'0'?'0':'1'))
				{	s[4]=s[3]>'0'?'9':'1';
					if(--s[3]<'0')s[3]='0';
				}
				s[10]=0;s[2]=s[5]='.';
				SetDlgItemText(hDlg,idEdit,s);
}	}	}	}

VOID AlignSecFrSpin1(HWND hDlg,WPARAM wParam,int idEdit,wchar_t* s)
{
	if(SB_THUMBPOSITION==LOWORD(wParam) || SB_THUMBTRACK==LOWORD(wParam))
	{	if(HIWORD(wParam)>50)
		{	if(GetDlgItemText(hDlg,idEdit,s,MAX_PATH))
			{	if(++s[7]>(s[6]<'6'?'9':'0'))
				{	s[7]=s[6]<'5'?'0':'9';
					if(++s[6]>'5')s[6]='5';
				}
				s[12]=0;s[2]=s[5]=s[8]='.';
				SetDlgItemText(hDlg,idEdit,s);
		}	} else
		{	if(GetDlgItemText(hDlg,idEdit,s,MAX_PATH))
			{	if(--s[7]<'0')
				{	s[7]=s[6]>'0'?'9':'0';
					if(--s[6]<'0')s[6]='0';
				}
				s[12]=0;s[2]=s[5]=s[8]='.';
				SetDlgItemText(hDlg,idEdit,s);
}	}	}	}

VOID AlignYearFrSpin1(HWND hDlg,WPARAM wParam,int idEdit,wchar_t* s)
{
	if(SB_THUMBPOSITION==LOWORD(wParam) || SB_THUMBTRACK==LOWORD(wParam))
	{	if(HIWORD(wParam)>50)
		{	if(GetDlgItemText(hDlg,idEdit,s,MAX_PATH))
			{	if(++s[9]>'9')
				{	s[9]=(s[8]=='9'&&s[7]=='9'&&s[6]=='9')?'9':'0';
					if(++s[8]>'9')
					{	s[8]=(s[7]=='9'&&s[6]=='9')?'9':'0';
						if(++s[7]>'9')
						{	s[7] = s[6]=='9'?'9':'0';
							if(++s[6]>'9')s[6]='9';
				}	}	}
				s[10]=0;s[2]=s[5]='.';
				SetDlgItemText(hDlg,idEdit,s);
		}	} else
		{	if(GetDlgItemText(hDlg,idEdit,s,MAX_PATH))
			{	if(--s[9]<'0')
				{	s[9]=(s[8]=='0'&&s[7]=='0'&&s[6]=='0')?'0':'9';
					if(--s[8]<'0')
					{	s[8]=(s[7]=='0'&&s[6]=='0')?'0':'9';
						if(--s[7]<'0')
						{	s[7] = s[6]=='0'?'0':'9';
							if(--s[6]<'0')s[6]='0';
				}	}	}
				s[10]=0;s[2]=s[5]='.';
				SetDlgItemText(hDlg,idEdit,s);
}	}	}	}

VOID TimeToEdit1(FILETIME ft, HWND hDlg, int edtDateId, int edtTimeId)
{
SYSTEMTIME st;FileTimeToSystemTime(&ft,&st);
	wchar_t s[16];
	StringCchPrintf(s,16,L"%02d.%02d.%04d",st.wDay,st.wMonth,st.wYear);
	SetDlgItemText(hDlg,edtDateId,s);
	StringCchPrintf(s,16,L"%02d.%02d.%02d.%03d",st.wHour,st.wMinute,st.wSecond,st.wMilliseconds);
	SetDlgItemText(hDlg,edtTimeId,s);
}

VOID LocTimeToEdit11(HWND hDlg, int edtDateId, int edtTimeId)
{
SYSTEMTIME st;GetLocalTime(&st);
	wchar_t s[16];
	StringCchPrintf(s,16,L"%02d.%02d.%04d",st.wDay,st.wMonth,st.wYear);
	SetDlgItemText(hDlg,edtDateId,s);
	StringCchPrintf(s,16,L"%02d.%02d.%02d.%03d",st.wHour,st.wMinute,st.wSecond,st.wMilliseconds);
	SetDlgItemText(hDlg,edtTimeId,s);
}

VOID SetTabPage1(HWND hDlg, int iTabPage)
{
switch(iTabPage)
{
 case 0: default:
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ALTERNATIVE_NAME),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_ALTERNATIVE_FILE_NAME),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_CREATE_TIME_BEFORE),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_CREATE_TIME_AFTER),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_DATE),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_DATE2),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_DATE_AFTER),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_DATE_AFTER2),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_CREATE_TIME_BETWEEN),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_LAST_ACCESS_TIME_BEFORE),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_LAST_ACCESS_TIME_AFTER),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE2),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_AFTER),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_AFTER2),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_LAST_ACCESS_TIME_BETWEEN),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_LAST_WRITE_TIME_BEFORE),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_LAST_WRITE_TIME_AFTER),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE2),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_AFTER),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_AFTER2),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_LAST_WRITE_TIME_BETWEEN),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_FILE_SIZE),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_COMBO_FILE_SIZE_EQUATION),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_FILE_SIZE),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_FILE_SIZE),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_COMBO_FILE_SIZE_QUANTITY),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_FILE_ATTRIBUTE),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_ARCHIVE),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_COMPRESSED),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_DEVICE),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_DIRECTORY),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_ENCRYPTED),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_HIDDEN),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_NORMAL),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_NOT_INDEXED),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_OFFLINE),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_READ_ONLY),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_REPARSE_POINT),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_SPARSE_FILE),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_SYSTEM),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_TEMPORARY),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_VIRTUAL),SW_HIDE);

 	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_BETWEEN_DATE),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_BETWEEN_TIME),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_BETWEEN_DATE2),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_BETWEEN_TIME2),SW_HIDE);
		  
 	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_BETWEEN),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_TIME_BETWEEN),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_BETWEEN2),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_TIME_BETWEEN2),SW_HIDE);

 	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_BETWEEN),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_TIME_BETWEEN),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_BETWEEN2),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_TIME_BETWEEN2),SW_HIDE);

	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_DAY),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_MOONS),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_YEAR),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_DAY),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_MOONS),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_YEAR),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_DAY),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_MOONS),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_YEAR),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_DAY),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_MOON),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_YEAR),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_DAY),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_MOON),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_YEAR),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_DAY),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_MOON),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_YEAR),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_DAY),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_MOON),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_YEAR),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_DAY),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_MOON),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_YEAR),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_DAY),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_MOON),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_YEAR),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_DAY),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_MOON),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_YEAR),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_DAY),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_MOON),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_YEAR),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_DAY),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_MOON),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_YEAR),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_HOUR),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_MIN),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_SEC),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_MILS),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_HOUR),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_MIN),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_SEC),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_MILS),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_HOUR),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_MIN),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_SEC),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_MILS),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_HOUR),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_MIN),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_SEC),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_MILS),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_HOUR),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_MIN),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_SEC),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_MILS),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_HOUR),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_MIN),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_SEC),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_MILS),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_HOUR),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_MIN),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_SEC),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_MILS),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_HOUR),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_MIN),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_SEC),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_MILS),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_HOUR),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_MIN),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_SEC),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_MILS),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_HOUR),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_MIN),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_SEC),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_MILS),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_HOUR),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_MIN),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_SEC),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_MILS),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_HOUR),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_MIN),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_SEC),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_MILS),SW_HIDE);

	//Page1:
	ShowWindow(GetDlgItem(hDlg,IDC_STATIC1),SW_SHOW); 
	ShowWindow(GetDlgItem(hDlg,IDC_STATIC2),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_COMBO_SEARCH_NAME),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_BUTTON_ADD_PATH),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_COMBO_SEARCH_PATH),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_TEXT_SEACH),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_COMBO_SEARCH_FOR_TEXT),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_UNICODE_OR_MULTIBYTE),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_BINARY_OR_CHARACTER),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_REGISTR_CAPS),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_NO_TEXT_SEACH),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_COMBO_SEARCH_NOT_TEXT),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_UNICODE_OR_MULTIBYTE2),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_BINARY_OR_CHARACTER2),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_REGISTR_CAPS2),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_BUTTON_ADD_DISK),SW_SHOW);
	//ShowWindow(GetDlgItem(hDlg,IDC_COMBO_METHOD),SW_SHOW);	
 break;
 case 1:
	ShowWindow(GetDlgItem(hDlg,IDC_STATIC1),SW_HIDE); 
	ShowWindow(GetDlgItem(hDlg,IDC_STATIC2),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_COMBO_SEARCH_NAME),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_BUTTON_ADD_PATH),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_COMBO_SEARCH_PATH),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_TEXT_SEACH),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_COMBO_SEARCH_FOR_TEXT),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_UNICODE_OR_MULTIBYTE),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_BINARY_OR_CHARACTER),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_REGISTR_CAPS),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_NO_TEXT_SEACH),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_COMBO_SEARCH_NOT_TEXT),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_UNICODE_OR_MULTIBYTE2),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_BINARY_OR_CHARACTER2),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_REGISTR_CAPS2),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_BUTTON_ADD_DISK),SW_HIDE);
	//ShowWindow(GetDlgItem(hDlg,IDC_COMBO_METHOD),SW_SHOW);

	//Page1:
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ALTERNATIVE_NAME),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_ALTERNATIVE_FILE_NAME),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_CREATE_TIME_BEFORE),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_CREATE_TIME_AFTER),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_DATE),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_DATE2),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_DATE_AFTER),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_DATE_AFTER2),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_CREATE_TIME_BETWEEN),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_LAST_ACCESS_TIME_BEFORE),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_LAST_ACCESS_TIME_AFTER),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE2),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_AFTER),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_AFTER2),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_LAST_ACCESS_TIME_BETWEEN),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_LAST_WRITE_TIME_BEFORE),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_LAST_WRITE_TIME_AFTER),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE2),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_AFTER),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_AFTER2),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_LAST_WRITE_TIME_BETWEEN),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_FILE_SIZE),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_COMBO_FILE_SIZE_EQUATION),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_FILE_SIZE),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_FILE_SIZE),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_COMBO_FILE_SIZE_QUANTITY),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_FILE_ATTRIBUTE),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_ARCHIVE),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_COMPRESSED),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_DEVICE),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_DIRECTORY),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_ENCRYPTED),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_HIDDEN),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_NORMAL),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_NOT_INDEXED),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_OFFLINE),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_READ_ONLY),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_REPARSE_POINT),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_SPARSE_FILE),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_SYSTEM),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_TEMPORARY),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_VIRTUAL),SW_SHOW);

 	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_BETWEEN_DATE),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_BETWEEN_TIME),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_BETWEEN_DATE2),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_BETWEEN_TIME2),SW_SHOW);
		  
 	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_BETWEEN),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_TIME_BETWEEN),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_BETWEEN2),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_TIME_BETWEEN2),SW_SHOW);

 	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_BETWEEN),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_TIME_BETWEEN),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_BETWEEN2),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_TIME_BETWEEN2),SW_SHOW);

	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_DAY),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_MOONS),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_YEAR),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_DAY),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_MOONS),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_YEAR),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_DAY),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_MOONS),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_YEAR),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_DAY),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_MOON),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_YEAR),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_DAY),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_MOON),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_YEAR),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_DAY),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_MOON),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_YEAR),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_DAY),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_MOON),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_YEAR),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_DAY),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_MOON),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_YEAR),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_DAY),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_MOON),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_YEAR),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_DAY),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_MOON),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_YEAR),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_DAY),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_MOON),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_YEAR),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_DAY),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_MOON),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_YEAR),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_HOUR),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_MIN),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_SEC),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_MILS),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_HOUR),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_MIN),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_SEC),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_MILS),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_HOUR),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_MIN),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_SEC),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_MILS),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_HOUR),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_MIN),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_SEC),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_MILS),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_HOUR),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_MIN),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_SEC),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_MILS),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_HOUR),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_MIN),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_SEC),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_MILS),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_HOUR),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_MIN),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_SEC),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_MILS),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_HOUR),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_MIN),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_SEC),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_MILS),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_HOUR),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_MIN),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_SEC),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_MILS),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_HOUR),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_MIN),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_SEC),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_MILS),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_HOUR),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_MIN),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_SEC),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_MILS),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_HOUR),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_MIN),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_SEC),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_MILS),SW_SHOW);

break;
}}

//Faqatgina custom itemni chiqarishning o'zi uchun alohida shu yerga tiqishga majburman.
//Dialog resursini plagin dll imizdan topdim. Uni o'zidagi FinfIleDlgProc xuddi shunday, 1 oz farqi bo'lmasa.
INT_PTR CALLBACK CstmItemAttrbsDlgProc(HWND hDlg,UINT message,WPARAM wParam,LPARAM lParam)
{	//static int i=0;
	//char ss[32];sprintf(ss,"\n %d ",i++);
	//OutputDebugString(ss);
	//OutputDebugString(GetWinNotifyText(message));
	//sprintf(ss," %x %x",wParam,lParam);
	//OutputDebugString(ss);

static HFONT hf=0;static int hfRef=0;//obshiy hf, dinamik uchun emas:
static HBRUSH br=0;
static Panel *panel;
static HBRUSH brHtBk=0;
static CBToDisk selV7PthCB,selV7TxtCB,selV7ExclTxt,selV7NameCB;
	UNREFERENCED_PARAMETER(lParam);

	switch(message)
	{
	case WM_SIZING:
		RECT *rc; rc = (RECT*)lParam;
		if(rc->right-rc->left < minWidth)
			rc->right = rc->left + minWidth;
		/*if(hResultsLB)
		{	if(rc->bottom-rc->top < minHeightAftCrLB)
				rc->bottom = rc->top + minHeightAftCrLB;
		} else*/
		{	if(rc->bottom-rc->top < minHeight)
				rc->bottom = rc->top + minHeight;
			else if(rc->bottom-rc->top > minHeight)
				rc->bottom = rc->top + minHeight;
		}
		return 0;
	case WM_SIZE:
		ResizeChilds1(hDlg, LOWORD(lParam), HIWORD(lParam));
		return 0;
	/*case WM_SYSCOMMAND:
		if(SC_CLOSE==wParam)
		{	EndDialog(hDlg,0);
			return 1;
		}
		else if(SC_MAXIMIZE==wParam)
		{	static BOOL bMAximize = FALSE;
			bMAximize = !bMAximize;
			ResizeDlg(hDlg,bMAximize?1:2);
			return 1;
		}
		return 0;*/
	case WM_INITDIALOG:
		panel = (Panel*)lParam;

		int left,top;
		left = conf::wndLeft+(conf::wndWidth - minWidth)/2;
		top = conf::wndTop + (conf::wndHeight - minHeight)/2;
		MoveWindow(hDlg, left, top, minWidth, minHeight, TRUE);

		//Load language strings:
		wchar_t s[MAX_PATH];
		LoadString(hInst,IDS_STRINGSW_74,s,MAX_PATH);
		SetWindowText(hDlg,s);
		LoadString(hInst,IDS_STRINGSW_63,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_STATIC1,s);
		LoadString(hInst,IDS_STRINGSW_111,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_BUTTON_ADD_DISK,s);
		LoadString(hInst,IDS_STRINGSW_77,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_STATIC2,s);
		LoadString(hInst,IDS_STRINGSW_78,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_BUTTON_ADD_PATH,s);
		LoadString(hInst,IDS_STRINGSW_79,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_CHECK_TEXT_SEACH,s);
		LoadString(hInst,IDS_STRINGSW_80,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_CHECK_UNICODE_OR_MULTIBYTE,s);
		//LoadString(hInst,IDS_STRINGSW_81,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_CHECK_BINARY_OR_CHARACTER,L"ASCII");//s);
		LoadString(hInst,IDS_STRINGSW_82,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_CHECK_REGISTR_CAPS,s);
		LoadString(hInst,IDS_STRINGSW_110,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_CHECK_NO_TEXT_SEACH,s);
		LoadString(hInst,IDS_STRINGSW_80,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_CHECK_UNICODE_OR_MULTIBYTE2,s);
		//LoadString(hInst,IDS_STRINGSW_81,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_CHECK_BINARY_OR_CHARACTER2,L"ASCII");//s);
		LoadString(hInst,IDS_STRINGSW_82,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_CHECK_REGISTR_CAPS2,s);
		LoadString(hInst,lParam?IDS_STRINGSW_3:IDS_STRINGSW_41,s,MAX_PATH);
		SetDlgItemText(hDlg,IDOK,s);
		if(lParam)
		{	LoadString(hInst,IDS_STRINGSW_13,s,MAX_PATH);
			SetDlgItemText(hDlg,IDCANCEL,s);
		} else ShowWindow(GetDlgItem(hDlg,IDCANCEL),SW_HIDE);
		LoadString(hInst,IDS_STRINGSW_83,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_CHECK_ALTERNATIVE_NAME,s);
		LoadString(hInst,IDS_STRINGSW_84,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_CHECK_CREATE_TIME_BEFORE,s);
		LoadString(hInst,IDS_STRINGSW_85,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_CHECK_CREATE_TIME_AFTER,s);
		LoadString(hInst,IDS_STRINGSW_86,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_CHECK_CREATE_TIME_BETWEEN,s);
		LoadString(hInst,IDS_STRINGSW_87,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_CHECK_LAST_ACCESS_TIME_BEFORE,s);
		LoadString(hInst,IDS_STRINGSW_88,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_CHECK_LAST_ACCESS_TIME_AFTER,s);
		LoadString(hInst,IDS_STRINGSW_89,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_CHECK_LAST_ACCESS_TIME_BETWEEN,s);
		LoadString(hInst,IDS_STRINGSW_90,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_CHECK_LAST_WRITE_TIME_BEFORE,s);
		LoadString(hInst,IDS_STRINGSW_91,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_CHECK_LAST_WRITE_TIME_AFTER ,s);
		LoadString(hInst,IDS_STRINGSW_92,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_CHECK_LAST_WRITE_TIME_BETWEEN ,s);
		LoadString(hInst,IDS_STRINGSW_55,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_CHECK_FILE_SIZE,s);
		LoadString(hInst,IDS_STRINGSW_94,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_CHECK_FILE_ATTRIBUTE,s);
		LoadString(hInst,IDS_STRINGSW_158,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_CHECK_ATTRIBUTE_ARCHIVE,s);
		LoadString(hInst,IDS_STRINGSW_96,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_CHECK_ATTRIBUTE_COMPRESSED,s);
		LoadString(hInst,IDS_STRINGSW_97,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_CHECK_ATTRIBUTE_DEVICE,s);
		LoadString(hInst,IDS_STRINGSW_98,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_CHECK_ATTRIBUTE_DIRECTORY,s);
		LoadString(hInst,IDS_STRINGSW_99,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_CHECK_ATTRIBUTE_ENCRYPTED,s);
		LoadString(hInst,IDS_STRINGSW_100,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_CHECK_ATTRIBUTE_HIDDEN,s);
		LoadString(hInst,IDS_STRINGSW_101,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_CHECK_ATTRIBUTE_NORMAL,s);
		LoadString(hInst,IDS_STRINGSW_102,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_CHECK_ATTRIBUTE_NOT_INDEXED,s);
		LoadString(hInst,IDS_STRINGSW_103,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_CHECK_ATTRIBUTE_OFFLINE,s);
		LoadString(hInst,IDS_STRINGSW_104,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_CHECK_ATTRIBUTE_READ_ONLY,s);
		LoadString(hInst,IDS_STRINGSW_105,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_CHECK_ATTRIBUTE_REPARSE_POINT,s);
		LoadString(hInst,IDS_STRINGSW_106,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_CHECK_ATTRIBUTE_SPARSE_FILE,s);
		LoadString(hInst,IDS_STRINGSW_107,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_CHECK_ATTRIBUTE_SYSTEM,s);
		LoadString(hInst,IDS_STRINGSW_108,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_CHECK_ATTRIBUTE_TEMPORARY,s);
		LoadString(hInst,IDS_STRINGSW_109,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_CHECK_ATTRIBUTE_VIRTUAL,s);
		LoadString(hInst,IDS_STRINGSW_240,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_CHECK_ENUM_SUBDIR,s);

		SendMessage(GetDlgItem(hDlg,IDC_COMBO_METHOD),CB_INSERTSTRING,0,(LPARAM)L"FindFirstFile");
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_METHOD),CB_INSERTSTRING,0,(LPARAM)L"ZwQueryDirectoryFile");
		if(!NSKERNEL::pZwCreateFile)
		{	EnableWindow(GetDlgItem(hDlg,IDC_COMBO_METHOD),FALSE);
			SendMessage(GetDlgItem(hDlg,IDC_COMBO_METHOD),CB_SETCURSEL,1,0);
		} else SendMessage(GetDlgItem(hDlg,IDC_COMBO_METHOD),CB_SETCURSEL,0,0);

		UpItem1(hDlg,IDC_CHECK_ALTERNATIVE_NAME,462);
		UpItem1(hDlg,IDC_EDIT_ALTERNATIVE_FILE_NAME,462);
		UpItem1(hDlg,IDC_CHECK_CREATE_TIME_BEFORE,462);
		UpItem1(hDlg,IDC_CHECK_CREATE_TIME_AFTER,462);
		UpItem1(hDlg,IDC_EDIT_CREATE_DATE,462);
		UpItem1(hDlg,IDC_EDIT_CREATE_DATE2,462);
		UpItem1(hDlg,IDC_EDIT_CREATE_DATE_AFTER,462);
		UpItem1(hDlg,IDC_EDIT_CREATE_DATE_AFTER2,462);
		UpItem1(hDlg,IDC_CHECK_CREATE_TIME_BETWEEN,462);
		UpItem1(hDlg,IDC_CHECK_LAST_ACCESS_TIME_BEFORE,462);
		UpItem1(hDlg,IDC_CHECK_LAST_ACCESS_TIME_AFTER,462);
		UpItem1(hDlg,IDC_EDIT_LAST_ACCESS_DATE,462);
		UpItem1(hDlg,IDC_EDIT_LAST_ACCESS_DATE2,462);
		UpItem1(hDlg,IDC_EDIT_LAST_ACCESS_DATE_AFTER,462);
		UpItem1(hDlg,IDC_EDIT_LAST_ACCESS_DATE_AFTER2,462);
		UpItem1(hDlg,IDC_CHECK_LAST_ACCESS_TIME_BETWEEN,462);
		UpItem1(hDlg,IDC_CHECK_LAST_WRITE_TIME_BEFORE,462);
		UpItem1(hDlg,IDC_CHECK_LAST_WRITE_TIME_AFTER,462);
		UpItem1(hDlg,IDC_EDIT_LAST_WRITE_DATE,462);
		UpItem1(hDlg,IDC_EDIT_LAST_WRITE_DATE2,462);
		UpItem1(hDlg,IDC_EDIT_LAST_WRITE_DATE_AFTER,462);
		UpItem1(hDlg,IDC_EDIT_LAST_WRITE_DATE_AFTER2,462);
		UpItem1(hDlg,IDC_CHECK_LAST_WRITE_TIME_BETWEEN,462);
		UpItem1(hDlg,IDC_CHECK_FILE_SIZE,462);
		UpItem1(hDlg,IDC_COMBO_FILE_SIZE_EQUATION,462);
		UpItem1(hDlg,IDC_EDIT_FILE_SIZE,462);
		UpItem1(hDlg,IDC_SPIN_FILE_SIZE,462);
		UpItem1(hDlg,IDC_COMBO_FILE_SIZE_QUANTITY,462);
		UpItem1(hDlg,IDC_CHECK_FILE_ATTRIBUTE,462);
 		UpItem1(hDlg,IDC_CHECK_ATTRIBUTE_ARCHIVE,462);
 		UpItem1(hDlg,IDC_CHECK_ATTRIBUTE_COMPRESSED,462);
 		UpItem1(hDlg,IDC_CHECK_ATTRIBUTE_DEVICE,462);
 		UpItem1(hDlg,IDC_CHECK_ATTRIBUTE_DIRECTORY,462);
 		UpItem1(hDlg,IDC_CHECK_ATTRIBUTE_ENCRYPTED,462);
 		UpItem1(hDlg,IDC_CHECK_ATTRIBUTE_HIDDEN,462);
 		UpItem1(hDlg,IDC_CHECK_ATTRIBUTE_NORMAL,462);
 		UpItem1(hDlg,IDC_CHECK_ATTRIBUTE_NOT_INDEXED,462);
 		UpItem1(hDlg,IDC_CHECK_ATTRIBUTE_OFFLINE,462);
 		UpItem1(hDlg,IDC_CHECK_ATTRIBUTE_READ_ONLY,462);
 		UpItem1(hDlg,IDC_CHECK_ATTRIBUTE_REPARSE_POINT,462);
 		UpItem1(hDlg,IDC_CHECK_ATTRIBUTE_SPARSE_FILE,462);
 		UpItem1(hDlg,IDC_CHECK_ATTRIBUTE_SYSTEM,462);
 		UpItem1(hDlg,IDC_CHECK_ATTRIBUTE_TEMPORARY,462);
 		UpItem1(hDlg,IDC_CHECK_ATTRIBUTE_VIRTUAL,462);

 		UpItem1(hDlg,IDC_EDIT_CREATE_BETWEEN_DATE,462);
 		UpItem1(hDlg,IDC_EDIT_CREATE_BETWEEN_TIME,462);
 		UpItem1(hDlg,IDC_EDIT_CREATE_BETWEEN_DATE2,462);
 		UpItem1(hDlg,IDC_EDIT_CREATE_BETWEEN_TIME2,462);
		  
 		UpItem1(hDlg,IDC_EDIT_LAST_ACCESS_DATE_BETWEEN,462);
 		UpItem1(hDlg,IDC_EDIT_LAST_ACCESS_TIME_BETWEEN,462);
 		UpItem1(hDlg,IDC_EDIT_LAST_ACCESS_DATE_BETWEEN2,462);
 		UpItem1(hDlg,IDC_EDIT_LAST_ACCESS_TIME_BETWEEN2,462);

 		UpItem1(hDlg,IDC_EDIT_LAST_WRITE_DATE_BETWEEN,462);
 		UpItem1(hDlg,IDC_EDIT_LAST_WRITE_TIME_BETWEEN,462);
 		UpItem1(hDlg,IDC_EDIT_LAST_WRITE_DATE_BETWEEN2,462);
 		UpItem1(hDlg,IDC_EDIT_LAST_WRITE_TIME_BETWEEN2,462);

		UpItem1(hDlg,IDC_SPIN_CRTBEF_DAY,462);
		UpItem1(hDlg,IDC_SPIN_CRTBEF_MOONS,462);
		UpItem1(hDlg,IDC_SPIN_CRTBEF_YEAR,462);
		UpItem1(hDlg,IDC_SPIN_CRTBET_DAY,462);
		UpItem1(hDlg,IDC_SPIN_CRTBET_MOONS,462);
		UpItem1(hDlg,IDC_SPIN_CRTBET_YEAR,462);
		UpItem1(hDlg,IDC_SPIN_LSTBEF_DAY,462);
		UpItem1(hDlg,IDC_SPIN_LSTBEF_MOONS,462);
		UpItem1(hDlg,IDC_SPIN_LSTBEF_YEAR,462);
		UpItem1(hDlg,IDC_SPIN_LSTBET_DAY,462);
		UpItem1(hDlg,IDC_SPIN_LSTBET_MOON,462);
		UpItem1(hDlg,IDC_SPIN_LSTBET_YEAR,462);
		UpItem1(hDlg,IDC_SPIN_LSWTBEF_DAY,462);
		UpItem1(hDlg,IDC_SPIN_LSWTBEF_MOON,462);
		UpItem1(hDlg,IDC_SPIN_LSWTBEF_YEAR,462);
		UpItem1(hDlg,IDC_SPIN_LSWTBET_DAY,462);
		UpItem1(hDlg,IDC_SPIN_LSWTBET_MOON,462);
		UpItem1(hDlg,IDC_SPIN_LSWTBET_YEAR,462);
		UpItem1(hDlg,IDC_SPIN_CRAFT_DAY,462);
		UpItem1(hDlg,IDC_SPIN_CRAFT_MOON,462);
		UpItem1(hDlg,IDC_SPIN_CRAFT_YEAR,462);
		UpItem1(hDlg,IDC_SPIN_CRBET_DAY,462);
		UpItem1(hDlg,IDC_SPIN_CRBET_MOON,462);
		UpItem1(hDlg,IDC_SPIN_CRBET_YEAR,462);
		UpItem1(hDlg,IDC_SPIN_LSAFT_DAY,462);
		UpItem1(hDlg,IDC_SPIN_LSAFT_MOON,462);
		UpItem1(hDlg,IDC_SPIN_LSAFT_YEAR,462);
		UpItem1(hDlg,IDC_SPIN_LSABET_DAY,462);
		UpItem1(hDlg,IDC_SPIN_LSABET_MOON,462);
		UpItem1(hDlg,IDC_SPIN_LSABET_YEAR,462);
		UpItem1(hDlg,IDC_SPIN_LSWRAFT_DAY,462);
		UpItem1(hDlg,IDC_SPIN_LSWRAFT_MOON,462);
		UpItem1(hDlg,IDC_SPIN_LSWRAFT_YEAR,462);
		UpItem1(hDlg,IDC_SPIN_LSWRBET_DAY,462);
		UpItem1(hDlg,IDC_SPIN_LSWRBET_MOON,462);
		UpItem1(hDlg,IDC_SPIN_LSWRBET_YEAR,462);
		UpItem1(hDlg,IDC_SPIN_CRTBEF_HOUR,462);
		UpItem1(hDlg,IDC_SPIN_CRTBEF_MIN,462);
		UpItem1(hDlg,IDC_SPIN_CRTBEF_SEC,462);
		UpItem1(hDlg,IDC_SPIN_CRTBEF_MILS,462);
		UpItem1(hDlg,IDC_SPIN_CRTBET_HOUR,462);
		UpItem1(hDlg,IDC_SPIN_CRTBET_MIN,462);
		UpItem1(hDlg,IDC_SPIN_CRTBET_SEC,462);
		UpItem1(hDlg,IDC_SPIN_CRTBET_MILS,462);
		UpItem1(hDlg,IDC_SPIN_LSTBEF_HOUR,462);
		UpItem1(hDlg,IDC_SPIN_LSTBEF_MIN,462);
		UpItem1(hDlg,IDC_SPIN_LSTBEF_SEC,462);
		UpItem1(hDlg,IDC_SPIN_LSTBEF_MILS,462);
		UpItem1(hDlg,IDC_SPIN_LSTBET_HOUR,462);
		UpItem1(hDlg,IDC_SPIN_LSTBET_MIN,462);
		UpItem1(hDlg,IDC_SPIN_LSTBET_SEC,462);
		UpItem1(hDlg,IDC_SPIN_LSTBET_MILS,462);
		UpItem1(hDlg,IDC_SPIN_LSWTBEF_HOUR,462);
		UpItem1(hDlg,IDC_SPIN_LSWTBEF_MIN,462);
		UpItem1(hDlg,IDC_SPIN_LSWTBEF_SEC,462);
		UpItem1(hDlg,IDC_SPIN_LSWTBEF_MILS,462);
		UpItem1(hDlg,IDC_SPIN_LSWTBET_HOUR,462);
		UpItem1(hDlg,IDC_SPIN_LSWTBET_MIN,462);
		UpItem1(hDlg,IDC_SPIN_LSWTBET_SEC,462);
		UpItem1(hDlg,IDC_SPIN_LSWTBET_MILS,462);
		UpItem1(hDlg,IDC_SPIN_CRAFT_HOUR,462);
		UpItem1(hDlg,IDC_SPIN_CRAFT_MIN,462);
		UpItem1(hDlg,IDC_SPIN_CRAFT_SEC,462);
		UpItem1(hDlg,IDC_SPIN_CRAFT_MILS,462);
		UpItem1(hDlg,IDC_SPIN_CRBET_HOUR,462);
		UpItem1(hDlg,IDC_SPIN_CRBET_MIN,462);
		UpItem1(hDlg,IDC_SPIN_CRBET_SEC,462);
		UpItem1(hDlg,IDC_SPIN_CRBET_MILS,462);
		UpItem1(hDlg,IDC_SPIN_LSAFT_HOUR,462);
		UpItem1(hDlg,IDC_SPIN_LSAFT_MIN,462);
		UpItem1(hDlg,IDC_SPIN_LSAFT_SEC,462);
		UpItem1(hDlg,IDC_SPIN_LSAFT_MILS,462);
		UpItem1(hDlg,IDC_SPIN_LSABET_HOUR,462);
		UpItem1(hDlg,IDC_SPIN_LSABET_MIN,462);
		UpItem1(hDlg,IDC_SPIN_LSABET_SEC,462);
		UpItem1(hDlg,IDC_SPIN_LSABET_MILS,462);
		UpItem1(hDlg,IDC_SPIN_LSWRAFT_HOUR,462);
		UpItem1(hDlg,IDC_SPIN_LSWRAFT_MIN,462);
		UpItem1(hDlg,IDC_SPIN_LSWRAFT_SEC,462);
		UpItem1(hDlg,IDC_SPIN_LSWRAFT_MILS,462);
		UpItem1(hDlg,IDC_SPIN_LSWRBET_HOUR,462);
		UpItem1(hDlg,IDC_SPIN_LSWRBET_MIN,462);
		UpItem1(hDlg,IDC_SPIN_LSWRBET_SEC,462);
		UpItem1(hDlg,IDC_SPIN_LSWRBET_MILS,462);

		SetTabPage1(hDlg, 0);

		/*SendMessage(GetDlgItem(hDlg,IDC_CHECK_TEXT_SEACH),BM_SETCHECK,BST_UNCHECKED,0);
		EnableWindow(GetDlgItem(hDlg,IDC_COMBO_SEARCH_FOR_TEXT),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_CHECK_UNICODE_OR_MULTIBYTE),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_CHECK_BINARY_OR_CHARACTER),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_CHECK_REGISTR_CAPS),FALSE);

		SendMessage(GetDlgItem(hDlg,IDC_CHECK_NO_TEXT_SEACH),BM_SETCHECK,BST_UNCHECKED,0);
		EnableWindow(GetDlgItem(hDlg,IDC_COMBO_SEARCH_NOT_TEXT),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_CHECK_UNICODE_OR_MULTIBYTE2),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_CHECK_BINARY_OR_CHARACTER2),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_CHECK_REGISTR_CAPS2),FALSE);

		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ALTERNATIVE_NAME),BM_SETCHECK,BST_UNCHECKED,0);
		EnableWindow(GetDlgItem(hDlg,IDC_EDIT_ALTERNATIVE_FILE_NAME),FALSE);

		SendMessage(GetDlgItem(hDlg,IDC_CHECK_CREATE_TIME_BEFORE),BM_SETCHECK,BST_UNCHECKED,0);
		EnableWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_DATE),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_DATE2),FALSE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_CREATE_TIME_AFTER),BM_SETCHECK,BST_UNCHECKED,0);
		EnableWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_DATE_AFTER),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_DATE_AFTER2),FALSE);		
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_CREATE_TIME_BETWEEN),BM_SETCHECK,BST_UNCHECKED,0);
		EnableWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_BETWEEN_DATE),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_BETWEEN_TIME),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_BETWEEN_DATE2),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_BETWEEN_TIME2),FALSE);

		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_DAY),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_MOONS),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_YEAR),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_HOUR),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_MIN),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_SEC),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_MILS),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_DAY),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_MOONS),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_YEAR),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_HOUR),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_MIN),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_SEC),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_MILS),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_DAY),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_MOON),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_YEAR),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_HOUR),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_MIN),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_SEC),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_MILS),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_DAY),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_MOON),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_YEAR),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_HOUR),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_MIN),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_SEC),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_MILS),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_DAY),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_MOONS),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_YEAR),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_HOUR),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_MIN),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_SEC),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_MILS),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_DAY),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_MOON),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_YEAR),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_HOUR),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_MIN),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_SEC),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_MILS),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_DAY),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_MOON),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_YEAR),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_HOUR),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_MIN),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_SEC),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_MILS),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_FILE_SIZE),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_DAY),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_MOON),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_YEAR),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_HOUR),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_MIN),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_SEC),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_MILS),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_DAY),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_MOON),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_YEAR),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_HOUR),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_MIN),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_SEC),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_MILS),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_DAY),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_MOON),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_YEAR),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_HOUR),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_MIN),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_SEC),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_MILS),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_DAY),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_MOON),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_YEAR),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_HOUR),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_MIN),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_SEC),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_MILS),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_DAY),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_MOON),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_YEAR),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_HOUR),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_MIN),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_SEC),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_MILS),FALSE);
		  
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_ACCESS_TIME_BETWEEN),BM_SETCHECK,BST_UNCHECKED,0);
		EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_BETWEEN),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_TIME_BETWEEN),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_BETWEEN2),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_TIME_BETWEEN2),FALSE);

		SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_WRITE_TIME_BETWEEN),BM_SETCHECK,BST_UNCHECKED,0);
		EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_BETWEEN),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_TIME_BETWEEN),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_BETWEEN2),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_TIME_BETWEEN2),FALSE);

		SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_ACCESS_TIME_BEFORE),BM_SETCHECK,BST_UNCHECKED,0);
		EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE2),FALSE);
		 
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_ACCESS_TIME_AFTER),BM_SETCHECK,BST_UNCHECKED,0);
		EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_AFTER),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_AFTER2),FALSE);
		 
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_WRITE_TIME_BEFORE),BM_SETCHECK,BST_UNCHECKED,0);
		EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE2),FALSE);
	
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_WRITE_TIME_AFTER),BM_SETCHECK,BST_UNCHECKED,0);
		EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_AFTER),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_AFTER2),FALSE);
	
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_FILE_SIZE),BM_SETCHECK,BST_UNCHECKED,0);
		EnableWindow(GetDlgItem(hDlg,IDC_COMBO_FILE_SIZE_EQUATION),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_EDIT_FILE_SIZE),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_COMBO_FILE_SIZE_QUANTITY),FALSE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_FILE_ATTRIBUTE),BM_SETCHECK,BST_UNCHECKED,0);
		EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_ARCHIVE),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_COMPRESSED),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_DEVICE),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_DIRECTORY),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_ENCRYPTED),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_HIDDEN),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_NORMAL),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_NOT_INDEXED),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_OFFLINE),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_READ_ONLY),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_REPARSE_POINT),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_SPARSE_FILE),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_SYSTEM),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_TEMPORARY),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_VIRTUAL),FALSE);*/
  		 
		TCITEM tie;
		tie.mask = TCIF_TEXT;// | TCIF_IMAGE;
		tie.iImage = -1;
		LoadString(hInst,IDS_STRINGSW_76,s,MAX_PATH);
		tie.pszText = s;//"Size and time parameters:";
		TabCtrl_InsertItem(GetDlgItem(hDlg,IDC_TAB_FILE_SEACH),0, &tie);
		LoadString(hInst,IDS_STRINGSW_75,s,MAX_PATH);
		tie.pszText = s;//"Common parameters:";
		TabCtrl_InsertItem(GetDlgItem(hDlg,IDC_TAB_FILE_SEACH),0, &tie);

		TabCtrl_SetCurSel(GetDlgItem(hDlg,IDC_TAB_FILE_SEACH),0);

		SendMessage(GetDlgItem(hDlg,IDC_COMBO_FILE_SIZE_EQUATION),CB_INSERTSTRING,(WPARAM)-1,(LPARAM)"<");
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_FILE_SIZE_EQUATION),CB_INSERTSTRING,(WPARAM)-1,(LPARAM)">");
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_FILE_SIZE_EQUATION),CB_INSERTSTRING,(WPARAM)-1,(LPARAM)"==");
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_FILE_SIZE_EQUATION),CB_SETCURSEL,0,0);

		SendMessage(GetDlgItem(hDlg,IDC_COMBO_FILE_SIZE_QUANTITY),CB_INSERTSTRING,(WPARAM)-1,(LPARAM)"byte");
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_FILE_SIZE_QUANTITY),CB_INSERTSTRING,(WPARAM)-1,(LPARAM)"kb");
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_FILE_SIZE_QUANTITY),CB_INSERTSTRING,(WPARAM)-1,(LPARAM)"mb");
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_FILE_SIZE_QUANTITY),CB_INSERTSTRING,(WPARAM)-1,(LPARAM)"gb");
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_FILE_SIZE_QUANTITY),CB_SETCURSEL,0,0);

		SendMessage(GetDlgItem(hDlg,IDC_SPIN_FILE_SIZE),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_DAY),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_MOONS),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_YEAR),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_HOUR),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_MIN),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_SEC),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_MILS),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRTBET_DAY),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRTBET_MOONS),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRTBET_YEAR),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRTBET_HOUR),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRTBET_MIN),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRTBET_SEC),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRTBET_MILS),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRBET_DAY),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRBET_MOON),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRBET_YEAR),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRBET_HOUR),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRBET_MIN),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRBET_SEC),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRBET_MILS),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRAFT_DAY),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRAFT_MOON),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRAFT_YEAR),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRAFT_HOUR),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRAFT_MIN),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRAFT_SEC),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRAFT_MILS),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_DAY),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_MOONS),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_YEAR),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_HOUR),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_MIN),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_SEC),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_MILS),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_DAY),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_MOON),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_YEAR),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_HOUR),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_MIN),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_SEC),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_MILS),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_DAY),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_MOON),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_YEAR),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_HOUR),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_MIN),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_SEC),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_MILS),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSAFT_DAY),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSAFT_MOON),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSAFT_YEAR),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSAFT_HOUR),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSAFT_MIN),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSAFT_SEC),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSAFT_MILS),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSTBET_DAY),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSTBET_MOON),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSTBET_YEAR),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSTBET_HOUR),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSTBET_MIN),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSTBET_SEC),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSTBET_MILS),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSABET_DAY),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSABET_MOON),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSABET_YEAR),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSABET_HOUR),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSABET_MIN),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSABET_SEC),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSABET_MILS),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_DAY),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_MOON),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_YEAR),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_HOUR),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_MIN),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_SEC),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_MILS),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_DAY),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_MOON),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_YEAR),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_HOUR),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_MIN),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_SEC),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_MILS),UDM_SETRANGE32,0,100);

		SendMessage(GetDlgItem(hDlg,IDC_SPIN_FILE_SIZE),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_DAY),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_MOONS),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_YEAR),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_HOUR),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_MIN),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_SEC),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_MILS),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRTBET_DAY),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRTBET_MOONS),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRTBET_YEAR),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRTBET_HOUR),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRTBET_MIN),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRTBET_SEC),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRTBET_MILS),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRBET_DAY),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRBET_MOON),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRBET_YEAR),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRBET_HOUR),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRBET_MIN),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRBET_SEC),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRBET_MILS),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRAFT_DAY),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRAFT_MOON),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRAFT_YEAR),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRAFT_HOUR),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRAFT_MIN),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRAFT_SEC),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRAFT_MILS),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_DAY),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_MOONS),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_YEAR),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_HOUR),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_MIN),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_SEC),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_MILS),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_DAY),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_MOON),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_YEAR),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_HOUR),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_MIN),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_SEC),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_MILS),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_DAY),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_MOON),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_YEAR),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_HOUR),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_MIN),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_SEC),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_MILS),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSAFT_DAY),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSAFT_MOON),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSAFT_YEAR),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSAFT_HOUR),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSAFT_MIN),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSAFT_SEC),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSAFT_MILS),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSTBET_DAY),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSTBET_MOON),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSTBET_YEAR),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSTBET_HOUR),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSTBET_MIN),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSTBET_SEC),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSTBET_MILS),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSABET_DAY),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSABET_MOON),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSABET_YEAR),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSABET_HOUR),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSABET_MIN),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSABET_SEC),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSABET_MILS),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_DAY),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_MOON),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_YEAR),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_HOUR),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_MIN),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_SEC),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_MILS),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_DAY),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_MOON),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_YEAR),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_HOUR),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_MIN),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_SEC),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_MILS),UDM_SETPOS32,0,50);

		LocTimeToEdit11(hDlg, IDC_EDIT_CREATE_DATE, IDC_EDIT_CREATE_DATE2);
		LocTimeToEdit11(hDlg, IDC_EDIT_CREATE_DATE_AFTER, IDC_EDIT_CREATE_DATE_AFTER2);
		LocTimeToEdit11(hDlg, IDC_EDIT_CREATE_BETWEEN_DATE, IDC_EDIT_CREATE_BETWEEN_TIME);
		LocTimeToEdit11(hDlg, IDC_EDIT_CREATE_BETWEEN_DATE2, IDC_EDIT_CREATE_BETWEEN_TIME2);
		LocTimeToEdit11(hDlg, IDC_EDIT_LAST_ACCESS_DATE, IDC_EDIT_LAST_ACCESS_DATE2);
		LocTimeToEdit11(hDlg, IDC_EDIT_LAST_ACCESS_DATE_AFTER, IDC_EDIT_LAST_ACCESS_DATE_AFTER2);
		LocTimeToEdit11(hDlg, IDC_EDIT_LAST_ACCESS_DATE_BETWEEN, IDC_EDIT_LAST_ACCESS_TIME_BETWEEN);
		LocTimeToEdit11(hDlg, IDC_EDIT_LAST_ACCESS_DATE_BETWEEN2, IDC_EDIT_LAST_ACCESS_TIME_BETWEEN2);
		LocTimeToEdit11(hDlg, IDC_EDIT_LAST_WRITE_DATE, IDC_EDIT_LAST_WRITE_DATE2);
		LocTimeToEdit11(hDlg, IDC_EDIT_LAST_WRITE_DATE_AFTER, IDC_EDIT_LAST_WRITE_DATE_AFTER2);
		LocTimeToEdit11(hDlg, IDC_EDIT_LAST_WRITE_DATE_BETWEEN, IDC_EDIT_LAST_WRITE_TIME_BETWEEN);
		LocTimeToEdit11(hDlg, IDC_EDIT_LAST_WRITE_DATE_BETWEEN2, IDC_EDIT_LAST_WRITE_TIME_BETWEEN2);
	
		if(lParam)
		{	selV7PthCB.Read(selV7PthCBFName,GetDlgItem(hDlg,IDC_COMBO_SEARCH_PATH),25,MAX_PATH);
			selV7TxtCB.Read(selV7TxtCBFName,GetDlgItem(hDlg,IDC_COMBO_SEARCH_FOR_TEXT),25,MAX_PATH);
			selV7ExclTxt.Read(selV7ExclTxtFName,GetDlgItem(hDlg,IDC_COMBO_SEARCH_NOT_TEXT),25,MAX_PATH);

			MyStringCpy(s,MAX_PATH,panel->GetPath());
			MyStringRemoveLastChar(s,MAX_PATH,'*');
			MyStringCat(s,MAX_PATH,L";");
			SetDlgItemText(hDlg,IDC_COMBO_SEARCH_PATH,s);
			CBToDisk::AddToCB(GetDlgItem(hDlg,IDC_COMBO_SEARCH_PATH),s);
		

			SetDlgItemText(hDlg,IDC_EDIT_FILE_SIZE,L"1");
			if(!selV7NameCB.Read(selV7NameCBFName,
								  GetDlgItem(hDlg,IDC_COMBO_SEARCH_NAME),
								  MAX_SAVE_SELECTION_STR,
								  MAX_SEL_PATH))//fSeachViaF7.FillSearchFilterCB(hDlg,IDC_COMBO_SEARCH_NAME);
				SetDlgItemText(hDlg,IDC_COMBO_SEARCH_NAME,L"*.*;");
		}
		else//Agar confdan chaqirgan bo'lsa:
		{	EnableWindow(GetDlgItem(hDlg,IDC_COMBO_SEARCH_PATH),FALSE);
			EnableWindow(GetDlgItem(hDlg,IDC_BUTTON_ADD_PATH),FALSE);
			EnableWindow(GetDlgItem(hDlg,IDC_BUTTON_ADD_DISK),FALSE);
			SetDlgItemText(hDlg,IDC_COMBO_SEARCH_NAME,item.filtr);
			SetDlgItemText(hDlg,IDC_COMBO_SEARCH_PATH,item.rootPath);
			SendMessage(GetDlgItem(hDlg,IDC_CHECK_TEXT_SEACH),BM_SETCHECK,item.bFindForText?BST_CHECKED:BST_UNCHECKED,0);
			if(item.bFindForText)
			{	SetDlgItemText(hDlg,IDC_COMBO_SEARCH_FOR_TEXT,item.FindForText);
				EnableWindow(GetDlgItem(hDlg,IDC_COMBO_SEARCH_FOR_TEXT),TRUE);
				EnableWindow(GetDlgItem(hDlg,IDC_CHECK_UNICODE_OR_MULTIBYTE),TRUE);
				EnableWindow(GetDlgItem(hDlg,IDC_CHECK_BINARY_OR_CHARACTER),TRUE);
				EnableWindow(GetDlgItem(hDlg,IDC_CHECK_REGISTR_CAPS),TRUE);
				SendMessage(GetDlgItem(hDlg,IDC_CHECK_UNICODE_OR_MULTIBYTE),BM_SETCHECK,item.bFindForText_Unicode?BST_CHECKED:BST_UNCHECKED,0);
				SendMessage(GetDlgItem(hDlg,IDC_CHECK_BINARY_OR_CHARACTER),BM_SETCHECK,item.bFindForText_ASCII?BST_CHECKED:BST_UNCHECKED,0);
				SendMessage(GetDlgItem(hDlg,IDC_CHECK_REGISTR_CAPS),BM_SETCHECK,item.bFindForText_UpperCase?BST_CHECKED:BST_UNCHECKED,0);
			}
			SendMessage(GetDlgItem(hDlg,IDC_CHECK_NO_TEXT_SEACH),BM_SETCHECK,item.bFindForExcldText?BST_CHECKED:BST_UNCHECKED,0);
			if(item.bFindForExcldText)
			{	SetDlgItemText(hDlg,IDC_COMBO_SEARCH_NOT_TEXT,item.FindForExcldText);
				EnableWindow(GetDlgItem(hDlg,IDC_COMBO_SEARCH_NOT_TEXT),TRUE);
				EnableWindow(GetDlgItem(hDlg,IDC_CHECK_UNICODE_OR_MULTIBYTE2),TRUE);
				EnableWindow(GetDlgItem(hDlg,IDC_CHECK_BINARY_OR_CHARACTER2),TRUE);
				EnableWindow(GetDlgItem(hDlg,IDC_CHECK_REGISTR_CAPS2),TRUE);
				SendMessage(GetDlgItem(hDlg,IDC_CHECK_UNICODE_OR_MULTIBYTE2),BM_SETCHECK,item.bFindForExcldText_Unicode?BST_CHECKED:BST_UNCHECKED,0);
				SendMessage(GetDlgItem(hDlg,IDC_CHECK_BINARY_OR_CHARACTER2),BM_SETCHECK,item.bFindForExcldText_ASCII?BST_CHECKED:BST_UNCHECKED,0);
				SendMessage(GetDlgItem(hDlg,IDC_CHECK_REGISTR_CAPS2),BM_SETCHECK,item.bFindForExcldText_UpperCase?BST_CHECKED:BST_UNCHECKED,0);
			}

			SendMessage(GetDlgItem(hDlg,IDC_CHECK_ALTERNATIVE_NAME),BM_SETCHECK,item.bFindForAlterName?BST_CHECKED:BST_UNCHECKED,0);
			if(item.bFindForAlterName)
			{	SetDlgItemText(hDlg,IDC_EDIT_ALTERNATIVE_FILE_NAME,item.altName);
				EnableWindow(GetDlgItem(hDlg,IDC_EDIT_ALTERNATIVE_FILE_NAME),TRUE);
			}
			//wchar_t altNameW[MAX_PATH];

			SendMessage(GetDlgItem(hDlg,IDC_CHECK_CREATE_TIME_BEFORE),BM_SETCHECK,item.bCrTimeBef?BST_CHECKED:BST_UNCHECKED,0);
			if(item.bCrTimeBef)
			{	TimeToEdit1(item.CrTimeBef,hDlg,IDC_EDIT_CREATE_DATE,IDC_EDIT_CREATE_DATE2);
				EnableWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_DATE),TRUE);
				EnableWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_DATE2),TRUE);
			}
			SendMessage(GetDlgItem(hDlg,IDC_CHECK_CREATE_TIME_AFTER),BM_SETCHECK,item.bCrTimeAft?BST_CHECKED:BST_UNCHECKED,0);
			if(item.bCrTimeAft)
			{	TimeToEdit1(item.CrTimeAft,hDlg,IDC_EDIT_CREATE_DATE_AFTER,IDC_EDIT_CREATE_DATE_AFTER2);
				EnableWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_DATE_AFTER),TRUE);
				EnableWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_DATE_AFTER2),TRUE);
			}
			SendMessage(GetDlgItem(hDlg,IDC_CHECK_CREATE_TIME_BETWEEN),BM_SETCHECK,item.bCrTimeBet?BST_CHECKED:BST_UNCHECKED,0);
			if(item.bCrTimeBet)
			{	TimeToEdit1(item.CrTimeBet[0],hDlg,IDC_EDIT_CREATE_BETWEEN_DATE,IDC_EDIT_CREATE_BETWEEN_TIME);
				TimeToEdit1(item.CrTimeBet[1],hDlg,IDC_EDIT_CREATE_BETWEEN_DATE2,IDC_EDIT_CREATE_BETWEEN_TIME2);
				EnableWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_BETWEEN_DATE),TRUE);
				EnableWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_BETWEEN_TIME),TRUE);
				EnableWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_BETWEEN_DATE2),TRUE);
				EnableWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_BETWEEN_TIME2),TRUE);
			}
			SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_ACCESS_TIME_BEFORE),BM_SETCHECK,item.bLstAccTimeBef?BST_CHECKED:BST_UNCHECKED,0);
			if(item.bLstAccTimeBef)
			{	TimeToEdit1(item.LstAccTimeBef,hDlg,IDC_EDIT_LAST_ACCESS_DATE,IDC_EDIT_LAST_ACCESS_DATE2);
				EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE),TRUE);
				EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE2),TRUE);
			}
			SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_ACCESS_TIME_AFTER),BM_SETCHECK,item.bLstAccTimeAft?BST_CHECKED:BST_UNCHECKED,0);
			if(item.bLstAccTimeAft)
			{	TimeToEdit1(item.LstAccTimeBef,hDlg,IDC_EDIT_LAST_ACCESS_DATE_AFTER,IDC_EDIT_LAST_ACCESS_DATE_AFTER2);
				EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_AFTER),TRUE);
				EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_AFTER2),TRUE);
			}
			SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_ACCESS_TIME_BETWEEN),BM_SETCHECK,item.bLastAccTimeBet?BST_CHECKED:BST_UNCHECKED,0);
			if(item.bLastAccTimeBet)
			{	TimeToEdit1(item.LastAccTimeBet[0],hDlg,IDC_EDIT_LAST_ACCESS_DATE_BETWEEN,IDC_EDIT_LAST_ACCESS_TIME_BETWEEN);
				TimeToEdit1(item.LastAccTimeBet[1],hDlg,IDC_EDIT_LAST_ACCESS_DATE_BETWEEN2,IDC_EDIT_LAST_ACCESS_TIME_BETWEEN2);
				EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_BETWEEN),TRUE);
				EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_TIME_BETWEEN),TRUE);
				EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_BETWEEN2),TRUE);
				EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_TIME_BETWEEN2),TRUE);
			}
			SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_WRITE_TIME_BEFORE),BM_SETCHECK,item.bLstWrTimeBef?BST_CHECKED:BST_UNCHECKED,0);
			if(item.bLstWrTimeBef)
			{	TimeToEdit1(item.LstWrTimeBef,hDlg,IDC_EDIT_LAST_WRITE_DATE,IDC_EDIT_LAST_WRITE_DATE2);
				EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE),TRUE);
				EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE2),TRUE);
			}
			SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_WRITE_TIME_AFTER),BM_SETCHECK,item.bLstWrTimeAft?BST_CHECKED:BST_UNCHECKED,0);
			if(item.bLstWrTimeAft)
			{	TimeToEdit1(item.LstWrTimeAft,hDlg,IDC_EDIT_LAST_WRITE_DATE_AFTER,IDC_EDIT_LAST_WRITE_DATE_AFTER2);
				EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_AFTER),TRUE);
				EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_AFTER2),TRUE);
			}
			SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_WRITE_TIME_BETWEEN),BM_SETCHECK,item.bLstWrTimeBet?BST_CHECKED:BST_UNCHECKED,0);
			if(item.bLstWrTimeBet)
			{	TimeToEdit1(item.LstWrTimeBet[0],hDlg,IDC_EDIT_LAST_WRITE_DATE_BETWEEN,IDC_EDIT_LAST_WRITE_TIME_BETWEEN);
				TimeToEdit1(item.LstWrTimeBet[1],hDlg,IDC_EDIT_LAST_WRITE_DATE_BETWEEN2,IDC_EDIT_LAST_WRITE_TIME_BETWEEN2);
				EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_BETWEEN),TRUE);
				EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_TIME_BETWEEN),TRUE);
				EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_BETWEEN2),TRUE);
				EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_TIME_BETWEEN2),TRUE);
			}
			SendMessage(GetDlgItem(hDlg,IDC_CHECK_FILE_SIZE),BM_SETCHECK,item.bFileSz?BST_CHECKED:BST_UNCHECKED,0);
			if(item.bFileSz)
			{	EnableWindow(GetDlgItem(hDlg,IDC_COMBO_FILE_SIZE_EQUATION),TRUE);
				EnableWindow(GetDlgItem(hDlg,IDC_EDIT_FILE_SIZE),TRUE);
				EnableWindow(GetDlgItem(hDlg,IDC_COMBO_FILE_SIZE_QUANTITY),TRUE);
				switch(item.sFileSzEqu[0])
				{	case '<':
						SendMessage(GetDlgItem(hDlg,IDC_COMBO_FILE_SIZE_EQUATION),CB_SETCURSEL,0,0);
						break;
					case '>':
						SendMessage(GetDlgItem(hDlg,IDC_COMBO_FILE_SIZE_EQUATION),CB_SETCURSEL,1,0);
						break;
					case '=':
						SendMessage(GetDlgItem(hDlg,IDC_COMBO_FILE_SIZE_EQUATION),CB_SETCURSEL,2,0);
						break;
				}
				SetDlgItemText(hDlg,IDC_EDIT_FILE_SIZE,item.sFileSz);
				SendMessage(GetDlgItem(hDlg,IDC_COMBO_FILE_SIZE_QUANTITY),CB_SETCURSEL,item.iFileSzQual,0);
			}
			SendMessage(GetDlgItem(hDlg,IDC_CHECK_FILE_ATTRIBUTE),BM_SETCHECK,item.bFileAttr?BST_CHECKED:BST_UNCHECKED,0);
			if(item.bFileAttr)
			{	EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_ARCHIVE),TRUE);
				EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_COMPRESSED),TRUE);
				EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_DEVICE),TRUE);
				EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_DIRECTORY),TRUE);
				EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_ENCRYPTED),TRUE);
				EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_HIDDEN),TRUE);
				EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_NORMAL),TRUE);
				EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_NOT_INDEXED),TRUE);
				EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_OFFLINE),TRUE);
				EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_READ_ONLY),TRUE);
				EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_REPARSE_POINT),TRUE);
				EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_SPARSE_FILE),TRUE);
				EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_SYSTEM),TRUE);
				EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_TEMPORARY),TRUE);
				EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_VIRTUAL),TRUE);
				SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_ARCHIVE),BM_SETCHECK,item.bFileAttArchive?BST_CHECKED:BST_UNCHECKED,0);
				SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_COMPRESSED),BM_SETCHECK,item.bFileAttCompr?BST_CHECKED:BST_UNCHECKED,0);
				SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_DEVICE),BM_SETCHECK,item.bFileAttDevice?BST_CHECKED:BST_UNCHECKED,0);
				SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_DIRECTORY),BM_SETCHECK,item.bFileAttDir?BST_CHECKED:BST_UNCHECKED,0);
				SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_ENCRYPTED),BM_SETCHECK,item.bFileAttEncr?BST_CHECKED:BST_UNCHECKED,0);
				SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_HIDDEN),BM_SETCHECK,item.bFileAttHidden?BST_CHECKED:BST_UNCHECKED,0);
				SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_NORMAL),BM_SETCHECK,item.bFileAttNormal?BST_CHECKED:BST_UNCHECKED,0);
				SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_NOT_INDEXED),BM_SETCHECK,item.bFileAttNotInd?BST_CHECKED:BST_UNCHECKED,0);
				SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_OFFLINE),BM_SETCHECK,item.bFileAttOffl?BST_CHECKED:BST_UNCHECKED,0);
				SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_READ_ONLY),BM_SETCHECK,item.bFileAttReadOnly?BST_CHECKED:BST_UNCHECKED,0);
				SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_REPARSE_POINT),BM_SETCHECK,item.bFileAttRepPt?BST_CHECKED:BST_UNCHECKED,0);
				SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_SPARSE_FILE),BM_SETCHECK,item.bFileAttSparseFile?BST_CHECKED:BST_UNCHECKED,0);
				SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_SYSTEM),BM_SETCHECK,item.bFileAttSys?BST_CHECKED:BST_UNCHECKED,0);
				SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_TEMPORARY),BM_SETCHECK,item.bFileAttTemp?BST_CHECKED:BST_UNCHECKED,0);
				SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_VIRTUAL),BM_SETCHECK,item.bFileAttVirt?BST_CHECKED:BST_UNCHECKED,0);
		}	}
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_SEARCH_NAME),CB_SETEDITSEL,0,MAKELPARAM(0,-1));
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ENUM_SUBDIR),BM_SETCHECK,conf::bEnumSubDir?BST_CHECKED:BST_UNCHECKED,0);

		//COMBOBOXINFO ci; ci.cbSize = sizeof(COMBOBOXINFO);
		//if(SendMessage(GetDlgItem(hDlg,IDC_COMBO_SEARCH_NAME),CB_GETCOMBOBOXINFO,0,(LPARAM)&ci))
		//	SetFocus(ci.hwndItem);
		//PostMessage(hDlg,WM_NEXTDLGCTL,IDC_COMBO_SEARCH_NAME,MAKELONG(0,TRUE));

		iCall = 0;//search.iCall = 0;
		bStop = TRUE;//search.bStop = TRUE;
		bRun = FALSE;//search.bRun = FALSE;
		SendMessage(hDlg,WM_USER+1,0,0);

		/*if(search.LBListBuf)
		{	CreateResultsLB(hDlg);
			search.LoadLBList(hResultsLB);
		}*/
		return TRUE;
	case WM_CTLCOLORSTATIC:
	case WM_CTLCOLORDLG:HDC dc;dc = (HDC)wParam;
		SetTextColor(dc,conf::Dlg.dlgRGBs[6][1]);
		SetBkColor(dc,conf::Dlg.dlgRGBs[6][2]);
		return (INT_PTR)br;
	case WM_CTLCOLOREDIT:dc = (HDC)wParam;
		SetTextColor(dc,conf::Dlg.dlgRGBs[6][1]);
		SetBkColor(dc,conf::Dlg.dlgRGBs[6][2]);
		return (INT_PTR)br;
	case WM_CTLCOLORBTN:dc=(HDC)wParam;
		SetTextColor(dc,conf::Dlg.dlgRGBs[6][4]);
		SetBkColor(dc,conf::Dlg.dlgRGBs[6][5]);
		return (INT_PTR)brHtBk;
	case WM_DRAWITEM://WM_CTLCOLORBTN dagi knopkalar:
		LPDRAWITEMSTRUCT lpdis;lpdis = (LPDRAWITEMSTRUCT)lParam;
		GetWindowText(lpdis->hwndItem,s,64);
		RECT r;UINT uStyle;uStyle = DFCS_BUTTONPUSH;
		r = lpdis->rcItem;
		if(lpdis->itemState & ODS_SELECTED)
		{	uStyle |= DFCS_PUSHED|DFCS_TRANSPARENT;
			r.left+=2;r.top+=2;
		}
		DrawFrameControl(lpdis->hDC, &lpdis->rcItem, DFC_BUTTON, uStyle);
		if(lpdis->itemState & ODS_SELECTED)
			{r.left+=1;r.top+=1;r.bottom-=2;r.right-=3;}
		else
			{r.left+=1;r.top+=2;r.bottom-=3;r.right-=3;}
		FillRect(lpdis->hDC,&r,brHtBk);//DrawText(lpdis->hDC,"                                                  ",50,&rc,DT_SINGLELINE|DT_VCENTER|DT_INTERNAL|DT_LEFT);
		if(lpdis->itemState & ODS_SELECTED)
			{r.left-=1;r.top-=1;r.bottom+=3;r.right+=3;}
		else
			{r.left-=1;r.top-=2;r.bottom+=2;r.right+=3;}
		DrawText(lpdis->hDC,s,MyStringLength(s,64),&r,DT_SINGLELINE|DT_VCENTER|DT_CENTER);
		return TRUE;
	case WM_USER+1://hf obshiy uchun, dinamik o'zgartirish uchun emas:
		if(0==hfRef)
		{	hf = CreateFontIndirect(&conf::Dlg.dlgFnts[6]);
			br = CreateSolidBrush(conf::Dlg.dlgRGBs[6][0]);
			brHtBk = CreateSolidBrush(conf::Dlg.dlgRGBs[6][5]);
		}
		SendMessage(GetDlgItem(hDlg,IDC_TAB_FILE_SEACH),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_STATIC),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_METHOD),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_STATIC1),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_SEARCH_NAME),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_STATIC2),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_BUTTON_ADD_PATH),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_BUTTON_ADD_DISK),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_SEARCH_PATH),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_TEXT_SEACH),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_SEARCH_FOR_TEXT),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_UNICODE_OR_MULTIBYTE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_BINARY_OR_CHARACTER),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_REGISTR_CAPS),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_NO_TEXT_SEACH),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_UNICODE_OR_MULTIBYTE2),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_BINARY_OR_CHARACTER2),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_REGISTR_CAPS2),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDOK),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDCANCEL),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ALTERNATIVE_NAME),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_ALTERNATIVE_FILE_NAME),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_CREATE_TIME_BEFORE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_CREATE_TIME_AFTER),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_CREATE_DATE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_CREATE_DATE2),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_CREATE_DATE_AFTER),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_CREATE_DATE_AFTER2),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_CREATE_TIME_BETWEEN),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_CREATE_BETWEEN_DATE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_CREATE_BETWEEN_TIME),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_CREATE_BETWEEN_DATE2),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_CREATE_BETWEEN_TIME2),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_ACCESS_TIME_BEFORE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_ACCESS_TIME_AFTER),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE2),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_AFTER),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_AFTER2),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_ACCESS_TIME_BETWEEN),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_BETWEEN),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_TIME_BETWEEN),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_BETWEEN2),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_TIME_BETWEEN2),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_WRITE_TIME_BEFORE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_WRITE_TIME_AFTER),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE2),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_AFTER),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_AFTER2),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_WRITE_TIME_BETWEEN),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_BETWEEN),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_TIME_BETWEEN),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_BETWEEN2),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_TIME_BETWEEN2),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_FILE_SIZE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_FILE_SIZE_EQUATION),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_FILE_SIZE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_FILE_SIZE_QUANTITY),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_FILE_ATTRIBUTE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_ARCHIVE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_COMPRESSED),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_DEVICE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_DIRECTORY),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_ENCRYPTED),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_HIDDEN),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_NORMAL),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_NOT_INDEXED),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_OFFLINE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_READ_ONLY),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_REPARSE_POINT),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_SPARSE_FILE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_SYSTEM),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_TEMPORARY),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_VIRTUAL),WM_SETFONT,(WPARAM)hf,TRUE);
		++hfRef;
		return 0;//GWL_USERDATA
	case WM_DESTROY:
		if(--hfRef<1)
		{	DeleteObject(hf);
			DeleteObject(br);
			DeleteObject(brHtBk);
		}
		//search.SaveLBListBuf(hResultsLB);
		//hResultsLB = NULL;
		//hToPanelBTN=NULL;
		width = 0;
		return 0;
	case WM_USER+2://Dinamik o'zgartirish uchun:
		DeleteObject(hf);hfRef=1;
		hf = CreateFontIndirect(&conf::Dlg.dlgFnts[6]);
		SendMessage(GetDlgItem(hDlg,IDC_TAB_FILE_SEACH),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_STATIC),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_METHOD),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_STATIC1),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_SEARCH_NAME),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_STATIC2),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_BUTTON_ADD_PATH),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_BUTTON_ADD_DISK),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_SEARCH_PATH),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_TEXT_SEACH),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_SEARCH_FOR_TEXT),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_UNICODE_OR_MULTIBYTE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_BINARY_OR_CHARACTER),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_REGISTR_CAPS),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_NO_TEXT_SEACH),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_UNICODE_OR_MULTIBYTE2),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_BINARY_OR_CHARACTER2),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_REGISTR_CAPS2),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDOK),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDCANCEL),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ALTERNATIVE_NAME),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_ALTERNATIVE_FILE_NAME),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_CREATE_TIME_BEFORE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_CREATE_TIME_AFTER),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_CREATE_DATE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_CREATE_DATE2),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_CREATE_DATE_AFTER),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_CREATE_DATE_AFTER2),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_CREATE_TIME_BETWEEN),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_CREATE_BETWEEN_DATE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_CREATE_BETWEEN_TIME),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_CREATE_BETWEEN_DATE2),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_CREATE_BETWEEN_TIME2),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_ACCESS_TIME_BEFORE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_ACCESS_TIME_AFTER),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE2),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_AFTER),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_AFTER2),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_ACCESS_TIME_BETWEEN),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_BETWEEN),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_TIME_BETWEEN),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_BETWEEN2),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_TIME_BETWEEN2),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_WRITE_TIME_BEFORE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_WRITE_TIME_AFTER),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE2),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_AFTER),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_AFTER2),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_WRITE_TIME_BETWEEN),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_BETWEEN),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_TIME_BETWEEN),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_BETWEEN2),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_TIME_BETWEEN2),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_FILE_SIZE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_FILE_SIZE_EQUATION),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_FILE_SIZE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_FILE_SIZE_QUANTITY),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_FILE_ATTRIBUTE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_ARCHIVE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_COMPRESSED),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_DEVICE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_DIRECTORY),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_ENCRYPTED),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_HIDDEN),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_NORMAL),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_NOT_INDEXED),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_OFFLINE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_READ_ONLY),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_REPARSE_POINT),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_SPARSE_FILE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_SYSTEM),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_TEMPORARY),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_VIRTUAL),WM_SETFONT,(WPARAM)hf,TRUE);
		return 0;//GWL_USERDATA
	case WM_USER+3://Dinamik o'zgartirish uchun, colorni:
		DeleteObject(br);DeleteObject(brHtBk);hfRef=1;
		br = CreateSolidBrush(conf::Dlg.dlgRGBs[6][0]);
		brHtBk = CreateSolidBrush(conf::Dlg.dlgRGBs[6][5]);
		RedrawWindow(hDlg,NULL,NULL,RDW_INVALIDATE|RDW_ALLCHILDREN);
		return 0;//GWL_USERDATA
	case WM_COMMAND:
		switch(LOWORD(wParam))
		{	case IDOK:
				/*if(!search.bRun)//Start:
				{	LoadString(hInst,IDS_STRINGSW_50,s,MAX_PATH);
					SetDlgItemText(hDlg,IDOK,s);

					if(search.iCall)return FALSE;
					if(GetDlgItemText(hDlg,IDC_COMBO_SEARCH_PATH,s,MAX_PATH))
						CBToDisk::AddToCB(GetDlgItem(hDlg,IDC_COMBO_SEARCH_PATH),s);
					if(GetDlgItemText(hDlg,IDC_COMBO_SEARCH_FOR_TEXT,s,MAX_PATH))
						CBToDisk::AddToCB(GetDlgItem(hDlg,IDC_COMBO_SEARCH_FOR_TEXT),s);
					if(GetDlgItemText(hDlg,IDC_COMBO_SEARCH_NOT_TEXT,s,MAX_PATH))
						CBToDisk::AddToCB(GetDlgItem(hDlg,IDC_COMBO_SEARCH_NOT_TEXT),s);
					if(GetDlgItemText(hDlg,IDC_COMBO_SEARCH_NAME,s,MAX_PATH))
						CBToDisk::AddToCB(GetDlgItem(hDlg,IDC_COMBO_SEARCH_NAME),s);
					selV7PthCB.Save(selV7PthCBFName,GetDlgItem(hDlg,IDC_COMBO_SEARCH_PATH),25);
					selV7TxtCB.Save(selV7TxtCBFName,GetDlgItem(hDlg,IDC_COMBO_SEARCH_FOR_TEXT),25);
					selV7ExclTxt.Save(selV7ExclTxtFName,GetDlgItem(hDlg,IDC_COMBO_SEARCH_NOT_TEXT),25);
					selV7NameCB.Save(selV7NameCBFName,GetDlgItem(hDlg,IDC_COMBO_SEARCH_NAME),25);

					ClearResultsLB();
					CreateResultsLB(hDlg);

					//FILETIME crBef,crAft,crBtwn[2],lastBef,lastAft,lastBtwn[2],
					//lastWrBef,lastWrAft,lastWrBtwn[2];

					search.hDlg = hDlg;
					search.panel = panel;
					SetFocus(GetDlgItem(hDlg,IDOK));
					//SetThreadPriority(GetCurrentThread(), THREAD_MODE_BACKGROUND_BEGIN);
					//search.hThr = CreateThread(NULL,0,
					//			(LPTHREAD_START_ROUTINE)BeginSearch,
					//			 &search,0,
					//			 &search.thrId);//fSeachViaF7.BeginSearch(panel);
					search.bRun = TRUE;
					if(0==panel)//confdan chaqirilgan;
					{	GetDlgItems(search.hDlg);
						EndDialog(hDlg,1);
						return FALSE;//confdan chaqirilgan;
					}
   					BeginSearch();
					search.bRun = FALSE;
					LoadString(hInst,IDS_STRINGSW_3,s,MAX_PATH);
					SetDlgItemText(hDlg,IDOK,s);
					CreateOutptBtns(hDlg);
				}
				else //Stop:*/
				{	bStop = TRUE;//search.bStop = TRUE;
					//LoadString(hInst,IDS_STRINGSW_3,s,MAX_PATH);
					//SetDlgItemText(hDlg,IDOK,s);
				}
				EndDialog(hDlg,1);
				return FALSE;
			case IDCANCEL:
				if(0==panel) return FALSE;//confdan chaqirilgan;
				//int r;r = SendMessage(hResultsLB,LB_GETCOUNT,0,0);
				//if(!iCall)//if(!search.iCall)
					EndDialog(hDlg,0);
				return FALSE;
			case IDC_BUTTON_ADD_DISK:
				/*char *disksStr;disksStr=(char*)DialogBoxParam(hInst,
							MAKEINTRESOURCE(IDD_DIALOG_SELECT_DISKS),
							hDlg,AddDiskDlgProc,1);
				if(disksStr)
				{GetDlgItemText(hDlg,IDC_COMBO_SEARCH_PATH,s,MAX_PATH);
				 if(!strstr(s,disksStr))
				 {MyStringCat(s,MAX_PATH,disksStr);
				  SetDlgItemText(hDlg,IDC_COMBO_SEARCH_PATH,s);
				}}*/
				return TRUE;
			case IDC_BUTTON_ADD_PATH:
				BROWSEINFO bi; 
				bi.hwndOwner = hDlg;
				bi.pszDisplayName = s;
				bi.lpszTitle = L"Search file folder location:";
				bi.ulFlags = BIF_NONEWFOLDERBUTTON|BIF_DONTGOBELOWDOMAIN|BIF_NEWDIALOGSTYLE|
					BIF_NOTRANSLATETARGETS|BIF_RETURNFSANCESTORS;
				bi.lpfn = NULL;
				LPITEMIDLIST pidlRoot;pidlRoot = NULL;
				bi.pidlRoot = pidlRoot;
				LPITEMIDLIST pidlSelected;pidlSelected = SHBrowseForFolder(&bi);
				if(pidlRoot)
					CoTaskMemFree(pidlRoot);
				if(pidlSelected)
				{if(SHGetPathFromIDList(pidlSelected,s))
				 {	MyStringRemoveLastChar(s,MAX_PATH,'\\');
					MyStringCat(s,MAX_PATH+36,L"\\;");
					wchar_t st[MAX_PATH+36];GetDlgItemText(hDlg,IDC_COMBO_SEARCH_PATH,st,MAX_PATH);
					if(!wcsstr(st,s))
					{	MyStringCat(st,MAX_PATH+36,s);
						SetDlgItemText(hDlg,IDC_COMBO_SEARCH_PATH,st);
				  }	}
				  CoTaskMemFree(pidlSelected);
				}
				return TRUE;
			case IDC_CHECK_TEXT_SEACH:
				if(BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_TEXT_SEACH),BM_GETCHECK,0,0))
				{	EnableWindow(GetDlgItem(hDlg,IDC_COMBO_SEARCH_FOR_TEXT),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_UNICODE_OR_MULTIBYTE),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_BINARY_OR_CHARACTER),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_REGISTR_CAPS),TRUE);
				}
				else
				{	EnableWindow(GetDlgItem(hDlg,IDC_COMBO_SEARCH_FOR_TEXT),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_UNICODE_OR_MULTIBYTE),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_BINARY_OR_CHARACTER),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_REGISTR_CAPS),FALSE);
				}
				return (INT_PTR)TRUE;
			case IDC_CHECK_NO_TEXT_SEACH:
				if(BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_NO_TEXT_SEACH),BM_GETCHECK,0,0))
				{	EnableWindow(GetDlgItem(hDlg,IDC_COMBO_SEARCH_NOT_TEXT),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_UNICODE_OR_MULTIBYTE2),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_BINARY_OR_CHARACTER2),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_REGISTR_CAPS2),TRUE);
				}
				else
				{	EnableWindow(GetDlgItem(hDlg,IDC_COMBO_SEARCH_NOT_TEXT),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_UNICODE_OR_MULTIBYTE2),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_BINARY_OR_CHARACTER2),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_REGISTR_CAPS2),FALSE);
				}
				return (INT_PTR)TRUE;
			case IDC_CHECK_UNICODE_OR_MULTIBYTE:
				if(BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_UNICODE_OR_MULTIBYTE),BM_GETCHECK,0,0))
				{	//LoadString(hInst,IDS_STRINGSW_80,s,MAX_PATH);
					SetDlgItemText(hDlg,IDC_CHECK_UNICODE_OR_MULTIBYTE,L"Unicode");
				}
				else
				{	LoadString(hInst,IDS_STRINGSW_80,s,MAX_PATH);
					SetDlgItemText(hDlg,IDC_CHECK_UNICODE_OR_MULTIBYTE,s);
				}
				return (INT_PTR)TRUE;
			case IDC_CHECK_UNICODE_OR_MULTIBYTE2:
				if(BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_UNICODE_OR_MULTIBYTE2),BM_GETCHECK,0,0))
				{	//LoadString(hInst,IDS_STRINGSW_80,s,MAX_PATH);
					SetDlgItemText(hDlg,IDC_CHECK_UNICODE_OR_MULTIBYTE2,L"Unicode");
				}
				else
				{	LoadString(hInst,IDS_STRINGSW_80,s,MAX_PATH);
					SetDlgItemText(hDlg,IDC_CHECK_UNICODE_OR_MULTIBYTE2,s);
				}
				return (INT_PTR)TRUE;
			case IDC_CHECK_BINARY_OR_CHARACTER:
				if(BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_BINARY_OR_CHARACTER),BM_GETCHECK,0,0))
				{	LoadString(hInst,IDS_STRINGSW_81,s,MAX_PATH);
					SetDlgItemText(hDlg,IDC_CHECK_BINARY_OR_CHARACTER,s);
				}
				else
				{	LoadString(hInst,IDS_STRINGSW_81,s,MAX_PATH);
					//SetDlgItemText(hDlg,IDC_CHECK_BINARY_OR_CHARACTER,s);
					SetDlgItemText(hDlg,IDC_CHECK_BINARY_OR_CHARACTER,L"ASCII");
				}
				break;
			case IDC_CHECK_BINARY_OR_CHARACTER2:
				if(BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_BINARY_OR_CHARACTER2),BM_GETCHECK,0,0))
				{	LoadString(hInst,IDS_STRINGSW_81,s,MAX_PATH);
					SetDlgItemText(hDlg,IDC_CHECK_BINARY_OR_CHARACTER2,s);
				}
				else
				{	//LoadString(hInst,IDS_STRINGSW_81,s,MAX_PATH);
					SetDlgItemText(hDlg,IDC_CHECK_BINARY_OR_CHARACTER2,L"ASCII");
				}
				break;
			case IDC_CHECK_ALTERNATIVE_NAME:
				if(BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_ALTERNATIVE_NAME),BM_GETCHECK,0,0))
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_ALTERNATIVE_FILE_NAME),TRUE);
				else
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_ALTERNATIVE_FILE_NAME),FALSE);
				break;
			case IDC_CHECK_CREATE_TIME_BEFORE:
				if(BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_CREATE_TIME_BEFORE),BM_GETCHECK,0,0))
				{	//SendMessage(GetDlgItem(hDlg,IDC_CHECK_CREATE_TIME_AFTER),BM_SETCHECK,BST_UNCHECKED,0);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_DATE),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_DATE2),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_DAY),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_MOONS),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_YEAR),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_HOUR),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_MIN),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_SEC),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_MILS),TRUE);
				}
				else
				{	EnableWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_DATE),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_DATE2),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_DAY),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_MOONS),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_YEAR),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_HOUR),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_MIN),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_SEC),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_MILS),FALSE);
				}
				break;
			case IDC_CHECK_CREATE_TIME_AFTER:
				if(BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_CREATE_TIME_AFTER),BM_GETCHECK,0,0))
				{	//SendMessage(GetDlgItem(hDlg,IDC_CHECK_CREATE_TIME_BEFORE),BM_SETCHECK,BST_UNCHECKED,0);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_DATE_AFTER),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_DATE_AFTER2),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_DAY),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_MOON),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_YEAR),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_HOUR),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_MIN),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_SEC),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_MILS),TRUE);
				}
				else
				{	EnableWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_DATE_AFTER),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_DATE_AFTER2),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_DAY),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_MOON),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_YEAR),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_HOUR),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_MIN),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_SEC),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_MILS),FALSE);
				}
				break;				 
			case IDC_CHECK_CREATE_TIME_BETWEEN:
				if(BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_CREATE_TIME_BETWEEN),BM_GETCHECK,0,0))
				{	EnableWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_BETWEEN_DATE),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_BETWEEN_TIME),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_BETWEEN_DATE2),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_BETWEEN_TIME2),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_DAY),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_MOONS),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_YEAR),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_HOUR),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_MIN),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_SEC),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_MILS),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_DAY),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_MOON),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_YEAR),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_HOUR),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_MIN),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_SEC),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_MILS),TRUE);
				}
				else
				{	EnableWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_BETWEEN_DATE),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_BETWEEN_TIME),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_BETWEEN_DATE2),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_BETWEEN_TIME2),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_DAY),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_MOONS),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_YEAR),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_HOUR),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_MIN),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_SEC),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_MILS),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_DAY),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_MOON),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_YEAR),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_HOUR),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_MIN),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_SEC),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_MILS),FALSE);
				}
				break;
			case IDC_CHECK_LAST_ACCESS_TIME_BETWEEN:
				if(BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_ACCESS_TIME_BETWEEN),BM_GETCHECK,0,0))
				{	EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_BETWEEN),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_TIME_BETWEEN),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_BETWEEN2),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_TIME_BETWEEN2),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_DAY),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_MOON),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_YEAR),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_HOUR),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_MIN),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_SEC),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_MILS),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_DAY),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_MOON),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_YEAR),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_HOUR),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_MIN),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_SEC),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_MILS),TRUE);
				}
				else
				{	EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_BETWEEN),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_TIME_BETWEEN),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_BETWEEN2),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_TIME_BETWEEN2),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_DAY),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_MOON),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_YEAR),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_HOUR),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_MIN),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_SEC),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_MILS),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_DAY),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_MOON),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_YEAR),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_HOUR),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_MIN),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_SEC),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_MILS),FALSE);
				}
				break;
			case IDC_CHECK_LAST_WRITE_TIME_BETWEEN:
				if(BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_WRITE_TIME_BETWEEN),BM_GETCHECK,0,0))
				{	EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_BETWEEN),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_TIME_BETWEEN),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_BETWEEN2),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_TIME_BETWEEN2),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_DAY),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_MOON),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_YEAR),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_HOUR),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_MIN),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_SEC),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_MILS),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_DAY),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_MOON),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_YEAR),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_HOUR),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_MIN),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_SEC),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_MILS),TRUE);
				}
				else
				{	EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_BETWEEN),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_TIME_BETWEEN),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_BETWEEN2),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_TIME_BETWEEN2),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_DAY),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_MOON),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_YEAR),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_HOUR),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_MIN),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_SEC),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_MILS),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_DAY),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_MOON),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_YEAR),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_HOUR),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_MIN),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_SEC),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_MILS),FALSE);
				}
				break;
			case IDC_CHECK_LAST_ACCESS_TIME_BEFORE:
				if(BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_ACCESS_TIME_BEFORE),BM_GETCHECK,0,0))
				{	//SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_ACCESS_TIME_AFTER),BM_SETCHECK,BST_UNCHECKED,0);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE2),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_DAY),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_MOONS),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_YEAR),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_HOUR),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_MIN),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_SEC),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_MILS),TRUE);
				}
				else
				{	EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE2),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_DAY),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_MOONS),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_YEAR),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_HOUR),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_MIN),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_SEC),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_MILS),FALSE);
				}
				break;
			case IDC_CHECK_LAST_ACCESS_TIME_AFTER:
				if(BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_ACCESS_TIME_AFTER),BM_GETCHECK,0,0))
				{	//SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_ACCESS_TIME_BEFORE),BM_SETCHECK,BST_UNCHECKED,0);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_AFTER),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_AFTER2),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_DAY),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_MOON),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_YEAR),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_HOUR),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_MIN),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_SEC),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_MILS),TRUE);
				}
				else
				{	EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_AFTER),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_AFTER2),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_DAY),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_MOON),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_YEAR),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_HOUR),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_MIN),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_SEC),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_MILS),FALSE);
				}
				break;
			case IDC_CHECK_LAST_WRITE_TIME_BEFORE:
				if(BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_WRITE_TIME_BEFORE),BM_GETCHECK,0,0))
				{	//SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_WRITE_TIME_AFTER),BM_SETCHECK,BST_UNCHECKED,0);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE2),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_DAY),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_MOON),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_YEAR),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_HOUR),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_MIN),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_SEC),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_MILS),TRUE);
				}
				else
				{	EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE2),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_DAY),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_MOON),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_YEAR),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_HOUR),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_MIN),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_SEC),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_MILS),FALSE);
				}
				break;
			case IDC_CHECK_LAST_WRITE_TIME_AFTER:
				if(BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_WRITE_TIME_AFTER),BM_GETCHECK,0,0))
				{	//SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_WRITE_TIME_BEFORE),BM_SETCHECK,BST_UNCHECKED,0);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_AFTER),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_AFTER2),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_DAY),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_MOON),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_YEAR),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_HOUR),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_MIN),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_SEC),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_MILS),TRUE);
				}
				else
				{	EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_AFTER),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_AFTER2),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_DAY),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_MOON),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_YEAR),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_HOUR),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_MIN),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_SEC),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_MILS),FALSE);
				}
				break;
			case IDC_CHECK_FILE_SIZE:
				if(BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_FILE_SIZE),BM_GETCHECK,0,0))
				{	EnableWindow(GetDlgItem(hDlg,IDC_COMBO_FILE_SIZE_EQUATION),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_FILE_SIZE),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_FILE_SIZE),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_COMBO_FILE_SIZE_QUANTITY),TRUE);
				}
				else
				{	EnableWindow(GetDlgItem(hDlg,IDC_COMBO_FILE_SIZE_EQUATION),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_FILE_SIZE),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_FILE_SIZE),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_COMBO_FILE_SIZE_QUANTITY),FALSE);
				}
				break;
			case IDC_CHECK_FILE_ATTRIBUTE:
				if(BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_FILE_ATTRIBUTE),BM_GETCHECK,0,0))
				{	EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_ARCHIVE),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_COMPRESSED),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_DEVICE),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_DIRECTORY),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_ENCRYPTED),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_HIDDEN),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_NORMAL),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_NOT_INDEXED),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_OFFLINE),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_READ_ONLY),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_REPARSE_POINT),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_SPARSE_FILE),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_SYSTEM),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_TEMPORARY),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_VIRTUAL),TRUE);
				}
				else
				{	EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_ARCHIVE),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_COMPRESSED),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_DEVICE),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_DIRECTORY),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_ENCRYPTED),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_HIDDEN),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_NORMAL),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_NOT_INDEXED),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_OFFLINE),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_READ_ONLY),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_REPARSE_POINT),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_SPARSE_FILE),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_SYSTEM),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_TEMPORARY),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_VIRTUAL),FALSE);
				}
				break;
			case IDC_CHECK_ENUM_SUBDIR:
				conf::bEnumSubDir=(BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_ENUM_SUBDIR),BM_GETCHECK,0,0))
					? 1 : 0;
				break;
			case IDC_COMBO_METHOD:
				conf::Dlg.iEnumMethod = (int)SendMessage(GetDlgItem(hDlg,IDC_COMBO_METHOD),CB_GETCURSEL,0,0);
				if(conf::Dlg.iEnumMethod<0)conf::Dlg.iEnumMethod=0;
				if(conf::Dlg.iEnumMethod>1)conf::Dlg.iEnumMethod=1;
				break;
			case IDC_EDIT_CREATE_DATE:
			case IDC_EDIT_CREATE_DATE_AFTER:
			case IDC_EDIT_CREATE_BETWEEN_DATE:
			case IDC_EDIT_CREATE_BETWEEN_DATE2:
			case IDC_EDIT_LAST_ACCESS_DATE:
			case IDC_EDIT_LAST_ACCESS_DATE_AFTER:
			case IDC_EDIT_LAST_ACCESS_DATE_BETWEEN:
			case IDC_EDIT_LAST_ACCESS_DATE_BETWEEN2:
			case IDC_EDIT_LAST_WRITE_DATE:
			case IDC_EDIT_LAST_WRITE_DATE_AFTER:
			case IDC_EDIT_LAST_WRITE_DATE_BETWEEN:
			case IDC_EDIT_LAST_WRITE_DATE_BETWEEN2:
				if(EN_KILLFOCUS==HIWORD(wParam))
				{	if(GetWindowText((HWND)lParam,s,MAX_PATH))
					{	//first 2 char before '.' - day of month
						if(s[0] < '0') s[0] = '0';
						if(s[0] > '3') s[0] = '3';
						if(s[1] < (s[0]<'1'?'1':'0')) s[1] = s[0]<'1'?'1':'0';
						if(s[1] > (s[0]<'3'?'9':'1')) s[1] = s[0]<'3'?'9':'1';
						if(s[2] != '.') s[2] = '.';
						//second 2 char after first '.' - month
						if(s[3] < '0') s[3] = '0';
						if(s[3] > '1') s[3] = '1';
						if(s[4] < (s[3]<'1'?'1':'0')) s[4] = s[3]<'1'?'1':'0';
						if(s[4] > (s[3]<'1'?'9':'2')) s[4] = s[3]<'1'?'9':'2';
						if(s[5] != '.') s[5] = '.';
						//last 2 char after second '.' - year
						if(s[6] < '0') s[6] = '0';
						if(s[6] > '9') s[6] = '9';
						if(s[7] < '0') s[7] = '0';
						if(s[7] > '9') s[7] = '9';
						if(s[8] < '0') s[8] = '0';
						if(s[8] > '9') s[8] = '9';
						if(s[9] < '0') s[9] = '0';
						if(s[9] > '9') s[9] = '9';
						s[10] = 0;
						SetWindowText((HWND)lParam,s);
				}	}
				break;
			case IDC_EDIT_CREATE_DATE2:
			case IDC_EDIT_CREATE_DATE_AFTER2:
			case IDC_EDIT_CREATE_BETWEEN_TIME:
			case IDC_EDIT_CREATE_BETWEEN_TIME2:
			case IDC_EDIT_LAST_ACCESS_DATE2:
			case IDC_EDIT_LAST_ACCESS_DATE_AFTER2:
			case IDC_EDIT_LAST_ACCESS_TIME_BETWEEN:
			case IDC_EDIT_LAST_ACCESS_TIME_BETWEEN2:
			case IDC_EDIT_LAST_WRITE_DATE2:
			case IDC_EDIT_LAST_WRITE_DATE_AFTER2:
			case IDC_EDIT_LAST_WRITE_TIME_BETWEEN:
			case IDC_EDIT_LAST_WRITE_TIME_BETWEEN2:
				if(EN_KILLFOCUS==HIWORD(wParam))
				{	if(GetWindowText((HWND)lParam,s,MAX_PATH))
					{	//first 2 char before '.' - hour
						if(s[0] < '0') s[0] = '0';
						if(s[0] > '2') s[0] = '2';
						if(s[1] < '0') s[1] = '0';
						if(s[1] > (s[0]<'2'?'9':'4')) s[1] = s[0]<'2'?'9':'4';
						if(s[2] != '.') s[2] = '.';
						//second 2 char after first '.' - minute
						if(s[3] < '0') s[3] = '0';
						if(s[3] > '6') s[3] = '6';
						if(s[4] < '0') s[4] = '0';
						if(s[4] > (s[3]<'6'?'9':'0')) s[4] = s[3]<'6'?'9':'0';
						if(s[5] != '.') s[5] = '.';
						//third 2 char after second '.' - second
						if(s[6] < '0') s[6] = '0';
						if(s[6] > '6') s[6] = '6';
						if(s[7] < '0') s[7] = '0';
						if(s[7] > (s[6]<'6'?'9':'0')) s[7] = s[6]<'6'?'9':'0';
						if(s[8] != '.') s[8] = '.';
						//last 2 char - millisecond
						if(s[9] < '0') s[9] = '0';
						if(s[9] > '9') s[9] = '9';
						if(s[10] < '0') s[10] = '0';
						if(s[10] > '9') s[10] = '9';
						if(s[11] < '0') s[11] = '0';
						if(s[11] > '9') s[11] = '9';
						s[12] = 0;
						SetWindowText((HWND)lParam,s);
				}	}
				break;
			/*case IDC_BUTTON_VIEW-3://hBrowseBTN
				if(hToPanelBTN)
				{	int sel,ln;if(LB_ERR!=SendMessage(hResultsLB,LB_GETSELITEMS,1,(LPARAM)&sel))
					ln=SendMessage(hResultsLB,LB_GETTEXTLEN,sel,0);
					if(LB_ERR!=ln)
					{TCHAR *buf; buf = (TCHAR*)_malloca((ln+2)*sizeof(TCHAR));
					 if(LB_ERR!=SendMessage(hResultsLB,LB_GETTEXT,sel,(LPARAM)buf))
					 {	EndDialog(hDlg,0);
						if('<'==buf[0])//Directory:
						{	buf[ln-1] = '\\';
							buf[ln] = '*';
							buf[ln+1] = 0;
							//search.panel->ChangePath(&buf[1]);
							search.panel->FreeMem();//search.panel->FreeSelection();
							search.panel->GetEntry()->Reset();
							search.panel->SetPath(&buf[1],MAX_PATH);
							search.panel->GetEntry()->SetPushEntryInStartup(&buf[1]);
							search.panel->FillDirectFolder();
							search.panel->GetEntry()->Push(&buf[1],directFolder,0);
						}
						else //file:
						{	char *p = strrchr(buf,'\\');
							if(p){ *p = '\\'; *(p+1) = '*'; *(p+2) = 0; }
							else {buf[ln] = '\\';buf[ln+1] = '*';buf[ln+2] = 0;}
							//search.panel->ChangePath(&buf[1]);
							search.panel->FreeMem();//search.panel->FreeSelection();
							search.panel->GetEntry()->Reset();
							search.panel->SetPath(buf,MAX_PATH);
							search.panel->GetEntry()->SetPushEntryInStartup(buf);
							search.panel->FillDirectFolder();
							search.panel->GetEntry()->Push(buf,directFolder,0);
					 	}
						search.panel->AdjustHorScrollity();
						search.panel->SetHot(0);
						search.panel->ClrScr();
						search.panel->Render(NULL);
					}
					 _freea(buf);
				 }	}
				break;
			case IDC_BUTTON_VIEW-2://hToPanelBTN
				if(hToPanelBTN)
				{	EndDialog(hDlg,0);
					search.panel->FreeMem();//search.panel->FreeSelection();
					search.panel->GetPath()[0] = 0;
					search.panel->SetPathLn(0);
					search.panel->GetEntry()->Push((char*)hResultsLB,rndPathList,0);
					search.panel->FillRandomPathList();
					search.panel->AdjustHorScrollity();
					search.panel->SetHot(0);
					search.panel->ClrScr();
					search.panel->Render();
				}
				break;
			case IDC_BUTTON_VIEW-1://hEditBTN
				if(hToPanelBTN)
				{	int sel;if(LB_ERR!=SendMessage(hResultsLB,LB_GETSELITEMS,1,(LPARAM)&sel))
					{
				}	}
				break;
			case IDC_BUTTON_VIEW://hViewBTN
				break;*/
		}
		break;
	case WM_NOTIFY:
		NMHDR *lpnmhdr;lpnmhdr = (LPNMHDR)lParam;
		switch(lpnmhdr->idFrom)
		{	case IDC_TAB_FILE_SEACH:
				if(TCN_SELCHANGE == lpnmhdr->code)
				{	int id;
					id = TabCtrl_GetCurSel(GetDlgItem(hDlg,IDC_TAB_FILE_SEACH));
					SetTabPage1(hDlg,id);
				}
				break;
			//case IDC_SPIN_FILE_SIZE:
				//OutputDebugString(" IDC_SPIN_FILE_SIZE");
			//	break;
		}
		break;
	case WM_VSCROLL:
		unsigned __int64 szFile;szFile = 0;
		if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_FILE_SIZE))
		{	if(SB_THUMBPOSITION==LOWORD(wParam) || SB_THUMBTRACK==LOWORD(wParam))
			{	if(HIWORD(wParam)>50)
				{	if(GetDlgItemText(hDlg,IDC_EDIT_FILE_SIZE,s,MAX_PATH))
						szFile = MyAtoU64(s);
					MyU64To(s,MAX_PATH,++szFile);//StringCchPrintf(s,MAX_PATH,"%u",++szFile);
					SetDlgItemText(hDlg,IDC_EDIT_FILE_SIZE,s);
				} else
				{	if(GetDlgItemText(hDlg,IDC_EDIT_FILE_SIZE,s,MAX_PATH))
						szFile = MyAtoU64(s);
					if(szFile>0)szFile--;
					MyU64To(s,MAX_PATH,szFile);
					SetDlgItemText(hDlg,IDC_EDIT_FILE_SIZE,s);
			}	}
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_CRTBEF_DAY))
		{	AlignDayFrSpin1(hDlg,wParam,IDC_EDIT_CREATE_DATE,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_CRTBEF_MOONS))
		{	AlignMoonFrSpin1(hDlg,wParam,IDC_EDIT_CREATE_DATE,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_CRTBEF_YEAR))
		{	AlignYearFrSpin1(hDlg,wParam,IDC_EDIT_CREATE_DATE,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_CRTBEF_HOUR))
		{	AlignHourFrSpin1(hDlg,wParam,IDC_EDIT_CREATE_DATE2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_CRTBEF_MIN))
		{	AlignMinFrSpin1(hDlg,wParam,IDC_EDIT_CREATE_DATE2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_CRTBEF_SEC))
		{	AlignSecFrSpin1(hDlg,wParam,IDC_EDIT_CREATE_DATE2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_CRTBEF_MILS))
		{	AlignMilsFrSpin1(hDlg,wParam,IDC_EDIT_CREATE_DATE2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_CRTBET_DAY))
		{	AlignDayFrSpin1(hDlg,wParam,IDC_EDIT_CREATE_BETWEEN_DATE,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_CRTBET_MOONS))
		{	AlignMoonFrSpin1(hDlg,wParam,IDC_EDIT_CREATE_BETWEEN_DATE,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_CRTBET_YEAR))
		{	AlignYearFrSpin1(hDlg,wParam,IDC_EDIT_CREATE_BETWEEN_DATE,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_CRTBET_HOUR))
		{	AlignHourFrSpin1(hDlg,wParam,IDC_EDIT_CREATE_BETWEEN_TIME,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_CRTBET_MIN))
		{	AlignMinFrSpin1(hDlg,wParam,IDC_EDIT_CREATE_BETWEEN_TIME,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_CRTBET_SEC))
		{	AlignSecFrSpin1(hDlg,wParam,IDC_EDIT_CREATE_BETWEEN_TIME,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_CRTBET_MILS))
		{	AlignMilsFrSpin1(hDlg,wParam,IDC_EDIT_CREATE_BETWEEN_TIME,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_CRBET_DAY))
		{	AlignDayFrSpin1(hDlg,wParam,IDC_EDIT_CREATE_BETWEEN_DATE2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_CRBET_MOON))
		{	AlignMoonFrSpin1(hDlg,wParam,IDC_EDIT_CREATE_BETWEEN_DATE2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_CRBET_YEAR))
		{	AlignYearFrSpin1(hDlg,wParam,IDC_EDIT_CREATE_BETWEEN_DATE2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_CRBET_HOUR))
		{	AlignHourFrSpin1(hDlg,wParam,IDC_EDIT_CREATE_BETWEEN_TIME2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_CRBET_MIN))
		{	AlignMinFrSpin1(hDlg,wParam,IDC_EDIT_CREATE_BETWEEN_TIME2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_CRBET_SEC))
		{	AlignSecFrSpin1(hDlg,wParam,IDC_EDIT_CREATE_BETWEEN_TIME2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_CRBET_MILS))
		{	AlignMilsFrSpin1(hDlg,wParam,IDC_EDIT_CREATE_BETWEEN_TIME2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_CRAFT_DAY))
		{	AlignDayFrSpin1(hDlg,wParam,IDC_EDIT_CREATE_DATE_AFTER,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_CRAFT_MOON))
		{	AlignMoonFrSpin1(hDlg,wParam,IDC_EDIT_CREATE_DATE_AFTER,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_CRAFT_YEAR))
		{	AlignYearFrSpin1(hDlg,wParam,IDC_EDIT_CREATE_DATE_AFTER,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_CRAFT_HOUR))
		{	AlignHourFrSpin1(hDlg,wParam,IDC_EDIT_CREATE_DATE_AFTER2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_CRAFT_MIN))
		{	AlignMinFrSpin1(hDlg,wParam,IDC_EDIT_CREATE_DATE_AFTER2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_CRAFT_SEC))
		{	AlignSecFrSpin1(hDlg,wParam,IDC_EDIT_CREATE_DATE_AFTER2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_CRAFT_MILS))
		{	AlignMilsFrSpin1(hDlg,wParam,IDC_EDIT_CREATE_DATE_AFTER2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSTBEF_DAY))
		{	AlignDayFrSpin1(hDlg,wParam,IDC_EDIT_LAST_ACCESS_DATE,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSTBEF_MOONS))
		{	AlignMoonFrSpin1(hDlg,wParam,IDC_EDIT_LAST_ACCESS_DATE,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSTBEF_YEAR))
		{	AlignYearFrSpin1(hDlg,wParam,IDC_EDIT_LAST_ACCESS_DATE,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSTBEF_HOUR))
		{	AlignHourFrSpin1(hDlg,wParam,IDC_EDIT_LAST_ACCESS_DATE2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSTBEF_MIN))
		{	AlignMinFrSpin1(hDlg,wParam,IDC_EDIT_LAST_ACCESS_DATE2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSTBEF_SEC))
		{	AlignSecFrSpin1(hDlg,wParam,IDC_EDIT_LAST_ACCESS_DATE2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSTBEF_MILS))
		{	AlignMilsFrSpin1(hDlg,wParam,IDC_EDIT_LAST_ACCESS_DATE2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSWTBET_DAY))
		{	AlignDayFrSpin1(hDlg,wParam,IDC_EDIT_LAST_WRITE_DATE_BETWEEN,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSWTBET_MOON))
		{	AlignMoonFrSpin1(hDlg,wParam,IDC_EDIT_LAST_WRITE_DATE_BETWEEN,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSWTBET_YEAR))
		{	AlignYearFrSpin1(hDlg,wParam,IDC_EDIT_LAST_WRITE_DATE_BETWEEN,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSWTBET_HOUR))
		{	AlignHourFrSpin1(hDlg,wParam,IDC_EDIT_LAST_WRITE_TIME_BETWEEN,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSWTBET_MIN))
		{	AlignMinFrSpin1(hDlg,wParam,IDC_EDIT_LAST_WRITE_TIME_BETWEEN,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSWTBET_SEC))
		{	AlignSecFrSpin1(hDlg,wParam,IDC_EDIT_LAST_WRITE_TIME_BETWEEN,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSWTBET_MILS))
		{	AlignMilsFrSpin1(hDlg,wParam,IDC_EDIT_LAST_WRITE_TIME_BETWEEN,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSWRBET_DAY))
		{	AlignDayFrSpin1(hDlg,wParam,IDC_EDIT_LAST_WRITE_DATE_BETWEEN2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSWRBET_MOON))
		{	AlignMoonFrSpin1(hDlg,wParam,IDC_EDIT_LAST_WRITE_DATE_BETWEEN2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSWRBET_YEAR))
		{	AlignYearFrSpin1(hDlg,wParam,IDC_EDIT_LAST_WRITE_DATE_BETWEEN2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSWRBET_HOUR))
		{	AlignHourFrSpin1(hDlg,wParam,IDC_EDIT_LAST_WRITE_TIME_BETWEEN2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSWRBET_MIN))
		{	AlignMinFrSpin1(hDlg,wParam,IDC_EDIT_LAST_WRITE_TIME_BETWEEN2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSWRBET_SEC))
		{	AlignSecFrSpin1(hDlg,wParam,IDC_EDIT_LAST_WRITE_TIME_BETWEEN2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSWRBET_MILS))
		{	AlignMilsFrSpin1(hDlg,wParam,IDC_EDIT_LAST_WRITE_TIME_BETWEEN2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSAFT_DAY))
		{	AlignDayFrSpin1(hDlg,wParam,IDC_EDIT_LAST_ACCESS_DATE_AFTER,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSAFT_MOON))
		{	AlignMoonFrSpin1(hDlg,wParam,IDC_EDIT_LAST_ACCESS_DATE_AFTER,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSAFT_YEAR))
		{	AlignYearFrSpin1(hDlg,wParam,IDC_EDIT_LAST_ACCESS_DATE_AFTER,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSAFT_HOUR))
		{	AlignHourFrSpin1(hDlg,wParam,IDC_EDIT_LAST_ACCESS_DATE_AFTER2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSAFT_MIN))
		{	AlignMinFrSpin1(hDlg,wParam,IDC_EDIT_LAST_ACCESS_DATE_AFTER2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSAFT_SEC))
		{	AlignSecFrSpin1(hDlg,wParam,IDC_EDIT_LAST_ACCESS_DATE_AFTER2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSAFT_MILS))
		{	AlignMilsFrSpin1(hDlg,wParam,IDC_EDIT_LAST_ACCESS_DATE_AFTER2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSTBET_DAY))
		{	AlignDayFrSpin1(hDlg,wParam,IDC_EDIT_LAST_ACCESS_DATE_BETWEEN,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSTBET_MOON))
		{	AlignMoonFrSpin1(hDlg,wParam,IDC_EDIT_LAST_ACCESS_DATE_BETWEEN,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSTBET_YEAR))
		{	AlignYearFrSpin1(hDlg,wParam,IDC_EDIT_LAST_ACCESS_DATE_BETWEEN,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSTBET_HOUR))
		{	AlignHourFrSpin1(hDlg,wParam,IDC_EDIT_LAST_ACCESS_TIME_BETWEEN,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSTBET_MIN))
		{	AlignMinFrSpin1(hDlg,wParam,IDC_EDIT_LAST_ACCESS_TIME_BETWEEN,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSTBET_SEC))
		{	AlignSecFrSpin1(hDlg,wParam,IDC_EDIT_LAST_ACCESS_TIME_BETWEEN,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSTBET_MILS))
		{	AlignMilsFrSpin1(hDlg,wParam,IDC_EDIT_LAST_ACCESS_TIME_BETWEEN,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSABET_DAY))
		{	AlignDayFrSpin1(hDlg,wParam,IDC_EDIT_LAST_ACCESS_DATE_BETWEEN2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSABET_MOON))
		{	AlignMoonFrSpin1(hDlg,wParam,IDC_EDIT_LAST_ACCESS_DATE_BETWEEN2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSABET_YEAR))
		{	AlignYearFrSpin1(hDlg,wParam,IDC_EDIT_LAST_ACCESS_DATE_BETWEEN2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSABET_HOUR))
		{	AlignHourFrSpin1(hDlg,wParam,IDC_EDIT_LAST_ACCESS_TIME_BETWEEN2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSABET_MIN))
		{	AlignMinFrSpin1(hDlg,wParam,IDC_EDIT_LAST_ACCESS_TIME_BETWEEN2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSABET_SEC))
		{	AlignSecFrSpin1(hDlg,wParam,IDC_EDIT_LAST_ACCESS_TIME_BETWEEN2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSABET_MILS))
		{	AlignMilsFrSpin1(hDlg,wParam,IDC_EDIT_LAST_ACCESS_TIME_BETWEEN2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_DAY))
		{	AlignDayFrSpin1(hDlg,wParam,IDC_EDIT_LAST_WRITE_DATE,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_MOON))
		{	AlignMoonFrSpin1(hDlg,wParam,IDC_EDIT_LAST_WRITE_DATE,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_YEAR))
		{	AlignYearFrSpin1(hDlg,wParam,IDC_EDIT_LAST_WRITE_DATE,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_HOUR))
		{	AlignHourFrSpin1(hDlg,wParam,IDC_EDIT_LAST_WRITE_DATE2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_MIN))
		{	AlignMinFrSpin1(hDlg,wParam,IDC_EDIT_LAST_WRITE_DATE2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_SEC))
		{	AlignSecFrSpin1(hDlg,wParam,IDC_EDIT_LAST_WRITE_DATE2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_MILS))
		{	AlignMilsFrSpin1(hDlg,wParam,IDC_EDIT_LAST_WRITE_DATE2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_DAY))
		{	AlignDayFrSpin1(hDlg,wParam,IDC_EDIT_LAST_WRITE_DATE_AFTER,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_MOON))
		{	AlignMoonFrSpin1(hDlg,wParam,IDC_EDIT_LAST_WRITE_DATE_AFTER,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_YEAR))
		{	AlignYearFrSpin1(hDlg,wParam,IDC_EDIT_LAST_WRITE_DATE_AFTER,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_HOUR))
		{	AlignHourFrSpin1(hDlg,wParam,IDC_EDIT_LAST_WRITE_DATE_AFTER2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_MIN))
		{	AlignMinFrSpin1(hDlg,wParam,IDC_EDIT_LAST_WRITE_DATE_AFTER2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_SEC))
		{	AlignSecFrSpin1(hDlg,wParam,IDC_EDIT_LAST_WRITE_DATE_AFTER2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_MILS))
		{	AlignMilsFrSpin1(hDlg,wParam,IDC_EDIT_LAST_WRITE_DATE_AFTER2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		break;
	case WM_CONTEXTMENU:
		/*if(wParam==(WPARAM)hResultsLB)
		{	POINT pt;pt.x = LOWORD(lParam);
			pt.y = HIWORD(lParam);
			ScreenToClient(hResultsLB,&pt);
			int r=SendMessage(hResultsLB,LB_ITEMFROMPOINT,0,MAKELONG(pt.x,pt.y));
			r &= 0xffff;
			r=SendMessage(hResultsLB,LB_GETTEXT,r,(LPARAM)s);
			if(LB_ERR!=r)
			{	//myWMI::TAddtnMenuItems it;
				if(s[0]=='<')
				{	s[r-1]=0;
					//it.pNext = NULL;
					//it.itemStr = s;
					//it.iPan = this-&panel[0];
					//it.iPanItem = id;
					//it.iMsg = IDM_FILE_STREAM;
					myWMI::DoExplorerMenu(hResultsLB,&s[1],&pt,NULL);//&it);
				}
				else
				{
					myWMI::DoExplorerMenu(hResultsLB,s,&pt,NULL);//&it);
		}	}	}*/
		break;
	}
	return (INT_PTR)FALSE;
}

}//end of namespace

//Class CSearchPlgn ****
//Class CSearchPlgn ****
//Class CSearchPlgn ****
//Class CSearchPlgn ****
//Class CSearchPlgn ****
//Class CSearchPlgn ****
//Class CSearchPlgn ****
//Class CSearchPlgn ****
//Class CSearchPlgn ****
//Class CSearchPlgn ****
//Class CSearchPlgn ****
//Class CSearchPlgn ****
//Class CSearchPlgn ****
CSearchPlgn::CSearchPlgn():idNum(0),hm(NULL)
{
}

CSearchPlgn::~CSearchPlgn()
{
}

BOOL CSearchPlgn::LoadPlugin()
{
	if(hm) return FALSE;
	hm = LoadLibrary(pathAndName);
	if(!hm) return FALSE;

	GetPluginType = (fSearchViaF7::GetPluginType_t)GetProcAddress(hm,"GetPluginType");
	QSearchFrList$8 = (fSearchViaF7::QSearchFrList$8_t)GetProcAddress(hm,"QSearchFrList$8");
	ShowSearchDlg$8 = (fSearchViaF7::ShowSearchDlg$8_t)GetProcAddress(hm,"ShowSearchDlg$8");
	SetCallbacks$4xxx = (fSearchViaF7::SetCallbacks$4xxx_t)GetProcAddress(hm,"SetCallbacks$4xxx");
	GetPluginDescription = (fSearchViaF7::GetPluginDescription_t)GetProcAddress(hm,"GetPluginDescription");
	SearchForContainText$12 = (fSearchViaF7::SearchForContainText$12_t)GetProcAddress(hm,"SearchForContainText$12");
	SearchForContainTextW$12 = (fSearchViaF7::SearchForContainTextW$12_t)GetProcAddress(hm,"SearchForContainTextW$12");
	SearchForNotContainText$12 = (fSearchViaF7::SearchForNotContainText$12_t)GetProcAddress(hm,"SearchForNotContainText$12");
	SearchForNotContainTextW$12 = (fSearchViaF7::SearchForNotContainTextW$12_t)GetProcAddress(hm,"SearchForNotContainTextW$12");
	SetId$4 = (fSearchViaF7::SetId$4_t)GetProcAddress(hm,"SetId$4");
	ShowOptionDialog = (fSearchViaF7::ShowOptionDialog_t)GetProcAddress(hm,"ShowOptionDialog");
	GetSrchFltr$8 = (fSearchViaF7::GetSrchFltr$8_t)GetProcAddress(hm,"GetSrchFltr$8");
	SetCallbacks$4xxx(saveOptions,readOptions,getPanelSelectedItemsNum,getPanelItemPathAndName,execF3View);
	SetId$4(idNum);
	return TRUE;
}

VOID CSearchPlgn::FreePlugin()
{
	if(hm)
		FreeLibrary(hm);
	hm = 0;
	GetPluginType = 0;
	QSearchFrList$8 = 0;
	ShowSearchDlg$8 = 0;
	SetCallbacks$4xxx = 0;
	GetPluginDescription = 0;
	SearchForContainText$12 = 0;
	SearchForContainTextW$12 = 0;
	SearchForNotContainText$12 = 0;
	SearchForNotContainTextW$12 = 0;
	SetId$4 = 0;
	ShowOptionDialog = 0;
}

int CSearchPlgn::myOwnPlgnNum=-1;
BOOL CALLBACK CSearchPlgn::readOptions(int plgId,VOID *buf,int bufLen)
{
	if(plgId<0) return FALSE;//|| plgId>fSearchViaF7::numPlugins-1) return FALSE; ni qo'ymaymiz, hali numPlugins 1ta oshmagan bo'lishi mumkin;
DWORD rb;
wchar_t s[MAX_PATH];MyStringCpy(s,MAX_PATH-1,fSearchViaF7::plgns[plgId].pathAndName);
	wchar_t *p = wcsrchr(s,'.');
	if(p) *(p+1) = 0;
	MyStringCat(s,MAX_PATH-1,L"bin");
	HANDLE f = MyFopenViaCrF(s,L"r");
	if(!f) return FALSE;
	if(!ReadFile(f,buf,bufLen,&rb,NULL))
		rb=0;
	CloseHandle(f);
	return (rb!=bufLen)?FALSE:TRUE;
}

BOOL CALLBACK CSearchPlgn::saveOptions(int plgId,VOID *buf,int bufLen)
{
	if(plgId<0 || plgId>fSearchViaF7::numPlugins-1) return FALSE;
DWORD rb;
wchar_t s[MAX_PATH];MyStringCpy(s,MAX_PATH-1,fSearchViaF7::plgns[plgId].pathAndName);
	wchar_t *p = wcsrchr(s,'.');
	if(p) *(p+1) = 0;
	MyStringCat(s,MAX_PATH-1,L"bin");
	HANDLE f = MyFopenViaCrF(s,L"w");
	if(!f) return FALSE;
	if(!WriteFile(f,buf,bufLen,&rb,NULL))
		rb=0;
	CloseHandle(f);
	return (rb!=bufLen)?FALSE:TRUE;
}

int CALLBACK CSearchPlgn::getPanelSelectedItemsNum()
{
	return panel[iPanel].GetTotSelects();
}

wchar_t* CALLBACK CSearchPlgn::getPanelItemPathAndName(int iItem)
{int iSel=panel[iPanel].GetSelectedItemNum(iItem);
	return panel[iPanel].GetFullPathAndName(iSel);
}

VOID CALLBACK CSearchPlgn::execF3View(wchar_t *pthAndName)
{
	viewFileAssoc::Execute(panel[iPanel].GetHWND(),pthAndName,0);
}