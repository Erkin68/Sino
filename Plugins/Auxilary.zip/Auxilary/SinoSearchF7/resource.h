//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by sinsch32.rc
//
// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#endif
#endif
