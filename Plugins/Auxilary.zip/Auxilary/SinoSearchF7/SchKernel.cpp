//#include "Winternl.h"
#include "SchKernel.h"
#include <stdio.h>
#include <strsafe.h>
#include <malloc.h>
#include "SinSchF7.h"
#include "FindStrWthFltr.h"
#include "..\..\..\Operations\MyShell\MyShell.h"


extern "C"
{


NTSTATUS (WINAPI *pRtlInitUnicodeString)(PUNICODE_STRING, PCWSTR);
NTSTATUS (WINAPI *pZwCreateFile)(PHANDLE, ACCESS_MASK, POBJECT_ATTRIBUTES,PIO_STATUS_BLOCK,PLARGE_INTEGER,ULONG,ULONG,ULONG,ULONG,PVOID,ULONG);
NTSTATUS (WINAPI *pRtlInitAnsiString)(PANSI_STRING,PCSZ);
NTSTATUS (WINAPI *pRtlAnsiStringToUnicodeString)(PCUNICODE_STRING,PANSI_STRING,BOOLEAN);
NTSTATUS (WINAPI *pZwQueryDirectoryFile)(HANDLE,HANDLE,PIO_APC_ROUTINE,PVOID,PIO_STATUS_BLOCK,PVOID,ULONG,FILE_INFORMATION_CLASS,BOOLEAN,PUNICODE_STRING,BOOLEAN);
NTSTATUS (WINAPI *pRtlUnicodeStringToAnsiString)(PANSI_STRING,PCUNICODE_STRING,BOOLEAN);
NTSTATUS (WINAPI *pZwClose)(HANDLE);
NTSTATUS (NTAPI  *pNtCreateFile)(OUT PHANDLE,IN ACCESS_MASK,IN POBJECT_ATTRIBUTES, OUT PIO_STATUS_BLOCK,
								IN PLARGE_INTEGER, IN ULONG, IN ULONG, IN ULONG, IN ULONG, 
								IN PVOID EaBuffer OPTIONAL, IN ULONG EaLength);



typedef struct TNSDirList{ wchar_t s[MAX_PATH]; }NSDirList;
int NSDirListCnt = 0;
int NSDirListMaxSz = 0;
NSDirList* pdirList = NULL;//

VOID LoadNTFuncs()
{
HMODULE hModule = LoadLibrary(L"Ntdll.dll");
    pRtlInitUnicodeString = (NTSTATUS (WINAPI*)(PUNICODE_STRING, PCWSTR))GetProcAddress(hModule, "RtlInitUnicodeString");
	pZwCreateFile = (NTSTATUS(WINAPI*)(PHANDLE,ACCESS_MASK,POBJECT_ATTRIBUTES,PIO_STATUS_BLOCK,PLARGE_INTEGER,ULONG,ULONG,ULONG,ULONG,PVOID,ULONG))GetProcAddress(hModule,"ZwCreateFile");
    //pZwCreateEvent = (NTSTATUS (WINAPI*)(PHANDLE, ACCESS_MASK,POBJECT_ATTRIBUTES,EVENT_TYPE,BOOLEAN))GetProcAddress(hModule,"ZwCreateEvent");
    pZwQueryDirectoryFile = (NTSTATUS(WINAPI*)(HANDLE,HANDLE,PIO_APC_ROUTINE,PVOID, PIO_STATUS_BLOCK,PVOID,ULONG,FILE_INFORMATION_CLASS, BOOLEAN, PUNICODE_STRING, BOOLEAN))GetProcAddress(hModule,"ZwQueryDirectoryFile");
    //pZwWaitForSingleobject = (NTSTATUS (WINAPI*)(HANDLE,BOOLEAN,PLARGE_INTEGER))GetProcAddress(hModule,"ZwWaitForSingleObject");
    pRtlUnicodeStringToAnsiString = (NTSTATUS(WINAPI*)(PANSI_STRING,PCUNICODE_STRING,BOOLEAN))GetProcAddress(hModule,"RtlUnicodeStringToAnsiString");
    pRtlAnsiStringToUnicodeString = (NTSTATUS(WINAPI*)(PCUNICODE_STRING, PANSI_STRING,BOOLEAN))GetProcAddress(hModule,"RtlAnsiStringToUnicodeString");
	pRtlInitAnsiString = (NTSTATUS(WINAPI*)(PANSI_STRING,PCSZ))GetProcAddress(hModule,"RtlInitAnsiString");
    pZwClose = (NTSTATUS(WINAPI*)(HANDLE))GetProcAddress(hModule,"ZwClose");
	pNtCreateFile = (NTSTATUS(WINAPI*)(PHANDLE,ACCESS_MASK,POBJECT_ATTRIBUTES,PIO_STATUS_BLOCK,PLARGE_INTEGER,ULONG,ULONG,ULONG,ULONG,PVOID,ULONG))
		GetProcAddress(hModule, "NtCreateFile");

	if((!pRtlInitUnicodeString) || (!pZwCreateFile) || (!pZwQueryDirectoryFile) ||
		//(!pZwWaitForSingleobject) || 
		(!pRtlUnicodeStringToAnsiString) || (!pZwClose))
	{	pRtlInitUnicodeString = NULL;
		pZwCreateFile = NULL;
		//pZwCreateEvent = NULL;
		pZwQueryDirectoryFile = NULL;
		//pZwWaitForSingleobject = NULL;
		pRtlUnicodeStringToAnsiString = NULL;
		pRtlAnsiStringToUnicodeString = NULL;
		pRtlInitAnsiString = NULL;
		pZwClose = NULL;
}	}

}//end of extern "C"

VOID AddPathToEnumList(wchar_t* newPath)
{
	if(NSDirListCnt > NSDirListMaxSz-1)
	{	if(NSDirListMaxSz)
			pdirList = (NSDirList*)realloc(pdirList, sizeof(TNSDirList)*(NSDirListMaxSz+30));
		else
			pdirList = (NSDirList*)malloc(sizeof(TNSDirList)*(NSDirListMaxSz+30));
		if(pdirList)
			NSDirListMaxSz += 30;
	}
	MyStringCpy(pdirList[NSDirListCnt++].s,MAX_PATH,newPath);
}

wchar_t* GetFromPathEnumList()
{
	if((--NSDirListCnt)==-1)
	{	NSDirListCnt=0;
		return NULL;
	}
	if(NSDirListCnt<30)
	if(NSDirListMaxSz>30)
	{	pdirList = (NSDirList*)realloc(pdirList, sizeof(TNSDirList)*30);
		NSDirListMaxSz = 30;
	}
	return pdirList[NSDirListCnt].s;
}

BOOL SearchForContainTextPW(Search* search,wchar_t *rootPath,wchar_t *sub,PFILE_BOTH_DIR_INFORMATION pf)
{
//	char subA[MAX_PATH];
//	int lnSub=WideCharToMultiByte(AreFileApisANSI()?CP_ACP:CP_OEMCP,0,sub,-1,subA,MAX_PATH,NULL,NULL);
//	if(!lnSub)return FALSE;
//	else --lnSub;
	int lnSub = MyStringLength(sub,MAX_PATH);

	if(item.bFindForText_ASCII)
	{	for(int i=0; i<lnSub; i++)
		{	if(!IsBin(sub[i]))
			{	MessageBox(search->hDlg,L"Please,use only digit symbols without space.",L"Binary filtr string error:",MB_OK);
				search->bStop=TRUE;
				return FALSE;
		}	}
		if(lnSub%2)
		{	MessageBox(search->hDlg,L"Please,input pair symbols without space.",L"Binary filtr string length error:",MB_OK);
			search->bStop=TRUE;
			return FALSE;
		}
		lnSub /= 2;
	}

	HANDLE h = CreateFile(rootPath,GENERIC_READ,
						  FILE_SHARE_READ,
						  NULL,
						  OPEN_EXISTING,
						  pf->FileAttributes,
						  NULL);
	if(INVALID_HANDLE_VALUE==h)
	{	/*IO_STATUS_BLOCK Iosb;OBJECT_ATTRIBUTES fileAttributes;wchar_t pathW[MAX_PATH];
		MultiByteToWideChar(AreFileApisANSI()?CP_ACP:CP_OEMCP,MB_PRECOMPOSED,rootPath,MAX_PATH,pathW,MAX_PATH);
		UNICODE_STRING uniPath;
		pRtlInitUnicodeString(&uniPath, pathW);
		InitializeObjectAttributes(&fileAttributes, &uniPath, OBJ_CASE_INSENSITIVE, 0, 0);
		if(STATUS_SUCCESS!=pNtCreateFile(&h,GENERIC_READ,
						  &fileAttributes,
						  &Iosb,
						  0,
						  FILE_ATTRIBUTE_NORMAL,
						  FILE_SHARE_READ,
						  FILE_OPEN_IF,
						  6,//FILE_NON_DIRECTORY_FILE,
						  0,
						  0))
		  return FALSE;*/
		h = CreateFile(rootPath,GENERIC_READ,
						  FILE_SHARE_READ|FILE_SHARE_WRITE,
						  NULL,
						  OPEN_EXISTING,
						  FILE_ATTRIBUTE_NORMAL,
						  NULL);
	}
	if(INVALID_HANDLE_VALUE==h) return FALSE;

	//char *buf = (char*)_malloca(32768);
	//if(!buf) return FALSE;
	char buf[32768];
//static __declspec(align(32)) char buf[4096];

	int nr = 0, rb = 1, dumLn = lnSub-1;
	while(rb>0)
	{	if(nr)
		{	if(!ReadFile(h,buf+dumLn,32768-dumLn,(DWORD*)&rb,NULL))
				break;
		} else
		{	if(!ReadFile(h,buf,32768,(DWORD*)&rb,NULL))
				break;
		} char *pbuf = buf;
		if(rb>0)
		{	while(pbuf<buf+rb-dumLn)
			{	BOOL r; if(item.bFindForText_ASCII)//binary
				{	r = (NULL!=MyStrCmpBinNA(buf,(char*)sub,nr?rb:rb-dumLn,lnSub*sizeof(wchar_t)));
					pbuf += rb-dumLn;
				}
				else//ASCII:
				{	if(item.bFindForText_UpperCase)r=MyStrCmpNotRelUpRegNA(pbuf++,(char*)sub,lnSub*sizeof(wchar_t));
					else
					{	r=(NULL!=MyStrCmpNNA(buf,(char*)sub,nr?rb:rb-dumLn,lnSub*sizeof(wchar_t)));
						pbuf += rb-dumLn;
				}	}
				if(r)
				{	CloseHandle(h);
					//_freea(buf);
					return TRUE;
			}	}
			//Qolgan dumini boshiga ko'chiramiz:
			if(rb) {memcpy(buf, buf + rb - dumLn, dumLn); ++nr;}
			else nr = 0;
	}	}

	CloseHandle(h);
	//pNtClose(h);
	//_freea(buf);
	return FALSE;
}

#define FILE_OPEN_IF 0x00000003
BOOL SearchForContainTextP(Search *search,wchar_t *rootPath,wchar_t *sub,PFILE_BOTH_DIR_INFORMATION pf)
{
char subA[MAX_PATH];
	int lnSub=WideCharToMultiByte(AreFileApisANSI()?CP_ACP:CP_OEMCP,0,sub,-1,subA,MAX_PATH,NULL,NULL);
	//int lnSub = MyStringLength(sub,MAX_PATH);
	if(!lnSub)return FALSE;
	else --lnSub;

	if(item.bFindForText_ASCII)
	{	for(int i=0; i<lnSub; i++)
		{	if(!IsBin(sub[i]))
			{	MessageBox(search->hDlg,L"Please,use only digit symbols without space.",L"Binary filtr string error:",MB_OK);
				search->bStop=TRUE;
				return FALSE;
		}	}
		if(lnSub%2)
		{	MessageBox(search->hDlg,L"Please,input pair symbols without space.",L"Binary filtr string length error:",MB_OK);
			search->bStop=TRUE;
			return FALSE;
		}
		lnSub /= 2;
	}

	HANDLE h = CreateFile(rootPath,GENERIC_READ,
						  FILE_SHARE_READ,
						  NULL,
						  OPEN_EXISTING,
						  pf->FileAttributes,
						  NULL);
	if(INVALID_HANDLE_VALUE==h)
	{	/*IO_STATUS_BLOCK Iosb;OBJECT_ATTRIBUTES fileAttributes;wchar_t pathW[MAX_PATH];
		MultiByteToWideChar(AreFileApisANSI()?CP_ACP:CP_OEMCP,MB_PRECOMPOSED,rootPath,MAX_PATH,pathW,MAX_PATH);
		UNICODE_STRING uniPath;
		pRtlInitUnicodeString(&uniPath, pathW);
		InitializeObjectAttributes(&fileAttributes, &uniPath, OBJ_CASE_INSENSITIVE, 0, 0);
		if(STATUS_SUCCESS!=pNtCreateFile(&h,GENERIC_READ,
						  &fileAttributes,
						  &Iosb,
						  0,
						  FILE_ATTRIBUTE_NORMAL,
						  FILE_SHARE_READ,
						  FILE_OPEN_IF,
						  6,//FILE_NON_DIRECTORY_FILE,
						  0,
						  0))
		  return FALSE;*/
		h = CreateFile(rootPath,GENERIC_READ,
						  FILE_SHARE_READ|FILE_SHARE_WRITE,
						  NULL,
						  OPEN_EXISTING,
						  FILE_ATTRIBUTE_NORMAL,
						  NULL);
	}
	if(INVALID_HANDLE_VALUE==h) return FALSE;

	//char *buf = (char*)_malloca(32768);
	//if(!buf) return FALSE;
	char buf[32768];
//static __declspec(align(32)) char buf[4096];

	int nr = 0, rb = 1, dumLn = lnSub-1;
	while(rb>0)
	{	if(nr)
		{	if(!ReadFile(h,buf+dumLn,32768-dumLn,(DWORD*)&rb,NULL))
				break;
		} else
		{	if(!ReadFile(h,buf,32768,(DWORD*)&rb,NULL))
				break;
		} char *pbuf = buf;
		if(rb>0)
		{	while(pbuf<buf+rb-dumLn)
			{	BOOL r; if(item.bFindForText_ASCII)//binary
				{	r = (NULL!=MyStrCmpBinNA(buf,subA,nr?rb:rb-dumLn,lnSub));
					pbuf += rb-dumLn;
				}
				else//ASCII:
				{	if(item.bFindForText_UpperCase)r=MyStrCmpNotRelUpRegNA(pbuf++,subA,lnSub);
					else
					{	r=(NULL!=MyStrCmpNNA(buf,subA,nr?rb:rb-dumLn,lnSub));
						pbuf += rb-dumLn;
				}	}
				if(r)
				{	CloseHandle(h);
					//_freea(buf);
					return TRUE;
			}	}
			//Qolgan dumini boshiga ko'chiramiz:
			if(rb) {memcpy(buf, buf + rb - dumLn, dumLn); ++nr;}
			else nr = 0;
	}	}

	CloseHandle(h);
	//pNtClose(h);
	//_freea(buf);
	return FALSE;
}

BOOL SearchForNotContainText(Search *search,wchar_t *rootPath,wchar_t *sub,PFILE_BOTH_DIR_INFORMATION pf)
{
	int lnSub = MyStringLength(sub,MAX_PATH);
	if(!lnSub)return FALSE;

	if(item.bFindForExcldText_ASCII)
	{	for(int i=0; i<lnSub; i++)
		{	if(sub[i]<'0' || sub[i]>'9')
			{	MessageBox(search->hDlg,L"Please,use only digit symbols without space.",L"Binary filtr string error:",MB_OK);
				search->bStop=TRUE;
				return FALSE;
		}	}
		if(lnSub%2)
		{	MessageBox(search->hDlg,L"Please,input pair symbols without space.",L"Binary filtr string length error:",MB_OK);
			search->bStop=TRUE;
			return FALSE;
		}
		lnSub /= 2;
	}

	HANDLE h = CreateFile(rootPath,GENERIC_READ,
						  FILE_SHARE_READ,
						  NULL,
						  OPEN_EXISTING,
						  pf->FileAttributes,
						  NULL);
	if(INVALID_HANDLE_VALUE==h)
		h = CreateFile(rootPath,GENERIC_READ,
						  FILE_SHARE_READ|FILE_SHARE_WRITE,
						  NULL,
						  OPEN_EXISTING,
						  pf->FileAttributes,
						  NULL);
	if(INVALID_HANDLE_VALUE==h) return FALSE;

	wchar_t *buf = (wchar_t*)_malloca(2*4096);
	if(!buf) return FALSE;

	int nr = 4096, rb = 1, dum = 0; wchar_t *pbuf = buf;
	while(rb)
	{	if(!ReadFile(h,pbuf,nr,(DWORD*)&rb,NULL))break;
		wchar_t *pbufCmp = buf;
		while(pbufCmp<buf+dum+rb-lnSub+1)//for(int i=0; i<rb-lnSub+1; i++)//if(rb >= lnSub) ning o'zi edi;
		{	BOOL r; if(item.bFindForExcldText_ASCII)
			{	r = (NULL!=MyStrCmpBinNW(pbufCmp,sub,(int)(buf+dum+rb-lnSub+1-pbufCmp),lnSub));
				pbufCmp += buf+dum+rb-lnSub+1-pbufCmp;
			}
			else
			{	if(item.bFindForExcldText_UpperCase)r=MyStrCmpNotRelUpRegNW(pbufCmp++,sub,lnSub);
				else r=(NULL!=MyStrCmpNW(pbufCmp++,sub,lnSub));
			}
			if(r)
			{	CloseHandle(h);
				_freea(buf);
				return FALSE;
		}	}
		//Qolgan dumini boshiga ko'chiramiz:
		int ddum = 0;
		while(pbufCmp<buf+dum+rb)//for(int k=rb-lnSub+1; k<rb; k++)
			buf[ddum++] = *pbufCmp++;
		dum = ddum;
		pbuf = buf + dum;
		nr = 4096 - dum;
	}

	CloseHandle(h);
	_freea(buf);
	return TRUE;
}

BOOL SearchForNotContainTextW(wchar_t *rootPath,wchar_t *sub,PFILE_BOTH_DIR_INFORMATION pf)
{
	int lnSub = MyStringLength((wchar_t*)sub,MAX_PATH);
	if(!lnSub)return FALSE;

	/*if(item.bFindForExcldText_ASCII) unicodedda bin mumkin emas;
	{	for(int i=0; i<lnSub; i++)
		{	if(sub[i]<'0' || sub[i]>'9')
			{	MessageBox(search.hDlg,"Please,use only digit symbols without space.","Binary filtr string error:",MB_OK);
				search.bStop=TRUE;
				return FALSE;
		}	}
		if(lnSub%2)
		{	MessageBox(search.hDlg,"Please,input pair symbols without space.","Binary filtr string length error:",MB_OK);
			search.bStop=TRUE;
			return FALSE;
		}
		lnSub /= 2;
	}*/

	HANDLE h = CreateFile(rootPath,GENERIC_READ,
						  FILE_SHARE_READ,
						  NULL,
						  OPEN_EXISTING,
						  pf->FileAttributes,
						  NULL);
	if(INVALID_HANDLE_VALUE==h)
		h = CreateFile(rootPath,GENERIC_READ,
						  FILE_SHARE_READ|FILE_SHARE_WRITE,
						  NULL,
						  OPEN_EXISTING,
						  pf->FileAttributes,
						  NULL);
	if(INVALID_HANDLE_VALUE==h) return FALSE;

	wchar_t *buf = (wchar_t*)_malloca(2*4096);
	if(!buf) return FALSE;
	wchar_t *wbuf = (wchar_t*)_malloca(2*4096);
	if(!wbuf) return FALSE;

	int nr = 4096, rb = 1, dum = 0; wchar_t *pwbuf = wbuf;
	while(rb)
	{	if(!ReadFile(h,buf,nr,(DWORD*)&rb,NULL))break;
		if(!MultiByteToWideChar(AreFileApisANSI()?CP_ACP:CP_OEMCP,MB_PRECOMPOSED,(char*)buf,rb,pwbuf,rb)) break;
		wchar_t *pwbufCmp = wbuf;
		while(pwbufCmp<wbuf+dum+rb-lnSub+1)//for(int i=0; i<rb-lnSub+1; i++)//if(rb >= lnSub) ning o'zi edi;
		{	BOOL r;//if(item.bFindForExcldText_ASCII)
			//	r = MyStrCmpBinN(pwbufCmp++,(wchar_t*)sub,(wchar_t*)(buf+dum+rb-lnSub+1)-pwbufCmp,lnSub);
			//else
			{	if(item.bFindForExcldText_UpperCase)r=MyStrCmpNotRelUpRegNW(pwbufCmp++,(wchar_t*)sub,lnSub);
				else r=(NULL!=MyStrCmpNW(pwbufCmp++,sub,lnSub));
			}
			if(r)
			{	CloseHandle(h);
				_freea(buf);
				_freea(wbuf);
				return FALSE;
		}	}
		//Qolgan dumini boshiga ko'chiramiz:
		int ddum = 0;
		while(pwbufCmp<wbuf+dum+rb)//for(int k=rb-lnSub+1; k<rb; k++)
			wbuf[ddum++] = *pwbufCmp++;
		dum = ddum;
		pwbuf = wbuf + dum;
		nr = 4096 - dum;
	}

	CloseHandle(h);
	_freea(buf);
	_freea(wbuf);
	return TRUE;
}

//Qo'shimcha parametrlar asosida qidirish:
//Qo'shimcha parametrlar asosida qidirish:
BOOL CheckOtherSearchConditionsDirectFolder(Search *search,wchar_t* rootPath,PFILE_BOTH_DIR_INFORMATION pf, int type)
{
DWORD bCndtns = 0x00000000, bCndtnsMustbe = 0x00000000;

	if(0==type)//file
	{//1.1-Page, Filtr va RootPath -->> BeginSearch da;
	 //2.1-Page, Find for text:
	 if(item.bFindForText)
	 {if(item.FindForTextLn)
	  {bCndtnsMustbe |= 1;
	   if(item.bFindForText_Unicode)
	   {	FindStrWthFltr fs((wchar_t*)item.FindForText);
			for(int s=0; s<fs.GetNumStrs(); s++)
			{	wchar_t *sub=fs.GetSubstr(s);
				if(SearchForContainTextPW(search,rootPath,sub,pf))
				{	bCndtns |= 1;//[0] = TRUE;
		 			goto ToNotContainText;
		}	}	}
	    else
	    {	FindStrWthFltr fs(item.FindForText);
			for(int s=0; s<fs.GetNumStrs(); s++)
			{	wchar_t *sub=fs.GetSubstr(s);
				if(SearchForContainTextP(search,rootPath,sub,pf))
				{	bCndtns |= 1;//[0] = TRUE;
		 			goto ToNotContainText;
	 }	}	}	}
	 //3.1-Page, Find for do not contain text:
ToNotContainText:
	 if(item.bFindForExcldText)
	 {if(item.FindForExcldTextLn)
	  {bCndtnsMustbe |= 2;
	   if(item.bFindForText_Unicode)
	   {	FindStrWthFltr fs((wchar_t*)item.FindForExcldText);
			for(int s=0; s<fs.GetNumStrs(); s++)
			{	wchar_t *sub=fs.GetSubstr(s);
				if(SearchForNotContainTextW(rootPath,(wchar_t*)sub,pf))
				{	bCndtns |= 2;//[0] = TRUE;
		 			goto ToNotContainText;
		}	}	}
	    else
	    {	FindStrWthFltr fs(item.FindForExcldText);
			for(int s=0; s<fs.GetNumStrs(); s++)
			{	wchar_t *sub=fs.GetSubstr(s);
				if(SearchForNotContainText(search,rootPath,sub,pf))
				{	bCndtns |= 2;//[0] = TRUE;
		 			goto ToNotContainText;
	  }} }	}	}
	  //bCndtns[1] = FALSE;
	 }

	 if(item.bFileSz)
	 {if(item.sFileSzEqu[0])
	  { if(item.sFileSz[0])
		{	bCndtnsMustbe |= 4;
	  		__int64 sz = (__int64)MyAtoU64(item.sFileSz);
			for(int i=0; i<item.iFileSzQual; i++)
				sz = sz << 10;
			if('>'==item.sFileSzEqu[0])
			{	if(sz < pf->EndOfFile/*AllocationSize*/.QuadPart)
					bCndtns |= 4;
				//bCndtns[2] = (sz < fsz);
			}
			else if('<'==item.sFileSzEqu[0])
			{	if(sz > pf->EndOfFile/*AllocationSize*/.QuadPart)
					bCndtns |= 4;
				//bCndtns[2] = (sz > fsz);
			}
			else //if('='==item.sFileSzEqu[0])
			{	if(sz == pf->EndOfFile/*AllocationSize*/.QuadPart)
					bCndtns |= 4;
				//bCndtns[2] = (sz == fsz);
	}}}	}	}
	else//1==type -> folder
	{//1.1-Page, Filtr va RootPath -->> BeginSearch da;
	 //2.1-Page, Find for text:
	 //if(BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_TEXT_SEACH),BM_GETCHECK,0,0))
	 if(item.bFindForText)
		 return FALSE;
	 //3.1-Page, Find for do not contain text:
	 if(item.bFindForExcldText)
		 return FALSE;
	 //4.2-Page, Find for alternative name:
	 if(item.bFindForAlterName)
		 return FALSE;
	 if(item.bFileSz)
		 return FALSE;
	}

	//4.2-Page, Find for alternative name:
//FindAlternName:
	if(item.bFindForAlterName)
	{if(item.altName[0])
	 {	bCndtnsMustbe |= 8;
		if(0==wcscmp(pf->ShortName,item.altName))
			bCndtns |= 8;
	}}

	//5.2-Page, Find for creation time before:
	if(item.bCrTimeBef)
	{	bCndtnsMustbe |= 16;
		if(-1!=CmpFILETIMEsL(&item.CrTimeBef,&pf->CreationTime))
			bCndtns |= 16;
	}

	//6.2-Page, Find for creation time after:
	if(item.bCrTimeAft)
	{	bCndtnsMustbe |= 32;
		if(1!=CmpFILETIMEsL(&item.CrTimeAft,&pf->CreationTime))
			bCndtns |= 32;
	}

	//7.2-Page, Find for creation time between:
	if(item.bCrTimeBet)
	{	bCndtnsMustbe |= 64;
		if(1==CmpFILETIMEsBetweenL(&item.CrTimeBet[0],&item.CrTimeBet[1],&pf->CreationTime))
			bCndtns |= 64;
	}

	//8.2-Page, Find for last access time before:
	if(item.bLstAccTimeBef)
	{	bCndtnsMustbe |= 128;
		if(-1!=CmpFILETIMEsL(&item.LstAccTimeBef,&pf->CreationTime))
			bCndtns |= 128;
	}

	//9.2-Page, Find last access time after:
	if(item.bLstAccTimeAft)
	{	bCndtnsMustbe |= 256;
		if(1!=CmpFILETIMEsL(&item.LstAccTimeAft,&pf->LastAccessTime))
			bCndtns |= 256;
	}

	//10.2-Page, Find for last access time between:
	if(item.bLastAccTimeBet)
	{	bCndtnsMustbe |= 512;
		if(1==CmpFILETIMEsBetweenL(&item.LastAccTimeBet[0],&item.LastAccTimeBet[1],&pf->LastAccessTime))
			bCndtns |= 512;
	}

	//11.2-Page, Find for last write time before:
	if(item.bLstWrTimeBef)
	{	bCndtnsMustbe |= 1024;
		if(-1!=CmpFILETIMEsL(&item.LstWrTimeBef,&pf->LastWriteTime))
			bCndtns |= 1024;
	}

	//12.2-Page, Find last write time after:
	if(item.bLstWrTimeAft)
	{	bCndtnsMustbe |= 2048;
		if(1!=CmpFILETIMEsL(&item.LstWrTimeAft,&pf->LastWriteTime))
			bCndtns |= 2048;
	}

	//13.2-Page, Find for last write time between:
	if(item.bLstWrTimeBet)
	{	bCndtnsMustbe |= 4096;
		if(1==CmpFILETIMEsBetweenL(&item.LstWrTimeBet[0],&item.LstWrTimeBet[1],&pf->LastWriteTime))
			bCndtns |= 4096;
	}

	//14.2-Page, Find for file attribute:
	if(item.bFileAttr)
	{	if(item.bFileAttArchive)
		{	bCndtnsMustbe |= 8192;
			if(item.bFileAttArchiveEx)
			{	if((FILE_ATTRIBUTE_ARCHIVE & pf->FileAttributes) == 0)
					bCndtns |= 8192;
			}
			else
			{	if((FILE_ATTRIBUTE_ARCHIVE & pf->FileAttributes) != 0)
					bCndtns |= 8192;
		}	}
		if(item.bFileAttCompr)
		{	bCndtnsMustbe |= 16384;
			if(item.bFileAttComprEx)
			{	if((FILE_ATTRIBUTE_COMPRESSED & pf->FileAttributes) == 0)
					bCndtns |= 16384;
			}
			else
			{	if((FILE_ATTRIBUTE_COMPRESSED & pf->FileAttributes) != 0)
					bCndtns |= 16384;
		}	}
		if(item.bFileAttDevice)
		{	bCndtnsMustbe |= 32768;
			if(item.bFileAttDeviceEx)
			{	if((FILE_ATTRIBUTE_DEVICE & pf->FileAttributes) == 0)
					bCndtns |= 32768;
			}
			else
			{	if((FILE_ATTRIBUTE_DEVICE & pf->FileAttributes) != 0)
					bCndtns |= 32768;
			}
		}
		if(item.bFileAttDir)
		{	bCndtnsMustbe |= 65536;
			if(item.bFileAttDirEx)
			{	if((FILE_ATTRIBUTE_DIRECTORY & pf->FileAttributes) == 0)
					bCndtns |= 65536;
			}
			else
			{	if((FILE_ATTRIBUTE_DIRECTORY & pf->FileAttributes) != 0)
					bCndtns |= 65536;
		}	}
		if(item.bFileAttEncr)
		{	bCndtnsMustbe |= 132072;
			if(item.bFileAttEncrEx)
			{	if((FILE_ATTRIBUTE_ENCRYPTED & pf->FileAttributes) == 0)
					bCndtns |= 132072;
			}
			else
			{	if((FILE_ATTRIBUTE_ENCRYPTED & pf->FileAttributes) != 0)
					bCndtns |= 132072;
		}	}
		if(item.bFileAttHidden)
		{	bCndtnsMustbe |= 262144;
			if(item.bFileAttHiddenEx)
			{	if((FILE_ATTRIBUTE_HIDDEN & pf->FileAttributes) == 0)
					bCndtnsMustbe |= 262144;
			}
			else
			{	if((FILE_ATTRIBUTE_HIDDEN & pf->FileAttributes) != 0)
					bCndtnsMustbe |= 262144;
		}	}
		if(item.bFileAttNormal)
		{	bCndtnsMustbe |= 524288;
			if(item.bFileAttNormalEx)
			{	if((FILE_ATTRIBUTE_NORMAL & pf->FileAttributes) == 0)
					bCndtns |= 524288;
			}
			else
			{	if((FILE_ATTRIBUTE_NORMAL & pf->FileAttributes) != 0)
					bCndtns |= 524288;
		}	}
		if(item.bFileAttNotInd)
		{	bCndtnsMustbe |= 1048576;
			if(item.bFileAttNotIndEx)
			{	if((FILE_ATTRIBUTE_NOT_CONTENT_INDEXED & pf->FileAttributes) == 0)
					bCndtns |= 1048576;
			}
			else
			{	if((FILE_ATTRIBUTE_NOT_CONTENT_INDEXED & pf->FileAttributes) != 0)
					bCndtns |= 1048576;
		}	}
		if(item.bFileAttOffl)
		{	bCndtnsMustbe |= 2097152;
			if(item.bFileAttOfflEx)
			{	if((FILE_ATTRIBUTE_OFFLINE & pf->FileAttributes) == 0)
					bCndtns |= 2097152;
			}
			else
			{	if((FILE_ATTRIBUTE_OFFLINE & pf->FileAttributes) != 0)
					bCndtns |= 2097152;
		}	}
		if(item.bFileAttReadOnly)
		{	bCndtnsMustbe |= 4194304;
			if(item.bFileAttReadOnlyEx)
			{	if((FILE_ATTRIBUTE_READONLY & pf->FileAttributes) == 0)
					bCndtns |= 4194304;
			}
			else
			{	if((FILE_ATTRIBUTE_READONLY & pf->FileAttributes) != 0)
					bCndtns |= 4194304;
		}	}
		if(item.bFileAttRepPt)
		{	bCndtnsMustbe |= 8388608;
			if(item.bFileAttRepPtEx)
			{	if((FILE_ATTRIBUTE_REPARSE_POINT & pf->FileAttributes) == 0)
					bCndtns |= 8388608;
			}
			else
			{	if((FILE_ATTRIBUTE_REPARSE_POINT & pf->FileAttributes) != 0)
					bCndtns |= 8388608;
		}	}
		if(item.bFileAttSparseFile)
		{	bCndtnsMustbe |= 16777216;
			if(item.bFileAttSparseFileEx)
			{	if((FILE_ATTRIBUTE_SPARSE_FILE & pf->FileAttributes) == 0)
					bCndtns |= 16777216;
			}
			else
			{	if((FILE_ATTRIBUTE_SPARSE_FILE & pf->FileAttributes) != 0)
					bCndtns |= 16777216;
		}	}
		if(item.bFileAttSys)
		{	bCndtnsMustbe |= 33554432;
			if(item.bFileAttSysEx)
			{	if((FILE_ATTRIBUTE_SYSTEM & pf->FileAttributes) == 0)
					bCndtns |= 33554432;
			}
			else
			{	if((FILE_ATTRIBUTE_SYSTEM & pf->FileAttributes) != 0)
					bCndtns |= 33554432;
		}	}
		if(item.bFileAttTemp)
		{	bCndtnsMustbe |= 67108864;
			if(item.bFileAttTempEx)
			{	if((FILE_ATTRIBUTE_TEMPORARY & pf->FileAttributes) == 0)
					bCndtns |= 67108864;
			}
			else
			{	if((FILE_ATTRIBUTE_TEMPORARY & pf->FileAttributes) != 0)
					bCndtns |= 67108864;
		}	}
		if(item.bFileAttVirt)
		{	bCndtnsMustbe |= 134217728;
			if(item.bFileAttVirtEx)
			{	if((FILE_ATTRIBUTE_VIRTUAL & pf->FileAttributes) == 0)
					bCndtns |= 134217728;
			}
			else
			{	if((FILE_ATTRIBUTE_VIRTUAL & pf->FileAttributes) != 0)
					bCndtns |= 134217728;
	}	}	}

	//Hamma usloviyalarni tekshirib chiqdik, endi qaytamiz:
	return (bCndtnsMustbe^bCndtns ? FALSE : TRUE);
}

bool AddToDlgCheckCond(Search *search,wchar_t *pth,int attr,PFILE_BOTH_DIR_INFORMATION di,FindStrWthFltr *fs,wchar_t* pOnlyName)
{
	bool r=fs->CheckNameAndExt(pth,pOnlyName);
	if(r)
	{	if(file==attr)
		{	if(!CheckOtherSearchConditionsDirectFolder(search,pth,di,0))
				return false;
			SendMessageW(search->hResultsLB,LB_ADDSTRING,0,(LPARAM)pth);
			//SendMessage(hResultsLB,WM_PAINT,0,0);
			++search->iFoundFiles;
		} else if(item.filtr[0]!=0 && (!item.bFindForText) && (!item.bFindForExcldText))//folder selStrLen
		{	if(!CheckOtherSearchConditionsDirectFolder(search,pth,di,0))
				return false;
			wchar_t fullName[MAX_PATH+36] = L"<";
			int l=1+MyStringCpy(&fullName[1],MAX_PATH,pth);
			fullName[l++]='>';//MyStringCat(fullName,MAX_PATH+36,">");
			fullName[l]=0;
			SendMessageW(search->hResultsLB,LB_ADDSTRING,0,(LPARAM)fullName);
			//SendMessage(hResultsLB,WM_PAINT,0,0);
			++search->iFoundFolders;
	}	}
	else
	{	//Agar hech narsa belgilamagan bo'lsayam dopoln.parametrlar bo'yicha poisk qilsun;
		if(0==item.filtr[0])//if((!selStrLen) || (strstr(item.filtr,"*.*")))
		if(!item.bFindForText)
		if(!item.bFindForExcldText)
		if(!item.bFileSz)
		if(!item.bFindForAlterName)
		if(!item.bCrTimeBef)
		if(!item.bCrTimeAft)
		if(!item.bCrTimeBet)
		if(!item.bLstAccTimeBef)
		if(!item.bLstAccTimeAft)
		if(!item.bLastAccTimeBet)
		if(!item.bLstWrTimeBef)
		if(!item.bLstWrTimeAft)
		if(!item.bLstWrTimeBet)
		if(!item.bFileAttr)
		{	//Add to info edit:
			if(file==attr)
			{	SendMessageW(search->hResultsLB,LB_ADDSTRING,0,(LPARAM)pth);
				//SendMessage(hResultsLB,WM_PAINT,0,0);
				++search->iFoundFiles;
			} else//folder
			{	wchar_t fullName[MAX_PATH+36] = L"<";
				int l = 1+MyStringCpy(&fullName[1],MAX_PATH,pth);
				fullName[l++]='>';//MyStringCat(fullName,MAX_PATH+36,">");
				fullName[l]=0;
				SendMessageW(search->hResultsLB,LB_ADDSTRING,0,(LPARAM)fullName);
				//SendMessage(hResultsLB,WM_PAINT,0,0);
				++search->iFoundFolders;
			}
			r = true;
	}	}
	return r;
}

void EnumDirToDlgWithFiltr(Search *search,wchar_t* pth,FindStrWthFltr *fs,bool bEnumSubDir)
{
UNICODE_STRING RootDirectoryName;
//ANSI_STRING as;
OBJECT_ATTRIBUTES RootDirectoryAttributes;
NTSTATUS ntStatus = STATUS_SUCCESS;
HANDLE RootDirectoryHandle;
IO_STATUS_BLOCK Iosb;
//HANDLE Event;
PUCHAR Buffer[65536];
WCHAR  szBuffer[MAX_PATH];
int	   szBufferLn;
PFILE_BOTH_DIR_INFORMATION DirInformation;

    StringCchPrintf(szBuffer,sizeof(szBuffer),L"\\??\\%s",pth);
	MyStringRemoveLastChar(szBuffer,MAX_PATH,'*');
	ntStatus = pRtlInitUnicodeString(&RootDirectoryName,szBuffer);
    if (!NT_SUCCESS(ntStatus))
        return;// ntStatus;

    InitializeObjectAttributes(&RootDirectoryAttributes, &RootDirectoryName, OBJ_CASE_INSENSITIVE, 0, 0);

    ntStatus = pZwCreateFile(&RootDirectoryHandle,
        GENERIC_READ|SYNCHRONIZE,
        &RootDirectoryAttributes,
        &Iosb,
        0,
        FILE_ATTRIBUTE_DIRECTORY,
        FILE_SHARE_READ,// | FILE_SHARE_WRITE | FILE_SHARE_DELETE,
        FILE_OPEN,
        FILE_DIRECTORY_FILE|FILE_SYNCHRONOUS_IO_NONALERT,
        0, 0);
 
    if (!NT_SUCCESS(ntStatus))
	 ntStatus = pZwCreateFile(&RootDirectoryHandle,
        GENERIC_READ|SYNCHRONIZE,
        &RootDirectoryAttributes,
        &Iosb,
        0,
        FILE_ATTRIBUTE_DIRECTORY,
        FILE_SHARE_READ | FILE_SHARE_WRITE,// | FILE_SHARE_DELETE,
        FILE_OPEN,
        FILE_DIRECTORY_FILE|FILE_SYNCHRONOUS_IO_NONALERT,
        0, 0);
 
    if (!NT_SUCCESS(ntStatus))
        return;// ntStatus;
    
Loop:
	ntStatus = pZwQueryDirectoryFile(RootDirectoryHandle,
   //    Event, 0, 0,
		NULL,NULL,NULL,
        &Iosb,
        Buffer,
        sizeof(Buffer),
        FileBothDirectoryInformation,
        FALSE,
        NULL,
		FALSE);
    //    FALSE) == STATUS_PENDING)
    //{
    //    ntStatus = ((pZwWaitForSingleobject)(Event, TRUE, 0));
    //}
    if (!NT_SUCCESS(ntStatus))
        goto End;
	if(STATUS_NO_MORE_FILES==Iosb.Status)
		goto End;

	//szBuffer yuqoridagi kodda kosvenno ishlatiladi, shu sabab shu yerdan
	szBufferLn = MyStringLength(szBuffer,MAX_PATH);
	if('\\'!=szBuffer[szBufferLn-1])
	if(':'!=szBuffer[szBufferLn-2])
	{	szBuffer[szBufferLn++]='\\';//MyStringCat(szBuffer,MAX_PATH,"\\");
		szBuffer[szBufferLn]=0;//++szBufferLn;		
	}

	static int c=0;
    DirInformation = (PFILE_BOTH_DIR_INFORMATION) Buffer;
    while (1)
    {	WCHAR tmp = DirInformation -> FileName[DirInformation -> FileNameLength/sizeof(WCHAR)];
		DirInformation -> FileName[DirInformation -> FileNameLength/sizeof(WCHAR)] = 0;
		MyStringCpy(&szBuffer[szBufferLn],MAX_PATH-szBufferLn,&DirInformation -> FileName[0]);//MyStringCat(szBuffer,MAX_PATH,as.Buffer);
		if(FILE_ATTRIBUTE_DIRECTORY & DirInformation->FileAttributes)
		{	if(IsCrntOrPrntDirAttrbW(DirInformation -> FileName))//as.Buffer))
			{	AddToDlgCheckCond(search,&szBuffer[4],folder,DirInformation,fs,DirInformation -> FileName);//as.Buffer
				if(bEnumSubDir)
					AddPathToEnumList(&szBuffer[4]);//as.Buffer
				//Add to info edit:
				SetWindowText(search->hInfoEdit,&szBuffer[3]);//as.Buffer
				SendMessage(search->hInfoEdit,WM_PAINT,0,0);
		}	}
		else
		{	AddToDlgCheckCond(search,&szBuffer[4],file,DirInformation,fs,DirInformation -> FileName);//as.Buffer
		}
		DirInformation -> FileName[DirInformation -> FileNameLength/sizeof(WCHAR)] = tmp;
		szBuffer[szBufferLn] = 0;//pth, ya'ni rootni qaytib joyiga qo'yamiz:

		static int k=0;
		if(k++==150)
		{	MSG msg;if( PeekMessage( &msg, NULL, 0U, 0U, PM_REMOVE ) )
				DispatchMessage ( &msg );
			k=0;
		}
		if(search->bStop)break;

        if (0 == DirInformation -> NextEntryOffset)
            break;
        else if((PUCHAR*)DirInformation > Buffer+65536)
			break;
        else
            DirInformation = (PFILE_BOTH_DIR_INFORMATION) (((PUCHAR)DirInformation) + DirInformation -> NextEntryOffset);
    }
	if(Iosb.Information>0)
		goto Loop;
End:
    pZwClose(RootDirectoryHandle);
    return;// ntStatus;
}
	
void EnumToDlgWithFiltr(Search *search,wchar_t* rootPath,FindStrWthFltr *fs,bool bEnumSubDir)
{
//prepare:
	if(NSDirListCnt)NSDirListCnt = 0;
	AddPathToEnumList(rootPath);
	wchar_t* pth;
	while(NULL!=(pth = GetFromPathEnumList()))
	{	EnumDirToDlgWithFiltr(search,pth,fs,bEnumSubDir);
}	}