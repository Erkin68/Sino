#include "SinSchF7.h"
#include "commctrl.h"
#include "SchKernel.h"
#include "SchCBToDisk.h"
#include "shlobj.h"
#include "strsafe.h"
#include "resource.h"
#include <malloc.h>
#include "FindStrWthFltr.h"



HWND	hResultsLB=NULL,hInfoEdit=NULL,hToPanelBTN=NULL,hViewBTN=NULL,hEditBTN=NULL,hBrowseBTN=NULL;
//HDC	hInfoEditDC;
//RECT	hInfoEditRC;
int		plgId=0;
int		width,height;
int     minWidth=580,minHeight=486,minHeightAftCrLB=638;
Search	search;
SearchItem item;
char	initPath[MAX_PATH];
SearchConfig schConf;

BOOL BeginSearch();
VOID FindSelectsItems(char*,HWND,FindStrWithFltr*);


extern "C"
{
__declspec(dllexport) LPVOID ShowSearchFrPathDlg$8(HWND prnt, char *path)
{
	MyStringCpy(initPath,MAX_PATH-1,path);
	if(2==DialogBox(plgnDllInst,MAKEINTRESOURCE(IDD_DIALOG_SEACH_VIA_F7),
					prnt,FindFileDlgProc))
		return search.LBListBuf;
	//else:
	return 0;
}

__declspec(dllexport) LPVOID QSearchFrList$8(char *filtr,char *list)
{
	FindStrWthFltr fs(filtr);
	char *pl=list;
	int *ires=(int*)list;//Shu bufferning o'zini ishlatamiz:
	int n=0;
	while(*pl)
	{	bool r=fs.CheckNameAndExt(pl);
		int l = MyStringLength(pl,MAX_PATH);
		pl += l+1;
		if(r)
		{	*ires = n;
			++ires;
		}
		++n;
	}
	*ires = -1;//kones;
	return n?list:NULL;
}

__declspec(dllexport) const char* GetPluginDescription()
{
	return "Sino search-plugin version 1.1";

}
__declspec(dllexport) const int GetPluginType()
{
	return 100;//��������������� ������ ������; ��������������� �� 100-200;
}
__declspec(dllexport) void SetId$4(int id)
{
	plgId = id;
	readOptions(id,&schConf,sizeof(schConf));
}

//addItemToPanelList_t addItemToPanelList;
saveOptions_t saveOptions;
readOptions_t readOptions;
__declspec(dllexport) VOID SetCallbacks$4xxx(LPVOID frstCallback,...)
{
va_list args;
	va_start(args, frstCallback);//1
	saveOptions = (saveOptions_t)frstCallback;
	readOptions = (readOptions_t)va_arg(args, int);//2
	//addItemToPanelList = (addItemToPanelList_t)va_arg(args, int);//3
va_end (args);
	//readOptions(&schConf,sizeof(schConf)); SetId ga ko'chdi;
}

void saveOptCpp()
{
	saveOptions(plgId,&schConf,sizeof(schConf));
}

}//end of "C"


TSearch::TSearch():LBListBuf(NULL)
{
}

TSearch::~TSearch()
{
	if(LBListBuf) free(LBListBuf);
	LBListBuf=NULL;
}

VOID TSearch::LoadLBList(HWND hLB)
{
	//1.Calc the size:
	char *pBuf = LBListBuf;
	int *cnt = (int*)pBuf;
	pBuf += sizeof(int);
	for(int i=0; i<(*cnt); i++)
	{	if(LB_ERR==SendMessage(hLB,(UINT)LB_ADDSTRING,0,(LPARAM)pBuf))break;
		pBuf += lstrlen(pBuf)+1;
}	}

VOID TSearch::SaveLBListBuf(HWND hLB)
{
	//1.Calc the size:
	int sz=sizeof(int);
	int iLBCnt=SendMessage(hLB,(UINT)LB_GETCOUNT,0,0);
	if(LB_ERR==iLBCnt) return;
	for(int i=0; i<iLBCnt; i++)
		sz += 1+SendMessage(hLB,(UINT)LB_GETTEXTLEN,i,0);
	sz += 2;//for double null termination;
	//2.Allocateing buffer:
	if(LBListBuf)LBListBuf=(char*)realloc(LBListBuf,sz);
	else LBListBuf = (char*)malloc(sz);
	//3.Fill memory:
	char *pBuf = (char*)LBListBuf;
	*((int*)(pBuf))=iLBCnt;
	pBuf+=sizeof(int);
	for(int i=0; i<iLBCnt; i++)
	{	int r = SendMessage(hLB,(UINT)LB_GETTEXT,i,(LPARAM)pBuf);
		if(LB_ERR==r) break;
		pBuf += r+1;
		if(pBuf>=LBListBuf+sz)break;
	}
	*pBuf++ = 0;
	*pBuf = 0;
}

INT_PTR CALLBACK FindFileDlgProc(HWND hDlg,UINT message,WPARAM wParam,LPARAM lParam)
{	//static int i=0;
	//char ss[32];sprintf(ss,"\n %d ",i++);
	//OutputDebugString(ss);
	//OutputDebugString(GetWinNotifyText(message));
	//sprintf(ss," %x %x",wParam,lParam);
	//OutputDebugString(ss);

static HFONT hf=0;
static int hfRef=0;//obshiy hf, dinamik uchun emas:
static HBRUSH br=0;
//static LPVOID panel;
static HBRUSH brHtBk=0;
char s[MAX_PATH];

	//UNREFERENCED_PARAMETER(lParam);
	switch(message)
	{
	case WM_SIZING:RECT *rc;
		rc = (RECT*)lParam;
		if(rc->right-rc->left < minWidth)
			rc->right = rc->left + minWidth;
		if(hResultsLB)
		{	if(rc->bottom-rc->top < minHeightAftCrLB)
				rc->bottom = rc->top + minHeightAftCrLB;
		} else
		{	if(rc->bottom-rc->top < minHeight)
				rc->bottom = rc->top + minHeight;
			else if(rc->bottom-rc->top > minHeight)
				rc->bottom = rc->top + minHeight;
		}
		return 0;
	case WM_SIZE:
		ResizeChilds(hDlg, LOWORD(lParam), HIWORD(lParam));
		return 0;
	/*case WM_SYSCOMMAND:
		if(SC_CLOSE==wParam)
		{	EndDialog(hDlg,0);
			return 1;
		}
		else if(SC_MAXIMIZE==wParam)
		{	static BOOL bMAximize = FALSE;
			bMAximize = !bMAximize;
			ResizeDlg(hDlg,bMAximize?1:2);
			return 1;
		}
		return 0;*/
	case WM_INITDIALOG:RECT rc1;int left,top;
		//panel = (LPVOID)lParam;
		GetWindowRect(hDlg, &rc1);
		width = rc1.right - rc1.left;		
		left = (GetSystemMetrics(SM_CXFULLSCREEN) - width)/2;
		height = search.LBListBuf?(rc1.bottom - rc1.top):minHeight;
		top = (GetSystemMetrics(SM_CYFULLSCREEN) - height)/2;
		MoveWindow(hDlg, left, top+20, width, height, TRUE);

		//Load language strings:
		SetWindowText(hDlg,strngs[0]);
		SetDlgItemText(hDlg,IDC_STATIC1,strngs[1]);
		SetDlgItemText(hDlg,IDC_BUTTON_ADD_DISK,strngs[2]);
		SetDlgItemText(hDlg,IDC_STATIC2,strngs[3]);
		SetDlgItemText(hDlg,IDC_BUTTON_ADD_PATH,strngs[4]);
		SetDlgItemText(hDlg,IDC_CHECK_TEXT_SEACH,strngs[5]);
		SetDlgItemText(hDlg,IDC_CHECK_UNICODE_OR_MULTIBYTE,strngs[6]);
		//strngs[42]
		SetDlgItemText(hDlg,IDC_CHECK_BINARY_OR_CHARACTER,"ASCII");//s);
		SetDlgItemText(hDlg,IDC_CHECK_REGISTR_CAPS,strngs[7]);
		SetDlgItemText(hDlg,IDC_CHECK_NO_TEXT_SEACH,strngs[8]);
		SetDlgItemText(hDlg,IDC_CHECK_UNICODE_OR_MULTIBYTE2,strngs[6]);
		//strngs[42]
		SetDlgItemText(hDlg,IDC_CHECK_BINARY_OR_CHARACTER2,"ASCII");//s);
		SetDlgItemText(hDlg,IDC_CHECK_REGISTR_CAPS2,strngs[7]);
		SetDlgItemText(hDlg,IDOK,strngs[9]);//lParam?strngs[9]:strngs[10]);
		//if(lParam)
			SetDlgItemText(hDlg,IDCANCEL,strngs[11]);
		//else ShowWindow(GetDlgItem(hDlg,IDCANCEL),SW_HIDE);
		SetDlgItemText(hDlg,IDC_CHECK_ALTERNATIVE_NAME,strngs[12]);
		SetDlgItemText(hDlg,IDC_CHECK_CREATE_TIME_BEFORE,strngs[13]);
		SetDlgItemText(hDlg,IDC_CHECK_CREATE_TIME_AFTER,strngs[14]);
		SetDlgItemText(hDlg,IDC_CHECK_CREATE_TIME_BETWEEN,strngs[15]);
		SetDlgItemText(hDlg,IDC_CHECK_LAST_ACCESS_TIME_BEFORE,strngs[16]);
		SetDlgItemText(hDlg,IDC_CHECK_LAST_ACCESS_TIME_AFTER,strngs[17]);
		SetDlgItemText(hDlg,IDC_CHECK_LAST_ACCESS_TIME_BETWEEN,strngs[18]);
		SetDlgItemText(hDlg,IDC_CHECK_LAST_WRITE_TIME_BEFORE,strngs[19]);
		SetDlgItemText(hDlg,IDC_CHECK_LAST_WRITE_TIME_AFTER ,strngs[20]);
		SetDlgItemText(hDlg,IDC_CHECK_LAST_WRITE_TIME_BETWEEN ,strngs[21]);
		SetDlgItemText(hDlg,IDC_CHECK_FILE_SIZE,strngs[22]);
		SetDlgItemText(hDlg,IDC_CHECK_FILE_ATTRIBUTE,strngs[23]);
		SetDlgItemText(hDlg,IDC_CHECK_ATTRIBUTE_ARCHIVE,strngs[24]);
		SetDlgItemText(hDlg,IDC_CHECK_ATTRIBUTE_COMPRESSED,strngs[25]);
		SetDlgItemText(hDlg,IDC_CHECK_ATTRIBUTE_DEVICE,strngs[26]);
		SetDlgItemText(hDlg,IDC_CHECK_ATTRIBUTE_DIRECTORY,strngs[27]);
		SetDlgItemText(hDlg,IDC_CHECK_ATTRIBUTE_ENCRYPTED,strngs[28]);
		SetDlgItemText(hDlg,IDC_CHECK_ATTRIBUTE_HIDDEN,strngs[29]);
		SetDlgItemText(hDlg,IDC_CHECK_ATTRIBUTE_NORMAL,strngs[30]);
		SetDlgItemText(hDlg,IDC_CHECK_ATTRIBUTE_NOT_INDEXED,strngs[31]);
		SetDlgItemText(hDlg,IDC_CHECK_ATTRIBUTE_OFFLINE,strngs[33]);
		SetDlgItemText(hDlg,IDC_CHECK_ATTRIBUTE_READ_ONLY,strngs[33]);
		SetDlgItemText(hDlg,IDC_CHECK_ATTRIBUTE_REPARSE_POINT,strngs[34]);
		SetDlgItemText(hDlg,IDC_CHECK_ATTRIBUTE_SPARSE_FILE,strngs[35]);
		SetDlgItemText(hDlg,IDC_CHECK_ATTRIBUTE_SYSTEM,strngs[36]);
		SetDlgItemText(hDlg,IDC_CHECK_ATTRIBUTE_TEMPORARY,strngs[37]);
		SetDlgItemText(hDlg,IDC_CHECK_ATTRIBUTE_VIRTUAL,strngs[38]);
		SetDlgItemText(hDlg,IDC_CHECK_ENUM_SUBDIR,strngs[39]);

		SendMessage(GetDlgItem(hDlg,IDC_COMBO_METHOD),CB_INSERTSTRING,0,(LPARAM)"FindFirstFile");
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_METHOD),CB_INSERTSTRING,0,(LPARAM)"ZwQueryDirectoryFile");
		if(!pZwCreateFile)
		{	EnableWindow(GetDlgItem(hDlg,IDC_COMBO_METHOD),FALSE);
			SendMessage(GetDlgItem(hDlg,IDC_COMBO_METHOD),CB_SETCURSEL,1,0);
		} else SendMessage(GetDlgItem(hDlg,IDC_COMBO_METHOD),CB_SETCURSEL,0,0);

		UpItem(hDlg,IDC_CHECK_ALTERNATIVE_NAME,462);
		UpItem(hDlg,IDC_EDIT_ALTERNATIVE_FILE_NAME,462);
		UpItem(hDlg,IDC_CHECK_CREATE_TIME_BEFORE,462);
		UpItem(hDlg,IDC_CHECK_CREATE_TIME_AFTER,462);
		UpItem(hDlg,IDC_EDIT_CREATE_DATE,462);
		UpItem(hDlg,IDC_EDIT_CREATE_DATE2,462);
		UpItem(hDlg,IDC_EDIT_CREATE_DATE_AFTER,462);
		UpItem(hDlg,IDC_EDIT_CREATE_DATE_AFTER2,462);
		UpItem(hDlg,IDC_CHECK_CREATE_TIME_BETWEEN,462);
		UpItem(hDlg,IDC_CHECK_LAST_ACCESS_TIME_BEFORE,462);
		UpItem(hDlg,IDC_CHECK_LAST_ACCESS_TIME_AFTER,462);
		UpItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE,462);
		UpItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE2,462);
		UpItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_AFTER,462);
		UpItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_AFTER2,462);
		UpItem(hDlg,IDC_CHECK_LAST_ACCESS_TIME_BETWEEN,462);
		UpItem(hDlg,IDC_CHECK_LAST_WRITE_TIME_BEFORE,462);
		UpItem(hDlg,IDC_CHECK_LAST_WRITE_TIME_AFTER,462);
		UpItem(hDlg,IDC_EDIT_LAST_WRITE_DATE,462);
		UpItem(hDlg,IDC_EDIT_LAST_WRITE_DATE2,462);
		UpItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_AFTER,462);
		UpItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_AFTER2,462);
		UpItem(hDlg,IDC_CHECK_LAST_WRITE_TIME_BETWEEN,462);
		UpItem(hDlg,IDC_CHECK_FILE_SIZE,462);
		UpItem(hDlg,IDC_COMBO_FILE_SIZE_EQUATION,462);
		UpItem(hDlg,IDC_EDIT_FILE_SIZE,462);
		UpItem(hDlg,IDC_SPIN_FILE_SIZE,462);
		UpItem(hDlg,IDC_COMBO_FILE_SIZE_QUANTITY,462);
		UpItem(hDlg,IDC_CHECK_FILE_ATTRIBUTE,462);
 		UpItem(hDlg,IDC_CHECK_ATTRIBUTE_ARCHIVE,462);
 		UpItem(hDlg,IDC_CHECK_ATTRIBUTE_COMPRESSED,462);
 		UpItem(hDlg,IDC_CHECK_ATTRIBUTE_DEVICE,462);
 		UpItem(hDlg,IDC_CHECK_ATTRIBUTE_DIRECTORY,462);
 		UpItem(hDlg,IDC_CHECK_ATTRIBUTE_ENCRYPTED,462);
 		UpItem(hDlg,IDC_CHECK_ATTRIBUTE_HIDDEN,462);
 		UpItem(hDlg,IDC_CHECK_ATTRIBUTE_NORMAL,462);
 		UpItem(hDlg,IDC_CHECK_ATTRIBUTE_NOT_INDEXED,462);
 		UpItem(hDlg,IDC_CHECK_ATTRIBUTE_OFFLINE,462);
 		UpItem(hDlg,IDC_CHECK_ATTRIBUTE_READ_ONLY,462);
 		UpItem(hDlg,IDC_CHECK_ATTRIBUTE_REPARSE_POINT,462);
 		UpItem(hDlg,IDC_CHECK_ATTRIBUTE_SPARSE_FILE,462);
 		UpItem(hDlg,IDC_CHECK_ATTRIBUTE_SYSTEM,462);
 		UpItem(hDlg,IDC_CHECK_ATTRIBUTE_TEMPORARY,462);
 		UpItem(hDlg,IDC_CHECK_ATTRIBUTE_VIRTUAL,462);

 		UpItem(hDlg,IDC_EDIT_CREATE_BETWEEN_DATE,462);
 		UpItem(hDlg,IDC_EDIT_CREATE_BETWEEN_TIME,462);
 		UpItem(hDlg,IDC_EDIT_CREATE_BETWEEN_DATE2,462);
 		UpItem(hDlg,IDC_EDIT_CREATE_BETWEEN_TIME2,462);
		  
 		UpItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_BETWEEN,462);
 		UpItem(hDlg,IDC_EDIT_LAST_ACCESS_TIME_BETWEEN,462);
 		UpItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_BETWEEN2,462);
 		UpItem(hDlg,IDC_EDIT_LAST_ACCESS_TIME_BETWEEN2,462);

 		UpItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_BETWEEN,462);
 		UpItem(hDlg,IDC_EDIT_LAST_WRITE_TIME_BETWEEN,462);
 		UpItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_BETWEEN2,462);
 		UpItem(hDlg,IDC_EDIT_LAST_WRITE_TIME_BETWEEN2,462);

		UpItem(hDlg,IDC_SPIN_CRTBEF_DAY,462);
		UpItem(hDlg,IDC_SPIN_CRTBEF_MOONS,462);
		UpItem(hDlg,IDC_SPIN_CRTBEF_YEAR,462);
		UpItem(hDlg,IDC_SPIN_CRTBET_DAY,462);
		UpItem(hDlg,IDC_SPIN_CRTBET_MOONS,462);
		UpItem(hDlg,IDC_SPIN_CRTBET_YEAR,462);
		UpItem(hDlg,IDC_SPIN_LSTBEF_DAY,462);
		UpItem(hDlg,IDC_SPIN_LSTBEF_MOONS,462);
		UpItem(hDlg,IDC_SPIN_LSTBEF_YEAR,462);
		UpItem(hDlg,IDC_SPIN_LSTBET_DAY,462);
		UpItem(hDlg,IDC_SPIN_LSTBET_MOON,462);
		UpItem(hDlg,IDC_SPIN_LSTBET_YEAR,462);
		UpItem(hDlg,IDC_SPIN_LSWTBEF_DAY,462);
		UpItem(hDlg,IDC_SPIN_LSWTBEF_MOON,462);
		UpItem(hDlg,IDC_SPIN_LSWTBEF_YEAR,462);
		UpItem(hDlg,IDC_SPIN_LSWTBET_DAY,462);
		UpItem(hDlg,IDC_SPIN_LSWTBET_MOON,462);
		UpItem(hDlg,IDC_SPIN_LSWTBET_YEAR,462);
		UpItem(hDlg,IDC_SPIN_CRAFT_DAY,462);
		UpItem(hDlg,IDC_SPIN_CRAFT_MOON,462);
		UpItem(hDlg,IDC_SPIN_CRAFT_YEAR,462);
		UpItem(hDlg,IDC_SPIN_CRBET_DAY,462);
		UpItem(hDlg,IDC_SPIN_CRBET_MOON,462);
		UpItem(hDlg,IDC_SPIN_CRBET_YEAR,462);
		UpItem(hDlg,IDC_SPIN_LSAFT_DAY,462);
		UpItem(hDlg,IDC_SPIN_LSAFT_MOON,462);
		UpItem(hDlg,IDC_SPIN_LSAFT_YEAR,462);
		UpItem(hDlg,IDC_SPIN_LSABET_DAY,462);
		UpItem(hDlg,IDC_SPIN_LSABET_MOON,462);
		UpItem(hDlg,IDC_SPIN_LSABET_YEAR,462);
		UpItem(hDlg,IDC_SPIN_LSWRAFT_DAY,462);
		UpItem(hDlg,IDC_SPIN_LSWRAFT_MOON,462);
		UpItem(hDlg,IDC_SPIN_LSWRAFT_YEAR,462);
		UpItem(hDlg,IDC_SPIN_LSWRBET_DAY,462);
		UpItem(hDlg,IDC_SPIN_LSWRBET_MOON,462);
		UpItem(hDlg,IDC_SPIN_LSWRBET_YEAR,462);
		UpItem(hDlg,IDC_SPIN_CRTBEF_HOUR,462);
		UpItem(hDlg,IDC_SPIN_CRTBEF_MIN,462);
		UpItem(hDlg,IDC_SPIN_CRTBEF_SEC,462);
		UpItem(hDlg,IDC_SPIN_CRTBEF_MILS,462);
		UpItem(hDlg,IDC_SPIN_CRTBET_HOUR,462);
		UpItem(hDlg,IDC_SPIN_CRTBET_MIN,462);
		UpItem(hDlg,IDC_SPIN_CRTBET_SEC,462);
		UpItem(hDlg,IDC_SPIN_CRTBET_MILS,462);
		UpItem(hDlg,IDC_SPIN_LSTBEF_HOUR,462);
		UpItem(hDlg,IDC_SPIN_LSTBEF_MIN,462);
		UpItem(hDlg,IDC_SPIN_LSTBEF_SEC,462);
		UpItem(hDlg,IDC_SPIN_LSTBEF_MILS,462);
		UpItem(hDlg,IDC_SPIN_LSTBET_HOUR,462);
		UpItem(hDlg,IDC_SPIN_LSTBET_MIN,462);
		UpItem(hDlg,IDC_SPIN_LSTBET_SEC,462);
		UpItem(hDlg,IDC_SPIN_LSTBET_MILS,462);
		UpItem(hDlg,IDC_SPIN_LSWTBEF_HOUR,462);
		UpItem(hDlg,IDC_SPIN_LSWTBEF_MIN,462);
		UpItem(hDlg,IDC_SPIN_LSWTBEF_SEC,462);
		UpItem(hDlg,IDC_SPIN_LSWTBEF_MILS,462);
		UpItem(hDlg,IDC_SPIN_LSWTBET_HOUR,462);
		UpItem(hDlg,IDC_SPIN_LSWTBET_MIN,462);
		UpItem(hDlg,IDC_SPIN_LSWTBET_SEC,462);
		UpItem(hDlg,IDC_SPIN_LSWTBET_MILS,462);
		UpItem(hDlg,IDC_SPIN_CRAFT_HOUR,462);
		UpItem(hDlg,IDC_SPIN_CRAFT_MIN,462);
		UpItem(hDlg,IDC_SPIN_CRAFT_SEC,462);
		UpItem(hDlg,IDC_SPIN_CRAFT_MILS,462);
		UpItem(hDlg,IDC_SPIN_CRBET_HOUR,462);
		UpItem(hDlg,IDC_SPIN_CRBET_MIN,462);
		UpItem(hDlg,IDC_SPIN_CRBET_SEC,462);
		UpItem(hDlg,IDC_SPIN_CRBET_MILS,462);
		UpItem(hDlg,IDC_SPIN_LSAFT_HOUR,462);
		UpItem(hDlg,IDC_SPIN_LSAFT_MIN,462);
		UpItem(hDlg,IDC_SPIN_LSAFT_SEC,462);
		UpItem(hDlg,IDC_SPIN_LSAFT_MILS,462);
		UpItem(hDlg,IDC_SPIN_LSABET_HOUR,462);
		UpItem(hDlg,IDC_SPIN_LSABET_MIN,462);
		UpItem(hDlg,IDC_SPIN_LSABET_SEC,462);
		UpItem(hDlg,IDC_SPIN_LSABET_MILS,462);
		UpItem(hDlg,IDC_SPIN_LSWRAFT_HOUR,462);
		UpItem(hDlg,IDC_SPIN_LSWRAFT_MIN,462);
		UpItem(hDlg,IDC_SPIN_LSWRAFT_SEC,462);
		UpItem(hDlg,IDC_SPIN_LSWRAFT_MILS,462);
		UpItem(hDlg,IDC_SPIN_LSWRBET_HOUR,462);
		UpItem(hDlg,IDC_SPIN_LSWRBET_MIN,462);
		UpItem(hDlg,IDC_SPIN_LSWRBET_SEC,462);
		UpItem(hDlg,IDC_SPIN_LSWRBET_MILS,462);

		SetTabPage(hDlg, 0);

		/*SendMessage(GetDlgItem(hDlg,IDC_CHECK_TEXT_SEACH),BM_SETCHECK,BST_UNCHECKED,0);
		EnableWindow(GetDlgItem(hDlg,IDC_COMBO_SEARCH_FOR_TEXT),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_CHECK_UNICODE_OR_MULTIBYTE),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_CHECK_BINARY_OR_CHARACTER),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_CHECK_REGISTR_CAPS),FALSE);

		SendMessage(GetDlgItem(hDlg,IDC_CHECK_NO_TEXT_SEACH),BM_SETCHECK,BST_UNCHECKED,0);
		EnableWindow(GetDlgItem(hDlg,IDC_COMBO_SEARCH_NOT_TEXT),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_CHECK_UNICODE_OR_MULTIBYTE2),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_CHECK_BINARY_OR_CHARACTER2),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_CHECK_REGISTR_CAPS2),FALSE);

		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ALTERNATIVE_NAME),BM_SETCHECK,BST_UNCHECKED,0);
		EnableWindow(GetDlgItem(hDlg,IDC_EDIT_ALTERNATIVE_FILE_NAME),FALSE);

		SendMessage(GetDlgItem(hDlg,IDC_CHECK_CREATE_TIME_BEFORE),BM_SETCHECK,BST_UNCHECKED,0);
		EnableWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_DATE),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_DATE2),FALSE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_CREATE_TIME_AFTER),BM_SETCHECK,BST_UNCHECKED,0);
		EnableWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_DATE_AFTER),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_DATE_AFTER2),FALSE);		
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_CREATE_TIME_BETWEEN),BM_SETCHECK,BST_UNCHECKED,0);
		EnableWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_BETWEEN_DATE),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_BETWEEN_TIME),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_BETWEEN_DATE2),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_BETWEEN_TIME2),FALSE);

		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_DAY),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_MOONS),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_YEAR),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_HOUR),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_MIN),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_SEC),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_MILS),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_DAY),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_MOONS),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_YEAR),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_HOUR),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_MIN),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_SEC),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_MILS),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_DAY),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_MOON),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_YEAR),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_HOUR),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_MIN),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_SEC),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_MILS),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_DAY),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_MOON),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_YEAR),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_HOUR),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_MIN),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_SEC),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_MILS),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_DAY),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_MOONS),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_YEAR),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_HOUR),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_MIN),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_SEC),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_MILS),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_DAY),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_MOON),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_YEAR),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_HOUR),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_MIN),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_SEC),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_MILS),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_DAY),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_MOON),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_YEAR),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_HOUR),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_MIN),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_SEC),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_MILS),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_FILE_SIZE),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_DAY),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_MOON),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_YEAR),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_HOUR),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_MIN),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_SEC),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_MILS),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_DAY),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_MOON),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_YEAR),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_HOUR),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_MIN),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_SEC),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_MILS),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_DAY),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_MOON),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_YEAR),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_HOUR),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_MIN),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_SEC),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_MILS),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_DAY),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_MOON),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_YEAR),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_HOUR),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_MIN),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_SEC),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_MILS),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_DAY),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_MOON),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_YEAR),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_HOUR),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_MIN),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_SEC),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_MILS),FALSE);
		  
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_ACCESS_TIME_BETWEEN),BM_SETCHECK,BST_UNCHECKED,0);
		EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_BETWEEN),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_TIME_BETWEEN),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_BETWEEN2),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_TIME_BETWEEN2),FALSE);

		SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_WRITE_TIME_BETWEEN),BM_SETCHECK,BST_UNCHECKED,0);
		EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_BETWEEN),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_TIME_BETWEEN),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_BETWEEN2),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_TIME_BETWEEN2),FALSE);

		SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_ACCESS_TIME_BEFORE),BM_SETCHECK,BST_UNCHECKED,0);
		EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE2),FALSE);
		 
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_ACCESS_TIME_AFTER),BM_SETCHECK,BST_UNCHECKED,0);
		EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_AFTER),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_AFTER2),FALSE);
		 
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_WRITE_TIME_BEFORE),BM_SETCHECK,BST_UNCHECKED,0);
		EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE2),FALSE);
	
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_WRITE_TIME_AFTER),BM_SETCHECK,BST_UNCHECKED,0);
		EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_AFTER),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_AFTER2),FALSE);
	
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_FILE_SIZE),BM_SETCHECK,BST_UNCHECKED,0);
		EnableWindow(GetDlgItem(hDlg,IDC_COMBO_FILE_SIZE_EQUATION),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_EDIT_FILE_SIZE),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_COMBO_FILE_SIZE_QUANTITY),FALSE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_FILE_ATTRIBUTE),BM_SETCHECK,BST_UNCHECKED,0);
		EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_ARCHIVE),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_COMPRESSED),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_DEVICE),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_DIRECTORY),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_ENCRYPTED),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_HIDDEN),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_NORMAL),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_NOT_INDEXED),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_OFFLINE),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_READ_ONLY),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_REPARSE_POINT),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_SPARSE_FILE),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_SYSTEM),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_TEMPORARY),FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_VIRTUAL),FALSE);*/
  		 
		TCITEM tie;
		tie.mask = TCIF_TEXT;// | TCIF_IMAGE;
		tie.iImage = -1;
		tie.pszText = strngs[41];//"Size and time parameters:";
		TabCtrl_InsertItem(GetDlgItem(hDlg,IDC_TAB_FILE_SEACH),0, &tie);
		tie.pszText = strngs[40];//"Common parameters:";
		TabCtrl_InsertItem(GetDlgItem(hDlg,IDC_TAB_FILE_SEACH),0, &tie);

		TabCtrl_SetCurSel(GetDlgItem(hDlg,IDC_TAB_FILE_SEACH),0);

		SendMessage(GetDlgItem(hDlg,IDC_COMBO_FILE_SIZE_EQUATION),CB_INSERTSTRING,(WPARAM)-1,(LPARAM)"<");
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_FILE_SIZE_EQUATION),CB_INSERTSTRING,(WPARAM)-1,(LPARAM)">");
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_FILE_SIZE_EQUATION),CB_INSERTSTRING,(WPARAM)-1,(LPARAM)"==");
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_FILE_SIZE_EQUATION),CB_SETCURSEL,0,0);

		SendMessage(GetDlgItem(hDlg,IDC_COMBO_FILE_SIZE_QUANTITY),CB_INSERTSTRING,(WPARAM)-1,(LPARAM)"byte");
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_FILE_SIZE_QUANTITY),CB_INSERTSTRING,(WPARAM)-1,(LPARAM)"kb");
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_FILE_SIZE_QUANTITY),CB_INSERTSTRING,(WPARAM)-1,(LPARAM)"mb");
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_FILE_SIZE_QUANTITY),CB_INSERTSTRING,(WPARAM)-1,(LPARAM)"gb");
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_FILE_SIZE_QUANTITY),CB_SETCURSEL,0,0);

		SendMessage(GetDlgItem(hDlg,IDC_SPIN_FILE_SIZE),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_DAY),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_MOONS),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_YEAR),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_HOUR),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_MIN),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_SEC),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_MILS),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRTBET_DAY),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRTBET_MOONS),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRTBET_YEAR),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRTBET_HOUR),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRTBET_MIN),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRTBET_SEC),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRTBET_MILS),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRBET_DAY),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRBET_MOON),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRBET_YEAR),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRBET_HOUR),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRBET_MIN),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRBET_SEC),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRBET_MILS),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRAFT_DAY),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRAFT_MOON),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRAFT_YEAR),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRAFT_HOUR),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRAFT_MIN),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRAFT_SEC),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRAFT_MILS),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_DAY),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_MOONS),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_YEAR),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_HOUR),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_MIN),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_SEC),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_MILS),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_DAY),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_MOON),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_YEAR),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_HOUR),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_MIN),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_SEC),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_MILS),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_DAY),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_MOON),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_YEAR),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_HOUR),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_MIN),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_SEC),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_MILS),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSAFT_DAY),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSAFT_MOON),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSAFT_YEAR),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSAFT_HOUR),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSAFT_MIN),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSAFT_SEC),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSAFT_MILS),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSTBET_DAY),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSTBET_MOON),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSTBET_YEAR),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSTBET_HOUR),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSTBET_MIN),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSTBET_SEC),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSTBET_MILS),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSABET_DAY),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSABET_MOON),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSABET_YEAR),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSABET_HOUR),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSABET_MIN),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSABET_SEC),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSABET_MILS),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_DAY),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_MOON),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_YEAR),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_HOUR),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_MIN),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_SEC),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_MILS),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_DAY),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_MOON),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_YEAR),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_HOUR),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_MIN),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_SEC),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_MILS),UDM_SETRANGE32,0,100);

		SendMessage(GetDlgItem(hDlg,IDC_SPIN_FILE_SIZE),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_DAY),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_MOONS),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_YEAR),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_HOUR),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_MIN),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_SEC),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_MILS),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRTBET_DAY),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRTBET_MOONS),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRTBET_YEAR),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRTBET_HOUR),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRTBET_MIN),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRTBET_SEC),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRTBET_MILS),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRBET_DAY),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRBET_MOON),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRBET_YEAR),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRBET_HOUR),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRBET_MIN),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRBET_SEC),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRBET_MILS),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRAFT_DAY),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRAFT_MOON),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRAFT_YEAR),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRAFT_HOUR),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRAFT_MIN),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRAFT_SEC),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRAFT_MILS),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_DAY),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_MOONS),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_YEAR),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_HOUR),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_MIN),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_SEC),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_MILS),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_DAY),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_MOON),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_YEAR),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_HOUR),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_MIN),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_SEC),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_MILS),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_DAY),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_MOON),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_YEAR),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_HOUR),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_MIN),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_SEC),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_MILS),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSAFT_DAY),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSAFT_MOON),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSAFT_YEAR),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSAFT_HOUR),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSAFT_MIN),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSAFT_SEC),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSAFT_MILS),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSTBET_DAY),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSTBET_MOON),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSTBET_YEAR),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSTBET_HOUR),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSTBET_MIN),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSTBET_SEC),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSTBET_MILS),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSABET_DAY),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSABET_MOON),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSABET_YEAR),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSABET_HOUR),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSABET_MIN),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSABET_SEC),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSABET_MILS),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_DAY),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_MOON),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_YEAR),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_HOUR),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_MIN),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_SEC),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_MILS),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_DAY),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_MOON),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_YEAR),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_HOUR),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_MIN),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_SEC),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_MILS),UDM_SETPOS32,0,50);

		LocTimeToEdit(hDlg, IDC_EDIT_CREATE_DATE, IDC_EDIT_CREATE_DATE2);
		LocTimeToEdit(hDlg, IDC_EDIT_CREATE_DATE_AFTER, IDC_EDIT_CREATE_DATE_AFTER2);
		LocTimeToEdit(hDlg, IDC_EDIT_CREATE_BETWEEN_DATE, IDC_EDIT_CREATE_BETWEEN_TIME);
		LocTimeToEdit(hDlg, IDC_EDIT_CREATE_BETWEEN_DATE2, IDC_EDIT_CREATE_BETWEEN_TIME2);
		LocTimeToEdit(hDlg, IDC_EDIT_LAST_ACCESS_DATE, IDC_EDIT_LAST_ACCESS_DATE2);
		LocTimeToEdit(hDlg, IDC_EDIT_LAST_ACCESS_DATE_AFTER, IDC_EDIT_LAST_ACCESS_DATE_AFTER2);
		LocTimeToEdit(hDlg, IDC_EDIT_LAST_ACCESS_DATE_BETWEEN, IDC_EDIT_LAST_ACCESS_TIME_BETWEEN);
		LocTimeToEdit(hDlg, IDC_EDIT_LAST_ACCESS_DATE_BETWEEN2, IDC_EDIT_LAST_ACCESS_TIME_BETWEEN2);
		LocTimeToEdit(hDlg, IDC_EDIT_LAST_WRITE_DATE, IDC_EDIT_LAST_WRITE_DATE2);
		LocTimeToEdit(hDlg, IDC_EDIT_LAST_WRITE_DATE_AFTER, IDC_EDIT_LAST_WRITE_DATE_AFTER2);
		LocTimeToEdit(hDlg, IDC_EDIT_LAST_WRITE_DATE_BETWEEN, IDC_EDIT_LAST_WRITE_TIME_BETWEEN);
		LocTimeToEdit(hDlg, IDC_EDIT_LAST_WRITE_DATE_BETWEEN2, IDC_EDIT_LAST_WRITE_TIME_BETWEEN2);
	
		//if(lParam)
		{	selV7PthCB.Read(selV7PthCBFName,GetDlgItem(hDlg,IDC_COMBO_SEARCH_PATH),25,MAX_PATH);
			selV7TxtCB.Read(selV7TxtCBFName,GetDlgItem(hDlg,IDC_COMBO_SEARCH_FOR_TEXT),25,MAX_PATH);
			selV7ExclTxt.Read(selV7ExclTxtFName,GetDlgItem(hDlg,IDC_COMBO_SEARCH_NOT_TEXT),25,MAX_PATH);

			MyStringCpy(s,MAX_PATH,initPath);
			MyStringRemoveLastChar(s,MAX_PATH,'*');
			MyStringCat(s,MAX_PATH,";");
			SetDlgItemText(hDlg,IDC_COMBO_SEARCH_PATH,s);
			selV7PthCB.AddToCB(GetDlgItem(hDlg,IDC_COMBO_SEARCH_PATH),s);
		

			SetDlgItemText(hDlg,IDC_EDIT_FILE_SIZE,"1");
			if(!selV7NameCB.Read(selV7NameCBFName,
								 GetDlgItem(hDlg,IDC_COMBO_SEARCH_NAME),
								 MAX_SAVE_SELECTION_STR,
								 MAX_SEL_PATH))//fSeachViaF7.FillSearchFilterCB(hDlg,IDC_COMBO_SEARCH_NAME);
				SetDlgItemText(hDlg,IDC_COMBO_SEARCH_NAME,"*.*;");
		}
		/*else//Agar confdan chaqirgan bo'lsa:
		{	EnableWindow(GetDlgItem(hDlg,IDC_COMBO_SEARCH_PATH),FALSE);
			EnableWindow(GetDlgItem(hDlg,IDC_BUTTON_ADD_PATH),FALSE);
			EnableWindow(GetDlgItem(hDlg,IDC_BUTTON_ADD_DISK),FALSE);
			SetDlgItemText(hDlg,IDC_COMBO_SEARCH_NAME,item.filtr);
			SetDlgItemText(hDlg,IDC_COMBO_SEARCH_PATH,item.rootPath);
			SendMessage(GetDlgItem(hDlg,IDC_CHECK_TEXT_SEACH),BM_SETCHECK,item.bFindForText?BST_CHECKED:BST_UNCHECKED,0);
			if(item.bFindForText)
			{	SetDlgItemText(hDlg,IDC_COMBO_SEARCH_FOR_TEXT,item.FindForText);
				EnableWindow(GetDlgItem(hDlg,IDC_COMBO_SEARCH_FOR_TEXT),TRUE);
				EnableWindow(GetDlgItem(hDlg,IDC_CHECK_UNICODE_OR_MULTIBYTE),TRUE);
				EnableWindow(GetDlgItem(hDlg,IDC_CHECK_BINARY_OR_CHARACTER),TRUE);
				EnableWindow(GetDlgItem(hDlg,IDC_CHECK_REGISTR_CAPS),TRUE);
				SendMessage(GetDlgItem(hDlg,IDC_CHECK_UNICODE_OR_MULTIBYTE),BM_SETCHECK,item.bFindForText_Unicode?BST_CHECKED:BST_UNCHECKED,0);
				SendMessage(GetDlgItem(hDlg,IDC_CHECK_BINARY_OR_CHARACTER),BM_SETCHECK,item.bFindForText_ASCII?BST_CHECKED:BST_UNCHECKED,0);
				SendMessage(GetDlgItem(hDlg,IDC_CHECK_REGISTR_CAPS),BM_SETCHECK,item.bFindForText_UpperCase?BST_CHECKED:BST_UNCHECKED,0);
			}
			SendMessage(GetDlgItem(hDlg,IDC_CHECK_NO_TEXT_SEACH),BM_SETCHECK,item.bFindForExcldText?BST_CHECKED:BST_UNCHECKED,0);
			if(item.bFindForExcldText)
			{	SetDlgItemText(hDlg,IDC_COMBO_SEARCH_NOT_TEXT,item.FindForExcldText);
				EnableWindow(GetDlgItem(hDlg,IDC_COMBO_SEARCH_NOT_TEXT),TRUE);
				EnableWindow(GetDlgItem(hDlg,IDC_CHECK_UNICODE_OR_MULTIBYTE2),TRUE);
				EnableWindow(GetDlgItem(hDlg,IDC_CHECK_BINARY_OR_CHARACTER2),TRUE);
				EnableWindow(GetDlgItem(hDlg,IDC_CHECK_REGISTR_CAPS2),TRUE);
				SendMessage(GetDlgItem(hDlg,IDC_CHECK_UNICODE_OR_MULTIBYTE2),BM_SETCHECK,item.bFindForExcldText_Unicode?BST_CHECKED:BST_UNCHECKED,0);
				SendMessage(GetDlgItem(hDlg,IDC_CHECK_BINARY_OR_CHARACTER2),BM_SETCHECK,item.bFindForExcldText_ASCII?BST_CHECKED:BST_UNCHECKED,0);
				SendMessage(GetDlgItem(hDlg,IDC_CHECK_REGISTR_CAPS2),BM_SETCHECK,item.bFindForExcldText_UpperCase?BST_CHECKED:BST_UNCHECKED,0);
			}

			SendMessage(GetDlgItem(hDlg,IDC_CHECK_ALTERNATIVE_NAME),BM_SETCHECK,item.bFindForAlterName?BST_CHECKED:BST_UNCHECKED,0);
			if(item.bFindForAlterName)
			{	SetDlgItemText(hDlg,IDC_EDIT_ALTERNATIVE_FILE_NAME,item.altName);
				EnableWindow(GetDlgItem(hDlg,IDC_EDIT_ALTERNATIVE_FILE_NAME),TRUE);
			}
			//wchar_t altNameW[MAX_PATH];

			SendMessage(GetDlgItem(hDlg,IDC_CHECK_CREATE_TIME_BEFORE),BM_SETCHECK,item.bCrTimeBef?BST_CHECKED:BST_UNCHECKED,0);
			if(item.bCrTimeBef)
			{	TimeToEdit(item.CrTimeBef,hDlg,IDC_EDIT_CREATE_DATE,IDC_EDIT_CREATE_DATE2);
				EnableWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_DATE),TRUE);
				EnableWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_DATE2),TRUE);
			}
			SendMessage(GetDlgItem(hDlg,IDC_CHECK_CREATE_TIME_AFTER),BM_SETCHECK,item.bCrTimeAft?BST_CHECKED:BST_UNCHECKED,0);
			if(item.bCrTimeAft)
			{	TimeToEdit(item.CrTimeAft,hDlg,IDC_EDIT_CREATE_DATE_AFTER,IDC_EDIT_CREATE_DATE_AFTER2);
				EnableWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_DATE_AFTER),TRUE);
				EnableWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_DATE_AFTER2),TRUE);
			}
			SendMessage(GetDlgItem(hDlg,IDC_CHECK_CREATE_TIME_BETWEEN),BM_SETCHECK,item.bCrTimeBet?BST_CHECKED:BST_UNCHECKED,0);
			if(item.bCrTimeBet)
			{	TimeToEdit(item.CrTimeBet[0],hDlg,IDC_EDIT_CREATE_BETWEEN_DATE,IDC_EDIT_CREATE_BETWEEN_TIME);
				TimeToEdit(item.CrTimeBet[1],hDlg,IDC_EDIT_CREATE_BETWEEN_DATE2,IDC_EDIT_CREATE_BETWEEN_TIME2);
				EnableWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_BETWEEN_DATE),TRUE);
				EnableWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_BETWEEN_TIME),TRUE);
				EnableWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_BETWEEN_DATE2),TRUE);
				EnableWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_BETWEEN_TIME2),TRUE);
			}
			SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_ACCESS_TIME_BEFORE),BM_SETCHECK,item.bLstAccTimeBef?BST_CHECKED:BST_UNCHECKED,0);
			if(item.bLstAccTimeBef)
			{	TimeToEdit(item.LstAccTimeBef,hDlg,IDC_EDIT_LAST_ACCESS_DATE,IDC_EDIT_LAST_ACCESS_DATE2);
				EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE),TRUE);
				EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE2),TRUE);
			}
			SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_ACCESS_TIME_AFTER),BM_SETCHECK,item.bLstAccTimeAft?BST_CHECKED:BST_UNCHECKED,0);
			if(item.bLstAccTimeAft)
			{	TimeToEdit(item.LstAccTimeBef,hDlg,IDC_EDIT_LAST_ACCESS_DATE_AFTER,IDC_EDIT_LAST_ACCESS_DATE_AFTER2);
				EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_AFTER),TRUE);
				EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_AFTER2),TRUE);
			}
			SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_ACCESS_TIME_BETWEEN),BM_SETCHECK,item.bLastAccTimeBet?BST_CHECKED:BST_UNCHECKED,0);
			if(item.bLastAccTimeBet)
			{	TimeToEdit(item.LastAccTimeBet[0],hDlg,IDC_EDIT_LAST_ACCESS_DATE_BETWEEN,IDC_EDIT_LAST_ACCESS_TIME_BETWEEN);
				TimeToEdit(item.LastAccTimeBet[1],hDlg,IDC_EDIT_LAST_ACCESS_DATE_BETWEEN2,IDC_EDIT_LAST_ACCESS_TIME_BETWEEN2);
				EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_BETWEEN),TRUE);
				EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_TIME_BETWEEN),TRUE);
				EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_BETWEEN2),TRUE);
				EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_TIME_BETWEEN2),TRUE);
			}
			SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_WRITE_TIME_BEFORE),BM_SETCHECK,item.bLstWrTimeBef?BST_CHECKED:BST_UNCHECKED,0);
			if(item.bLstWrTimeBef)
			{	TimeToEdit(item.LstWrTimeBef,hDlg,IDC_EDIT_LAST_WRITE_DATE,IDC_EDIT_LAST_WRITE_DATE2);
				EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE),TRUE);
				EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE2),TRUE);
			}
			SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_WRITE_TIME_AFTER),BM_SETCHECK,item.bLstWrTimeAft?BST_CHECKED:BST_UNCHECKED,0);
			if(item.bLstWrTimeAft)
			{	TimeToEdit(item.LstWrTimeAft,hDlg,IDC_EDIT_LAST_WRITE_DATE_AFTER,IDC_EDIT_LAST_WRITE_DATE_AFTER2);
				EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_AFTER),TRUE);
				EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_AFTER2),TRUE);
			}
			SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_WRITE_TIME_BETWEEN),BM_SETCHECK,item.bLstWrTimeBet?BST_CHECKED:BST_UNCHECKED,0);
			if(item.bLstWrTimeBet)
			{	TimeToEdit(item.LstWrTimeBet[0],hDlg,IDC_EDIT_LAST_WRITE_DATE_BETWEEN,IDC_EDIT_LAST_WRITE_TIME_BETWEEN);
				TimeToEdit(item.LstWrTimeBet[1],hDlg,IDC_EDIT_LAST_WRITE_DATE_BETWEEN2,IDC_EDIT_LAST_WRITE_TIME_BETWEEN2);
				EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_BETWEEN),TRUE);
				EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_TIME_BETWEEN),TRUE);
				EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_BETWEEN2),TRUE);
				EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_TIME_BETWEEN2),TRUE);
			}
			SendMessage(GetDlgItem(hDlg,IDC_CHECK_FILE_SIZE),BM_SETCHECK,item.bFileSz?BST_CHECKED:BST_UNCHECKED,0);
			if(item.bFileSz)
			{	EnableWindow(GetDlgItem(hDlg,IDC_COMBO_FILE_SIZE_EQUATION),TRUE);
				EnableWindow(GetDlgItem(hDlg,IDC_EDIT_FILE_SIZE),TRUE);
				EnableWindow(GetDlgItem(hDlg,IDC_COMBO_FILE_SIZE_QUANTITY),TRUE);
				switch(item.sFileSzEqu[0])
				{	case '<':
						SendMessage(GetDlgItem(hDlg,IDC_COMBO_FILE_SIZE_EQUATION),CB_SETCURSEL,0,0);
						break;
					case '>':
						SendMessage(GetDlgItem(hDlg,IDC_COMBO_FILE_SIZE_EQUATION),CB_SETCURSEL,1,0);
						break;
					case '=':
						SendMessage(GetDlgItem(hDlg,IDC_COMBO_FILE_SIZE_EQUATION),CB_SETCURSEL,2,0);
						break;
				}
				SetDlgItemText(hDlg,IDC_EDIT_FILE_SIZE,item.sFileSz);
				SendMessage(GetDlgItem(hDlg,IDC_COMBO_FILE_SIZE_QUANTITY),CB_SETCURSEL,item.iFileSzQual,0);
			}
			SendMessage(GetDlgItem(hDlg,IDC_CHECK_FILE_ATTRIBUTE),BM_SETCHECK,item.bFileAttr?BST_CHECKED:BST_UNCHECKED,0);
			if(item.bFileAttr)
			{	EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_ARCHIVE),TRUE);
				EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_COMPRESSED),TRUE);
				EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_DEVICE),TRUE);
				EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_DIRECTORY),TRUE);
				EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_ENCRYPTED),TRUE);
				EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_HIDDEN),TRUE);
				EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_NORMAL),TRUE);
				EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_NOT_INDEXED),TRUE);
				EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_OFFLINE),TRUE);
				EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_READ_ONLY),TRUE);
				EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_REPARSE_POINT),TRUE);
				EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_SPARSE_FILE),TRUE);
				EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_SYSTEM),TRUE);
				EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_TEMPORARY),TRUE);
				EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_VIRTUAL),TRUE);
				SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_ARCHIVE),BM_SETCHECK,item.bFileAttArchive?BST_CHECKED:BST_UNCHECKED,0);
				SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_COMPRESSED),BM_SETCHECK,item.bFileAttCompr?BST_CHECKED:BST_UNCHECKED,0);
				SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_DEVICE),BM_SETCHECK,item.bFileAttDevice?BST_CHECKED:BST_UNCHECKED,0);
				SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_DIRECTORY),BM_SETCHECK,item.bFileAttDir?BST_CHECKED:BST_UNCHECKED,0);
				SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_ENCRYPTED),BM_SETCHECK,item.bFileAttEncr?BST_CHECKED:BST_UNCHECKED,0);
				SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_HIDDEN),BM_SETCHECK,item.bFileAttHidden?BST_CHECKED:BST_UNCHECKED,0);
				SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_NORMAL),BM_SETCHECK,item.bFileAttNormal?BST_CHECKED:BST_UNCHECKED,0);
				SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_NOT_INDEXED),BM_SETCHECK,item.bFileAttNotInd?BST_CHECKED:BST_UNCHECKED,0);
				SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_OFFLINE),BM_SETCHECK,item.bFileAttOffl?BST_CHECKED:BST_UNCHECKED,0);
				SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_READ_ONLY),BM_SETCHECK,item.bFileAttReadOnly?BST_CHECKED:BST_UNCHECKED,0);
				SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_REPARSE_POINT),BM_SETCHECK,item.bFileAttRepPt?BST_CHECKED:BST_UNCHECKED,0);
				SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_SPARSE_FILE),BM_SETCHECK,item.bFileAttSparseFile?BST_CHECKED:BST_UNCHECKED,0);
				SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_SYSTEM),BM_SETCHECK,item.bFileAttSys?BST_CHECKED:BST_UNCHECKED,0);
				SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_TEMPORARY),BM_SETCHECK,item.bFileAttTemp?BST_CHECKED:BST_UNCHECKED,0);
				SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_VIRTUAL),BM_SETCHECK,item.bFileAttVirt?BST_CHECKED:BST_UNCHECKED,0);
		}	}*/
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_SEARCH_NAME),CB_SETEDITSEL,0,MAKELPARAM(0,-1));
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ENUM_SUBDIR),BM_SETCHECK,
					schConf.bEnumSubDir?BST_CHECKED:BST_UNCHECKED,0);
		COMBOBOXINFO ci; ci.cbSize = sizeof(COMBOBOXINFO);
		if(SendMessage(GetDlgItem(hDlg,IDC_COMBO_SEARCH_NAME),CB_GETCOMBOBOXINFO,0,(LPARAM)&ci))
			SetFocus(ci.hwndItem);
		PostMessage(hDlg,WM_NEXTDLGCTL,IDC_COMBO_SEARCH_NAME,MAKELONG(0,TRUE));

		search.iCall = 0;
		search.bStop = TRUE;
		search.bRun = FALSE;
		SendMessage(hDlg,WM_USER+1,0,0);

		if(search.LBListBuf)
		{	CreateResultsLB(hDlg);
			search.LoadLBList(hResultsLB);
			CreateOutptBtns(hDlg);
		}
		return TRUE;
	case WM_CTLCOLORSTATIC:
	case WM_CTLCOLORLISTBOX:
	case WM_CTLCOLORSCROLLBAR:
	case WM_CTLCOLORDLG:HDC dc;dc = (HDC)wParam;
		SetTextColor(dc,RGB(0x20,0x20,0x00));//conf::Dlg.dlgRGBs[6][1]);
		SetBkColor(dc,RGB(224,231,241));//0xec,0xe1,0xec));//conf::Dlg.dlgRGBs[6][2]);
		return (INT_PTR)br;
	case WM_CTLCOLOREDIT:dc = (HDC)wParam;
		SetTextColor(dc,RGB(0x20,0x20,0));//conf::Dlg.dlgRGBs[6][1]);
		SetBkColor(dc,RGB(224,231,241));//conf::Dlg.dlgRGBs[6][2]);
		return (INT_PTR)br;
	case WM_CTLCOLORBTN:dc=(HDC)wParam;
		SetTextColor(dc,RGB(0x20,0x20,0x00));//conf::Dlg.dlgRGBs[6][1]);
		SetBkColor(dc,RGB(224,231,241));//0xee,0xae,0xd7));//conf::Dlg.dlgRGBs[6][2]);
		return (INT_PTR)brHtBk;
	case WM_DRAWITEM://WM_CTLCOLORBTN dagi knopkalar:
		LPDRAWITEMSTRUCT lpdis;lpdis = (LPDRAWITEMSTRUCT)lParam;
		GetWindowText(lpdis->hwndItem,s,64);
		RECT r;UINT uStyle;uStyle = DFCS_BUTTONPUSH;
		r = lpdis->rcItem;
		if(lpdis->itemState & ODS_SELECTED)
		{	uStyle |= DFCS_PUSHED|DFCS_TRANSPARENT;
			r.left+=2;r.top+=2;
		}
		DrawFrameControl(lpdis->hDC, &lpdis->rcItem, DFC_BUTTON, uStyle);
		if(lpdis->itemState & ODS_SELECTED)
			{r.left+=1;r.top+=1;r.bottom-=2;r.right-=3;}
		else
			{r.left+=1;r.top+=2;r.bottom-=3;r.right-=3;}
		FillRect(lpdis->hDC,&r,brHtBk);//DrawText(lpdis->hDC,"                                                  ",50,&rc,DT_SINGLELINE|DT_VCENTER|DT_INTERNAL|DT_LEFT);
		if(lpdis->itemState & ODS_SELECTED)
			{r.left-=1;r.top-=1;r.bottom+=3;r.right+=3;}
		else
			{r.left-=1;r.top-=2;r.bottom+=2;r.right+=3;}
		DrawText(lpdis->hDC,s,MyStringLength(s,64),&r,DT_SINGLELINE|DT_VCENTER|DT_CENTER);
		return FALSE;
	case WM_USER+1://hf obshiy uchun, dinamik o'zgartirish uchun emas:
		if(0==hfRef)
		{	LOGFONT lf;InitLOGFONT(&lf);
			hf = CreateFontIndirect(&lf);
			br = CreateSolidBrush(RGB(224,231,241));//0xeb,0xe0,0xeb));//conf::Dlg.dlgRGBs[6][0]);
			brHtBk = CreateSolidBrush(RGB(224,231,241));//conf::Dlg.dlgRGBs[6][5]);
			//dlgRGBs[d][0] = 0x00c98193;//0x00ebe0eb;//Back
			//dlgRGBs[d][1] = 0x008a0000;//0x00c98193;//0x008a0000;//Front
			//dlgRGBs[d][2] = 0x00c08197;//0x00ece1ec;//Select back
			//dlgRGBs[d][3] = 0x000000ff;//Select
			//dlgRGBs[d][4] = 0x00ff0000;//0x001e1404;//0x00ff0000;//Hot
			//dlgRGBs[d][5] = 0x00748975;//0x00eeaed7;//Hot back
		}
		SendMessage(GetDlgItem(hDlg,IDC_TAB_FILE_SEACH),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_STATIC),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_METHOD),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_STATIC1),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_SEARCH_NAME),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_STATIC2),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_BUTTON_ADD_PATH),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_BUTTON_ADD_DISK),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_SEARCH_PATH),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_TEXT_SEACH),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_SEARCH_FOR_TEXT),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_UNICODE_OR_MULTIBYTE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_BINARY_OR_CHARACTER),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_REGISTR_CAPS),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_NO_TEXT_SEACH),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_UNICODE_OR_MULTIBYTE2),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_BINARY_OR_CHARACTER2),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_REGISTR_CAPS2),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDOK),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDCANCEL),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ALTERNATIVE_NAME),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_ALTERNATIVE_FILE_NAME),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_CREATE_TIME_BEFORE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_CREATE_TIME_AFTER),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_CREATE_DATE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_CREATE_DATE2),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_CREATE_DATE_AFTER),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_CREATE_DATE_AFTER2),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_CREATE_TIME_BETWEEN),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_CREATE_BETWEEN_DATE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_CREATE_BETWEEN_TIME),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_CREATE_BETWEEN_DATE2),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_CREATE_BETWEEN_TIME2),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_ACCESS_TIME_BEFORE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_ACCESS_TIME_AFTER),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE2),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_AFTER),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_AFTER2),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_ACCESS_TIME_BETWEEN),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_BETWEEN),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_TIME_BETWEEN),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_BETWEEN2),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_TIME_BETWEEN2),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_WRITE_TIME_BEFORE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_WRITE_TIME_AFTER),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE2),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_AFTER),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_AFTER2),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_WRITE_TIME_BETWEEN),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_BETWEEN),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_TIME_BETWEEN),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_BETWEEN2),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_TIME_BETWEEN2),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_FILE_SIZE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_FILE_SIZE_EQUATION),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_FILE_SIZE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_FILE_SIZE_QUANTITY),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_FILE_ATTRIBUTE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_ARCHIVE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_COMPRESSED),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_DEVICE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_DIRECTORY),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_ENCRYPTED),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_HIDDEN),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_NORMAL),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_NOT_INDEXED),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_OFFLINE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_READ_ONLY),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_REPARSE_POINT),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_SPARSE_FILE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_SYSTEM),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_TEMPORARY),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_VIRTUAL),WM_SETFONT,(WPARAM)hf,TRUE);
		++hfRef;
		return 0;//GWL_USERDATA
	case WM_DESTROY:
		if(--hfRef<1)
		{	DeleteObject(hf);
			DeleteObject(br);
			DeleteObject(brHtBk);
		}
		search.SaveLBListBuf(hResultsLB);
		hResultsLB = NULL;
		hToPanelBTN=NULL;
		width = 0;
		return 0;
	/*case WM_USER+2://Dinamik o'zgartirish uchun:
		DeleteObject(hf);hfRef=1;
		LOGFONT lf;InitLOGFONT(&lf);
		hf = CreateFontIndirect(&lf));//conf::Dlg.dlgFnts[6]);
		SendMessage(GetDlgItem(hDlg,IDC_TAB_FILE_SEACH),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_STATIC),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_METHOD),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_STATIC1),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_SEARCH_NAME),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_STATIC2),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_BUTTON_ADD_PATH),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_BUTTON_ADD_DISK),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_SEARCH_PATH),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_TEXT_SEACH),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_SEARCH_FOR_TEXT),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_UNICODE_OR_MULTIBYTE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_BINARY_OR_CHARACTER),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_REGISTR_CAPS),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_NO_TEXT_SEACH),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_UNICODE_OR_MULTIBYTE2),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_BINARY_OR_CHARACTER2),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_REGISTR_CAPS2),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDOK),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDCANCEL),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ALTERNATIVE_NAME),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_ALTERNATIVE_FILE_NAME),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_CREATE_TIME_BEFORE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_CREATE_TIME_AFTER),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_CREATE_DATE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_CREATE_DATE2),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_CREATE_DATE_AFTER),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_CREATE_DATE_AFTER2),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_CREATE_TIME_BETWEEN),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_CREATE_BETWEEN_DATE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_CREATE_BETWEEN_TIME),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_CREATE_BETWEEN_DATE2),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_CREATE_BETWEEN_TIME2),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_ACCESS_TIME_BEFORE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_ACCESS_TIME_AFTER),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE2),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_AFTER),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_AFTER2),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_ACCESS_TIME_BETWEEN),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_BETWEEN),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_TIME_BETWEEN),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_BETWEEN2),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_TIME_BETWEEN2),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_WRITE_TIME_BEFORE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_WRITE_TIME_AFTER),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE2),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_AFTER),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_AFTER2),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_WRITE_TIME_BETWEEN),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_BETWEEN),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_TIME_BETWEEN),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_BETWEEN2),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_TIME_BETWEEN2),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_FILE_SIZE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_FILE_SIZE_EQUATION),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_FILE_SIZE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_FILE_SIZE_QUANTITY),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_FILE_ATTRIBUTE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_ARCHIVE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_COMPRESSED),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_DEVICE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_DIRECTORY),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_ENCRYPTED),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_HIDDEN),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_NORMAL),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_NOT_INDEXED),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_OFFLINE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_READ_ONLY),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_REPARSE_POINT),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_SPARSE_FILE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_SYSTEM),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_TEMPORARY),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_VIRTUAL),WM_SETFONT,(WPARAM)hf,TRUE);
		return 0;//GWL_USERDATA
	case WM_USER+3://Dinamik o'zgartirish uchun, colorni:
		DeleteObject(br);DeleteObject(brHtBk);hfRef=1;
		br = CreateSolidBrush(conf::Dlg.dlgRGBs[6][0]);
		brHtBk = CreateSolidBrush(conf::Dlg.dlgRGBs[6][5]);
		RedrawWindow(hDlg,NULL,NULL,RDW_INVALIDATE|RDW_ALLCHILDREN);
		return 0;//GWL_USERDATA*/
	case WM_COMMAND:
		switch(LOWORD(wParam))
		{	case IDOK:
				if(!search.bRun)//Start:
				{	SetDlgItemText(hDlg,IDOK,strngs[43]);

					if(search.iCall)return FALSE;
					if(GetDlgItemText(hDlg,IDC_COMBO_SEARCH_PATH,s,MAX_PATH))
						selV7PthCB.AddToCB(GetDlgItem(hDlg,IDC_COMBO_SEARCH_PATH),s);
					if(GetDlgItemText(hDlg,IDC_COMBO_SEARCH_FOR_TEXT,s,MAX_PATH))
						selV7TxtCB.AddToCB(GetDlgItem(hDlg,IDC_COMBO_SEARCH_FOR_TEXT),s);
					if(GetDlgItemText(hDlg,IDC_COMBO_SEARCH_NOT_TEXT,s,MAX_PATH))
						selV7ExclTxt.AddToCB(GetDlgItem(hDlg,IDC_COMBO_SEARCH_NOT_TEXT),s);
					if(GetDlgItemText(hDlg,IDC_COMBO_SEARCH_NAME,s,MAX_PATH))
						selV7NameCB.AddToCB(GetDlgItem(hDlg,IDC_COMBO_SEARCH_NAME),s);
					selV7PthCB.Save(selV7PthCBFName,GetDlgItem(hDlg,IDC_COMBO_SEARCH_PATH),25);
					selV7TxtCB.Save(selV7TxtCBFName,GetDlgItem(hDlg,IDC_COMBO_SEARCH_FOR_TEXT),25);
					selV7ExclTxt.Save(selV7ExclTxtFName,GetDlgItem(hDlg,IDC_COMBO_SEARCH_NOT_TEXT),25);
					selV7NameCB.Save(selV7NameCBFName,GetDlgItem(hDlg,IDC_COMBO_SEARCH_NAME),25);

					ClearResultsLB();
					CreateResultsLB(hDlg);

					//FILETIME crBef,crAft,crBtwn[2],lastBef,lastAft,lastBtwn[2],
					//lastWrBef,lastWrAft,lastWrBtwn[2];

					search.hDlg = hDlg;
					//search.panel = panel;
					SetFocus(GetDlgItem(hDlg,IDOK));
					//SetThreadPriority(GetCurrentThread(), THREAD_MODE_BACKGROUND_BEGIN);
					//search.hThr = CreateThread(NULL,0,
					//			(LPTHREAD_START_ROUTINE)BeginSearch,
					//			 &search,0,
					//			 &search.thrId);//fSeachViaF7.BeginSearch(panel);
					search.bRun = TRUE;
					/*if(0==panel)//confdan chaqirilgan;
					{	GetDlgItems(search.hDlg);
						EndDialog(hDlg,1);
						return FALSE;//confdan chaqirilgan;
					}*/
   					BeginSearch();
					search.bRun = FALSE;
					SetDlgItemText(hDlg,IDOK,strngs[9]);
					CreateOutptBtns(hDlg);
				}
				else //Stop:
				{	search.bStop = TRUE;
					//LoadString(plgnDllInst,IDS_STRINGSW_3,s,MAX_PATH);
					//SetDlgItemText(hDlg,IDOK,s);
				}
				return FALSE;
			case IDCANCEL:
				//if(0==panel) return FALSE;//confdan chaqirilgan;
				//int r;r = SendMessage(hResultsLB,LB_GETCOUNT,0,0);
				if(!search.iCall)
					EndDialog(hDlg,0);
				return FALSE;
			case IDC_BUTTON_ADD_DISK:
				char *disksStr;disksStr=(char*)DialogBoxParam(plgnDllInst,
							MAKEINTRESOURCE(IDD_DIALOG_SELECT_DISKS),
							hDlg,AddDiskDlgProc,1);
				if(disksStr)
				{GetDlgItemText(hDlg,IDC_COMBO_SEARCH_PATH,s,MAX_PATH);
				 if(!strstr(s,disksStr))
				 {MyStringCat(s,MAX_PATH,disksStr);
				  SetDlgItemText(hDlg,IDC_COMBO_SEARCH_PATH,s);
				}}
				return TRUE;
			case IDC_BUTTON_ADD_PATH:
				BROWSEINFO bi; 
				bi.hwndOwner = hDlg;
				bi.pszDisplayName = s;
				bi.lpszTitle = "Search file folder location:";
				bi.ulFlags = BIF_NONEWFOLDERBUTTON|BIF_DONTGOBELOWDOMAIN|BIF_NEWDIALOGSTYLE|
					BIF_NOTRANSLATETARGETS|BIF_RETURNFSANCESTORS;
				bi.lpfn = NULL;
				LPITEMIDLIST pidlRoot;pidlRoot = NULL;
				bi.pidlRoot = pidlRoot;
				LPITEMIDLIST pidlSelected;pidlSelected = SHBrowseForFolder(&bi);
				if(pidlRoot)
					CoTaskMemFree(pidlRoot);
				if(pidlSelected)
				{if(SHGetPathFromIDList(pidlSelected,s))
				 {	MyStringRemoveLastChar(s,MAX_PATH,'\\');
					MyStringCat(s,MAX_PATH+36,"\\;");
					char st[MAX_PATH+36];GetDlgItemText(hDlg,IDC_COMBO_SEARCH_PATH,st,MAX_PATH);
					if(!strstr(st,s))
					{	MyStringCat(st,MAX_PATH+36,s);
						SetDlgItemText(hDlg,IDC_COMBO_SEARCH_PATH,st);
				  }	}
				  CoTaskMemFree(pidlSelected);
				}
				return TRUE;
			case IDC_CHECK_TEXT_SEACH:
				if(BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_TEXT_SEACH),BM_GETCHECK,0,0))
				{	EnableWindow(GetDlgItem(hDlg,IDC_COMBO_SEARCH_FOR_TEXT),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_UNICODE_OR_MULTIBYTE),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_BINARY_OR_CHARACTER),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_REGISTR_CAPS),TRUE);
				}
				else
				{	EnableWindow(GetDlgItem(hDlg,IDC_COMBO_SEARCH_FOR_TEXT),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_UNICODE_OR_MULTIBYTE),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_BINARY_OR_CHARACTER),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_REGISTR_CAPS),FALSE);
				}
				return (INT_PTR)TRUE;
			case IDC_CHECK_NO_TEXT_SEACH:
				if(BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_NO_TEXT_SEACH),BM_GETCHECK,0,0))
				{	EnableWindow(GetDlgItem(hDlg,IDC_COMBO_SEARCH_NOT_TEXT),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_UNICODE_OR_MULTIBYTE2),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_BINARY_OR_CHARACTER2),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_REGISTR_CAPS2),TRUE);
				}
				else
				{	EnableWindow(GetDlgItem(hDlg,IDC_COMBO_SEARCH_NOT_TEXT),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_UNICODE_OR_MULTIBYTE2),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_BINARY_OR_CHARACTER2),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_REGISTR_CAPS2),FALSE);
				}
				return (INT_PTR)TRUE;
			case IDC_CHECK_UNICODE_OR_MULTIBYTE:
				if(BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_UNICODE_OR_MULTIBYTE),BM_GETCHECK,0,0))
				{	//strngs[6]
					SetDlgItemText(hDlg,IDC_CHECK_UNICODE_OR_MULTIBYTE,"Unicode");
				}
				else
					SetDlgItemText(hDlg,IDC_CHECK_UNICODE_OR_MULTIBYTE,strngs[6]);
				return (INT_PTR)TRUE;
			case IDC_CHECK_UNICODE_OR_MULTIBYTE2:
				if(BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_UNICODE_OR_MULTIBYTE2),BM_GETCHECK,0,0))
				{	//strngs[6]
					SetDlgItemText(hDlg,IDC_CHECK_UNICODE_OR_MULTIBYTE2,"Unicode");
				}
				else
					SetDlgItemText(hDlg,IDC_CHECK_UNICODE_OR_MULTIBYTE2,strngs[6]);
				return (INT_PTR)TRUE;
			case IDC_CHECK_BINARY_OR_CHARACTER:
				if(BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_BINARY_OR_CHARACTER),BM_GETCHECK,0,0))
					SetDlgItemText(hDlg,IDC_CHECK_BINARY_OR_CHARACTER,strngs[42]);
				else
				{	//SetDlgItemText(hDlg,IDC_CHECK_BINARY_OR_CHARACTER,strngs[42]);
					SetDlgItemText(hDlg,IDC_CHECK_BINARY_OR_CHARACTER,"ASCII");
				}
				break;
			case IDC_CHECK_BINARY_OR_CHARACTER2:
				if(BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_BINARY_OR_CHARACTER2),BM_GETCHECK,0,0))
					SetDlgItemText(hDlg,IDC_CHECK_BINARY_OR_CHARACTER2,strngs[42]);
				else
				{	//strngs[42]
					SetDlgItemText(hDlg,IDC_CHECK_BINARY_OR_CHARACTER2,"ASCII");
				}
				break;
			case IDC_CHECK_ALTERNATIVE_NAME:
				if(BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_ALTERNATIVE_NAME),BM_GETCHECK,0,0))
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_ALTERNATIVE_FILE_NAME),TRUE);
				else
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_ALTERNATIVE_FILE_NAME),FALSE);
				break;
			case IDC_CHECK_CREATE_TIME_BEFORE:
				if(BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_CREATE_TIME_BEFORE),BM_GETCHECK,0,0))
				{	//SendMessage(GetDlgItem(hDlg,IDC_CHECK_CREATE_TIME_AFTER),BM_SETCHECK,BST_UNCHECKED,0);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_DATE),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_DATE2),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_DAY),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_MOONS),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_YEAR),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_HOUR),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_MIN),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_SEC),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_MILS),TRUE);
				}
				else
				{	EnableWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_DATE),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_DATE2),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_DAY),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_MOONS),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_YEAR),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_HOUR),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_MIN),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_SEC),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_MILS),FALSE);
				}
				break;
			case IDC_CHECK_CREATE_TIME_AFTER:
				if(BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_CREATE_TIME_AFTER),BM_GETCHECK,0,0))
				{	//SendMessage(GetDlgItem(hDlg,IDC_CHECK_CREATE_TIME_BEFORE),BM_SETCHECK,BST_UNCHECKED,0);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_DATE_AFTER),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_DATE_AFTER2),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_DAY),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_MOON),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_YEAR),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_HOUR),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_MIN),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_SEC),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_MILS),TRUE);
				}
				else
				{	EnableWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_DATE_AFTER),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_DATE_AFTER2),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_DAY),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_MOON),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_YEAR),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_HOUR),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_MIN),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_SEC),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_MILS),FALSE);
				}
				break;				 
			case IDC_CHECK_CREATE_TIME_BETWEEN:
				if(BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_CREATE_TIME_BETWEEN),BM_GETCHECK,0,0))
				{	EnableWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_BETWEEN_DATE),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_BETWEEN_TIME),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_BETWEEN_DATE2),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_BETWEEN_TIME2),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_DAY),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_MOONS),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_YEAR),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_HOUR),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_MIN),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_SEC),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_MILS),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_DAY),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_MOON),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_YEAR),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_HOUR),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_MIN),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_SEC),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_MILS),TRUE);
				}
				else
				{	EnableWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_BETWEEN_DATE),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_BETWEEN_TIME),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_BETWEEN_DATE2),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_BETWEEN_TIME2),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_DAY),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_MOONS),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_YEAR),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_HOUR),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_MIN),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_SEC),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_MILS),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_DAY),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_MOON),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_YEAR),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_HOUR),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_MIN),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_SEC),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_MILS),FALSE);
				}
				break;
			case IDC_CHECK_LAST_ACCESS_TIME_BETWEEN:
				if(BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_ACCESS_TIME_BETWEEN),BM_GETCHECK,0,0))
				{	EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_BETWEEN),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_TIME_BETWEEN),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_BETWEEN2),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_TIME_BETWEEN2),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_DAY),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_MOON),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_YEAR),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_HOUR),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_MIN),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_SEC),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_MILS),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_DAY),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_MOON),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_YEAR),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_HOUR),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_MIN),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_SEC),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_MILS),TRUE);
				}
				else
				{	EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_BETWEEN),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_TIME_BETWEEN),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_BETWEEN2),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_TIME_BETWEEN2),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_DAY),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_MOON),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_YEAR),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_HOUR),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_MIN),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_SEC),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_MILS),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_DAY),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_MOON),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_YEAR),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_HOUR),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_MIN),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_SEC),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_MILS),FALSE);
				}
				break;
			case IDC_CHECK_LAST_WRITE_TIME_BETWEEN:
				if(BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_WRITE_TIME_BETWEEN),BM_GETCHECK,0,0))
				{	EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_BETWEEN),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_TIME_BETWEEN),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_BETWEEN2),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_TIME_BETWEEN2),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_DAY),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_MOON),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_YEAR),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_HOUR),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_MIN),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_SEC),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_MILS),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_DAY),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_MOON),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_YEAR),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_HOUR),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_MIN),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_SEC),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_MILS),TRUE);
				}
				else
				{	EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_BETWEEN),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_TIME_BETWEEN),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_BETWEEN2),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_TIME_BETWEEN2),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_DAY),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_MOON),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_YEAR),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_HOUR),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_MIN),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_SEC),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_MILS),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_DAY),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_MOON),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_YEAR),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_HOUR),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_MIN),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_SEC),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_MILS),FALSE);
				}
				break;
			case IDC_CHECK_LAST_ACCESS_TIME_BEFORE:
				if(BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_ACCESS_TIME_BEFORE),BM_GETCHECK,0,0))
				{	//SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_ACCESS_TIME_AFTER),BM_SETCHECK,BST_UNCHECKED,0);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE2),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_DAY),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_MOONS),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_YEAR),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_HOUR),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_MIN),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_SEC),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_MILS),TRUE);
				}
				else
				{	EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE2),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_DAY),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_MOONS),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_YEAR),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_HOUR),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_MIN),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_SEC),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_MILS),FALSE);
				}
				break;
			case IDC_CHECK_LAST_ACCESS_TIME_AFTER:
				if(BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_ACCESS_TIME_AFTER),BM_GETCHECK,0,0))
				{	//SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_ACCESS_TIME_BEFORE),BM_SETCHECK,BST_UNCHECKED,0);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_AFTER),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_AFTER2),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_DAY),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_MOON),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_YEAR),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_HOUR),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_MIN),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_SEC),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_MILS),TRUE);
				}
				else
				{	EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_AFTER),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_AFTER2),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_DAY),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_MOON),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_YEAR),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_HOUR),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_MIN),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_SEC),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_MILS),FALSE);
				}
				break;
			case IDC_CHECK_LAST_WRITE_TIME_BEFORE:
				if(BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_WRITE_TIME_BEFORE),BM_GETCHECK,0,0))
				{	//SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_WRITE_TIME_AFTER),BM_SETCHECK,BST_UNCHECKED,0);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE2),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_DAY),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_MOON),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_YEAR),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_HOUR),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_MIN),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_SEC),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_MILS),TRUE);
				}
				else
				{	EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE2),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_DAY),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_MOON),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_YEAR),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_HOUR),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_MIN),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_SEC),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_MILS),FALSE);
				}
				break;
			case IDC_CHECK_LAST_WRITE_TIME_AFTER:
				if(BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_WRITE_TIME_AFTER),BM_GETCHECK,0,0))
				{	//SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_WRITE_TIME_BEFORE),BM_SETCHECK,BST_UNCHECKED,0);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_AFTER),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_AFTER2),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_DAY),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_MOON),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_YEAR),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_HOUR),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_MIN),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_SEC),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_MILS),TRUE);
				}
				else
				{	EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_AFTER),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_AFTER2),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_DAY),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_MOON),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_YEAR),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_HOUR),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_MIN),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_SEC),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_MILS),FALSE);
				}
				break;
			case IDC_CHECK_FILE_SIZE:
				if(BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_FILE_SIZE),BM_GETCHECK,0,0))
				{	EnableWindow(GetDlgItem(hDlg,IDC_COMBO_FILE_SIZE_EQUATION),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_FILE_SIZE),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_FILE_SIZE),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_COMBO_FILE_SIZE_QUANTITY),TRUE);
				}
				else
				{	EnableWindow(GetDlgItem(hDlg,IDC_COMBO_FILE_SIZE_EQUATION),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_FILE_SIZE),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_FILE_SIZE),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_COMBO_FILE_SIZE_QUANTITY),FALSE);
				}
				break;
			case IDC_CHECK_FILE_ATTRIBUTE:
				if(BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_FILE_ATTRIBUTE),BM_GETCHECK,0,0))
				{	EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_ARCHIVE),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_COMPRESSED),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_DEVICE),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_DIRECTORY),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_ENCRYPTED),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_HIDDEN),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_NORMAL),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_NOT_INDEXED),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_OFFLINE),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_READ_ONLY),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_REPARSE_POINT),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_SPARSE_FILE),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_SYSTEM),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_TEMPORARY),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_VIRTUAL),TRUE);
				}
				else
				{	EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_ARCHIVE),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_COMPRESSED),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_DEVICE),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_DIRECTORY),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_ENCRYPTED),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_HIDDEN),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_NORMAL),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_NOT_INDEXED),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_OFFLINE),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_READ_ONLY),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_REPARSE_POINT),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_SPARSE_FILE),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_SYSTEM),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_TEMPORARY),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_VIRTUAL),FALSE);
				}
				break;
			case IDC_CHECK_ENUM_SUBDIR:
				schConf.bEnumSubDir=(BST_CHECKED==SendMessage(
						GetDlgItem(hDlg,IDC_CHECK_ENUM_SUBDIR),BM_GETCHECK,0,0)) ? 1 : 0;
				break;
			case IDC_COMBO_METHOD:
				schConf.iEnumMethod = SendMessage(GetDlgItem(hDlg,IDC_COMBO_METHOD),CB_GETCURSEL,0,0);
				if(schConf.iEnumMethod<0)schConf.iEnumMethod=0;
				if(schConf.iEnumMethod>1)schConf.iEnumMethod=1;
				break;
			case IDC_EDIT_CREATE_DATE:
			case IDC_EDIT_CREATE_DATE_AFTER:
			case IDC_EDIT_CREATE_BETWEEN_DATE:
			case IDC_EDIT_CREATE_BETWEEN_DATE2:
			case IDC_EDIT_LAST_ACCESS_DATE:
			case IDC_EDIT_LAST_ACCESS_DATE_AFTER:
			case IDC_EDIT_LAST_ACCESS_DATE_BETWEEN:
			case IDC_EDIT_LAST_ACCESS_DATE_BETWEEN2:
			case IDC_EDIT_LAST_WRITE_DATE:
			case IDC_EDIT_LAST_WRITE_DATE_AFTER:
			case IDC_EDIT_LAST_WRITE_DATE_BETWEEN:
			case IDC_EDIT_LAST_WRITE_DATE_BETWEEN2:
				if(EN_KILLFOCUS==HIWORD(wParam))
				{	if(GetWindowText((HWND)lParam,s,MAX_PATH))
					{	//first 2 char before '.' - day of month
						if(s[0] < '0') s[0] = '0';
						if(s[0] > '3') s[0] = '3';
						if(s[1] < (s[0]<'1'?'1':'0')) s[1] = s[0]<'1'?'1':'0';
						if(s[1] > (s[0]<'3'?'9':'1')) s[1] = s[0]<'3'?'9':'1';
						if(s[2] != '.') s[2] = '.';
						//second 2 char after first '.' - month
						if(s[3] < '0') s[3] = '0';
						if(s[3] > '1') s[3] = '1';
						if(s[4] < (s[3]<'1'?'1':'0')) s[4] = s[3]<'1'?'1':'0';
						if(s[4] > (s[3]<'1'?'9':'2')) s[4] = s[3]<'1'?'9':'2';
						if(s[5] != '.') s[5] = '.';
						//last 2 char after second '.' - year
						if(s[6] < '0') s[6] = '0';
						if(s[6] > '9') s[6] = '9';
						if(s[7] < '0') s[7] = '0';
						if(s[7] > '9') s[7] = '9';
						if(s[8] < '0') s[8] = '0';
						if(s[8] > '9') s[8] = '9';
						if(s[9] < '0') s[9] = '0';
						if(s[9] > '9') s[9] = '9';
						s[10] = 0;
						SetWindowText((HWND)lParam,s);
				}	}
				break;
			case IDC_EDIT_CREATE_DATE2:
			case IDC_EDIT_CREATE_DATE_AFTER2:
			case IDC_EDIT_CREATE_BETWEEN_TIME:
			case IDC_EDIT_CREATE_BETWEEN_TIME2:
			case IDC_EDIT_LAST_ACCESS_DATE2:
			case IDC_EDIT_LAST_ACCESS_DATE_AFTER2:
			case IDC_EDIT_LAST_ACCESS_TIME_BETWEEN:
			case IDC_EDIT_LAST_ACCESS_TIME_BETWEEN2:
			case IDC_EDIT_LAST_WRITE_DATE2:
			case IDC_EDIT_LAST_WRITE_DATE_AFTER2:
			case IDC_EDIT_LAST_WRITE_TIME_BETWEEN:
			case IDC_EDIT_LAST_WRITE_TIME_BETWEEN2:
				if(EN_KILLFOCUS==HIWORD(wParam))
				{	if(GetWindowText((HWND)lParam,s,MAX_PATH))
					{	//first 2 char before '.' - hour
						if(s[0] < '0') s[0] = '0';
						if(s[0] > '2') s[0] = '2';
						if(s[1] < '0') s[1] = '0';
						if(s[1] > (s[0]<'2'?'9':'4')) s[1] = s[0]<'2'?'9':'4';
						if(s[2] != '.') s[2] = '.';
						//second 2 char after first '.' - minute
						if(s[3] < '0') s[3] = '0';
						if(s[3] > '6') s[3] = '6';
						if(s[4] < '0') s[4] = '0';
						if(s[4] > (s[3]<'6'?'9':'0')) s[4] = s[3]<'6'?'9':'0';
						if(s[5] != '.') s[5] = '.';
						//third 2 char after second '.' - second
						if(s[6] < '0') s[6] = '0';
						if(s[6] > '6') s[6] = '6';
						if(s[7] < '0') s[7] = '0';
						if(s[7] > (s[6]<'6'?'9':'0')) s[7] = s[6]<'6'?'9':'0';
						if(s[8] != '.') s[8] = '.';
						//last 2 char - millisecond
						if(s[9] < '0') s[9] = '0';
						if(s[9] > '9') s[9] = '9';
						if(s[10] < '0') s[10] = '0';
						if(s[10] > '9') s[10] = '9';
						if(s[11] < '0') s[11] = '0';
						if(s[11] > '9') s[11] = '9';
						s[12] = 0;
						SetWindowText((HWND)lParam,s);
				}	}
				break;
			case IDC_BUTTON_BROWSE://hBrowseBTN
				if(hBrowseBTN)
				{	int sel,ln;if(LB_ERR!=SendMessage(hResultsLB,LB_GETSELITEMS,1,(LPARAM)&sel))
					ln=SendMessage(hResultsLB,LB_GETTEXTLEN,sel,0);
					if(LB_ERR!=ln)
					{TCHAR *buf; buf = (TCHAR*)_malloca((ln+2)*sizeof(TCHAR));
					 if(LB_ERR!=SendMessage(hResultsLB,LB_GETTEXT,sel,(LPARAM)buf))
					 {	//EndDialog(hDlg,0);
						if('<'==buf[0])//Directory:
						{	buf[ln-1] = 0;//'\\';
							//buf[ln] = '*';
							//buf[ln+1] = 0;
							ShellExecute(hDlg,"explore",&buf[1],NULL,&buf[1],SW_SHOW);//SW_SHOWNORMAL);
						}
						else //file:
						{	char *p = strrchr(buf,'\\');
							if(p){ *p = 0;/*'\\'; *(p+1) = '*'; *(p+2) = 0;*/}
							else {buf[ln] = 0;/*'\\';buf[ln+1] = '*';buf[ln+2] = 0;*/}
							ShellExecute(hDlg,"explore",buf,NULL,buf,SW_SHOW);
				 	 }	}
					 _freea(buf);
				 }	}
				break;
			case IDC_BUTTON_TO_PANEL://hToPanelBTN
				if(hToPanelBTN)
					EndDialog(hDlg,2);
				break;
			case IDC_BUTTON_EDIT:
				if(hEditBTN)
				{	int sel,ln;if(LB_ERR!=SendMessage(hResultsLB,LB_GETSELITEMS,1,(LPARAM)&sel))
					ln=SendMessage(hResultsLB,LB_GETTEXTLEN,sel,0);
					if(LB_ERR!=ln)
					{TCHAR *buf; buf = (TCHAR*)_malloca((ln+2)*sizeof(TCHAR));
					 if(LB_ERR!=SendMessage(hResultsLB,LB_GETTEXT,sel,(LPARAM)buf))
					 {	if('<'!=buf[0])//file:
							ShellExecute(hDlg,"edit",buf,NULL,buf,SW_SHOW);
				 	 }
					 _freea(buf);
				 }	}
				break;
			case IDC_BUTTON_VIEW:
				if(hViewBTN)
				{	int sel,ln;if(LB_ERR!=SendMessage(hResultsLB,LB_GETSELITEMS,1,(LPARAM)&sel))
					ln=SendMessage(hResultsLB,LB_GETTEXTLEN,sel,0);
					if(LB_ERR!=ln)
					{TCHAR *buf; buf = (TCHAR*)_malloca((ln+2)*sizeof(TCHAR));
					 if(LB_ERR!=SendMessage(hResultsLB,LB_GETTEXT,sel,(LPARAM)buf))
					 {	if('<'!=buf[0])//file:
							ShellExecute(hDlg,"open",buf,NULL,buf,SW_SHOW);
				 	 }
					 _freea(buf);
				 }	}
				break;
		}
		break;
	case WM_NOTIFY:
		NMHDR *lpnmhdr;lpnmhdr = (LPNMHDR)lParam;
		switch(lpnmhdr->idFrom)
		{	case IDC_TAB_FILE_SEACH:
				if(TCN_SELCHANGE == lpnmhdr->code)
				{	int id;
					id = TabCtrl_GetCurSel(GetDlgItem(hDlg,IDC_TAB_FILE_SEACH));
					SetTabPage(hDlg,id);
				}
				break;
			//case IDC_SPIN_FILE_SIZE:
				//OutputDebugString(" IDC_SPIN_FILE_SIZE");
			//	break;
		}
		break;
	case WM_VSCROLL:
		unsigned __int64 szFile;szFile = 0;
		if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_FILE_SIZE))
		{	if(SB_THUMBPOSITION==LOWORD(wParam) || SB_THUMBTRACK==LOWORD(wParam))
			{	if(HIWORD(wParam)>50)
				{	if(GetDlgItemText(hDlg,IDC_EDIT_FILE_SIZE,s,MAX_PATH))
						szFile = MyAtoU64(s);
					MyU64ToA(s,MAX_PATH,++szFile);//StringCchPrintf(s,MAX_PATH,"%u",++szFile);
					SetDlgItemText(hDlg,IDC_EDIT_FILE_SIZE,s);
				} else
				{	if(GetDlgItemText(hDlg,IDC_EDIT_FILE_SIZE,s,MAX_PATH))
						szFile = MyAtoU64(s);
					if(szFile>0)szFile--;
					MyU64ToA(s,MAX_PATH,szFile);
					SetDlgItemText(hDlg,IDC_EDIT_FILE_SIZE,s);
			}	}
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_CRTBEF_DAY))
		{	AlignDayFrSpin(hDlg,wParam,IDC_EDIT_CREATE_DATE,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_CRTBEF_MOONS))
		{	AlignMoonFrSpin(hDlg,wParam,IDC_EDIT_CREATE_DATE,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_CRTBEF_YEAR))
		{	AlignYearFrSpin(hDlg,wParam,IDC_EDIT_CREATE_DATE,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_CRTBEF_HOUR))
		{	AlignHourFrSpin(hDlg,wParam,IDC_EDIT_CREATE_DATE2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_CRTBEF_MIN))
		{	AlignMinFrSpin(hDlg,wParam,IDC_EDIT_CREATE_DATE2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_CRTBEF_SEC))
		{	AlignSecFrSpin(hDlg,wParam,IDC_EDIT_CREATE_DATE2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_CRTBEF_MILS))
		{	AlignMilsFrSpin(hDlg,wParam,IDC_EDIT_CREATE_DATE2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_CRTBET_DAY))
		{	AlignDayFrSpin(hDlg,wParam,IDC_EDIT_CREATE_BETWEEN_DATE,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_CRTBET_MOONS))
		{	AlignMoonFrSpin(hDlg,wParam,IDC_EDIT_CREATE_BETWEEN_DATE,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_CRTBET_YEAR))
		{	AlignYearFrSpin(hDlg,wParam,IDC_EDIT_CREATE_BETWEEN_DATE,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_CRTBET_HOUR))
		{	AlignHourFrSpin(hDlg,wParam,IDC_EDIT_CREATE_BETWEEN_TIME,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_CRTBET_MIN))
		{	AlignMinFrSpin(hDlg,wParam,IDC_EDIT_CREATE_BETWEEN_TIME,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_CRTBET_SEC))
		{	AlignSecFrSpin(hDlg,wParam,IDC_EDIT_CREATE_BETWEEN_TIME,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_CRTBET_MILS))
		{	AlignMilsFrSpin(hDlg,wParam,IDC_EDIT_CREATE_BETWEEN_TIME,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_CRBET_DAY))
		{	AlignDayFrSpin(hDlg,wParam,IDC_EDIT_CREATE_BETWEEN_DATE2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_CRBET_MOON))
		{	AlignMoonFrSpin(hDlg,wParam,IDC_EDIT_CREATE_BETWEEN_DATE2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_CRBET_YEAR))
		{	AlignYearFrSpin(hDlg,wParam,IDC_EDIT_CREATE_BETWEEN_DATE2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_CRBET_HOUR))
		{	AlignHourFrSpin(hDlg,wParam,IDC_EDIT_CREATE_BETWEEN_TIME2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_CRBET_MIN))
		{	AlignMinFrSpin(hDlg,wParam,IDC_EDIT_CREATE_BETWEEN_TIME2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_CRBET_SEC))
		{	AlignSecFrSpin(hDlg,wParam,IDC_EDIT_CREATE_BETWEEN_TIME2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_CRBET_MILS))
		{	AlignMilsFrSpin(hDlg,wParam,IDC_EDIT_CREATE_BETWEEN_TIME2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_CRAFT_DAY))
		{	AlignDayFrSpin(hDlg,wParam,IDC_EDIT_CREATE_DATE_AFTER,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_CRAFT_MOON))
		{	AlignMoonFrSpin(hDlg,wParam,IDC_EDIT_CREATE_DATE_AFTER,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_CRAFT_YEAR))
		{	AlignYearFrSpin(hDlg,wParam,IDC_EDIT_CREATE_DATE_AFTER,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_CRAFT_HOUR))
		{	AlignHourFrSpin(hDlg,wParam,IDC_EDIT_CREATE_DATE_AFTER2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_CRAFT_MIN))
		{	AlignMinFrSpin(hDlg,wParam,IDC_EDIT_CREATE_DATE_AFTER2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_CRAFT_SEC))
		{	AlignSecFrSpin(hDlg,wParam,IDC_EDIT_CREATE_DATE_AFTER2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_CRAFT_MILS))
		{	AlignMilsFrSpin(hDlg,wParam,IDC_EDIT_CREATE_DATE_AFTER2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSTBEF_DAY))
		{	AlignDayFrSpin(hDlg,wParam,IDC_EDIT_LAST_ACCESS_DATE,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSTBEF_MOONS))
		{	AlignMoonFrSpin(hDlg,wParam,IDC_EDIT_LAST_ACCESS_DATE,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSTBEF_YEAR))
		{	AlignYearFrSpin(hDlg,wParam,IDC_EDIT_LAST_ACCESS_DATE,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSTBEF_HOUR))
		{	AlignHourFrSpin(hDlg,wParam,IDC_EDIT_LAST_ACCESS_DATE2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSTBEF_MIN))
		{	AlignMinFrSpin(hDlg,wParam,IDC_EDIT_LAST_ACCESS_DATE2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSTBEF_SEC))
		{	AlignSecFrSpin(hDlg,wParam,IDC_EDIT_LAST_ACCESS_DATE2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSTBEF_MILS))
		{	AlignMilsFrSpin(hDlg,wParam,IDC_EDIT_LAST_ACCESS_DATE2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSWTBET_DAY))
		{	AlignDayFrSpin(hDlg,wParam,IDC_EDIT_LAST_WRITE_DATE_BETWEEN,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSWTBET_MOON))
		{	AlignMoonFrSpin(hDlg,wParam,IDC_EDIT_LAST_WRITE_DATE_BETWEEN,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSWTBET_YEAR))
		{	AlignYearFrSpin(hDlg,wParam,IDC_EDIT_LAST_WRITE_DATE_BETWEEN,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSWTBET_HOUR))
		{	AlignHourFrSpin(hDlg,wParam,IDC_EDIT_LAST_WRITE_TIME_BETWEEN,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSWTBET_MIN))
		{	AlignMinFrSpin(hDlg,wParam,IDC_EDIT_LAST_WRITE_TIME_BETWEEN,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSWTBET_SEC))
		{	AlignSecFrSpin(hDlg,wParam,IDC_EDIT_LAST_WRITE_TIME_BETWEEN,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSWTBET_MILS))
		{	AlignMilsFrSpin(hDlg,wParam,IDC_EDIT_LAST_WRITE_TIME_BETWEEN,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSWRBET_DAY))
		{	AlignDayFrSpin(hDlg,wParam,IDC_EDIT_LAST_WRITE_DATE_BETWEEN2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSWRBET_MOON))
		{	AlignMoonFrSpin(hDlg,wParam,IDC_EDIT_LAST_WRITE_DATE_BETWEEN2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSWRBET_YEAR))
		{	AlignYearFrSpin(hDlg,wParam,IDC_EDIT_LAST_WRITE_DATE_BETWEEN2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSWRBET_HOUR))
		{	AlignHourFrSpin(hDlg,wParam,IDC_EDIT_LAST_WRITE_TIME_BETWEEN2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSWRBET_MIN))
		{	AlignMinFrSpin(hDlg,wParam,IDC_EDIT_LAST_WRITE_TIME_BETWEEN2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSWRBET_SEC))
		{	AlignSecFrSpin(hDlg,wParam,IDC_EDIT_LAST_WRITE_TIME_BETWEEN2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSWRBET_MILS))
		{	AlignMilsFrSpin(hDlg,wParam,IDC_EDIT_LAST_WRITE_TIME_BETWEEN2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSAFT_DAY))
		{	AlignDayFrSpin(hDlg,wParam,IDC_EDIT_LAST_ACCESS_DATE_AFTER,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSAFT_MOON))
		{	AlignMoonFrSpin(hDlg,wParam,IDC_EDIT_LAST_ACCESS_DATE_AFTER,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSAFT_YEAR))
		{	AlignYearFrSpin(hDlg,wParam,IDC_EDIT_LAST_ACCESS_DATE_AFTER,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSAFT_HOUR))
		{	AlignHourFrSpin(hDlg,wParam,IDC_EDIT_LAST_ACCESS_DATE_AFTER2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSAFT_MIN))
		{	AlignMinFrSpin(hDlg,wParam,IDC_EDIT_LAST_ACCESS_DATE_AFTER2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSAFT_SEC))
		{	AlignSecFrSpin(hDlg,wParam,IDC_EDIT_LAST_ACCESS_DATE_AFTER2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSAFT_MILS))
		{	AlignMilsFrSpin(hDlg,wParam,IDC_EDIT_LAST_ACCESS_DATE_AFTER2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSTBET_DAY))
		{	AlignDayFrSpin(hDlg,wParam,IDC_EDIT_LAST_ACCESS_DATE_BETWEEN,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSTBET_MOON))
		{	AlignMoonFrSpin(hDlg,wParam,IDC_EDIT_LAST_ACCESS_DATE_BETWEEN,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSTBET_YEAR))
		{	AlignYearFrSpin(hDlg,wParam,IDC_EDIT_LAST_ACCESS_DATE_BETWEEN,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSTBET_HOUR))
		{	AlignHourFrSpin(hDlg,wParam,IDC_EDIT_LAST_ACCESS_TIME_BETWEEN,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSTBET_MIN))
		{	AlignMinFrSpin(hDlg,wParam,IDC_EDIT_LAST_ACCESS_TIME_BETWEEN,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSTBET_SEC))
		{	AlignSecFrSpin(hDlg,wParam,IDC_EDIT_LAST_ACCESS_TIME_BETWEEN,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSTBET_MILS))
		{	AlignMilsFrSpin(hDlg,wParam,IDC_EDIT_LAST_ACCESS_TIME_BETWEEN,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSABET_DAY))
		{	AlignDayFrSpin(hDlg,wParam,IDC_EDIT_LAST_ACCESS_DATE_BETWEEN2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSABET_MOON))
		{	AlignMoonFrSpin(hDlg,wParam,IDC_EDIT_LAST_ACCESS_DATE_BETWEEN2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSABET_YEAR))
		{	AlignYearFrSpin(hDlg,wParam,IDC_EDIT_LAST_ACCESS_DATE_BETWEEN2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSABET_HOUR))
		{	AlignHourFrSpin(hDlg,wParam,IDC_EDIT_LAST_ACCESS_TIME_BETWEEN2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSABET_MIN))
		{	AlignMinFrSpin(hDlg,wParam,IDC_EDIT_LAST_ACCESS_TIME_BETWEEN2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSABET_SEC))
		{	AlignSecFrSpin(hDlg,wParam,IDC_EDIT_LAST_ACCESS_TIME_BETWEEN2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSABET_MILS))
		{	AlignMilsFrSpin(hDlg,wParam,IDC_EDIT_LAST_ACCESS_TIME_BETWEEN2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_DAY))
		{	AlignDayFrSpin(hDlg,wParam,IDC_EDIT_LAST_WRITE_DATE,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_MOON))
		{	AlignMoonFrSpin(hDlg,wParam,IDC_EDIT_LAST_WRITE_DATE,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_YEAR))
		{	AlignYearFrSpin(hDlg,wParam,IDC_EDIT_LAST_WRITE_DATE,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_HOUR))
		{	AlignHourFrSpin(hDlg,wParam,IDC_EDIT_LAST_WRITE_DATE2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_MIN))
		{	AlignMinFrSpin(hDlg,wParam,IDC_EDIT_LAST_WRITE_DATE2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_SEC))
		{	AlignSecFrSpin(hDlg,wParam,IDC_EDIT_LAST_WRITE_DATE2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_MILS))
		{	AlignMilsFrSpin(hDlg,wParam,IDC_EDIT_LAST_WRITE_DATE2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_DAY))
		{	AlignDayFrSpin(hDlg,wParam,IDC_EDIT_LAST_WRITE_DATE_AFTER,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_MOON))
		{	AlignMoonFrSpin(hDlg,wParam,IDC_EDIT_LAST_WRITE_DATE_AFTER,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_YEAR))
		{	AlignYearFrSpin(hDlg,wParam,IDC_EDIT_LAST_WRITE_DATE_AFTER,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_HOUR))
		{	AlignHourFrSpin(hDlg,wParam,IDC_EDIT_LAST_WRITE_DATE_AFTER2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_MIN))
		{	AlignMinFrSpin(hDlg,wParam,IDC_EDIT_LAST_WRITE_DATE_AFTER2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_SEC))
		{	AlignSecFrSpin(hDlg,wParam,IDC_EDIT_LAST_WRITE_DATE_AFTER2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_MILS))
		{	AlignMilsFrSpin(hDlg,wParam,IDC_EDIT_LAST_WRITE_DATE_AFTER2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		break;
	case WM_CONTEXTMENU:
		if(wParam==(WPARAM)hResultsLB)
		{	POINT pt;pt.x = LOWORD(lParam);
			pt.y = HIWORD(lParam);
			ScreenToClient(hResultsLB,&pt);
			int r=SendMessage(hResultsLB,LB_ITEMFROMPOINT,0,MAKELONG(pt.x,pt.y));
			r &= 0xffff;
			r=SendMessage(hResultsLB,LB_GETTEXT,r,(LPARAM)s);
			if(LB_ERR!=r)
			{	//myWMI::TAddtnMenuItems it;
				if(s[0]=='<')
				{	s[r-1]=0;
					//it.pNext = NULL;
					//it.itemStr = s;
					//it.iPan = this-&panel[0];
					//it.iPanItem = id;
					//it.iMsg = IDM_FILE_STREAM;
					DoExplorerMenu(hResultsLB,&s[1],&pt,NULL);//&it);
				}
				else
					DoExplorerMenu(hResultsLB,s,&pt,NULL);//&it);
		}	}
		break;
	}
	return (INT_PTR)FALSE;
}

void ResizeChilds(HWND dlg, int w, int h)
{
	width = w; height = h;

	SetWindowPos(GetDlgItem(dlg,IDC_TAB_FILE_SEACH),HWND_BOTTOM,3,3,w-7,420,SWP_SHOWWINDOW);//MoveWindow(GetDlgItem(dlg,IDC_TAB_FILE_SEACH),3,3,w-7,420,TRUE);//3 3 370 260
	SetWindowPos(GetDlgItem(dlg,IDC_STATIC),HWND_TOP,w-170,5,47,14,SWP_SHOWWINDOW);//268 5 27 8
	SetWindowPos(GetDlgItem(dlg,IDC_COMBO_METHOD),HWND_TOP,w-116,1,114,12,SWP_SHOWWINDOW);//297 1 78 12

	if(hResultsLB)
	{	SetWindowPos(hInfoEdit,HWND_TOP,2,448,w-4,22,SWP_SHOWWINDOW);
		SetWindowPos(hResultsLB,HWND_TOP,2,472,w-4,h-minHeight+14,SWP_SHOWWINDOW);
	}

	int id = TabCtrl_GetCurSel(GetDlgItem(dlg,IDC_TAB_FILE_SEACH));
	//if(0==id)
	//{
		//SetWindowPos(GetDlgItem(dlg,IDC_BUTTON_ADD_PATH),HWND_TOP,w-204,78,95,17,SWP_SHOWWINDOW);//210 46 77 13
		//SetWindowPos(GetDlgItem(dlg,IDC_BUTTON_ADD_DISK),HWND_TOP,w-106,78,95,17,SWP_SHOWWINDOW);//288 46 77 13

		SetWindowPos(GetDlgItem(dlg,IDC_COMBO_SEARCH_FOR_TEXT),HWND_TOP,7,138,w-14,12,id?SWP_HIDEWINDOW:SWP_SHOWWINDOW);//7 85 361 12
		SetWindowPos(GetDlgItem(dlg,IDC_COMBO_SEARCH_NOT_TEXT),HWND_TOP,7,268,w-14,12,id?SWP_HIDEWINDOW:SWP_SHOWWINDOW);
	
		SetWindowPos(GetDlgItem(dlg,IDC_COMBO_SEARCH_PATH),HWND_TOP,7,95,w-14,12,id?SWP_HIDEWINDOW:SWP_SHOWWINDOW);//7 59 361 12
	
		SetWindowPos(GetDlgItem(dlg,IDC_COMBO_SEARCH_NAME),HWND_TOP,7,50,w-14,12,
			id?SWP_HIDEWINDOW:SWP_SHOWWINDOW);//7 30 361 12
	//}

	/*IDCANCEL
	IDOK
	IDC_EDIT_ALTERNATIVE_FILE_NAME*/
}

INT_PTR CALLBACK AddDiskDlgProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
static HFONT hf=0;
static int hfRef=0;//obshiy hf, dinamik uchun emas:
static HBRUSH br=0;
static HBRUSH brHtBk=0;
	UNREFERENCED_PARAMETER(lParam);
	
	switch (message)
	{
	case WM_INITDIALOG:RECT rc1;int left,top;
		//Adjust to center:
		GetWindowRect(hDlg, &rc1);
		width = rc1.right - rc1.left;		
		left = (GetSystemMetrics(SM_CXFULLSCREEN) - width)/2;
		height = rc1.bottom - rc1.top;
		top = (GetSystemMetrics(SM_CYFULLSCREEN) - height)/2;
		MoveWindow(hDlg, left, top+20, width, height, TRUE);

		char s[MAX_PATH];
		SetWindowText(hDlg,strngs[2]);
		SetDlgItemText(hDlg,IDC_BUTTON_ALL_DISKS,strngs[44]);
		SetDlgItemText(hDlg,IDC_BUTTON_ALL_FIXED_DISKS,strngs[45]);
		SetDlgItemText(hDlg,IDOK,strngs[10]);

		for(int i=0; i<GetTotalLogicalDrives(); i++)
		{	SendMessage(GetDlgItem(hDlg,IDC_COMBO_DISKS),CB_ADDSTRING,0,
				(LPARAM)GetLogicalDriveName(i));
		}
		SetDlgItemText(hDlg,IDC_COMBO_DISKS,GetLogicalDriveName(0));
		SendMessage(hDlg,WM_USER+1,0,0);
		SetWindowLong(hDlg,GWL_USERDATA,lParam);
		return TRUE;
	case WM_CTLCOLORSTATIC:
	case WM_CTLCOLORDLG:HDC dc;dc = (HDC)wParam;
		SetTextColor(dc,RGB(0x8a,0,0));//conf::Dlg.dlgRGBs[7][1]);
		SetBkColor(dc,RGB(0xec,0xe1,0xec));//conf::Dlg.dlgRGBs[7][2]);
		return (INT_PTR)br;
	case WM_CTLCOLOREDIT:dc = (HDC)wParam;
		SetTextColor(dc,RGB(0x8a,0,0));//conf::Dlg.dlgRGBs[7][1]);
		SetBkColor(dc,RGB(0xec,0xe1,0xec));//conf::Dlg.dlgRGBs[7][2]);
		return (INT_PTR)br;
	case WM_CTLCOLORBTN:dc=(HDC)wParam;
		SetTextColor(dc,RGB(0,0,0xff));//conf::Dlg.dlgRGBs[7][1]);
		SetBkColor(dc,RGB(0xee,0xae,0xd7));//conf::Dlg.dlgRGBs[7][2]);
		return (INT_PTR)brHtBk;
	case WM_DRAWITEM:RECT rc;//WM_CTLCOLORBTN dagi knopkalar:
		LPDRAWITEMSTRUCT lpdis;lpdis = (LPDRAWITEMSTRUCT)lParam;
		GetWindowText(lpdis->hwndItem,s,64);
		UINT uStyle;uStyle = DFCS_BUTTONPUSH;
		rc = lpdis->rcItem;
		if(lpdis->itemState & ODS_SELECTED)
		{	uStyle |= DFCS_PUSHED|DFCS_TRANSPARENT;
			rc.left+=2;rc.top+=2;
		}
		DrawFrameControl(lpdis->hDC, &lpdis->rcItem, DFC_BUTTON, uStyle);
		if(lpdis->itemState & ODS_SELECTED)
			{rc.left+=1;rc.top+=1;rc.bottom-=2;rc.right-=3;}
		else
			{rc.left+=1;rc.top+=2;rc.bottom-=3;rc.right-=3;}
		FillRect(lpdis->hDC,&rc,brHtBk);//DrawText(lpdis->hDC,"                                                  ",50,&rc,DT_SINGLELINE|DT_VCENTER|DT_INTERNAL|DT_LEFT);
		if(lpdis->itemState & ODS_SELECTED)
			{rc.left-=1;rc.top-=1;rc.bottom+=3;rc.right+=3;}
		else
			{rc.left-=1;rc.top-=2;rc.bottom+=2;rc.right+=3;}
		DrawText(lpdis->hDC,s,MyStringLength(s,64),&rc,DT_SINGLELINE|DT_VCENTER|DT_CENTER);
		return FALSE;
	case WM_USER+1://hf obshiy uchun, dinamik o'zgartirish uchun emas:
		if(0==hfRef)
		{	LOGFONT lf;InitLOGFONT(&lf);
			hf = CreateFontIndirect(&lf);//conf::Dlg.dlgFnts[7]);
			br = CreateSolidBrush(RGB(0xeb,0xe0,0xeb));//conf::Dlg.dlgRGBs[7][0]);
			brHtBk = CreateSolidBrush(RGB(0xee,0xae,0xd7));//conf::Dlg.dlgRGBs[7][5]);
		}
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_DISKS),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDOK),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_BUTTON_ALL_FIXED_DISKS),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_BUTTON_ALL_DISKS),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDCANCEL),WM_SETFONT,(WPARAM)hf,TRUE);
		++hfRef;
		return 0;//GWL_USERDATA
	case WM_DESTROY:
		if(--hfRef<1)
		{	DeleteObject(hf);
			DeleteObject(br);
			DeleteObject(brHtBk);
		}
		return 0;
	/*case WM_USER+2://Dinamik o'zgartirish uchun:
		DeleteObject(hf);hfRef=1;
		hf = CreateFontIndirect(&conf::Dlg.dlgFnts[7]);
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_DISKS),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDOK),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_BUTTON_ALL_FIXED_DISKS),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_BUTTON_ALL_DISKS),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDCANCEL),WM_SETFONT,(WPARAM)hf,TRUE);
		return 0;//GWL_USERDATA
	case WM_USER+3://Dinamik o'zgartirish uchun, colorni:
		DeleteObject(br);DeleteObject(brHtBk);hfRef=1;
		br = CreateSolidBrush(conf::Dlg.dlgRGBs[7][0]);
		brHtBk = CreateSolidBrush(conf::Dlg.dlgRGBs[7][5]);
		RedrawWindow(hDlg,NULL,NULL,RDW_INVALIDATE|RDW_ALLCHILDREN);
		return 0;//GWL_USERDATA*/
	case WM_COMMAND:
		switch(LOWORD(wParam))
		{	case IDOK:
				if(!GetWindowLong(hDlg,GWL_USERDATA))return TRUE;//confdan chaqirilgan;
				static char str[MAX_PATH];
				GetDlgItemText(hDlg,IDC_COMBO_DISKS,str,MAX_PATH);
				MyStringCat(str,MAX_PATH,";");
				EndDialog(hDlg,(INT_PTR)str);//Showligi faqat conf da,shu uchun
				return (INT_PTR)TRUE;//Destroyni ishlatmadim;
			case IDC_BUTTON_ALL_DISKS:
				if(!GetWindowLong(hDlg,GWL_USERDATA))return TRUE;//confdan chaqirilgan;
				str[0]=0;
				for(int i=0; i<GetTotalLogicalDrives(); i++)
				{	MyStringCat(str,MAX_PATH,GetLogicalDriveName(i));
					MyStringCat(str,MAX_PATH,"\\;");
				}
				EndDialog(hDlg,(INT_PTR)str);
				return (INT_PTR)TRUE;
			case IDC_BUTTON_ALL_FIXED_DISKS:
				if(!GetWindowLong(hDlg,GWL_USERDATA))return TRUE;//confdan chaqirilgan;
				str[0]=0;
				for(int i=0; i<GetTotalLogicalDrives(); i++)
				{	if(12==GetLogicalDriveMediaType(i))
					{	MyStringCat(str,MAX_PATH,GetLogicalDriveName(i));
						MyStringCat(str,MAX_PATH,"\\;");
				}	}
				EndDialog(hDlg,(INT_PTR)str);
				return (INT_PTR)TRUE;
			case IDCANCEL://ESC
				if(!GetWindowLong(hDlg,GWL_USERDATA))return TRUE;//confdan chaqirilgan;
				EndDialog(hDlg, NULL);
				return (INT_PTR)TRUE;
		}
		break;
	}
	return (INT_PTR)FALSE;
}

VOID GetDlgItems(HWND hDlg)
{
	if(!GetDlgItemText(hDlg,IDC_COMBO_SEARCH_NAME,item.filtr,MAX_PATH))
		item.filtr[0]=item.filtr[1] = 0;
	if(!GetDlgItemText(search.hDlg,IDC_COMBO_SEARCH_PATH,item.rootPath,MAX_PATH))
		item.rootPath[0] = 0;

	item.bFindForText = (BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_TEXT_SEACH),BM_GETCHECK,0,0));
	item.bFindForExcldText = (BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_NO_TEXT_SEACH),BM_GETCHECK,0,0));

	item.bFindForText_Unicode = (BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_UNICODE_OR_MULTIBYTE),BM_GETCHECK,0,0));
	if(item.bFindForText_Unicode)
	{item.FindForTextLn = GetDlgItemTextW(hDlg,IDC_COMBO_SEARCH_FOR_TEXT,(LPWSTR)item.FindForText,MAX_PATH);
	 if(!item.FindForTextLn)	
		item.FindForText[0] = item.FindForText[1] = 0;
	}else
	{ item.FindForTextLn = GetDlgItemText(hDlg,IDC_COMBO_SEARCH_FOR_TEXT,item.FindForText,MAX_PATH);
	 if(!item.FindForTextLn)	
		item.FindForText[0] = 0;
	}

	item.bFindForExcldText_Unicode = (BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_UNICODE_OR_MULTIBYTE2),BM_GETCHECK,0,0));
	if(item.bFindForExcldText_Unicode)
	{item.FindForExcldTextLn = GetDlgItemTextW(hDlg,IDC_COMBO_SEARCH_NOT_TEXT,(LPWSTR)item.FindForExcldText,MAX_PATH);
	 if(!item.FindForExcldTextLn)	
		item.FindForExcldText[0] = item.FindForExcldText[1] = 0;
	}else
	{ item.FindForExcldTextLn = GetDlgItemText(hDlg,IDC_COMBO_SEARCH_NOT_TEXT,item.FindForExcldText,MAX_PATH);
	 if(!item.FindForTextLn)	
		item.FindForExcldText[0] = 0;
	}

	item.bFindForText_ASCII = (BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_BINARY_OR_CHARACTER),BM_GETCHECK,0,0));
	item.bFindForExcldText_ASCII = (BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_BINARY_OR_CHARACTER2),BM_GETCHECK,0,0));

	item.bFindForText_UpperCase = (BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_REGISTR_CAPS),BM_GETCHECK,0,0));
	item.bFindForExcldText_UpperCase = (BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_REGISTR_CAPS2),BM_GETCHECK,0,0));

	item.bFindForAlterName = (BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_ALTERNATIVE_NAME),BM_GETCHECK,0,0));

	if(!GetDlgItemText(hDlg,IDC_EDIT_ALTERNATIVE_FILE_NAME,item.altName,MAX_PATH))
		item.altName[0] = 0;
	if(!GetDlgItemTextW(hDlg,IDC_EDIT_ALTERNATIVE_FILE_NAME,item.altNameW,MAX_PATH))
		item.altNameW[0] = 0;

	char sd[32]="";char st[32]="";
	item.bCrTimeBef = (BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_CREATE_TIME_BEFORE),BM_GETCHECK,0,0));
	if(item.bCrTimeBef)
	{	GetDlgItemText(hDlg,IDC_EDIT_CREATE_DATE,sd,MAX_PATH);
		GetDlgItemText(hDlg,IDC_EDIT_CREATE_DATE2,st,MAX_PATH);
		if(!EditsToFileTime(&item.CrTimeBef,sd,st))
			item.bCrTimeBef = FALSE;
	}
	
	item.bCrTimeAft = (BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_CREATE_TIME_AFTER),BM_GETCHECK,0,0));
	if(item.bCrTimeAft)
	{	GetDlgItemText(hDlg,IDC_EDIT_CREATE_DATE_AFTER,sd,MAX_PATH);
		GetDlgItemText(hDlg,IDC_EDIT_CREATE_DATE_AFTER2,st,MAX_PATH);
		if(!EditsToFileTime(&item.CrTimeAft,sd,st))
			item.bCrTimeAft = FALSE;
	}
	
	item.bCrTimeBet = (BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_CREATE_TIME_BETWEEN),BM_GETCHECK,0,0));
	if(item.bCrTimeBet)
	{	GetDlgItemText(hDlg,IDC_EDIT_CREATE_BETWEEN_DATE,sd,MAX_PATH);
		GetDlgItemText(hDlg,IDC_EDIT_CREATE_BETWEEN_TIME,st,MAX_PATH);
		if(!EditsToFileTime(&item.CrTimeBet[0],sd,st))
			item.bCrTimeBet = FALSE;
		GetDlgItemText(hDlg,IDC_EDIT_CREATE_BETWEEN_DATE2,sd,MAX_PATH);
		GetDlgItemText(hDlg,IDC_EDIT_CREATE_BETWEEN_TIME2,st,MAX_PATH);
		if(!EditsToFileTime(&item.CrTimeBet[1],sd,st))
			item.bCrTimeBet = FALSE;
	}

	item.bLstAccTimeBef = (BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_ACCESS_TIME_BEFORE),BM_GETCHECK,0,0));
	if(item.bLstAccTimeBef)
	{	GetDlgItemText(hDlg,IDC_EDIT_LAST_ACCESS_DATE,sd,MAX_PATH);
		GetDlgItemText(hDlg,IDC_EDIT_LAST_ACCESS_DATE2,st,MAX_PATH);
		if(!EditsToFileTime(&item.LstAccTimeBef,sd,st))
			item.bLstAccTimeBef = FALSE;
	}
	
	item.bLstAccTimeAft = (BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_ACCESS_TIME_AFTER),BM_GETCHECK,0,0));
	if(item.bLstAccTimeAft)
	{	GetDlgItemText(hDlg,IDC_EDIT_LAST_ACCESS_DATE_AFTER,sd,MAX_PATH);
		GetDlgItemText(hDlg,IDC_EDIT_LAST_ACCESS_DATE_AFTER2,st,MAX_PATH);
		if(!EditsToFileTime(&item.LstAccTimeAft,sd,st))
			item.bLstAccTimeAft = FALSE;
	}

	item.bLastAccTimeBet = (BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_ACCESS_TIME_BETWEEN),BM_GETCHECK,0,0));
	if(item.bLastAccTimeBet)
	{	GetDlgItemText(hDlg,IDC_EDIT_LAST_ACCESS_DATE_BETWEEN,sd,MAX_PATH);
		GetDlgItemText(hDlg,IDC_EDIT_LAST_ACCESS_TIME_BETWEEN,st,MAX_PATH);
		if(!EditsToFileTime(&item.LastAccTimeBet[0],sd,st))
			item.bLastAccTimeBet = FALSE;
		GetDlgItemText(hDlg,IDC_EDIT_LAST_ACCESS_DATE_BETWEEN2,sd,MAX_PATH);
		GetDlgItemText(hDlg,IDC_EDIT_LAST_ACCESS_TIME_BETWEEN2,st,MAX_PATH);
		if(!EditsToFileTime(&item.LastAccTimeBet[1],sd,st))
			item.bLastAccTimeBet = FALSE;
	}

	item.bLstWrTimeBef = (BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_WRITE_TIME_BEFORE),BM_GETCHECK,0,0));
	if(item.bLstWrTimeBef)
	{	GetDlgItemText(hDlg,IDC_EDIT_LAST_WRITE_DATE,sd,MAX_PATH);
		GetDlgItemText(hDlg,IDC_EDIT_LAST_WRITE_DATE2,st,MAX_PATH);
		if(!EditsToFileTime(&item.LstWrTimeBef,sd,st))
			item.bLstWrTimeBef = FALSE;
	}
	
	item.bLstWrTimeAft = (BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_WRITE_TIME_AFTER),BM_GETCHECK,0,0));
	if(item.bLstWrTimeAft)
	{	GetDlgItemText(hDlg,IDC_EDIT_LAST_WRITE_DATE_AFTER,sd,MAX_PATH);
		GetDlgItemText(hDlg,IDC_EDIT_LAST_WRITE_DATE_AFTER2,st,MAX_PATH);
		if(!EditsToFileTime(&item.LstWrTimeAft,sd,st))
			item.bLstWrTimeAft = FALSE;
	}
	
	item.bLstWrTimeBet = (BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_WRITE_TIME_BETWEEN),BM_GETCHECK,0,0));
	if(item.bLstWrTimeBet)
	{	GetDlgItemText(hDlg,IDC_EDIT_LAST_WRITE_DATE_BETWEEN,sd,MAX_PATH);
		GetDlgItemText(hDlg,IDC_EDIT_LAST_WRITE_TIME_BETWEEN,st,MAX_PATH);
		if(!EditsToFileTime(&item.LstWrTimeBet[0],sd,st))
			item.bLstWrTimeBet = FALSE;
		GetDlgItemText(hDlg,IDC_EDIT_LAST_WRITE_DATE_BETWEEN2,sd,MAX_PATH);
		GetDlgItemText(hDlg,IDC_EDIT_LAST_WRITE_TIME_BETWEEN2,st,MAX_PATH);
		if(!EditsToFileTime(&item.LstWrTimeBet[1],sd,st))
			item.bLstWrTimeBet = FALSE;
	}

	item.bFileSz = (BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_FILE_SIZE),BM_GETCHECK,0,0));
	if(!GetDlgItemText(hDlg,IDC_COMBO_FILE_SIZE_EQUATION,item.sFileSzEqu	,MAX_PATH))
		item.sFileSzEqu[0] = 0;

	if(!GetDlgItemText(hDlg,IDC_EDIT_FILE_SIZE,item.sFileSz	,MAX_PATH))
		item.sFileSz[0] = 0;

	item.iFileSzQual = SendMessage(GetDlgItem(hDlg,IDC_COMBO_FILE_SIZE_QUANTITY),CB_GETCURSEL,0,0);

	item.bFileAttr = (BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_FILE_ATTRIBUTE),BM_GETCHECK,0,0));
	item.bFileAttArchive = (BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_ARCHIVE),BM_GETCHECK,0,0));
	item.bFileAttCompr = (BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_COMPRESSED),BM_GETCHECK,0,0));
	item.bFileAttDevice = (BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_DEVICE),BM_GETCHECK,0,0));
	item.bFileAttDir = (BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_DIRECTORY),BM_GETCHECK,0,0));
	item.bFileAttEncr= (BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_ENCRYPTED),BM_GETCHECK,0,0));
	item.bFileAttHidden = (BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_HIDDEN),BM_GETCHECK,0,0));
	item.bFileAttNormal = (BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_NORMAL),BM_GETCHECK,0,0));
	item.bFileAttNotInd = (BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_NOT_INDEXED),BM_GETCHECK,0,0));
	item.bFileAttOffl = (BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_OFFLINE),BM_GETCHECK,0,0));
	item.bFileAttReadOnly = (BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_READ_ONLY),BM_GETCHECK,0,0));
	item.bFileAttRepPt = (BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_REPARSE_POINT),BM_GETCHECK,0,0));
	item.bFileAttSparseFile = (BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_SPARSE_FILE),BM_GETCHECK,0,0));
	item.bFileAttSys = (BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_SYSTEM),BM_GETCHECK,0,0));
	item.bFileAttTemp = (BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_TEMPORARY),BM_GETCHECK,0,0));
	item.bFileAttVirt = (BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_VIRTUAL),BM_GETCHECK,0,0));
}

VOID ClearResultsLB()
{
	if(!hResultsLB) return;
	SendMessage(hResultsLB,LB_RESETCONTENT,0,0);	
}

VOID CreateResultsLB(HWND hDlg)
{
	if(hResultsLB) return;

	//DC_COMBO_SEARCH_NAME
	//2 265
	RECT rc; GetWindowRect(hDlg, &rc);
	if(rc.bottom-rc.top<minHeightAftCrLB)
		MoveWindow(hDlg,rc.left, 
						rc.top,
						rc.right-rc.left,
						minHeightAftCrLB,
						TRUE);
	//Create List:
	hInfoEdit = CreateWindowEx(WS_EX_CLIENTEDGE,
							"EDIT",
                            NULL,
                            WS_CHILD | WS_VISIBLE | ES_LEFT | ES_AUTOHSCROLL,
                            0,
							450,
							rc.right-rc.left-14,
							20,
                            hDlg,
                            NULL,
                            plgnDllInst,
                            NULL);
	hResultsLB = CreateWindowEx(WS_EX_CLIENTEDGE,
							"LISTBOX",
                            NULL,
                            WS_CHILD | WS_VISIBLE | WS_BORDER | LBS_EXTENDEDSEL | WS_VSCROLL | WS_HSCROLL |
							LBS_HASSTRINGS | LBS_MULTIPLESEL | LBS_NOTIFY | LBS_SORT,
                            0,
							472,
							rc.right-rc.left-12,
							136,
                            hDlg,
                            NULL,
                            plgnDllInst,
                            NULL);
	SendMessage(hResultsLB, LB_SETHORIZONTALEXTENT, (rc.right-rc.left)*4, 0);
	SendMessage(hInfoEdit,EM_SETLIMITTEXT,55,0);
	//hInfoEditDC = GetDC(hInfoEdit);
	//hInfoEditRC.left = hInfoEditRC.top = 0;
	//hInfoEditRC.right = rc.right-rc.left-12;
	//hInfoEditRC.bottom = 20;
}

VOID CreateOutptBtns(HWND hDlg)
{
 if(!hToPanelBTN)
 {	hBrowseBTN = CreateWindowEx(WS_EX_CLIENTEDGE,
							"BUTTON",
                            strngs[46],//"Browse",
                            WS_TABSTOP | WS_VISIBLE | WS_CHILD | WS_BORDER | BS_OWNERDRAW,
                            302,
							426,
							100,
							24,
                            hDlg,
                            (HMENU)(IDC_BUTTON_BROWSE),
                            plgnDllInst,
                            NULL);
	hToPanelBTN = CreateWindowEx(WS_EX_CLIENTEDGE,
							"BUTTON",
                            "To panel",
                            WS_TABSTOP | WS_VISIBLE | WS_CHILD | WS_BORDER | BS_OWNERDRAW,
                            202,
							426,
							100,
							24,
                            hDlg,
                            (HMENU)(IDC_BUTTON_TO_PANEL),
                            plgnDllInst,
                            NULL);
	hEditBTN = CreateWindowEx(WS_EX_CLIENTEDGE,
							"BUTTON",
                            strngs[47],//"Edit",
                            WS_TABSTOP | WS_VISIBLE | WS_CHILD | WS_BORDER | BS_OWNERDRAW,
                            102,
							426,
							100,
							24,
                            hDlg,
							(HMENU)(IDC_BUTTON_EDIT),
                            plgnDllInst,
                            NULL);
	hViewBTN = CreateWindowEx(WS_EX_CLIENTEDGE,
							"BUTTON",
                            strngs[48],//"View",
                            WS_TABSTOP | WS_VISIBLE | WS_CHILD | WS_BORDER | BS_OWNERDRAW,
                            2,
							426,
							100,
							24,
                            hDlg,
                            (HMENU)IDC_BUTTON_VIEW,
                            plgnDllInst,
                            NULL);
 }
 SendMessage(hResultsLB,LB_SETSEL,TRUE,0);
 //PostMessage(hDlg,WM_NEXTDLGCTL,IDC_BUTTON_VIEW-3,TRUE);
 //SetFocus(hBrowseBTN);
 //SendMessage(hDlg,DM_SETDEFID,IDC_BUTTON_VIEW-3,0);
}

BOOL BeginSearch()
{
	search.bStop = FALSE;
	search.iFoundFiles = 0;
	search.iFoundFolders = 0;
	search.iCall++;
	search.ticks[0] = GetTickCount();

	//EnableWindow(GetDlgItem(search.hDlg,IDOK),FALSE);
	EnableWindow(GetDlgItem(search.hDlg,IDCANCEL),FALSE);
	GetDlgItems(search.hDlg);
	/*EnableWindow(GetDlgItem(search.hDlg,IDC_TAB_FILE_SEACH),FALSE);
	if(0==SendMessage(GetDlgItem(search.hDlg,IDC_TAB_FILE_SEACH),TCM_GETCURSEL,0,0))
	{	EnableWindow(GetDlgItem(search.hDlg,IDC_COMBO_SEARCH_NAME),FALSE);
		EnableWindow(GetDlgItem(search.hDlg,IDC_BUTTON_ADD_PATH),FALSE);
		EnableWindow(GetDlgItem(search.hDlg,IDC_BUTTON_ADD_DISK),FALSE);
		EnableWindow(GetDlgItem(search.hDlg,IDC_COMBO_SEARCH_PATH),FALSE);
		EnableWindow(GetDlgItem(search.hDlg,IDC_CHECK_TEXT_SEACH),FALSE);
		EnableWindow(GetDlgItem(search.hDlg,IDC_COMBO_SEARCH_FOR_TEXT),FALSE);
		EnableWindow(GetDlgItem(search.hDlg,IDC_CHECK_UNICODE_OR_MULTIBYTE),FALSE);
		EnableWindow(GetDlgItem(search.hDlg,IDC_CHECK_BINARY_OR_CHARACTER),FALSE);
		EnableWindow(GetDlgItem(search.hDlg,IDC_CHECK_REGISTR_CAPS),FALSE);
		EnableWindow(GetDlgItem(search.hDlg,IDC_CHECK_NO_TEXT_SEACH),FALSE);
		EnableWindow(GetDlgItem(search.hDlg,IDC_COMBO_SEARCH_NOT_TEXT),FALSE);
		EnableWindow(GetDlgItem(search.hDlg,IDC_CHECK_UNICODE_OR_MULTIBYTE2),FALSE);
		EnableWindow(GetDlgItem(search.hDlg,IDC_CHECK_BINARY_OR_CHARACTER2),FALSE);
		EnableWindow(GetDlgItem(search.hDlg,IDC_CHECK_REGISTR_CAPS2),FALSE);
	} else
	{	EnableWindow(GetDlgItem(search.hDlg,IDC_CHECK_ALTERNATIVE_NAME),FALSE);
		if(BST_CHECKED==SendMessage(GetDlgItem(search.hDlg,IDC_CHECK_ALTERNATIVE_NAME),BM_GETCHECK,0,0))
			EnableWindow(GetDlgItem(search.hDlg,IDC_EDIT_ALTERNATIVE_FILE_NAME),FALSE);
		EnableWindow(GetDlgItem(search.hDlg,IDC_CHECK_CREATE_TIME_BEFORE),FALSE);
		if(BST_CHECKED==SendMessage(GetDlgItem(search.hDlg,IDC_CHECK_CREATE_TIME_BEFORE),BM_GETCHECK,0,0))
		{	EnableWindow(GetDlgItem(search.hDlg,IDC_EDIT_CREATE_DATE),FALSE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_CRTBEF_DAY),FALSE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_CRTBEF_MOONS),FALSE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_CRTBEF_YEAR),FALSE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_EDIT_CREATE_DATE2),FALSE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_CRTBEF_HOUR),FALSE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_CRTBEF_MIN),FALSE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_CRTBEF_SEC),FALSE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_CRTBEF_MILS),FALSE);
		}
		EnableWindow(GetDlgItem(search.hDlg,IDC_CHECK_CREATE_TIME_AFTER),FALSE);
		if(BST_CHECKED==SendMessage(GetDlgItem(search.hDlg,IDC_CHECK_CREATE_TIME_AFTER),BM_GETCHECK,0,0))
		{	EnableWindow(GetDlgItem(search.hDlg,IDC_EDIT_CREATE_DATE_AFTER),FALSE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_CRAFT_DAY),FALSE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_CRAFT_MOON),FALSE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_CRAFT_YEAR),FALSE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_EDIT_CREATE_DATE_AFTER2),FALSE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_CRAFT_HOUR),FALSE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_CRAFT_MIN),FALSE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_CRAFT_SEC),FALSE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_CRAFT_MILS),FALSE);
		}
		EnableWindow(GetDlgItem(search.hDlg,IDC_CHECK_CREATE_TIME_BETWEEN),FALSE);
		if(BST_CHECKED==SendMessage(GetDlgItem(search.hDlg,IDC_CHECK_CREATE_TIME_BETWEEN),BM_GETCHECK,0,0))
		{	EnableWindow(GetDlgItem(search.hDlg,IDC_EDIT_CREATE_BETWEEN_DATE),FALSE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_CRTBET_DAY),FALSE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_CRTBET_MOONS),FALSE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_CRTBET_YEAR),FALSE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_EDIT_CREATE_BETWEEN_TIME),FALSE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_CRTBET_HOUR),FALSE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_CRTBET_MIN),FALSE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_CRTBET_SEC),FALSE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_CRTBET_MILS),FALSE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_EDIT_CREATE_BETWEEN_DATE2),FALSE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_CRBET_DAY),FALSE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_CRBET_MOON),FALSE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_CRBET_YEAR),FALSE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_EDIT_CREATE_BETWEEN_TIME2),FALSE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_CRBET_HOUR),FALSE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_CRBET_MIN),FALSE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_CRBET_SEC),FALSE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_CRBET_MILS),FALSE);
		}
		EnableWindow(GetDlgItem(search.hDlg,IDC_CHECK_LAST_ACCESS_TIME_BEFORE),FALSE);
		if(BST_CHECKED==SendMessage(GetDlgItem(search.hDlg,IDC_CHECK_LAST_ACCESS_TIME_BEFORE),BM_GETCHECK,0,0))
		{	EnableWindow(GetDlgItem(search.hDlg,IDC_EDIT_LAST_ACCESS_DATE),FALSE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_LSTBEF_DAY),FALSE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_LSTBEF_MOONS),FALSE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_LSTBEF_YEAR),FALSE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_EDIT_LAST_ACCESS_DATE2),FALSE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_LSTBEF_HOUR),FALSE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_LSTBEF_MIN),FALSE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_LSTBEF_SEC),FALSE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_LSTBEF_MILS),FALSE);
		}
		EnableWindow(GetDlgItem(search.hDlg,IDC_CHECK_LAST_ACCESS_TIME_AFTER),FALSE);
		if(BST_CHECKED==SendMessage(GetDlgItem(search.hDlg,IDC_CHECK_LAST_ACCESS_TIME_AFTER),BM_GETCHECK,0,0))
		{	EnableWindow(GetDlgItem(search.hDlg,IDC_EDIT_LAST_ACCESS_DATE_AFTER),FALSE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_LSAFT_DAY),FALSE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_LSAFT_MOON),FALSE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_LSAFT_YEAR),FALSE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_EDIT_LAST_ACCESS_DATE_AFTER2),FALSE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_LSAFT_HOUR),FALSE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_LSAFT_MIN),FALSE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_LSAFT_SEC),FALSE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_LSAFT_MILS),FALSE);
		}
		EnableWindow(GetDlgItem(search.hDlg,IDC_CHECK_LAST_ACCESS_TIME_BETWEEN),FALSE);
		if(BST_CHECKED==SendMessage(GetDlgItem(search.hDlg,IDC_CHECK_LAST_ACCESS_TIME_BETWEEN),BM_GETCHECK,0,0))
		{	EnableWindow(GetDlgItem(search.hDlg,IDC_EDIT_LAST_ACCESS_DATE_BETWEEN),FALSE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_LSTBET_DAY),FALSE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_LSTBET_MOON),FALSE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_LSTBET_YEAR),FALSE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_EDIT_LAST_ACCESS_TIME_BETWEEN),FALSE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_LSTBET_HOUR),FALSE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_LSTBET_MIN),FALSE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_LSTBET_SEC),FALSE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_LSTBET_MILS),FALSE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_EDIT_LAST_ACCESS_DATE_BETWEEN2),FALSE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_LSABET_DAY),FALSE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_LSABET_MOON),FALSE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_LSABET_YEAR),FALSE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_EDIT_LAST_ACCESS_TIME_BETWEEN2),FALSE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_LSABET_HOUR),FALSE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_LSABET_MIN),FALSE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_LSABET_SEC),FALSE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_LSABET_MILS),FALSE);
		}
		EnableWindow(GetDlgItem(search.hDlg,IDC_CHECK_LAST_WRITE_TIME_BEFORE),FALSE);
		if(BST_CHECKED==SendMessage(GetDlgItem(search.hDlg,IDC_CHECK_LAST_WRITE_TIME_BEFORE),BM_GETCHECK,0,0))
		{	EnableWindow(GetDlgItem(search.hDlg,IDC_EDIT_LAST_WRITE_DATE),FALSE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_LSWTBEF_DAY),FALSE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_LSWTBEF_MOON),FALSE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_LSWTBEF_YEAR),FALSE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_EDIT_LAST_WRITE_DATE2),FALSE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_LSWTBEF_HOUR),FALSE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_LSWTBEF_MIN),FALSE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_LSWTBEF_SEC),FALSE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_LSWTBEF_MILS),FALSE);
		}
		EnableWindow(GetDlgItem(search.hDlg,IDC_CHECK_LAST_WRITE_TIME_AFTER),FALSE);
		if(BST_CHECKED==SendMessage(GetDlgItem(search.hDlg,IDC_CHECK_LAST_WRITE_TIME_AFTER),BM_GETCHECK,0,0))
		{	EnableWindow(GetDlgItem(search.hDlg,IDC_EDIT_LAST_WRITE_DATE_AFTER),FALSE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_LSWRAFT_DAY),FALSE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_LSWRAFT_MOON),FALSE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_LSWRAFT_YEAR),FALSE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_EDIT_LAST_WRITE_DATE_AFTER2),FALSE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_LSWRAFT_HOUR),FALSE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_LSWRAFT_MIN),FALSE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_LSWRAFT_SEC),FALSE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_LSWRAFT_MILS),FALSE);
		}
		EnableWindow(GetDlgItem(search.hDlg,IDC_CHECK_LAST_WRITE_TIME_BETWEEN),FALSE);
		if(BST_CHECKED==SendMessage(GetDlgItem(search.hDlg,IDC_CHECK_LAST_WRITE_TIME_BETWEEN),BM_GETCHECK,0,0))
		{	EnableWindow(GetDlgItem(search.hDlg,IDC_EDIT_LAST_WRITE_DATE_BETWEEN),FALSE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_LSWTBET_DAY),FALSE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_LSWTBET_MOON),FALSE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_LSWTBET_YEAR),FALSE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_EDIT_LAST_WRITE_TIME_BETWEEN),FALSE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_LSWTBET_HOUR),FALSE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_LSWTBET_MIN),FALSE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_LSWTBET_SEC),FALSE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_LSWTBET_MILS),FALSE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_EDIT_LAST_WRITE_DATE_BETWEEN2),FALSE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_LSWRBET_DAY),FALSE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_LSWRBET_MOON),FALSE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_LSWRBET_YEAR),FALSE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_EDIT_LAST_WRITE_TIME_BETWEEN2),FALSE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_LSWRBET_HOUR),FALSE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_LSWRBET_MIN),FALSE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_LSWRBET_SEC),FALSE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_LSWRBET_MILS),FALSE);
		}
		EnableWindow(GetDlgItem(search.hDlg,IDC_CHECK_FILE_SIZE),FALSE);
		if(BST_CHECKED==SendMessage(GetDlgItem(search.hDlg,IDC_CHECK_FILE_SIZE),BM_GETCHECK,0,0))
		{	EnableWindow(GetDlgItem(search.hDlg,IDC_COMBO_FILE_SIZE_EQUATION),FALSE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_EDIT_FILE_SIZE),FALSE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_FILE_SIZE),FALSE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_COMBO_FILE_SIZE_QUANTITY),FALSE);
		}
		EnableWindow(GetDlgItem(search.hDlg,IDC_CHECK_FILE_ATTRIBUTE),FALSE);
		if(BST_CHECKED==SendMessage(GetDlgItem(search.hDlg,IDC_CHECK_FILE_ATTRIBUTE),BM_GETCHECK,0,0))
		{	EnableWindow(GetDlgItem(search.hDlg,IDC_CHECK_ATTRIBUTE_ARCHIVE),FALSE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_CHECK_ATTRIBUTE_COMPRESSED),FALSE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_CHECK_ATTRIBUTE_DEVICE),FALSE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_CHECK_ATTRIBUTE_DIRECTORY),FALSE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_CHECK_ATTRIBUTE_ENCRYPTED),FALSE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_CHECK_ATTRIBUTE_HIDDEN),FALSE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_CHECK_ATTRIBUTE_NORMAL),FALSE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_CHECK_ATTRIBUTE_NOT_INDEXED),FALSE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_CHECK_ATTRIBUTE_OFFLINE),FALSE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_CHECK_ATTRIBUTE_READ_ONLY),FALSE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_CHECK_ATTRIBUTE_REPARSE_POINT),FALSE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_CHECK_ATTRIBUTE_SPARSE_FILE),FALSE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_CHECK_ATTRIBUTE_SYSTEM),FALSE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_CHECK_ATTRIBUTE_TEMPORARY),FALSE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_CHECK_ATTRIBUTE_VIRTUAL),FALSE);
	}	}*/

//char s[MAX_PATH];GetDlgItemText(search.hDlg,IDC_COMBO_SEARCH_NAME,s,MAX_PATH);
	//int selStrLen = MyStringLength((char*)item.filtr,MAX_PATH);

//char rootS[MAX_PATH];if(!GetDlgItemText(search.hDlg,IDC_COMBO_SEARCH_PATH,rootS,MAX_PATH))
//		return FALSE;
	FindStrWthFltr fs(item.filtr);
	char name[MAX_PATH],*pn=&name[0];
	for(char *rp=&item.rootPath[0]; *rp; rp++)
	{	if(*rp!=0 && *rp!=';')
		{	*pn++ = *rp++;
			continue;
		}
		if(*rp==';')
		{	*pn = 0;
			//Find filtr match for pn:
			if(0==fs.GetFullStrLn())
				FindSelectsItems(name,search.hDlg,NULL);
			else
				FindSelectsItems(name,search.hDlg,(FindStrWithFltr*)&fs);
			pn = &name[0];
			while(*rp==';')
				++rp;
	}	}

/*	for(int r=0; r<=rootStrLen; r++)//Oxirgi 0 niyam olsun, aks holda 1ta qolib ketadur;
	{if(';'==item.rootPath[r])//Ajratamiz;
	 {item.rootPath[r]=0;
	  if(r-rootFrom>0)
	  {	char subRoot[MAX_PATH];MySubstr(item.rootPath,subRoot,rootFrom,r);
		rootFrom = r+1;
	   
		for(int i=0; i<=selStrLen; i++)//Oxirgi 0 niyam olsun, aks holda 1ta qolib ketadur;
		{	if(' '==item.filtr[i] ||//CreateFile qoidasiga ko'ra ajratamiz;
			   ';'==item.filtr[i] ||//CreateFile qoidasiga ko'ra ajratamiz;
			   '<'==item.filtr[i] ||//CreateFile qoidasiga ko'ra ajratamiz;
			   '>'==item.filtr[i] ||//CreateFile qoidasiga ko'ra ajratamiz;
			   ':'==item.filtr[i] ||//CreateFile qoidasiga ko'ra ajratamiz;
			  '\"'==item.filtr[i] ||//CreateFile qoidasiga ko'ra ajratamiz;
			   '/'==item.filtr[i] ||//CreateFile qoidasiga ko'ra ajratamiz;
			  '\\'==item.filtr[i] ||//CreateFile qoidasiga ko'ra ajratamiz;
			   '|'==item.filtr[i] ||//CreateFile qoidasiga ko'ra ajratamiz;
			   '?'==item.filtr[i] ||//CreateFile qoidasiga ko'ra ajratamiz;
			   item.filtr[i]<32    )//Ajratamiz;  0 ham kiradi, ya'ni oxiri;
			   //'*' ni qoldiramiz, chunki hammasi degani;
			{	if(i-iFrom>0)
				{	FindSelectsItems(subRoot,search.hDlg,(char*)item.filtr,iFrom,i);
					iFrom = i+1;
					continue;
		}	}	}

		//Agar hech narsa belgilamagan bo'lsayam dopoln.parametrlar bo'yicha poisk qilsun;
		if(!selStrLen)
			FindSelectsItems(subRoot,search.hDlg,NULL,0,0);
	}}}
*/
	/*if(search.panel->totSelects<1 &&	oldHot>0)
	{	search.panel->ChangeSelection(oldHot,hotselected,TRUE);
		search.panel->ScrollItemToView(oldHot);
	}
	else
	{
		search.panel->ScrollItemToView(search.panel->pSelects[0]);
	}*/
	
	//EnableWindow(GetDlgItem(search.hDlg,IDOK),TRUE);
	EnableWindow(GetDlgItem(search.hDlg,IDCANCEL),TRUE);
/*	EnableWindow(GetDlgItem(search.hDlg,IDC_TAB_FILE_SEACH),TRUE);
	if(0==SendMessage(GetDlgItem(search.hDlg,IDC_TAB_FILE_SEACH),TCM_GETCURSEL,0,0))
	{	EnableWindow(GetDlgItem(search.hDlg,IDC_COMBO_SEARCH_NAME),FALSE);
		EnableWindow(GetDlgItem(search.hDlg,IDC_BUTTON_ADD_PATH),TRUE);
		EnableWindow(GetDlgItem(search.hDlg,IDC_BUTTON_ADD_DISK),TRUE);
		EnableWindow(GetDlgItem(search.hDlg,IDC_COMBO_SEARCH_PATH),TRUE);
		EnableWindow(GetDlgItem(search.hDlg,IDC_CHECK_TEXT_SEACH),TRUE);
		if(BST_CHECKED==SendMessage(GetDlgItem(search.hDlg,IDC_CHECK_TEXT_SEACH),BM_GETCHECK,0,0))
		{	EnableWindow(GetDlgItem(search.hDlg,IDC_COMBO_SEARCH_FOR_TEXT),TRUE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_CHECK_UNICODE_OR_MULTIBYTE),TRUE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_CHECK_BINARY_OR_CHARACTER),TRUE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_CHECK_REGISTR_CAPS),TRUE);
		}
		EnableWindow(GetDlgItem(search.hDlg,IDC_CHECK_NO_TEXT_SEACH),TRUE);
		if(BST_CHECKED==SendMessage(GetDlgItem(search.hDlg,IDC_CHECK_NO_TEXT_SEACH),BM_GETCHECK,0,0))
		{	EnableWindow(GetDlgItem(search.hDlg,IDC_COMBO_SEARCH_NOT_TEXT),TRUE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_CHECK_UNICODE_OR_MULTIBYTE2),TRUE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_CHECK_BINARY_OR_CHARACTER2),TRUE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_CHECK_REGISTR_CAPS2),TRUE);
	}	} else
	{	EnableWindow(GetDlgItem(search.hDlg,IDC_CHECK_ALTERNATIVE_NAME),TRUE);
		if(BST_CHECKED==SendMessage(GetDlgItem(search.hDlg,IDC_CHECK_ALTERNATIVE_NAME),BM_GETCHECK,0,0))
			EnableWindow(GetDlgItem(search.hDlg,IDC_EDIT_ALTERNATIVE_FILE_NAME),TRUE);
		EnableWindow(GetDlgItem(search.hDlg,IDC_CHECK_CREATE_TIME_BEFORE),TRUE);
		if(BST_CHECKED==SendMessage(GetDlgItem(search.hDlg,IDC_CHECK_CREATE_TIME_BEFORE),BM_GETCHECK,0,0))
		{	EnableWindow(GetDlgItem(search.hDlg,IDC_EDIT_CREATE_DATE),TRUE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_CRTBEF_DAY),TRUE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_CRTBEF_MOONS),TRUE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_CRTBEF_YEAR),TRUE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_EDIT_CREATE_DATE2),TRUE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_CRTBEF_HOUR),TRUE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_CRTBEF_MIN),TRUE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_CRTBEF_SEC),TRUE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_CRTBEF_MILS),TRUE);
		}
		EnableWindow(GetDlgItem(search.hDlg,IDC_CHECK_CREATE_TIME_AFTER),TRUE);
		if(BST_CHECKED==SendMessage(GetDlgItem(search.hDlg,IDC_CHECK_CREATE_TIME_AFTER),BM_GETCHECK,0,0))
		{	EnableWindow(GetDlgItem(search.hDlg,IDC_EDIT_CREATE_DATE_AFTER),TRUE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_CRAFT_DAY),TRUE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_CRAFT_MOON),TRUE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_CRAFT_YEAR),TRUE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_EDIT_CREATE_DATE_AFTER2),TRUE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_CRAFT_HOUR),TRUE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_CRAFT_MIN),TRUE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_CRAFT_SEC),TRUE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_CRAFT_MILS),TRUE);
		}
		EnableWindow(GetDlgItem(search.hDlg,IDC_CHECK_CREATE_TIME_BETWEEN),TRUE);
		if(BST_CHECKED==SendMessage(GetDlgItem(search.hDlg,IDC_CHECK_CREATE_TIME_BETWEEN),BM_GETCHECK,0,0))
		{	EnableWindow(GetDlgItem(search.hDlg,IDC_EDIT_CREATE_BETWEEN_DATE),TRUE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_CRTBET_DAY),TRUE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_CRTBET_MOONS),TRUE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_CRTBET_YEAR),TRUE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_EDIT_CREATE_BETWEEN_TIME),TRUE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_CRTBET_HOUR),TRUE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_CRTBET_MIN),TRUE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_CRTBET_SEC),TRUE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_CRTBET_MILS),TRUE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_EDIT_CREATE_BETWEEN_DATE2),TRUE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_CRBET_DAY),TRUE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_CRBET_MOON),TRUE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_CRBET_YEAR),TRUE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_EDIT_CREATE_BETWEEN_TIME2),TRUE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_CRBET_HOUR),TRUE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_CRBET_MIN),TRUE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_CRBET_SEC),TRUE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_CRBET_MILS),TRUE);
		}
		EnableWindow(GetDlgItem(search.hDlg,IDC_CHECK_LAST_ACCESS_TIME_BEFORE),TRUE);
		if(BST_CHECKED==SendMessage(GetDlgItem(search.hDlg,IDC_CHECK_LAST_ACCESS_TIME_BEFORE),BM_GETCHECK,0,0))
		{	EnableWindow(GetDlgItem(search.hDlg,IDC_EDIT_LAST_ACCESS_DATE),TRUE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_LSTBEF_DAY),TRUE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_LSTBEF_MOONS),TRUE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_LSTBEF_YEAR),TRUE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_EDIT_LAST_ACCESS_DATE2),TRUE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_LSTBEF_HOUR),TRUE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_LSTBEF_MIN),TRUE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_LSTBEF_SEC),TRUE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_LSTBEF_MILS),TRUE);
		}
		EnableWindow(GetDlgItem(search.hDlg,IDC_CHECK_LAST_ACCESS_TIME_AFTER),TRUE);
		if(BST_CHECKED==SendMessage(GetDlgItem(search.hDlg,IDC_CHECK_LAST_ACCESS_TIME_AFTER),BM_GETCHECK,0,0))
		{	EnableWindow(GetDlgItem(search.hDlg,IDC_EDIT_LAST_ACCESS_DATE_AFTER),TRUE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_LSAFT_DAY),TRUE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_LSAFT_MOON),TRUE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_LSAFT_YEAR),TRUE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_EDIT_LAST_ACCESS_DATE_AFTER2),TRUE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_LSAFT_HOUR),TRUE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_LSAFT_MIN),TRUE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_LSAFT_SEC),TRUE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_LSAFT_MILS),TRUE);
		}
		EnableWindow(GetDlgItem(search.hDlg,IDC_CHECK_LAST_ACCESS_TIME_BETWEEN),TRUE);
		if(BST_CHECKED==SendMessage(GetDlgItem(search.hDlg,IDC_CHECK_LAST_ACCESS_TIME_BETWEEN),BM_GETCHECK,0,0))
		{	EnableWindow(GetDlgItem(search.hDlg,IDC_EDIT_LAST_ACCESS_DATE_BETWEEN),TRUE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_LSTBET_DAY),TRUE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_LSTBET_MOON),TRUE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_LSTBET_YEAR),TRUE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_EDIT_LAST_ACCESS_TIME_BETWEEN),TRUE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_LSTBET_HOUR),TRUE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_LSTBET_MIN),TRUE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_LSTBET_SEC),TRUE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_LSTBET_MILS),TRUE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_EDIT_LAST_ACCESS_DATE_BETWEEN2),TRUE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_LSABET_DAY),TRUE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_LSABET_MOON),TRUE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_LSABET_YEAR),TRUE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_EDIT_LAST_ACCESS_TIME_BETWEEN2),TRUE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_LSABET_HOUR),TRUE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_LSABET_MIN),TRUE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_LSABET_SEC),TRUE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_LSABET_MILS),TRUE);
		}
		EnableWindow(GetDlgItem(search.hDlg,IDC_CHECK_LAST_WRITE_TIME_BEFORE),TRUE);
		if(BST_CHECKED==SendMessage(GetDlgItem(search.hDlg,IDC_CHECK_LAST_WRITE_TIME_BEFORE),BM_GETCHECK,0,0))
		{	EnableWindow(GetDlgItem(search.hDlg,IDC_EDIT_LAST_WRITE_DATE),TRUE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_LSWTBEF_DAY),TRUE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_LSWTBEF_MOON),TRUE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_LSWTBEF_YEAR),TRUE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_EDIT_LAST_WRITE_DATE2),TRUE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_LSWTBEF_HOUR),TRUE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_LSWTBEF_MIN),TRUE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_LSWTBEF_SEC),TRUE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_LSWTBEF_MILS),TRUE);
		}
		EnableWindow(GetDlgItem(search.hDlg,IDC_CHECK_LAST_WRITE_TIME_AFTER),TRUE);
		if(BST_CHECKED==SendMessage(GetDlgItem(search.hDlg,IDC_CHECK_LAST_WRITE_TIME_AFTER),BM_GETCHECK,0,0))
		{	EnableWindow(GetDlgItem(search.hDlg,IDC_EDIT_LAST_WRITE_DATE_AFTER),TRUE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_LSWRAFT_DAY),TRUE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_LSWRAFT_MOON),TRUE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_LSWRAFT_YEAR),TRUE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_EDIT_LAST_WRITE_DATE_AFTER2),TRUE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_LSWRAFT_HOUR),TRUE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_LSWRAFT_MIN),TRUE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_LSWRAFT_SEC),TRUE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_LSWRAFT_MILS),TRUE);
		}
		EnableWindow(GetDlgItem(search.hDlg,IDC_CHECK_LAST_WRITE_TIME_BETWEEN),TRUE);
		if(BST_CHECKED==SendMessage(GetDlgItem(search.hDlg,IDC_CHECK_LAST_WRITE_TIME_BETWEEN),BM_GETCHECK,0,0))
		{	EnableWindow(GetDlgItem(search.hDlg,IDC_EDIT_LAST_WRITE_DATE_BETWEEN),TRUE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_LSWTBET_DAY),TRUE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_LSWTBET_MOON),TRUE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_LSWTBET_YEAR),TRUE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_EDIT_LAST_WRITE_TIME_BETWEEN),TRUE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_LSWTBET_HOUR),TRUE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_LSWTBET_MIN),TRUE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_LSWTBET_SEC),TRUE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_LSWTBET_MILS),TRUE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_EDIT_LAST_WRITE_DATE_BETWEEN2),TRUE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_LSWRBET_DAY),TRUE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_LSWRBET_MOON),TRUE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_LSWRBET_YEAR),TRUE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_EDIT_LAST_WRITE_TIME_BETWEEN2),TRUE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_LSWRBET_HOUR),TRUE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_LSWRBET_MIN),TRUE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_LSWRBET_SEC),TRUE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_LSWRBET_MILS),TRUE);
		}
		EnableWindow(GetDlgItem(search.hDlg,IDC_CHECK_FILE_SIZE),TRUE);
		if(BST_CHECKED==SendMessage(GetDlgItem(search.hDlg,IDC_CHECK_FILE_SIZE),BM_GETCHECK,0,0))
		{	EnableWindow(GetDlgItem(search.hDlg,IDC_COMBO_FILE_SIZE_EQUATION),TRUE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_EDIT_FILE_SIZE),TRUE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_SPIN_FILE_SIZE),TRUE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_COMBO_FILE_SIZE_QUANTITY),TRUE);
		}
		EnableWindow(GetDlgItem(search.hDlg,IDC_CHECK_FILE_ATTRIBUTE),TRUE);
		if(BST_CHECKED==SendMessage(GetDlgItem(search.hDlg,IDC_CHECK_FILE_ATTRIBUTE),BM_GETCHECK,0,0))
		{	EnableWindow(GetDlgItem(search.hDlg,IDC_CHECK_ATTRIBUTE_ARCHIVE),TRUE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_CHECK_ATTRIBUTE_COMPRESSED),TRUE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_CHECK_ATTRIBUTE_DEVICE),TRUE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_CHECK_ATTRIBUTE_DIRECTORY),TRUE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_CHECK_ATTRIBUTE_ENCRYPTED),TRUE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_CHECK_ATTRIBUTE_HIDDEN),TRUE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_CHECK_ATTRIBUTE_NORMAL),TRUE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_CHECK_ATTRIBUTE_NOT_INDEXED),TRUE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_CHECK_ATTRIBUTE_OFFLINE),TRUE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_CHECK_ATTRIBUTE_READ_ONLY),TRUE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_CHECK_ATTRIBUTE_REPARSE_POINT),TRUE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_CHECK_ATTRIBUTE_SPARSE_FILE),TRUE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_CHECK_ATTRIBUTE_SYSTEM),TRUE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_CHECK_ATTRIBUTE_TEMPORARY),TRUE);
			EnableWindow(GetDlgItem(search.hDlg,IDC_CHECK_ATTRIBUTE_VIRTUAL),TRUE);
	}	}*/

	search.iCall--;char s[128];
	search.ticks[1] = GetTickCount();
	StringCchPrintf(s,MAX_PATH,"Founded folders: %d, Founded files: %d, elapsed time: %d milliseconds.",search.iFoundFolders,search.iFoundFiles,search.ticks[1]-search.ticks[0]);
	SetWindowText(hInfoEdit,s);
	//ExitThread(0); avval alohida thread edi, shu uchun turibdi.Hozir tez ishlashi
	return TRUE;//uchun asosiy threadga kiritilagn, ya'ni funk qilib chaqiriladur!!!
}

VOID AddToInfoEdit(char* rootPath, WIN32_FIND_DATA& ff)
{
char s[3*MAX_PATH];
	MyStringCpy(s,MAX_PATH,rootPath);
	char *p = strrchr(s,'\\');
	if(p) *(p+1) = 0;
	MyStringCat(s,MAX_PATH,ff.cFileName);
	SetWindowText(hInfoEdit,s);
	SendMessage(hInfoEdit,WM_PAINT,0,0);
	//DrawText(hInfoEditDC,s,-1,&hInfoEditRC,DT_RIGHT);
}

extern "C"
{
//rootPath - multibyte, sub - unicode;
__declspec(dllexport) BOOL SearchForContainTextW$12(char *rootPath,wchar_t *sub,WIN32_FIND_DATA *pf)
{
	int lnSub = MyStringLengthW(sub,MAX_PATH);
	if(!lnSub)return FALSE;

	char path[MAX_PATH];MyStringCpy(path,MAX_PATH,rootPath);
	MyStringCat(path,MAX_PATH,pf->cFileName);

	if(item.bFindForText_ASCII)
	{	for(int i=0; i<lnSub; i++)
		{	if(!IsBin(sub[i]))
			{	MessageBox(NULL,"Please,use only digit symbols without space.","Binary filtr string error:",MB_OK);
				return FALSE;
		}	}
		if(lnSub%2)
		{	MessageBox(NULL,"Please,input pair symbols without space.","Binary filtr string length error:",MB_OK);
			return FALSE;
		}
		lnSub /= 2;
	}

	HANDLE h = CreateFile(path,GENERIC_READ,
						  FILE_SHARE_READ,
						  NULL,
						  OPEN_EXISTING,
						  pf->dwFileAttributes,
						  NULL);
	if(INVALID_HANDLE_VALUE==h) return FALSE;

	char *buf = (char*)_malloca(4096);
	if(!buf) return FALSE;
	wchar_t *wbuf = (wchar_t*)_malloca(2*4096);
	if(!wbuf) return FALSE;

	int nr = 4096, rb = 1, dum = 0; wchar_t *pwbuf = wbuf;
	while(rb)
	{	if(!ReadFile(h,buf,nr,(DWORD*)&rb,NULL))break;
		if(!MultiByteToWideChar(CP_ACP,MB_PRECOMPOSED,buf,rb,pwbuf,rb)) break;
		wchar_t *pwbufCmp = wbuf;
		while(pwbufCmp<wbuf+dum+rb-lnSub+1)//for(int i=0; i<rb-lnSub+1; i++)//if(rb >= lnSub) ning o'zi edi;
		{	wchar_t *r; if(item.bFindForText_ASCII)
			{	r = MyStrCmpBinNW(pwbufCmp,(wchar_t*)sub,wbuf+dum+rb-lnSub+1-pwbufCmp,lnSub);
				pwbufCmp += (wchar_t*)(buf+dum+rb-lnSub+1)-pwbufCmp;
			}
			else
			{	if(item.bFindForText_UpperCase)r=(wchar_t*)MyStrCmpNotRelUpRegNW(pwbufCmp++,(wchar_t*)sub,lnSub);
				else r=(wchar_t*)MyStrCmpNW(pwbufCmp++,(wchar_t*)sub,lnSub);
			}
			if(r)
			{	CloseHandle(h);
				_freea(buf);
				_freea(wbuf);
				return TRUE;
		}	}
		//Qolgan dumini boshiga ko'chiramiz:
		if(rb)
		{	int ddum = 0;
			while(pwbufCmp<wbuf+dum+rb)//for(int k=rb-lnSub+1; k<rb; k++)
				wbuf[ddum++] = *pwbufCmp++;
			dum = ddum;
			pwbuf = wbuf + dum;
			nr = 4096 - dum;
	}	}

	CloseHandle(h);
	_freea(buf);
	_freea(wbuf);
	return FALSE;
}

__declspec(dllexport) BOOL SearchForContainText$12(char *rootPath,char *sub,WIN32_FIND_DATA *pf)
{
	int lnSub = MyStringLength(sub,MAX_PATH);
	if(!lnSub)return FALSE;

	char path[MAX_PATH];MyStringCpy(path,MAX_PATH,rootPath);
	MyStringCat(path,MAX_PATH,pf->cFileName);

	if(item.bFindForText_ASCII)
	{	for(int i=0; i<lnSub; i++)
		{	if(!IsBin(sub[i]))
			{	MessageBox(NULL,"Please,use only digit symbols without space.","Binary filtr string error:",MB_OK);
				return FALSE;
		}	}
		if(lnSub%2)
		{	MessageBox(NULL,"Please,input pair symbols without space.","Binary filtr string length error:",MB_OK);
			return FALSE;
		}
		lnSub /= 2;
	}

	HANDLE h = CreateFile(path,GENERIC_READ,
						  FILE_SHARE_READ,
						  NULL,
						  OPEN_EXISTING,
						  pf->dwFileAttributes,//|FILE_FLAG_SEQUENTIAL_SCAN,
						  NULL);
	/*IO_STATUS_BLOCK Iosb;OBJECT_ATTRIBUTES fileAttributes;wchar_t pathW[MAX_PATH];
	MultiByteToWideChar(CP_ACP,MB_PRECOMPOSED,path,MAX_PATH,pathW,MAX_PATH);
	UNICODE_STRING uniPath;
	pRtlInitUnicodeString(&uniPath, pathW);
	InitializeObjectAttributes(&fileAttributes, &uniPath, OBJ_CASE_INSENSITIVE, 0, 0);
	if(STATUS_SUCCESS!=pNtCreateFile(&h,GENERIC_READ,
						  &fileAttributes,
						  &Iosb,
						  0,
						  FILE_ATTRIBUTE_NORMAL,
						  FILE_SHARE_READ,
						  FILE_OPEN_IF,
						  FILE_NON_DIRECTORY_FILE,
						  0,
						  0))
		  return FALSE;*/
	if(INVALID_HANDLE_VALUE==h) return FALSE;

	//char *buf = (char*)_malloca(32768);
	//if(!buf) return FALSE;
	char buf[32768];
//static __declspec(align(32)) char buf[4096];

	int nr = 0, rb = 1, dumLn = lnSub-1;
	while(rb>0)
	{	if(nr)
		{	if(!ReadFile(h,buf+dumLn,32768-dumLn,(DWORD*)&rb,NULL))
				break;
		} else
		{	if(!ReadFile(h,buf,32768,(DWORD*)&rb,NULL))
				break;
		} char *pbuf = buf;
		if(rb>0)
		{	while(pbuf<buf+rb-dumLn)
			{	char* r; if(item.bFindForText_ASCII)
				{	r = MyStrCmpBinN(buf,sub,nr?rb:rb-dumLn,lnSub);
					pbuf += rb-dumLn;
				}
				else
				{	if(item.bFindForText_UpperCase)r=(char*)MyStrCmpNotRelUpRegN(pbuf++,sub,lnSub);
					else
					{	r=MyStrCmpNN(buf,sub,nr?rb:rb-dumLn,lnSub);
						pbuf += rb-dumLn;
				}	}
				if(r)
				{	CloseHandle(h);
					//_freea(buf);
					return TRUE;
			}	}
			//Qolgan dumini boshiga ko'chiramiz:
			if(rb) {memcpy(buf, buf + rb - dumLn, dumLn); ++nr;}
			else nr = 0;
	}	}

	CloseHandle(h);
	//pNtClose(h);
	//_freea(buf);
	return FALSE;
}

__declspec(dllexport) BOOL SearchForNotContainTextW$12(char *rootPath,wchar_t *sub,WIN32_FIND_DATA *pf)
{
	int lnSub = MyStringLengthW(sub,MAX_PATH);
	if(!lnSub)return FALSE;

	char path[MAX_PATH];MyStringCpy(path,MAX_PATH,rootPath);
	MyStringCat(path,MAX_PATH,pf->cFileName);

	if(item.bFindForExcldText_ASCII)
	{	for(int i=0; i<lnSub; i++)
		{	if(sub[i]<'0' || sub[i]>'9')
			{	MessageBox(NULL,"Please,use only digit symbols without space.","Binary filtr string error:",MB_OK);
				return FALSE;
		}	}
		if(lnSub%2)
		{	MessageBox(NULL,"Please,input pair symbols without space.","Binary filtr string length error:",MB_OK);
			return FALSE;
		}
		lnSub /= 2;
	}

	HANDLE h = CreateFile(path,GENERIC_READ,
						  FILE_SHARE_READ,
						  NULL,
						  OPEN_EXISTING,
						  pf->dwFileAttributes,
						  NULL);
	if(!h) return FALSE;

	char *buf = (char*)_malloca(4096);
	if(!buf) return FALSE;
	wchar_t *wbuf = (wchar_t*)_malloca(2*4096);
	if(!wbuf) return FALSE;

	int nr = 4096, rb = 1, dum = 0; wchar_t *pwbuf = wbuf;
	while(rb)
	{	if(!ReadFile(h,buf,nr,(DWORD*)&rb,NULL))break;
		if(!MultiByteToWideChar(CP_ACP,MB_PRECOMPOSED,buf,rb,pwbuf,rb)) break;
		wchar_t *pwbufCmp = wbuf;
		while(pwbufCmp<wbuf+dum+rb-lnSub+1)//for(int i=0; i<rb-lnSub+1; i++)//if(rb >= lnSub) ning o'zi edi;
		{	wchar_t* r; if(item.bFindForExcldText_ASCII)
				r = MyStrCmpBinNW(pwbufCmp++,(wchar_t*)sub,(wchar_t*)(buf+dum+rb-lnSub+1)-pwbufCmp,lnSub);
			else
			{	if(item.bFindForExcldText_UpperCase)r=(wchar_t*)MyStrCmpNotRelUpRegNW(pwbufCmp++,(wchar_t*)sub,lnSub);
				else r=(wchar_t*)MyStrCmpNW(pwbufCmp++,(wchar_t*)sub,lnSub);
			}
			if(r)
			{	CloseHandle(h);
				_freea(buf);
				_freea(wbuf);
				return FALSE;
		}	}
		//Qolgan dumini boshiga ko'chiramiz:
		int ddum = 0;
		while(pwbufCmp<wbuf+dum+rb)//for(int k=rb-lnSub+1; k<rb; k++)
			wbuf[ddum++] = *pwbufCmp++;
		dum = ddum;
		pwbuf = wbuf + dum;
		nr = 4096 - dum;
	}

	CloseHandle(h);
	_freea(buf);
	_freea(wbuf);
	return TRUE;
}

__declspec(dllexport) BOOL SearchForNotContainText$12(char *rootPath,char *sub,WIN32_FIND_DATA *pf)
{
	int lnSub = MyStringLength(sub,MAX_PATH);
	if(!lnSub)return FALSE;

	char path[MAX_PATH];MyStringCpy(path,MAX_PATH,rootPath);
	MyStringCat(path,MAX_PATH,pf->cFileName);

	if(item.bFindForExcldText_ASCII)
	{	for(int i=0; i<lnSub; i++)
		{	if(sub[i]<'0' || sub[i]>'9')
			{	MessageBox(NULL,"Please,use only digit symbols without space.","Binary filtr string error:",MB_OK);
				return FALSE;
		}	}
		if(lnSub%2)
		{	MessageBox(NULL,"Please,input pair symbols without space.","Binary filtr string length error:",MB_OK);
			return FALSE;
		}
		lnSub /= 2;
	}

	HANDLE h = CreateFile(path,GENERIC_READ,
						  FILE_SHARE_READ,
						  NULL,
						  OPEN_EXISTING,
						  pf->dwFileAttributes,
						  NULL);
	if(!h) return FALSE;

	char *buf = (char*)_malloca(4096);
	if(!buf) return FALSE;

	int nr = 4096, rb = 1, dum = 0; char *pbuf = buf;
	while(rb)
	{	if(!ReadFile(h,pbuf,nr,(DWORD*)&rb,NULL))break;
		char *pbufCmp = buf;
		while(pbufCmp<buf+dum+rb-lnSub+1)//for(int i=0; i<rb-lnSub+1; i++)//if(rb >= lnSub) ning o'zi edi;
		{	char *r; if(item.bFindForExcldText_ASCII)
			{	r = MyStrCmpBinN(pbufCmp,sub,buf+dum+rb-lnSub+1-pbufCmp,lnSub);
				pbufCmp += buf+dum+rb-lnSub+1-pbufCmp;
			}
			else
			{	if(item.bFindForExcldText_UpperCase)r=(char*)MyStrCmpNotRelUpRegN(pbufCmp++,sub,lnSub);
				else r=(char*)MyStrCmpN(pbufCmp++,sub,lnSub);
			}
			if(r)
			{	CloseHandle(h);
				_freea(buf);
				return FALSE;
		}	}
		//Qolgan dumini boshiga ko'chiramiz:
		int ddum = 0;
		while(pbufCmp<buf+dum+rb)//for(int k=rb-lnSub+1; k<rb; k++)
			buf[ddum++] = *pbufCmp++;
		dum = ddum;
		pbuf = buf + dum;
		nr = 4096 - dum;
	}

	CloseHandle(h);
	_freea(buf);
	return TRUE;
}
}//extern "C"

//Qo'shimcha parametrlar asosida qidirish:
BOOL CheckOtherSearchConditionsDirectFolder(char* rootPath,WIN32_FIND_DATA *pf, int type)
{
DWORD bCndtns = 0x00000000;

	if(0==type)//file
	{//1.1-Page, Filtr va RootPath -->> BeginSearch da;
	 //2.1-Page, Find for text:
	 if(item.bFindForText)
	 {if(item.FindForTextLn)
	  {FindStrWthFltr fs(item.FindForText);
	   for(int s=0; s<fs.GetNumStrs(); s++)
	   {	char *sub=fs.GetSubstr(s);
			if(item.bFindForExcldText_Unicode?SearchForContainTextW$12(rootPath,(wchar_t*)sub,pf):SearchForContainText$12(rootPath,sub,pf))
			{	bCndtns |= 0x00000001;//[0] = TRUE;
		 		goto ToNotContainText;
	  }}	}
	  //bCndtns[0] = FALSE;
	 }
	 else bCndtns |= 0x00000001;//[0] = TRUE;
	 //3.1-Page, Find for do not contain text:
ToNotContainText:
	 if(item.bFindForExcldText)
	 {if(item.FindForExcldTextLn)
	  {FindStrWthFltr fs(item.FindForExcldText);
	   for(int s=0; s<fs.GetNumStrs(); s++)
	   {	char *sub=fs.GetSubstr(s);
			if(item.bFindForExcldText_Unicode?SearchForNotContainTextW$12(rootPath,(wchar_t*)sub,pf):SearchForNotContainText$12(rootPath,sub,pf))
		    {	bCndtns |= 0x00000001;//[0] = TRUE;
		 		goto ToNotContainText;
	  }}	}   
	  //bCndtns[1] = FALSE;
	 }
	 else bCndtns |= 0x00000002;//[1] = TRUE;

	 if(item.bFileSz)
	 {if(!item.sFileSzEqu[0])
		bCndtns |=0x00000004;//[2] = TRUE;
	  else
	  { if(!item.sFileSz[0])
		  bCndtns |=0x00000004;//[2] = TRUE;
	    else
		{	if(CB_ERR==item.iFileSzQual) bCndtns |= 0x00000003;//[2] = TRUE;
			else
			{	unsigned __int64 sz = MyAtoU64(item.sFileSz);
				for(int i=0; i<item.iFileSzQual; i++)
					sz = sz <<  10;
				unsigned __int64 fsz = ((unsigned __int64)pf->nFileSizeHigh << 32) + (unsigned __int64)pf->nFileSizeLow;
				if('>'==item.sFileSzEqu[0])
				{	if(sz < fsz)
						bCndtns |= 0x00000004;
					//bCndtns[2] = (sz < fsz);
				}
				else if('<'==item.sFileSzEqu[0])
				{	if(sz > fsz)
						bCndtns |= 0x00000004;
					//bCndtns[2] = (sz > fsz);
				}
				else //if('='==item.sFileSzEqu[0])
				{	if(sz == fsz)
						bCndtns |= 0x00000004;
					//bCndtns[2] = (sz == fsz);
	 }}	}	}	}
	 else bCndtns |= 0x00000004;//[2] = TRUE;
	}
	else//if(1==0)//folder
	{//1.1-Page, Filtr va RootPath -->> BeginSearch da;
	 //2.1-Page, Find for text:
	 //if(BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_TEXT_SEACH),BM_GETCHECK,0,0))
	 if(item.bFindForText)
		 return FALSE;
	 //3.1-Page, Find for do not contain text:
	 if(item.bFindForExcldText)
		 return FALSE;
	 //4.2-Page, Find for alternative name:
	 if(item.bFindForAlterName)
		 return FALSE;
	 if(item.bFileSz)
		 return FALSE;
	 bCndtns |= 0x00000007;//bCndtns[0] = bCndtns[1] = bCndtns[2] = TRUE;
	}

	//4.2-Page, Find for alternative name:
//FindAlternName:
	if(item.bFindForAlterName)
	{if(item.altName[0])
	{	if(0==strcmp(pf->cAlternateFileName,item.altName))
			bCndtns |= 0x00000008;
	 }
	} else bCndtns |= 0x00000008;//[3] = TRUE;

	//5.2-Page, Find for creation time before:
	if(item.bCrTimeBef)
	{	if(-1!=CmpFILETIMEs(&item.CrTimeBef,&pf->ftCreationTime))
			bCndtns |= 0x00000010;
	}
	else bCndtns |= 0x00000010;//[4] = TRUE;

	//6.2-Page, Find for creation time after:
	if(item.bCrTimeAft)
	{	if(1!=CmpFILETIMEs(&item.CrTimeAft,&pf->ftCreationTime))
			bCndtns |= 0x00000020;
	}
	else bCndtns |= 0x00000020;//bCndtns[5] = TRUE;

	//7.2-Page, Find for creation time between:
	if(item.bCrTimeBet)
	{	if(1==CmpFILETIMEsBetween(&item.CrTimeBet[0],&item.CrTimeBet[1],&pf->ftCreationTime))
			bCndtns |= 0x00000040;
	}
	else bCndtns |= 0x00000040;//bCndtns[6] = TRUE;

	//8.2-Page, Find for last access time before:
	if(item.bLstAccTimeBef)
	{	if(-1!=CmpFILETIMEs(&item.LstAccTimeBef,&pf->ftCreationTime))
			bCndtns |= 0x00000080;
	}
	else bCndtns |= 0x00000080;//bCndtns[7] = TRUE;

	//9.2-Page, Find last access time after:
	if(item.bLstAccTimeAft)
	{	if(1!=CmpFILETIMEs(&item.LstAccTimeAft,&pf->ftLastAccessTime))
			bCndtns |= 0x00000100;
	}
	else bCndtns |= 0x00000100;//bCndtns[8] = TRUE;

	//10.2-Page, Find for last access time between:
	if(item.bLastAccTimeBet)
	{	if(1==CmpFILETIMEsBetween(&item.LastAccTimeBet[0],&item.LastAccTimeBet[1],&pf->ftLastAccessTime))
			bCndtns |= 0x00000200;
	}
	else bCndtns |= 0x00000200;//bCndtns[9] = TRUE;

	//11.2-Page, Find for last write time before:
	if(item.bLstWrTimeBef)
	{	if(-1!=CmpFILETIMEs(&item.LstWrTimeBef,&pf->ftLastWriteTime))
			bCndtns |= 0x00000400;
	}
	else bCndtns |= 0x00000400;//bCndtns[10] = TRUE;

	//12.2-Page, Find last write time after:
	if(item.bLstWrTimeAft)
	{	if(1!=CmpFILETIMEs(&item.LstWrTimeAft,&pf->ftLastWriteTime))
			bCndtns |= 0x00000800;
	}
	else bCndtns |= 0x00000800;//bCndtns[11] = TRUE;

	//13.2-Page, Find for last write time between:
	if(item.bLstWrTimeBet)
	{	if(1==CmpFILETIMEsBetween(&item.LstWrTimeBet[0],&item.LstWrTimeBet[1],&pf->ftLastWriteTime))
			bCndtns |= 0x00001000;
	}
	else bCndtns |= 0x00001000;//bCndtns[12] = TRUE;

	//14.2-Page, Find for file attribute:
	if(item.bFileAttr)
	{	if(item.bFileAttArchive)
		if((FILE_ATTRIBUTE_ARCHIVE & pf->dwFileAttributes) != 0)
			bCndtns |= 0x00002000;
		if(item.bFileAttCompr)
		if((FILE_ATTRIBUTE_COMPRESSED & pf->dwFileAttributes) != 0)
			bCndtns |= 0x00004000;
		if(item.bFileAttDevice)
		if((FILE_ATTRIBUTE_DEVICE & pf->dwFileAttributes) != 0)
			bCndtns |= 0x00008000;
		if(item.bFileAttDir)
		if((FILE_ATTRIBUTE_DIRECTORY & pf->dwFileAttributes) != 0)
			bCndtns |= 0x00010000;
		if(item.bFileAttEncr)
		if((FILE_ATTRIBUTE_ENCRYPTED & pf->dwFileAttributes) != 0)
			bCndtns |= 0x00020000;
		if(item.bFileAttHidden)
		if((FILE_ATTRIBUTE_HIDDEN & pf->dwFileAttributes) != 0)
			bCndtns |= 0x00040000;
		if(item.bFileAttNormal)
		if((FILE_ATTRIBUTE_NORMAL & pf->dwFileAttributes) != 0)
			bCndtns |= 0x00080000;
		if(item.bFileAttNotInd)
		if((FILE_ATTRIBUTE_NOT_CONTENT_INDEXED & pf->dwFileAttributes) != 0)
			bCndtns |= 0x00100000;
		if(item.bFileAttOffl)
		if((FILE_ATTRIBUTE_OFFLINE & pf->dwFileAttributes) != 0)
			bCndtns |= 0x00200000;
		if(item.bFileAttReadOnly)
		if((FILE_ATTRIBUTE_READONLY & pf->dwFileAttributes) != 0)
			bCndtns |= 0x00400000;
		if(item.bFileAttRepPt)
		if((FILE_ATTRIBUTE_REPARSE_POINT & pf->dwFileAttributes) != 0)
			bCndtns |= 0x00800000;
		if(item.bFileAttSparseFile)
		if((FILE_ATTRIBUTE_SPARSE_FILE & pf->dwFileAttributes) != 0)
			bCndtns |= 0x01000000;
		if(item.bFileAttSys)
		if((FILE_ATTRIBUTE_SYSTEM & pf->dwFileAttributes) != 0)
			bCndtns |= 0x02000000;
		if(item.bFileAttTemp)
		if((FILE_ATTRIBUTE_TEMPORARY & pf->dwFileAttributes) != 0)
			bCndtns |= 0x04000000;
		if(item.bFileAttVirt)
		if((FILE_ATTRIBUTE_VIRTUAL & pf->dwFileAttributes) != 0)
			bCndtns |= 0x08000000;
	}
	else
	{	bCndtns |= 0x0fffe000;
	}

	//Hamma usloviyalarni tekshirib chiqdik, endi qaytamiz:
	if(0x0fffffff==bCndtns)
		return TRUE;
	return FALSE;
}

VOID AddToResultsLB(HWND dlg,WIN32_FIND_DATA* ff,char *rootPath,int type)
{
	if(!hResultsLB) return;
	if(!IsCrntOrPrntDirAttrb(ff->cFileName)) return;
	char fullName[MAX_PATH+36];
	if(0==type)//file
	{	if(!CheckOtherSearchConditionsDirectFolder(rootPath,ff,0))
			return;
		MyStringCpy(fullName,MAX_PATH,rootPath);
		char *p = strrchr(fullName,'\\');
		if(p) *(p+1) = 0;
		MyStringCat(fullName,MAX_PATH+36,ff->cFileName);
		++search.iFoundFiles;
	}
	else if(1==type)//folder
	{	if(!-CheckOtherSearchConditionsDirectFolder(rootPath,ff,1))
			return;
		fullName[0]='<';//'[';
		MyStringCpy(&fullName[1],MAX_PATH,rootPath);
		char *p = strrchr(fullName,'\\');
		if(p) *(p+1) = 0;
		MyStringCat(fullName,MAX_PATH+36,ff->cFileName);
		MyStringCat(fullName,MAX_PATH+36,">");//"]");
		++search.iFoundFolders;
	}
	SendMessage(hResultsLB,LB_ADDSTRING,0,(LPARAM)fullName);
	//SendMessage(hResultsLB,WM_PAINT,0,0);
}

VOID FindSelectsInFolders(HWND,char*,char*,int,int);
//Reentrance:
VOID FindSelectsItemsDirectFolder(HWND dlg,char *rootPath,char* str,int iFrom,int iTo)
{
	search.iCall++;

	char path[MAX_PATH],sub[MAX_PATH];
	MyStringCpy(path,MAX_PATH,rootPath);
	if(str)
	{	MySubstr(str,sub,iFrom,iTo);
		MyStringCat(path,MAX_PATH,sub);
	}
	else
		MyStringCat(path,MAX_PATH,"*");

	WIN32_FIND_DATA ff;
	HANDLE hFind;hFind = INVALID_HANDLE_VALUE;

	hFind = FindFirstFile(path, &ff);
	if(INVALID_HANDLE_VALUE==hFind)
	{	FindSelectsInFolders(dlg,rootPath,str,iFrom,iTo);
		search.iCall--;
		return;
	}
	else
	{	if(FILE_ATTRIBUTE_DIRECTORY & ff.dwFileAttributes)//if(IsDirectory(path, &ff, TRUE))
		{	if(1==schConf.bEnumSubDir)
			{	if(IsCrntOrPrntDirAttrb(ff.cFileName))
				{	MyStringCpy(path,MAX_PATH,rootPath);
					MyStringCat(path,MAX_PATH,ff.cFileName);
					MyStringCat(path,MAX_PATH,"\\");
					FindSelectsItemsDirectFolder(dlg,path,str,iFrom,iTo);
		}	}	}
		else
		{	AddToInfoEdit(path, ff);
			AddToResultsLB(dlg, &ff, rootPath, 0);//path, 0);
	}	}

	while(FindNextFile(hFind, &ff))
	{	if(FILE_ATTRIBUTE_DIRECTORY & ff.dwFileAttributes)//if(IsDirectory(path, &ff, TRUE))
		{	if(IsCrntOrPrntDirAttrb(ff.cFileName))
			{	MyStringCpy(path,MAX_PATH,rootPath);
				MyStringCat(path,MAX_PATH,ff.cFileName);
				MyStringCat(path,MAX_PATH,"\\");
				AddToInfoEdit(path, ff);
				AddToResultsLB(dlg, &ff, rootPath, 1);//path, 1);
				if(1==schConf.bEnumSubDir)
					FindSelectsItemsDirectFolder(dlg,path,str,iFrom,iTo);
		}	}
		else
		{	AddToInfoEdit(path, ff);
			AddToResultsLB(dlg, &ff, rootPath, 0);//path, 0);
		}
		if(search.bStop)
			break;

		static int k=0;
		if(k++==150)
		{	MSG msg;if( PeekMessage( &msg, NULL, 0U, 0U, PM_REMOVE ) )
				DispatchMessage ( &msg );
			k=0;
	}	}

	FindClose(hFind);
	--search.iCall;
}

VOID FindSelectsInFolders(HWND dlg,char *rootPath,char* str,int iFrom,int iTo)
{
	search.iCall++;

	char path[MAX_PATH];
	MyStringCpy(path,MAX_PATH,rootPath);
	MyStringCat(path,MAX_PATH,"*");

	WIN32_FIND_DATA ff;
	HANDLE hFind;hFind = INVALID_HANDLE_VALUE;

	hFind = FindFirstFile(path, &ff);
	if(INVALID_HANDLE_VALUE==hFind)
	{	search.iCall--;
		return;
	}
	else
	{	if(FILE_ATTRIBUTE_DIRECTORY & ff.dwFileAttributes)
		{	if(IsCrntOrPrntDirAttrb(ff.cFileName))
			{	AddToInfoEdit(rootPath, ff);
				if(1==schConf.bEnumSubDir)
				{	MyStringCpy(path,MAX_PATH,rootPath);
					MyStringCat(path,MAX_PATH,ff.cFileName);
					MyStringCat(path,MAX_PATH,"\\");
					FindSelectsItemsDirectFolder(dlg,path,str,iFrom,iTo);
	}	}	}	}

	while(FindNextFile(hFind, &ff))
	{	if(FILE_ATTRIBUTE_DIRECTORY & ff.dwFileAttributes)//if(IsDirectory(path, &ff, TRUE))
		{	if(IsCrntOrPrntDirAttrb(ff.cFileName))
			{	AddToInfoEdit(rootPath, ff);
				if(1==schConf.bEnumSubDir)
				{	MyStringCpy(path,MAX_PATH,rootPath);
					MyStringCat(path,MAX_PATH,ff.cFileName);
					MyStringCat(path,MAX_PATH,"\\");
					FindSelectsItemsDirectFolder(dlg,path,str,iFrom,iTo);
		}	}	}
		if(search.bStop)
			break;
	}
	FindClose(hFind);
	--search.iCall;
}

VOID FindSelectsItems(char *rootPath,HWND hDlg,FindStrWithFltr *fs)
{
	/*if(pZwCreateFile && (1==schConf.iEnumMethod))
	{
		EnumToDlgWithFiltr(hDlg,rootPath,str,iFrom,iTo,schConf.bEnumSubDir==1?true:false);
	}
	else
	{
		FindSelectsItemsDirectFolder(hDlg,rootPath,str,iFrom,iTo);
	}*/
	return;
}	