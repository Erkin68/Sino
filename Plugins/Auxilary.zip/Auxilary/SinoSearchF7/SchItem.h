#ifndef __SCHITEM_H__
#define __SCHITEM_H__

#include "windows.h"


typedef struct TSearchItem
{	
public:
		 TSearchItem();
	bool bEnumSubDir;
	struct 
	{	__int32 bFindForText: 1;
		__int32 iEnumMethod: 1;
		__int32 bFindForText_Unicode: 1;
		__int32 bFindForText_ASCII: 1;
		__int32 bFindForText_UpperCase: 1;
		__int32 bFindForExcldText: 1;
		__int32 bFindForExcldText_Unicode: 1;
		__int32 bFindForExcldText_ASCII: 1;
		__int32 bFindForExcldText_UpperCase: 1;
		__int32 bFindForAlterName: 1;
		__int32 bCrTimeBef: 1;
		__int32 bCrTimeAft: 1;
		__int32 bCrTimeBet: 1;
		__int32 bLstAccTimeBef: 1;
		__int32 bLstAccTimeAft: 1;
		__int32 bLastAccTimeBet: 1;
		__int32 bLstWrTimeBef: 1;
		__int32 bLstWrTimeAft: 1;
		__int32 bLstWrTimeBet: 1;
		__int32 bFileSz: 1;
		__int32 bFileAttr: 1;
		__int32 bFileAttArchive: 1;
		__int32 bFileAttCompr: 1;
		__int32 bFileAttDevice: 1;
		__int32 bFileAttDir: 1;
		__int32 bFileAttEncr: 1;
		__int32 bFileAttHidden: 1;
		__int32 bFileAttNormal: 1;
		__int32 bFileAttNotInd: 1;
		__int32 bFileAttOffl: 1;
		__int32 bFileAttReadOnly: 1;
		__int32 bFileAttRepPt: 1;//32
	};
	struct 
	{	__int32 bFileAttSparseFile: 1;
		__int32 bFileAttSys: 1;
		__int32 bFileAttTemp: 1;//35
		__int32 bFileAttVirt: 1;
		__int32 bFileAttArchiveEx: 1;
		__int32 bFileAttComprEx: 1;
		__int32 bFileAttDeviceEx: 1;
		__int32 bFileAttDirEx: 1;
		__int32 bFileAttEncrEx: 1;
		__int32 bFileAttHiddenEx: 1;
		__int32 bFileAttNormalEx: 1;
		__int32 bFileAttNotIndEx: 1;
		__int32 bFileAttOfflEx: 1;
		__int32 bFileAttReadOnlyEx: 1;
		__int32 bFileAttRepPtEx: 1;//32
		__int32 bFileAttSparseFileEx: 1;
		__int32 bFileAttSysEx: 1;
		__int32 bFileAttTempEx: 1;//35
		__int32 bFileAttVirtEx: 1;
		__int32 bSaveResultsLB: 1;		
	};

	wchar_t filtr[MAX_PATH];//spare for unicode
	wchar_t rootPath[MAX_PATH];//spare for unicode
	wchar_t FindForText[MAX_PATH];
	int  FindForTextLn;
	wchar_t FindForExcldText[2*MAX_PATH];
	int  FindForExcldTextLn;
	wchar_t altName[MAX_PATH];
	FILETIME CrTimeBef;
	//wchar_t crTimeBefD[MAX_PATH];
	//wchar_t crTimeBefT[MAX_PATH];
	FILETIME CrTimeAft;
	//wchar_t crTimeAftD[MAX_PATH];
	//wchar_t crTimeAftT[MAX_PATH];
	FILETIME CrTimeBet[2];
	//wchar_t crTimeBetBD[MAX_PATH];
	//wchar_t crTimeBetBT[MAX_PATH];
	//wchar_t crTimeBetAD[MAX_PATH];
	//wchar_t crTimeBetAT[MAX_PATH];
	FILETIME LstAccTimeBef;
	//wchar_t LstAccTimeBefD[MAX_PATH];
	//wchar_t LstAccTimeBefT[MAX_PATH];
	FILETIME LstAccTimeAft;
	//wchar_t LstAccTimeAftD[MAX_PATH];
	//wchar_t LstAccTimeAftT[MAX_PATH];
	FILETIME LastAccTimeBet[2];
	//wchar_t LastAccTimeBetBD[MAX_PATH];
	//wchar_t LastAccTimeBetBT[MAX_PATH];
	//wchar_t LastAccTimeBetAD[MAX_PATH];
	//wchar_t LastAccTimeBetAT[MAX_PATH];
	FILETIME LstWrTimeBef;
	//wchar_t LstWrTimeBefD[MAX_PATH];
	//wchar_t LstWrTimeBefT[MAX_PATH];
	FILETIME LstWrTimeAft;
	//wchar_t LstWrTimeAftD[MAX_PATH];
	//wchar_t LstWrTimeAftT[MAX_PATH];
	FILETIME LstWrTimeBet[2];
	//wchar_t LstWrTimeBetBefD[MAX_PATH];
	//wchar_t LstWrTimeBetBefT[MAX_PATH];
	//wchar_t LstWrTimeAftBefD[MAX_PATH];
	//wchar_t LstWrTimeAftBefT[MAX_PATH];
	wchar_t sFileSzEqu[4];
	wchar_t sFileSz[MAX_PATH];
	int  iFileSzQual;
} SearchItem;


#endif//__SCHITEM_H__