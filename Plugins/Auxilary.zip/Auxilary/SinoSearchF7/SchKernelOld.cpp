#include "SchKernel.h"
#include <stdio.h>
#include <malloc.h>
#include "SinSchF7.h"
#include "FindStrWthFltr.h"



NTSTATUS (WINAPI *pZwCreateFile)(PHANDLE, ACCESS_MASK, POBJECT_ATTRIBUTES,PIO_STATUS_BLOCK,PLARGE_INTEGER,ULONG,ULONG,ULONG,ULONG,PVOID,ULONG);
NTSTATUS (WINAPI *pRtlInitAnsiString)(PANSI_STRING,PCSZ);
NTSTATUS (WINAPI *pRtlAnsiStringToUnicodeString)(PCUNICODE_STRING,PANSI_STRING,BOOLEAN);
NTSTATUS (WINAPI *pZwQueryDirectoryFile)(HANDLE,HANDLE,PIO_APC_ROUTINE,PVOID,PIO_STATUS_BLOCK,PVOID,ULONG,FILE_INFORMATION_CLASS,BOOLEAN,PUNICODE_STRING,BOOLEAN);
NTSTATUS (WINAPI *pRtlUnicodeStringToAnsiString)(PANSI_STRING,PCUNICODE_STRING,BOOLEAN);
NTSTATUS (WINAPI *pZwClose)(HANDLE);

extern "C"
{

typedef struct TNSDirList{ char s[MAX_PATH]; }NSDirList;
int NSDirListCnt = 0;
int NSDirListMaxSz = 0;
NSDirList* pdirList = NULL;//
HWND dlg;char* fltrStr;int fltrFrom,fltrTo;

VOID LoadNTFuncs()
{
HMODULE hModule = LoadLibrary ("Ntdll.dll");
    //pRtlInitUnicodeString = (NTSTATUS (WINAPI*)(PUNICODE_STRING, PCWSTR)) GetProcAddress (hModule, "RtlInitUnicodeString");
	pZwCreateFile = (NTSTATUS(WINAPI*)(PHANDLE,ACCESS_MASK,POBJECT_ATTRIBUTES,PIO_STATUS_BLOCK,PLARGE_INTEGER,ULONG,ULONG,ULONG,ULONG,PVOID,ULONG))GetProcAddress(hModule,"ZwCreateFile");
    //pZwCreateEvent = (NTSTATUS (WINAPI*)(PHANDLE, ACCESS_MASK,POBJECT_ATTRIBUTES,EVENT_TYPE,BOOLEAN))GetProcAddress(hModule,"ZwCreateEvent");
    pZwQueryDirectoryFile = (NTSTATUS(WINAPI*)(HANDLE,HANDLE,PIO_APC_ROUTINE,PVOID, PIO_STATUS_BLOCK,PVOID,ULONG,FILE_INFORMATION_CLASS, BOOLEAN, PUNICODE_STRING, BOOLEAN))GetProcAddress(hModule,"ZwQueryDirectoryFile");
    //pZwWaitForSingleobject = (NTSTATUS (WINAPI*)(HANDLE,BOOLEAN,PLARGE_INTEGER))GetProcAddress(hModule,"ZwWaitForSingleObject");
    pRtlUnicodeStringToAnsiString = (NTSTATUS(WINAPI*)(PANSI_STRING,PCUNICODE_STRING,BOOLEAN))GetProcAddress(hModule,"RtlUnicodeStringToAnsiString");
    pRtlAnsiStringToUnicodeString = (NTSTATUS(WINAPI*)(PCUNICODE_STRING, PANSI_STRING,BOOLEAN))GetProcAddress(hModule,"RtlAnsiStringToUnicodeString");
	pRtlInitAnsiString = (NTSTATUS(WINAPI*)(PANSI_STRING,PCSZ))GetProcAddress(hModule,"RtlInitAnsiString");
    pZwClose = (NTSTATUS(WINAPI*)(HANDLE))GetProcAddress (hModule,"ZwClose");
	/*if((!pRtlInitUnicodeString) || (!pZwCreateFile) || (!pZwQueryDirectoryFile) ||
	//	(!pZwWaitForSingleobject) || (!pRtlUnicodeStringToAnsiString) || (!pZwClose))
	/*{	pRtlInitUnicodeString = NULL;
		pZwCreateFile = NULL;
		//pZwCreateEvent = NULL;
		pZwQueryDirectoryFile = NULL;
		pZwWaitForSingleobject = NULL;
		pRtlUnicodeStringToAnsiString = NULL;
		pRtlAnsiStringToUnicodeString = NULL;
		pRtlInitAnsiString = NULL;
		pZwClose = NULL;
}	*/}

}//end of extern "C"

VOID AddPathToEnumList(char* newPath)
{
	if(NSDirListCnt > NSDirListMaxSz-1)
	{	if(NSDirListMaxSz)
			pdirList = (NSDirList*)realloc(pdirList, sizeof(TNSDirList)*(NSDirListMaxSz+30));
		else
			pdirList = (NSDirList*)malloc(sizeof(TNSDirList)*(NSDirListMaxSz+30));
		if(pdirList)
			NSDirListMaxSz += 30;
	}
	MyStringCpy(pdirList[NSDirListCnt++].s,MAX_PATH,newPath);
}

char* GetFromPathEnumList()
{
	if((--NSDirListCnt)==-1)
	{	NSDirListCnt=0;
		return NULL;
	}
	if(NSDirListCnt<30)
	if(NSDirListMaxSz>30)
	{	pdirList = (NSDirList*)realloc(pdirList, sizeof(TNSDirList)*30);
		NSDirListMaxSz = 30;
	}
	return pdirList[NSDirListCnt].s;
}

BOOL SearchForContainTextPW(char *rootPath,wchar_t *sub,PFILE_BOTH_DIR_INFORMATION pf)
{
	int lnSub = MyStringLengthW(sub,MAX_PATH);
	if(!lnSub)return FALSE;

	if(item.bFindForText_ASCII)
	{	for(int i=0; i<lnSub; i++)
		{	if(!IsBin(sub[i]))
			{	MessageBox(NULL,"Please,use only digit symbols without space.","Binary filtr string error:",MB_OK);
				return FALSE;
		}	}
		if(lnSub%2)
		{	MessageBox(NULL,"Please,input pair symbols without space.","Binary filtr string length error:",MB_OK);
			return FALSE;
		}
		lnSub /= 2;
	}

	HANDLE h = CreateFile(rootPath,GENERIC_READ,
						  FILE_SHARE_READ,
						  NULL,
						  OPEN_EXISTING,
						  pf->FileAttributes,
						  NULL);
	if(INVALID_HANDLE_VALUE==h) return FALSE;

	char *buf = (char*)_malloca(4096);
	if(!buf) return FALSE;
	wchar_t *wbuf = (wchar_t*)_malloca(2*4096);
	if(!wbuf) return FALSE;

	int nr = 4096, rb = 1, dum = 0; wchar_t *pwbuf = wbuf;
	while(rb)
	{	if(!ReadFile(h,buf,nr,(DWORD*)&rb,NULL))break;
		if(!MultiByteToWideChar(CP_ACP,MB_PRECOMPOSED,buf,rb,pwbuf,rb)) break;
		wchar_t *pwbufCmp = wbuf;
		while(pwbufCmp<wbuf+dum+rb-lnSub+1)//for(int i=0; i<rb-lnSub+1; i++)//if(rb >= lnSub) ning o'zi edi;
		{	wchar_t *r; if(item.bFindForText_ASCII)
			{	r = MyStrCmpBinNW(pwbufCmp,(wchar_t*)sub,wbuf+dum+rb-lnSub+1-pwbufCmp,lnSub);
				pwbufCmp += (wchar_t*)(buf+dum+rb-lnSub+1)-pwbufCmp;
			}
			else
			{	if(item.bFindForText_UpperCase)r=(wchar_t*)MyStrCmpNotRelUpRegNW(pwbufCmp++,(wchar_t*)sub,lnSub);
				else r=(wchar_t*)MyStrCmpNW(pwbufCmp++,(wchar_t*)sub,lnSub);
			}
			if(r)
			{	CloseHandle(h);
				_freea(buf);
				_freea(wbuf);
				return TRUE;
		}	}
		//Qolgan dumini boshiga ko'chiramiz:
		if(rb)
		{	int ddum = 0;
			while(pwbufCmp<wbuf+dum+rb)//for(int k=rb-lnSub+1; k<rb; k++)
				wbuf[ddum++] = *pwbufCmp++;
			dum = ddum;
			pwbuf = wbuf + dum;
			nr = 4096 - dum;
	}	}

	CloseHandle(h);
	_freea(buf);
	_freea(wbuf);
	return FALSE;
}

BOOL SearchForContainTextP(char *rootPath,char *sub,PFILE_BOTH_DIR_INFORMATION pf)
{
	int lnSub = MyStringLength(sub,MAX_PATH);
	if(!lnSub)return FALSE;

	if(item.bFindForText_ASCII)
	{	for(int i=0; i<lnSub; i++)
		{	if(!IsBin(sub[i]))
			{	MessageBox(NULL,"Please,use only digit symbols without space.","Binary filtr string error:",MB_OK);
				return FALSE;
		}	}
		if(lnSub%2)
		{	MessageBox(NULL,"Please,input pair symbols without space.","Binary filtr string length error:",MB_OK);
			return FALSE;
		}
		lnSub /= 2;
	}

	HANDLE h = CreateFile(rootPath,GENERIC_READ,
						  FILE_SHARE_READ,
						  NULL,
						  OPEN_EXISTING,
						  pf->FileAttributes,//|FILE_FLAG_SEQUENTIAL_SCAN,
						  NULL);
	/*IO_STATUS_BLOCK Iosb;OBJECT_ATTRIBUTES fileAttributes;wchar_t pathW[MAX_PATH];
	MultiByteToWideChar(CP_ACP,MB_PRECOMPOSED,path,MAX_PATH,pathW,MAX_PATH);
	UNICODE_STRING uniPath;
	pRtlInitUnicodeString(&uniPath, pathW);
	InitializeObjectAttributes(&fileAttributes, &uniPath, OBJ_CASE_INSENSITIVE, 0, 0);
	if(STATUS_SUCCESS!=pNtCreateFile(&h,GENERIC_READ,
						  &fileAttributes,
						  &Iosb,
						  0,
						  FILE_ATTRIBUTE_NORMAL,
						  FILE_SHARE_READ,
						  FILE_OPEN_IF,
						  FILE_NON_DIRECTORY_FILE,
						  0,
						  0))
		  return FALSE;*/
	if(INVALID_HANDLE_VALUE==h) return FALSE;

	//char *buf = (char*)_malloca(32768);
	//if(!buf) return FALSE;
	char buf[32768];
//static __declspec(align(32)) char buf[4096];

	int nr = 0, rb = 1, dumLn = lnSub-1;
	while(rb>0)
	{	if(nr)
		{	if(!ReadFile(h,buf+dumLn,32768-dumLn,(DWORD*)&rb,NULL))
				break;
		} else
		{	if(!ReadFile(h,buf,32768,(DWORD*)&rb,NULL))
				break;
		} char *pbuf = buf;
		if(rb>0)
		{	while(pbuf<buf+rb-dumLn)
			{	char* r; if(item.bFindForText_ASCII)
				{	r = MyStrCmpBinN(buf,sub,nr?rb:rb-dumLn,lnSub);
					pbuf += rb-dumLn;
				}
				else
				{	if(item.bFindForText_UpperCase)r=(char*)MyStrCmpNotRelUpRegN(pbuf++,sub,lnSub);
					else
					{	r=MyStrCmpNN(buf,sub,nr?rb:rb-dumLn,lnSub);
						pbuf += rb-dumLn;
				}	}
				if(r)
				{	CloseHandle(h);
					//_freea(buf);
					return TRUE;
			}	}
			//Qolgan dumini boshiga ko'chiramiz:
			if(rb) {memcpy(buf, buf + rb - dumLn, dumLn); ++nr;}
			else nr = 0;
	}	}

	CloseHandle(h);
	//pNtClose(h);
	//_freea(buf);
	return FALSE;
}

BOOL SearchForNotContainText(char *rootPath,char *sub,PFILE_BOTH_DIR_INFORMATION pf)
{
	int lnSub = MyStringLength(sub,MAX_PATH);
	if(!lnSub)return FALSE;

	if(item.bFindForExcldText_ASCII)
	{	for(int i=0; i<lnSub; i++)
		{	if(sub[i]<'0' || sub[i]>'9')
			{	MessageBox(NULL,"Please,use only digit symbols without space.","Binary filtr string error:",MB_OK);
				return FALSE;
		}	}
		if(lnSub%2)
		{	MessageBox(NULL,"Please,input pair symbols without space.","Binary filtr string length error:",MB_OK);
			return FALSE;
		}
		lnSub /= 2;
	}

	HANDLE h = CreateFile(rootPath,GENERIC_READ,
						  FILE_SHARE_READ,
						  NULL,
						  OPEN_EXISTING,
						  pf->FileAttributes,
						  NULL);
	if(!h) return FALSE;

	char *buf = (char*)_malloca(4096);
	if(!buf) return FALSE;

	int nr = 4096, rb = 1, dum = 0; char *pbuf = buf;
	while(rb)
	{	if(!ReadFile(h,pbuf,nr,(DWORD*)&rb,NULL))break;
		char *pbufCmp = buf;
		while(pbufCmp<buf+dum+rb-lnSub+1)//for(int i=0; i<rb-lnSub+1; i++)//if(rb >= lnSub) ning o'zi edi;
		{	char *r; if(item.bFindForExcldText_ASCII)
			{	r = MyStrCmpBinN(pbufCmp,sub,buf+dum+rb-lnSub+1-pbufCmp,lnSub);
				pbufCmp += buf+dum+rb-lnSub+1-pbufCmp;
			}
			else
			{	if(item.bFindForExcldText_UpperCase)r=(char*)MyStrCmpNotRelUpRegN(pbufCmp++,sub,lnSub);
				else r=(char*)MyStrCmpN(pbufCmp++,sub,lnSub);
			}
			if(r)
			{	CloseHandle(h);
				_freea(buf);
				return FALSE;
		}	}
		//Qolgan dumini boshiga ko'chiramiz:
		int ddum = 0;
		while(pbufCmp<buf+dum+rb)//for(int k=rb-lnSub+1; k<rb; k++)
			buf[ddum++] = *pbufCmp++;
		dum = ddum;
		pbuf = buf + dum;
		nr = 4096 - dum;
	}

	CloseHandle(h);
	_freea(buf);
	return TRUE;
}

BOOL SearchForNotContainTextW(char *rootPath,char *sub,PFILE_BOTH_DIR_INFORMATION pf)
{
	int lnSub = MyStringLengthW((wchar_t*)sub,MAX_PATH);
	if(!lnSub)return FALSE;

	if(item.bFindForExcldText_ASCII)
	{	for(int i=0; i<lnSub; i++)
		{	if(sub[i]<'0' || sub[i]>'9')
			{	MessageBox(NULL,"Please,use only digit symbols without space.","Binary filtr string error:",MB_OK);
				return FALSE;
		}	}
		if(lnSub%2)
		{	MessageBox(NULL,"Please,input pair symbols without space.","Binary filtr string length error:",MB_OK);
			return FALSE;
		}
		lnSub /= 2;
	}

	HANDLE h = CreateFile(rootPath,GENERIC_READ,
						  FILE_SHARE_READ,
						  NULL,
						  OPEN_EXISTING,
						  pf->FileAttributes,
						  NULL);
	if(!h) return FALSE;

	char *buf = (char*)_malloca(4096);
	if(!buf) return FALSE;
	wchar_t *wbuf = (wchar_t*)_malloca(2*4096);
	if(!wbuf) return FALSE;

	int nr = 4096, rb = 1, dum = 0; wchar_t *pwbuf = wbuf;
	while(rb)
	{	if(!ReadFile(h,buf,nr,(DWORD*)&rb,NULL))break;
		if(!MultiByteToWideChar(CP_ACP,MB_PRECOMPOSED,buf,rb,pwbuf,rb)) break;
		wchar_t *pwbufCmp = wbuf;
		while(pwbufCmp<wbuf+dum+rb-lnSub+1)//for(int i=0; i<rb-lnSub+1; i++)//if(rb >= lnSub) ning o'zi edi;
		{	wchar_t* r; if(item.bFindForExcldText_ASCII)
				r = MyStrCmpBinNW(pwbufCmp++,(wchar_t*)sub,(wchar_t*)(buf+dum+rb-lnSub+1)-pwbufCmp,lnSub);
			else
			{	if(item.bFindForExcldText_UpperCase)r=(wchar_t*)MyStrCmpNotRelUpRegNW(pwbufCmp++,(wchar_t*)sub,lnSub);
				else r=(wchar_t*)MyStrCmpNW(pwbufCmp++,(wchar_t*)sub,lnSub);
			}
			if(r)
			{	CloseHandle(h);
				_freea(buf);
				_freea(wbuf);
				return FALSE;
		}	}
		//Qolgan dumini boshiga ko'chiramiz:
		int ddum = 0;
		while(pwbufCmp<wbuf+dum+rb)//for(int k=rb-lnSub+1; k<rb; k++)
			wbuf[ddum++] = *pwbufCmp++;
		dum = ddum;
		pwbuf = wbuf + dum;
		nr = 4096 - dum;
	}

	CloseHandle(h);
	_freea(buf);
	_freea(wbuf);
	return TRUE;
}

//Qo'shimcha parametrlar asosida qidirish:
//Qo'shimcha parametrlar asosida qidirish:
BOOL CheckOtherSearchConditionsDirectFolder(char* rootPath,PFILE_BOTH_DIR_INFORMATION pf, int type)
{
DWORD bCndtns = 0x00000000;

	if(0==type)//file
	{//1.1-Page, Filtr va RootPath -->> BeginSearch da;
	 //2.1-Page, Find for text:
	 if(item.bFindForText)
	 {if(item.FindForTextLn)
	  {FindStrWthFltr fs(item.FindForText);
	   for(int s=0; s<fs.GetNumStrs(); s++)
	   {	char *sub=fs.GetSubstr(s);
			if(item.bFindForExcldText_Unicode?SearchForContainTextPW(rootPath,(wchar_t*)sub,pf):SearchForContainTextP(rootPath,sub,pf))
			{	bCndtns |= 0x00000001;//[0] = TRUE;
		 		goto ToNotContainText;
	  }}	}
	  //bCndtns[0] = FALSE;
	 }
	 else bCndtns |= 0x00000001;//[0] = TRUE;
	 //3.1-Page, Find for do not contain text:
ToNotContainText:
	 if(item.bFindForExcldText)
	 {if(item.FindForExcldTextLn)
	  {FindStrWthFltr fs(item.FindForExcldText);
	   for(int s=0; s<fs.GetNumStrs(); s++)
	   {	char *sub=fs.GetSubstr(s);
			if(item.bFindForExcldText_Unicode?SearchForNotContainTextW(rootPath,sub,pf):SearchForNotContainText(rootPath,sub,pf))
		    {	bCndtns |= 0x00000001;//[0] = TRUE;
		 		goto ToNotContainText;
	  }}	}   
	  //bCndtns[1] = FALSE;
	 }
	 else bCndtns |= 0x00000002;//[1] = TRUE;

	 if(item.bFileSz)
	 {if(!item.sFileSzEqu[0])
		bCndtns |=0x00000004;//[2] = TRUE;
	  else
	  { if(!item.sFileSz[0])
		  bCndtns |=0x00000004;//[2] = TRUE;
	    else
		{	if(CB_ERR==item.iFileSzQual) bCndtns |= 0x00000003;//[2] = TRUE;
			else
			{	__int64 sz = (__int64)MyAtoU64(item.sFileSz);
				for(int i=0; i<item.iFileSzQual; i++)
					sz = sz << 10;
				if('>'==item.sFileSzEqu[0])
				{	if(sz < pf->EndOfFile/*AllocationSize*/.QuadPart)
						bCndtns |= 0x00000004;
					//bCndtns[2] = (sz < fsz);
				}
				else if('<'==item.sFileSzEqu[0])
				{	if(sz > pf->EndOfFile/*AllocationSize*/.QuadPart)
						bCndtns |= 0x00000004;
					//bCndtns[2] = (sz > fsz);
				}
				else //if('='==item.sFileSzEqu[0])
				{	if(sz == pf->EndOfFile/*AllocationSize*/.QuadPart)
						bCndtns |= 0x00000004;
					//bCndtns[2] = (sz == fsz);
	 }}	}	}	}
	 else bCndtns |= 0x00000004;//[2] = TRUE;
	}
	else//if(1==0)//folder
	{//1.1-Page, Filtr va RootPath -->> BeginSearch da;
	 //2.1-Page, Find for text:
	 //if(BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_TEXT_SEACH),BM_GETCHECK,0,0))
	 if(item.bFindForText)
		 return FALSE;
	 //3.1-Page, Find for do not contain text:
	 if(item.bFindForExcldText)
		 return FALSE;
	 //4.2-Page, Find for alternative name:
	 if(item.bFindForAlterName)
		 return FALSE;
	 if(item.bFileSz)
		 return FALSE;
	 bCndtns |= 0x00000007;//bCndtns[0] = bCndtns[1] = bCndtns[2] = TRUE;
	}

	//4.2-Page, Find for alternative name:
//FindAlternName:
	if(item.bFindForAlterName)
	{if(item.altName[0])
	{	if(0==wcscmp(pf->ShortName,item.altNameW))
			bCndtns |= 0x00000008;
	 }
	} else bCndtns |= 0x00000008;//[3] = TRUE;

	//5.2-Page, Find for creation time before:
	if(item.bCrTimeBef)
	{	if(-1!=CmpFILETIMEs(&item.CrTimeBef,&pf->CreationTime))
			bCndtns |= 0x00000010;
	}
	else bCndtns |= 0x00000010;//[4] = TRUE;

	//6.2-Page, Find for creation time after:
	if(item.bCrTimeAft)
	{	if(1!=CmpFILETIMEs(&item.CrTimeAft,&pf->CreationTime))
			bCndtns |= 0x00000020;
	}
	else bCndtns |= 0x00000020;//bCndtns[5] = TRUE;

	//7.2-Page, Find for creation time between:
	if(item.bCrTimeBet)
	{	if(1==CmpFILETIMEsBetween(&item.CrTimeBet[0],&item.CrTimeBet[1],&pf->CreationTime))
			bCndtns |= 0x00000040;
	}
	else bCndtns |= 0x00000040;//bCndtns[6] = TRUE;

	//8.2-Page, Find for last access time before:
	if(item.bLstAccTimeBef)
	{	if(-1!=CmpFILETIMEs(&item.LstAccTimeBef,&pf->CreationTime))
			bCndtns |= 0x00000080;
	}
	else bCndtns |= 0x00000080;//bCndtns[7] = TRUE;

	//9.2-Page, Find last access time after:
	if(item.bLstAccTimeAft)
	{	if(1!=CmpFILETIMEs(&item.LstAccTimeAft,&pf->LastAccessTime))
			bCndtns |= 0x00000100;
	}
	else bCndtns |= 0x00000100;//bCndtns[8] = TRUE;

	//10.2-Page, Find for last access time between:
	if(item.bLastAccTimeBet)
	{	if(1==CmpFILETIMEsBetween(&item.LastAccTimeBet[0],&item.LastAccTimeBet[1],&pf->LastAccessTime))
			bCndtns |= 0x00000200;
	}
	else bCndtns |= 0x00000200;//bCndtns[9] = TRUE;

	//11.2-Page, Find for last write time before:
	if(item.bLstWrTimeBef)
	{	if(-1!=CmpFILETIMEs(&item.LstWrTimeBef,&pf->LastWriteTime))
			bCndtns |= 0x00000400;
	}
	else bCndtns |= 0x00000400;//bCndtns[10] = TRUE;

	//12.2-Page, Find last write time after:
	if(item.bLstWrTimeAft)
	{	if(1!=CmpFILETIMEs(&item.LstWrTimeAft,&pf->LastWriteTime))
			bCndtns |= 0x00000800;
	}
	else bCndtns |= 0x00000800;//bCndtns[11] = TRUE;

	//13.2-Page, Find for last write time between:
	if(item.bLstWrTimeBet)
	{	if(1==CmpFILETIMEsBetween(&item.LstWrTimeBet[0],&item.LstWrTimeBet[1],&pf->LastWriteTime))
			bCndtns |= 0x00001000;
	}
	else bCndtns |= 0x00001000;//bCndtns[12] = TRUE;

	//14.2-Page, Find for file attribute:
	if(item.bFileAttr)
	{	if(item.bFileAttArchive)
		if((FILE_ATTRIBUTE_ARCHIVE & pf->FileAttributes) != 0)
			bCndtns |= 0x00002000;
		if(item.bFileAttCompr)
		if((FILE_ATTRIBUTE_COMPRESSED & pf->FileAttributes) != 0)
			bCndtns |= 0x00004000;
		if(item.bFileAttDevice)
		if((FILE_ATTRIBUTE_DEVICE & pf->FileAttributes) != 0)
			bCndtns |= 0x00008000;
		if(item.bFileAttDir)
		if((FILE_ATTRIBUTE_DIRECTORY & pf->FileAttributes) != 0)
			bCndtns |= 0x00010000;
		if(item.bFileAttEncr)
		if((FILE_ATTRIBUTE_ENCRYPTED & pf->FileAttributes) != 0)
			bCndtns |= 0x00020000;
		if(item.bFileAttHidden)
		if((FILE_ATTRIBUTE_HIDDEN & pf->FileAttributes) != 0)
			bCndtns |= 0x00040000;
		if(item.bFileAttNormal)
		if((FILE_ATTRIBUTE_NORMAL & pf->FileAttributes) != 0)
			bCndtns |= 0x00080000;
		if(item.bFileAttNotInd)
		if((FILE_ATTRIBUTE_NOT_CONTENT_INDEXED & pf->FileAttributes) != 0)
			bCndtns |= 0x00100000;
		if(item.bFileAttOffl)
		if((FILE_ATTRIBUTE_OFFLINE & pf->FileAttributes) != 0)
			bCndtns |= 0x00200000;
		if(item.bFileAttReadOnly)
		if((FILE_ATTRIBUTE_READONLY & pf->FileAttributes) != 0)
			bCndtns |= 0x00400000;
		if(item.bFileAttRepPt)
		if((FILE_ATTRIBUTE_REPARSE_POINT & pf->FileAttributes) != 0)
			bCndtns |= 0x00800000;
		if(item.bFileAttSparseFile)
		if((FILE_ATTRIBUTE_SPARSE_FILE & pf->FileAttributes) != 0)
			bCndtns |= 0x01000000;
		if(item.bFileAttSys)
		if((FILE_ATTRIBUTE_SYSTEM & pf->FileAttributes) != 0)
			bCndtns |= 0x02000000;
		if(item.bFileAttTemp)
		if((FILE_ATTRIBUTE_TEMPORARY & pf->FileAttributes) != 0)
			bCndtns |= 0x04000000;
		if(item.bFileAttVirt)
		if((FILE_ATTRIBUTE_VIRTUAL & pf->FileAttributes) != 0)
			bCndtns |= 0x08000000;
	}
	else
	{	bCndtns |= 0x0fffe000;
	}

	//Hamma usloviyalarni tekshirib chiqdik, endi qaytamiz:
	if(0x0fffffff==bCndtns)
		return TRUE;
	return FALSE;
}

bool AddToDlgCheckCond(PCHAR pth,int attr,PFILE_BOTH_DIR_INFORMATION di)
{
	FindStrWthFltr fs(item.filtr);
	bool r=fs.CheckNameAndExt(item.rootPath);
	if(r)
	{	if(file==attr)
		{	if(!CheckOtherSearchConditionsDirectFolder(pth,di,0))
				return false;
			SendMessage(hResultsLB,LB_ADDSTRING,0,(LPARAM)pth);
			//SendMessage(hResultsLB,WM_PAINT,0,0);
			++search.iFoundFiles;
		} else if(item.filtr[0]!=0 && (!item.bFindForText) && (!item.bFindForExcldText))//folder selStrLen
		{	if(!CheckOtherSearchConditionsDirectFolder(pth,di,0))
				return false;
			char fullName[MAX_PATH+36] = "<";
			int l=1+MyStringCpy(&fullName[1],MAX_PATH,pth);
			fullName[l++]='>';//MyStringCat(fullName,MAX_PATH+36,">");
			fullName[l]=0;
			SendMessage(hResultsLB,LB_ADDSTRING,0,(LPARAM)fullName);
			//SendMessage(hResultsLB,WM_PAINT,0,0);
			++search.iFoundFolders;
	}	}
	else
	{	//Agar hech narsa belgilamagan bo'lsayam dopoln.parametrlar bo'yicha poisk qilsun;
		if(0==item.filtr[0])//if((!selStrLen) || (strstr(item.filtr,"*.*")))
		if(!item.bFindForText)
		if(!item.bFindForExcldText)
		if(!item.bFileSz)
		if(!item.bFindForAlterName)
		if(!item.bCrTimeBef)
		if(!item.bCrTimeAft)
		if(!item.bCrTimeBet)
		if(!item.bLstAccTimeBef)
		if(!item.bLstAccTimeAft)
		if(!item.bLastAccTimeBet)
		if(!item.bLstWrTimeBef)
		if(!item.bLstWrTimeAft)
		if(!item.bLstWrTimeBet)
		if(!item.bFileAttr)
		{	//Add to info edit:
			if(file==attr)
			{	SendMessage(hResultsLB,LB_ADDSTRING,0,(LPARAM)pth);
				//SendMessage(hResultsLB,WM_PAINT,0,0);
				++search.iFoundFiles;
			} else//folder
			{	char fullName[MAX_PATH+36] = "<";
				int l = 1+MyStringCpy(&fullName[1],MAX_PATH,pth);
				fullName[l++]='>';//MyStringCat(fullName,MAX_PATH+36,">");
				fullName[l]=0;
				SendMessage(hResultsLB,LB_ADDSTRING,0,(LPARAM)fullName);
				//SendMessage(hResultsLB,WM_PAINT,0,0);
				++search.iFoundFolders;
			}
			r = true;
	}	}
	return r;
}

void EnumDirToDlgWithFiltr(char* pth,bool bEnumSubDir)
{
UNICODE_STRING RootDirectoryName;
ANSI_STRING as;
OBJECT_ATTRIBUTES RootDirectoryAttributes;
NTSTATUS ntStatus = STATUS_SUCCESS;
HANDLE RootDirectoryHandle;
IO_STATUS_BLOCK Iosb;
//HANDLE Event;
PUCHAR Buffer[65536];
CHAR   szBuffer[2*MAX_PATH];
int	   szBufferLn;
PFILE_BOTH_DIR_INFORMATION DirInformation;
 
    szBufferLn = _snprintf_s(szBuffer,sizeof(szBuffer),"\\??\\%s",pth);
	if('*'==szBuffer[szBufferLn-1])//MyStringRemoveLastChar(szBuffer,MAX_PATH,'*');
		szBuffer[--szBufferLn]=0;
	ntStatus = pRtlInitAnsiString(&as,szBuffer);

    if (!NT_SUCCESS(ntStatus))
        return;// ntStatus;

	ntStatus = pRtlAnsiStringToUnicodeString(&RootDirectoryName,&as,TRUE);
    if (!NT_SUCCESS(ntStatus))
        return;// ntStatus;
    InitializeObjectAttributes(&RootDirectoryAttributes, &RootDirectoryName, OBJ_CASE_INSENSITIVE, 0, 0);

    ntStatus = pZwCreateFile(&RootDirectoryHandle,
        GENERIC_READ|SYNCHRONIZE,
        &RootDirectoryAttributes,
        &Iosb,
        0,
        FILE_ATTRIBUTE_DIRECTORY,
        FILE_SHARE_READ,// | FILE_SHARE_WRITE | FILE_SHARE_DELETE,
        FILE_OPEN,
        FILE_DIRECTORY_FILE|FILE_SYNCHRONOUS_IO_NONALERT,
        0, 0);
 
    if (!NT_SUCCESS(ntStatus))
        return;// ntStatus;
    
    //ntStatus = pZwCreateEvent(&Event, GENERIC_ALL, 0, NotificationEvent, FALSE);
    //if (!NT_SUCCESS(ntStatus))
    //    return;// ntStatus;

Loop:
    //if(pZwQueryDirectoryFile(RootDirectoryHandle,
	ntStatus = pZwQueryDirectoryFile(RootDirectoryHandle,
   //    Event, 0, 0,
		NULL,NULL,NULL,
        &Iosb,
        Buffer,
        sizeof(Buffer),
        FileBothDirectoryInformation,
        FALSE,
        NULL,
		FALSE);
    //    FALSE) == STATUS_PENDING)
    //{
    //    ntStatus = ((pZwWaitForSingleobject)(Event, TRUE, 0));
    //}
    if (!NT_SUCCESS(ntStatus))
        goto End;
	if(STATUS_NO_MORE_FILES==Iosb.Status)
		goto End;

	//szBuffer yuqoridagi koda kosvenno ishlatiladi, shu samab shu yerdan
	//szBufferLn = MyStringLength(szBuffer,MAX_PATH);
	if('\\'!=szBuffer[szBufferLn-1])
	if(':'!=szBuffer[szBufferLn-2])
	{	szBuffer[szBufferLn++]='\\';//MyStringCat(szBuffer,MAX_PATH,"\\");
		szBuffer[szBufferLn]=0;//++szBufferLn;		
	}

	static int c=0;
    DirInformation = (PFILE_BOTH_DIR_INFORMATION) Buffer;
    while (1)
    {	UNICODE_STRING EntryName;
        EntryName.MaximumLength = EntryName.Length = (USHORT) DirInformation -> FileNameLength;
        EntryName.Buffer = &DirInformation -> FileName[0];
        pRtlUnicodeStringToAnsiString(&as, &EntryName, TRUE);

		MyStringCpy(&szBuffer[szBufferLn],MAX_PATH-szBufferLn,as.Buffer);//MyStringCat(szBuffer,MAX_PATH,as.Buffer);
		if(FILE_ATTRIBUTE_DIRECTORY & DirInformation->FileAttributes)
		{	if(IsCrntOrPrntDirAttrb(as.Buffer))
			{	AddToDlgCheckCond(&szBuffer[4],folder,DirInformation);//as.Buffer
				if(bEnumSubDir)
					AddPathToEnumList(&szBuffer[4]);//as.Buffer
				//Add to info edit:
				SetWindowText(hInfoEdit,&szBuffer[3]);//as.Buffer
				SendMessage(hInfoEdit,WM_PAINT,0,0);
		}	}
		else
		{	AddToDlgCheckCond(&szBuffer[4],file,DirInformation);//as.Buffer
		}
		szBuffer[szBufferLn] = 0;//pth, ya'ni rootni qaytib joyiga qo'yamiz:

		static int k=0;
		if(k++==150)
		{	MSG msg;if( PeekMessage( &msg, NULL, 0U, 0U, PM_REMOVE ) )
				DispatchMessage ( &msg );
			k=0;
		}
		if(search.bStop)break;

        if (0 == DirInformation -> NextEntryOffset)
            break;
        else if((PUCHAR*)DirInformation > Buffer+65536)
			break;
        else
            DirInformation = (PFILE_BOTH_DIR_INFORMATION) (((PUCHAR)DirInformation) + DirInformation -> NextEntryOffset);
    }
	if(Iosb.Information>0)
		goto Loop;
End:
    pZwClose(RootDirectoryHandle);
    return;// ntStatus;
}
	
void EnumToDlgWithFiltr(HWND hDlg,char* rootPath,char* str,int iFrom,int iTo,bool bEnumSubDir)
{
//prepare:
	if(NSDirListCnt)NSDirListCnt = 0;
	dlg = hDlg;fltrStr = str; fltrFrom = iFrom; fltrTo = iTo;
	AddPathToEnumList(rootPath);
	char* pth;
	while(NULL!=(pth = GetFromPathEnumList()))
	{	EnumDirToDlgWithFiltr(pth,bEnumSubDir);
}	}