#define _CRT_SECURE_NO_WARNINGS

#include "windows.h"
//#include "resource.h"
#include "stdio.h"



#define MAX_STRINGS 51

LPVOID pResultsLBtoPanelBuf=0;
wchar_t **strngs=NULL;
HMODULE plgnDllInst;
VOID LoadNTFuncs();
//void saveOptCpp(Search*);

extern int fscanLineString(FILE*,int,wchar_t*);


BOOL APIENTRY DllMain(HMODULE hModule,DWORD ul_reason_for_call,LPVOID lpReserved)
{
FILE *f;
int i,l;
wchar_t *pend,dllname[260],mnuStr[64];


	//static int ii=0;
	//char ss[32];sprintf(ss,"\n %d ",ii++);
	//OutputDebugStringA(ss);
	//OutputDebugStringA(GetWinNotifyText(message));
	//sprintf(ss," %x %x",wParam,lParam);
	//OutputDebugStringA(ss);

	switch(ul_reason_for_call)
	{	case DLL_PROCESS_ATTACH:
			plgnDllInst=hModule;
			if(strngs)break;
			strngs = (wchar_t **)malloc(MAX_STRINGS*sizeof(wchar_t*));
			GetModuleFileNameW(hModule,dllname,260);
			LoadNTFuncs();
			pend = wcsrchr(dllname,'\\')+1;
			if(pend) *pend = 0;
			if(GetEnvironmentVariable(L"languge",mnuStr,64))//Language instartup qo'yadur;
			{	if(!wcscmp(mnuStr,L"russian"))
					wcscat(dllname,L"SrchStrsRus.txt");
				else if(!wcscmp(mnuStr,L"uzbekl"))
					wcscat(dllname,L"SrchStrsUZBL.txt");
				else if(!wcscmp(mnuStr,L"uzbekk"))
					wcscat(dllname,L"SrchStrsUZBK.txt");
				else//if(wcscmp(mnuStr,L"Exit")
					wcscat(dllname,L"SrchStrsEng.txt");
			}	
			else wcscat(dllname,L"SrchStrsEng.txt");

			f=_wfopen(dllname,L"r,ccs=UNICODE");
			if(f)
			{	wchar_t s[260];fwscanf(f,L"%s", s);
				if(wcscmp(s,L"Plugin")) goto NillStr;
				fwscanf(f,L"%s", s);
				if(wcscmp(s,L"sinsch32.dll")) goto NillStr;
				fwscanf(f,L"%s", s);
				if(wcscmp(s,L"Strings:")) goto NillStr;
				for(i=0; i<MAX_STRINGS; i++)
				{	int t;fwscanf_s(f,L"%d", &t);
					if(t-1!=i) goto NillStr;
					//l=fwscanf(f,L"%s", s);
					l=fscanLineString(f,256,s);
					strngs[i]=(wchar_t*)malloc(sizeof(wchar_t)*(l+1));
					memcpy(strngs[i],s,sizeof(wchar_t)*(l+1));
				}
				fclose(f);
			}
			else
			{int l;
NillStr:
				l=(int)wcslen(L"Find files:")+1;
					strngs[0]=(wchar_t*)malloc(2*l);wcscpy(strngs[0],L"Find files:");
				l=(int)wcslen(L"Filter:")+1;
					strngs[1]=(wchar_t*)malloc(2*l);wcscpy(strngs[1],L"Filter:");
				l=(int)wcslen(L"Storage disks:")+1;
					strngs[2]=(wchar_t*)malloc(2*l);wcscpy(strngs[2],L"Storage disks:");
				l=(int)wcslen(L"Root path:")+1;
					strngs[3]=(wchar_t*)malloc(2*l);wcscpy(strngs[3],L"Root path:");
				l=(int)wcslen(L"Add")+1;
					strngs[4]=(wchar_t*)malloc(2*l);wcscpy(strngs[4],L"Add");
				l=(int)wcslen(L"Find for text(separate-';'):")+1;
					strngs[5]=(wchar_t*)malloc(2*l);wcscpy(strngs[5],L"Find for text(separate-';'):");
				l=(int)wcslen(L"1-byte")+1;
					strngs[6]=(wchar_t*)malloc(2*l);wcscpy(strngs[6],L"1-byte");
				l=(int)wcslen(L"Upper key sensivity")+1;
					strngs[7]=(wchar_t*)malloc(2*l);wcscpy(strngs[7],L"Upper key sensivity");
				l=(int)wcslen(L"Find for not contain text(separate-';'):")+1;
					strngs[8]=(wchar_t*)malloc(2*l);wcscpy(strngs[8],L"Find for not contain text(separate-';'):");
				l=(int)wcslen(L"Start")+1;
					strngs[9]=(wchar_t*)malloc(2*l);wcscpy(strngs[9],L"Start");
				l=(int)wcslen(L"OK")+1;
					strngs[10]=(wchar_t*)malloc(2*l);wcscpy(strngs[10],L"OK");
				l=(int)wcslen(L"Cancel")+1;
					strngs[11]=(wchar_t*)malloc(2*l);wcscpy(strngs[11],L"Cancel");
				l=(int)wcslen(L"Find for alternative name:")+1;
					strngs[12]=(wchar_t*)malloc(2*l);wcscpy(strngs[12],L"Find for alternative name:");
				l=(int)wcslen(L"Creation date and time before:")+1;
					strngs[13]=(wchar_t*)malloc(2*l);wcscpy(strngs[13],L"Creation date and time before:");
				l=(int)wcslen(L"Creation date and time after:")+1;
					strngs[14]=(wchar_t*)malloc(2*l);wcscpy(strngs[14],L"Creation date and time after:");
				l=(int)wcslen(L"Creation date and time between:")+1;
					strngs[15]=(wchar_t*)malloc(2*l);wcscpy(strngs[15],L"Creation date and time between:");
				l=(int)wcslen(L"Last access date and time before:")+1;
					strngs[16]=(wchar_t*)malloc(2*l);wcscpy(strngs[16],L"Last access date and time before:");
				l=(int)wcslen(L"Last access date and time after:")+1;
					strngs[17]=(wchar_t*)malloc(2*l);wcscpy(strngs[17],L"Last access date and time after:");
				l=(int)wcslen(L"Last access date and time between:")+1;
					strngs[18]=(wchar_t*)malloc(2*l);wcscpy(strngs[18],L"Last access date and time between:");
				l=(int)wcslen(L"Last write date and time before:")+1;
					strngs[19]=(wchar_t*)malloc(2*l);wcscpy(strngs[19],L"Last write date and time before:");
				l=(int)wcslen(L"Last write date and time after:")+1;
					strngs[20]=(wchar_t*)malloc(2*l);wcscpy(strngs[20],L"Last write date and time after:");
				l=(int)wcslen(L"Last write date and time between:")+1;
					strngs[21]=(wchar_t*)malloc(2*l);wcscpy(strngs[21],L"Last write date and time between:");
				l=(int)wcslen(L"File size:")+1;
					strngs[22]=(wchar_t*)malloc(2*l);wcscpy(strngs[22],L"File size:");
				l=(int)wcslen(L"File attribute:")+1;
					strngs[23]=(wchar_t*)malloc(2*l);wcscpy(strngs[23],L"File attribute:");
				l=(int)wcslen(L"Archive")+1;
					strngs[24]=(wchar_t*)malloc(2*l);wcscpy(strngs[24],L"Archive");
				l=(int)wcslen(L"Compressed")+1;
					strngs[25]=(wchar_t*)malloc(2*l);wcscpy(strngs[25],L"Compressed");
				l=(int)wcslen(L"Device")+1;
					strngs[26]=(wchar_t*)malloc(2*l);wcscpy(strngs[26],L"Device");
				l=(int)wcslen(L"Directory")+1;
					strngs[27]=(wchar_t*)malloc(2*l);wcscpy(strngs[27],L"Directory");
				l=(int)wcslen(L"Encrypted")+1;
					strngs[28]=(wchar_t*)malloc(2*l);wcscpy(strngs[28],L"Encrypted");
				l=(int)wcslen(L"Hidden")+1;
					strngs[29]=(wchar_t*)malloc(2*l);wcscpy(strngs[29],L"Hidden");
				l=(int)wcslen(L"Normal")+1;
					strngs[30]=(wchar_t*)malloc(2*l);wcscpy(strngs[30],L"Normal");
				l=(int)wcslen(L"Not indexed")+1;
					strngs[31]=(wchar_t*)malloc(2*l);wcscpy(strngs[31],L"Not indexed");
				l=(int)wcslen(L"Offline")+1;
					strngs[32]=(wchar_t*)malloc(2*l);wcscpy(strngs[32],L"Offline");
				l=(int)wcslen(L"Read only")+1;
					strngs[33]=(wchar_t*)malloc(2*l);wcscpy(strngs[33],L"Read only");
				l=(int)wcslen(L"Reparse point")+1;
					strngs[34]=(wchar_t*)malloc(2*l);wcscpy(strngs[34],L"Reparse point");
				l=(int)wcslen(L"Sparse file")+1;
					strngs[35]=(wchar_t*)malloc(2*l);wcscpy(strngs[35],L"Sparse file");
				l=(int)wcslen(L"System")+1;
					strngs[36]=(wchar_t*)malloc(2*l);wcscpy(strngs[36],L"System");
				l=(int)wcslen(L"Temporary")+1;
					strngs[37]=(wchar_t*)malloc(2*l);wcscpy(strngs[37],L"Temporary");
				l=(int)wcslen(L"Virtual")+1;
					strngs[38]=(wchar_t*)malloc(2*l);wcscpy(strngs[38],L"Virtual");
				l=(int)wcslen(L"Enum subdirectories")+1;
					strngs[39]=(wchar_t*)malloc(2*l);wcscpy(strngs[39],L"Enum subdirectories");
				l=(int)wcslen(L"Common parameters:")+1;
					strngs[40]=(wchar_t*)malloc(2*l);wcscpy(strngs[40],L"Common parameters:");
				l=(int)wcslen(L"Size and time parameters:")+1;
					strngs[41]=(wchar_t*)malloc(2*l);wcscpy(strngs[41],L"Size and time parameters:");
				l=(int)wcslen(L"Binary")+1;
					strngs[42]=(wchar_t*)malloc(2*l);wcscpy(strngs[42],L"Binary");
				l=(int)wcslen(L"Stop")+1;
					strngs[43]=(wchar_t*)malloc(2*l);wcscpy(strngs[43],L"Stop");
				l=(int)wcslen(L"Select all")+1;
					strngs[44]=(wchar_t*)malloc(2*l);wcscpy(strngs[44],L"Select all");
				l=(int)wcslen(L"Select all fixed")+1;
					strngs[45]=(wchar_t*)malloc(2*l);wcscpy(strngs[45],L"Select all fixed");					
				l=(int)wcslen(L"Browse")+1;
					strngs[46]=(wchar_t*)malloc(2*l);wcscpy(strngs[46],L"Browse");					
				l=(int)wcslen(L"Edit")+1;
					strngs[47]=(wchar_t*)malloc(2*l);wcscpy(strngs[47],L"Edit");					
				l=(int)wcslen(L"View")+1;
					strngs[48]=(wchar_t*)malloc(2*l);wcscpy(strngs[48],L"View");
				l=(int)wcslen(L"To panel")+1;
					strngs[49]=(wchar_t*)malloc(2*l);wcscpy(strngs[48],L"To panel");
				l=(int)wcslen(L"Save results")+1;
					strngs[50]=(wchar_t*)malloc(2*l);wcscpy(strngs[50],L"Save results");
			}
			//LoadLBResultsFrFile();
			break;
		case DLL_THREAD_ATTACH:
			break;
		case DLL_THREAD_DETACH:
			break;
		case DLL_PROCESS_DETACH:
			if(strngs)
			{	for(i=0; i<MAX_STRINGS; i++)
					free(strngs[i]);
				free(strngs);
				strngs=NULL;
			}
			if(pResultsLBtoPanelBuf)
				free(pResultsLBtoPanelBuf);
			pResultsLBtoPanelBuf = 0;
			break;
	}
	return TRUE;
}