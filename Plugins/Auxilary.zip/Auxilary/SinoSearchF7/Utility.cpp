#include "Windows.h"
#include "strsafe.h"
#include "resource.h"
#include "SinSchF7.h"
#include "shlobj.h"
#include "Wbemidl.h"
#include "comutil.h"
#include "..\..\..\Operations\MyShell\MyShell.h"
#include <malloc.h>
//#include "shlwapi.h"


VOID SetTabPage(HWND hDlg, int iTabPage)
{
switch(iTabPage)
{
 case 0: default:
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ALTERNATIVE_NAME),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_ALTERNATIVE_FILE_NAME),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_CREATE_TIME_BEFORE),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_CREATE_TIME_AFTER),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_DATE),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_DATE2),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_DATE_AFTER),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_DATE_AFTER2),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_CREATE_TIME_BETWEEN),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_LAST_ACCESS_TIME_BEFORE),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_LAST_ACCESS_TIME_AFTER),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE2),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_AFTER),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_AFTER2),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_LAST_ACCESS_TIME_BETWEEN),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_LAST_WRITE_TIME_BEFORE),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_LAST_WRITE_TIME_AFTER),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE2),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_AFTER),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_AFTER2),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_LAST_WRITE_TIME_BETWEEN),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_FILE_SIZE),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_COMBO_FILE_SIZE_EQUATION),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_FILE_SIZE),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_FILE_SIZE),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_COMBO_FILE_SIZE_QUANTITY),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_FILE_ATTRIBUTE),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_ARCHIVE),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_ARCHIVE_EX),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_COMPRESSED),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_COMPRESSED_EX),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_DEVICE),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_DEVICE_EX),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_DIRECTORY),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_DIRECTORY_EX),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_ENCRYPTED),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_ENCRYPTED_EX),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_HIDDEN),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_HIDDEN_EX),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_NORMAL),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_NORMAL_EX),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_NOT_INDEXED),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_NOT_INDEXED_EX),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_OFFLINE),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_OFFLINE_EX),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_READ_ONLY),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_READ_ONLY_EX),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_REPARSE_POINT),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_REPARSE_POINT_EX),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_SPARSE_FILE),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_SPARSE_FILE_EX),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_SYSTEM),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_SYSTEM_EX),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_TEMPORARY),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_TEMPORARY_EX),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_VIRTUAL),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_VIRTUAL_EX),SW_HIDE);

 	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_BETWEEN_DATE),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_BETWEEN_TIME),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_BETWEEN_DATE2),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_BETWEEN_TIME2),SW_HIDE);
		  
 	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_BETWEEN),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_TIME_BETWEEN),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_BETWEEN2),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_TIME_BETWEEN2),SW_HIDE);

 	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_BETWEEN),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_TIME_BETWEEN),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_BETWEEN2),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_TIME_BETWEEN2),SW_HIDE);

	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_DAY),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_MOONS),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_YEAR),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_DAY),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_MOONS),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_YEAR),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_DAY),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_MOONS),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_YEAR),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_DAY),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_MOON),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_YEAR),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_DAY),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_MOON),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_YEAR),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_DAY),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_MOON),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_YEAR),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_DAY),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_MOON),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_YEAR),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_DAY),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_MOON),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_YEAR),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_DAY),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_MOON),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_YEAR),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_DAY),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_MOON),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_YEAR),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_DAY),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_MOON),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_YEAR),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_DAY),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_MOON),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_YEAR),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_HOUR),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_MIN),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_SEC),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_MILS),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_HOUR),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_MIN),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_SEC),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_MILS),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_HOUR),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_MIN),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_SEC),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_MILS),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_HOUR),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_MIN),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_SEC),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_MILS),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_HOUR),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_MIN),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_SEC),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_MILS),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_HOUR),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_MIN),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_SEC),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_MILS),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_HOUR),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_MIN),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_SEC),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_MILS),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_HOUR),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_MIN),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_SEC),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_MILS),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_HOUR),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_MIN),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_SEC),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_MILS),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_HOUR),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_MIN),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_SEC),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_MILS),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_HOUR),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_MIN),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_SEC),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_MILS),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_HOUR),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_MIN),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_SEC),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_MILS),SW_HIDE);

	//Page1:
	ShowWindow(GetDlgItem(hDlg,IDC_STATIC_SCH1),SW_SHOW); 
	ShowWindow(GetDlgItem(hDlg,IDC_STATIC_SCH2),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_COMBO_SEARCH_NAME),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_BUTTON_ADD_PATH),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_COMBO_SEARCH_PATH),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_TEXT_SEACH),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_COMBO_SEARCH_FOR_TEXT),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_UNICODE_OR_MULTIBYTE),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_BINARY_OR_CHARACTER),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_REGISTR_CAPS),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_NO_TEXT_SEACH),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_COMBO_SEARCH_NOT_TEXT),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_UNICODE_OR_MULTIBYTE2),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_BINARY_OR_CHARACTER2),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_REGISTR_CAPS2),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_BUTTON_ADD_DISK),SW_SHOW);
	//ShowWindow(GetDlgItem(hDlg,IDC_COMBO_METHOD),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_SAVE_RESULTS),SW_SHOW);
 break;
 case 1:
	ShowWindow(GetDlgItem(hDlg,IDC_STATIC_SCH1),SW_HIDE); 
	ShowWindow(GetDlgItem(hDlg,IDC_STATIC_SCH2),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_COMBO_SEARCH_NAME),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_BUTTON_ADD_PATH),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_COMBO_SEARCH_PATH),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_TEXT_SEACH),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_COMBO_SEARCH_FOR_TEXT),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_UNICODE_OR_MULTIBYTE),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_BINARY_OR_CHARACTER),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_REGISTR_CAPS),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_NO_TEXT_SEACH),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_COMBO_SEARCH_NOT_TEXT),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_UNICODE_OR_MULTIBYTE2),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_BINARY_OR_CHARACTER2),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_REGISTR_CAPS2),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_BUTTON_ADD_DISK),SW_HIDE);
	//ShowWindow(GetDlgItem(hDlg,IDC_COMBO_METHOD),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_SAVE_RESULTS),SW_HIDE);

	//Page1:
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ALTERNATIVE_NAME),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_ALTERNATIVE_FILE_NAME),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_CREATE_TIME_BEFORE),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_CREATE_TIME_AFTER),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_DATE),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_DATE2),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_DATE_AFTER),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_DATE_AFTER2),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_CREATE_TIME_BETWEEN),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_LAST_ACCESS_TIME_BEFORE),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_LAST_ACCESS_TIME_AFTER),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE2),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_AFTER),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_AFTER2),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_LAST_ACCESS_TIME_BETWEEN),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_LAST_WRITE_TIME_BEFORE),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_LAST_WRITE_TIME_AFTER),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE2),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_AFTER),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_AFTER2),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_LAST_WRITE_TIME_BETWEEN),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_FILE_SIZE),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_COMBO_FILE_SIZE_EQUATION),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_FILE_SIZE),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_FILE_SIZE),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_COMBO_FILE_SIZE_QUANTITY),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_FILE_ATTRIBUTE),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_ARCHIVE),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_ARCHIVE_EX),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_COMPRESSED),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_COMPRESSED_EX),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_DEVICE),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_DEVICE_EX),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_DIRECTORY),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_DIRECTORY_EX),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_ENCRYPTED),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_ENCRYPTED_EX),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_HIDDEN),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_HIDDEN_EX),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_NORMAL),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_NORMAL_EX),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_NOT_INDEXED),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_NOT_INDEXED_EX),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_OFFLINE),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_OFFLINE_EX),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_READ_ONLY),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_READ_ONLY_EX),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_REPARSE_POINT),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_REPARSE_POINT_EX),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_SPARSE_FILE),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_SPARSE_FILE_EX),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_SYSTEM),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_SYSTEM_EX),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_TEMPORARY),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_TEMPORARY_EX),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_VIRTUAL),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_VIRTUAL_EX),SW_SHOW);

 	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_BETWEEN_DATE),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_BETWEEN_TIME),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_BETWEEN_DATE2),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_BETWEEN_TIME2),SW_SHOW);
		  
 	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_BETWEEN),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_TIME_BETWEEN),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_BETWEEN2),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_TIME_BETWEEN2),SW_SHOW);

 	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_BETWEEN),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_TIME_BETWEEN),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_BETWEEN2),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_TIME_BETWEEN2),SW_SHOW);

	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_DAY),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_MOONS),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_YEAR),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_DAY),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_MOONS),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_YEAR),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_DAY),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_MOONS),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_YEAR),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_DAY),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_MOON),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_YEAR),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_DAY),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_MOON),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_YEAR),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_DAY),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_MOON),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_YEAR),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_DAY),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_MOON),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_YEAR),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_DAY),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_MOON),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_YEAR),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_DAY),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_MOON),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_YEAR),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_DAY),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_MOON),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_YEAR),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_DAY),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_MOON),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_YEAR),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_DAY),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_MOON),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_YEAR),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_HOUR),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_MIN),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_SEC),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_MILS),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_HOUR),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_MIN),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_SEC),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_MILS),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_HOUR),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_MIN),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_SEC),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_MILS),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_HOUR),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_MIN),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_SEC),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_MILS),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_HOUR),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_MIN),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_SEC),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_MILS),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_HOUR),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_MIN),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_SEC),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_MILS),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_HOUR),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_MIN),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_SEC),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_MILS),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_HOUR),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_MIN),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_SEC),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_MILS),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_HOUR),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_MIN),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_SEC),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_MILS),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_HOUR),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_MIN),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_SEC),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_MILS),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_HOUR),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_MIN),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_SEC),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_MILS),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_HOUR),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_MIN),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_SEC),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_MILS),SW_SHOW);

break;
}}

int totLogDiskDrives=0;
int GetTotalLogicalDrives(){BuildLogicalDrives();return totLogDiskDrives;};
wchar_t	logDrNames[32][MAX_WMI_CHAR]={L"",L"",L"",L"",L"",L"",L"",L"",L"",L"",
									  L"",L"",L"",L"",L"",L"",L"",L"",L"",L"",
									  L"",L"",L"",L"",L"",L"",L"",L"",L"",L"",
									  L"",L""};//BuildLogicalDrives()
unsigned __int32 logDrMediaType[32]={10,10,10,10,10,10,10,10,10,10,
									 10,10,10,10,10,10,10,10,10,10,
									 10,10,10,10,10,10,10,10,10,10,
									 10,10};//FDD
wchar_t	logDrLabels[32][MAX_WMI_CHAR]={L"",L"",L"",L"",L"",L"",L"",L"",L"",L"",
									   L"",L"",L"",L"",L"",L"",L"",L"",L"",L"",
									   L"",L"",L"",L"",L"",L"",L"",L"",L"",L"",
									   L"",L""};//BuildLogicalDrives()
wchar_t	logDrDescrptn[32][MAX_WMI_CHAR]={L"",L"",L"",L"",L"",L"",L"",L"",L"",L"",
									   L"",L"",L"",L"",L"",L"",L"",L"",L"",L"",
									   L"",L"",L"",L"",L"",L"",L"",L"",L"",L"",
									   L"",L""};//BuildLogicalDrives()
unsigned __int32 logDrType[32]={3,3,3,3,3,3,3,3,3,3,
								3,3,3,3,3,3,3,3,3,3,
								3,3,3,3,3,3,3,3,3,3,3,3};//HDD
BOOL bCoInitializeCalled=FALSE;
//DropTarget* mDropTarget = NULL;
wchar_t* GetLogicalDriveName(int i)
{	//BuildLogicalDrives();
	if(i>=totLogDiskDrives) return NULL;
	return &logDrNames[i][0];
}
wchar_t* GetLogicalDriveLabel(int i)
{	if(i>=totLogDiskDrives) return NULL;
	return &logDrLabels[i][0];
}
int GetLogicalDriveMediaType(int n)
{
	if(n<32) return logDrMediaType[n];
	return 0;
}
/*VOID ReleaseDragAndDrop()
{
	if(mDropTarget)
	{	RevokeDragDrop(hWnd);
		CoLockObjectExternal(mDropTarget, FALSE, TRUE);
		//if(mDropTarget)mDropTarget->Release();// yuqoridagining o'zi qilobdur(3-parametri);
		mDropTarget = NULL;
		OleUninitialize();
}	}*/
int BuildLogicalDrives()
{
//CoInitializeEx uchun:
#pragma message ("Shu yerga yam 1 qara:")
//	if(bCoInitializeCalled) ReleaseDragAndDrop();

    // Step 1: --------------------------------------------------
    // Initialize COM. ------------------------------------------
    HRESULT hres = CoInitializeEx(0, COINIT_MULTITHREADED);
	if(!bCoInitializeCalled)
	{	//AssertFatal(S_OK==hres,"CoInitializeEx for WMI error...");
		if(S_OK!=hres) return -1;
		bCoInitializeCalled=TRUE;
	}

	// Step 2:
    // Set general COM security levels --------------------------
    // Note: If you are using Windows 2000, you need to specify -
    // the default authentication credentials for a user by using
    // a SOLE_AUTHENTICATION_LIST structure in the pAuthList ----
    // parameter of CoInitializeSecurity ------------------------
    /*hres =  CoInitializeSecurity(
        NULL, 
        -1,                          // COM authentication
        NULL,                        // Authentication services
        NULL,                        // Reserved
        RPC_C_AUTHN_LEVEL_DEFAULT,   // Default authentication 
        RPC_C_IMP_LEVEL_IMPERSONATE, // Default Impersonation  
        NULL,                        // Authentication info
        EOAC_NONE,                   // Additional capabilities 
        NULL);                       // Reserved
	if (FAILED(hres))
	{	CoUninitialize();
		return -1;//fatalExit("CoInitializeSecurity for WMI error...");
	}*/

	// Step 3: ---------------------------------------------------
	// Obtain the initial locator to WMI -------------------------
    IWbemLocator *pLoc = NULL;
    hres = CoCreateInstance(CLSID_WbemLocator,
							0,
							CLSCTX_INPROC_SERVER,
							IID_IWbemLocator, (LPVOID *) &pLoc); 
    if (FAILED(hres))
	{	CoUninitialize();
		return -1;//fatalExit("Failed to create IWbemLocator object for WMI...");
	}

    // Step 4: -----------------------------------------------------
    // Connect to WMI through the IWbemLocator::ConnectServer method
    IWbemServices *pSvc = NULL;
    // Connect to the root\cimv2 namespace with
    // the current user and obtain pointer pSvc
    // to make IWbemServices calls.
    hres = pLoc->ConnectServer(
         _bstr_t(L"ROOT\\CIMV2"), // Object path of WMI namespace
         NULL,                    // User name. NULL = current user
         NULL,                    // User password. NULL = current
         0,                       // Locale. NULL indicates current
         NULL,                    // Security flags.
         0,                       // Authority (e.g. Kerberos)
         0,                       // Context object 
         &pSvc);                  // pointer to IWbemServices proxy
    if (FAILED(hres))
 	{	pLoc->Release();
		CoUninitialize();
		return -1;//fatalExit("Failed to connect to server for WMI...");
    }

    // Step 5: --------------------------------------------------
    // Set security levels on the proxy -------------------------
    hres = CoSetProxyBlanket(
       pSvc,                        // Indicates the proxy to set
       RPC_C_AUTHN_WINNT,           // RPC_C_AUTHN_xxx
       RPC_C_AUTHZ_NONE,            // RPC_C_AUTHZ_xxx
       NULL,                        // Server principal name 
       RPC_C_AUTHN_LEVEL_CALL,      // RPC_C_AUTHN_LEVEL_xxx 
       RPC_C_IMP_LEVEL_IMPERSONATE, // RPC_C_IMP_LEVEL_xxx
       NULL,                        // client identity
       EOAC_NONE);                  // proxy capabilities 
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();     
        CoUninitialize();
		return -1;//fatalExit("Failed to set proxy blanket for WMI...");
    }

    // Step 6: --------------------------------------------------
    // Use the IWbemServices pointer to make requests of WMI ----
    // For example, get the volume name of the log. disk
    IEnumWbemClassObject* pEnumerator = NULL;
    hres = pSvc->ExecQuery(
        bstr_t("WQL"),
		bstr_t("SELECT VolumeName, Name, Description, MediaType, DriveType FROM Win32_LogicalDisk"),
        WBEM_FLAG_FORWARD_ONLY | WBEM_FLAG_RETURN_IMMEDIATELY, 
        NULL,
        &pEnumerator);
    if (FAILED(hres))
    {   pSvc->Release();
        pLoc->Release();
        CoUninitialize();
		return -1;//fatalExit("Failed to get logical partition information for WMI...");
	}

	for(int i=0; i<32; i++)
		{logDrLabels[i][0]=0;logDrNames[i][0]=0;logDrMediaType[i]=10;}//10-FDD

    // Step 7: -------------------------------------------------
    // Get the data from the query in step 6 -------------------
    IWbemClassObject *pclsObj;
    ULONG uReturn = 0; totLogDiskDrives=0;
    while (pEnumerator)
    {	HRESULT hr = pEnumerator->Next(WBEM_INFINITE, 1, &pclsObj, &uReturn);
        if(0 == uReturn)
            break;
        VARIANT vtProp;
        hr = pclsObj->Get(L"VolumeName", 0, &vtProp, 0, 0);
		if(VT_EMPTY!=vtProp.vt && VT_NULL!=vtProp.vt)
			MyStringCpy(&logDrLabels[totLogDiskDrives][0],128,vtProp.bstrVal);
			//WideCharToMultiByte(CP_ACP,0,vtProp.bstrVal,-1,&logDrLabels[totLogDiskDrives][0],MAX_WMI_CHAR,NULL,NULL);
        VariantClear(&vtProp);
        hr = pclsObj->Get(L"Name", 0, &vtProp, 0, 0);
		if(VT_EMPTY!=vtProp.vt && VT_NULL!=vtProp.vt)
		{	int l=MyStringCpy(&logDrNames[totLogDiskDrives][0],128,vtProp.bstrVal);
			//int l=WideCharToMultiByte(CP_ACP,0,vtProp.bstrVal,-1,&logDrNames[totLogDiskDrives][0],MAX_WMI_CHAR,NULL,NULL);
			logDrNames[totLogDiskDrives][l++]='\\';//MyStringCat(logDrNames[totLogDiskDrives],MAX_WMI_CHAR,"\\");
			logDrNames[totLogDiskDrives][l]=0;
		}
        VariantClear(&vtProp);
        hr = pclsObj->Get(L"Description", 0, &vtProp, 0, 0);
		if(VT_EMPTY!=vtProp.vt && VT_NULL!=vtProp.vt)
			MyStringCpy(&logDrLabels[totLogDiskDrives][0],128,vtProp.bstrVal);
			//WideCharToMultiByte(CP_ACP,0,vtProp.bstrVal,-1,&logDrDescrptn[totLogDiskDrives][0],MAX_WMI_CHAR,NULL,NULL);
        VariantClear(&vtProp);
        hr = pclsObj->Get(L"DriveType", 0, &vtProp, 0, 0);
		if(VT_EMPTY!=vtProp.vt && VT_NULL!=vtProp.vt)
			logDrType[totLogDiskDrives]=vtProp.uintVal;
        VariantClear(&vtProp);

        hr = pclsObj->Get(L"MediaType", 0, &vtProp, 0, 0);
		if(VT_EMPTY!=vtProp.vt && VT_NULL!=vtProp.vt)
		{	if(logDrType[totLogDiskDrives]>2)//4-Network Drive,5-Compact Disc,6-RAM Disk
			{	if(3==logDrType[totLogDiskDrives])
					logDrMediaType[totLogDiskDrives] = 12;//HDD;
				else logDrMediaType[totLogDiskDrives] = logDrType[totLogDiskDrives];
			}
			else
			{	if(11==vtProp.uintVal)
					logDrMediaType[totLogDiskDrives] = 11;//other then fdd
				else if(12==vtProp.uintVal)
					logDrMediaType[totLogDiskDrives] = 12;//hard
				else
					logDrMediaType[totLogDiskDrives] = 10;//fdd
		}	}
		else if(2==logDrType[totLogDiskDrives])
				logDrMediaType[totLogDiskDrives] = 2;//USB
        VariantClear(&vtProp);

		++totLogDiskDrives;
		if(totLogDiskDrives>31) break;
    }

	// Cleanup
    // ========
    pSvc->Release();
    pLoc->Release();
    pEnumerator->Release();
    pclsObj->Release();
    CoUninitialize();

//CoInitializeEx uchun:
#pragma message ("Shu yerga ham yana bir qarab qo'ying: Utility.cpp 1152")
//	if(!CmnCntrl::CreateDragAndDrop())
//		return -1;
    return totLogDiskDrives;// Program successfully completed.
}