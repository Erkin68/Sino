#include "SchCBToDisk.h"
#include "..\..\..\Operations\MyShell\MyShell.h"
#include <malloc.h>

extern "C"
{
extern wchar_t* MyStringAddModulePath(wchar_t*);
}
extern HANDLE MyFopenViaCrF(wchar_t*,const wchar_t*);


CBToDisk selV7NameCB,selV7ExclTxt,selV7TxtCB,selV7PthCB;

CBToDisk::CBToDisk():buf(0),cnt(0)
{
}

CBToDisk::~CBToDisk()
{
	if(buf)
	{	RealSave();
		free(buf);
	}
	buf=0;
	cnt=0;
}

BOOL CBToDisk::AddToCB(HWND hCB, wchar_t* str,BOOL setInEdit)
{
wchar_t s[MAX_PATH];
	int r = SendMessage(hCB,CB_GETCOUNT,0,0);
	if(CB_ERR!=r)
	{	for(int j=0; j<r; j++)
		{	if(CB_ERR!=SendMessageW(hCB,CB_GETLBTEXT,j,(LPARAM)s))
			{	if(!wcscmp(s,str))
					return FALSE;
	}	}	}
	SendMessageW(hCB,CB_INSERTSTRING/*ADDSTRING*/,0,(LPARAM)str);
	if(setInEdit)
		SendMessage(hCB,CB_SETCURSEL,r,0);
	return TRUE;
}

BOOL CBToDisk::DeleteFrCB(HWND hCB, wchar_t* str)
{
wchar_t s[MAX_PATH];
	int r = SendMessage(hCB,CB_GETCOUNT,0,0);
	if(CB_ERR!=r)
	{	for(int j=0; j<r; j++)
		{	if(CB_ERR!=SendMessageW(hCB,CB_GETLBTEXT,j,(LPARAM)s))
			{	if(wcsstr(s,str))
				{	SendMessageW(hCB,CB_DELETESTRING,j,0);
					return TRUE;
	}	}	}	}
	return FALSE;
}

BOOL CBToDisk::RealRead(wchar_t* fName, HWND hCB, int maxStrs, int strLen)
{
BOOL bAdd = FALSE;
HANDLE f = MyFopenViaCrF(MyStringAddModulePath(fName),L"r");
	if(!f)return FALSE;

	wchar_t *str = (wchar_t*)_malloca(sizeof(wchar_t)*strLen);

	for(int i=0; i<maxStrs; i++)
	{	DWORD nr=1;
		str[0]=0;
		wchar_t *ps = str;
		while(nr)
		{	if(!ReadFile(f,ps,sizeof(wchar_t),&nr,NULL))
			{	nr = 0;
				break;
			}
			if(0==*ps)
				break;
			ps++;
		}
		if(!nr)
			break;
		if(str[0])
		{	BOOL a = AddToCB(hCB,str);
			if(0==i) if(a)
				SetWindowText(hCB,str);
			bAdd = TRUE;
	}	}
	_freea(str);
	CloseHandle(f);
	return bAdd;
}

BOOL CBToDisk::Read(wchar_t* fName, HWND hCB, int maxStrs, int strLen)
{
	if(!buf) return RealRead(fName,hCB,maxStrs,strLen);
	//else:
	wchar_t *pbuf=(wchar_t*)buf;
	for(int i=0; i<cnt+1; i++)
	{	int ln = MyStringLength(pbuf,MAX_PATH);
		if(i>0) 
		{	BOOL a = AddToCB(hCB,pbuf);
			if(1==i) if(a)
				SetWindowText(hCB,pbuf);
		}
		pbuf += ln+1;
	}
	return TRUE;
}

VOID CBToDisk::RealSave()
{
BOOL bWr = TRUE;
HANDLE f = MyFopenViaCrF(MyStringAddModulePath((wchar_t*)buf),L"w");
	if(!f)return;

	wchar_t *pbuf = (wchar_t*)buf;
	for(int i=0; i<cnt+1; i++)
	{	int ln = MyStringLength(pbuf,MAX_PATH);
		if(i>0)
		{	DWORD nw;
			WriteFile(f,pbuf,sizeof(wchar_t)*(ln+1),&nw,NULL);
		}
		pbuf += ln+1;
	}
	CloseHandle(f);
}

//vaqtinchalik save qilish:
BOOL CBToDisk::Save(wchar_t* fName, HWND hCB, int maxCount)
{
	cnt=SendMessage(hCB,CB_GETCOUNT,0,0);
	if(CB_ERR==cnt)cnt=0;
	if(cnt>maxCount) cnt = maxCount;

	//1.Qancha joy ketishini aniqlab olamiz:
	int ln = MyStringLength(fName,MAX_PATH)+1;
	wchar_t s[MAX_PATH];
	for(int i=0; i<cnt; i++)
	{	int l=SendMessageW(hCB,CB_GETLBTEXT,i,(LPARAM)s);
		ln += l+1;
	}
	if(buf) buf = realloc(buf,sizeof(wchar_t)*ln);
	else buf = malloc(sizeof(wchar_t)*ln);
	if(!buf)
	{	cnt=0;
		return FALSE;
	}

	//2.Bufferni to'ldiramiz:
	wchar_t *pbuf=(wchar_t*)buf;
	pbuf+=MyStringCpy(pbuf,MAX_PATH-1,fName)+1;
	for(int i=0; i<cnt; i++)
	{	int l=SendMessageW(hCB,CB_GETLBTEXT,i,(LPARAM)pbuf);
		pbuf += l+1;
	}
	return TRUE;
}