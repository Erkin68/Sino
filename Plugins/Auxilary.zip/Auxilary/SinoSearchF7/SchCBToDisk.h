#include "windows.h"


class CBToDisk
{
public:
			CBToDisk();
		   ~CBToDisk();
	BOOL	AddToCB(HWND,wchar_t*,BOOL setInEdit=FALSE);
	BOOL	DeleteFrCB(HWND, wchar_t*);
	BOOL	RealRead(wchar_t*,HWND,int,int);
	BOOL	Read(wchar_t*,HWND,int,int);
	VOID	RealSave();
	BOOL	Save(wchar_t*,HWND,int);
protected:
	VOID	*buf;
	int		cnt;
};

extern CBToDisk selV7PthCB;
extern CBToDisk selV7TxtCB;
extern CBToDisk selV7ExclTxt;
extern CBToDisk selV7NameCB;