#ifndef __SinSchF7_H__
#define __SinSchF7_H__


#include "windows.h"
#include "resource.h"
#include "schitem.h"
#include "FindStrWthFltr.h"


#define MAX_SAVE_SELECTION_STR	25
#define MAX_SEL_PATH			128
#define MAX_WMI_CHAR			128

#define selV7PthCBFName L"Plugins\\Auxilary\\SinoSearchF7\\CBToDsk.bin"
#define selV7TxtCBFName L"Plugins\\Auxilary\\SinoSearchF7\\CBToDsk.bin:stream"
#define selV7ExclTxtFName L"Plugins\\Auxilary\\SinoSearchF7\\CBToDsk.bin:stream0"
#define selV7NameCBFName L"Plugins\\Auxilary\\SinoSearchF7\\CBToDsk.bin:stream1"

extern "C"
{
extern wchar_t **strngs;//Language strings;
extern HINSTANCE plgnDllInst;
//Callbacks:
//typedef int  (CALLBACK *addItemToPanelList_t)(wchar_t*,WIN32_FIND_DATA*);
typedef BOOL (CALLBACK *saveOptions_t)(int,VOID*,int);
typedef BOOL (CALLBACK *readOptions_t)(int,VOID*,int);
typedef int  (CALLBACK *getPanelSelectedItemsNum_t)();
typedef wchar_t* (CALLBACK *getPanelItemPathAndName_t)(int);
typedef VOID (CALLBACK *execF3View_t)(wchar_t*);

//extern saveOptions_t saveOptions;
//extern readOptions_t readOptions;
//extern addItemToPanelList_t addItemToPanelList;
}

typedef struct TSearch
{	
			TSearch();
		   ~TSearch();
	   HWND hDlg;
	//LPVOID  panel;
	HANDLE	hThr;
	DWORD	thrId;
	BOOL	bStop,bRun;
	int		iCall;
	int		iFoundFiles;
	int		iFoundFolders;
	FILETIME crBef,crAft,crBtwn[2],lastBef,lastAft,lastBtwn[2],
			lastWrBef,lastWrAft,lastWrBtwn[2];
	DWORD   ticks[2];
	wchar_t *LBListBuf;

	HWND	hResultsLB,hInfoEdit,hToPanelBTN,hViewBTN,hEditBTN,hBrowseBTN;
	//HDC	hInfoEditDC;
	//RECT	hInfoEditRC;
	int		width,height;
	int     minWidth,minHeight,minHeightAftCrLB;
	BOOL    bFindDlgFirstCreatedToResizeChld;
	int		endDialogCodeToWM_DESTROY;

	VOID    SaveLBListBuf(HWND,int);
	VOID	LoadLBList(HWND);
} Search;

//extern Search	search; in earch dialog own search;
extern SearchItem item;

extern "C"
{
extern unsigned __int64 MyAtoU64(wchar_t*);
extern wchar_t *MyStringAddModulePath(wchar_t*);
extern int  MyStringCat(wchar_t*,int,wchar_t*);
extern int  MyStringLength(wchar_t*,int);
extern BOOL MyStringRemoveLastChar(wchar_t*,int,wchar_t);
extern BOOL MySubstr(wchar_t*,wchar_t*,int,int);

#ifndef MyStrCmpNotRelUpRegNA
extern BOOL MyStrCmpNotRelUpRegNA(char*,char*,int);
#endif
#ifndef MyStrCmpNotRelUpRegNW
extern BOOL MyStrCmpNotRelUpRegNW(wchar_t*,wchar_t*,int);
#endif
#ifndef MyStrCmpBinNA
extern char *MyStrCmpBinNA(char*,char*,int,int);
#endif
#ifndef MyStrCmpBinNW
extern wchar_t *MyStrCmpBinNW(wchar_t*,wchar_t*,int,int);
#endif
#ifndef MyStrCmpNW
extern BOOL MyStrCmpNW(wchar_t*,wchar_t*,int);
#endif
}

extern INT_PTR CALLBACK FindFileDlgProc(HWND,UINT,WPARAM,LPARAM);
extern INT_PTR CALLBACK AddDiskDlgProc(HWND,UINT,WPARAM,LPARAM);
extern void ResizeChilds(Search*,int,int);
extern VOID SetTabPage(HWND,int);
extern VOID CreateOutptBtns(Search*);
extern VOID CreateResultsLB(Search*);
extern int  GetTotalLogicalDrives();
extern wchar_t *GetLogicalDriveLabel(int);
extern wchar_t*	GetLogicalDriveName(int);
extern int  GetLogicalDriveMediaType(int);
extern int  BuildLogicalDrives();
extern void EnumToDlgWithFiltr(Search*,wchar_t*,FindStrWthFltr*,bool);
template<class T> BOOL IsBin(T ch)
{
	if(ch >= '0')
	if(ch <= '9')
		return TRUE;
	if(ch >= 'A')
	if(ch <= 'F')
		return TRUE;
	if(ch >= 'a')
	if(ch <= 'f')
		return TRUE;
	return FALSE;
}

#endif// __SinSchF7_H__