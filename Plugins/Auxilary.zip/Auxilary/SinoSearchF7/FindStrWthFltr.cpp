#include <string.h>
#include "stdio.h"
#include "malloc.h"
#include "SinSchF7.h"
#include "FindStrWthFltr.h"

#define MAX_PATH 260

/*FindStrWthFltr::FindStrWthFltr(char initStr[]):numStrs(0),pStr(0),fullStr(0),lnFullStr(0)
{	
char *p;
	if(0==initStr[0])
		{initStr[0]='*';initStr[1]='.';initStr[2]='*';initStr[3]=';';initStr[4]=0;}
	//1-t step:
	for(p=(char*)&initStr[0]; *p; p++)
	{	if(';'== (*p))
		if(';'!= (*(p+1)))
			++numStrs;
	}
	if(!numStrs) numStrs = 1;//return;
	else if(*(p-1)!=';') ++numStrs;

	//2.Init total string:
	lnFullStr = p-initStr;
	fullStr = (char*)malloc(lnFullStr+1);
	//3.Init substrs:
	pStr = (FStr*)malloc(sizeof(FStr)*numStrs);
	for(int i=0; i<numStrs; i++)
		pStr[i].TFStr::TFStr();

	//4.Fill substrs:
	int iCrntSbstr=0;
	pStr[0].pos = 0;
	char *pfull=&fullStr[0];
	for(int i=0; i<lnFullStr; i++)//p=initStr; *p; p++)
	{	if(';'==initStr[i] )if(';'==initStr[i+1] )continue;//2 ta 1 xil b-sa;
		if('*'==initStr[i] )if('*'==initStr[i+1] )continue;//2 ta 1 xil b-sa;
		if('~'==initStr[i] )if('~'==initStr[i+1] )continue;//2 ta 1 xil b-sa;
		if(' '==initStr[i] )if(' '==initStr[i+1] )continue;//2 ta 1 xil b-sa;
		if('\\'==initStr[i])if('\\'==initStr[i+1])continue;//2 ta 1 xil b-sa;
		if('.'==initStr[i] )if('.'==initStr[i+1] )continue;//2 ta 1 xil b-sa;
		*pfull = initStr[i];
		if(';'== *pfull)// && 0!=initStr[i+1] && ';'!=initStr[i+1])
		{	*pfull = 0;
			if(++iCrntSbstr<numStrs)
				pStr[iCrntSbstr].pos = pfull-&fullStr[0]+1;
		}
		++pfull;
	}
	//oxirgi nolniyam:
	*pfull=0;
	lnFullStr = pfull - &fullStr[0];

	//5.Queue each substr:
	for(int i=0; i<numStrs; i++)
	{	//1.find substrs via space symbol:
		pStr[i].iSubStrs = 0;
		char *p;
		for(p=&fullStr[pStr[i].pos]; *p; p++)
		{	if(' '==(*p))
				++pStr[i].iSubStrs;
		}
		if(!pStr[i].iSubStrs)pStr[i].iSubStrs = 1;
		else if(*(p-1)!=' ')++pStr[i].iSubStrs;

		//2.Allocate substrs:
		pStr[i].pSubStr = (SubStr*)malloc(sizeof(SubStr)*pStr[i].iSubStrs);
		pStr[i].pSubStr[0].pos = pStr[i].pos;
		int isb=0;
		for(p=&fullStr[pStr[i].pos]; *p; p++)
		{	if(' '==(*p))
			{	if(isb<pStr[i].iSubStrs-1)
					pStr[i].pSubStr[++isb].pos=p-&fullStr[0]+1;
				*p = 0;//Probel o'rniga kones stroki qo'yamiz;
	}	}	}

	//6.Find type of substrs:
	for(int i=0; i<numStrs; i++)
	for(int j=0; j<pStr[i].iSubStrs; j++)
	{	bool bExcpt = ('~'==fullStr[pStr[i].pSubStr[j].pos]?true:false);
		bool pth = false;
		pStr[i].pSubStr[j].ln = 0;
		pStr[i].pSubStr[j].fltrExtPos = -1;
		pStr[i].pSubStr[j].fltrNumAsterics = 0;
		pStr[i].pSubStr[j].fltrNumQuestns = 0;
		pStr[i].pSubStr[j].fltrExtNumAsterics = 0;
		pStr[i].pSubStr[j].fltrExtNumQuestns = 0;
		for(char *p=&fullStr[pStr[i].pSubStr[j].pos]; (*p)!=0 && (*p)!=' '; p++)
		{	if('\\'==(*p))pth=true;
			if('.'==(*p))pStr[i].pSubStr[j].fltrExtPos=p-&fullStr[0]+1;
			if('*'==(*p))
			{	if(pStr[i].pSubStr[j].fltrExtPos>-1)
					++pStr[i].pSubStr[j].fltrExtNumAsterics;
				else
					++pStr[i].pSubStr[j].fltrNumAsterics;
			}
			if('?'==(*p))
			{	if(pStr[i].pSubStr[j].fltrExtPos>-1)
					++pStr[i].pSubStr[j].fltrExtNumQuestns;
				else
					++pStr[i].pSubStr[j].fltrNumQuestns;
			}
			++pStr[i].pSubStr[j].ln;
		}
		if(pth)
		{	if(bExcpt)
			{	pStr[i].pSubStr[j].type = excptPath;
				++pStr[i].pSubStr[j].pos;
			}
			else pStr[i].pSubStr[j].type = path;
		}
		else
		{	if(bExcpt)
			{	pStr[i].pSubStr[j].type = excptFiltr;
				++pStr[i].pSubStr[j].pos;
			}
			else pStr[i].pSubStr[j].type = filtr;	
}	}	}

FindStrWthFltr::~FindStrWthFltr()
{
	if(pStr)
	{	for(int i=0; i<numStrs; i++)
		{	if(pStr[i].pSubStr)
			{	free(pStr[i].pSubStr);
				pStr[i].pSubStr = 0;
		}	}
		free(pStr);
		pStr=0;
	}
	if(fullStr)
	{	free(fullStr);
		fullStr=0;
}	}

bool FindStrWthFltr::CheckNameAndExt(char *s)
{
char *pExt = strrchr(s,'.');
	if(pExt) ++pExt;
	for(int i=0; i<numStrs; i++)
	{	for(int j=0; j<pStr[i].iSubStrs; j++)
		{	if(excptPath==pStr[i].pSubStr[j].type)continue;
			if(path     ==pStr[i].pSubStr[j].type)continue;
			if(filtr    ==pStr[i].pSubStr[j].type)
			{	if(CheckNameWithSubstrFiltr(&pStr[i].pSubStr[j],s,pExt))
					return true;
			}
			else//if(excptFiltr ==pStr[i].pSubStr[j].type)
			{	if(!CheckNameWithSubstrFiltr(&pStr[i].pSubStr[j],s,pExt))
					return true;
	}	}	}
	return false;
}

//Agar moslik topsa true qaytaradur;
bool FindStrWthFltr::CheckNameWithSubstrFiltr(SubStr *sbstr,char* s,char *sExt)
{
char *pext = strrchr(s,'.');
char *pfltr = &fullStr[sbstr->pos];
char *pLastCntrlCharPos=pfltr;
Loop1:
int unmatchCnt=0,astCnt=0,questCnt=0;
	for(;;)//while('*'==pfltr || '?'==pfltr)
	{	if('*'==(*pfltr))
		{	++astCnt;
			++pfltr;
		} else if('?'==(*pfltr))
		{	++questCnt;
			++pfltr;
		} else if(0==(*pfltr) || '.'==(*pfltr))
		{	if('*'==*(pfltr-1) || '?'==*(pfltr-1))
				pLastCntrlCharPos = pfltr;
			goto CheckEndOfName;
		}
		else
		{	if('*'==*(pfltr-1) || '?'==*(pfltr-1))
				pLastCntrlCharPos = pfltr;
			break;
	}	}
Loop2:
	for(int i=0; i<questCnt; i++)
	{	++s;
		if(s >= sExt || 0== (*s))
		if(sbstr->fltrExtPos>0 && pfltr < &fullStr[sbstr->fltrExtPos-1])
			return false;
	}

	if(*pfltr == *s)
	{   unmatchCnt=0;
		++pfltr;
		++s;
		goto CheckEndOfName;
	}
	else//if(*pfltr != *s)
	{	if(s==sExt || 0==(*s)) goto CheckEndOfName;
		++unmatchCnt;
		pfltr=pLastCntrlCharPos;
		++s;
		goto Loop2;
	}
CheckEndOfName:
	bool fltrCont = false;
	bool sCont = false;
	if(sbstr->fltrExtPos>0)
	{	if(pfltr<&fullStr[sbstr->fltrExtPos-1] && '.'!=(*pfltr))//filtr davomi bor;
			fltrCont = true;
	}
	else if(*pfltr)
		fltrCont = true;
	if(s<sExt && 0!= (*s) && '.'!= (*s))
		sCont = true;
	else if(!sExt && 0!=(*s))
		sCont = true;

	if(fltrCont)
	{	if(sCont)
			goto Loop1;
		//else
		while((*pfltr) && '.'!=(*pfltr))
		{	if('*' != (*pfltr))
				return false;
			++pfltr;
	}	}
	else//fltr dostig konsa:
	{	if(sCont)
		{	if(pext)
				s = pext+1;
			else
				s += MyStringLength(s,MAX_PATH);
			goto ChExt;
		}
		else if('.'==(*s))
		{	++s;
			goto ChExt;
		}
		if(pfltr==pLastCntrlCharPos)
		{	for(; 0!=(*s) && s<sExt && '.' != (*s); ++s);
			if('.'==(*s))++s;
		}
		else return false;
	}


ChExt:
	if(unmatchCnt>0)
		return false;

//check for empty extnsn:
	if(-1==sbstr->fltrExtPos)
		return true;
	if(0==sbstr->fltrExtPos && 0==sExt)
		return true;





pfltr = &fullStr[sbstr->fltrExtPos];//s uje tayyor:
pLastCntrlCharPos=pfltr;
Loop3:
	unmatchCnt=0,astCnt=0,questCnt=0;
	for(;;)//while('*'==pfltr || '?'==pfltr)
	{	if('*'==(*pfltr))
		{	++astCnt;
			++pfltr;
		} else if('?'==(*pfltr))
		{	++questCnt;
			++pfltr;
		} else if(0==(*pfltr) || '.'==(*pfltr))
		{	if('*'==*(pfltr-1) || '?'==*(pfltr-1))
				pLastCntrlCharPos = pfltr;
			goto CheckEndOfExt;
		}
		else
		{	if('*'==*(pfltr-1) || '?'==*(pfltr-1))
				pLastCntrlCharPos = pfltr;
			break;
	}	}
Loop4:
	for(int i=0; i<questCnt; i++)
	{	if(*(++s) == 0)
		if(sbstr->fltrExtPos>0 && pfltr < &fullStr[sbstr->fltrExtPos-1])
			return false;
	}
	if(*pfltr == *s)
	{   unmatchCnt=0;
		++pfltr;
		++s;
		goto CheckEndOfExt;
	}
	else//if(*pfltr != *s)
	{	if(0==(*s)) goto CheckEndOfExt;
		++unmatchCnt;
		pfltr=pLastCntrlCharPos;
		++s;
		goto Loop4;
	}
CheckEndOfExt:
	if(0!=(*pfltr))
	{	if(0!=(*s))
			goto Loop3;
		//else
		while(*pfltr)
		{	if('*' != (*pfltr))
				return false;
			++pfltr;
		}
		return true;
	} else//rasshir. dostig konsa:
	{	if(0==(*s))
			return true;
		//else
		if('*'==*(pfltr-1))
			return true;
		//if('?'==*(pfltr-1) && (*(s+1))==0)
		//	return true;
		int l = lstrlen(s);
		if((int)l<=questCnt)
			return TRUE;
		//else, break and return false;
	}
	return false;
}

void FindStrWthFltr::PrintState()
{
	for(int i=0; i<numStrs; i++)
	{	for(int j=0; j<pStr[i].iSubStrs; j++)
		{	char c = fullStr[pStr[i].pSubStr[j].pos+pStr[i].pSubStr[j].ln];
			fullStr[pStr[i].pSubStr[j].pos+pStr[i].pSubStr[j].ln]=0;
			printf("\n%17s ",&fullStr[pStr[i].pSubStr[j].pos]);
			if(path==pStr[i].pSubStr[j].type)
				printf("path ");
			else if(filtr==pStr[i].pSubStr[j].type)
				printf("filter ");
			else if(excptFiltr==pStr[i].pSubStr[j].type)
				printf("except filter ");
			else// if(excptPath==pStr[i].pSubStr[j].type)
				printf("except path ");
			fullStr[pStr[i].pSubStr[j].pos+pStr[i].pSubStr[j].ln]=c;
			printf(" pos of ext: %d",pStr[i].pSubStr[j].fltrExtPos);
			printf(" numAsteriks: %d",pStr[i].pSubStr[j].fltrNumAsterics);
			printf(" numQuestn: %d",pStr[i].pSubStr[j].fltrNumQuestns);
			printf(" numExtAsteriks: %d",pStr[i].pSubStr[j].fltrExtNumAsterics);
			printf(" numExtQuestn: %d",pStr[i].pSubStr[j].fltrExtNumQuestns);
}	}	}*/

/*
int _tmain(int argc, _TCHAR* argv[])
{
//FindStrWthFltr fs("*.sys ~*.exe windows\\ *a?s4.s?s4 ~~~windows\\system32\\;*.com *.?*s");
	//fs.PrintState();
FindStrWthFltr fs("as*cda?*1a88?s4.*1*14?s?s4");
	bool r=fs.CheckNameAndExt("as545454cda21a88ss4.1141sys4");


FindStrWthFltr fs1("sdsdsdas*cda?*1a88?s4.*1*14?s?s4");
	r=fs1.CheckNameAndExt("sdsdas545454cda21a88ss4.1141sys4");

FindStrWthFltr fs2("*das*cda?*1a88?s4.*1*14?s?s4");
	r=fs2.CheckNameAndExt("sd sdas545454cda21a88ss4.1141sys4");

FindStrWthFltr fs3("*.*1*14?s?s4");
	r=fs3.CheckNameAndExt("sdsdas545454cda21a88ss4.1141sys4");

FindStrWthFltr fs4("*");
	r=fs4.CheckNameAndExt("45451141sys4.45445");

FindStrWthFltr fs5("*da??");
	r=fs5.CheckNameAndExt("asdada45.xtx");

FindStrWthFltr fs6("*xtx");
	r=fs6.CheckNameAndExt("asdada45.xtx");

FindStrWthFltr fs7("*x.tx");
	r=fs7.CheckNameAndExt("asdada45x.tx");

FindStrWthFltr fs8(".e*c");
	r=fs8.CheckNameAndExt("bioxlog.edoc");
	r=fs8.CheckNameAndExt("x121.edocx");
	r=fs8.CheckNameAndExt("x.edoc");

	//getchar();
	return 0;
}*/

//FindStrWthFltr
//FindStrWthFltr
//FindStrWthFltr
//FindStrWthFltr
//FindStrWthFltr
//FindStrWthFltr
//FindStrWthFltr
//FindStrWthFltr
//FindStrWthFltr
//FindStrWthFltr
//FindStrWthFltr
//FindStrWthFltr
FindStrWthFltr::FindStrWthFltr(wchar_t initStr[]):numStrs(0),pStr(0),fullStr(0),lnFullStr(0)
{	
wchar_t *p;
	if(0==initStr[0])
		{initStr[0]='*';initStr[1]='.';initStr[2]='*';initStr[3]=';';initStr[4]=0;}
	//1-t step:
	for(p=(wchar_t*)&initStr[0]; *p; p++)
	{	if(';'== (*p))
		if(';'!= (*(p+1)))
			++numStrs;
	}
	if(!numStrs) numStrs = 1;//return;
	else if(*(p-1)!=';') ++numStrs;

	//2.Init total string:
	lnFullStr = p-initStr;
	fullStr = (wchar_t*)malloc(sizeof(wchar_t)*(lnFullStr+1));
	//3.Init substrs:
	pStr = (FStr*)malloc(sizeof(FStr)*numStrs);
	for(int i=0; i<numStrs; i++)
		pStr[i].TFStr::TFStr();

	//4.Fill substrs:
	int iCrntSbstr=0;
	pStr[0].pos = 0;
	wchar_t *pfull=&fullStr[0];
	for(int i=0; i<lnFullStr; i++)//p=initStr; *p; p++)
	{	if(';'==initStr[i] )if(';'==initStr[i+1] )continue;//2 ta 1 xil b-sa;
		if('*'==initStr[i] )if('*'==initStr[i+1] )continue;//2 ta 1 xil b-sa;
		if('~'==initStr[i] )if('~'==initStr[i+1] )continue;//2 ta 1 xil b-sa;
		if(' '==initStr[i] )if(' '==initStr[i+1] )continue;//2 ta 1 xil b-sa;
		if('\\'==initStr[i])if('\\'==initStr[i+1])continue;//2 ta 1 xil b-sa;
		if('.'==initStr[i] )if('.'==initStr[i+1] )continue;//2 ta 1 xil b-sa;
		*pfull = initStr[i];
		if(';'== *pfull)// && 0!=initStr[i+1] && ';'!=initStr[i+1])
		{	*pfull = 0;
			if(++iCrntSbstr<numStrs)
				pStr[iCrntSbstr].pos = pfull-&fullStr[0]+1;
		}
		++pfull;
	}
	//oxirgi nolniyam:
	*pfull=0;
	lnFullStr = pfull - &fullStr[0];

	//5.Queue each substr:
	for(int i=0; i<numStrs; i++)
	{	//1.find substrs via space symbol:
		pStr[i].iSubStrs = 0;
		wchar_t *p;
		for(p=&fullStr[pStr[i].pos]; *p; p++)
		{	if(' '==(*p))
				++pStr[i].iSubStrs;
		}
		if(!pStr[i].iSubStrs)pStr[i].iSubStrs = 1;
		else if(*(p-1)!=' ')++pStr[i].iSubStrs;

		//2.Allocate substrs:
		pStr[i].pSubStr = (SubStr*)malloc(sizeof(SubStr)*pStr[i].iSubStrs);
		pStr[i].pSubStr[0].pos = pStr[i].pos;
		int isb=0;
		for(p=&fullStr[pStr[i].pos]; *p; p++)
		{	if(' '==(*p))
			{	if(isb<pStr[i].iSubStrs-1)
					pStr[i].pSubStr[++isb].pos=p-&fullStr[0]+1;
				*p = 0;//Probel o'rniga kones stroki qo'yamiz;
	}	}	}

	//6.Find type of substrs:
	for(int i=0; i<numStrs; i++)
	for(int j=0; j<pStr[i].iSubStrs; j++)
	{	bool bExcpt = ('~'==fullStr[pStr[i].pSubStr[j].pos]?true:false);
		bool pth = false;
		pStr[i].pSubStr[j].ln = 0;
		pStr[i].pSubStr[j].fltrExtPos = -1;
		pStr[i].pSubStr[j].fltrNumAsterics = 0;
		pStr[i].pSubStr[j].fltrNumQuestns = 0;
		pStr[i].pSubStr[j].fltrExtNumAsterics = 0;
		pStr[i].pSubStr[j].fltrExtNumQuestns = 0;
		for(wchar_t *p=&fullStr[pStr[i].pSubStr[j].pos]; (*p)!=0 && (*p)!=' '; p++)
		{	if('\\'==(*p))pth=true;
			if('.'==(*p))pStr[i].pSubStr[j].fltrExtPos=p-&fullStr[0]+1;
			if('*'==(*p))
			{	if(pStr[i].pSubStr[j].fltrExtPos>-1)
					++pStr[i].pSubStr[j].fltrExtNumAsterics;
				else
					++pStr[i].pSubStr[j].fltrNumAsterics;
			}
			if('?'==(*p))
			{	if(pStr[i].pSubStr[j].fltrExtPos>-1)
					++pStr[i].pSubStr[j].fltrExtNumQuestns;
				else
					++pStr[i].pSubStr[j].fltrNumQuestns;
			}
			++pStr[i].pSubStr[j].ln;
		}
		if(pth)
		{	if(bExcpt)
			{	pStr[i].pSubStr[j].type = excptPath;
				++pStr[i].pSubStr[j].pos;
			}
			else pStr[i].pSubStr[j].type = path;
		}
		else
		{	if(bExcpt)
			{	pStr[i].pSubStr[j].type = excptFiltr;
				++pStr[i].pSubStr[j].pos;
			}
			else pStr[i].pSubStr[j].type = filtr;	
}	}	}

FindStrWthFltr::~FindStrWthFltr()
{
	if(pStr)
	{	for(int i=0; i<numStrs; i++)
		{	if(pStr[i].pSubStr)
			{	free(pStr[i].pSubStr);
				pStr[i].pSubStr = 0;
		}	}
		free(pStr);
		pStr=0;
	}
	if(fullStr)
	{	free(fullStr);
		fullStr=0;
}	}

bool FindStrWthFltr::CheckNameAndExt(wchar_t *s,wchar_t *onlyName)
{
wchar_t *pExt = wcsrchr(onlyName?onlyName:s,'.');
	if(pExt) ++pExt;
	for(int i=0; i<numStrs; i++)
	{	for(int j=0; j<pStr[i].iSubStrs; j++)
		{	if(excptPath==pStr[i].pSubStr[j].type)continue;
			if(path     ==pStr[i].pSubStr[j].type)continue;
			if(filtr    ==pStr[i].pSubStr[j].type)
			{	if(CheckNameWithSubstrFiltr(&pStr[i].pSubStr[j],s,pExt))
					return true;
			}
			else//if(excptFiltr ==pStr[i].pSubStr[j].type)
			{	if(!CheckNameWithSubstrFiltr(&pStr[i].pSubStr[j],s,pExt))
					return true;
	}	}	}
	return false;
}

//Agar moslik topsa true qaytaradur;
bool FindStrWthFltr::CheckNameWithSubstrFiltr(SubStr *sbstr,wchar_t* s,wchar_t *sExt)
{
/*	if(!sbstr->fltrNumAsterics)
	{	if(!sbstr->fltrNumQuestns)
			return (0==strcmp(pfltr,s) ? true : false);
		else
		{	int nln=sbstr->fltrExtPos-sbstr->pos-1;
			if(0!=strncmp(pfltr,s,nln))
				return false;
			for(pfltr += nln, s += nln; (*pfltr) && (*s); pfltr++,s++)
			{	if('?'==(*pfltr)) continue;
				if((*pfltr)!=(*s)) return false;
			}
			return true;
	}	}*/
wchar_t *pext = wcsrchr(s,'.');
wchar_t *pfltr = &fullStr[sbstr->pos];
wchar_t *pLastCntrlCharPos=pfltr;
Loop1:
int unmatchCnt=0,astCnt=0,questCnt=0;
	for(;;)//while('*'==pfltr || '?'==pfltr)
	{	if('*'==(*pfltr))
		{	++astCnt;
			++pfltr;
		} else if('?'==(*pfltr))
		{	++questCnt;
			++pfltr;
		} else if(0==(*pfltr) || '.'==(*pfltr))
		{	if('*'==*(pfltr-1) || '?'==*(pfltr-1))
				pLastCntrlCharPos = pfltr;
			goto CheckEndOfName;
		}
		else
		{	if('*'==*(pfltr-1) || '?'==*(pfltr-1))
				pLastCntrlCharPos = pfltr;
			break;
	}	}
Loop2:
	for(int i=0; i<questCnt; i++)
	{	++s;
		if(s >= sExt || 0== (*s))
		if(sbstr->fltrExtPos>0 && pfltr < &fullStr[sbstr->fltrExtPos-1])
			return false;
	}

	if(*pfltr == *s)
	{   unmatchCnt=0;
		++pfltr;
		++s;
		goto CheckEndOfName;
	}
	else//if(*pfltr != *s)
	{	if(s==sExt || 0==(*s)) goto CheckEndOfName;
		++unmatchCnt;
		pfltr=pLastCntrlCharPos;
		++s;
		goto Loop2;
	}
CheckEndOfName:
	bool fltrCont = false;
	bool sCont = false;

	if(sbstr->fltrExtPos>0)
	{	if(pfltr<&fullStr[sbstr->fltrExtPos-1] && '.'!=(*pfltr))//filtr davomi bor;
			fltrCont = true;
	}
	else if(*pfltr)
		fltrCont = true;

	if((*pfltr) && 0!= (*s) && '.'!= (*s))
		sCont = true;
	else if(!sExt && 0!=(*s))
		sCont = true;

	if(fltrCont)
	{	if(sCont)
			goto Loop1;
		//else
		while((*pfltr) && '.'!=(*pfltr))
		{	if('*' != (*pfltr))
				return false;
			++pfltr;
	}	}
	else//fltr dostig konsa:
	{	if(sCont)
		{	if(pext)
				s = pext+1;
			else
				s += MyStringLength(s,MAX_PATH);
			goto ChExt;
		}
		else if('.'==(*s))
		{	++s;
			goto ChExt;
		}
		if(pfltr==pLastCntrlCharPos)
		{	for(; 0!=(*s) && s<sExt && '.' != (*s); ++s);
			if('.'==(*s))++s;
		}
		else return false;
	}


ChExt:
	if(unmatchCnt>0)
		return false;

//check for empty extnsn:
	if(-1==sbstr->fltrExtPos)
		return true;
	if(0==sbstr->fltrExtPos && 0==sExt)
		return true;





pfltr = &fullStr[sbstr->fltrExtPos];//s uje tayyor:
pLastCntrlCharPos=pfltr;
Loop3:
	unmatchCnt=0,astCnt=0,questCnt=0;
	for(;;)//while('*'==pfltr || '?'==pfltr)
	{	if('*'==(*pfltr))
		{	++astCnt;
			++pfltr;
		} else if('?'==(*pfltr))
		{	++questCnt;
			++pfltr;
		} else if(0==(*pfltr) || '.'==(*pfltr))
		{	if('*'==*(pfltr-1) || '?'==*(pfltr-1))
				pLastCntrlCharPos = pfltr;
			goto CheckEndOfExt;
		}
		else
		{	if('*'==*(pfltr-1) || '?'==*(pfltr-1))
				pLastCntrlCharPos = pfltr;
			break;
	}	}
Loop4:
	for(int i=0; i<questCnt; i++)
	{	if(*(++s) == 0)
		if(sbstr->fltrExtPos>0 && pfltr < &fullStr[sbstr->fltrExtPos-1])
			return false;
	}
	if(*pfltr == *s)
	{   unmatchCnt=0;
		++pfltr;
		++s;
		goto CheckEndOfExt;
	}
	else//if(*pfltr != *s)
	{	if(0==(*s)) goto CheckEndOfExt;
		++unmatchCnt;
		pfltr=pLastCntrlCharPos;
		++s;
		goto Loop4;
	}
CheckEndOfExt:
	if(0!=(*pfltr))
	{	if(0!=(*s))
			goto Loop3;
		//else
		while(*pfltr)
		{	if('*' != (*pfltr))
				return false;
			++pfltr;
		}
		return true;
	} else//rasshir. dostig konsa:
	{	if(0==(*s))
			return true;
		//else
		if('*'==*(pfltr-1))
			return true;
		//if('?'==*(pfltr-1) && (*(s+1))==0)
		//	return true;
		int l = lstrlenW(s);
		if((int)l<=questCnt)
			return TRUE;
		//else, break and return false;
	}
	return false;
}

void FindStrWthFltr::PrintState()
{
	for(int i=0; i<numStrs; i++)
	{	for(int j=0; j<pStr[i].iSubStrs; j++)
		{	wchar_t c = fullStr[pStr[i].pSubStr[j].pos+pStr[i].pSubStr[j].ln];
			fullStr[pStr[i].pSubStr[j].pos+pStr[i].pSubStr[j].ln]=0;
			printf("\n%17s ",&fullStr[pStr[i].pSubStr[j].pos]);
			if(path==pStr[i].pSubStr[j].type)
				printf("path ");
			else if(filtr==pStr[i].pSubStr[j].type)
				printf("filter ");
			else if(excptFiltr==pStr[i].pSubStr[j].type)
				printf("except filter ");
			else// if(excptPath==pStr[i].pSubStr[j].type)
				printf("except path ");
			fullStr[pStr[i].pSubStr[j].pos+pStr[i].pSubStr[j].ln]=c;
			printf(" pos of ext: %d",pStr[i].pSubStr[j].fltrExtPos);
			printf(" numAsteriks: %d",pStr[i].pSubStr[j].fltrNumAsterics);
			printf(" numQuestn: %d",pStr[i].pSubStr[j].fltrNumQuestns);
			printf(" numExtAsteriks: %d",pStr[i].pSubStr[j].fltrExtNumAsterics);
			printf(" numExtQuestn: %d",pStr[i].pSubStr[j].fltrExtNumQuestns);
}	}	}

