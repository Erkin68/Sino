//****** ANSI string filter search: ****

int FindSubstrToAst(char* sb, char* se)
{
int k=0;
	while(sb<se)
	{	if('*'==*sb)
			return k;
		k++;
		sb++;
	}
	return k;
}

char* FindFirstSubstrTail(char* dest, char* src, int srcLn)
{
char* d = dest;
char* s = src;
int bEqu = 0;

	//if(dest==(char*)0x2c)
	//	return 0;

	while((*d != 0) && (s<src+srcLn))
	{	if(*d == *s)
		{	s++;
			d++;
			++bEqu;
		}
		else
		{	bEqu = 0;
			s = src;
			d++;
	}	}
	return bEqu==srcLn?d:0;
}

char* EmitAst(char* s)
{
	while(*s == '*')
		s++;
	return s;
}

//FindFirstFile ning o'zi zo'r bajarar edi, kernelda(ntdll), lekin biz uni ajratdik,
//shuning uchun o'zimiz qilishimiz kerak. str - 0 -char b-n tugagan, fltr esa bunaqamas;
/*int MyStringCmprFltrA(char* str,char* fltrStr,int iFltrFrom,int iFltrTo)
{
	if(iFltrTo==iFltrFrom) return 0;
int lnSub;
char* d = str;
char* fb = &fltrStr[iFltrFrom];
char* fe = &fltrStr[iFltrTo];

	do
	{	lnSub = FindSubstrToAst(fb, fe);
		if(lnSub)
		{
			d = FindFirstSubstrTail(d,fb,lnSub);
			if(!d) return 0;
		}
		fb = EmitAst(fb+lnSub);
	} while(fb < fe);

	return 1;
}*/


//****** UNICODE string filter search: ****

int FindSubstrToAstW(wchar_t* sb, wchar_t* se)
{
int k=0;
	while(sb<se)
	{	if('*'==*sb)
			return k;
		k++;
		sb++;
	}
	return k;
}

wchar_t* FindFirstSubstrTailW(wchar_t* dest, wchar_t* src, int srcLn)
{
wchar_t* d = dest;
wchar_t* s = src;
int bEqu = 0;
	while((*d != 0) && (s<src+srcLn))
	{	bEqu = (*d == *s)?1:0;
		if(!bEqu)
		{	s = src;
			d++;
		} else
		{	s++;
			d++;
	}	}
	return bEqu?d:0;
}

wchar_t* EmitAstW(wchar_t* s)
{
	while(*s == '*')
		s++;
	return s;
}

//FindFirstFile ning o'zi zo'r bajarar edi, kernelda(ntdll), lekin biz uni ajratdik,
//shuning uchun o'zimiz qilishimiz kerak. str - 0 -char b-n tugagan, fltr esa bunaqamas;
int MyStringCmprFltr(wchar_t* str,wchar_t* fltrStr,int iFltrFrom,int iFltrTo)
{
int lnSub;
wchar_t* d = str;
wchar_t* fb = &fltrStr[iFltrFrom];
wchar_t* fe = &fltrStr[iFltrTo];

	do
	{	lnSub = FindSubstrToAstW(fb, fe);
		if(lnSub)
		{
			d = FindFirstSubstrTailW(d,fb,lnSub);
			if(!d) return 0;
		}
		fb = EmitAstW(fb+lnSub);
	} while(fb < fe);

	return 1;
}