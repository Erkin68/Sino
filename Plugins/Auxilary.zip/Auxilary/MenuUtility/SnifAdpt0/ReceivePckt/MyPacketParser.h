#include "libnetutil\TCPHeader.h"
#include "libnetutil\UDPHeader.h"
#include "libnetutil\ICMPv4Header.h"
#include "libnetutil\ICMPv6Header.h"
#include "libnetutil\ICMPv6Option.h"
#include "libnetutil\EthernetHeader.h"
#include "libnetutil\DestOptsHeader.h"
#include "libnetutil\FragmentHeader.h"
#include "libnetutil\RoutingHeader.h"
#include "libnetutil\ARPHeader.h"



#define LINK_LAYER         2
#define NETWORK_LAYER      3
#define TRANSPORT_LAYER    4
#define APPLICATION_LAYER  5
#define EXTHEADERS_LAYER   6

#define MAX_HEADERS_IN_PACKET 32

typedef unsigned char u8;
typedef unsigned __int32 u32;
typedef struct header_type_string
{	u32 type;
    const char *str;
}header_type_string_t;
typedef struct packet_type
{	u32 type;
    u32 length;
    u8 *buf;
}pkt_type_t;

extern pkt_type_t* MyParse_packet1(const u8*,int,int*,bool,FILE*);
extern pkt_type_t* MyParse_packet2(const u8*,int,int*,bool);
extern bool PrintPacket(pkt_type_t*);