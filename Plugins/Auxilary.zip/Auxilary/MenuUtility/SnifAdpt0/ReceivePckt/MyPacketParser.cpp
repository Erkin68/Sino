#include <assert.h>
#include "libnetutil\IPv4Header.h"
#include "libnetutil\IPv6Header.h"
#include "MyPacketParser.h"

void PrintData(FILE*,const unsigned char*,int);
 
static pkt_type_t this_packet[MAX_HEADERS_IN_PACKET+1];

//very slow

pkt_type_t* MyParse_packet1(const u8 *pkt,int pktlen,int *totalPackets,bool eth_included,FILE *f)
{
u8 current_header=0;             /* Current array position of "this_packet" */
const u8 *curr_pkt=pkt;          /* Pointer to current part of the packet   */
size_t curr_pktlen=pktlen;       /* Remaining packet length                 */
int ethlen=0, arplen=0;          /* Aux length variables: link layer        */
int iplen=0,ip6len=0;            /* Aux length variables: network layer     */
int tcplen=0,udplen=0,icmplen=0; /* Aux length variables: transport layer   */
int exthdrlen=0;                 /* Aux length variables: extension headers */
int next_layer=0;                /* Next header type to process             */
int expected=0;                  /* Next protocol expected                  */
bool finished=false;             /* Loop breaking flag                      */
bool unknown_hdr=false;          /* Indicates unknown header found          */
IPv4Header ip4;
IPv6Header ip6;
TCPHeader tcp;
UDPHeader udp;
ICMPv4Header icmp4;
ICMPv6Header icmp6;
EthernetHeader eth;
DestOptsHeader ext_dopts;
FragmentHeader ext_frag;
HopByHopHeader ext_hopt;
RoutingHeader ext_routing;
ARPHeader arp;

  memset(this_packet, 0, sizeof(this_packet));
  *totalPackets = 0;
  fprintf(f,"Packet:");

  /* Decide which layer we have to start from */
  if(eth_included)
  { next_layer=LINK_LAYER;
    expected=HEADER_TYPE_ETHERNET;
  }else
    next_layer=NETWORK_LAYER;

  /* Header processing loop */
  while(!finished && curr_pktlen>0 && current_header<MAX_HEADERS_IN_PACKET)
  {	/* Ethernet and ARP headers ***********************************************/
    if(next_layer==LINK_LAYER)
	{	if(expected==HEADER_TYPE_ETHERNET)
		{	if(eth.storeRecvData(curr_pkt, curr_pktlen)==OP_FAILURE)
			{	unknown_hdr=true;
                break;
            }
            if((ethlen=eth.validate())==OP_FAILURE)
			{	unknown_hdr=true;
                break;
            }
            /* Determine next header type */
            switch(eth.getEtherType())
			{	case ETHTYPE_IPV4:
                    expected=HEADER_TYPE_IPv4;
                    next_layer=NETWORK_LAYER;
                break;
                case ETHTYPE_IPV6:
                    expected=HEADER_TYPE_IPv6;
                    next_layer=NETWORK_LAYER;
                break;
                case ETHTYPE_ARP:
                    next_layer=LINK_LAYER;
                    expected=HEADER_TYPE_ARP;
                break;
                default:
                    next_layer=APPLICATION_LAYER;
                    expected=HEADER_TYPE_RAW_DATA;
                break;
            }
            this_packet[current_header].length=ethlen;
            this_packet[current_header].buf=(u8*)curr_pkt;
            this_packet[current_header++].type=HEADER_TYPE_ETHERNET;
			eth.print(f,PRINT_DETAIL_HIGH);
			fprintf(f,"\n\tETH.HDR.DATA:");PrintData(f,curr_pkt,ethlen);
            eth.reset();
            curr_pkt+=ethlen;
            curr_pktlen-=ethlen;
			++(*totalPackets);
        }
		else if(expected==HEADER_TYPE_ARP)
		{	if(arp.storeRecvData(curr_pkt, curr_pktlen)==OP_FAILURE)
			{	unknown_hdr=true;
                break;
            }
            if((arplen=arp.validate())==OP_FAILURE)
			{	unknown_hdr=true;
                break;
            }
            this_packet[current_header].length=arplen;
            this_packet[current_header].buf=(u8*)curr_pkt;
            this_packet[current_header++].type=HEADER_TYPE_ARP;
			arp.print(f,PRINT_DETAIL_HIGH);
			fprintf(f,"\n\tARP.HDR.DATA:");PrintData(f,curr_pkt,arplen);
            arp.reset();
            curr_pkt+=arplen;
            curr_pktlen-=arplen;
			++(*totalPackets);
            if(curr_pktlen>0)
			{	next_layer=APPLICATION_LAYER;
                expected=HEADER_TYPE_RAW_DATA;
            }else
				finished=true;
        }else
			assert(finished==true);
    }
    /* IPv4 and IPv6 headers **************************************************/
	else if(next_layer==NETWORK_LAYER)
	{	/* Determine IP version */
        if(ip4.storeRecvData(curr_pkt, curr_pktlen)==OP_FAILURE)
		{   unknown_hdr=true;
            break;
        }

        /* IP version 4 ---------------------------------*/
        if(ip4.getVersion()==4)
		{	if((iplen=ip4.validate())==OP_FAILURE)
			{	unknown_hdr=true;
                break;
            }
            /* Determine next header type */
            switch(ip4.getNextProto())
			{	case HEADER_TYPE_ICMPv4:
                    next_layer=TRANSPORT_LAYER;
                    expected=HEADER_TYPE_ICMPv4;
                break;
                case HEADER_TYPE_IPv4: /* IP in IP */
                    next_layer=NETWORK_LAYER;
                    expected=HEADER_TYPE_IPv4;
                break;
                case HEADER_TYPE_TCP:
                    next_layer=TRANSPORT_LAYER;
                    expected=HEADER_TYPE_TCP;
                break;
                case HEADER_TYPE_UDP:
                    next_layer=TRANSPORT_LAYER;
                    expected=HEADER_TYPE_UDP;
                break;
                case HEADER_TYPE_IPv6: /* IPv6 in IPv4 */
                    next_layer=NETWORK_LAYER;
                    expected=HEADER_TYPE_IPv6;
                break;
                default:
                    next_layer=APPLICATION_LAYER;
                    expected=HEADER_TYPE_RAW_DATA;
                break;
            }
            this_packet[current_header].length=iplen;
            this_packet[current_header].buf=(u8*)curr_pkt;
            this_packet[current_header++].type=HEADER_TYPE_IPv4;
			ip4.print(f,PRINT_DETAIL_HIGH);
			fprintf(f,"\n\tIP4.HDR.DATA:");PrintData(f,curr_pkt,iplen);
            ip4.reset();
            curr_pkt+=iplen;
            curr_pktlen-=iplen;
			++(*totalPackets);
        }
        /* IP version 6 ---------------------------------*/
		else if(ip4.getVersion()==6)
		{	ip4.reset();
            if(ip6.storeRecvData(curr_pkt, curr_pktlen)==OP_FAILURE)
			{	unknown_hdr=true;
                break;
            }
            if((ip6len=ip6.validate())==OP_FAILURE)
			{	unknown_hdr=true;
                break;
            }
            switch(ip6.getNextHeader())
			{	case HEADER_TYPE_ICMPv6:
                    next_layer=TRANSPORT_LAYER;
                    expected=HEADER_TYPE_ICMPv6;
                break;
                case HEADER_TYPE_IPv4: /* IPv4 in IPv6 */
                    next_layer=NETWORK_LAYER;
                    expected=HEADER_TYPE_IPv4;
                break;
                case HEADER_TYPE_TCP:
                    next_layer=TRANSPORT_LAYER;
                    expected=HEADER_TYPE_TCP;
                break;
                case HEADER_TYPE_UDP:
                    next_layer=TRANSPORT_LAYER;
                    expected=HEADER_TYPE_UDP;
                break;
                case HEADER_TYPE_IPv6: /* IPv6 in IPv6 */
                    next_layer=NETWORK_LAYER;
                    expected=HEADER_TYPE_IPv6;
                break;
                case HEADER_TYPE_IPv6_HOPOPT:
                    next_layer=EXTHEADERS_LAYER;
                    expected=HEADER_TYPE_IPv6_HOPOPT;
                break;
                case HEADER_TYPE_IPv6_OPTS:
                    next_layer=EXTHEADERS_LAYER;
                    expected=HEADER_TYPE_IPv6_OPTS;
                break;
                case HEADER_TYPE_IPv6_ROUTE:
                    next_layer=EXTHEADERS_LAYER;
                    expected=HEADER_TYPE_IPv6_ROUTE;
                break;
                case HEADER_TYPE_IPv6_FRAG:
                    next_layer=EXTHEADERS_LAYER;
                    expected=HEADER_TYPE_IPv6_FRAG;
                break;
                default:
                    next_layer=APPLICATION_LAYER;
                    expected=HEADER_TYPE_RAW_DATA;
                break;
            }
            this_packet[current_header].length=ip6len;
            this_packet[current_header].buf=(u8*)curr_pkt;
            this_packet[current_header++].type=HEADER_TYPE_IPv6;
			ip6.print(f,PRINT_DETAIL_HIGH);
			fprintf(f,"\nIP6.HDR.DATA:");PrintData(f,curr_pkt,ip6len);
            ip6.reset();
            curr_pkt+=ip6len;
            curr_pktlen-=ip6len;
			++(*totalPackets);
        /* Bogus IP version -----------------------------*/
        }
		else
		{	/* Wrong IP version, treat as raw data. */
            next_layer=APPLICATION_LAYER;
            expected=HEADER_TYPE_RAW_DATA;
	}	}
    /* TCP, UDP, ICMPv4 and ICMPv6 headers ************************************/
	else if(next_layer==TRANSPORT_LAYER)
	{	if(expected==HEADER_TYPE_TCP)
		{	if(tcp.storeRecvData(curr_pkt, curr_pktlen)==OP_FAILURE)
			{	unknown_hdr=true;
                break;
            }
            if((tcplen=tcp.validate())==OP_FAILURE)
			{	unknown_hdr=true;
                break;
            }
            expected=HEADER_TYPE_RAW_DATA;
            this_packet[current_header].length=tcplen;
            this_packet[current_header].buf=(u8*)curr_pkt;
            this_packet[current_header++].type=HEADER_TYPE_TCP;
			tcp.print(f,PRINT_DETAIL_HIGH);
			fprintf(f,"\n\tTCP.HDR.DATA:");PrintData(f,curr_pkt,tcplen);
			fprintf(f,"\n\tTCP.RAW DATA:");
			//if(ip4.getLen()>0)
				PrintData(f,curr_pkt+tcp.getOffset()*4,pktlen - tcp.getOffset()*4 - ip4.getHeaderLength()*4);
			//else if(ip6.getLen()>0)
			//	PrintData(f,curr_pkt+sizeof(udp.h),(udp.getTotalLength() - sizeof(udp.h) - ip6.getHeaderLength()*4));
            tcp.reset();
            curr_pkt+=tcplen;
            curr_pktlen-=tcplen;
			++(*totalPackets);
            next_layer=APPLICATION_LAYER;
        }
		else if(expected==HEADER_TYPE_UDP)
		{	if(udp.storeRecvData(curr_pkt, curr_pktlen)==OP_FAILURE)
			{	unknown_hdr=true;
                break;
            }
            if((udplen=udp.validate())==OP_FAILURE)
			{	unknown_hdr=true;
                break;
            }
            expected=HEADER_TYPE_RAW_DATA;
            this_packet[current_header].length=udplen;
            this_packet[current_header].buf=(u8*)curr_pkt;
            this_packet[current_header++].type=HEADER_TYPE_UDP;
			udp.print(f,PRINT_DETAIL_HIGH);
			fprintf(f,"\n\tUDP.HDR.DATA:");PrintData(f,curr_pkt,udplen);
			fprintf(f,"\n\tUDP.RAW DATA:");
			//if(ip4.getLen()>0)
				PrintData(f,curr_pkt+sizeof(udp.h),(udp.getTotalLength() - sizeof(udp.h) - ip4.getHeaderLength()*4));
			//else if(ip6.getLen()>0)
			//	PrintData(f,curr_pkt+sizeof(udp.h),(udp.getTotalLength() - sizeof(udp.h) - ip6.getHeaderLength()*4));
            udp.reset();
            curr_pkt+=udplen;
            curr_pktlen-=udplen;
			++(*totalPackets);
            next_layer=APPLICATION_LAYER;
        }
		else if(expected==HEADER_TYPE_ICMPv4)
		{	if(icmp4.storeRecvData(curr_pkt, curr_pktlen)==OP_FAILURE)
			{	unknown_hdr=true;
                break;
            }
            if((icmplen=icmp4.validate())==OP_FAILURE)
			{	unknown_hdr=true;
                break;
            }
            switch(icmp4.getType())
			{	/* Types that include an IPv4 packet as payload */
                case ICMP_UNREACH:
                case ICMP_TIMXCEED:
                case ICMP_PARAMPROB:
                case ICMP_SOURCEQUENCH:
                case ICMP_REDIRECT:
                    next_layer=NETWORK_LAYER;
                    expected=HEADER_TYPE_IPv4;
                break;
                /* ICMP types that include misc payloads (or no payload) */
                default:
                    expected=HEADER_TYPE_RAW_DATA;
                    next_layer=APPLICATION_LAYER;
                break;
            }
            this_packet[current_header].length=icmplen;
            this_packet[current_header].buf=(u8*)curr_pkt;
            this_packet[current_header++].type=HEADER_TYPE_ICMPv4;
			icmp4.print(f,PRINT_DETAIL_HIGH);
			fprintf(f,"\n\tICMP4.HDR.DATA:");PrintData(f,curr_pkt,icmplen);
            icmp4.reset();
            curr_pkt+=icmplen;
            curr_pktlen-=icmplen;
			++(*totalPackets);
        }
		else if(expected==HEADER_TYPE_ICMPv6)
		{	if(icmp6.storeRecvData(curr_pkt, curr_pktlen)==OP_FAILURE)
			{	unknown_hdr=true;
                break;
            }
            if((icmplen=icmp6.validate())==OP_FAILURE)
			{	unknown_hdr=true;
                break;
            }
            switch(icmp6.getType())
			{	/* Types that include an IPv6 packet as payload */
                case ICMPv6_UNREACH:
                case ICMPv6_PKTTOOBIG:
                case ICMPv6_TIMXCEED:
                case ICMPv6_PARAMPROB:
                    next_layer=NETWORK_LAYER;
                    expected=HEADER_TYPE_IPv6;
                break;
                /* ICMPv6 types that include misc payloads (or no payload) */
                default:
                    expected=HEADER_TYPE_RAW_DATA;
                    next_layer=APPLICATION_LAYER;
                break;
            }
            this_packet[current_header].length=icmplen;
            this_packet[current_header].buf=(u8*)curr_pkt;
            this_packet[current_header++].type=HEADER_TYPE_ICMPv6;
			icmp6.print(f,PRINT_DETAIL_HIGH);
			fprintf(f,"\n\tICMP6.HDR.DATA:");PrintData(f,curr_pkt,icmplen);
            icmp6.reset();
            curr_pkt+=icmplen;
            curr_pktlen-=icmplen;
			++(*totalPackets);
        }
		else
		{	/* Wrong application layer protocol, treat as raw data. */
            next_layer=APPLICATION_LAYER;
            expected=HEADER_TYPE_RAW_DATA;
    }   }
	/* IPv6 Extension Headers */
	else if(next_layer==EXTHEADERS_LAYER)
	{	u8 ext_next=0;
        /* Hop-by-Hop Options */
        if(expected==HEADER_TYPE_IPv6_HOPOPT)
		{	if(ext_hopt.storeRecvData(curr_pkt, curr_pktlen)==OP_FAILURE)
			{	unknown_hdr=true;
                break;
            }
            if((exthdrlen=ext_hopt.validate())==OP_FAILURE)
			{	unknown_hdr=true;
                break;
            }
            ext_next=ext_hopt.getNextHeader();
            ext_hopt.reset();
        }
		/* Routing Header */
        else if(expected==HEADER_TYPE_IPv6_ROUTE)
		{	if(ext_routing.storeRecvData(curr_pkt, curr_pktlen)==OP_FAILURE)
			{	unknown_hdr=true;
                break;
            }
            if((exthdrlen=ext_routing.validate())==OP_FAILURE)
			{	unknown_hdr=true;
                break;
            }
            ext_next=ext_routing.getNextHeader();
            ext_routing.reset();
        }
		/* Fragmentation Header */
		else if(expected==HEADER_TYPE_IPv6_FRAG)
		{	if(ext_frag.storeRecvData(curr_pkt, curr_pktlen)==OP_FAILURE)
			{	unknown_hdr=true;
                break;
            }
            if((exthdrlen=ext_frag.validate())==OP_FAILURE)
			{	unknown_hdr=true;
                break;
            }
            ext_next=ext_frag.getNextHeader();
            ext_frag.reset();
        }
        /* Destination Options Header */
		else if(expected==HEADER_TYPE_IPv6_OPTS)
		{	if(ext_dopts.storeRecvData(curr_pkt, curr_pktlen)==OP_FAILURE)
			{	unknown_hdr=true;
                break;
            }
            if((exthdrlen=ext_dopts.validate())==OP_FAILURE)
			{	unknown_hdr=true;
                break;
            }
            ext_next=ext_dopts.getNextHeader();
            ext_dopts.reset();
        }
		else
		{	/* Should never happen. */
            unknown_hdr=true;
            break;
        }

        /* Update the info for this header */
        this_packet[current_header].length=exthdrlen;
        this_packet[current_header].buf=(u8*)curr_pkt;
        this_packet[current_header++].type=expected;
        curr_pkt+=exthdrlen;
        curr_pktlen-=exthdrlen;
		++(*totalPackets);

        /* Lets's see what comes next */
        switch(ext_next)
		{	case HEADER_TYPE_ICMPv6:
                next_layer=TRANSPORT_LAYER;
                expected=HEADER_TYPE_ICMPv6;
            break;
            case HEADER_TYPE_IPv4: /* IPv4 in IPv6 */
                next_layer=NETWORK_LAYER;
                expected=HEADER_TYPE_IPv4;
            break;
            case HEADER_TYPE_TCP:
                next_layer=TRANSPORT_LAYER;
                expected=HEADER_TYPE_TCP;
            break;
            case HEADER_TYPE_UDP:
                next_layer=TRANSPORT_LAYER;
                expected=HEADER_TYPE_UDP;
            break;
            case HEADER_TYPE_IPv6: /* IPv6 in IPv6 */
                next_layer=NETWORK_LAYER;
                expected=HEADER_TYPE_IPv6;
            break;
            case HEADER_TYPE_IPv6_HOPOPT:
                next_layer=EXTHEADERS_LAYER;
                expected=HEADER_TYPE_IPv6_HOPOPT;
            break;
            case HEADER_TYPE_IPv6_OPTS:
                next_layer=EXTHEADERS_LAYER;
                expected=HEADER_TYPE_IPv6_OPTS;
            break;
            case HEADER_TYPE_IPv6_ROUTE:
                next_layer=EXTHEADERS_LAYER;
                expected=HEADER_TYPE_IPv6_ROUTE;
            break;
            case HEADER_TYPE_IPv6_FRAG:
                next_layer=EXTHEADERS_LAYER;
                expected=HEADER_TYPE_IPv6_FRAG;
            break;
            default:
                next_layer=APPLICATION_LAYER;
                expected=HEADER_TYPE_RAW_DATA;
            break;
	}	}
    /* Miscellaneous payloads *************************************************/
	else
	{ // next_layer==APPLICATION_LAYER
        if(curr_pktlen>0)
		{	//if(expected==HEADER_TYPE_DNS){
            //}else if(expected==HEADER_TYPE_HTTP){
            //}... ETC
            this_packet[current_header].length=(int)curr_pktlen;
            this_packet[current_header].buf=(u8*)curr_pkt;
            this_packet[current_header++].type=HEADER_TYPE_RAW_DATA;
			//fprintf(f,"\n\tRAW DATA:");
			//for(int i=0; i<curr_pktlen; i++)
			//	fprintf(f,"%s0%.2x","0x",curr_pkt[i]);
            curr_pktlen=0;
        }
        finished=true;
  } } /* End of header processing loop */

  /* If we couldn't validate some header, treat that header and any remaining
   * data, as raw application data. */
  if(unknown_hdr==true)
  {	if(curr_pktlen>0)
	{	this_packet[current_header].length=(int)curr_pktlen;
        this_packet[current_header].buf=(u8*)curr_pkt;
        this_packet[current_header++].type=HEADER_TYPE_RAW_DATA;
		//fprintf(f,"\n\tRAW DATA:");
		//for(int i=0; i<(int)curr_pktlen; i++)
		//	fprintf(f,"%s0%.2x","0x",curr_pkt[i]);
  } }

  return this_packet;
} /* End of parse_received_packet() */

//fast code:
pkt_type_t* MyParse_packet2(const u8 *pkt,int pktlen,int *totalPackets,bool eth_included)
{
u8 current_header=0;             /* Current array position of "this_packet" */
const u8 *curr_pkt=pkt;          /* Pointer to current part of the packet   */
size_t curr_pktlen=pktlen;       /* Remaining packet length                 */
int ethlen=0, arplen=0;          /* Aux length variables: link layer        */
int iplen=0,ip6len=0;            /* Aux length variables: network layer     */
int tcplen=0,udplen=0,icmplen=0; /* Aux length variables: transport layer   */
int exthdrlen=0;                 /* Aux length variables: extension headers */
int next_layer=0;                /* Next header type to process             */
int expected=0;                  /* Next protocol expected                  */
bool finished=false;             /* Loop breaking flag                      */
bool unknown_hdr=false;          /* Indicates unknown header found          */
IPv4Header *ip4;
IPv6Header *ip6;
TCPHeader *tcp;
UDPHeader *udp;
ICMPv4Header *icmp4;
ICMPv6Header *icmp6;
EthernetHeader *eth;
DestOptsHeader *ext_dopts;
FragmentHeader *ext_frag;
HopByHopHeader *ext_hopt;
RoutingHeader *ext_routing;
ARPHeader *arp;

  //memset(this_packet, 0, sizeof(this_packet));
  *totalPackets = 0;

  /* Decide which layer we have to start from */
  if(eth_included)
  { next_layer=LINK_LAYER;
    expected=HEADER_TYPE_ETHERNET;
  }else
    next_layer=NETWORK_LAYER;

  /* Header processing loop */
  while(!finished && curr_pktlen>0 && current_header<MAX_HEADERS_IN_PACKET)
  {	/* Ethernet and ARP headers ***********************************************/
    if(next_layer==LINK_LAYER)
	{	if(expected==HEADER_TYPE_ETHERNET)
		{	if(curr_pkt==NULL || curr_pktlen<ETH_HEADER_LEN)//eth.storeRecvData(curr_pkt, curr_pktlen)==OP_FAILURE)
			{	unknown_hdr=true;
                break;
            }
			eth = (EthernetHeader*)curr_pkt;
            if((ethlen=eth->validate())==OP_FAILURE)
			{	unknown_hdr=true;
                break;
            }
            /* Determine next header type */
            switch(eth->getEtherType())
			{	case ETHTYPE_IPV4:
                    expected=HEADER_TYPE_IPv4;
                    next_layer=NETWORK_LAYER;
                break;
                case ETHTYPE_IPV6:
                    expected=HEADER_TYPE_IPv6;
                    next_layer=NETWORK_LAYER;
                break;
                case ETHTYPE_ARP:
                    next_layer=LINK_LAYER;
                    expected=HEADER_TYPE_ARP;
                break;
                default:
                    next_layer=APPLICATION_LAYER;
                    expected=HEADER_TYPE_RAW_DATA;
                break;
            }
            this_packet[current_header].length=ethlen;
            this_packet[current_header].buf=(u8*)curr_pkt;
            this_packet[current_header++].type=HEADER_TYPE_ETHERNET;
            //eth.reset();
            curr_pkt+=ethlen;
            curr_pktlen-=ethlen;
			++(*totalPackets);
        }
		else if(expected==HEADER_TYPE_ARP)
		{	if(curr_pkt==NULL || curr_pktlen<ARP_HEADER_LEN)//arp.storeRecvData(curr_pkt, curr_pktlen)==OP_FAILURE)
			{	unknown_hdr=true;
                break;
            }
			arp = (ARPHeader*)curr_pkt;
            if((arplen=arp->validate())==OP_FAILURE)
			{	unknown_hdr=true;
                break;
            }
            this_packet[current_header].length=arplen;
            this_packet[current_header].buf=(u8*)curr_pkt;
            this_packet[current_header++].type=HEADER_TYPE_ARP;
            //arp.reset();
            curr_pkt+=arplen;
            curr_pktlen-=arplen;
			++(*totalPackets);
            if(curr_pktlen>0)
			{	next_layer=APPLICATION_LAYER;
                expected=HEADER_TYPE_RAW_DATA;
            }else
				finished=true;
        }
		else
			assert(finished==true);
    }
    /* IPv4 and IPv6 headers **************************************************/
	else if(next_layer==NETWORK_LAYER)
	{	/* Determine IP version */
        if(curr_pkt==NULL || curr_pktlen<IP_HEADER_LEN)//ip4.storeRecvData(curr_pkt, curr_pktlen)==OP_FAILURE)
		{   unknown_hdr=true;
            break;
        }
		ip4 = (IPv4Header*)curr_pkt;
        /* IP version 4 ---------------------------------*/
        if(ip4->getVersion()==4)
		{	if((iplen=ip4->validate())==OP_FAILURE)
			{	unknown_hdr=true;
                break;
            }
            /* Determine next header type */
            switch(ip4->getNextProto())
			{	case HEADER_TYPE_ICMPv4:
                    next_layer=TRANSPORT_LAYER;
                    expected=HEADER_TYPE_ICMPv4;
                break;
                case HEADER_TYPE_IPv4: /* IP in IP */
                    next_layer=NETWORK_LAYER;
                    expected=HEADER_TYPE_IPv4;
                break;
                case HEADER_TYPE_TCP:
                    next_layer=TRANSPORT_LAYER;
                    expected=HEADER_TYPE_TCP;
                break;
                case HEADER_TYPE_UDP:
                    next_layer=TRANSPORT_LAYER;
                    expected=HEADER_TYPE_UDP;
                break;
                case HEADER_TYPE_IPv6: /* IPv6 in IPv4 */
                    next_layer=NETWORK_LAYER;
                    expected=HEADER_TYPE_IPv6;
                break;
                default:
                    next_layer=APPLICATION_LAYER;
                    expected=HEADER_TYPE_RAW_DATA;
                break;
            }
            this_packet[current_header].length=iplen;
            this_packet[current_header].buf=(u8*)curr_pkt;
            this_packet[current_header++].type=HEADER_TYPE_IPv4;
            //ip4.reset();
            curr_pkt+=iplen;
            curr_pktlen-=iplen;
			++(*totalPackets);
        }
        /* IP version 6 ---------------------------------*/
		else if(ip4->getVersion()==6)
		{	//ip4.reset();
            if(curr_pkt==NULL || curr_pktlen<IPv6_HEADER_LEN)//ip6.storeRecvData(curr_pkt, curr_pktlen)==OP_FAILURE)
			{	unknown_hdr=true;
                break;
            }
			ip6 = (IPv6Header*)curr_pkt; 
            if((ip6len=ip6->validate())==OP_FAILURE)
			{	unknown_hdr=true;
                break;
            }
            switch(ip6->getNextHeader())
			{	case HEADER_TYPE_ICMPv6:
                    next_layer=TRANSPORT_LAYER;
                    expected=HEADER_TYPE_ICMPv6;
                break;
                case HEADER_TYPE_IPv4: /* IPv4 in IPv6 */
                    next_layer=NETWORK_LAYER;
                    expected=HEADER_TYPE_IPv4;
                break;
                case HEADER_TYPE_TCP:
                    next_layer=TRANSPORT_LAYER;
                    expected=HEADER_TYPE_TCP;
                break;
                case HEADER_TYPE_UDP:
                    next_layer=TRANSPORT_LAYER;
                    expected=HEADER_TYPE_UDP;
                break;
                case HEADER_TYPE_IPv6: /* IPv6 in IPv6 */
                    next_layer=NETWORK_LAYER;
                    expected=HEADER_TYPE_IPv6;
                break;
                case HEADER_TYPE_IPv6_HOPOPT:
                    next_layer=EXTHEADERS_LAYER;
                    expected=HEADER_TYPE_IPv6_HOPOPT;
                break;
                case HEADER_TYPE_IPv6_OPTS:
                    next_layer=EXTHEADERS_LAYER;
                    expected=HEADER_TYPE_IPv6_OPTS;
                break;
                case HEADER_TYPE_IPv6_ROUTE:
                    next_layer=EXTHEADERS_LAYER;
                    expected=HEADER_TYPE_IPv6_ROUTE;
                break;
                case HEADER_TYPE_IPv6_FRAG:
                    next_layer=EXTHEADERS_LAYER;
                    expected=HEADER_TYPE_IPv6_FRAG;
                break;
                default:
                    next_layer=APPLICATION_LAYER;
                    expected=HEADER_TYPE_RAW_DATA;
                break;
            }
            this_packet[current_header].length=ip6len;
            this_packet[current_header].buf=(u8*)curr_pkt;
            this_packet[current_header++].type=HEADER_TYPE_IPv6;
            //ip6.reset();
            curr_pkt+=ip6len;
            curr_pktlen-=ip6len;
			++(*totalPackets);
        /* Bogus IP version -----------------------------*/
        }
		else
		{	/* Wrong IP version, treat as raw data. */
            next_layer=APPLICATION_LAYER;
            expected=HEADER_TYPE_RAW_DATA;
	}	}
    /* TCP, UDP, ICMPv4 and ICMPv6 headers ************************************/
	else if(next_layer==TRANSPORT_LAYER)
	{	if(expected==HEADER_TYPE_TCP)
		{	if(curr_pkt==NULL || curr_pktlen<TCP_HEADER_LEN)//tcp.storeRecvData(curr_pkt, curr_pktlen)==OP_FAILURE)
			{	unknown_hdr=true;
                break;
            }
			tcp = (TCPHeader*)curr_pkt;
            if((tcplen=tcp->validate())==OP_FAILURE)
			{	unknown_hdr=true;
                break;
            }
            expected=HEADER_TYPE_RAW_DATA;
            this_packet[current_header].length=tcplen;
            this_packet[current_header].buf=(u8*)curr_pkt;
            this_packet[current_header++].type=HEADER_TYPE_TCP;
            //tcp.reset();
            curr_pkt+=tcplen;
            curr_pktlen-=tcplen;
			++(*totalPackets);
            next_layer=APPLICATION_LAYER;
        }
		else if(expected==HEADER_TYPE_UDP)
		{	if(curr_pkt==NULL || curr_pktlen<UDP_HEADER_LEN)//udp.storeRecvData(curr_pkt, curr_pktlen)==OP_FAILURE)
			{	unknown_hdr=true;
                break;
            }
			udp = (UDPHeader*)curr_pkt;
            if((udplen=udp->validate())==OP_FAILURE)
			{	unknown_hdr=true;
                break;
            }
            expected=HEADER_TYPE_RAW_DATA;
            this_packet[current_header].length=udplen;
            this_packet[current_header].buf=(u8*)curr_pkt;
            this_packet[current_header++].type=HEADER_TYPE_UDP;
            //udp.reset();
            curr_pkt+=udplen;
            curr_pktlen-=udplen;
			++(*totalPackets);
            next_layer=APPLICATION_LAYER;
        }
		else if(expected==HEADER_TYPE_ICMPv4)
		{	if(curr_pkt==NULL || curr_pktlen<ICMP_STD_HEADER_LEN)//icmp4.storeRecvData(curr_pkt, curr_pktlen)==OP_FAILURE)
			{	unknown_hdr=true;
                break;
            }
			icmp4 = (ICMPv4Header*)curr_pkt;
            if((icmplen=icmp4->validate())==OP_FAILURE)
			{	unknown_hdr=true;
                break;
            }
            switch(icmp4->getType())
			{	/* Types that include an IPv4 packet as payload */
                case ICMP_UNREACH:
                case ICMP_TIMXCEED:
                case ICMP_PARAMPROB:
                case ICMP_SOURCEQUENCH:
                case ICMP_REDIRECT:
                    next_layer=NETWORK_LAYER;
                    expected=HEADER_TYPE_IPv4;
                break;
                /* ICMP types that include misc payloads (or no payload) */
                default:
                    expected=HEADER_TYPE_RAW_DATA;
                    next_layer=APPLICATION_LAYER;
                break;
            }
            this_packet[current_header].length=icmplen;
            this_packet[current_header].buf=(u8*)curr_pkt;
            this_packet[current_header++].type=HEADER_TYPE_ICMPv4;
            //icmp4.reset();
            curr_pkt+=icmplen;
            curr_pktlen-=icmplen;
			++(*totalPackets);
        }
		else if(expected==HEADER_TYPE_ICMPv6)
		{	if(curr_pkt==NULL || curr_pktlen<ICMPv6_MIN_HEADER_LEN)//icmp6.storeRecvData(curr_pkt, curr_pktlen)==OP_FAILURE)
			{	unknown_hdr=true;
                break;
            }
			icmp6 = (ICMPv6Header*)curr_pkt;
            if((icmplen=icmp6->validate())==OP_FAILURE)
			{	unknown_hdr=true;
                break;
            }
            switch(icmp6->getType())
			{	/* Types that include an IPv6 packet as payload */
                case ICMPv6_UNREACH:
                case ICMPv6_PKTTOOBIG:
                case ICMPv6_TIMXCEED:
                case ICMPv6_PARAMPROB:
                    next_layer=NETWORK_LAYER;
                    expected=HEADER_TYPE_IPv6;
                break;
                /* ICMPv6 types that include misc payloads (or no payload) */
                default:
                    expected=HEADER_TYPE_RAW_DATA;
                    next_layer=APPLICATION_LAYER;
                break;
            }
            this_packet[current_header].length=icmplen;
            this_packet[current_header].buf=(u8*)curr_pkt;
            this_packet[current_header++].type=HEADER_TYPE_ICMPv6;
            //icmp6.reset();
            curr_pkt+=icmplen;
            curr_pktlen-=icmplen;
			++(*totalPackets);
        }
		else
		{	/* Wrong application layer protocol, treat as raw data. */
            next_layer=APPLICATION_LAYER;
            expected=HEADER_TYPE_RAW_DATA;
    }   }
	/* IPv6 Extension Headers */
	else if(next_layer==EXTHEADERS_LAYER)
	{	u8 ext_next=0;
        /* Hop-by-Hop Options */
        if(expected==HEADER_TYPE_IPv6_HOPOPT)
		{	if(curr_pkt==NULL || curr_pktlen<HOPBYHOP_MIN_HEADER_LEN)//ext_hopt.storeRecvData(curr_pkt, curr_pktlen)==OP_FAILURE)
			{	unknown_hdr=true;
                break;
            }
			ext_hopt= (HopByHopHeader*)curr_pkt;
            if((exthdrlen=ext_hopt->validate())==OP_FAILURE)
			{	unknown_hdr=true;
                break;
            }
            ext_next=ext_hopt->getNextHeader();
            //ext_hopt.reset();
        }
		/* Routing Header */
        else if(expected==HEADER_TYPE_IPv6_ROUTE)
		{	if(curr_pkt==NULL || curr_pktlen<ROUTING_HEADER_MIN_LEN)//ext_routing.storeRecvData(curr_pkt, curr_pktlen)==OP_FAILURE)
			{	unknown_hdr=true;
                break;
            }
			ext_routing = (RoutingHeader*)curr_pkt;
            if((exthdrlen=ext_routing->validate())==OP_FAILURE)
			{	unknown_hdr=true;
                break;
            }
            ext_next=ext_routing->getNextHeader();
            ext_routing->reset();
        }
		/* Fragmentation Header */
		else if(expected==HEADER_TYPE_IPv6_FRAG)
		{	if(curr_pkt==NULL || curr_pktlen<FRAGMENT_HEADER_LEN)//ext_frag.storeRecvData(curr_pkt, curr_pktlen)==OP_FAILURE)
			{	unknown_hdr=true;
                break;
            }
			ext_frag = (FragmentHeader*)curr_pkt;
            if((exthdrlen=ext_frag->validate())==OP_FAILURE)
			{	unknown_hdr=true;
                break;
            }
            ext_next=ext_frag->getNextHeader();
            //ext_frag.reset();
        }
        /* Destination Options Header */
		else if(expected==HEADER_TYPE_IPv6_OPTS)
		{	if(curr_pkt==NULL || curr_pktlen<ICMPv6_OPTION_MIN_HEADER_LEN)//ext_dopts.storeRecvData(curr_pkt, curr_pktlen)==OP_FAILURE)
			{	unknown_hdr=true;
                break;
            }
			ext_dopts = (DestOptsHeader*)curr_pkt;
            if((exthdrlen=ext_dopts->validate())==OP_FAILURE)
			{	unknown_hdr=true;
                break;
            }
            ext_next=ext_dopts->getNextHeader();
            //ext_dopts.reset();
        }
		else
		{	/* Should never happen. */
            unknown_hdr=true;
            break;
        }

        /* Update the info for this header */
        this_packet[current_header].length=exthdrlen;
        this_packet[current_header].buf=(u8*)curr_pkt;
        this_packet[current_header++].type=expected;
        curr_pkt+=exthdrlen;
        curr_pktlen-=exthdrlen;
		++(*totalPackets);

        /* Lets's see what comes next */
        switch(ext_next)
		{	case HEADER_TYPE_ICMPv6:
                next_layer=TRANSPORT_LAYER;
                expected=HEADER_TYPE_ICMPv6;
            break;
            case HEADER_TYPE_IPv4: /* IPv4 in IPv6 */
                next_layer=NETWORK_LAYER;
                expected=HEADER_TYPE_IPv4;
            break;
            case HEADER_TYPE_TCP:
                next_layer=TRANSPORT_LAYER;
                expected=HEADER_TYPE_TCP;
            break;
            case HEADER_TYPE_UDP:
                next_layer=TRANSPORT_LAYER;
                expected=HEADER_TYPE_UDP;
            break;
            case HEADER_TYPE_IPv6: /* IPv6 in IPv6 */
                next_layer=NETWORK_LAYER;
                expected=HEADER_TYPE_IPv6;
            break;
            case HEADER_TYPE_IPv6_HOPOPT:
                next_layer=EXTHEADERS_LAYER;
                expected=HEADER_TYPE_IPv6_HOPOPT;
            break;
            case HEADER_TYPE_IPv6_OPTS:
                next_layer=EXTHEADERS_LAYER;
                expected=HEADER_TYPE_IPv6_OPTS;
            break;
            case HEADER_TYPE_IPv6_ROUTE:
                next_layer=EXTHEADERS_LAYER;
                expected=HEADER_TYPE_IPv6_ROUTE;
            break;
            case HEADER_TYPE_IPv6_FRAG:
                next_layer=EXTHEADERS_LAYER;
                expected=HEADER_TYPE_IPv6_FRAG;
            break;
            default:
                next_layer=APPLICATION_LAYER;
                expected=HEADER_TYPE_RAW_DATA;
            break;
	}	}
    /* Miscellaneous payloads *************************************************/
	else
	{ // next_layer==APPLICATION_LAYER
        if(curr_pktlen>0)
		{	//if(expected==HEADER_TYPE_DNS){
            //}else if(expected==HEADER_TYPE_HTTP){
            //}... ETC
            this_packet[current_header].length=(int)curr_pktlen;
            this_packet[current_header].buf=(u8*)curr_pkt;
            this_packet[current_header++].type=HEADER_TYPE_RAW_DATA;
            curr_pktlen=0;
        }
        finished=true;
  } } /* End of header processing loop */

  /* If we couldn't validate some header, treat that header and any remaining
   * data, as raw application data. */
  if(unknown_hdr==true)
  {	if(curr_pktlen>0)
	{	this_packet[current_header].length=(int)curr_pktlen;
        this_packet[current_header].buf=(u8*)curr_pkt;
        this_packet[current_header++].type=HEADER_TYPE_RAW_DATA;
  } }

  return this_packet;
} /* End of parse_received_packet() */

bool PrintPacket(pkt_type_t *pckt)
{
IPv4Header* ip4 = (IPv4Header*)pckt->buf;
IPv6Header* ip6 = (IPv6Header*)pckt->buf;
TCPHeader* tcp = (TCPHeader*)pckt->buf;
UDPHeader* udp = (UDPHeader*)pckt->buf;
ICMPv4Header* icmp4 = (ICMPv4Header*)pckt->buf;
ICMPv6Header* icmp6 = (ICMPv6Header*)pckt->buf;
EthernetHeader eth;// = (EthernetHeader&)pckt->buf;
DestOptsHeader* ext_dopts = (DestOptsHeader*)pckt->buf;
FragmentHeader* ext_frag = (FragmentHeader*)pckt->buf;
HopByHopHeader* ext_hopt = (HopByHopHeader*)pckt->buf;
RoutingHeader* ext_routing = (RoutingHeader*)pckt->buf;
ARPHeader* arp = (ARPHeader*)pckt->buf;

	FILE *f = fopen("pckInfo.txt","w");

	switch(pckt->type)
	{	case HEADER_TYPE_ETHERNET:
			eth.storeRecvData(pckt->buf,pckt->length);
			eth.print(f,PRINT_DETAIL_HIGH);
			break;
		case HEADER_TYPE_IPv4:
			ip4->print(f,PRINT_DETAIL_HIGH);
			break;
		case HEADER_TYPE_IPv6:
			ip6->print(f,PRINT_DETAIL_HIGH);
			break;
		case HEADER_TYPE_ARP:
			arp->print(f,PRINT_DETAIL_HIGH);
			break;
		case HEADER_TYPE_RAW_DATA:
			//arp->print(f,PRINT_DETAIL_HIGH);
			break;
		case HEADER_TYPE_ICMPv4:
			icmp4->print(f,PRINT_DETAIL_HIGH);
			break;
		case HEADER_TYPE_ICMPv6:
			icmp6->print(f,PRINT_DETAIL_HIGH);
			break;
		case HEADER_TYPE_TCP:
			tcp->print(f,PRINT_DETAIL_HIGH);
			break;
		case HEADER_TYPE_UDP:
			udp->print(f,PRINT_DETAIL_HIGH);
			break;
		case HEADER_TYPE_IPv6_HOPOPT:
			ext_hopt->print(f,PRINT_DETAIL_HIGH);
			break;
		case HEADER_TYPE_IPv6_OPTS:
			ext_dopts->print(f,PRINT_DETAIL_HIGH);
			break;
		case HEADER_TYPE_IPv6_ROUTE:
			ext_routing->print(f,PRINT_DETAIL_HIGH);
			break;
		case HEADER_TYPE_IPv6_FRAG:
			ext_frag->print(f,PRINT_DETAIL_HIGH);
			break;
	}
	fclose(f);
	return true;
/*#undef ip4
#undef ip6
#undef tcp
#undef udp
#undef icmp4
#undef icmp6
#undef eth
#undef ext_dopts
#undef ext_frag
#undef ext_hopt
#undef ext_routing
#undef arp*/
}

void PrintData(FILE *f,const unsigned char* data , int Size)
{
char a , line[17] , c;
int i,j;

	fprintf(f,"\n");

//loop over each character and print
for(i=0 ; i < Size ; i++)
{	c = data[i];
 
	//Print the hex value for every character , with a space. Important to make unsigned
	fprintf(f," %.2x", (unsigned char) c);
	 
	//Add the character to data line. Important to make unsigned
	a = ( c >=32 && c <=128) ? (unsigned char) c : '.';
	line[i%16] = a;
	 
	//if last character of a line , then print the line - 16 characters in 1 line
	if( (i!=0 && (i+1)%16==0) || i == Size - 1)
	{	line[i%16 + 1] = '\0';
		
		//print a big gap of 10 characters between hex and characters
		fprintf(f ," ");
	
		//Print additional spaces for last lines which might be less than 16 characters in length
		for( j = (int)strlen(line) ; j < 16; j++)
			fprintf(f , " ");
	 
		fprintf(f , "%s \n" , line);
}	}
 
//fprintf(f , "\n");
}