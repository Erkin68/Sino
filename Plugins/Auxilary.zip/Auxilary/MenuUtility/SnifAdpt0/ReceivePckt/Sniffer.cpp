#pragma warning(disable:4005)
#pragma warning(disable:4996)


#include "winsock2.h"
#include "..\resource.h"
#include "MyPacketParser.h"
#include "..\..\..\..\Virtual Panel\AdptrIP4Scan\Packet\Packet32.h"
extern "C" {
#include "..\..\..\..\Virtual Panel\AdptrIP4Scan\Plugins_C.h"
}


//#pragma comment(lib, "packet.lib")
#pragma comment(lib, "ws2_32.lib")
#pragma comment(lib,"iphlpapi.lib")

#define NDIS_PACKET_TYPE_DIRECTED 0x0001

extern "C"
{

extern BOOL bQuit;
extern int iAdptr;

char s[512];DWORD rs;
char RetCar[3] = {0x0d, 0x0a, 0x00};

DWORD snif(LPVOID dlg)//command line: 192.168.101.5 192.168.14.35
{
 char s_mac[6]={0};
 LPADAPTER lpAdapter;
 LPPACKET lpRecvPckt;
 static CHAR adapter_list[10][1024];
 char adapter_name[2048];
 char *name,*desc;
 ULONG adapter_length=1024;
 ULONG i,adapter_num=0;
 unsigned char sndBuf[1024]={0};
 unsigned char rcvBuf[256000]={0};
 char localMac[20]={0},localIP[20]={0};
 char remoteMac[6]={0};
 FILE *f; 

 if(PacketGetAdapterNames((PTSTR)adapter_name, &adapter_length)==FALSE)
 {	printf("PacketGetAdapterNames error:%d\n",GetLastError());
    return -1;
 }
    
 desc = adapter_name;
 while(*desc != '\0' || *(desc + 1) != '\0')
	desc++;	
 desc += 2;	
 name = adapter_name;
 i = 0;
 //printf("\nNetwork adapters searched:");

 int iCmb = (int)SendMessage(GetDlgItem((HWND)dlg,IDC_COMBO_ADAPTER),CB_GETCOUNT,0,0);
 //SendMessage(GetDlgItem((HWND)dlg,IDC_COMBO_ADAPTER),CB_RESETCONTENT,0,0);
 while (*name != '\0')
 {	memcpy(adapter_list[i],name,2*(desc-name));
	//printf("\n%d-adapter founded: %s, desc: %s",i+1,adapter_list[i],desc);
	if(!iCmb)
		SendMessageA(GetDlgItem((HWND)dlg,IDC_COMBO_ADAPTER),CB_ADDSTRING,0,(LPARAM)desc);
 	name += strlen((char*)name) + 1;
 	desc += strlen((char*)desc) + 1;
	++i;
 } 
 if(!iCmb)SendMessage(GetDlgItem((HWND)dlg,IDC_COMBO_ADAPTER),CB_SETCURSEL,0,0);

 lpAdapter=(LPADAPTER)PacketOpenAdapter((PCHAR)adapter_list[iAdptr]); 
 if (!lpAdapter||(lpAdapter->hFile==INVALID_HANDLE_VALUE))
 {   sprintf(s,"Unable to open the driver, Error Code : %lx\n", GetLastError());
	 //WriteFile(GetStdHandle(STD_OUTPUT_HANDLE),s,strlen(s),&rs,NULL);

	SendMessageA(GetDlgItem((HWND)dlg,IDC_EDIT_STDOUT),EM_REPLACESEL,(WPARAM)FALSE,(LPARAM)(LPCSTR)s);
	SendMessageA(GetDlgItem((HWND)dlg,IDC_EDIT_STDOUT),EM_REPLACESEL, (WPARAM)FALSE, (LPARAM)(LPCSTR)RetCar);
	SendMessageA(GetDlgItem((HWND)dlg,IDC_EDIT_STDOUT),EM_SCROLLCARET, (WPARAM)0, (LPARAM)0);
	return -1;
 }


#define NDIS_PACKET_TYPE_DIRECTED		0x0001
#define NDIS_PACKET_TYPE_PROMISCUOUS    0x0020
#define NDIS_PACKET_TYPE_BROADCAST		0x0040
#define NDIS_PACKET_TYPE_SOURCE_ROUTING 0x00000010
//#define NDIS_PACKET_TYPE_BROADCAST		0x00000008
#define NDIS_PACKET_TYPE_ALL_MULTICAST  0x00000004
#define NDIS_PACKET_TYPE_MULTICAST      0x00000002
#define NDIS_PACKET_TYPE_SMT            0x00000040
#define NDIS_PACKET_TYPE_ALL_FUNCTIONAL 0x00002000
#define NDIS_PACKET_TYPE_FUNCTIONAL     0x00004000
#define NDIS_PACKET_TYPE_MAC_FRAME      0x00008000
#define NDIS_RING_SIGNAL_LOSS           0x00008000
#define NDIS_PACKET_TYPE_ALL_LOCAL      0x00000080
#define NDIS_PACKET_TYPE_GROUP          0x00001000

 if(!PacketSetHwFilter(lpAdapter, NDIS_PACKET_TYPE_PROMISCUOUS))
	PacketSetHwFilter(lpAdapter, NDIS_PACKET_TYPE_ALL_LOCAL);
 PacketSetBuff(lpAdapter,512000);
 PacketSetReadTimeout(lpAdapter,1500);//sekund


 lpRecvPckt=PacketAllocatePacket();
 PacketInitPacket(lpRecvPckt,rcvBuf,256000);

 f=fopen("pckInfo.txt","w");

 int p=0;
 while(1)
 {	pkt_type_t* t;int totalPackets;
	PacketReceivePacket(lpAdapter, lpRecvPckt, TRUE);//20===sizeof(bpf_hdr);
	if(lpRecvPckt->ulBytesReceived>20)
	{	sprintf(s,"%d-packet received and printed to the file 'pckInfo.txt'",p);//"\n edi
		//WriteFile(GetStdHandle(STD_OUTPUT_HANDLE),s,strlen(s),&rs,NULL);

		SendMessageA(GetDlgItem((HWND)dlg,IDC_EDIT_STDOUT),EM_REPLACESEL,(WPARAM)FALSE,(LPARAM)(LPCSTR)s);
		SendMessageA(GetDlgItem((HWND)dlg,IDC_EDIT_STDOUT),EM_REPLACESEL,(WPARAM)FALSE, (LPARAM)(LPCSTR)RetCar);
		SendMessageA(GetDlgItem((HWND)dlg,IDC_EDIT_STDOUT),EM_SCROLLCARET,(WPARAM)0, (LPARAM)0);

		fprintf(f,"\n%d-",p++);
		t = MyParse_packet1(rcvBuf+20,lpRecvPckt->ulBytesReceived-20,&totalPackets,true,f);
	}
	else
	{	SendMessageA(GetDlgItem((HWND)dlg,IDC_EDIT_STDOUT),EM_REPLACESEL,(WPARAM)FALSE,(LPARAM)(LPCSTR)"Packet not received...");
		SendMessageA(GetDlgItem((HWND)dlg,IDC_EDIT_STDOUT),EM_REPLACESEL,(WPARAM)FALSE, (LPARAM)(LPCSTR)RetCar);
		SendMessageA(GetDlgItem((HWND)dlg,IDC_EDIT_STDOUT),EM_SCROLLCARET,(WPARAM)0, (LPARAM)0);
	}
	memset(rcvBuf,0,4096);
	if(bQuit)
	{	SendMessageA(GetDlgItem((HWND)dlg,IDC_EDIT_STDOUT),EM_REPLACESEL,(WPARAM)FALSE,(LPARAM)(LPCSTR)"break sended...");
		break;
}	}
 fclose(f);

 PacketFreePacket(lpRecvPckt);
 PacketCloseAdapter(lpAdapter); 
 return 0;
}
}//end of extern "C"