#define _CRT_SECURE_NO_WARNINGS

#include "windows.h"
//#include "resource.h"
#include "stdio.h"
#include "strsafe.h"
#include "..\..\..\..\Operations\MyShell\MyShellC.h"

#include <objbase.h>
#include <activeds.h>
#include <ACCCTRL.h>
// For security descriptor control flags.
#include <winnt.h>
#define _WIN32_WINNT 0x0500
#include <Sddl.h>


#pragma comment(lib, "Secur32.lib")

#define SECURITY_WIN32

#include "Security.h"

#define MAX_STRINGS 5
#pragma warning(disable:4995)


wchar_t **strngs=NULL;
HMODULE plgnDllInst;

BOOL APIENTRY DllMain(HMODULE hModule,DWORD ul_reason_for_call,LPVOID lpReserved)
{
FILE *f;
int i,l;
wchar_t *pend;
wchar_t dllname[260],mnuStr[64];
	switch(ul_reason_for_call)
	{	case DLL_PROCESS_ATTACH:
			plgnDllInst=hModule;
			if(strngs)break;
			strngs = (wchar_t **)malloc(MAX_STRINGS*sizeof(wchar_t*));
#ifdef _DEBUG
			GetModuleFileNameW(hModule,dllname,260);//GetModuleHandle("FileDefragDbg.dll")
#else
			GetModuleFileNameW(hModule,dllname,260);//GetModuleHandle("FileDefragRel.dll")
#endif
			//LoadNTFuncs();
			pend = wcsrchr(dllname,'\\');
			if(pend){*pend++='\\';*pend=0;}

			if(GetEnvironmentVariable(L"languge",mnuStr,64))//Language instartup qo'yadur;
			{	if(!wcscmp(mnuStr,L"russian"))
					wcscat(dllname,L"PlugSnffrStrsRus.txt");
				else if(!wcscmp(mnuStr,L"uzbekl"))
					wcscat(dllname,L"PlugSnffrStrsUZBL.txt");
				else if(!wcscmp(mnuStr,L"uzbekk"))
					wcscat(dllname,L"PlugSnffrStrsUZBK.txt");
				else//if(wcscmp(mnuStr,L"Exit")
					wcscat(dllname,L"PlugSnffrStrsEng.txt");
			}	
			else wcscat(dllname,L"PlugSnffrStrsEng.txt");

			f=_wfopen(dllname,L"r,ccs=UNICODE");
			if(f)
			{	wchar_t s[260];fwscanf(f,L"%s", s);
				if(wcscmp(s,L"Plugin")) goto NillStr;
				fwscanf(f,L"%s", s);
				if(wcscmp(s,L"Sniffer.dll")) goto NillStr;
				fwscanf(f,L"%s", s);
				if(wcscmp(s,L"Strings:")) goto NillStr;
				for(i=0; i<MAX_STRINGS; i++)
				{	int t;fwscanf_s(f,L"%d", &t);
					if(t-1!=i) goto NillStr;
					//l=fscanf(f,"%s", s);
					l=fscanLineString(f,256,s);
					strngs[i]=(wchar_t*)malloc(sizeof(wchar_t)*(l+1));
					memcpy(strngs[i],s,sizeof(wchar_t)*(l+1));
				}
				fclose(f);
			}
			else
			{int l;
NillStr:
				l=(int)wcslen(L"Sino-sniffer plugin,ver.1.0. fr.Erkin Sattorov.Karaulbazar-2013.")+1;
					strngs[0]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[0],l,L"Sino-sniffer plugin,ver.1.0. fr.Erkin Sattorov.Karaulbazar-2013.");
				l=(int)wcslen(L"Sniffer:")+1;
					strngs[1]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[1],l,L"Sniffer:");
				l=(int)wcslen(L"Sniffer")+1;//strngs[2] bo'sh
					strngs[2]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[2],l,L"Sniffer");
				l=(int)wcslen(L"Exit")+1;
					strngs[3]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[3],l,L"Exit");
				l=(int)wcslen(L"Sniffer")+1;
					strngs[4]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[4],l,L"Sniffer");
			}
			break;
		case DLL_THREAD_ATTACH:
			break;
		case DLL_THREAD_DETACH:
			break;
		case DLL_PROCESS_DETACH:
			if(strngs)
			{	for(i=0; i<MAX_STRINGS; i++)
					free(strngs[i]);
				free(strngs);
				//saveOptCpp();
				strngs=NULL;
			}
			break;
	}
	return TRUE;
}

int GetAppUserName(LPWSTR computerName, LPWSTR userName, int *ln1, int *ln2)
{
	LPWSTR		ptstrUserName = NULL;
	DWORD		dwLength = (1024 + 1) * sizeof(TCHAR);
	int			bSuccess = 0,l1,l2;
	
	if ((ptstrUserName = (LPTSTR)LocalAlloc(LPTR, dwLength)))
	{   if (GetUserNameExW(NameSamCompatible,ptstrUserName,&dwLength))//
		{	wchar_t *p = wcschr(ptstrUserName, '\\');
			if(p)
			{	l1 = (int)(p - &ptstrUserName[0]);
				l2 = wcslen(p+1)+1;
				if(l1 > (*ln1)-1) {*ln1 = l1+1; bSuccess = -1;}
				if(l2 > (*ln2)) {*ln2 = l2; bSuccess = -2;}
				if(!bSuccess)
				{	memcpy(computerName, ptstrUserName, l1 * sizeof(wchar_t));
					memcpy(userName, p+1, l2 * sizeof(wchar_t));
					computerName[l1] = 0;
					bSuccess = 1;
		}	}	}
	    LocalFree(ptstrUserName);
	}

	return bSuccess;
}


int Logon()
{
/*PRIVILEGE_SET ps;ps.Control=PRIVILEGE_SET_ALL_NECESSARY;
BOOL b = PrivilegeCheck(HANDLE ClientToken,
						PPRIVILEGE_SET RequiredPrivileges,
						LPBOOL pfResult);*/

 wchar_t computerName[128],userName[128];int l1=128,l2=128,err;
 int ib = GetAppUserName(computerName,userName,&l1,&l2);
 HANDLE h;	
 BOOL b = LogonUser(userName,computerName,L"1968129",LOGON32_LOGON_NEW_CREDENTIALS,LOGON32_PROVIDER_WINNT50,&h);//LOGON32_LOGON_NETWORK, LOGON32_PROVIDER_DEFAULT,//LOGON32_LOGON_SERVICE,LOGON32_PROVIDER_DEFAULT,
 if(!b)
	 err = GetLastError();//1327 - ERROR_ACCOUNT_RESTRICTION, admin paroli pustoy
 else
 {	ImpersonateLoggedOnUser(h);
	//RevertToSelf();
 }
 return 0;
}

/*HRESULT ModifyPrivilege(
    IN LPCTSTR szPrivilege,
    IN BOOL fEnable)
{
    HRESULT hr = S_OK;
    TOKEN_PRIVILEGES NewState;
    LUID             luid;
    HANDLE hToken    = NULL;

    // Open the process token for this process.
    if (!OpenProcessToken(GetCurrentProcess(),
                          TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY,
                          &hToken ))
    {
        printf("Failed OpenProcessToken\n");
        return ERROR_FUNCTION_FAILED;
    }

    // Get the local unique ID for the privilege.
    if ( !LookupPrivilegeValue( NULL,
                                szPrivilege,
                                &luid ))
    {
        CloseHandle( hToken );
        printf("Failed LookupPrivilegeValue\n");
        return ERROR_FUNCTION_FAILED;
    }

    // Assign values to the TOKEN_PRIVILEGE structure.
    NewState.PrivilegeCount = 1;
    NewState.Privileges[0].Luid = luid;
    NewState.Privileges[0].Attributes = 
              (fEnable ? SE_PRIVILEGE_ENABLED : 0);

    // Adjust the token privilege.
    if (!AdjustTokenPrivileges(hToken,
                               FALSE,
                               &NewState,
                               0,
                               NULL,
                               NULL))
    {
        printf("Failed AdjustTokenPrivileges\n");
        hr = ERROR_FUNCTION_FAILED;
    }

    // Close the handle.
    CloseHandle(hToken);

    return hr;
}*/