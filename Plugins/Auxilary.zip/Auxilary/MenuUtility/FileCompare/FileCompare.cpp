#include "windows.h"
#include "resource.h"
#include "strsafe.h"
#include "shlobj.h"
#include "ShiftedFile.h"
#include "..\..\..\..\Operations\MyShell\MyShell.h"


#define CHRB  4
#define CHRWB 10
#define CHRW  12
#define CHRH  16



extern "C"
{
extern wchar_t **strngs;
extern HMODULE plgnDllInst;
}

INT_PTR CALLBACK CmprDlgProc(HWND,UINT,WPARAM,LPARAM);
INT_PTR CALLBACK Cmpr2FilesDlgProc(HWND,UINT,WPARAM,LPARAM);
BOOL CmprFiles(HWND hDlg,wchar_t*,wchar_t*);
BOOL CheckStopBtnMsg(HWND);
BOOL Resize(HWND,int,int);
BOOL Draw(HWND);
BOOL DrawBinary(HWND);
BOOL DrawUnicode(HWND);

typedef BOOL (CALLBACK *saveOptions_t)(int,VOID*,int);
typedef BOOL (CALLBACK *readOptions_t)(int,VOID*,int);
typedef int  (CALLBACK *getTotPanels_t)();
typedef int  (CALLBACK *getCrntPanelNum_t)();
typedef wchar_t* (CALLBACK *getPanelPath_t)(int);
typedef LPVOID (CALLBACK *getPanelCrntItem_t)(int,WIN32_FIND_DATAW*);
typedef LPVOID (CALLBACK *getPanelSelectedItems_t)(int,int*);
typedef unsigned __int64* (CALLBACK *getLogicalDriveSpace_t)(int);


saveOptions_t saveOptions=0;
readOptions_t readOptions=0;
getTotPanels_t getTotPanels=0;
getCrntPanelNum_t getCrntPanelNum=0;
getPanelCrntItem_t getPanelCrntItem=0;
getPanelSelectedItems_t getPanelSelectedItems=0;
getPanelPath_t getPanelPath=0;
getLogicalDriveSpace_t getLogicalDriveSpace=0;

BOOL bStop=FALSE;
HBRUSH whteBrsh;
HFONT fnt=0;
RECT rcSrc,rcSrcAddr;//src va dest, srcAddr, destAddr rect i;
WIN32_FIND_DATA pFindFileData[2];
HWND hSrc,hDest,hSrcAddr,hDestAddr;
WORD scrlPos=0;//O'rtadagi vert scroll posi,0 dan 65535 gachon;
unsigned __int64 fCrntOffst;//tepadan 1-qator offseti,faylning to'liq shkaladagi posi, mapdagi fMapOffst ga ekvivalent;
__int64 totLines=0,iTotScrlLines=0;//map qilingan ozudan boshlab scroll liniyasi, iHorChars ga k'opaytirsak, charlarni beradir;
int plgId = 0,iHorChars,iVerChars;//Tepadaginign o'zi, faqat charlarda;
int widthSrc,heightSrc;//hSrc va hDest ning pixellardagi eni va balandligi;
SftdFile fSrc(65535);
SftdFile fDst(65535);

//configurations:
BOOL bHexAddrMode=FALSE,bASCII=TRUE,bUnicode=FALSE;
int iCodePage=0,iFlagForMultibyte=0;

extern "C"
{
__declspec (dllexport) VOID SetCallbacks$4xxx(LPVOID frstCallback,...)
{
va_list args;
	va_start(args, frstCallback);//1
	saveOptions = (saveOptions_t)frstCallback;//1
	readOptions = (readOptions_t)va_arg(args, LPVOID);//2
	getTotPanels = (getTotPanels_t)va_arg(args, LPVOID);//3
	getCrntPanelNum = (getCrntPanelNum_t)va_arg(args, LPVOID);//4
	getPanelCrntItem = (getPanelCrntItem_t)va_arg(args, LPVOID);//5
	getPanelSelectedItems = (getPanelSelectedItems_t)va_arg(args, LPVOID);//6
	getPanelPath = (getPanelPath_t)va_arg(args, LPVOID);//7
	getLogicalDriveSpace = (getLogicalDriveSpace_t)va_arg(args, LPVOID);//8
va_end (args);
}

__declspec (dllexport) BOOL Run$4(HWND prnt)
{
int ttlPnl,crntPnl;
	if(!getCrntPanelNum) return FALSE;
	if(!getTotPanels)return FALSE;
	ttlPnl=getTotPanels();
	crntPnl=getCrntPanelNum();
	if(ttlPnl<2) return FALSE;
	if(crntPnl<0) return FALSE;
	if(crntPnl>ttlPnl-1) return FALSE;
	if(!getPanelCrntItem) return FALSE;
	if(1==DialogBox(plgnDllInst,MAKEINTRESOURCE(IDD_DIALOG_COMPARE),prnt,CmprDlgProc))
		DialogBox(plgnDllInst,MAKEINTRESOURCE(IDD_DIALOG_CMP_TWO_FILES),prnt,Cmpr2FilesDlgProc);
	return TRUE;
}

__declspec (dllexport) int GetPluginType()
{
	return 102;
}

__declspec (dllexport) const wchar_t* GetPluginName()
{
	return strngs[1];
}

__declspec (dllexport) int GetMenuNum()
{
	return 0;
}

__declspec (dllexport) int GetMenuPos()
{
	return 4;
}

__declspec (dllexport) const wchar_t* GetMenuItemText()
{
	return strngs[0];
}

__declspec (dllexport) const wchar_t* GetMenuText()
{
	return strngs[0];
}

__declspec (dllexport) VOID SetId$4(int id)
{
	plgId = id;
}

__declspec (dllexport) const wchar_t* GetPluginDescription()
{
	return strngs[1];
}

__declspec (dllexport) VOID ShowOptionDialog(HWND prnt)
{
}
}

BOOL IsCrntOrPrntDirAttrbW(wchar_t* fd)
{//see Naming Conventions in MSDN:
	if('.'==fd[0])
	{	if('\0'==fd[1])//"."
			return FALSE;
		if('.'==fd[1])
			if('\0'==fd[2])//".."
				return FALSE;
	}
	return TRUE;//Hozircha;
}

unsigned __int64 MyAtoU64(wchar_t *s)
{
unsigned __int64 rt=0;
wchar_t *ps = s;
	while(*ps!=0)
	{	if(*ps < '0')
			return 0;
		if(*ps > '9')
			return 0;
		rt = rt*10 + (*ps - '0');
		ps++;
	}
	return rt;
}

BOOL MyU64ToA(wchar_t* st,int sLen,unsigned __int64 u)
{
int i,l=0;
unsigned __int64 delit = u;
static wchar_t s[32];
	if(!u)
	{	st[0] = '0';
		st[1] = 0;
		return TRUE;
	}

	while(delit)
	{	s[l++] = delit % 10 + '0';
		delit /= 10;
	}
	for(i=0; i<l; i++)
		st[i] = s[l-i-1];
	st[l] = 0;
	return TRUE;
}

VOID MyInt64ToString(char *s,int max,unsigned __int64 n)
{
int i;
unsigned __int64 N=n;
char *ps = s+max; *ps=0;
	for(i=0; i<max; i++)
	{	--ps;
		*ps = N % 10 + '0';
		N /= 10;
}	}

VOID MyInt64ToHexString(char *s,int max,unsigned __int64 n)
{
int i;
unsigned __int64 N=n;
char *ps = s+max; *ps=0;
	for(i=0; i<max; i++)
	{	--ps;
		char k = N % 16;
		if(k<10)
			*ps = k + '0';
		else
			*ps = 'A' + (k - 10);
		N /= 16;
}	}

INT_PTR CALLBACK CmprDlgProc(HWND hDlg,UINT message,WPARAM wParam,LPARAM lParam)
{	//static int i=0;
	//char ss[32];sprintf(ss,"\n %d ",i++);
	//OutputDebugString(ss);
	//OutputDebugString(GetWinNotifyText(message));
	//sprintf(ss," %x %x",wParam,lParam);
	//OutputDebugString(ss);

static HFONT hf=0;
//static int hfRef=0;//obshiy hf, dinamik uchun emas:
static HBRUSH br=0;
//static LPVOID panel;
static HBRUSH brHtBk=0;
static int endDialogCodeToWM_DESTROY;
static int szQntSlct=0;
wchar_t s[MAX_PATH];
int left,top,width,height;
//LPDRAWITEMSTRUCT lpdis;
OPENFILENAME ofn;
LOGFONT fnt;
RECT rc,rc1;
//UINT uStyle;
HDC dc;

	switch(message)
	{	case WM_INITDIALOG:
			GetWindowRect(hDlg, &rc1);
			HWND prnt;prnt = GetParent(hDlg);if(!prnt)prnt=GetDesktopWindow();
			GetWindowRect(prnt, &rc);
			width = rc1.right - rc1.left;		
			left = rc.left + (rc.right - rc.left - width)/2;//left = (GetSystemMetrics(SM_CXFULLSCREEN) - width)/2;
			height = rc1.bottom - rc1.top;
			top = rc.top + (rc.bottom - rc.top - height)/2;//top = (GetSystemMetrics(SM_CYFULLSCREEN) - height)/2;
			MoveWindow(hDlg, left, top+20, width, height, TRUE);

			//Load language strings:
			SetWindowText(hDlg,strngs[0]);
			SetDlgItemText(hDlg,IDC_STATIC5,strngs[1]);
			SetDlgItemText(hDlg,IDC_STATIC1,strngs[2]);
			SetDlgItemText(hDlg,IDOK,strngs[10]);
			SetDlgItemText(hDlg,IDCANCEL,strngs[9]);
			SetDlgItemText(hDlg,IDC_BUTTON_BROWSE,strngs[3]);
			SetDlgItemText(hDlg,IDC_BUTTON_BROWSE2,strngs[3]);

			left=getCrntPanelNum();
			top=getTotPanels();
			width=left<top-1?left+1:(left>0?left-1:left);
			getPanelCrntItem(left,&pFindFileData[0]);
			SetDlgItemText(hDlg,IDC_EDIT_SRC,pFindFileData[0].cFileName);
			getPanelCrntItem(width,&pFindFileData[1]);
			SetDlgItemText(hDlg,IDC_EDIT_DEST,pFindFileData[1].cFileName);
			SetTimer(hDlg,0,500,NULL);
			if(top>0 && top<5)
			{	for(width=0; width<top; width++)
				{	if(left!=width)
					{	StringCchPrintf(s,MAX_PATH-1,L"%d-panel",width+1);
						SendMessage(GetDlgItem(hDlg,IDC_COMBO_DEST_PANEL),CB_INSERTSTRING,(WPARAM)-1,(LPARAM)s);
			}	}	}
			SendMessage(hDlg,WM_USER+1,0,0);
			break;
		case WM_TIMER:
			KillTimer(hDlg,0);
			CmprFiles(hDlg,pFindFileData[0].cFileName,pFindFileData[1].cFileName);
			break;
		case WM_CTLCOLORSTATIC:
		case WM_CTLCOLORDLG:dc = (HDC)wParam;
			SetTextColor(dc,RGB(0xea,0xe0,0xff));//SetTextColor(dc,RGB(0x8a,0,0));
			SetBkColor(dc,RGB(0x40,0x21,0x17));//SetBkColor(dc,RGB(0xc0,0x81,0x97));
			return (INT_PTR)br;
		case WM_CTLCOLOREDIT:dc = (HDC)wParam;
			SetTextColor(dc,RGB(0xea,0xe0,0xff));//SetTextColor(dc,RGB(0x8a,0,0));
			SetBkColor(dc,RGB(0x40,0x21,0x17));//SetBkColor(dc,RGB(0xc0,0x81,0x97));
			return (INT_PTR)br;
		case WM_CTLCOLORBTN:dc=(HDC)wParam;
			SetTextColor(dc,RGB(0xd0,0xe0,0xff));
			SetBkColor(dc,RGB(0x64,0x79,0x65));
			return (INT_PTR)brHtBk;
/*		case WM_DRAWITEM://WM_CTLCOLORBTN dagi knopkalar:
			lpdis = (LPDRAWITEMSTRUCT)lParam;
			GetWindowText(lpdis->hwndItem,s,MAX_PATH);
			uStyle = DFCS_BUTTONPUSH;
			rc = lpdis->rcItem;
			if(lpdis->itemState & ODS_SELECTED)
			{	uStyle |= DFCS_PUSHED|DFCS_TRANSPARENT;
				rc.left+=2;rc.top+=2;
			}
			DrawFrameControl(lpdis->hDC, &lpdis->rcItem, DFC_BUTTON, uStyle);
			if(lpdis->itemState & ODS_SELECTED)
				{rc.left+=1;rc.top+=1;rc.bottom-=2;rc.right-=3;}
			else
				{rc.left+=1;rc.top+=2;rc.bottom-=3;rc.right-=3;}
			FillRect(lpdis->hDC,&rc,brHtBk);//DrawText(lpdis->hDC,"",50,&rc,DT_SINGLELINE|DT_VCENTER|DT_INTERNAL|DT_LEFT);
			if(lpdis->itemState & ODS_SELECTED)
				{rc.left-=1;rc.top-=1;rc.bottom+=3;rc.right+=3;}
			else
				{rc.left-=1;rc.top-=2;rc.bottom+=2;rc.right+=3;}
			DrawText(lpdis->hDC,s,MyStringLength(s,MAX_PATH),&rc,DT_SINGLELINE|DT_VCENTER|DT_CENTER);
			return TRUE;*/
		case WM_USER+1://hf obshiy uchun, dinamik o'zgartirish uchun emas:
			//if(0==hfRef)
			{	InitLOGFONT(&fnt);
				hf = CreateFontIndirect(&fnt);
				br = CreateSolidBrush(RGB(0x40,0x21,0x17));//0xc9,0x81,0x93));
				brHtBk = CreateSolidBrush(RGB(0x64,0x79,0x65));
			}
			SendMessage(GetDlgItem(hDlg,IDC_BUTTON_BROWSE),WM_SETFONT,(WPARAM)hf,TRUE);
			SendMessage(GetDlgItem(hDlg,IDC_BUTTON_BROWSE2),WM_SETFONT,(WPARAM)hf,TRUE);
			SendMessage(GetDlgItem(hDlg,IDSTOP),WM_SETFONT,(WPARAM)hf,TRUE);
			SendMessage(GetDlgItem(hDlg,IDCANCEL),WM_SETFONT,(WPARAM)hf,TRUE);
			SendMessage(GetDlgItem(hDlg,IDOK),WM_SETFONT,(WPARAM)hf,TRUE);
			SendMessage(GetDlgItem(hDlg,IDCANCEL),WM_SETFONT,(WPARAM)hf,TRUE);
			SendMessage(GetDlgItem(hDlg,IDC_STATIC5),WM_SETFONT,(WPARAM)hf,TRUE);
			SendMessage(GetDlgItem(hDlg,IDC_STATIC1),WM_SETFONT,(WPARAM)hf,TRUE);
    		SendMessage(GetDlgItem(hDlg,IDC_COMBO_DEST_PANEL),WM_SETFONT,(WPARAM)hf,TRUE);			

			SendMessage(GetDlgItem(hDlg,IDC_EDIT_SRC),WM_SETFONT,(WPARAM)hf,TRUE);
			SendMessage(GetDlgItem(hDlg,IDC_EDIT_DEST),WM_SETFONT,(WPARAM)hf,TRUE);
			//++hfRef;
			return 0;//GWL_USERDATA
		case WM_DESTROY:
			//if(--hfRef<1)
			{	DeleteObject(hf);
				DeleteObject(br);
				DeleteObject(brHtBk);
			}
			return 0;
		case WM_COMMAND:
			switch(LOWORD(wParam))
			{	case IDC_BUTTON_BROWSE://dest
					ZeroMemory(&ofn, sizeof(ofn));
					pFindFileData[1].cFileName[0] = '\0';
					ofn.lStructSize = sizeof(ofn);
					ofn.hwndOwner = NULL; 
					ofn.lpstrFile = pFindFileData[1].cFileName; 
					ofn.nMaxFile = MAX_PATH;
					ofn.lpstrFilter = NULL;
					ofn.nFilterIndex = 1;
					ofn.lpstrTitle = strngs[8];
					ofn.lpstrInitialDir = NULL;
					ofn.lpstrCustomFilter = NULL;
					ofn.nMaxCustFilter = 0;
					ofn.lpstrFileTitle = strngs[4];
					ofn.nMaxFileTitle = 0;
					ofn.nFileOffset = 0;
					ofn.nFileExtension = 0;
					ofn.lpstrDefExt = NULL;
					ofn.lCustData = 0;
					ofn.lpfnHook = 0;
					ofn.lpTemplateName = 0;
					ofn.Flags = OFN_PATHMUSTEXIST | OFN_FILEMUSTEXIST | OFN_HIDEREADONLY |OFN_EXTENSIONDIFFERENT;
					MyStringCpy(s,MAX_PATH-1,pFindFileData[1].cFileName);						
					if(GetOpenFileName(&ofn))
					{	if(wcscmp(s,pFindFileData[1].cFileName))
						{	if(CmprFiles(hDlg,pFindFileData[0].cFileName,pFindFileData[1].cFileName))
								SetDlgItemText(hDlg,IDC_EDIT_SRC,pFindFileData[1].cFileName);
					}	}
	   				return (INT_PTR)TRUE;
				case IDC_BUTTON_BROWSE2://src
					ZeroMemory(&ofn, sizeof(ofn));
					pFindFileData[0].cFileName[0] = '\0';
					ofn.lStructSize = sizeof(ofn);
					ofn.hwndOwner = NULL; 
					ofn.lpstrFile = pFindFileData[0].cFileName; 
					ofn.nMaxFile = MAX_PATH;
					ofn.lpstrFilter = NULL;
					ofn.nFilterIndex = 1;
					ofn.lpstrTitle = strngs[7];
					ofn.lpstrInitialDir = NULL;
					ofn.lpstrCustomFilter = NULL;
					ofn.nMaxCustFilter = 0;
					ofn.lpstrFileTitle = strngs[4];
					ofn.nMaxFileTitle = 0;
					ofn.nFileOffset = 0;
					ofn.nFileExtension = 0;
					ofn.lpstrDefExt = NULL;
					ofn.lCustData = 0;
					ofn.lpfnHook = 0;
					ofn.lpTemplateName = 0;
					ofn.Flags = OFN_PATHMUSTEXIST | OFN_FILEMUSTEXIST | OFN_HIDEREADONLY |OFN_EXTENSIONDIFFERENT;
					MyStringCpy(s,MAX_PATH-1,pFindFileData[0].cFileName);
					if(GetOpenFileName(&ofn))
					{	if(wcscmp(s,pFindFileData[0].cFileName))
						{	if(CmprFiles(hDlg,pFindFileData[0].cFileName,pFindFileData[1].cFileName))
								SetDlgItemText(hDlg,IDC_EDIT_SRC,pFindFileData[0].cFileName);
					}	}
					return (INT_PTR)TRUE;
				case IDOK:
					EndDialog(hDlg, 1);
					return (INT_PTR)TRUE;
				case IDCANCEL:
					EndDialog(hDlg, 0);
					return (INT_PTR)TRUE;
				case IDSTOP:
					bStop = !bStop;
					SetDlgItemText(hDlg,IDSTOP,bStop?strngs[8]:strngs[15]);
					break;
				case IDC_EDIT_SRC:
					if(EN_KILLFOCUS==HIWORD(wParam))
					{	MyStringCpy(s,MAX_PATH-1,pFindFileData[0].cFileName);
						GetDlgItemText(hDlg,IDC_EDIT_SRC,pFindFileData[0].cFileName,MAX_PATH-1);
						if(wcscmp(s,pFindFileData[0].cFileName))
						{	if(!CmprFiles(hDlg,pFindFileData[0].cFileName,pFindFileData[1].cFileName))
							{	MessageBox(hDlg,pFindFileData[0].cFileName,strngs[18],MB_ICONWARNING);
								SendMessage(hDlg,WM_COMMAND,MAKELONG(IDC_BUTTON_BROWSE2,BN_CLICKED),(LPARAM)GetDlgItem(hDlg,IDC_BUTTON_BROWSE2));
					}	}	}
					break;
				case IDC_EDIT_DEST:
					if(EN_KILLFOCUS==HIWORD(wParam))
					{	MyStringCpy(s,MAX_PATH-1,pFindFileData[1].cFileName);
						GetDlgItemText(hDlg,IDC_EDIT_SRC,pFindFileData[1].cFileName,MAX_PATH-1);
						if(wcscmp(s,pFindFileData[1].cFileName))
						{	if(!CmprFiles(hDlg,pFindFileData[0].cFileName,pFindFileData[1].cFileName))
							{	MessageBox(hDlg,pFindFileData[1].cFileName,strngs[18],MB_ICONWARNING);
								SendMessage(hDlg,WM_COMMAND,MAKELONG(IDC_BUTTON_BROWSE2,BN_CLICKED),(LPARAM)GetDlgItem(hDlg,IDC_BUTTON_BROWSE2));
					}	}	}
					break;
				case IDC_COMBO_DEST_PANEL:
					if(CBN_SELCHANGE==HIWORD(wParam))
					{	int l=(int)SendMessage(GetDlgItem(hDlg,IDC_COMBO_DEST_PANEL),CB_GETCURSEL,0,0);
						MyStringCpy(s,MAX_PATH-1,pFindFileData[1].cFileName);
						getPanelCrntItem(l,&pFindFileData[1]);
						if(wcscmp(s,pFindFileData[1].cFileName))
						{	if(CmprFiles(hDlg,pFindFileData[0].cFileName,pFindFileData[1].cFileName))
								SetDlgItemText(hDlg,IDC_EDIT_DEST,pFindFileData[1].cFileName);
					}	}
					break;
			}
			break;
	}
	return (INT_PTR)FALSE;
}

BOOL CheckStopBtnMsg(HWND dlg)
{
MSG msg;
	while(PeekMessage(&msg,dlg,0,0,PM_REMOVE))
		DispatchMessage(&msg);	
	return bStop;
}

//#define BUFSZ 32768
#define BUFSZ 65535
BOOL CmprFiles(HWND hDlg,wchar_t *frstFilePathAndName,wchar_t *scndFilePathAndName)
{
BOOL r=TRUE;
HANDLE f[2];
DWORD rd[2];
BY_HANDLE_FILE_INFORMATION fi[2];
DWORD *pdw[2];
wchar_t buf0[BUFSZ],buf1[BUFSZ],*pch[2];
unsigned __int64 sz,cmsz=0;
int i,dw,ch;

	SetDlgItemText(hDlg,IDC_EDIT_INFO,L"....");

	f[0]=CreateFile(frstFilePathAndName,GENERIC_READ,FILE_SHARE_READ,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_READONLY,NULL);
	if(INVALID_HANDLE_VALUE==f[0])
	{	SetDlgItemText(hDlg,IDC_EDIT_INFO,strngs[5]);
		EnableWindow(GetDlgItem(hDlg,IDOK),TRUE);
		return FALSE;
	}
	f[1]=CreateFile(scndFilePathAndName,GENERIC_READ,FILE_SHARE_READ,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_READONLY,NULL);
	if(INVALID_HANDLE_VALUE==f[1])
	{	CloseHandle(f[0]);
		SetDlgItemText(hDlg,IDC_EDIT_INFO,strngs[6]);
		EnableWindow(GetDlgItem(hDlg,IDOK),TRUE);
		return FALSE;
	}
	if(!GetFileInformationByHandle(f[0],&fi[0])) {r=FALSE;goto End;}
	if(!GetFileInformationByHandle(f[1],&fi[1])) {r=FALSE;goto End;}
	if(fi[0].nFileSizeHigh!=fi[1].nFileSizeHigh) {r=FALSE;goto End;}
	if(fi[0].nFileSizeLow!=fi[1].nFileSizeLow)   {r=FALSE;goto End;}
	sz = ((unsigned __int64)fi[0].nFileSizeHigh<<32) | fi[0].nFileSizeLow;
	sz /= 4;
	do
	{	if(ReadFile(f[0],buf0,BUFSZ,&rd[0],NULL) != ReadFile(f[1],buf1,BUFSZ,&rd[1],NULL) )
		   {r=FALSE;goto End;}
		if(rd[0]!=rd[1]) {r=FALSE;goto End;}
		dw=rd[0]/4; ch=rd[0]%4;
		pdw[0]=(DWORD*)buf0; pdw[1]=(DWORD*)buf1;
		for(i=0; i<dw; i++)
		{	if((*pdw[0]) != (*pdw[1])) {r=FALSE;goto End;}
			++pdw[0]; ++pdw[1];
		}
		cmsz += dw;
		PostMessage(GetDlgItem(hDlg,IDC_PROGRESS_COMPARE),PBM_SETPOS,(int)(100.0f*cmsz/sz),0);
		if(CheckStopBtnMsg(hDlg)) {r=FALSE;goto End;}
		pch[0]=(wchar_t*)pdw[0]; pch[1]=(wchar_t*)pdw[1];
		for(i=0; i<ch; i++)
		{	if((*pch[0]) != (*pch[1])) {r=FALSE;goto End;}
			++pch[0]; ++pch[1];
		}
	} while(rd[0] && rd[0]==rd[1]);
End:
	CloseHandle(f[0]);CloseHandle(f[1]);
	SetDlgItemText(hDlg,IDC_EDIT_INFO,r?strngs[11]:strngs[12]);
	EnableWindow(GetDlgItem(hDlg,IDOK),!r);
	return r;
}

BOOL Resize(HWND dlg,int x,int y)
{
//x-=2;y-=2;
int addrBarWidth;
RECT rc;GetClientRect(dlg,&rc);
x=rc.right-rc.left;y=rc.bottom-rc.top;
	if(!x) return FALSE; if(!y) return FALSE;
	if(x<7) x=7;if(y<20)y=20;
	//addrBarWidth=(int)(0.65*CHRW*(fSrc.()>fDst.GetSizeDecWidth()?fSrc.GetSizeDecWidth():fDst.GetSizeDecWidth()));
	addrBarWidth=(int)(0.9f*CHRW*(fSrc.GetSizeDecWidth()>fDst.GetSizeDecWidth()?fSrc.GetSizeDecWidth():fDst.GetSizeDecWidth()));

	MoveWindow(GetDlgItem(dlg,IDC_VERT_SCROLLBAR),x/2-7,0,18,y,TRUE);
	MoveWindow(GetDlgItem(dlg,IDC_EDIT_SRC_NAME),0,0,(int)(0.5*x-7),20,TRUE);
	MoveWindow(GetDlgItem(dlg,IDC_EDIT_DEST_NAME),(int)(0.5*x+10),0,(int)(0.5*x-7),20,TRUE);	
	
	MoveWindow(hSrcAddr,0,20,addrBarWidth,y-20,TRUE);	
	MoveWindow(hDestAddr,(int)(x-addrBarWidth),20,addrBarWidth,y-20,TRUE);
	MoveWindow(hSrc,addrBarWidth,20,(int)(0.5*x-addrBarWidth-6),y-20,TRUE);
	MoveWindow(hDest,(int)(0.5*x+9),20,(int)(0.5*x-addrBarWidth-6),y-20,TRUE);

	GetClientRect(hSrcAddr,&rcSrcAddr);
	GetClientRect(hSrc,&rcSrc);
	widthSrc=rcSrc.right-rcSrc.left;
	heightSrc=rcSrc.bottom-rcSrc.top;

	iHorChars = widthSrc / CHRW;
	iVerChars = heightSrc / CHRH -1;
	if(heightSrc % CHRH > 0) ++iVerChars;
	if(iHorChars<1)iHorChars=1;

	if(fSrc.GetSize()>fDst.GetSize())
	{	totLines = fSrc.GetSize() / iHorChars;
		if(fSrc.GetSize() % iHorChars > 0)
			++totLines;
		totLines -= iVerChars;
		scrlPos=(WORD)(65535*fCrntOffst/fSrc.GetSize());
		SendMessage(GetDlgItem(dlg,IDC_VERT_SCROLLBAR),(UINT)SBM_SETPOS,scrlPos,FALSE);		
	}
	else //if(sz[0]>sz[1])
	{	totLines = fDst.GetSize() / iHorChars;
		if(fDst.GetSize() % iHorChars > 0)
			++totLines;
		totLines -= iVerChars;
		scrlPos=(WORD)(65535*fCrntOffst/fDst.GetSize());
		SendMessage(GetDlgItem(dlg,IDC_VERT_SCROLLBAR),(UINT)SBM_SETPOS,scrlPos,FALSE);		
	}
	return TRUE;
}

INT_PTR CALLBACK SmplChldDlgProc(HWND hDlg,UINT message,WPARAM wParam,LPARAM lParam)
{	switch(message){case WM_PAINT: return 0;}
	return DefWindowProc(hDlg,message,wParam,lParam);
}

BOOL Scroll(HWND hDlg,int type,WORD lParam)//,BOOL bToPrev)//else to next (it means down);
{
__int64 oldLines=iTotScrlLines;

	switch(type)
	{	case 0://ushlab tortgan,lParam ishladur;
			if(lParam>scrlPos)
			{	if(65535==lParam)iTotScrlLines=totLines;
				else iTotScrlLines += (lParam-scrlPos)*totLines/65535;
			}
			else if(lParam<scrlPos)
			{	if(0==lParam)iTotScrlLines=0;
				else iTotScrlLines -= (scrlPos-lParam)*totLines/65535;
			}
			break;
		case 1: --iTotScrlLines; break;//tepaga 1 ta;
		case 2:	++iTotScrlLines; break;//pastga 1 ta
		case 3://tepag 1 bet;
			if(iVerChars<1) break;
			iTotScrlLines-=iVerChars-1;
			break;
		case 4://pastga 1 bet;
			if(iVerChars<1) break;
			iTotScrlLines+=iVerChars-1;
			//else break;
			break;
	}//div_t div_result = div(totLines*scrlPos,65535);
	if(iTotScrlLines<0)iTotScrlLines=0;
	else if(iTotScrlLines>totLines)iTotScrlLines=totLines;
	if(iTotScrlLines==oldLines)	return FALSE;

	//scrlPos ning o'zini ham korrektirovka qilib qo'yamiz:
	scrlPos = (WORD)(65535*((double)iTotScrlLines/totLines));

	fCrntOffst = (unsigned __int64)iTotScrlLines*iHorChars;
	if(fCrntOffst>(fSrc.GetSize()>fDst.GetSize()?fSrc.GetSize():fDst.GetSize()))
		fCrntOffst = fSrc.GetSize()>fDst.GetSize()?fSrc.GetSize():fDst.GetSize();
	Draw(hDlg);
	return TRUE;
}

INT_PTR CALLBACK Cmpr2FilesDlgProc(HWND hDlg,UINT message,WPARAM wParam,LPARAM lParam)
{
int  left,top,width,height;
RECT  rc,rc1;HMENU hm;
MENUITEMINFO mi;
HWND prnt;WNDCLASSEX wcex;LOGFONT lf;
	//static int i=0;
	//wchar_t ss[32];sprintf(ss,"\n %d ",i++);
	//OutputDebugString(ss);
	//OutputDebugString(GetWinNotifyText(message));
	//sprintf(ss," %x %x",wParam,lParam);
	//OutputDebugString(ss);
	switch(message)
	{	case WM_INITDIALOG:
			GetWindowRect(hDlg, &rc1);
			prnt = GetParent(hDlg);
			if(!prnt)prnt=GetDesktopWindow();
			GetWindowRect(prnt, &rc);
			width = rc1.right - rc1.left;		
			left = rc.left + (rc.right - rc.left - width)/2;//left = (GetSystemMetrics(SM_CXFULLSCREEN) - width)/2;
			height = rc1.bottom - rc1.top;
			top = rc.top + (rc.bottom - rc.top - height)/2;//top = (GetSystemMetrics(SM_CYFULLSCREEN) - height)/2;
			MoveWindow(hDlg, left, top+20, width, height, TRUE);
			//Load language strings:
			SetWindowText(hDlg,strngs[0]);
			hm = GetMenu(hDlg);
			if(!hm) return FALSE;
			mi.cbSize = sizeof(MENUITEMINFO);
			mi.fMask=MIIM_STRING; mi.fType=MFT_STRING;
			mi.dwTypeData = strngs[22];SetMenuItemInfo(hm,0,TRUE,&mi);
			mi.dwTypeData = strngs[15];SetMenuItemInfo(hm,ID_ADDRESSMODE_HEX,FALSE,&mi);
			mi.dwTypeData = strngs[16];SetMenuItemInfo(hm,ID_ADDRESSMODE_DEC,FALSE,&mi);
			mi.dwTypeData = strngs[23];SetMenuItemInfo(hm,1,TRUE,&mi);
			mi.dwTypeData = strngs[17];SetMenuItemInfo(hm,ID_EDITMODE_BINARY,FALSE,&mi);
			mi.dwTypeData = strngs[18];SetMenuItemInfo(hm,2,TRUE,&mi);
			mi.dwTypeData = strngs[19];SetMenuItemInfo(hm,ID_ASCII_ANSI8,FALSE,&mi);

			CheckMenuItem(GetMenu(hDlg),ID_ADDRESSMODE_HEX,(bHexAddrMode?MF_CHECKED:MF_UNCHECKED)|MF_BYCOMMAND);
			CheckMenuItem(GetMenu(hDlg),ID_ADDRESSMODE_DEC,(bHexAddrMode?MF_UNCHECKED:MF_CHECKED)|MF_BYCOMMAND);
			CheckMenuItem(GetMenu(hDlg),ID_EDITMODE_ASCII,(bASCII?MF_CHECKED:MF_UNCHECKED)|MF_BYCOMMAND);
			CheckMenuItem(GetMenu(hDlg),ID_EDITMODE_BINARY,(bASCII?MF_UNCHECKED:MF_CHECKED)|MF_BYCOMMAND);
			CheckMenuItem(GetMenu(hDlg),ID_ASCII_ANSI8,(bUnicode?MF_UNCHECKED:MF_CHECKED)|MF_BYCOMMAND);
			CheckMenuItem(GetMenu(hDlg),ID_CHARACTERCODES_UNICODE,(bUnicode?MF_CHECKED:MF_UNCHECKED)|MF_BYCOMMAND);

			CheckMenuItem(GetMenu(hDlg),ID_CODEPAGES_ACP+iCodePage,MF_CHECKED|MF_BYCOMMAND);
			CheckMenuItem(GetMenu(hDlg),ID_MB_PRECOMPOSED+iFlagForMultibyte,MF_CHECKED|MF_BYCOMMAND);

			InitLOGFONT(&lf);
			fnt=CreateFontIndirect(&lf);
			whteBrsh=CreateSolidBrush(RGB(255,255,255));

			SendMessage(GetDlgItem(hDlg,IDC_EDIT_SRC_NAME),WM_SETFONT,(WPARAM)fnt,0);
			SendMessage(GetDlgItem(hDlg,IDC_EDIT_DEST_NAME),WM_SETFONT,(WPARAM)fnt,0);
			SetDlgItemText(hDlg,IDC_EDIT_SRC_NAME,pFindFileData[0].cFileName);
			SetDlgItemText(hDlg,IDC_EDIT_DEST_NAME,pFindFileData[1].cFileName);
			SetScrollRange(GetDlgItem(hDlg,IDC_VERT_SCROLLBAR),SB_CTL,0,65535,TRUE);//sz[0]>sz[1]?(sz[0]/32):(sz[1]/32)

			wcex.cbSize = sizeof(WNDCLASSEX);
			wcex.style			= CS_HREDRAW|CS_VREDRAW|CS_OWNDC;
			wcex.lpfnWndProc	= (WNDPROC)SmplChldDlgProc;
			wcex.cbClsExtra		= 0;
			wcex.cbWndExtra		= 0;//sizeof(HANDLE);
			wcex.hInstance		= plgnDllInst;
			wcex.hIcon			= NULL;
			wcex.hCursor		= LoadCursor(NULL, IDC_ARROW);
			wcex.hbrBackground	= whteBrsh;//(HBRUSH)GetStockObject(WHITE_BRUSH);
			wcex.lpszMenuName	= NULL;
			wcex.lpszClassName	= L"Source file compare window class";
			wcex.hIconSm		= NULL;
			RegisterClassEx(&wcex);
			hSrcAddr = CreateWindowEx(WS_EX_CLIENTEDGE,
							L"Source file compare window class",
							L"Source file compare window",
							WS_VISIBLE|WS_CHILD,
							0,
							20,
							54,
							402,
							hDlg,
							NULL,
							plgnDllInst,
							(LPVOID)1);
			if(NULL==hSrcAddr) {/*msg(0,strngs[]);*/EndDialog(hDlg,0);return FALSE;}
			hSrc = CreateWindowEx(WS_EX_CLIENTEDGE,
							L"Source file compare window class",
							L"Source file compare window",
							WS_VISIBLE|WS_CHILD,
							54,
							20,
							325,
							402,
							hDlg,
							NULL,
							plgnDllInst,
							(LPVOID)2);
			if(NULL==hSrc) {/*msg(0,strngs[]);*/EndDialog(hDlg,0);return FALSE;}
			hDest = CreateWindowEx(WS_EX_CLIENTEDGE,
							L"Source file compare window class",
							L"Source file compare window",
							WS_VISIBLE|WS_CHILD,
							398,
							20,
							325,
							402,
							hDlg,
							NULL,
							plgnDllInst,
							(LPVOID)3);
			if(NULL==hDest) {/*msg(0,strngs[]);*/EndDialog(hDlg,0);return FALSE;}
			hDestAddr = CreateWindowEx(WS_EX_CLIENTEDGE,
							L"Source file compare window class",
							L"Source file compare window",
							WS_VISIBLE|WS_CHILD,
							724,
							20,
							54,
							402,
							hDlg,
							NULL,
							plgnDllInst,
							(LPVOID)3);
			if(NULL==hDestAddr) {/*msg(0,strngs[]);*/EndDialog(hDlg,0);return FALSE;}
			SetFocus(hSrc);
			fSrc.Open(pFindFileData[0].cFileName);
			fDst.Open(pFindFileData[1].cFileName);
			Resize(hDlg,width,height);
			Draw(hDlg);
			break;
		case WM_SIZE:
			Resize(hDlg,LOWORD(lParam),HIWORD(lParam));
			break;
		case WM_PAINT:
			//hdc = BeginPaint(hwnd, &ps); 
			Draw(hDlg);
            //EndPaint(hwnd, &ps); 
			break;
		case WM_MOUSEWHEEL:
			//if(MK_MBUTTON==LOWORD(wParam))
			SendMessage(hDlg,WM_VSCROLL,GET_WHEEL_DELTA_WPARAM(wParam)<0?SB_PAGERIGHT:SB_PAGELEFT,0);
			break;
		/*case WM_KEYDOWN:  focus avtomaticheski scrollga o'tib olarkan o'zi;
			switch(wParam)
			{	case VK_DOWN:
					if(Scroll(hDlg,1,0))
						SendMessage(GetDlgItem(hDlg,IDC_VERT_SCROLLBAR),(UINT)SBM_SETPOS,scrlPos,FALSE);
					break;
				case VK_UP:
					if(Scroll(hDlg,2,0))
						SendMessage(GetDlgItem(hDlg,IDC_VERT_SCROLLBAR),(UINT)SBM_SETPOS,scrlPos,FALSE);
					break;
				case VK_PRIOR:
					if(Scroll(hDlg,3,0))
						SendMessage(GetDlgItem(hDlg,IDC_VERT_SCROLLBAR),(UINT)SBM_SETPOS,scrlPos,FALSE);
					break;
				case VK_NEXT:
					if(Scroll(hDlg,4,0))
						SendMessage(GetDlgItem(hDlg,IDC_VERT_SCROLLBAR),(UINT)SBM_SETPOS,scrlPos,FALSE);
					break;
			}
			break;*/
		case WM_VSCROLL:
			if(SB_THUMBPOSITION==LOWORD(wParam) ||SB_THUMBTRACK==LOWORD(wParam))
			{	if(Scroll(hDlg,0,HIWORD(wParam)))//,oldScrlPos>scrlPos);
					SendMessage(GetDlgItem(hDlg,IDC_VERT_SCROLLBAR),(UINT)SBM_SETPOS,scrlPos,FALSE);
			}
			else
			{	BOOL r=FALSE;
				if(SB_LINELEFT==LOWORD(wParam))
					r=Scroll(hDlg,1,0);
				else if(SB_LINERIGHT==LOWORD(wParam))
					r=Scroll(hDlg,2,0);
				else if(SB_PAGELEFT==LOWORD(wParam))
					r=Scroll(hDlg,3,0);
				else if(SB_PAGERIGHT==LOWORD(wParam))
					r=Scroll(hDlg,4,0);
				if(r)SendMessage(GetDlgItem(hDlg,IDC_VERT_SCROLLBAR),(UINT)SBM_SETPOS,scrlPos,TRUE);
			}
			break;
		case WM_COMMAND:
			switch(LOWORD(wParam))
			{	case IDCANCEL:
					EndDialog(hDlg, 0);
					return (INT_PTR)TRUE;
				case ID_ADDRESSMODE_HEX:
					bHexAddrMode = TRUE;
					CheckMenuItem(GetMenu(hDlg),ID_ADDRESSMODE_HEX,(bHexAddrMode?MF_CHECKED:MF_UNCHECKED)|MF_BYCOMMAND);
					CheckMenuItem(GetMenu(hDlg),ID_ADDRESSMODE_DEC,(bHexAddrMode?MF_UNCHECKED:MF_CHECKED)|MF_BYCOMMAND);
					Draw(hDlg);
					return (INT_PTR)TRUE;
				case ID_ADDRESSMODE_DEC:
					bHexAddrMode = FALSE;
					CheckMenuItem(GetMenu(hDlg),ID_ADDRESSMODE_HEX,(bHexAddrMode?MF_CHECKED:MF_UNCHECKED)|MF_BYCOMMAND);
					CheckMenuItem(GetMenu(hDlg),ID_ADDRESSMODE_DEC,(bHexAddrMode?MF_UNCHECKED:MF_CHECKED)|MF_BYCOMMAND);
					Draw(hDlg);
					return (INT_PTR)TRUE;
				case ID_EDITMODE_ASCII:
					bASCII = TRUE;
					CheckMenuItem(GetMenu(hDlg),ID_EDITMODE_ASCII,(bASCII?MF_CHECKED:MF_UNCHECKED)|MF_BYCOMMAND);
					CheckMenuItem(GetMenu(hDlg),ID_EDITMODE_BINARY,(bASCII?MF_UNCHECKED:MF_CHECKED)|MF_BYCOMMAND);
					Draw(hDlg);
					return (INT_PTR)TRUE;
				case ID_EDITMODE_BINARY:
					bASCII = FALSE;
					CheckMenuItem(GetMenu(hDlg),ID_EDITMODE_ASCII,(bASCII?MF_CHECKED:MF_UNCHECKED)|MF_BYCOMMAND);
					CheckMenuItem(GetMenu(hDlg),ID_EDITMODE_BINARY,(bASCII?MF_UNCHECKED:MF_CHECKED)|MF_BYCOMMAND);
					Draw(hDlg);
					return (INT_PTR)TRUE;
				case ID_ASCII_ANSI8:
					if(!bASCII)
					{	MessageBox(hDlg,L"ASCII (not binary) mode",L"Please,Shift to",MB_OK);
						return (INT_PTR)TRUE;
					}
					bUnicode = FALSE;
					CheckMenuItem(GetMenu(hDlg),ID_ASCII_ANSI8,(bUnicode?MF_UNCHECKED:MF_CHECKED)|MF_BYCOMMAND);
					CheckMenuItem(GetMenu(hDlg),ID_CHARACTERCODES_UNICODE,(bUnicode?MF_CHECKED:MF_UNCHECKED)|MF_BYCOMMAND);
					Draw(hDlg);
					return (INT_PTR)TRUE;
				case ID_CHARACTERCODES_UNICODE:
					if(!bASCII)
					{	MessageBox(hDlg,L"ASCII (not binary) mode",L"Please,Shift to",MB_OK);
						return (INT_PTR)TRUE;
					}
					bUnicode = TRUE;
					CheckMenuItem(GetMenu(hDlg),ID_ASCII_ANSI8,(bUnicode?MF_UNCHECKED:MF_CHECKED)|MF_BYCOMMAND);
					CheckMenuItem(GetMenu(hDlg),ID_CHARACTERCODES_UNICODE,(bUnicode?MF_CHECKED:MF_UNCHECKED)|MF_BYCOMMAND);
					Draw(hDlg);
					return (INT_PTR)TRUE;
				case ID_MB_PRECOMPOSED://oxirgi sum menu
					if(!bASCII)
					{	MessageBox(hDlg,L"ASCII (not binary) mode",L"Please,Shift to",MB_OK);
						return (INT_PTR)TRUE;
					}
					if(!bUnicode)
					{	MessageBox(hDlg,L"Unicode mode",L"Please,Shift to",MB_OK);
						return (INT_PTR)TRUE;
					}
					iFlagForMultibyte = 0;
					CheckMenuItem(GetMenu(hDlg),ID_MB_PRECOMPOSED,MF_CHECKED|MF_BYCOMMAND);
					CheckMenuItem(GetMenu(hDlg),ID_MB_COMPOSITE,MF_UNCHECKED|MF_BYCOMMAND);
					CheckMenuItem(GetMenu(hDlg),ID_MB_ERR_INVALID_CHARS,MF_UNCHECKED|MF_BYCOMMAND);
					CheckMenuItem(GetMenu(hDlg),ID_MB_USEGLYPHCHARS,MF_UNCHECKED|MF_BYCOMMAND);
					CheckMenuItem(GetMenu(hDlg),ID_MB_0,MF_UNCHECKED|MF_BYCOMMAND);
					return (INT_PTR)TRUE;
				case ID_MB_COMPOSITE:
					if(!bASCII)
					{	MessageBox(hDlg,L"ASCII (not binary) mode",L"Please,Shift to",MB_OK);
						return (INT_PTR)TRUE;
					}
					if(!bUnicode)
					{	MessageBox(hDlg,L"Unicode mode",L"Please,Shift to",MB_OK);
						return (INT_PTR)TRUE;
					}
					iFlagForMultibyte = 1;
					CheckMenuItem(GetMenu(hDlg),ID_MB_PRECOMPOSED,MF_UNCHECKED|MF_BYCOMMAND);
					CheckMenuItem(GetMenu(hDlg),ID_MB_COMPOSITE,MF_CHECKED|MF_BYCOMMAND);
					CheckMenuItem(GetMenu(hDlg),ID_MB_ERR_INVALID_CHARS,MF_UNCHECKED|MF_BYCOMMAND);
					CheckMenuItem(GetMenu(hDlg),ID_MB_USEGLYPHCHARS,MF_UNCHECKED|MF_BYCOMMAND);
					CheckMenuItem(GetMenu(hDlg),ID_MB_0,MF_UNCHECKED|MF_BYCOMMAND);
					return (INT_PTR)TRUE;
				case ID_MB_ERR_INVALID_CHARS:
					if(!bASCII)
					{	MessageBox(hDlg,L"ASCII (not binary) mode",L"Please,Shift to",MB_OK);
						return (INT_PTR)TRUE;
					}
					if(!bUnicode)
					{	MessageBox(hDlg,L"Unicode mode",L"Please,Shift to",MB_OK);
						return (INT_PTR)TRUE;
					}
					iFlagForMultibyte = 2;
					CheckMenuItem(GetMenu(hDlg),ID_MB_PRECOMPOSED,MF_UNCHECKED|MF_BYCOMMAND);
					CheckMenuItem(GetMenu(hDlg),ID_MB_COMPOSITE,MF_UNCHECKED|MF_BYCOMMAND);
					CheckMenuItem(GetMenu(hDlg),ID_MB_ERR_INVALID_CHARS,MF_CHECKED|MF_BYCOMMAND);
					CheckMenuItem(GetMenu(hDlg),ID_MB_USEGLYPHCHARS,MF_UNCHECKED|MF_BYCOMMAND);
					CheckMenuItem(GetMenu(hDlg),ID_MB_0,MF_UNCHECKED|MF_BYCOMMAND);
					return (INT_PTR)TRUE;
				case ID_MB_USEGLYPHCHARS:
					if(!bASCII)
					{	MessageBox(hDlg,L"ASCII (not binary) mode",L"Please,Shift to",MB_OK);
						return (INT_PTR)TRUE;
					}
					if(!bUnicode)
					{	MessageBox(hDlg,L"Unicode mode",L"Please,Shift to",MB_OK);
						return (INT_PTR)TRUE;
					}
					iFlagForMultibyte = 3;
					CheckMenuItem(GetMenu(hDlg),ID_MB_PRECOMPOSED,MF_UNCHECKED|MF_BYCOMMAND);
					CheckMenuItem(GetMenu(hDlg),ID_MB_COMPOSITE,MF_UNCHECKED|MF_BYCOMMAND);
					CheckMenuItem(GetMenu(hDlg),ID_MB_ERR_INVALID_CHARS,MF_UNCHECKED|MF_BYCOMMAND);
					CheckMenuItem(GetMenu(hDlg),ID_MB_USEGLYPHCHARS,MF_CHECKED|MF_BYCOMMAND);
					CheckMenuItem(GetMenu(hDlg),ID_MB_0,MF_UNCHECKED|MF_BYCOMMAND);
					return (INT_PTR)TRUE;
				case ID_MB_0:
					if(!bASCII)
					{	MessageBox(hDlg,L"ASCII (not binary) mode",L"Please,Shift to",MB_OK);
						return (INT_PTR)TRUE;
					}
					if(!bUnicode)
					{	MessageBox(hDlg,L"Unicode mode",L"Please,Shift to",MB_OK);
						return (INT_PTR)TRUE;
					}
					iFlagForMultibyte = 4;
					CheckMenuItem(GetMenu(hDlg),ID_MB_PRECOMPOSED,MF_UNCHECKED|MF_BYCOMMAND);
					CheckMenuItem(GetMenu(hDlg),ID_MB_COMPOSITE,MF_UNCHECKED|MF_BYCOMMAND);
					CheckMenuItem(GetMenu(hDlg),ID_MB_ERR_INVALID_CHARS,MF_UNCHECKED|MF_BYCOMMAND);
					CheckMenuItem(GetMenu(hDlg),ID_MB_USEGLYPHCHARS,MF_UNCHECKED|MF_BYCOMMAND);
					CheckMenuItem(GetMenu(hDlg),ID_MB_0,MF_CHECKED|MF_BYCOMMAND);
					return (INT_PTR)TRUE;
			}
			if(LOWORD(wParam)>=ID_CODEPAGES_ACP && LOWORD(wParam)<=ID_CODEPAGES_65001)
			{	if(!bASCII)
				{	MessageBox(hDlg,L"ASCII (not binary) mode",L"Please,Shift to",MB_OK);
					return (INT_PTR)TRUE;
				}
				if(!bUnicode)
				{	MessageBox(hDlg,L"Unicode mode",L"Please,Shift to",MB_OK);
					return (INT_PTR)TRUE;
				}
				CheckMenuItem(GetMenu(hDlg),ID_CODEPAGES_ACP+iCodePage,MF_UNCHECKED|MF_BYCOMMAND);
				iCodePage = LOWORD(wParam)-ID_CODEPAGES_ACP;
				CheckMenuItem(GetMenu(hDlg),ID_CODEPAGES_ACP+iCodePage,MF_CHECKED|MF_BYCOMMAND);
				return (INT_PTR)TRUE;
			}
			break;
		case WM_DESTROY:
			if(fnt)DeleteObject(fnt);
			if(whteBrsh)DeleteObject(whteBrsh);
			fnt=0;whteBrsh=0;
			fSrc.Close();
			fDst.Close();
			break;
	}
	return (INT_PTR)FALSE;
}

VOID ConvertToBin(unsigned char* dest,unsigned char* src,int ln)
{
	for(int i=0; i<ln; i++)
	{	*dest = (*src) / 16;
		if((*dest) < 10)
			*dest += '0';
		else
			*dest = ((*dest)-10) + 'A';
		++dest;
		*dest = (*src) % 16;
		if((*dest) < 10)
			*dest += '0';
		else
			*dest = ((*dest)-10) + 'A';
		++dest;
		*dest = ' ';
		++dest;++src;
	}
	*(dest-1) = 0;
}

CONST INT spcb[256]={CHRWB,CHRWB,CHRB,CHRWB,CHRWB,CHRB,CHRWB,CHRWB,CHRB,CHRWB,CHRWB,CHRB,CHRWB,CHRWB,CHRB,CHRWB,CHRWB,CHRB,CHRWB,CHRWB,CHRB,CHRWB,CHRWB,CHRB,CHRWB,CHRWB,CHRB,CHRWB,CHRWB,CHRB,CHRWB,CHRWB,CHRB,CHRWB,CHRWB,CHRB,CHRWB,CHRWB,CHRB,CHRWB,CHRWB,CHRB,CHRWB,CHRWB,CHRB,CHRWB,CHRWB,CHRB,CHRWB,CHRWB,CHRB,CHRWB,CHRWB,CHRB,CHRWB,CHRWB,CHRB,CHRWB,CHRWB,CHRB,CHRWB,CHRWB,CHRB,CHRWB,CHRWB,CHRB,CHRWB,CHRWB,CHRB,CHRWB,CHRWB,CHRB,CHRWB,CHRWB,CHRB,CHRWB,CHRWB,CHRB,CHRWB,CHRWB,CHRB,CHRWB,CHRWB,CHRB,CHRWB,CHRWB,CHRB,CHRWB,CHRWB,CHRB,CHRWB,CHRWB,CHRB,CHRWB,CHRWB,CHRB,CHRWB,CHRWB,CHRB,CHRWB,CHRWB,CHRB,CHRWB,CHRWB,CHRB,CHRWB,CHRWB,CHRB,CHRWB,CHRWB,CHRB,CHRWB,CHRWB,CHRB,CHRWB,CHRWB,CHRB,CHRWB,CHRWB,CHRB,CHRWB,CHRWB,CHRB,CHRWB,CHRWB,CHRB,CHRWB,CHRWB,CHRB,CHRWB,CHRWB,CHRB,CHRWB,CHRWB,CHRB,CHRWB,CHRWB,CHRB,CHRWB,CHRWB,CHRB,CHRWB,CHRWB,CHRB,CHRWB,CHRWB,CHRB,CHRWB,CHRWB,CHRB,CHRWB,CHRWB,CHRB,CHRWB,CHRWB,CHRB,CHRWB,CHRWB,CHRB,CHRWB,CHRWB,CHRB,CHRWB,CHRWB,CHRB,CHRWB,CHRWB,CHRB,CHRWB,CHRWB,CHRB,CHRWB,CHRWB,CHRB,CHRWB,CHRWB,CHRB,CHRWB,CHRWB,CHRB,CHRWB,CHRWB,CHRB,CHRWB,CHRWB,CHRB,CHRWB,CHRWB,CHRB,CHRWB,CHRWB,CHRB,CHRWB,CHRWB,CHRB,CHRWB,CHRWB,CHRB,CHRWB,CHRWB,CHRB,CHRWB,CHRWB,CHRB,CHRWB,CHRWB,CHRB,CHRWB,CHRWB,CHRB,CHRWB,CHRWB,CHRB,CHRWB,CHRWB,CHRB,CHRWB,CHRWB,CHRB,CHRWB,CHRWB,CHRB,CHRWB,CHRWB,CHRB,CHRWB,CHRWB,CHRB,CHRWB,CHRWB,CHRB,CHRWB,CHRWB,CHRB,CHRWB,CHRWB,CHRB,CHRWB,CHRWB,CHRB,CHRB,CHRWB,CHRWB,CHRB,CHRB,CHRWB,CHRWB,CHRB,CHRB,CHRWB,CHRWB,CHRB,CHRB,CHRWB,CHRWB,CHRB};
BOOL DrawBinary(HWND dlg)
{
char s[32];int i,k;
unsigned __int64 FCrntOffst=fCrntOffst;//tepadan 1-qator offseti,faylning to'liq shkaladagi posi, mapdagi fMapOffst ga ekvivalent;
BOOL r=FALSE;
HDC dcSrc=GetDC(hSrc);
HDC dcDest=GetDC(hDest);
HDC	dcSrcAddr=GetDC(hSrcAddr);
HDC dcDestAddr=GetDC(hDestAddr);
HGDIOBJ oldSrcAddrFnt,oldSrcFnt,oldDestFnt,oldDestAddrFnt;

RECT rSrcAddr = rcSrcAddr;
RECT rSrc = rcSrc;

int iHorCharsB=(int)(0.52f*iHorChars);

	if((!dcSrc) || (!dcDest) || (!dcSrcAddr) || (!dcDestAddr)) return FALSE;
	oldSrcAddrFnt=SelectObject(dcSrcAddr,fnt);
	oldSrcFnt=SelectObject(dcSrc,fnt);
	oldDestFnt=SelectObject(dcDest,fnt);
	oldDestAddrFnt=SelectObject(dcDestAddr,fnt);
	//SetBkColor(dcSrcAddr,RGB(235,235,255));SetBkColor(dcSrc,RGB(245,245,255));SetBkColor(dcDest,RGB(245,235,255));SetBkColor(dcDestAddr,RGB(245,245,255));

	FillRect(dcSrc,&rSrc,whteBrsh);FillRect(dcDest,&rSrc,whteBrsh);
	FillRect(dcSrcAddr ,&rSrcAddr,whteBrsh);FillRect(dcDestAddr ,&rSrcAddr,whteBrsh);
	rSrcAddr.top = 0; rSrcAddr.bottom = 25; rSrcAddr.left = 0;//(LONG)(0.136f*widthSrc)-szDecPosLn[0]*CHRH+64;
	rSrc.left=0;rSrc.right=0;rSrc.top=0;rSrc.bottom=CHRH;//GetClientRect(hSrc,&rSrc);

	SetTextColor(dcSrcAddr,RGB(0,0,155));SetTextColor(dcDestAddr,RGB(0,0,155));
//	SetTextColor(dcSrc,RGB(0,0,0));	SetTextColor(dcDest,RGB(0,0,0));
	SetTextColor(dcSrc,RGB(0,0,0));
	SetTextColor(dcDest,RGB(0,0,0));

	int SZWD=(fSrc.GetSizeDecWidth()>fDst.GetSizeDecWidth() ? fSrc.GetSizeDecWidth() : fDst.GetSizeDecWidth());

	//2-la siyam bor bo'lgan zona:
	unsigned char *p[2],ph0[128],ph1[128],*pCh[2];int ln[2];
	for(i=0; i<iVerChars; i++)
	{	ln[0]=fSrc.Read(&FCrntOffst,iHorCharsB,(void**)&p[0]);
		ln[1]=fDst.Read(&FCrntOffst,iHorCharsB,(void**)&p[1]);
		if(ln[0]<=0 || ln[1]<=0) break;
		pCh[0]=&ph0[0];pCh[1]=&ph1[0];
		ConvertToBin(pCh[0],p[0],ln[0]);
		ConvertToBin(pCh[1],p[1],ln[1]);

		if(bHexAddrMode)
			MyInt64ToHexString(s,SZWD,FCrntOffst);//StringCchPrintf(s,15,fSrc.GetOffsetStrFormat(),FCrntOffst);
		else
			MyInt64ToString(s,SZWD,FCrntOffst);
		if(ln[0])ExtTextOutA(dcSrcAddr,rSrcAddr.left,rSrcAddr.top,ETO_OPAQUE,NULL,s,SZWD,NULL);
		if(ln[1])ExtTextOutA(dcDestAddr,rSrcAddr.left,rSrcAddr.top,ETO_OPAQUE,NULL,s,SZWD,NULL);
		rSrcAddr.top += CHRH; rSrcAddr.bottom += CHRH;
		
		rSrc.left = 0; rSrc.right = 2*CHRW+CHRB;
		int c=0;
		for(k=0; k<iHorCharsB; k++)
		{	BOOL bEqu=FALSE;int iLocEqu=1;
			if(ln[0]==ln[1])
			{	bEqu=((*p[0]) == (*p[1]));
				while(bEqu ? (p[0][iLocEqu]==p[1][iLocEqu]) : (p[0][iLocEqu]!=p[1][iLocEqu]))
				{	if(rSrc.right+2*CHRWB+CHRB > widthSrc-1) break;
					if(iLocEqu>iHorCharsB-1)break;
					++k;++iLocEqu;
					rSrc.right += 2*CHRWB+CHRB;
			}	}
			if(!bEqu){SetTextColor(dcSrc,RGB(255,0,0));SetTextColor(dcDest,RGB(255,0,0));}
			if(ln[0]>=k)
				ExtTextOutA(dcSrc,rSrc.left,rSrc.top,ETO_OPAQUE,&rSrc,(LPCSTR)pCh[0],iLocEqu*3-1,spcb);
			if(ln[1]>=k)
				ExtTextOutA(dcDest,rSrc.left,rSrc.top,ETO_OPAQUE,&rSrc,(LPCSTR)pCh[1],iLocEqu*3-1,spcb);
			if(!bEqu){SetTextColor(dcSrc,RGB(0,0,0));SetTextColor(dcDest,RGB(0,0,0));}
			p[0]+=iLocEqu;p[1]+=iLocEqu;
			c+=iLocEqu;
			rSrc.left = c*(2*CHRWB+CHRB);rSrc.right = rSrc.left + (2*CHRWB+CHRB);
			pCh[0]+=iLocEqu*3; pCh[1]+=iLocEqu*3; FCrntOffst+=iLocEqu;
		}
		rSrc.top += CHRH; rSrc.bottom+= CHRH;
		if((iHorCharsB!=ln[0]) || (iHorCharsB!=ln[1])) break;
	}
	SetTextColor(dcSrc,RGB(255,0,0));SetTextColor(dcDest,RGB(255,0,0));
	rSrc.left = 0; rSrc.right = CHRW*iHorChars;

	if(fSrc.GetSize()>fDst.GetSize())
	{	pCh[0]=&ph0[0];
		for(k=i; k<iVerChars; k++)
		{	ln[0]=fSrc.Read(&FCrntOffst,iHorCharsB,(void**)&p[0]);
			if(!ln[0]) break;
			ConvertToBin(pCh[0],p[0],ln[0]);
			if(bHexAddrMode)
				MyInt64ToHexString(s,SZWD,FCrntOffst);//StringCchPrintf(s,15,fSrc.GetOffsetStrFormat(),FCrntOffst);
			else
				MyInt64ToString(s,SZWD,FCrntOffst);
			ExtTextOutA(dcSrcAddr,rSrcAddr.left,rSrcAddr.top,ETO_OPAQUE,NULL,s,SZWD,NULL);
			ConvertToBin(pCh[0],p[0],ln[0]);
			ExtTextOutA(dcSrc,rSrc.left,rSrc.top,ETO_OPAQUE,&rSrc,(LPCSTR)pCh[0],ln[0]*3-1,spcb);
			rSrcAddr.top += CHRH; rSrcAddr.bottom += CHRH;
			rSrc.top += CHRH; rSrc.bottom+= CHRH;
			FCrntOffst += iHorCharsB;
	}	}
	else
	{	pCh[1]=&ph1[0];
		for(k=i; k<iVerChars; k++)
		{	ln[1]=fDst.Read(&FCrntOffst,iHorCharsB,(void**)&p[1]);
			if(!ln[1]) break;
			if(bHexAddrMode)
				MyInt64ToHexString(s,SZWD,FCrntOffst);//StringCchPrintf(s,15,fSrc.GetOffsetStrFormat(),FCrntOffst);
			else
				MyInt64ToString(s,SZWD,FCrntOffst);
			ExtTextOutA(dcDestAddr,rSrcAddr.left,rSrcAddr.top,ETO_OPAQUE,NULL,s,SZWD,NULL);
			ConvertToBin(pCh[1],p[1],ln[1]);
			ExtTextOutA(dcDest,rSrc.left,rSrc.top,ETO_OPAQUE,&rSrc,(LPCSTR)pCh[1],ln[1]*3-1,spcb);
			rSrcAddr.top += CHRH; rSrcAddr.bottom += CHRH;
			rSrc.top += CHRH; rSrc.bottom+= CHRH;
			FCrntOffst += iHorCharsB;
	}	}

	RedrawWindow(hSrcAddr,NULL,NULL,RDW_NOINTERNALPAINT|RDW_VALIDATE);
	RedrawWindow(hSrc,NULL,NULL,RDW_NOINTERNALPAINT|RDW_VALIDATE);
	RedrawWindow(hDest,NULL,NULL,RDW_NOINTERNALPAINT|RDW_VALIDATE);
	RedrawWindow(hDestAddr,NULL,NULL,RDW_NOINTERNALPAINT|RDW_VALIDATE);
	SelectObject(dcSrcAddr,oldSrcAddrFnt);
	SelectObject(dcSrc,oldSrcFnt);
	SelectObject(dcDest,oldDestFnt);
	SelectObject(dcDestAddr,oldDestAddrFnt);
	if(dcSrcAddr)ReleaseDC(hSrcAddr,dcSrcAddr);
	if(dcSrc)ReleaseDC(hSrc,dcSrc);
	if(dcDest)ReleaseDC(hDest,dcDest);
	if(dcDestAddr)ReleaseDC(hDestAddr,dcDestAddr);
	return r;
}

CONST INT spc[128]={CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW};
BOOL Draw(HWND dlg)
{
char s[32];int i,k;
unsigned __int64 FCrntOffst=fCrntOffst;//tepadan 1-qator offseti,faylning to'liq shkaladagi posi, mapdagi fMapOffst ga ekvivalent;
BOOL r=FALSE;
HDC dcSrc=GetDC(hSrc);
HDC dcDest=GetDC(hDest);
HDC	dcSrcAddr=GetDC(hSrcAddr);
HDC dcDestAddr=GetDC(hDestAddr);
HGDIOBJ oldSrcAddrFnt,oldSrcFnt,oldDestFnt,oldDestAddrFnt;

	if(!bASCII) return DrawBinary(dlg);
	if(bUnicode) return DrawUnicode(dlg);

RECT rSrcAddr = rcSrcAddr;
RECT rSrc = rcSrc;

	if((!dcSrc) || (!dcDest) || (!dcSrcAddr) || (!dcDestAddr)) return FALSE;
	oldSrcAddrFnt=SelectObject(dcSrcAddr,fnt);
	oldSrcFnt=SelectObject(dcSrc,fnt);
	oldDestFnt=SelectObject(dcDest,fnt);
	oldDestAddrFnt=SelectObject(dcDestAddr,fnt);
	//SetBkColor(dcSrcAddr,RGB(235,235,255));SetBkColor(dcSrc,RGB(245,245,255));SetBkColor(dcDest,RGB(245,235,255));SetBkColor(dcDestAddr,RGB(245,245,255));

	FillRect(dcSrc,&rSrc,whteBrsh);FillRect(dcDest,&rSrc,whteBrsh);
	FillRect(dcSrcAddr ,&rSrcAddr,whteBrsh);FillRect(dcDestAddr ,&rSrcAddr,whteBrsh);
	rSrcAddr.top = 0; rSrcAddr.bottom = 25; rSrcAddr.left = 0;//(LONG)(0.136f*widthSrc)-szDecPosLn[0]*CHRH+64;
	rSrc.left=0;rSrc.right=0;rSrc.top=0;rSrc.bottom=CHRH;//GetClientRect(hSrc,&rSrc);

	SetTextColor(dcSrcAddr,RGB(0,0,155));SetTextColor(dcDestAddr,RGB(0,0,155));
//	SetTextColor(dcSrc,RGB(0,0,0));	SetTextColor(dcDest,RGB(0,0,0));
	SetTextColor(dcSrc,RGB(0,0,0));
	SetTextColor(dcDest,RGB(0,0,0));

	int SZWD=(fSrc.GetSizeDecWidth()>fDst.GetSizeDecWidth() ? fSrc.GetSizeDecWidth() : fDst.GetSizeDecWidth());

	//2-la siyam bor bo'lgan zona:
	unsigned char *pCh[2];int ln[2];
	for(i=0; i<iVerChars; i++)
	{	ln[0]=fSrc.Read(&FCrntOffst,iHorChars,(void**)&pCh[0]);
		ln[1]=fDst.Read(&FCrntOffst,iHorChars,(void**)&pCh[1]);
		if(ln[0]<=0 || ln[1]<=0) break;

		if(bHexAddrMode)
			MyInt64ToHexString(s,SZWD,FCrntOffst);//StringCchPrintf(s,15,fSrc.GetOffsetStrFormat(),FCrntOffst);
		else
			MyInt64ToString(s,SZWD,FCrntOffst);
		if(ln[0])ExtTextOutA(dcSrcAddr,rSrcAddr.left,rSrcAddr.top,ETO_OPAQUE,NULL,s,SZWD,NULL);
		if(ln[1])ExtTextOutA(dcDestAddr,rSrcAddr.left,rSrcAddr.top,ETO_OPAQUE,NULL,s,SZWD,NULL);
		rSrcAddr.top += CHRH; rSrcAddr.bottom += CHRH;
		
		rSrc.left = 0; rSrc.right = CHRW;
		for(k=0; k<iHorChars; k++)
		{	BOOL bEqu=FALSE;int iLocEqu=1;
			if(ln[0]==ln[1])
			{	bEqu=((*pCh[0]) == (*pCh[1]));
				while(bEqu ? (pCh[0][iLocEqu]==pCh[1][iLocEqu]) : (pCh[0][iLocEqu]!=pCh[1][iLocEqu]))
				{	if(rSrc.right+CHRW > widthSrc-1) break;
					++k;++iLocEqu;
					rSrc.right += CHRW;
			}	}
			if(!bEqu){SetTextColor(dcSrc,RGB(255,0,0));SetTextColor(dcDest,RGB(255,0,0));}
			if(ln[0]>k)
				ExtTextOutA(dcSrc ,rSrc.left,rSrc.top,ETO_OPAQUE,&rSrc,(LPCSTR)pCh[0],iLocEqu,spc);
			if(ln[1]>k)
				ExtTextOutA(dcDest,rSrc.left,rSrc.top,ETO_OPAQUE,&rSrc,(LPCSTR)pCh[1],iLocEqu,spc);
			if(!bEqu){SetTextColor(dcSrc,RGB(0,0,0));SetTextColor(dcDest,RGB(0,0,0));}
			rSrc.left += CHRW*iLocEqu; rSrc.right+= CHRW*iLocEqu;
			pCh[0]+=iLocEqu; pCh[1]+=iLocEqu; FCrntOffst+=iLocEqu;
		}
		rSrc.top += CHRH; rSrc.bottom+= CHRH;
		if((iHorChars!=ln[0]) || (iHorChars!=ln[1])) break;
	}
	SetTextColor(dcSrc,RGB(255,0,0));SetTextColor(dcDest,RGB(255,0,0));
	rSrc.left = 0; rSrc.right = CHRW*iHorChars;

	if(fSrc.GetSize()>fDst.GetSize())
	{	for(k=i; k<iVerChars; k++)
		{	ln[0]=fSrc.Read(&FCrntOffst,iHorChars,(void**)&pCh[0]);
			if(!ln[0]) break;
			if(bHexAddrMode)
				MyInt64ToHexString(s,SZWD,FCrntOffst);//StringCchPrintf(s,15,fSrc.GetOffsetStrFormat(),FCrntOffst);
			else
				MyInt64ToString(s,SZWD,FCrntOffst);
			ExtTextOutA(dcSrcAddr,rSrcAddr.left,rSrcAddr.top,ETO_OPAQUE,NULL,s,SZWD,NULL);
			ExtTextOutA(dcSrc,rSrc.left,rSrc.top,ETO_OPAQUE,&rSrc,(LPCSTR)pCh[0],ln[0],spc);
			rSrcAddr.top += CHRH; rSrcAddr.bottom += CHRH;
			rSrc.top += CHRH; rSrc.bottom+= CHRH;
			FCrntOffst += iHorChars;
	}	}
	else
	{	for(k=i; k<iVerChars; k++)
		{	ln[1]=fDst.Read(&FCrntOffst,iHorChars,(void**)&pCh[1]);
			if(!ln[1]) break;
			if(bHexAddrMode)
				MyInt64ToHexString(s,SZWD,FCrntOffst);//StringCchPrintf(s,15,fSrc.GetOffsetStrFormat(),FCrntOffst);
			else
				MyInt64ToString(s,SZWD,FCrntOffst);
			ExtTextOutA(dcDestAddr,rSrcAddr.left,rSrcAddr.top,ETO_OPAQUE,NULL,s,SZWD,NULL);
			ExtTextOutA(dcDest,rSrc.left,rSrc.top,ETO_OPAQUE,&rSrc,(LPCSTR)pCh[1],ln[1],spc);
			rSrcAddr.top += CHRH; rSrcAddr.bottom += CHRH;
			rSrc.top += CHRH; rSrc.bottom+= CHRH;
			FCrntOffst += iHorChars;
	}	}

	RedrawWindow(hSrcAddr,NULL,NULL,RDW_NOINTERNALPAINT|RDW_VALIDATE);
	RedrawWindow(hSrc,NULL,NULL,RDW_NOINTERNALPAINT|RDW_VALIDATE);
	RedrawWindow(hDest,NULL,NULL,RDW_NOINTERNALPAINT|RDW_VALIDATE);
	RedrawWindow(hDestAddr,NULL,NULL,RDW_NOINTERNALPAINT|RDW_VALIDATE);
	SelectObject(dcSrcAddr,oldSrcAddrFnt);
	SelectObject(dcSrc,oldSrcFnt);
	SelectObject(dcDest,oldDestFnt);
	SelectObject(dcDestAddr,oldDestAddrFnt);
	if(dcSrcAddr)ReleaseDC(hSrcAddr,dcSrcAddr);
	if(dcSrc)ReleaseDC(hSrc,dcSrc);
	if(dcDest)ReleaseDC(hDest,dcDest);
	if(dcDestAddr)ReleaseDC(hDestAddr,dcDestAddr);
	return r;
}

BOOL DrawUnicode(HWND dlg)
{
char s[32];int i,k;
unsigned __int64 FCrntOffst=fCrntOffst;//tepadan 1-qator offseti,faylning to'liq shkaladagi posi, mapdagi fMapOffst ga ekvivalent;
BOOL r=FALSE;
HDC dcSrc=GetDC(hSrc);
HDC dcDest=GetDC(hDest);
HDC	dcSrcAddr=GetDC(hSrcAddr);
HDC dcDestAddr=GetDC(hDestAddr);
HGDIOBJ oldSrcAddrFnt,oldSrcFnt,oldDestFnt,oldDestAddrFnt;

RECT rSrcAddr = rcSrcAddr;
RECT rSrc = rcSrc;

	if((!dcSrc) || (!dcDest) || (!dcSrcAddr) || (!dcDestAddr)) return FALSE;
	oldSrcAddrFnt=SelectObject(dcSrcAddr,fnt);
	oldSrcFnt=SelectObject(dcSrc,fnt);
	oldDestFnt=SelectObject(dcDest,fnt);
	oldDestAddrFnt=SelectObject(dcDestAddr,fnt);
	//SetBkColor(dcSrcAddr,RGB(235,235,255));SetBkColor(dcSrc,RGB(245,245,255));SetBkColor(dcDest,RGB(245,235,255));SetBkColor(dcDestAddr,RGB(245,245,255));

	FillRect(dcSrc,&rSrc,whteBrsh);FillRect(dcDest,&rSrc,whteBrsh);
	FillRect(dcSrcAddr ,&rSrcAddr,whteBrsh);FillRect(dcDestAddr ,&rSrcAddr,whteBrsh);
	rSrcAddr.top = 0; rSrcAddr.bottom = 25; rSrcAddr.left = 0;//(LONG)(0.136f*widthSrc)-szDecPosLn[0]*CHRH+64;
	rSrc.left=0;rSrc.right=0;rSrc.top=0;rSrc.bottom=CHRH;//GetClientRect(hSrc,&rSrc);

	SetTextColor(dcSrcAddr,RGB(0,0,155));SetTextColor(dcDestAddr,RGB(0,0,155));
//	SetTextColor(dcSrc,RGB(0,0,0));	SetTextColor(dcDest,RGB(0,0,0));
	SetTextColor(dcSrc,RGB(0,0,0));
	SetTextColor(dcDest,RGB(0,0,0));

	int SZWD=(fSrc.GetSizeDecWidth()>fDst.GetSizeDecWidth() ? fSrc.GetSizeDecWidth() : fDst.GetSizeDecWidth());

	//2-la siyam bor bo'lgan zona:
	char *pCh[2];int ln[2];
	for(i=0; i<iVerChars; i++)
	{	ln[0]=fSrc.Read(&FCrntOffst,2*iHorChars,(void**)&pCh[0]);
		ln[1]=fDst.Read(&FCrntOffst,2*iHorChars,(void**)&pCh[1]);
		if(ln[0]<=0 || ln[1]<=0) break;

		if(bHexAddrMode)
			MyInt64ToHexString(s,SZWD,FCrntOffst);//StringCchPrintf(s,15,fSrc.GetOffsetStrFormat(),FCrntOffst);
		else
			MyInt64ToString(s,SZWD,FCrntOffst);
		if(ln[0])ExtTextOutA(dcSrcAddr,rSrcAddr.left,rSrcAddr.top,ETO_OPAQUE,NULL,s,SZWD,NULL);
		if(ln[1])ExtTextOutA(dcDestAddr,rSrcAddr.left,rSrcAddr.top,ETO_OPAQUE,NULL,s,SZWD,NULL);
		rSrcAddr.top += CHRH; rSrcAddr.bottom += CHRH;
		
		rSrc.left = 0; rSrc.right = CHRW;
		for(k=0; k<iHorChars; k++)
		{	BOOL bEqu=FALSE;int iLocEqu=1;
			if(ln[0]==ln[1])
			{	bEqu=((*pCh[0]) == (*pCh[1]));
				while(bEqu ? (pCh[0][iLocEqu]==pCh[1][iLocEqu]) : (pCh[0][iLocEqu]!=pCh[1][iLocEqu]))
				{	if(rSrc.right+CHRW > widthSrc-1) break;
					++k;++iLocEqu;
					rSrc.right += CHRW;
			}	}
			if(!bEqu){SetTextColor(dcSrc,RGB(255,0,0));SetTextColor(dcDest,RGB(255,0,0));}
			if(ln[0]>k)
				ExtTextOutW(dcSrc,rSrc.left,rSrc.top,ETO_OPAQUE,&rSrc,(LPCWSTR)pCh[0],iLocEqu,spc);
			if(ln[1]>k)
				ExtTextOutW(dcDest,rSrc.left,rSrc.top,ETO_OPAQUE,&rSrc,(LPCWSTR)pCh[1],iLocEqu,spc);
			if(!bEqu){SetTextColor(dcSrc,RGB(0,0,0));SetTextColor(dcDest,RGB(0,0,0));}
			rSrc.left += CHRW*iLocEqu; rSrc.right+= CHRW*iLocEqu;
			pCh[0]+=iLocEqu; pCh[1]+=iLocEqu; FCrntOffst+=iLocEqu;
		}
		rSrc.top += CHRH; rSrc.bottom+= CHRH;
		if((2*iHorChars!=ln[0]) || (2*iHorChars!=ln[1])) break;
	}
	SetTextColor(dcSrc,RGB(255,0,0));SetTextColor(dcDest,RGB(255,0,0));
	rSrc.left = 0; rSrc.right = CHRW*iHorChars;

	if(fSrc.GetSize()>fDst.GetSize())
	{	for(k=i; k<iVerChars; k++)
		{	ln[0]=fSrc.Read(&FCrntOffst,2*iHorChars,(void**)&pCh[0]);
			if(!ln[0]) break;
			if(bHexAddrMode)
				MyInt64ToHexString(s,SZWD,FCrntOffst);//StringCchPrintf(s,15,fSrc.GetOffsetStrFormat(),FCrntOffst);
			else
				MyInt64ToString(s,SZWD,FCrntOffst);
			ExtTextOutA(dcSrcAddr,rSrcAddr.left,rSrcAddr.top,ETO_OPAQUE,NULL,s,SZWD,NULL);
			ExtTextOutA(dcSrc,rSrc.left,rSrc.top,ETO_OPAQUE,&rSrc,pCh[0],ln[0],spc);
			rSrcAddr.top += CHRH; rSrcAddr.bottom += CHRH;
			rSrc.top += CHRH; rSrc.bottom+= CHRH;
			FCrntOffst += iHorChars;
	}	}
	else
	{	for(k=i; k<iVerChars; k++)
		{	ln[1]=fDst.Read(&FCrntOffst,2*iHorChars,(void**)&pCh[1]);
			if(!ln[1]) break;
			if(bHexAddrMode)
				MyInt64ToHexString(s,SZWD,FCrntOffst);//StringCchPrintf(s,15,fSrc.GetOffsetStrFormat(),FCrntOffst);
			else
				MyInt64ToString(s,SZWD,FCrntOffst);
			ExtTextOutA(dcDestAddr,rSrcAddr.left,rSrcAddr.top,ETO_OPAQUE,NULL,s,SZWD,NULL);
			ExtTextOutA(dcDest,rSrc.left,rSrc.top,ETO_OPAQUE,&rSrc,pCh[1],ln[1],spc);
			rSrcAddr.top += CHRH; rSrcAddr.bottom += CHRH;
			rSrc.top += CHRH; rSrc.bottom+= CHRH;
			FCrntOffst += iHorChars;
	}	}

	RedrawWindow(hSrcAddr,NULL,NULL,RDW_NOINTERNALPAINT|RDW_VALIDATE);
	RedrawWindow(hSrc,NULL,NULL,RDW_NOINTERNALPAINT|RDW_VALIDATE);
	RedrawWindow(hDest,NULL,NULL,RDW_NOINTERNALPAINT|RDW_VALIDATE);
	RedrawWindow(hDestAddr,NULL,NULL,RDW_NOINTERNALPAINT|RDW_VALIDATE);
	SelectObject(dcSrcAddr,oldSrcAddrFnt);
	SelectObject(dcSrc,oldSrcFnt);
	SelectObject(dcDest,oldDestFnt);
	SelectObject(dcDestAddr,oldDestAddrFnt);
	if(dcSrcAddr)ReleaseDC(hSrcAddr,dcSrcAddr);
	if(dcSrc)ReleaseDC(hSrc,dcSrc);
	if(dcDest)ReleaseDC(hDest,dcDest);
	if(dcDestAddr)ReleaseDC(hDestAddr,dcDestAddr);
	return r;
}