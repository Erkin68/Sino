#ifndef _SHIFTED_FILE_H_
#define _SHIFTED_FILE_H_

#include "windows.h"

class SftdFile
{
public:
		 SftdFile(DWORD);
		~SftdFile();
	BOOL Open(wchar_t*);
	VOID Close();
	int  GetSizeDecWidth();
	wchar_t* GetOffsetStrFormat();
	unsigned __int64  GetSize();
	int Read(unsigned __int64*,int,void**);

protected:
	DWORD   bufSize,bufSizeSP;
	unsigned char* buf;
	unsigned __int64 sz;
	unsigned __int64 offset;
	HANDLE f;
	wchar_t szDecPos[8];//sz ning xonasi;
	int szDecWidth;//tepadagining o'lchami;
};


inline int SftdFile::GetSizeDecWidth(){return szDecWidth;}
inline unsigned __int64 SftdFile::GetSize(){return sz;}
inline wchar_t* SftdFile::GetOffsetStrFormat(){return &szDecPos[0];}

#endif
