#include "ShiftedFile.h"
#include "..\..\..\..\Operations\MyShell\MyShell.h"


extern "C"
{
VOID MyInt64ToString(char*,int,unsigned __int64);
}


SftdFile::SftdFile(DWORD s):bufSize(s),f(0),offset(0),szDecWidth(1),bufSizeSP(s)
{
	buf=(unsigned char*)malloc(s);
}

SftdFile::~SftdFile()
{
	if(buf) free(buf);
	buf=0;
	bufSize=0;
	if(f)CloseHandle(f);
	f=0;
}

BOOL SftdFile::Open(wchar_t *s)
{
BY_HANDLE_FILE_INFORMATION fi;
	f=CreateFile(s,GENERIC_READ,FILE_SHARE_READ,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_READONLY,NULL);
	if(INVALID_HANDLE_VALUE==f)return FALSE;
	if(GetFileInformationByHandle(f,&fi))
		sz=((unsigned __int64)fi.nFileSizeHigh<<32) | fi.nFileSizeLow;

	if(sz<10){MyStringCpy(szDecPos,5,L"%0.1d");szDecWidth = 1;}
	else if(sz<100){MyStringCpy(szDecPos,5,L"%0.2d");szDecWidth = 2;}
	else if(sz<1000){MyStringCpy(szDecPos,5,L"%0.3d");szDecWidth = 3;}
	else if(sz<10000){MyStringCpy(szDecPos,5,L"%0.4d");szDecWidth = 4;}
	else if(sz<100000){MyStringCpy(szDecPos,5,L"%0.5d");szDecWidth = 5;}
	else if(sz<1000000){MyStringCpy(szDecPos,5,L"%0.6d");szDecWidth = 6;}
	else if(sz<10000000){MyStringCpy(szDecPos,5,L"%0.7d");szDecWidth = 7;}
	else if(sz<100000000){MyStringCpy(szDecPos,5,L"%0.8d");szDecWidth = 8;}
	else if(sz<1000000000){MyStringCpy(szDecPos,5,L"%0.9d");szDecWidth = 9;}
	else if(sz<10000000000){MyStringCpy(szDecPos,6,L"%0.10d");szDecWidth = 10;}
	else if(sz<100000000000){MyStringCpy(szDecPos,6,L"%0.11d");szDecWidth = 11;}
	else if(sz<1000000000000){MyStringCpy(szDecPos,6,L"%0.12d");szDecWidth = 12;}
	else if(sz<10000000000000){MyStringCpy(szDecPos,6,L"%0.13d");szDecWidth = 13;}
	else if(sz<100000000000000){MyStringCpy(szDecPos,6,L"%0.14d");szDecWidth = 14;}
	else if(sz<1000000000000000){MyStringCpy(szDecPos,6,L"%0.15d");szDecWidth = 15;}
	else {MyStringCpy(szDecPos,6,L"%0.16d");szDecWidth = 16;}

	ReadFile(f,buf,bufSize,&bufSize,NULL);
	return TRUE;
}

void SftdFile::Close()
{
	if(f)CloseHandle(f);
	f=0;
	sz=0;
	offset=0;
}

int SftdFile::Read(unsigned __int64 *frPos,int len,void **pout)
{
	if((*frPos)>sz)	return 0;
	if(*frPos >= offset)
	{	if(*frPos+len <= offset+bufSize)
		{	*pout = &buf[(*frPos)-offset+1];
			return len;
		}
		else if(*frPos+len > sz)
		{	*pout = &buf[*frPos-offset+1];
			return (int)(sz-(*frPos));
	}	}
	//else
	if(*frPos > sz) return 0;
	offset = *frPos;
	SetFilePointer(f,(LONG)offset,((LONG*)frPos)+1,FILE_BEGIN);
	bufSize=bufSizeSP;//avvalgidan qolib ketgan bo'lishi mumkin;
	ReadFile(f,buf,bufSize,&bufSize,NULL);
	*pout = &buf[0];
	return len<(int)bufSize?len:(int)bufSize;
}

/*
BOOL bMpSetUp[2]={FALSE,FALSE};
BOOL bMpSetDown[2]={FALSE,FALSE};
BOOL bScSetUp[2]={FALSE,FALSE};
BOOL bScSetDown[2]={FALSE,FALSE};
*/