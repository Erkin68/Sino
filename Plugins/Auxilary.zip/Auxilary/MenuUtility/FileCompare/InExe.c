#include "windows.h"
#include "resource.h"
#include "strsafe.h"
#include "shlobj.h"

#define CHRW 12
#define CHRH 16

HMODULE plgnDllInst;

INT_PTR CALLBACK Cmpr2FilesDlgProc(HWND,UINT,WPARAM,LPARAM);
BOOL Resize(HWND,int,int);
BOOL Draw(HWND);
BOOL Scroll(HWND,int,WORD);

HBRUSH whteBrsh;HFONT fnt=0;HANDLE f[2]={0,0};//fayllar handli;
RECT rcSrc,rcSrcAddr,rcDestAddr;//src va dest, srcAddr, destAddr rect i;
WIN32_FIND_DATA pFindFileData[2];//2 ta fayl nomlar;
HWND hSrc,hSrcAddr,hDest,hDestAddr;//Ishlatgan kontrollar HWND si;
BY_HANDLE_FILE_INFORMATION fi[2];
DWORD MINFILEMAPSZ=65535;//#define MINFILEMAPSZ 65535//mapfile std hajmi, bundan kam ham bo'lishi mumkin;
	  fMapSz[2]={0,0};//MapFile qilingan, standart yoko undan kam bo'lgan hajmi;
char szDecPos[2][8];//sz ning xonasi;
int szDecPosLn[2],//tepadagining o'lchami;
	widthSrc,heightSrc,//hSrc va hDest ning pixellardagi eni va balandligi;
	iHorChars,iVerChars;//Tepadaginign o'zi, faqat charlarda;
WORD scrlPos=0;//O'rtadagi vert scroll posi,0 dan 65535 gachon;
LPVOID fMapPt[2]={0,0};//Map qilingan to 65535 gacha yoki undan kichik ozu, MapFile b-n ochilgan;
BOOL bMpSetUp[2]={FALSE,FALSE};
BOOL bMpSetDown[2]={FALSE,FALSE};
BOOL bScSetUp[2]={FALSE,FALSE};
BOOL bScSetDown[2]={FALSE,FALSE};

unsigned char *pch[2];
unsigned char *pchEnd[2];
unsigned __int64 fCrntOffst[2],//tepadan 1-qator offseti,faylning to'liq shkaladagi posi, mapdagi fMapOffst ga ekvivalent;
				 fBeforeMapOffst[2],//faylning mapgacha qismi hajmi;
				 sz[2];//fayllarning to'liq hajmi;
__int64 totLines=0,
		iTotScrlLines=0,//map qilingan ozudan boshlab scroll liniyasi, iHorChars ga k'opaytirsak, charlarni beradir;
		iScrlLines[2]={0,0};//map qilingan ozudan boshlab scroll liniyasi, iHorChars ga k'opaytirsak, charlarni beradir;

int __stdcall WinMain(HINSTANCE hInstance,HINSTANCE hPrevInstance,LPSTR lpCmdLine,int nShowCmnd)
{
SYSTEM_INFO si;//MSG msg;
LOGFONT lf;int r=0;
	plgnDllInst = hInstance;
	MyStringCpy(pFindFileData[0].cFileName,MAX_PATH-1,"d:\\temp\\SinoDbg.exe");//"d:\\Install\\Disk Images\\3D���������_1.nrg");
	MyStringCpy(pFindFileData[1].cFileName,MAX_PATH-1,"d:\\temp\\common.c");
	InitLOGFONT(&lf,0);
	fnt=CreateFontIndirect(&lf);
	whteBrsh=CreateSolidBrush(RGB(255,255,255));
	f[0]=CreateFile(pFindFileData[0].cFileName,GENERIC_READ,FILE_SHARE_READ,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_READONLY,NULL);
	if(INVALID_HANDLE_VALUE==f[0])goto End;
	f[1]=CreateFile(pFindFileData[1].cFileName,GENERIC_READ,FILE_SHARE_READ,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_READONLY,NULL);
	if(INVALID_HANDLE_VALUE==f[1]) goto End;
	if(!GetFileInformationByHandle(f[0],&fi[0])) {r=FALSE;goto End;}
	if(!GetFileInformationByHandle(f[1],&fi[1])) {r=FALSE;goto End;}
	sz[0] = ((unsigned __int64)fi[0].nFileSizeHigh<<32) | fi[0].nFileSizeLow;
	sz[1] = ((unsigned __int64)fi[1].nFileSizeHigh<<32) | fi[1].nFileSizeLow;

	if(sz[0]<10){MyStringCpy(szDecPos[0],5,"%0.1d");szDecPosLn[0] = 1;}
	else if(sz[0]<100){MyStringCpy(szDecPos[0],5,"%0.2d");szDecPosLn[0] = 2;}
	else if(sz[0]<1000){MyStringCpy(szDecPos[0],5,"%0.3d");szDecPosLn[0] = 3;}
	else if(sz[0]<10000){MyStringCpy(szDecPos[0],5,"%0.4d");szDecPosLn[0] = 4;}
	else if(sz[0]<100000){MyStringCpy(szDecPos[0],5,"%0.5d");szDecPosLn[0] = 5;}
	else if(sz[0]<1000000){MyStringCpy(szDecPos[0],5,"%0.6d");szDecPosLn[0] = 6;}
	else if(sz[0]<10000000){MyStringCpy(szDecPos[0],5,"%0.7d");szDecPosLn[0] = 7;}
	else if(sz[0]<100000000){MyStringCpy(szDecPos[0],5,"%0.8d");szDecPosLn[0] = 8;}
	else if(sz[0]<1000000000){MyStringCpy(szDecPos[0],5,"%0.9d");szDecPosLn[0] = 9;}
	else if(sz[0]<10000000000){MyStringCpy(szDecPos[0],6,"%0.10d");szDecPosLn[0] = 10;}
	else if(sz[0]<100000000000){MyStringCpy(szDecPos[0],6,"%0.11d");szDecPosLn[0] = 11;}
	else if(sz[0]<1000000000000){MyStringCpy(szDecPos[0],6,"%0.12d");szDecPosLn[0] = 12;}
	else if(sz[0]<10000000000000){MyStringCpy(szDecPos[0],6,"%0.13d");szDecPosLn[0] = 13;}
	else if(sz[0]<100000000000000){MyStringCpy(szDecPos[0],6,"%0.14d");szDecPosLn[0] = 14;}
	else if(sz[0]<1000000000000000){MyStringCpy(szDecPos[0],6,"%0.15d");szDecPosLn[0] = 15;}
	else {MyStringCpy(szDecPos[0],6,"%0.16d");szDecPosLn[0] = 16;}

	if(sz[1]<10){MyStringCpy(szDecPos[1],5,"%0.1d");szDecPosLn[1] = 1;}
	else if(sz[1]<100){MyStringCpy(szDecPos[1],5,"%0.2d");szDecPosLn[1] = 2;}
	else if(sz[1]<1000){MyStringCpy(szDecPos[1],5,"%0.3d");szDecPosLn[1] = 3;}
	else if(sz[1]<10000){MyStringCpy(szDecPos[1],5,"%0.4d");szDecPosLn[1] = 4;}
	else if(sz[1]<100000){MyStringCpy(szDecPos[1],5,"%0.5d");szDecPosLn[1] = 5;}
	else if(sz[1]<1000000){MyStringCpy(szDecPos[1],5,"%0.6d");szDecPosLn[1] = 6;}
	else if(sz[1]<10000000){MyStringCpy(szDecPos[1],5,"%0.7d");szDecPosLn[1] = 7;}
	else if(sz[1]<100000000){MyStringCpy(szDecPos[1],5,"%0.8d");szDecPosLn[1] = 8;}
	else if(sz[1]<1000000000){MyStringCpy(szDecPos[1],5,"%0.9d");szDecPosLn[1] = 9;}
	else if(sz[1]<10000000000){MyStringCpy(szDecPos[1],6,"%0.10d");szDecPosLn[1] = 10;}
	else if(sz[1]<100000000000){MyStringCpy(szDecPos[1],6,"%0.11d");szDecPosLn[1] = 11;}
	else if(sz[1]<1000000000000){MyStringCpy(szDecPos[1],6,"%0.12d");szDecPosLn[1] = 12;}
	else if(sz[1]<10000000000000){MyStringCpy(szDecPos[1],6,"%0.13d");szDecPosLn[1] = 13;}
	else if(sz[1]<100000000000000){MyStringCpy(szDecPos[1],6,"%0.14d");szDecPosLn[1] = 14;}
	else if(sz[1]<1000000000000000){MyStringCpy(szDecPos[1],6,"%0.15d");szDecPosLn[1] = 15;}
	else {MyStringCpy(szDecPos[1],6,"%0.16d");szDecPosLn[1] = 16;}

	GetSystemInfo(&si);MINFILEMAPSZ=si.dwAllocationGranularity;
	fMapPt[0]=malloc(MINFILEMAPSZ); fMapPt[1]=malloc(MINFILEMAPSZ);
	if(!fMapPt[0]) goto End; if(!fMapPt[1]) goto End;

	fMapSz[0]=(int)(sz[0]<MINFILEMAPSZ?sz[0]:MINFILEMAPSZ);
	fMapSz[1]=(int)(sz[1]<MINFILEMAPSZ?sz[1]:MINFILEMAPSZ);
	fCrntOffst[0]=fCrntOffst[1]=0;//fMapOffst[0]=fMapOffst[1]=
	fBeforeMapOffst[0]=fBeforeMapOffst[1]=0;

	ReadFile(f[0],fMapPt[0],fMapSz[0],&fMapSz[0],NULL);
	ReadFile(f[1],fMapPt[1],fMapSz[1],&fMapSz[1],NULL);
	if(!fMapSz[0]) goto End;
	if(!fMapSz[1]) goto End;
	pch[0]=(char*)fMapPt[0];
	pch[1]=(char*)fMapPt[1];
	pchEnd[0]=(char*)fMapPt[0]+fMapSz[0];
	pchEnd[1]=(char*)fMapPt[1]+fMapSz[1];
	bMpSetUp[0]=bMpSetUp[1]=bMpSetDown[0]=bMpSetDown[1]=
	bScSetUp[0]=bScSetUp[1]=bScSetDown[0]=bScSetDown[1]=FALSE;

	r=DialogBox(hInstance,MAKEINTRESOURCE(IDD_DIALOG_CMP_TWO_FILES),NULL,Cmpr2FilesDlgProc);
/*	r=CreateDialog(hInstance,MAKEINTRESOURCE(IDD_DIALOG_CMP_TWO_FILES),NULL,Cmpr2FilesDlgProc);
	ShowWindow(r,SW_SHOW);

	while(1)
	{	if(PeekMessage(&msg, NULL, 0U, 0U, PM_REMOVE))
		{	//if(!ProcessMessage(&msg))    !!!!!!!!
				TranslateMessage(&msg);//Agar olib tashlasang, EDIT lar ishlamaydur!!!!
				DispatchMessage(&msg);
			if(msg.hwnd==r && WM_CLOSE==msg.message)
				Beep(0,0);
	}	}*/

End:
	if(fMapPt[0])free(fMapPt[0]); if(fMapPt[1])free(fMapPt[1]);
	if(f[0])CloseHandle(f[0]); if(f[1])CloseHandle(f[1]);
	if(fnt)DeleteObject(fnt);
	if(whteBrsh)DeleteObject(whteBrsh);
	return r;
}

BOOL Resize(HWND dlg,int x,int y)
{
//x-=2;y-=2;
int addrBarWidth;
RECT rc;GetClientRect(dlg,&rc);
x=rc.right-rc.left;y=rc.bottom-rc.top;
	if(!x) return FALSE; if(!y) return FALSE;
	if(x<7) x=7;if(y<20)y=20;
	addrBarWidth=(int)(0.65*CHRW*(szDecPosLn[0]>szDecPosLn[1]?szDecPosLn[0]:szDecPosLn[1]));

	MoveWindow(GetDlgItem(dlg,IDC_VERT_SCROLLBAR),x/2-7,0,18,y,TRUE);
	MoveWindow(GetDlgItem(dlg,IDC_EDIT_SRC_NAME),0,0,(int)(0.5*x-7),20,TRUE);
	MoveWindow(GetDlgItem(dlg,IDC_EDIT_DEST_NAME),(int)(0.5*x+10),0,(int)(0.5*x-7),20,TRUE);	
	
	MoveWindow(hSrcAddr,0,20,addrBarWidth,y-20,TRUE);	
	MoveWindow(hDestAddr,(int)(x-addrBarWidth),20,addrBarWidth,y-20,TRUE);
	MoveWindow(hSrc,addrBarWidth,20,(int)(0.5*x-addrBarWidth-6),y-20,TRUE);
	MoveWindow(hDest,(int)(0.5*x+9),20,(int)(0.5*x-addrBarWidth-6),y-20,TRUE);

	GetClientRect(hSrcAddr,&rcSrcAddr);
	GetClientRect(hSrc,&rcSrc);
	GetClientRect(hDestAddr,&rcDestAddr);//GetClientRect(hDest,&rcDest);
	widthSrc=rcSrc.right-rcSrc.left;
	heightSrc=rcSrc.bottom-rcSrc.top;

	iHorChars = widthSrc / CHRW;
	iVerChars = heightSrc / CHRH;
	if(heightSrc % CHRH > 0) ++iVerChars;
	if(iHorChars<1)iHorChars=1;

	if(sz[0]>sz[1])
	{	totLines = sz[0] / iHorChars;
		if(sz[0] % iHorChars > 0)
			++totLines;
		totLines -= iVerChars;
		scrlPos=65535*fCrntOffst[0]/iHorChars;
		SendMessage(GetDlgItem(dlg,IDC_VERT_SCROLLBAR),(UINT)SBM_SETPOS,scrlPos,FALSE);		
	}
	else //if(sz[0]>sz[1])
	{	totLines = sz[1] / iHorChars;
		if(sz[1] % iHorChars > 0)
			++totLines;
		totLines -= iVerChars;
		scrlPos=65535*fCrntOffst[1]/iHorChars;
		SendMessage(GetDlgItem(dlg,IDC_VERT_SCROLLBAR),(UINT)SBM_SETPOS,scrlPos,FALSE);		
	}
	return TRUE;
}

INT_PTR CALLBACK SmplChldDlgProc(HWND hDlg,UINT message,WPARAM wParam,LPARAM lParam)
{
	switch(message)
	{	case WM_PAINT: return 0;
		//case WM_ERASEBKGND:
		//	return 1;
	}
	return DefWindowProc(hDlg,message,wParam,lParam);
}

INT_PTR CALLBACK Cmpr2FilesDlgProc(hDlg,message,wParam,lParam)
HWND hDlg;
UINT message;
WPARAM wParam;
LPARAM lParam;
{	
int  left,top,width,height;
RECT  rc,rc1;//HMENU hm;
//MENUITEMINFO mi;
HWND prnt;WNDCLASSEX wcex;
	//static int i=0;
	//char ss[32];sprintf(ss,"\n %d ",i++);
	//OutputDebugString(ss);
	//OutputDebugString(GetWinNotifyText(message));
	//sprintf(ss," %x %x",wParam,lParam);
	//OutputDebugString(ss);
	switch(message)
	{	case WM_INITDIALOG:
			GetWindowRect(hDlg, &rc1);
			prnt = GetParent(hDlg);
			if(!prnt)prnt=GetDesktopWindow();
			GetWindowRect(prnt, &rc);
			width = rc1.right - rc1.left;		
			left = rc.left + (rc.right - rc.left - width)/2;//left = (GetSystemMetrics(SM_CXFULLSCREEN) - width)/2;
			height = rc1.bottom - rc1.top;
			top = rc.top + (rc.bottom - rc.top - height)/2;//top = (GetSystemMetrics(SM_CYFULLSCREEN) - height)/2;
			MoveWindow(hDlg, left, top+20, width, height, TRUE);
			//Load language strings:
			/*SetWindowText(hDlg,strngs[0]);
			SetDlgItemText(hDlg,IDOK,strngs[21]);
			hm = GetMenu(hDlg);
			if(!hm) return FALSE;
			mi.cbSize = sizeof(MENUITEMINFO);
			mi.fMask=MIIM_STRING; mi.fType=MFT_STRING;
			mi.dwTypeData = strngs[15];SetMenuItemInfo(hm,ID_ADDRESSMODE_HEX,FALSE,&mi);
			mi.dwTypeData = strngs[16];SetMenuItemInfo(hm,ID_ADDRESSMODE_DEC,FALSE,&mi);
			mi.dwTypeData = strngs[17];SetMenuItemInfo(hm,ID_EDITMODE_BINARY,FALSE,&mi);
			mi.dwTypeData = strngs[13];SetMenuItemInfo(hm,0,TRUE,&mi);
			mi.dwTypeData = strngs[CHRW];SetMenuItemInfo(hm,1,TRUE,&mi);
			mi.dwTypeData = strngs[18];SetMenuItemInfo(hm,2,TRUE,&mi);*/
			SendMessage(GetDlgItem(hDlg,IDC_EDIT_SRC_NAME),WM_SETFONT,(WPARAM)fnt,0);
			SendMessage(GetDlgItem(hDlg,IDC_EDIT_DEST_NAME),WM_SETFONT,(WPARAM)fnt,0);
			SetDlgItemText(hDlg,IDC_EDIT_SRC_NAME,pFindFileData[0].cFileName);
			SetDlgItemText(hDlg,IDC_EDIT_DEST_NAME,pFindFileData[1].cFileName);
			SetScrollRange(GetDlgItem(hDlg,IDC_VERT_SCROLLBAR),SB_CTL,0,65535,TRUE);//sz[0]>sz[1]?(sz[0]/32):(sz[1]/32)

			wcex.cbSize = sizeof(WNDCLASSEX);
			wcex.style			= CS_HREDRAW|CS_VREDRAW|CS_OWNDC;
			wcex.lpfnWndProc	= SmplChldDlgProc;
			wcex.cbClsExtra		= 0;
			wcex.cbWndExtra		= 0;//sizeof(HANDLE);
			wcex.hInstance		= plgnDllInst;
			wcex.hIcon			= NULL;
			wcex.hCursor		= LoadCursor(NULL, IDC_ARROW);
			wcex.hbrBackground	= whteBrsh;//(HBRUSH)GetStockObject(WHITE_BRUSH);
			wcex.lpszMenuName	= NULL;
			wcex.lpszClassName	= "Source file compare window class";
			wcex.hIconSm		= NULL;
			RegisterClassEx(&wcex);
			hSrcAddr = CreateWindowEx(WS_EX_CLIENTEDGE,
							"Source file compare window class",
							"Source file compare window",
							WS_VISIBLE|WS_CHILD,
							0,
							20,
							54,
							402,
							hDlg,
							NULL,
							plgnDllInst,
							(LPVOID)1);
			if(NULL==hSrcAddr) {/*msg(0,strngs[]);*/EndDialog(hDlg,0);return FALSE;}
			hSrc = CreateWindowEx(WS_EX_CLIENTEDGE,
							"Source file compare window class",
							"Source file compare window",
							WS_VISIBLE|WS_CHILD,
							54,
							20,
							325,
							402,
							hDlg,
							NULL,
							plgnDllInst,
							(LPVOID)2);
			if(NULL==hSrc) {/*msg(0,strngs[]);*/EndDialog(hDlg,0);return FALSE;}
			hDest = CreateWindowEx(WS_EX_CLIENTEDGE,
							"Source file compare window class",
							"Source file compare window",
							WS_VISIBLE|WS_CHILD,
							398,
							20,
							325,
							402,
							hDlg,
							NULL,
							plgnDllInst,
							(LPVOID)3);
			if(NULL==hDest) {/*msg(0,strngs[]);*/EndDialog(hDlg,0);return FALSE;}
			hDestAddr = CreateWindowEx(WS_EX_CLIENTEDGE,
							"Source file compare window class",
							"Source file compare window",
							WS_VISIBLE|WS_CHILD,
							724,
							20,
							54,
							402,
							hDlg,
							NULL,
							plgnDllInst,
							(LPVOID)3);
			if(NULL==hDestAddr) {/*msg(0,strngs[]);*/EndDialog(hDlg,0);return FALSE;}
			SetFocus(hSrc);
			Resize(hDlg,width,height);
			Draw(hDlg);
			break;
		case WM_SIZE:
			Resize(hDlg,LOWORD(lParam),HIWORD(lParam));
			break;
		case WM_PAINT:
			//hdc = BeginPaint(hwnd, &ps); 
			Draw(hDlg);
            //EndPaint(hwnd, &ps); 
			break;
		case WM_MOUSEWHEEL:
			//if(MK_MBUTTON==LOWORD(wParam))
			SendMessage(hDlg,WM_VSCROLL,GET_WHEEL_DELTA_WPARAM(wParam)<0?SB_PAGERIGHT:SB_PAGELEFT,0);
			break;
		/*case WM_KEYDOWN:  focus avtomaticheski scrollga o'tib olarkan o'zi;
			switch(wParam)
			{	case VK_DOWN:
					if(Scroll(hDlg,1,0))
						SendMessage(GetDlgItem(hDlg,IDC_VERT_SCROLLBAR),(UINT)SBM_SETPOS,scrlPos,FALSE);
					break;
				case VK_UP:
					if(Scroll(hDlg,2,0))
						SendMessage(GetDlgItem(hDlg,IDC_VERT_SCROLLBAR),(UINT)SBM_SETPOS,scrlPos,FALSE);
					break;
				case VK_PRIOR:
					if(Scroll(hDlg,3,0))
						SendMessage(GetDlgItem(hDlg,IDC_VERT_SCROLLBAR),(UINT)SBM_SETPOS,scrlPos,FALSE);
					break;
				case VK_NEXT:
					if(Scroll(hDlg,4,0))
						SendMessage(GetDlgItem(hDlg,IDC_VERT_SCROLLBAR),(UINT)SBM_SETPOS,scrlPos,FALSE);
					break;
			}
			break;*/
		case WM_VSCROLL:
			if(SB_THUMBPOSITION==LOWORD(wParam) ||SB_THUMBTRACK==LOWORD(wParam))
			{	if(Scroll(hDlg,0,HIWORD(wParam)));//,oldScrlPos>scrlPos);
					SendMessage(GetDlgItem(hDlg,IDC_VERT_SCROLLBAR),(UINT)SBM_SETPOS,scrlPos,FALSE);
			}
			else
			{	BOOL r=FALSE;
				if(SB_LINELEFT==LOWORD(wParam))
					r=Scroll(hDlg,1,0);
				else if(SB_LINERIGHT==LOWORD(wParam))
					r=Scroll(hDlg,2,0);
				else if(SB_PAGELEFT==LOWORD(wParam))
					r=Scroll(hDlg,3,0);
				else if(SB_PAGERIGHT==LOWORD(wParam))
					r=Scroll(hDlg,4,0);
				if(r)SendMessage(GetDlgItem(hDlg,IDC_VERT_SCROLLBAR),(UINT)SBM_SETPOS,scrlPos,TRUE);
			}
			break;
		case WM_COMMAND:
			switch(LOWORD(wParam))
			{	case IDCANCEL:
					EndDialog(hDlg, 0);
					return (INT_PTR)TRUE;
			}
			break;
	}
	return (INT_PTR)FALSE;
}

CONST INT spc[128]={CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW};
BOOL Draw(HWND dlg)
{
char s[32];
unsigned __int64 FCrntOffst[2]={fCrntOffst[0],fCrntOffst[1]};//tepadan 1-qator offseti,faylning to'liq shkaladagi posi, mapdagi fMapOffst ga ekvivalent;
char *pCh[2]={pch[0],pch[1]};
BOOL r=FALSE;
HDC dcSrc=GetDC(hSrc);
HDC dcDest=GetDC(hDest);
HDC	dcSrcAddr=GetDC(hSrcAddr);
HDC dcDestAddr=GetDC(hDestAddr);
HGDIOBJ oldSrcAddrFnt,oldSrcFnt,oldDestFnt,oldDestAddrFnt;

RECT rSrcAddr = rcSrcAddr;
RECT rSrc = rcSrc;
RECT rDestAddr = rcDestAddr;

	if((!dcSrc) || (!dcDest) || (!dcSrcAddr) || (!dcDestAddr)) return FALSE;
	oldSrcAddrFnt=SelectObject(dcSrcAddr,fnt);
	oldSrcFnt=SelectObject(dcSrc,fnt);
	oldDestFnt=SelectObject(dcDest,fnt);
	oldDestAddrFnt=SelectObject(dcDestAddr,fnt);
	//SetBkColor(dcSrcAddr,RGB(235,235,255));SetBkColor(dcSrc,RGB(245,245,255));SetBkColor(dcDest,RGB(245,235,255));SetBkColor(dcDestAddr,RGB(245,245,255));

	FillRect(dcSrc ,&rSrc,whteBrsh);FillRect(dcSrcAddr ,&rSrcAddr,whteBrsh);
	rSrcAddr.top = 0; rSrcAddr.bottom = 25; rSrcAddr.left = 0;//(LONG)(0.136f*widthSrc)-szDecPosLn[0]*CHRH+64;
	rSrc.left=0;rSrc.right=0;rSrc.top=0;rSrc.bottom=CHRH;//GetClientRect(hSrc,&rSrc);

	SetTextColor(dcSrcAddr,RGB(0,0,155));SetTextColor(dcDestAddr,RGB(0,0,155));
//	SetTextColor(dcSrc,RGB(0,0,0));	SetTextColor(dcDest,RGB(0,0,0));

	//1tasi 2-sidan ortib qoldu:
	SetTextColor(dcSrc,RGB(255,0,0));
	while(pCh[0]<pchEnd[0])//srcni chizamiz:
	{	int iChars = (pCh[0]+iHorChars<pchEnd[0]) ? iHorChars : (pchEnd[0]-pCh[0]);
		if(iChars>0)
		{	MyInt64ToString(s,szDecPosLn[0],FCrntOffst[0]);//StringCchPrintf(s,15,szDecPos[0],FCrntOffst[0]);
			ExtTextOut(dcSrcAddr,rSrcAddr.left,rSrcAddr.top,ETO_OPAQUE,NULL,s,szDecPosLn[0],NULL);
			rSrcAddr.top += CHRH; rSrcAddr.bottom += CHRH;
		}
		if(rSrc.top > heightSrc-10) goto SkipTail;//break; duminiyam chizish kerakmas;
		__try
		{
			ExtTextOut(dcSrc,rSrc.left,rSrc.top,ETO_OPAQUE,NULL,pCh[0],iChars,spc);
		}__except(1)
		{
			;
		}
		rSrc.top += CHRH;rSrc.bottom+= CHRH;rSrc.left=0;
		pCh[0]+=iChars; FCrntOffst[0]+=iChars;
	}

SkipTail:
	RedrawWindow(hSrcAddr,NULL,NULL,RDW_NOINTERNALPAINT|RDW_VALIDATE);
	RedrawWindow(hSrc,NULL,NULL,RDW_NOINTERNALPAINT|RDW_VALIDATE);
	RedrawWindow(hDest,NULL,NULL,RDW_NOINTERNALPAINT|RDW_VALIDATE);
	RedrawWindow(hDestAddr,NULL,NULL,RDW_NOINTERNALPAINT|RDW_VALIDATE);
	SelectObject(dcSrcAddr,oldSrcAddrFnt);
	SelectObject(dcSrc,oldSrcFnt);
	SelectObject(dcDest,oldDestFnt);
	SelectObject(dcDestAddr,oldDestAddrFnt);
	if(dcSrcAddr)ReleaseDC(hSrcAddr,dcSrcAddr);
	if(dcSrc)ReleaseDC(hSrc,dcSrc);
	if(dcDest)ReleaseDC(hDest,dcDest);
	if(dcDestAddr)ReleaseDC(hDestAddr,dcDestAddr);
	return r;
}

//FILE *fp=NULL;
BOOL Scroll(HWND hDlg,int type,WORD lParam)//,BOOL bToPrev)//else to next (it means down);
{
unsigned __int64 plannedOffset;
__int64 oldLines=iTotScrlLines;
LONG offstHigh;
			
	//if(!fp)fp=fopen("prof.txt","w");

	switch(type)
	{	case 0://ushlab tortgan,lParam ishladur;
			if(lParam>scrlPos)
			{	if(65535==lParam)iTotScrlLines=totLines;
				else iTotScrlLines += (lParam-scrlPos)*totLines/65535;
			}
			else if(lParam<scrlPos)
			{	if(0==lParam)iTotScrlLines=0;
				else iTotScrlLines -= (scrlPos-lParam)*totLines/65535;
			}
			break;
		case 1: --iTotScrlLines; break;//tepaga 1 ta;
		case 2:	++iTotScrlLines; break;//pastga 1 ta
		case 3://tepag 1 bet;
			if(iVerChars<1) break;
			iTotScrlLines-=iVerChars-1;
			break;
		case 4://pastga 1 bet;
			if(iVerChars<1) break;
			iTotScrlLines+=iVerChars-1;
			//else break;
			break;
	}//div_t div_result = div(totLines*scrlPos,65535);
	if(iTotScrlLines<0)iTotScrlLines=0;
	else if(iTotScrlLines>totLines)iTotScrlLines=totLines;
	if(iTotScrlLines==oldLines)	return FALSE;

	//scrlPos ning o'zini ham korrektirovka qilib qo'yamiz:
	scrlPos = (WORD)(65535*((double)iTotScrlLines/totLines));

	plannedOffset = (unsigned __int64)iTotScrlLines*iHorChars;
	if(plannedOffset>=sz[0])plannedOffset=sz[0];

	if((!bMpSetDown[0]) && iTotScrlLines>oldLines &&
	     plannedOffset > fBeforeMapOffst[0] + fMapSz[0] - iHorChars*iVerChars)//down:
	{	DWORD mpsz=MINFILEMAPSZ;
		offstHigh = plannedOffset>>32;
		SetFilePointer(f[0],plannedOffset&0xffffffff,&offstHigh,FILE_BEGIN);
		ReadFile(f[0],fMapPt[0],mpsz,&mpsz,NULL);
		if(fMapSz[0]>0)
		{	fBeforeMapOffst[0] = plannedOffset;
			iScrlLines[0]=0;
			fMapSz[0]=mpsz;
			pch[0]=(unsigned char*)fMapPt[0];
			pchEnd[0]=(char*)fMapPt[0]+fMapSz[0];
			fCrntOffst[0]=fBeforeMapOffst[0]+iScrlLines[0]*iHorChars;
			if(fBeforeMapOffst[0]+fMapSz[0]>=sz[0])
				bMpSetDown[0]=TRUE;		
		}
		/*fprintf(fp,"\n Down BfMpOf: %d",fBeforeMapOffst[0]);
		fprintf(fp," fCrOfs: %d",fCrntOffst[0]);
		fprintf(fp," scrlPos: %d",scrlPos);
		fprintf(fp," fMpSz: %d",fMapSz[0]);
		fprintf(fp," pch: %d",pch[0]);
		fprintf(fp," pchEnd: %d",pchEnd[0]);
		fprintf(fp," totLns: %d",totLines);
		fprintf(fp," iTotScLns: %d",iTotScrlLines);
		fprintf(fp," plndOfs: %d",plannedOffset);*/
	}
	else if((!bMpSetUp[0]) && iTotScrlLines<oldLines &&
			  plannedOffset<fBeforeMapOffst[0])
	{	DWORD mpsz=MINFILEMAPSZ;
		if(plannedOffset>MINFILEMAPSZ-iHorChars*iVerChars)
		{	plannedOffset-=MINFILEMAPSZ-iHorChars*iVerChars;//boshi;
			plannedOffset &= ~(iHorChars-1);
		}
		else plannedOffset=0;
		offstHigh = plannedOffset>>32;
		SetFilePointer(f[0],plannedOffset&0xffffffff,&offstHigh,FILE_BEGIN);
		ReadFile(f[0],fMapPt[0],mpsz,&mpsz,NULL);
		if(fMapSz[0]>0)
		{	fMapSz[0]=mpsz;
			fBeforeMapOffst[0] = plannedOffset;
			iScrlLines[0]=(MINFILEMAPSZ/iHorChars)-iVerChars;
			fCrntOffst[0] = plannedOffset+iScrlLines[0]*iHorChars;
			bMpSetDown[0]=FALSE;
			pch[0]=(unsigned char*)fMapPt[0];
			pchEnd[0]=(char*)fMapPt[0]+fMapSz[0];			
		}
		/*fprintf(fp,"\n Up BfMpOf: %d",fBeforeMapOffst[0]);
		fprintf(fp," fCrOfs: %d",fCrntOffst[0]);
		fprintf(fp," fMpSz: %d",fMapSz[0]);
		fprintf(fp," scrlPos: %d",scrlPos);
		fprintf(fp," pch: %d",pch[0]);
		fprintf(fp," pchEnd: %d",pchEnd[0]);
		fprintf(fp," totLns: %d",totLines);
		fprintf(fp," iTotScLns: %d",iTotScrlLines);
		fprintf(fp," plndOfs: %d",plannedOffset);*/
	}
	else
	{	if(iTotScrlLines>oldLines)//oshishga
		{	if(!bScSetDown[0])
			{	int sclns = iTotScrlLines-fBeforeMapOffst[0]/iHorChars;
				unsigned char* p=(unsigned char*)fMapPt[0]+sclns*iHorChars;
				bScSetUp[0]=FALSE;
				if(p+iHorChars*(iVerChars-1)<pchEnd[0])
				{	pch[0]=p;
					iScrlLines[0]=sclns;
					fCrntOffst[0]=fBeforeMapOffst[0]+iScrlLines[0]*iHorChars;
				}
				else bScSetDown[0]=TRUE;					
		}	}
		else if(iTotScrlLines<oldLines)
		{	if(!bScSetUp[0])
			{	int sclns = iTotScrlLines-fBeforeMapOffst[0]/iHorChars;
				unsigned char* p=(unsigned char*)fMapPt[0]+sclns*iHorChars;
				bScSetDown[0]=FALSE;
				if(p+iHorChars*(iVerChars-1)<pchEnd[0])
				{	iScrlLines[0]=sclns;
					pch[0]=(unsigned char*)fMapPt[0]+iScrlLines[0]*iHorChars;
					fCrntOffst[0]=fBeforeMapOffst[0]+iScrlLines[0]*iHorChars;					
				}
				else bScSetUp[0]=TRUE;
				/*fprintf(fp,"\n iScrlLines[0]-- %d %d",iScrlLines[0] ,  oldLines-iTotScrlLines);
				fprintf(fp," fCrntOffst[0]: %d",fCrntOffst[0]);
				fprintf(fp," pch[0]: %d",pch[0]);
				fprintf(fp," pchEnd[0]: %d",pchEnd[0]);
				fprintf(fp," iTotScrlLines: %d",iTotScrlLines);*/
	}	}	}



	//2-file:
	//2-file:
	//2-file:
	//2-file:
	plannedOffset = (unsigned __int64)iTotScrlLines*iHorChars;
	if(plannedOffset>=sz[1])plannedOffset=sz[1];

	if((!bMpSetDown[1]) && iTotScrlLines>oldLines &&
	     plannedOffset > fBeforeMapOffst[1] + fMapSz[1] - iHorChars*iVerChars)//down:
	{	DWORD mpsz=MINFILEMAPSZ;
		offstHigh = plannedOffset>>32;
		SetFilePointer(f[1],plannedOffset&0xffffffff,&offstHigh,FILE_BEGIN);
		ReadFile(f[1],fMapPt[1],mpsz,&mpsz,NULL);
		if(fMapSz[1]>0)
		{	fBeforeMapOffst[1] = plannedOffset;
			iScrlLines[1]=0;
			fMapSz[1]=mpsz;
			pch[1]=(unsigned char*)fMapPt[1];
			pchEnd[1]=(char*)fMapPt[1]+fMapSz[1];
			fCrntOffst[1]=fBeforeMapOffst[1]+iScrlLines[1]*iHorChars;
			if(fBeforeMapOffst[1]+fMapSz[1]>=sz[1])
				bMpSetDown[1]=TRUE;		
	}	}
	else if((!bMpSetUp[1]) && iTotScrlLines<oldLines &&
			  plannedOffset<fBeforeMapOffst[1])
	{	DWORD mpsz=MINFILEMAPSZ;
		if(plannedOffset>MINFILEMAPSZ-iHorChars*iVerChars)
		{	plannedOffset-=MINFILEMAPSZ-iHorChars*iVerChars;//boshi;
			plannedOffset &= ~(iHorChars-1);
		}
		else plannedOffset=0;
		offstHigh = plannedOffset>>32;
		SetFilePointer(f[1],plannedOffset&0xffffffff,&offstHigh,FILE_BEGIN);
		ReadFile(f[1],fMapPt[1],mpsz,&mpsz,NULL);
		if(fMapSz[1]>0)
		{	fMapSz[1]=mpsz;
			fBeforeMapOffst[1] = plannedOffset;
			iScrlLines[1]=(MINFILEMAPSZ/iHorChars)-iVerChars;
			fCrntOffst[1] = plannedOffset+iScrlLines[1]*iHorChars;
			bMpSetDown[1]=FALSE;
			pch[1]=(unsigned char*)fMapPt[1];
			pchEnd[1]=(char*)fMapPt[0]+fMapSz[1];
	}	}
	else
	{	if(iTotScrlLines>oldLines)//oshishga
		{	if(!bScSetDown[1])
			{	int sclns = iTotScrlLines-fBeforeMapOffst[1]/iHorChars;
				unsigned char* p=(unsigned char*)fMapPt[1]+sclns*iHorChars;
				bScSetUp[1]=FALSE;
				if(p+iHorChars*(iVerChars-1)<pchEnd[1])
				{	pch[1]=p;
					iScrlLines[1]=sclns;
					fCrntOffst[1]=fBeforeMapOffst[1]+iScrlLines[1]*iHorChars;
				}
				else bScSetDown[1]=TRUE;
		}	}
		else if(iTotScrlLines<oldLines)
		{	if(!bScSetUp[1])
			{	int sclns = iTotScrlLines-fBeforeMapOffst[1]/iHorChars;
				unsigned char* p=(unsigned char*)fMapPt[1]+sclns*iHorChars;
				bScSetDown[1]=FALSE;
				if(p+iHorChars*(iVerChars-1)<pchEnd[1])
				{	iScrlLines[1]=sclns;
					pch[1]=(unsigned char*)fMapPt[1]+iScrlLines[1]*iHorChars;
					fCrntOffst[1]=fBeforeMapOffst[1]+iScrlLines[1]*iHorChars;					
				}
				else bScSetUp[1]=TRUE;
	}	}	}

	Draw(hDlg);
	return TRUE;
}