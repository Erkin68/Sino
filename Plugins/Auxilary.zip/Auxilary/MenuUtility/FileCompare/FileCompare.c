#include "windows.h"
#include "resource.h"
#include "strsafe.h"
#include "shlobj.h"



extern char **strngs;
extern HMODULE plgnDllInst;
extern int MyStringLength(char*,int);
extern int MyStringCat(char*,int,char*);
extern VOID InitLOGFONT(LOGFONT*,int);
extern int MyStringCpy(char*,int,char*);

INT_PTR CALLBACK CmprDlgProc(HWND,UINT,WPARAM,LPARAM);
INT_PTR CALLBACK Cmpr2FilesDlgProc(HWND,UINT,WPARAM,LPARAM);
BOOL CmprFiles(HWND hDlg,char*,char*);
BOOL CheckStopBtnMsg(HWND);
BOOL Resize(HWND,int,int);
BOOL Draw(HWND);

typedef BOOL (CALLBACK *saveOptions_t)(int,VOID*,int);
typedef BOOL (CALLBACK *readOptions_t)(int,VOID*,int);
typedef int  (CALLBACK *getTotPanels_t)();
typedef int  (CALLBACK *getCrntPanelNum_t)();
typedef char* (CALLBACK *getPanelPath_t)(int);
typedef LPVOID (CALLBACK *getPanelCrntItem_t)(int,WIN32_FIND_DATA*);
typedef LPVOID (CALLBACK *getPanelSelectedItems_t)(int,int*);
typedef unsigned __int64* (CALLBACK *getLogicalDriveSpace_t)(int);


saveOptions_t saveOptions=0;
readOptions_t readOptions=0;
getTotPanels_t getTotPanels=0;
getCrntPanelNum_t getCrntPanelNum=0;
getPanelCrntItem_t getPanelCrntItem=0;
getPanelSelectedItems_t getPanelSelectedItems=0;
getPanelPath_t getPanelPath=0;
getLogicalDriveSpace_t getLogicalDriveSpace=0;

int plgId = 0;
BOOL bStop=FALSE;
WIN32_FIND_DATA pFindFileData[2];
HWND hSrc,hDest,hSrcAddr,hDestAddr;

__declspec (dllexport) VOID SetCallbacks$4xxx(LPVOID frstCallback,...)
{
va_list args;
	va_start(args, frstCallback);//1
	saveOptions = (saveOptions_t)frstCallback;//1
	readOptions = (readOptions_t)va_arg(args, int);//2
	getTotPanels = (getTotPanels_t)va_arg(args, int);//3
	getCrntPanelNum = (getCrntPanelNum_t)va_arg(args, int);//4
	getPanelCrntItem = (getPanelCrntItem_t)va_arg(args, int);//5
	getPanelSelectedItems = (getPanelSelectedItems_t)va_arg(args, int);//6
	getPanelPath = (getPanelPath_t)va_arg(args, int);//7
	getLogicalDriveSpace = (getLogicalDriveSpace_t)va_arg(args, int);//8
va_end (args);
}

__declspec (dllexport) BOOL Run$4(HWND prnt)
{
int ttlPnl,crntPnl;
	if(!getCrntPanelNum) return FALSE;
	if(!getTotPanels)return FALSE;
	ttlPnl=getTotPanels();
	crntPnl=getCrntPanelNum();
	if(ttlPnl<2) return FALSE;
	if(crntPnl<0) return FALSE;
	if(crntPnl>ttlPnl-1) return FALSE;
	if(!getPanelCrntItem) return FALSE;
	if(1==DialogBox(plgnDllInst,MAKEINTRESOURCE(IDD_DIALOG_COMPARE),prnt,CmprDlgProc))
		DialogBox(plgnDllInst,MAKEINTRESOURCE(IDD_DIALOG_CMP_TWO_FILES),prnt,Cmpr2FilesDlgProc);
	return TRUE;
}

__declspec (dllexport) int GetPluginType()
{
	return 102;
}

__declspec (dllexport) const char* GetPluginName()
{
	return strngs[1];
}

__declspec (dllexport) int GetMenuNum()
{
	return 0;
}

__declspec (dllexport) int GetMenuPos()
{
	return 4;
}

__declspec (dllexport) const char* GetMenuItemText()
{
	return strngs[0];
}

__declspec (dllexport) const char* GetMenuText()
{
	return strngs[0];
}

__declspec (dllexport) VOID SetId$4(int id)
{
	plgId = id;
}

__declspec (dllexport) const char* GetPluginDescription()
{
	return strngs[1];
}

__declspec (dllexport) VOID ShowOptionDialog(HWND prnt)
{
}

BOOL IsCrntOrPrntDirAttrb(char* fd)
{//see Naming Conventions in MSDN:
	if('.'==fd[0])
	{	if('\0'==fd[1])//"."
			return FALSE;
		if('.'==fd[1])
			if('\0'==fd[2])//".."
				return FALSE;
	}
	return TRUE;//Hozircha;
}

unsigned __int64 MyAtoU64(char *s)
{
unsigned __int64 rt=0;
char *ps = s;
	while(*ps!=0)
	{	if(*ps < '0')
			return 0;
		if(*ps > '9')
			return 0;
		rt = rt*10 + (*ps - '0');
		ps++;
	}
	return rt;
}

BOOL MyU64ToA(char* st,int sLen,unsigned __int64 u)
{
int i,l=0;
unsigned __int64 delit = u;
static char s[32];
	if(!u)
	{	st[0] = '0';
		st[1] = 0;
		return TRUE;
	}

	while(delit)
	{	s[l++] = delit % 10 + '0';
		delit /= 10;
	}
	for(i=0; i<l; i++)
		st[i] = s[l-i-1];
	st[l] = 0;
	return TRUE;
}

INT_PTR CALLBACK CmprDlgProc(hDlg,message,wParam,lParam)
HWND hDlg;
UINT message;
WPARAM wParam;
LPARAM lParam;
{	//static int i=0;
	//char ss[32];sprintf(ss,"\n %d ",i++);
	//OutputDebugString(ss);
	//OutputDebugString(GetWinNotifyText(message));
	//sprintf(ss," %x %x",wParam,lParam);
	//OutputDebugString(ss);

static HFONT hf=0;
//static int hfRef=0;//obshiy hf, dinamik uchun emas:
static HBRUSH br=0;
//static LPVOID panel;
static HBRUSH brHtBk=0;
static int endDialogCodeToWM_DESTROY;
static int szQntSlct=0;
char s[MAX_PATH];
int left,top,width,height;
LPDRAWITEMSTRUCT lpdis;
OPENFILENAME ofn;
LOGFONT fnt;
RECT rc,rc1;
UINT uStyle;
HDC dc;

	switch(message)
	{	case WM_INITDIALOG:
			GetWindowRect(hDlg, &rc1);
			HWND prnt;prnt = GetParent(hDlg);
			if(!prnt)prnt=GetDesktopWindow();
			GetWindowRect(prnt, &rc);
			width = rc1.right - rc1.left;		
			left = rc.left + (rc.right - rc.left - width)/2;//left = (GetSystemMetrics(SM_CXFULLSCREEN) - width)/2;
			height = rc1.bottom - rc1.top;
			top = rc.top + (rc.bottom - rc.top - height)/2;//top = (GetSystemMetrics(SM_CYFULLSCREEN) - height)/2;
			MoveWindow(hDlg, left, top+20, width, height, TRUE);

			//Load language strings:
			SetWindowText(hDlg,strngs[0]);
			SetDlgItemText(hDlg,IDC_STATIC5,strngs[1]);
			SetDlgItemText(hDlg,IDC_STATIC1,strngs[2]);
			SetDlgItemText(hDlg,IDOK,strngs[10]);
			SetDlgItemText(hDlg,IDCANCEL,strngs[9]);
			SetDlgItemText(hDlg,IDC_BUTTON_BROWSE,strngs[3]);
			SetDlgItemText(hDlg,IDC_BUTTON_BROWSE2,strngs[3]);

			left=getCrntPanelNum();
			top=getTotPanels();
			width=left<top-1?left+1:(left>0?left-1:left);
			getPanelCrntItem(left,&pFindFileData[0]);
			SetDlgItemText(hDlg,IDC_EDIT_SRC,pFindFileData[0].cFileName);
			getPanelCrntItem(width,&pFindFileData[1]);
			SetDlgItemText(hDlg,IDC_EDIT_DEST,pFindFileData[1].cFileName);
			SetTimer(hDlg,0,500,NULL);
			if(top>0 && top<5)
			{	for(width=0; width<top; width++)
				{	if(left!=width)
					{	StringCchPrintf(s,MAX_PATH-1,"%d-panel",width+1);
						SendMessage(GetDlgItem(hDlg,IDC_COMBO_DEST_PANEL),CB_INSERTSTRING,(WPARAM)-1,(LPARAM)s);
			}	}	}
			SendMessage(hDlg,WM_USER+1,0,0);
			break;
		case WM_TIMER:
			KillTimer(hDlg,0);
			CmprFiles(hDlg,pFindFileData[0].cFileName,pFindFileData[1].cFileName);
			break;
		case WM_CTLCOLORSTATIC:
		case WM_CTLCOLORDLG:dc = (HDC)wParam;
			SetTextColor(dc,RGB(0xea,0xe0,0xff));//SetTextColor(dc,RGB(0x8a,0,0));
			SetBkColor(dc,RGB(0x40,0x21,0x17));//SetBkColor(dc,RGB(0xc0,0x81,0x97));
			return (INT_PTR)br;
		case WM_CTLCOLOREDIT:dc = (HDC)wParam;
			SetTextColor(dc,RGB(0xea,0xe0,0xff));//SetTextColor(dc,RGB(0x8a,0,0));
			SetBkColor(dc,RGB(0x40,0x21,0x17));//SetBkColor(dc,RGB(0xc0,0x81,0x97));
			return (INT_PTR)br;
		case WM_CTLCOLORBTN:dc=(HDC)wParam;
			SetTextColor(dc,RGB(0xd0,0xe0,0xff));
			SetBkColor(dc,RGB(0x64,0x79,0x65));
			return (INT_PTR)brHtBk;
		case WM_DRAWITEM://WM_CTLCOLORBTN dagi knopkalar:
			lpdis = (LPDRAWITEMSTRUCT)lParam;
			GetWindowText(lpdis->hwndItem,s,MAX_PATH);
			uStyle = DFCS_BUTTONPUSH;
			rc = lpdis->rcItem;
			if(lpdis->itemState & ODS_SELECTED)
			{	uStyle |= DFCS_PUSHED|DFCS_TRANSPARENT;
				rc.left+=2;rc.top+=2;
			}
			DrawFrameControl(lpdis->hDC, &lpdis->rcItem, DFC_BUTTON, uStyle);
			if(lpdis->itemState & ODS_SELECTED)
				{rc.left+=1;rc.top+=1;rc.bottom-=2;rc.right-=3;}
			else
				{rc.left+=1;rc.top+=2;rc.bottom-=3;rc.right-=3;}
			FillRect(lpdis->hDC,&rc,brHtBk);//DrawText(lpdis->hDC,"",50,&rc,DT_SINGLELINE|DT_VCENTER|DT_INTERNAL|DT_LEFT);
			if(lpdis->itemState & ODS_SELECTED)
				{rc.left-=1;rc.top-=1;rc.bottom+=3;rc.right+=3;}
			else
				{rc.left-=1;rc.top-=2;rc.bottom+=2;rc.right+=3;}
			DrawText(lpdis->hDC,s,MyStringLength(s,MAX_PATH),&rc,DT_SINGLELINE|DT_VCENTER|DT_CENTER);
			return FALSE;
		case WM_USER+1://hf obshiy uchun, dinamik o'zgartirish uchun emas:
			//if(0==hfRef)
			{	InitLOGFONT(&fnt,0);
				hf = CreateFontIndirect(&fnt);
				br = CreateSolidBrush(RGB(0x40,0x21,0x17));//0xc9,0x81,0x93));
				brHtBk = CreateSolidBrush(RGB(0x64,0x79,0x65));
			}
			SendMessage(GetDlgItem(hDlg,IDC_BUTTON_BROWSE),WM_SETFONT,(WPARAM)hf,TRUE);
			SendMessage(GetDlgItem(hDlg,IDC_BUTTON_BROWSE2),WM_SETFONT,(WPARAM)hf,TRUE);
			SendMessage(GetDlgItem(hDlg,IDSTOP),WM_SETFONT,(WPARAM)hf,TRUE);
			SendMessage(GetDlgItem(hDlg,IDCANCEL),WM_SETFONT,(WPARAM)hf,TRUE);
			SendMessage(GetDlgItem(hDlg,IDOK),WM_SETFONT,(WPARAM)hf,TRUE);
			SendMessage(GetDlgItem(hDlg,IDCANCEL),WM_SETFONT,(WPARAM)hf,TRUE);
			SendMessage(GetDlgItem(hDlg,IDC_STATIC5),WM_SETFONT,(WPARAM)hf,TRUE);
			SendMessage(GetDlgItem(hDlg,IDC_STATIC1),WM_SETFONT,(WPARAM)hf,TRUE);
    		SendMessage(GetDlgItem(hDlg,IDC_COMBO_DEST_PANEL),WM_SETFONT,(WPARAM)hf,TRUE);			

			SendMessage(GetDlgItem(hDlg,IDC_EDIT_SRC),WM_SETFONT,(WPARAM)hf,TRUE);
			SendMessage(GetDlgItem(hDlg,IDC_EDIT_DEST),WM_SETFONT,(WPARAM)hf,TRUE);
			//++hfRef;
			return 0;//GWL_USERDATA
		case WM_DESTROY:
			//if(--hfRef<1)
			{	DeleteObject(hf);
				DeleteObject(br);
				DeleteObject(brHtBk);
			}
			return 0;
		case WM_COMMAND:
			switch(LOWORD(wParam))
			{	case IDC_BUTTON_BROWSE://dest
					ZeroMemory(&ofn, sizeof(ofn));
					pFindFileData[1].cFileName[0] = '\0';
					ofn.lStructSize = sizeof(ofn);
					ofn.hwndOwner = NULL; 
					ofn.lpstrFile = pFindFileData[1].cFileName; 
					ofn.nMaxFile = MAX_PATH;
					ofn.lpstrFilter = NULL;
					ofn.nFilterIndex = 1;
					ofn.lpstrTitle = strngs[8];
					ofn.lpstrInitialDir = NULL;
					ofn.lpstrCustomFilter = NULL;
					ofn.nMaxCustFilter = 0;
					ofn.lpstrFileTitle = strngs[4];
					ofn.nMaxFileTitle = 0;
					ofn.nFileOffset = 0;
					ofn.nFileExtension = 0;
					ofn.lpstrDefExt = NULL;
					ofn.lCustData = 0;
					ofn.lpfnHook = 0;
					ofn.lpTemplateName = 0;
					ofn.Flags = OFN_PATHMUSTEXIST | OFN_FILEMUSTEXIST | OFN_HIDEREADONLY |OFN_EXTENSIONDIFFERENT;
					MyStringCpy(s,MAX_PATH-1,pFindFileData[1].cFileName);						
					if(GetOpenFileName(&ofn))
					{	if(strcmp(s,pFindFileData[1].cFileName))
						{	if(CmprFiles(hDlg,pFindFileData[0].cFileName,pFindFileData[1].cFileName))
								SetDlgItemText(hDlg,IDC_EDIT_SRC,pFindFileData[1].cFileName);
					}	}
	   				return (INT_PTR)TRUE;
				case IDC_BUTTON_BROWSE2://src
					ZeroMemory(&ofn, sizeof(ofn));
					pFindFileData[0].cFileName[0] = '\0';
					ofn.lStructSize = sizeof(ofn);
					ofn.hwndOwner = NULL; 
					ofn.lpstrFile = pFindFileData[0].cFileName; 
					ofn.nMaxFile = MAX_PATH;
					ofn.lpstrFilter = NULL;
					ofn.nFilterIndex = 1;
					ofn.lpstrTitle = strngs[7];
					ofn.lpstrInitialDir = NULL;
					ofn.lpstrCustomFilter = NULL;
					ofn.nMaxCustFilter = 0;
					ofn.lpstrFileTitle = strngs[4];
					ofn.nMaxFileTitle = 0;
					ofn.nFileOffset = 0;
					ofn.nFileExtension = 0;
					ofn.lpstrDefExt = NULL;
					ofn.lCustData = 0;
					ofn.lpfnHook = 0;
					ofn.lpTemplateName = 0;
					ofn.Flags = OFN_PATHMUSTEXIST | OFN_FILEMUSTEXIST | OFN_HIDEREADONLY |OFN_EXTENSIONDIFFERENT;
					MyStringCpy(s,MAX_PATH-1,pFindFileData[0].cFileName);
					if(GetOpenFileName(&ofn))
					{	if(strcmp(s,pFindFileData[0].cFileName))
						{	if(CmprFiles(hDlg,pFindFileData[0].cFileName,pFindFileData[1].cFileName))
								SetDlgItemText(hDlg,IDC_EDIT_SRC,pFindFileData[0].cFileName);
					}	}
					return (INT_PTR)TRUE;
				case IDOK:
					EndDialog(hDlg, 1);
					return (INT_PTR)TRUE;
				case IDCANCEL:
					EndDialog(hDlg, 0);
					return (INT_PTR)TRUE;
				case IDSTOP:
					bStop = !bStop;
					SetDlgItemText(hDlg,IDSTOP,bStop?strngs[8]:strngs[15]);
					break;
				case IDC_EDIT_SRC:
					if(EN_KILLFOCUS==HIWORD(wParam))
					{	MyStringCpy(s,MAX_PATH-1,pFindFileData[0].cFileName);
						GetDlgItemText(hDlg,IDC_EDIT_SRC,pFindFileData[0].cFileName,MAX_PATH-1);
						if(strcmp(s,pFindFileData[0].cFileName))
						{	if(!CmprFiles(hDlg,pFindFileData[0].cFileName,pFindFileData[1].cFileName))
							{	MessageBox(hDlg,pFindFileData[0].cFileName,strngs[18],MB_ICONWARNING);
								SendMessage(hDlg,WM_COMMAND,MAKELONG(IDC_BUTTON_BROWSE2,BN_CLICKED),(LPARAM)GetDlgItem(hDlg,IDC_BUTTON_BROWSE2));
					}	}	}
					break;
				case IDC_EDIT_DEST:
					if(EN_KILLFOCUS==HIWORD(wParam))
					{	MyStringCpy(s,MAX_PATH-1,pFindFileData[1].cFileName);
						GetDlgItemText(hDlg,IDC_EDIT_SRC,pFindFileData[1].cFileName,MAX_PATH-1);
						if(strcmp(s,pFindFileData[1].cFileName))
						{	if(!CmprFiles(hDlg,pFindFileData[0].cFileName,pFindFileData[1].cFileName))
							{	MessageBox(hDlg,pFindFileData[1].cFileName,strngs[18],MB_ICONWARNING);
								SendMessage(hDlg,WM_COMMAND,MAKELONG(IDC_BUTTON_BROWSE2,BN_CLICKED),(LPARAM)GetDlgItem(hDlg,IDC_BUTTON_BROWSE2));
					}	}	}
					break;
				case IDC_COMBO_DEST_PANEL:
					if(CBN_SELCHANGE==HIWORD(wParam))
					{	int l=SendMessage(GetDlgItem(hDlg,IDC_COMBO_DEST_PANEL),CB_GETCURSEL,0,0);
						MyStringCpy(s,MAX_PATH-1,pFindFileData[1].cFileName);
						getPanelCrntItem(l,&pFindFileData[1]);
						if(strcmp(s,pFindFileData[1].cFileName))
						{	if(CmprFiles(hDlg,pFindFileData[0].cFileName,pFindFileData[1].cFileName))
								SetDlgItemText(hDlg,IDC_EDIT_DEST,pFindFileData[1].cFileName);
					}	}
					break;
			}
			break;
	}
	return (INT_PTR)FALSE;
}

BOOL CheckStopBtnMsg(HWND dlg)
{
MSG msg;
	while(PeekMessage(&msg,dlg,0,0,PM_REMOVE))
		DispatchMessage(&msg);	
	return bStop;
}

//#define BUFSZ 32768
#define BUFSZ 65535
BOOL CmprFiles(HWND hDlg,char *frstFilePathAndName,char *scndFilePathAndName)
{
BOOL r=TRUE;
HANDLE f[2];
DWORD rd[2];
BY_HANDLE_FILE_INFORMATION fi[2];
DWORD *pdw[2];
char buf0[BUFSZ],buf1[BUFSZ],*pch[2];
unsigned __int64 sz,cmsz=0;
int i,dw,ch;

	SetDlgItemText(hDlg,IDC_EDIT_INFO,"....");

	f[0]=CreateFile(frstFilePathAndName,GENERIC_READ,FILE_SHARE_READ,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_READONLY,NULL);
	if(INVALID_HANDLE_VALUE==f[0])
	{	SetDlgItemText(hDlg,IDC_EDIT_INFO,strngs[5]);
		EnableWindow(GetDlgItem(hDlg,IDOK),TRUE);
		return FALSE;
	}
	f[1]=CreateFile(scndFilePathAndName,GENERIC_READ,FILE_SHARE_READ,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_READONLY,NULL);
	if(INVALID_HANDLE_VALUE==f[1])
	{	CloseHandle(f[0]);
		SetDlgItemText(hDlg,IDC_EDIT_INFO,strngs[6]);
		EnableWindow(GetDlgItem(hDlg,IDOK),TRUE);
		return FALSE;
	}
	if(!GetFileInformationByHandle(f[0],&fi[0])) {r=FALSE;goto End;}
	if(!GetFileInformationByHandle(f[1],&fi[1])) {r=FALSE;goto End;}
	if(fi[0].nFileSizeHigh!=fi[1].nFileSizeHigh) {r=FALSE;goto End;}
	if(fi[0].nFileSizeLow!=fi[1].nFileSizeLow)   {r=FALSE;goto End;}
	sz = ((unsigned __int64)fi[0].nFileSizeHigh<<32) | fi[0].nFileSizeLow;
	sz /= 4;
	do
	{	if(ReadFile(f[0],buf0,BUFSZ,&rd[0],NULL) != ReadFile(f[1],buf1,BUFSZ,&rd[1],NULL) )
		   {r=FALSE;goto End;}
		if(rd[0]!=rd[1]) {r=FALSE;goto End;}
		dw=rd[0]/4; ch=rd[0]%4;
		pdw[0]=(DWORD*)buf0; pdw[1]=(DWORD*)buf1;
		for(i=0; i<dw; i++)
		{	if((*pdw[0]) != (*pdw[1])) {r=FALSE;goto End;}
			++pdw[0]; ++pdw[1];
		}
		cmsz += dw;
		PostMessage(GetDlgItem(hDlg,IDC_PROGRESS_COMPARE),PBM_SETPOS,(int)(100.0f*cmsz/sz),0);
		if(CheckStopBtnMsg(hDlg)) {r=FALSE;goto End;}
		pch[0]=(char*)pdw[0]; pch[1]=(char*)pdw[1];
		for(i=0; i<ch; i++)
		{	if((*pch[0]) != (*pch[1])) {r=FALSE;goto End;}
			++pch[0]; ++pch[1];
		}
	} while(rd[0] && rd[0]==rd[1]);
End:
	CloseHandle(f[0]);CloseHandle(f[1]);
	SetDlgItemText(hDlg,IDC_EDIT_INFO,r?strngs[11]:strngs[12]);
	EnableWindow(GetDlgItem(hDlg,IDOK),!r);
	return r;
}

BOOL Resize(HWND dlg,int x,int y)
{
int wScrl,h;//w;
RECT rc;
HWND chld;//=GetDlgItem(dlg,IDOK);
//GetClientRect(dlg,&rc);
//x=rc.right-rc.left;y=rc.bottom-rc.top;
x-=2;y-=2;
//GetWindowRect(chld,&rc);
//	w=rc.right-rc.left;	h=rc.bottom-rc.top;
//	MoveWindow(chld,x-75,y-22,w,h,TRUE);
	
	chld=GetDlgItem(dlg,IDC_VERT_SCROLLBAR);
	GetWindowRect(chld,&rc);
	wScrl=rc.right-rc.left;	h=rc.bottom-rc.top;
	MoveWindow(chld,x/2-wScrl/2,2,wScrl,y,TRUE);

	chld=GetDlgItem(dlg,IDC_EDIT_SRC_NAME);
	GetWindowRect(chld,&rc);
	MoveWindow(chld,0,0,(int)(0.5*x-wScrl/2),20,TRUE);
	
	chld=GetDlgItem(dlg,IDC_EDIT_DEST_NAME);
	MoveWindow(chld,(int)(0.5*x+wScrl/2),0,(int)(0.5*x-wScrl/2),20,TRUE);

	chld=GetDlgItem(dlg,IDC_EDIT_SRC);
	MoveWindow(chld,(int)(0.07*x),20,(int)(0.43*x-wScrl/2),y-22,TRUE);
	
	chld=GetDlgItem(dlg,IDC_EDIT_DEST);
	MoveWindow(chld,(int)(0.5*x+wScrl/2),20,(int)(0.43*x-wScrl/2),y-22,TRUE);

	chld=GetDlgItem(dlg,IDC_EDIT_SRC_ADDR);
	GetWindowRect(chld,&rc);
	MoveWindow(chld,0,20,(int)(0.07*x),y-22,TRUE);	

	chld=GetDlgItem(dlg,IDC_EDIT_DEST_ADDR);
	MoveWindow(chld,(int)(0.93*x),20,(int)(0.07*x),y-22,TRUE);	

	return TRUE;
}

INT_PTR CALLBACK Cmpr2FilesDlgProc(hDlg,message,wParam,lParam)
HWND hDlg;
UINT message;
WPARAM wParam;
LPARAM lParam;
{	//static int i=0;
	//char ss[32];sprintf(ss,"\n %d ",i++);
	//OutputDebugString(ss);
	//OutputDebugString(GetWinNotifyText(message));
	//sprintf(ss," %x %x",wParam,lParam);
	//OutputDebugString(ss);
int  left,top,width,height;
RECT  rc,rc1;
HMENU hm;
MENUITEMINFO mi;
	switch(message)
	{	case WM_INITDIALOG:
			GetWindowRect(hDlg, &rc1);
			HWND prnt;prnt = GetParent(hDlg);
			if(!prnt)prnt=GetDesktopWindow();
			GetWindowRect(prnt, &rc);
			width = rc1.right - rc1.left;		
			left = rc.left + (rc.right - rc.left - width)/2;//left = (GetSystemMetrics(SM_CXFULLSCREEN) - width)/2;
			height = rc1.bottom - rc1.top;
			top = rc.top + (rc.bottom - rc.top - height)/2;//top = (GetSystemMetrics(SM_CYFULLSCREEN) - height)/2;
			MoveWindow(hDlg, left, top+20, width, height, TRUE);
			//Load language strings:
			SetWindowText(hDlg,strngs[0]);
			//SetDlgItemText(hDlg,IDOK,strngs[21]);
			hm = GetMenu(hDlg);
			if(!hm) return FALSE;
			mi.cbSize = sizeof(MENUITEMINFO);
			mi.fMask=MIIM_STRING; mi.fType=MFT_STRING;
			mi.dwTypeData = strngs[15];SetMenuItemInfo(hm,ID_ADDRESSMODE_HEX,FALSE,&mi);
			mi.dwTypeData = strngs[16];SetMenuItemInfo(hm,ID_ADDRESSMODE_DEC,FALSE,&mi);
			mi.dwTypeData = strngs[17];SetMenuItemInfo(hm,ID_EDITMODE_BINARY,FALSE,&mi);
			mi.dwTypeData = strngs[13];SetMenuItemInfo(hm,0,TRUE,&mi);
			mi.dwTypeData = strngs[14];SetMenuItemInfo(hm,1,TRUE,&mi);
			mi.dwTypeData = strngs[18];SetMenuItemInfo(hm,2,TRUE,&mi);
			SetDlgItemText(hDlg,IDC_EDIT_SRC_NAME,pFindFileData[0].cFileName);
			SetDlgItemText(hDlg,IDC_EDIT_DEST_NAME,pFindFileData[1].cFileName);
			hSrc = CreateWindowEx(WS_EX_LEFT|WS_EX_CLIENTEDGE,
							"Source file compare window",
							panWindText,
							WS_GROUP|WS_VISIBLE | WS_CLIPSIBLINGS | WS_TABSTOP |
							WS_CHILDWINDOW,//See AdjustHorScrollity | WS_HSCROLL,
							x,
							y,
							w,
							h,
							hDlg,
							NULL,
							inst,
							(LPVOID)panelNumber);
	if(NULL==hwnd) return FALSE;


		HDC dcSrc=GetDC(GetDlgItem(dlg,IDC_EDIT_SRC)),
	dcDest=GetDC(GetDlgItem(dlg,IDC_EDIT_DEST)),
	dcSrcAddr=GetDC(GetDlgItem(dlg,IDC_EDIT_SRC_ADDR)),
	dcDestAddr=GetDC(GetDlgItem(dlg,IDC_EDIT_DEST_ADDR));

			//Resize(hDlg,width,height);
			Draw(hDlg);
			break;
		case WM_SIZE:
			Resize(hDlg,LOWORD(lParam),HIWORD(lParam));
			break;
		case WM_PAINT:
			//hdc = BeginPaint(hwnd, &ps); 
			//Draw(hDlg);
            //EndPaint(hwnd, &ps); 
			break;
		case WM_COMMAND:
			switch(LOWORD(wParam))
			{	case IDCANCEL:
					EndDialog(hDlg, 0);
					return (INT_PTR)TRUE;
			}
			break;
	}
	return (INT_PTR)FALSE;
}

BOOL Draw(HWND dlg)
{
int w;
unsigned char *pch[2];
unsigned __int64 sz[2],szCrnt[2];
char buf0[BUFSZ],buf1[BUFSZ];
RECT rcSrc={0,0,14,14},rcDest={0,0,14,14},rcSrcAddr={0,0,14,14},rcDestAddr={0,0,14,14};
BOOL r=FALSE; HANDLE f[2]={0,0};
DWORD i,rd[2];
BY_HANDLE_FILE_INFORMATION fi[2];
HDC dcSrc=GetDC(GetDlgItem(dlg,IDC_EDIT_SRC)),
	dcDest=GetDC(GetDlgItem(dlg,IDC_EDIT_DEST)),
	dcSrcAddr=GetDC(GetDlgItem(dlg,IDC_EDIT_SRC_ADDR)),
	dcDestAddr=GetDC(GetDlgItem(dlg,IDC_EDIT_DEST_ADDR));

	if((!dcSrc) || (!dcDest) || (!dcSrcAddr) || (!dcDestAddr)) goto End;
	f[0]=CreateFile(pFindFileData[0].cFileName,GENERIC_READ,FILE_SHARE_READ,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_READONLY,NULL);
	if(INVALID_HANDLE_VALUE==f[0]) goto End;
	f[1]=CreateFile(pFindFileData[1].cFileName,GENERIC_READ,FILE_SHARE_READ,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_READONLY,NULL);
	if(INVALID_HANDLE_VALUE==f[1]) goto End;

	if(!GetFileInformationByHandle(f[0],&fi[0])) {r=FALSE;goto End;}
	if(!GetFileInformationByHandle(f[1],&fi[1])) {r=FALSE;goto End;}
	sz[0] = ((unsigned __int64)fi[0].nFileSizeHigh<<32) | fi[0].nFileSizeLow;
	sz[1] = ((unsigned __int64)fi[1].nFileSizeHigh<<32) | fi[1].nFileSizeLow;

	w=GetDeviceCaps(dcSrc,LOGPIXELSX);//HORZSIZE);

	//SendMessage(hWndEditCons,EM_REPLACESEL, (WPARAM)FALSE, (LPARAM)(LPCSTR)buf);
	//SendMessage(hWndEditCons,EM_REPLACESEL, (WPARAM)FALSE, (LPARAM)(LPCSTR)RetCar);
	//SendMessage(hWndEditCons,EM_SCROLLCARET, (WPARAM)0, (LPARAM)0);

	DrawText(dcSrcAddr,"000000",1,&rcSrcAddr,DT_CENTER);
	DrawText(dcDestAddr,"000000",1,&rcDestAddr,DT_CENTER);

/*	rd[0]=rd[1]=1;szCrnt[0]=szCrnt[1]=0;
	do
	{	if(rd[0])ReadFile(f[0],buf0,BUFSZ,&rd[0],NULL);
		if(rd[1])ReadFile(f[1],buf1,BUFSZ,&rd[1],NULL);
		pch[0]=(unsigned char*)buf0; pch[1]=(unsigned char*)buf1;
		for(i=0; i<(rd[0]<rd[1]?rd[0]:rd[1]); i++)
		{	BOOL bEqu=((*pch[0]) == (*pch[1]));
			char s[2]={*pch[0],0};
			DrawText(dcSrc,s,1,&rcSrc,DT_CENTER);
			s[0]=*pch[1];
			DrawText(dcDest,s,1,&rcSrc,DT_CENTER);
			rcSrc.left += 14;
			++pch[0];++pch[1];
			if(rcSrc.left >= w)
			{	char s[16];
				rcSrc.left  = 0; rcSrc.bottom  += 14; rcSrc.top  += 14;
				StringCchPrintf(s,15,"%5d",i);
				rcSrcAddr.top += 14; rcSrcAddr.bottom += 14;
				DrawText(dcSrcAddr,s,1,&rcSrcAddr,DT_CENTER);
				//DrawText(dcDest,s,1,&rcSrcAddr,DT_CENTER);
		}	}
		szCrnt[0]=szCrnt[1]=i;
		rcDest = rcSrc;
		rcDestAddr = rcSrcAddr;
		break;
		//if(rd[0]) DrawSrc();
		//if(rd[1]) DrawDest();		
	} while(rd[0] && rd[1]);*/
End:
	if(f[0])CloseHandle(f[0]);if(f[1])CloseHandle(f[1]);
	if(dcSrc)ReleaseDC(GetDlgItem(dlg,IDC_EDIT_SRC),dcSrc);
	if(dcDest)ReleaseDC(GetDlgItem(dlg,IDC_EDIT_DEST),dcDest);
	if(dcSrcAddr)ReleaseDC(GetDlgItem(dlg,IDC_EDIT_SRC),dcSrcAddr);
	if(dcDestAddr)ReleaseDC(GetDlgItem(dlg,IDC_EDIT_DEST),dcDestAddr);
	return r;
}