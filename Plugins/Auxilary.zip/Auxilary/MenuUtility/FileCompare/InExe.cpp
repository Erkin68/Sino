#include "windows.h"
#include "resource.h"
#include "strsafe.h"
#include "shlobj.h"
#include "ShiftedFile.h"

#define CHRW 12
#define CHRH 16

HMODULE plgnDllInst;

INT_PTR CALLBACK Cmpr2FilesDlgProc(HWND,UINT,WPARAM,LPARAM);
BOOL Resize(HWND,int,int);
BOOL Draw(HWND);
BOOL Scroll(HWND,int,WORD);

SftdFile fSrc(65535);
SftdFile fDst(65535);

HBRUSH whteBrsh;HFONT fnt=0;
RECT rcSrc,rcSrcAddr;//src va dest, srcAddr, destAddr rect i;
WIN32_FIND_DATA pFindFileData[2];//2 ta fayl nomlar;
HWND hSrc,hSrcAddr,hDest,hDestAddr;//Ishlatgan kontrollar HWND si;
DWORD MINFILEMAPSZ=65535;//#define MINFILEMAPSZ 65535//mapfile std hajmi, bundan kam ham bo'lishi mumkin;
int widthSrc,heightSrc,//hSrc va hDest ning pixellardagi eni va balandligi;
	iHorChars,iVerChars;//Tepadaginign o'zi, faqat charlarda;
WORD scrlPos=0;//O'rtadagi vert scroll posi,0 dan 65535 gachon;
unsigned __int64 fCrntOffst;//tepadan 1-qator offseti,faylning to'liq shkaladagi posi, mapdagi fMapOffst ga ekvivalent;
__int64 totLines=0,iTotScrlLines=0;//map qilingan ozudan boshlab scroll liniyasi, iHorChars ga k'opaytirsak, charlarni beradir;

int __stdcall WinMain(HINSTANCE hInstance,HINSTANCE hPrevInstance,LPSTR lpCmdLine,int nShowCmnd)
{
LOGFONT lf;int r=0;
	plgnDllInst = hInstance;
	//MyStringCpy(pFindFileData[0].cFileName,MAX_PATH-1,"d:\\temp\\SinoDbg.exe");//"d:\\Install\\Disk Images\\3D���������_1.nrg");
	//MyStringCpy(pFindFileData[1].cFileName,MAX_PATH-1,"d:\\temp\\common.c");
	MyStringCpy(pFindFileData[0].cFileName,MAX_PATH-1,"d:\\temp\\CharacterDbg.lib");
	MyStringCpy(pFindFileData[1].cFileName,MAX_PATH-1,"d:\\temp\\2DScreenRel.lib");

	InitLOGFONT(&lf,0);
	fnt=CreateFontIndirect(&lf);
	whteBrsh=CreateSolidBrush(RGB(255,255,255));

	if(!fSrc.Open(pFindFileData[0].cFileName)) goto End;
	if(!fDst.Open(pFindFileData[1].cFileName)) goto End;

	//GetSystemInfo(&si);MINFILEMAPSZ=si.dwAllocationGranularity;
	fCrntOffst=0;//fMapOffst[0]=fMapOffst[1]=

	r=DialogBox(hInstance,MAKEINTRESOURCE(IDD_DIALOG_CMP_TWO_FILES),NULL,Cmpr2FilesDlgProc);
/*	r=CreateDialog(hInstance,MAKEINTRESOURCE(IDD_DIALOG_CMP_TWO_FILES),NULL,Cmpr2FilesDlgProc);
	ShowWindow(r,SW_SHOW);

	while(1)
	{	if(PeekMessage(&msg, NULL, 0U, 0U, PM_REMOVE))
		{	//if(!ProcessMessage(&msg))    !!!!!!!!
				TranslateMessage(&msg);//Agar olib tashlasang, EDIT lar ishlamaydur!!!!
				DispatchMessage(&msg);
			if(msg.hwnd==r && WM_CLOSE==msg.message)
				Beep(0,0);
	}	}*/

End:
	fSrc.Close();
	fDst.Close();
	if(fnt)DeleteObject(fnt);
	if(whteBrsh)DeleteObject(whteBrsh);
	return r;
}

BOOL Resize(HWND dlg,int x,int y)
{
//x-=2;y-=2;
int addrBarWidth;
RECT rc;GetClientRect(dlg,&rc);
x=rc.right-rc.left;y=rc.bottom-rc.top;
	if(!x) return FALSE; if(!y) return FALSE;
	if(x<7) x=7;if(y<20)y=20;
	addrBarWidth=(int)(0.65*CHRW*(fSrc.GetSizeDecWidth()>fDst.GetSizeDecWidth()?fSrc.GetSizeDecWidth():fDst.GetSizeDecWidth()));

	MoveWindow(GetDlgItem(dlg,IDC_VERT_SCROLLBAR),x/2-7,0,18,y,TRUE);
	MoveWindow(GetDlgItem(dlg,IDC_EDIT_SRC_NAME),0,0,(int)(0.5*x-7),20,TRUE);
	MoveWindow(GetDlgItem(dlg,IDC_EDIT_DEST_NAME),(int)(0.5*x+10),0,(int)(0.5*x-7),20,TRUE);	
	
	MoveWindow(hSrcAddr,0,20,addrBarWidth,y-20,TRUE);	
	MoveWindow(hDestAddr,(int)(x-addrBarWidth),20,addrBarWidth,y-20,TRUE);
	MoveWindow(hSrc,addrBarWidth,20,(int)(0.5*x-addrBarWidth-6),y-20,TRUE);
	MoveWindow(hDest,(int)(0.5*x+9),20,(int)(0.5*x-addrBarWidth-6),y-20,TRUE);

	GetClientRect(hSrcAddr,&rcSrcAddr);
	GetClientRect(hSrc,&rcSrc);
	widthSrc=rcSrc.right-rcSrc.left;
	heightSrc=rcSrc.bottom-rcSrc.top;

	iHorChars = widthSrc / CHRW;
	iVerChars = heightSrc / CHRH;
	if(heightSrc % CHRH > 0) ++iVerChars;
	if(iHorChars<1)iHorChars=1;

	if(fSrc.GetSize()>fDst.GetSize())
	{	totLines = fSrc.GetSize() / iHorChars;
		if(fSrc.GetSize() % iHorChars > 0)
			++totLines;
		totLines -= iVerChars;
		scrlPos=(WORD)(65535*fCrntOffst/fSrc.GetSize());
		SendMessage(GetDlgItem(dlg,IDC_VERT_SCROLLBAR),(UINT)SBM_SETPOS,scrlPos,FALSE);		
	}
	else //if(sz[0]>sz[1])
	{	totLines = fDst.GetSize() / iHorChars;
		if(fDst.GetSize() % iHorChars > 0)
			++totLines;
		totLines -= iVerChars;
		scrlPos=(WORD)(65535*fCrntOffst/fDst.GetSize());
		SendMessage(GetDlgItem(dlg,IDC_VERT_SCROLLBAR),(UINT)SBM_SETPOS,scrlPos,FALSE);		
	}
	return TRUE;
}

INT_PTR CALLBACK SmplChldDlgProc(HWND hDlg,UINT message,WPARAM wParam,LPARAM lParam)
{
	switch(message)
	{	case WM_PAINT: return 0;
		//case WM_ERASEBKGND:
		//	return 1;
	}
	return DefWindowProc(hDlg,message,wParam,lParam);
}

INT_PTR CALLBACK Cmpr2FilesDlgProc(HWND hDlg,UINT message,WPARAM wParam,LPARAM lParam)
{	
int  left,top,width,height;
RECT  rc,rc1;//HMENU hm;
//MENUITEMINFO mi;
HWND prnt;WNDCLASSEX wcex;
	//static int i=0;
	//char ss[32];sprintf(ss,"\n %d ",i++);
	//OutputDebugString(ss);
	//OutputDebugString(GetWinNotifyText(message));
	//sprintf(ss," %x %x",wParam,lParam);
	//OutputDebugString(ss);
	switch(message)
	{	case WM_INITDIALOG:
			GetWindowRect(hDlg, &rc1);
			prnt = GetParent(hDlg);
			if(!prnt)prnt=GetDesktopWindow();
			GetWindowRect(prnt, &rc);
			width = rc1.right - rc1.left;		
			left = rc.left + (rc.right - rc.left - width)/2;//left = (GetSystemMetrics(SM_CXFULLSCREEN) - width)/2;
			height = rc1.bottom - rc1.top;
			top = rc.top + (rc.bottom - rc.top - height)/2;//top = (GetSystemMetrics(SM_CYFULLSCREEN) - height)/2;
			MoveWindow(hDlg, left, top+20, width, height, TRUE);
			//Load language strings:
			/*SetWindowText(hDlg,strngs[0]);
			SetDlgItemText(hDlg,IDOK,strngs[21]);
			hm = GetMenu(hDlg);
			if(!hm) return FALSE;
			mi.cbSize = sizeof(MENUITEMINFO);
			mi.fMask=MIIM_STRING; mi.fType=MFT_STRING;
			mi.dwTypeData = strngs[15];SetMenuItemInfo(hm,ID_ADDRESSMODE_HEX,FALSE,&mi);
			mi.dwTypeData = strngs[16];SetMenuItemInfo(hm,ID_ADDRESSMODE_DEC,FALSE,&mi);
			mi.dwTypeData = strngs[17];SetMenuItemInfo(hm,ID_EDITMODE_BINARY,FALSE,&mi);
			mi.dwTypeData = strngs[13];SetMenuItemInfo(hm,0,TRUE,&mi);
			mi.dwTypeData = strngs[CHRW];SetMenuItemInfo(hm,1,TRUE,&mi);
			mi.dwTypeData = strngs[18];SetMenuItemInfo(hm,2,TRUE,&mi);*/
			SendMessage(GetDlgItem(hDlg,IDC_EDIT_SRC_NAME),WM_SETFONT,(WPARAM)fnt,0);
			SendMessage(GetDlgItem(hDlg,IDC_EDIT_DEST_NAME),WM_SETFONT,(WPARAM)fnt,0);
			SetDlgItemText(hDlg,IDC_EDIT_SRC_NAME,pFindFileData[0].cFileName);
			SetDlgItemText(hDlg,IDC_EDIT_DEST_NAME,pFindFileData[1].cFileName);
			SetScrollRange(GetDlgItem(hDlg,IDC_VERT_SCROLLBAR),SB_CTL,0,65535,TRUE);//sz[0]>sz[1]?(sz[0]/32):(sz[1]/32)

			wcex.cbSize = sizeof(WNDCLASSEX);
			wcex.style			= CS_HREDRAW|CS_VREDRAW|CS_OWNDC;
			wcex.lpfnWndProc	= (WNDPROC)SmplChldDlgProc;
			wcex.cbClsExtra		= 0;
			wcex.cbWndExtra		= 0;//sizeof(HANDLE);
			wcex.hInstance		= plgnDllInst;
			wcex.hIcon			= NULL;
			wcex.hCursor		= LoadCursor(NULL, IDC_ARROW);
			wcex.hbrBackground	= whteBrsh;//(HBRUSH)GetStockObject(WHITE_BRUSH);
			wcex.lpszMenuName	= NULL;
			wcex.lpszClassName	= "Source file compare window class";
			wcex.hIconSm		= NULL;
			RegisterClassEx(&wcex);
			hSrcAddr = CreateWindowEx(WS_EX_CLIENTEDGE,
							"Source file compare window class",
							"Source file compare window",
							WS_VISIBLE|WS_CHILD,
							0,
							20,
							54,
							402,
							hDlg,
							NULL,
							plgnDllInst,
							(LPVOID)1);
			if(NULL==hSrcAddr) {/*msg(0,strngs[]);*/EndDialog(hDlg,0);return FALSE;}
			hSrc = CreateWindowEx(WS_EX_CLIENTEDGE,
							"Source file compare window class",
							"Source file compare window",
							WS_VISIBLE|WS_CHILD,
							54,
							20,
							325,
							402,
							hDlg,
							NULL,
							plgnDllInst,
							(LPVOID)2);
			if(NULL==hSrc) {/*msg(0,strngs[]);*/EndDialog(hDlg,0);return FALSE;}
			hDest = CreateWindowEx(WS_EX_CLIENTEDGE,
							"Source file compare window class",
							"Source file compare window",
							WS_VISIBLE|WS_CHILD,
							398,
							20,
							325,
							402,
							hDlg,
							NULL,
							plgnDllInst,
							(LPVOID)3);
			if(NULL==hDest) {/*msg(0,strngs[]);*/EndDialog(hDlg,0);return FALSE;}
			hDestAddr = CreateWindowEx(WS_EX_CLIENTEDGE,
							"Source file compare window class",
							"Source file compare window",
							WS_VISIBLE|WS_CHILD,
							724,
							20,
							54,
							402,
							hDlg,
							NULL,
							plgnDllInst,
							(LPVOID)3);
			if(NULL==hDestAddr) {/*msg(0,strngs[]);*/EndDialog(hDlg,0);return FALSE;}
			SetFocus(hSrc);
			Resize(hDlg,width,height);
			Draw(hDlg);
			break;
		case WM_SIZE:
			Resize(hDlg,LOWORD(lParam),HIWORD(lParam));
			break;
		case WM_PAINT:
			//hdc = BeginPaint(hwnd, &ps); 
			Draw(hDlg);
            //EndPaint(hwnd, &ps); 
			break;
		case WM_MOUSEWHEEL:
			//if(MK_MBUTTON==LOWORD(wParam))
			SendMessage(hDlg,WM_VSCROLL,GET_WHEEL_DELTA_WPARAM(wParam)<0?SB_PAGERIGHT:SB_PAGELEFT,0);
			break;
		/*case WM_KEYDOWN:  focus avtomaticheski scrollga o'tib olarkan o'zi;
			switch(wParam)
			{	case VK_DOWN:
					if(Scroll(hDlg,1,0))
						SendMessage(GetDlgItem(hDlg,IDC_VERT_SCROLLBAR),(UINT)SBM_SETPOS,scrlPos,FALSE);
					break;
				case VK_UP:
					if(Scroll(hDlg,2,0))
						SendMessage(GetDlgItem(hDlg,IDC_VERT_SCROLLBAR),(UINT)SBM_SETPOS,scrlPos,FALSE);
					break;
				case VK_PRIOR:
					if(Scroll(hDlg,3,0))
						SendMessage(GetDlgItem(hDlg,IDC_VERT_SCROLLBAR),(UINT)SBM_SETPOS,scrlPos,FALSE);
					break;
				case VK_NEXT:
					if(Scroll(hDlg,4,0))
						SendMessage(GetDlgItem(hDlg,IDC_VERT_SCROLLBAR),(UINT)SBM_SETPOS,scrlPos,FALSE);
					break;
			}
			break;*/
		case WM_VSCROLL:
			if(SB_THUMBPOSITION==LOWORD(wParam) ||SB_THUMBTRACK==LOWORD(wParam))
			{	if(Scroll(hDlg,0,HIWORD(wParam)))//,oldScrlPos>scrlPos);
					SendMessage(GetDlgItem(hDlg,IDC_VERT_SCROLLBAR),(UINT)SBM_SETPOS,scrlPos,FALSE);
			}
			else
			{	BOOL r=FALSE;
				if(SB_LINELEFT==LOWORD(wParam))
					r=Scroll(hDlg,1,0);
				else if(SB_LINERIGHT==LOWORD(wParam))
					r=Scroll(hDlg,2,0);
				else if(SB_PAGELEFT==LOWORD(wParam))
					r=Scroll(hDlg,3,0);
				else if(SB_PAGERIGHT==LOWORD(wParam))
					r=Scroll(hDlg,4,0);
				if(r)SendMessage(GetDlgItem(hDlg,IDC_VERT_SCROLLBAR),(UINT)SBM_SETPOS,scrlPos,TRUE);
			}
			break;
		case WM_COMMAND:
			switch(LOWORD(wParam))
			{	case IDCANCEL:
					EndDialog(hDlg, 0);
					return (INT_PTR)TRUE;
			}
			break;
	}
	return (INT_PTR)FALSE;
}

CONST INT spc[128]={CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW,CHRW};
BOOL Draw(HWND dlg)
{
char s[32];int i,k;
unsigned __int64 FCrntOffst=fCrntOffst;//tepadan 1-qator offseti,faylning to'liq shkaladagi posi, mapdagi fMapOffst ga ekvivalent;
BOOL r=FALSE;
HDC dcSrc=GetDC(hSrc);
HDC dcDest=GetDC(hDest);
HDC	dcSrcAddr=GetDC(hSrcAddr);
HDC dcDestAddr=GetDC(hDestAddr);
HGDIOBJ oldSrcAddrFnt,oldSrcFnt,oldDestFnt,oldDestAddrFnt;

RECT rSrcAddr = rcSrcAddr;
RECT rSrc = rcSrc;

	if((!dcSrc) || (!dcDest) || (!dcSrcAddr) || (!dcDestAddr)) return FALSE;
	oldSrcAddrFnt=SelectObject(dcSrcAddr,fnt);
	oldSrcFnt=SelectObject(dcSrc,fnt);
	oldDestFnt=SelectObject(dcDest,fnt);
	oldDestAddrFnt=SelectObject(dcDestAddr,fnt);
	//SetBkColor(dcSrcAddr,RGB(235,235,255));SetBkColor(dcSrc,RGB(245,245,255));SetBkColor(dcDest,RGB(245,235,255));SetBkColor(dcDestAddr,RGB(245,245,255));

	FillRect(dcSrc,&rSrc,whteBrsh);FillRect(dcSrcAddr ,&rSrcAddr,whteBrsh);FillRect(dcDestAddr ,&rSrcAddr,whteBrsh);
	rSrcAddr.top = 0; rSrcAddr.bottom = 25; rSrcAddr.left = 0;//(LONG)(0.136f*widthSrc)-szDecPosLn[0]*CHRH+64;
	rSrc.left=0;rSrc.right=0;rSrc.top=0;rSrc.bottom=CHRH;//GetClientRect(hSrc,&rSrc);

	SetTextColor(dcSrcAddr,RGB(0,0,155));SetTextColor(dcDestAddr,RGB(0,0,155));
//	SetTextColor(dcSrc,RGB(0,0,0));	SetTextColor(dcDest,RGB(0,0,0));
	SetTextColor(dcSrc,RGB(0,0,0));
	SetTextColor(dcDest,RGB(0,0,0));

	//2-la siyam bor bo'lgan zona:
	unsigned char *pCh[2];int ln[2];
	for(i=0; i<iVerChars; i++)
	{	ln[0]=fSrc.Read(&FCrntOffst,iHorChars,(void**)&pCh[0]);
		ln[1]=fDst.Read(&FCrntOffst,iHorChars,(void**)&pCh[1]);
		if(ln[0]<=0 || ln[1]<=0) break;

		StringCchPrintf(s,15,fSrc.GetOffsetStrFormat(),FCrntOffst);
		if(ln[0])ExtTextOut(dcSrcAddr,rSrcAddr.left,rSrcAddr.top,ETO_OPAQUE,NULL,s,fSrc.GetSizeDecWidth(),NULL);
		if(ln[1])ExtTextOut(dcDestAddr,rSrcAddr.left,rSrcAddr.top,ETO_OPAQUE,NULL,s,fDst.GetSizeDecWidth(),NULL);
		rSrcAddr.top += CHRH; rSrcAddr.bottom += CHRH;
		
		rSrc.left = 0; rSrc.right = CHRW;
		for(k=0; k<iHorChars; k++)
		{	BOOL bEqu=FALSE;int iLocEqu=1;
			if(ln[0]==ln[1])
			{	bEqu=((*pCh[0]) == (*pCh[1]));
				while(bEqu ? (pCh[0][iLocEqu]==pCh[1][iLocEqu]) : (pCh[0][iLocEqu]!=pCh[1][iLocEqu]))
				{	if(rSrc.right+CHRW > widthSrc-1) break;
					++k;++iLocEqu;
					rSrc.right += CHRW;
			}	}
			if(!bEqu){SetTextColor(dcSrc,RGB(255,0,0));SetTextColor(dcDest,RGB(255,0,0));}
			if(ln[0]>k)
				ExtTextOut(dcSrc ,rSrc.left,rSrc.top,ETO_OPAQUE,&rSrc,(LPCSTR)pCh[0],iLocEqu,spc);
			if(ln[1]>k)
				ExtTextOut(dcDest,rSrc.left,rSrc.top,ETO_OPAQUE,&rSrc,(LPCSTR)pCh[1],iLocEqu,spc);
			if(!bEqu){SetTextColor(dcSrc,RGB(0,0,0));SetTextColor(dcDest,RGB(0,0,0));}
			rSrc.left += CHRW*iLocEqu; rSrc.right+= CHRW*iLocEqu;
			pCh[0]+=iLocEqu; pCh[1]+=iLocEqu; FCrntOffst+=iLocEqu;
		}
		rSrc.top += CHRH; rSrc.bottom+= CHRH;
		if((iHorChars!=ln[0]) || (iHorChars!=ln[1])) break;
	}
	SetTextColor(dcSrc,RGB(255,0,0));SetTextColor(dcDest,RGB(255,0,0));
	rSrc.left = 0; rSrc.right = CHRW*iHorChars;

	if(fSrc.GetSize()>fDst.GetSize())
	{	for(k=i; k<iVerChars; k++)
		{	ln[0]=fSrc.Read(&FCrntOffst,iHorChars,(void**)&pCh[0]);
			if(!ln[0]) break;
			StringCchPrintf(s,15,fSrc.GetOffsetStrFormat(),FCrntOffst);
			ExtTextOut(dcSrcAddr,rSrcAddr.left,rSrcAddr.top,ETO_OPAQUE,NULL,s,fSrc.GetSizeDecWidth(),NULL);
			ExtTextOut(dcSrc,rSrc.left,rSrc.top,ETO_OPAQUE,&rSrc,(LPCSTR)pCh[0],ln[0],spc);
			rSrcAddr.top += CHRH; rSrcAddr.bottom += CHRH;
			rSrc.top += CHRH; rSrc.bottom+= CHRH;
			FCrntOffst += iHorChars;
	}	}
	else
	{	for(k=i; k<iVerChars; k++)
		{	ln[1]=fDst.Read(&FCrntOffst,iHorChars,(void**)&pCh[1]);
			if(!ln[1]) break;
			StringCchPrintf(s,15,fDst.GetOffsetStrFormat(),FCrntOffst);
			ExtTextOut(dcDestAddr,rSrcAddr.left,rSrcAddr.top,ETO_OPAQUE,NULL,s,fDst.GetSizeDecWidth(),NULL);
			ExtTextOut(dcDest,rSrc.left,rSrc.top,ETO_OPAQUE,&rSrc,(LPCSTR)pCh[1],ln[1],spc);
			rSrcAddr.top += CHRH; rSrcAddr.bottom += CHRH;
			rSrc.top += CHRH; rSrc.bottom+= CHRH;
			FCrntOffst += iHorChars;
	}	}

	RedrawWindow(hSrcAddr,NULL,NULL,RDW_NOINTERNALPAINT|RDW_VALIDATE);
	RedrawWindow(hSrc,NULL,NULL,RDW_NOINTERNALPAINT|RDW_VALIDATE);
	RedrawWindow(hDest,NULL,NULL,RDW_NOINTERNALPAINT|RDW_VALIDATE);
	RedrawWindow(hDestAddr,NULL,NULL,RDW_NOINTERNALPAINT|RDW_VALIDATE);
	SelectObject(dcSrcAddr,oldSrcAddrFnt);
	SelectObject(dcSrc,oldSrcFnt);
	SelectObject(dcDest,oldDestFnt);
	SelectObject(dcDestAddr,oldDestAddrFnt);
	if(dcSrcAddr)ReleaseDC(hSrcAddr,dcSrcAddr);
	if(dcSrc)ReleaseDC(hSrc,dcSrc);
	if(dcDest)ReleaseDC(hDest,dcDest);
	if(dcDestAddr)ReleaseDC(hDestAddr,dcDestAddr);
	return r;
}

BOOL Scroll(HWND hDlg,int type,WORD lParam)//,BOOL bToPrev)//else to next (it means down);
{
__int64 oldLines=iTotScrlLines;

	switch(type)
	{	case 0://ushlab tortgan,lParam ishladur;
			if(lParam>scrlPos)
			{	if(65535==lParam)iTotScrlLines=totLines;
				else iTotScrlLines += (lParam-scrlPos)*totLines/65535;
			}
			else if(lParam<scrlPos)
			{	if(0==lParam)iTotScrlLines=0;
				else iTotScrlLines -= (scrlPos-lParam)*totLines/65535;
			}
			break;
		case 1: --iTotScrlLines; break;//tepaga 1 ta;
		case 2:	++iTotScrlLines; break;//pastga 1 ta
		case 3://tepag 1 bet;
			if(iVerChars<1) break;
			iTotScrlLines-=iVerChars-1;
			break;
		case 4://pastga 1 bet;
			if(iVerChars<1) break;
			iTotScrlLines+=iVerChars-1;
			//else break;
			break;
	}//div_t div_result = div(totLines*scrlPos,65535);
	if(iTotScrlLines<0)iTotScrlLines=0;
	else if(iTotScrlLines>totLines)iTotScrlLines=totLines;
	if(iTotScrlLines==oldLines)	return FALSE;

	//scrlPos ning o'zini ham korrektirovka qilib qo'yamiz:
	scrlPos = (WORD)(65535*((double)iTotScrlLines/totLines));

	fCrntOffst = (unsigned __int64)iTotScrlLines*iHorChars;
	if(fCrntOffst>(fSrc.GetSize()>fDst.GetSize()?fSrc.GetSize():fDst.GetSize()))
		fCrntOffst = fSrc.GetSize()>fDst.GetSize()?fSrc.GetSize():fDst.GetSize();
	Draw(hDlg);
	return TRUE;
}

int MyStringLength(char* buf, int mx)
{	int l=-1;
	if(!buf[0])return 0;
	while(++l<mx)
	{	if(!buf[l])//(0==buf[l])
			return l;
		if(l>=mx)
			return l;
	};
	return l;
}

VOID InitLOGFONT(LOGFONT* lf,int t)
{
	switch(t)
	{case 0://panel
		lf->lfCharSet=204;//Kirill
		lf->lfClipPrecision=2;
		lf->lfEscapement=0;
		StringCchPrintf(lf->lfFaceName,LF_FACESIZE,"MS Sans Serif");//Arial");//"Tahoma");//Arial Narrow");
		lf->lfHeight=-CHRW;//12;
		lf->lfItalic=0;
		lf->lfOrientation=0;
		lf->lfOutPrecision=3;
		lf->lfPitchAndFamily=34;
		lf->lfQuality=1;
		lf->lfStrikeOut=0;
		lf->lfUnderline=0;
		lf->lfWeight=FW_BOLD;//400;
		lf->lfWidth=0;
		break;
}	}

int MyStringCat(char* buf, int mx, char* src)
{	int l1=-1,l=-1;
	while(++l<mx)
	{	if(!buf[l]) break;//('\0'==buf[l])
		if(l>=mx) break;
	}
	while(++l1<mx-1)
	{	buf[l+l1] = src[l1];
		if(!src[l1]) break;//('\0'==src[l1])
	}
	if(buf[l+l1])//0 bo'lmasa;
	if(l1>=mx)
		buf[l+(--l1)] = 0;
	return l1;
}

int MyStringCpy(char* buf, int mx, char* src)
{	register int l=-1;
	while(++l<mx)
	{	buf[l] = src[l];
		if(!src[l]) break;//('\0'==src[l])
	}
	if(buf[l])//0 bo'lmasa;
	if(l>=mx)
		buf[l] = 0;
	return l;
}

VOID MyInt64ToString(char *s,int max,unsigned __int64 n)
{
int i;
unsigned __int64 N=n;
char *ps = s+max; *ps=0;
	for(i=0; i<max; i++)
	{	--ps;
		*ps = N % 10 + '0';
		N /= 10;
	}
}

