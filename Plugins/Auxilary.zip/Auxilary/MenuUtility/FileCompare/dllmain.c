#pragma warning (disable:4995)

#define _CRT_SECURE_NO_WARNINGS

#include "windows.h"
//#include "resource.h"
#include "stdio.h"
#include "strsafe.h"



#define MAX_STRINGS 25



wchar_t **strngs=NULL;
HMODULE plgnDllInst;



BOOL APIENTRY DllMain(hModule,ul_reason_for_call,lpReserved)
	HMODULE hModule;
	DWORD ul_reason_for_call;
	LPVOID lpReserved;
{
FILE *f;
int i,l;
wchar_t *pend;
wchar_t dllname[260],mnuStr[64];
	switch(ul_reason_for_call)
	{	case DLL_PROCESS_ATTACH:
			plgnDllInst=hModule;
			if(strngs)break;
			strngs = (wchar_t**)malloc(MAX_STRINGS*sizeof(wchar_t*));
#ifdef _DEBUG
			GetModuleFileNameW(hModule,dllname,260);//GetModuleHandle("FileCompareDbg.dll")
#else
			GetModuleFileNameW(hModule,dllname,260);//GetModuleHandle("FileCompareRel.dll")
#endif
			//LoadNTFuncs();
			pend = wcsrchr(dllname,'\\')+1;
			if(pend) *pend = 0;

			if(GetEnvironmentVariable(L"languge",mnuStr,64))//Language instartup qo'yadur;
			{	if(!wcscmp(mnuStr,L"russian"))
					wcscat(dllname,L"PlugCmprStrsRus.txt");
				else if(!wcscmp(mnuStr,L"uzbekl"))
					wcscat(dllname,L"PlugCmprStrsUZBL.txt");
				else if(!wcscmp(mnuStr,L"uzbekk"))
					wcscat(dllname,L"PlugCmprStrsUZBK.txt");
				else//if(wcscmp(mnuStr,L"Exit")
					wcscat(dllname,L"PlugCmprStrsEng.txt");
			}	
			else wcscat(dllname,L"PlugCmprStrsEng.txt");

			f=_wfopen(dllname,L"r,ccs=UNICODE");
			if(f)
			{	wchar_t s[260];fwscanf(f,L"%s", s);
				if(wcscmp(s,L"Plugin")) goto NillStr;
				fwscanf(f,L"%s", s);
				if(wcscmp(s,L"filecompare.dll")) goto NillStr;
				fwscanf(f,L"%s", s);
				if(wcscmp(s,L"Strings:")) goto NillStr;
				for(i=0; i<MAX_STRINGS; i++)
				{	int t;fwscanf_s(f,L"%d", &t);
					if(t-1!=i) goto NillStr;
					//l=fwscanf(f,"%s", s);
					l=fscanLineString(f,256,s);
					strngs[i]=(wchar_t*)malloc(2*(l+1));
					memcpy(strngs[i],s,2*(l+1));
				}
				fclose(f);
			}
			else
			{int l;
NillStr:
				l=(int)wcslen(L"File compare")+1;
					strngs[0]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[0],l,L"File compare");
				l=(int)wcslen(L"Sino file compare plugin")+1;
					strngs[1]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[1],l,L"Sino file compare plugin");
				l=(int)wcslen(L"Destination")+1;
					strngs[2]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[2],l,L"Destination");
				l=(int)wcslen(L"Browse")+1;
					strngs[3]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[3],l,L"Browse");
				l=(int)wcslen(L"Please Select a File")+1;
					strngs[4]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[4],l,L"Please Select a File");					
				l=(int)wcslen(L"Error opening source file")+1;
					strngs[5]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[5],l,L"Error opening source file");					
				l=(int)wcslen(L"Error opening destination file")+1;
					strngs[6]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[6],l,L"Error opening destination file");					
				l=(int)wcslen(L"Search for source file:")+1;
					strngs[7]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[7],l,L"Search for source file:");
				l=(int)wcslen(L"Search for destination file:")+1;
					strngs[8]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[8],l,L"Search for destination file:");
				l=(int)wcslen(L"Cancel")+1;
					strngs[9]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[9],l,L"Cancel");
				l=(int)wcslen(L"View")+1;
					strngs[10]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[10],l,L"View");
				l=(int)wcslen(L"Compared files are identicals.")+1;
					strngs[11]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[11],l,L"Compared files are identicals.");
				l=(int)wcslen(L"Compared files are not identicals.")+1;
					strngs[12]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[12],l,L"Compared files are not identicals.");
				l=(int)wcslen(L"Address mode")+1;
					strngs[13]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[13],l,L"Address mode");
				l=(int)wcslen(L"Edit mode")+1;
					strngs[14]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[14],l,L"Edit mode");
				l=(int)wcslen(L"Hexadecimal")+1;
					strngs[15]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[15],l,L"Hexadecimal");
				l=(int)wcslen(L"Decimal")+1;
					strngs[16]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[16],l,L"Decimal");
				l=(int)wcslen(L"Binary")+1;
					strngs[17]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[17],l,L"Binary");
				l=(int)wcslen(L"Character codes")+1;
					strngs[18]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[18],l,L"Character codes");
				l=(int)wcslen(L"ANSI  8-bit chars")+1;
					strngs[19]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[19],l,L"ANSI  8-bit chars");
				l=(int)wcslen(L"Code pages for MultiByteToWideChar")+1;
					strngs[20]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[20],l,L"Code pages for MultiByteToWideChar");
				l=(int)wcslen(L"OK")+1;
					strngs[21]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[21],l,L"OK");
				l=(int)wcslen(L"Address mode")+1;
					strngs[22]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[22],l,L"Address mode");
				l=(int)wcslen(L"Edit mode")+1;
					strngs[23]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[23],l,L"Edit mode");
				l=(int)wcslen(L"Source file:")+1;
					strngs[24]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[24],l,L"Source file:");
			}
			break;
		case DLL_THREAD_ATTACH:
			break;
		case DLL_THREAD_DETACH:
			break;
		case DLL_PROCESS_DETACH:
			if(strngs)
			{	for(i=0; i<MAX_STRINGS; i++)
					free(strngs[i]);
				free(strngs);
				//saveOptCpp();
				strngs=NULL;
			}
			break;
	}
	return TRUE;
}