//#include "..\SFDefrag\zenwin\zenwinx.h"
#include "windows.h"
#include "resource.h"
#include "..\..\..\..\..\Operations\MyShell\MyShell.h"




#define MAX_STRINGS 62

HINSTANCE hInst;
HWND	  hWnd;

INT_PTR CALLBACK	mainDlgProc(HWND, UINT, WPARAM, LPARAM);

extern "C"
{
extern wchar_t **strngs;
extern int frgmntCnt;
extern BOOL FragmentFile(wchar_t*,int);
extern int winx_init_library(void);
extern void winx_unload_library(void);
HWND   hStat;
}

int APIENTRY WinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPSTR     lpCmdLine,
                     int       nCmdShow)
{
	return DialogBox(hInst, MAKEINTRESOURCE(IDD_MAIN), hWnd, mainDlgProc);
}

INT_PTR CALLBACK mainDlgProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
wchar_t s[MAX_PATH];
	UNREFERENCED_PARAMETER(lParam);
	switch (message)
	{
	case WM_INITDIALOG:RECT rc,rc1;int width,height,left,top;
			GetWindowRect(hDlg, &rc1);
			GetWindowRect(GetDesktopWindow(), &rc);
			width = rc1.right - rc1.left;		
			left = rc.left + (rc.right - rc.left - width)/2;//left = (GetSystemMetrics(SM_CXFULLSCREEN) - width)/2;
			height = rc1.bottom - rc1.top;
			top = rc.top + (rc.bottom - rc.top - height)/2;//top = (GetSystemMetrics(SM_CYFULLSCREEN) - height)/2;
			MoveWindow(hDlg, left, top+20, width, height, TRUE);
			hStat = GetDlgItem(hDlg,IDC_STATIC_MESSAGE);
			winx_init_library();

strngs = (wchar_t **)malloc(MAX_STRINGS*sizeof(wchar_t*));

	int l;
NillStr:
		l=wcslen(L"Sino-file defrag plugin,ver.1.0. fr.Erkin Sattorov.Karaulbazar-2013.")+1;
			strngs[0]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[0],l,L"Sino-file defrag plugin,ver.1.0. fr.Erkin Sattorov.Karaulbazar-2013.");
		l=wcslen(L"Files to defrag:")+1;
			strngs[1]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[1],l,L"Files to defrag:");
		l=wcslen(L"Defrag")+1;//strngs[2] bo'sh
			strngs[2]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[2],l,L"Defrag");
		l=wcslen(L"Exit")+1;
			strngs[3]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[3],l,L"Exit");
		l=wcslen(L"File-defrag")+1;
			strngs[4]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[4],l,L"File-defrag");

		l=wcslen(L"build_full_paths started ...")+1;
			strngs[5]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[5],l,L"build_full_paths started ...");
		l=wcslen(L"build_full_paths: cannot allocate %I64u bytes of memory")+1;
			strngs[6]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[6],l,L"build_full_paths: cannot allocate %I64u bytes of memory");
		l=wcslen(L"build_full_paths completed in %I64u ms")+1;
			strngs[7]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[7],l,L"build_full_paths completed in %I64u ms");
		l=wcslen(L"%c: mft scan started ...")+1;
			strngs[8]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[8],l,L"%c: mft scan started ...");
		l=wcslen(L"%c: NTFS SCANNER TEST STARTED ...")+1;
			strngs[9]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[9],l,L"%c: NTFS SCANNER TEST STARTED ...");
		l=wcslen(L"%c: mft scan failed ...")+1;
			strngs[10]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[10],l,L"%c: mft scan failed ...");
		l=wcslen(L"%c: mft scan: cannot allocate %u bytes of memory ...")+1;
			strngs[11]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[11],l,L"%c: mft scan: cannot allocate %u bytes of memory ...");
		l=wcslen(L"%c: mft scan: get_file_record for $Mft failed ...")+1;
			strngs[12]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[12],l,L"%c: mft scan: get_file_record for $Mft failed ...");
		l=wcslen(L"%c: mft scan:%u attribute list entries have been processed totally ...")+1;
			strngs[13]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[13],l,L"%c: mft scan:%u attribute list entries have been processed totally ...");
		l=wcslen(L"%s:can't get volume bitmap from %I64u cluster ...")+1;
			strngs[14]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[14],l,L"%s:can't get volume bitmap from %I64u cluster ...");
		l=wcslen(L"%s:can't get enough space from-%I64u cluster to %I64u-cluster(end)...")+1;
			strngs[15]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[15],l,L"%s:can't get enough space from-%I64u cluster to %I64u-cluster(end)...");
		l=wcslen(L"%s:cannot get volume bitmap from %I64u cluster ...")+1;
			strngs[16]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[16],l,L"%s:cannot get volume bitmap from %I64u cluster ...");
		l=wcslen(L"%s:get volume bitmap,%d %c posted ...")+1;
			strngs[17]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[17],l,L"%s:get volume bitmap,%d %c posted ...");
		l=wcslen(L"%s:find freespace for %I64u clusters at the %%I64u - cluster ...")+1;
			strngs[18]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[18],l,L"%s:find freespace for %I64u clusters at the %%I64u - cluster ...");
		l=wcslen(L"%s:get volume bitmap,%d %c posted,analyze %d %c ...")+1;
			strngs[19]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[19],l,L"%s:get volume bitmap,%d %c posted,analyze %d %c ...");
		l=wcslen(L"s:find freespace at the %I64u-cluster ...")+1;
			strngs[20]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[20],l,L"s:find freespace at the %I64u-cluster ...");
		l=wcslen(L"%s:can't open volume handle ...")+1;
			strngs[21]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[21],l,L"%s:can't open volume handle ...");
		l=wcslen(L"%s:can't get volume bitmap ...")+1;
			strngs[22]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[22],l,L"%s:can't get volume bitmap ...");
		l=wcslen(L"%s:can't get volume bitmap from lcn � %I64u ...")+1;
			strngs[23]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[23],l,L"%s:can't get volume bitmap from lcn � %I64u ...");
		l=wcslen(L"%s:optimize volume about %d %c ...")+1;
			strngs[24]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[24],l,L"%s:optimize volume about %d %c ...");
		l=wcslen(L"%s:optimize volume about %d %c, analyze: %d %c ...")+1;
			strngs[25]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[25],l,L"%s:optimize volume about %d %c, analyze: %d %c ...");
		l=wcslen(L"%s:optimize volume,go scan mft ...")+1;
			strngs[26]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[26],l,L"%s:optimize volume,go scan mft ...");
		l=wcslen(L"%s:optimize volume,moving about %d%, move file %s,clusters-%I64u,to the %I64u-lcn ...")+1;
			strngs[27]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[27],l,L"%s:optimize volume,moving about %d%, move file %s,clusters-%I64u,to the %I64u-lcn ...");
		l=wcslen(L"%s:optimize volume,moving about %d %c ...")+1;
			strngs[28]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[28],l,L"%s:optimize volume,moving about %d %c ...");
		l=wcslen(L"%c: find optimal set for volume hole space %d %c posted ...")+1;
			strngs[29]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[29],l,L"%c: find optimal set for volume hole space %d %c posted ...");
		l=wcslen(L"File %s incorrect,can't defrag...")+1;
			strngs[30]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[30],l,L"File %s incorrect,can't defrag...");
		l=wcslen(L"%s:search for free space in the end of volume about %I64u clusters ...")+1;
			strngs[31]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[31],l,L"%s:search for free space in the end of volume about %I64u clusters ...");
		l=wcslen(L"%s,search for any free space in volume about %I64u clusters ...")+1;
			strngs[32]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[32],l,L"%s,search for any free space in volume about %I64u clusters ...");
		l=wcslen(L"%s:optimise volume for free %I64u clusters...")+1;
			strngs[33]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[33],l,L"%s:optimise volume for free %I64u clusters...");
		l=wcslen(L"%s:free space for %I64u clusters not founded,optimyzing volume ...")+1;
			strngs[34]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[34],l,L"%s:free space for %I64u clusters not founded,optimyzing volume ...");
		l=wcslen(L"%s:optimize finished,search free space for %I64u clusters ...")+1;
			strngs[35]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[35],l,L"%s:optimize finished,search free space for %I64u clusters ...");
		l=wcslen(L"%s:move file %I64u clusters to the %I64u-cluster ...")+1;
			strngs[36]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[36],l,L"%s:move file %I64u clusters to the %I64u-cluster ...");
		l=wcslen(L"�an't move file to %I64u-cluster...")+1;
			strngs[37]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[37],l,L"�an't move file to %I64u-cluster...");
		l=wcslen(L"%s:fill older set holes with other files...")+1;
			strngs[38]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[38],l,L"%s:fill older set holes with other files...");
		l=wcslen(L"%s:fill %I64u clusters from %I64u cluster with file...")+1;
			strngs[39]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[39],l,L"%s:fill %I64u clusters from %I64u cluster with file...");
		l=wcslen(L"%s:search for free space about %I64u clusters in the up of volume ...")+1;
			strngs[40]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[40],l,L"%s:search for free space about %I64u clusters in the up of volume ...");
		l=wcslen(L"%s:analyze for fragmentation before move the file to the up of volume ...")+1;
			strngs[41]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[41],l,L"%s:analyze for fragmentation before move the file to the up of volume ...");
		l=wcslen(L"%s:move defragmented file to the up of volume")+1;
			strngs[42]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[42],l,L"%s:move defragmented file to the up of volume");
		l=wcslen(L"%s - analyze file fragmentation level ...")+1;
			strngs[43]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[43],l,L"%s - analyze file fragmentation level ...");
		l=wcslen(L"%s - analyze file,can't open file.")+1;
			strngs[44]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[44],l,L"%s - analyze file,can't open file.");
		l=wcslen(L"%s - analyze file,open successfully, go to get retrival pointers ...")+1;
			strngs[45]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[45],l,L"%s - analyze file,open successfully, go to get retrival pointers ...");
		l=wcslen(L"%s - analyze file,get retrival pointers successfully,analyze data ...")+1;
			strngs[46]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[46],l,L"%s - analyze file,get retrival pointers successfully,analyze data ...");
		l=wcslen(L"%s - finish analyzing file")+1;
			strngs[47]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[47],l,L"%s - finish analyzing file");
		l=wcslen(L"%s - analyze system file ...")+1;
			strngs[48]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[48],l,L"%s - analyze system file ...");
		l=wcslen(L"%s - analyze system file,start scanning mft ...")+1;
			strngs[49]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[49],l,L"%s - analyze system file,start scanning mft ...");
		l=wcslen(L"%s - analyze system file,finish scanning mft ...")+1;
			strngs[50]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[50],l,L"%s - analyze system file,finish scanning mft ...");
		l=wcslen(L"%s - finishing analyze system file ...")+1;
			strngs[51]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[51],l,L"%s - finishing analyze system file ...");
		l=wcslen(L" is system file and may be accepted on boot time.")+1;
			strngs[52]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[52],l,L" is system file and may be accepted on boot time.");
		l=wcslen(L"Can't free enough space in the volume for ...")+1;
			strngs[53]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[53],l,L"Can't free enough space in the volume for ...");
		l=wcslen(L"Process for all selected files was finished.")+1;
			strngs[54]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[54],l,L"Process for all selected files was finished.");
		l=wcslen(L"File defragmentation...")+1;
			strngs[55]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[55],l,L"File defragmentation...");
		l=wcslen(L"There are not files to defrag.")+1;
			strngs[56]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[56],l,L"There are not files to defrag.");
		l=wcslen(L"Quiting...")+1;
			strngs[57]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[57],l,L"Quiting...");
		l=wcslen(L"Defrag job is in progress.")+1;
			strngs[58]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[58],l,L"Defrag job is in progress.");
		l=wcslen(L"Are you want terminate process?")+1;
			strngs[59]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[59],l,L"Are you want terminate process?");
		l=wcslen(L"Defrag job is in progress.")+1;
			strngs[60]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[60],l,L"Defrag job is in progress.");
		l=wcslen(L"Are you want terminate process?")+1;
			strngs[61]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[61],l,L"Are you want terminate process?");


		return (INT_PTR)TRUE;

	case WM_COMMAND:
		switch(LOWORD(wParam))
		{	case IDOK:
				if(GetDlgItemText(hDlg,IDC_EDIT_PATH,s,MAX_PATH))
				{	if(IsFileExist(s))
					{	if(FragmentFile(s,frgmntCnt))
							;//EndDialog(hDlg, LOWORD(wParam));
				}	}
				return (INT_PTR)TRUE;
			case IDCANCEL:
				EndDialog(hDlg, LOWORD(wParam));
				return (INT_PTR)TRUE;
			case IDC_EDIT_DIV_COUNT:
				if(GetDlgItemText(hDlg,IDC_EDIT_DIV_COUNT,s,MAX_PATH))
					frgmntCnt = _wtoi(s);
				return (INT_PTR)TRUE;
			case IDC_BUTTON_BROWSE:OPENFILENAME ofn;
				ZeroMemory(&ofn, sizeof(ofn));
				s[0] = '\0';
				ofn.lStructSize = sizeof(ofn);
				ofn.hwndOwner = NULL; 
				ofn.lpstrFile = s; 
				ofn.nMaxFile = MAX_PATH;
				ofn.lpstrFilter = NULL;
				ofn.nFilterIndex = 1;
				ofn.lpstrTitle = L"Search for file to fragmenting...";
				ofn.lpstrInitialDir = NULL;
				ofn.lpstrCustomFilter = NULL;
				ofn.nMaxCustFilter = 0;
				ofn.lpstrFileTitle = L"Please Select a File";
				ofn.nMaxFileTitle = 0;
				ofn.nFileOffset = 0;
				ofn.nFileExtension = 0;
				ofn.lpstrDefExt = NULL;
				ofn.lCustData = 0;
				ofn.lpfnHook = 0;
				ofn.lpTemplateName = 0;
				ofn.Flags = OFN_PATHMUSTEXIST | OFN_FILEMUSTEXIST | OFN_HIDEREADONLY |OFN_EXTENSIONDIFFERENT;
				if(GetOpenFileName(&ofn))
				{	SetDlgItemText(hDlg,IDC_EDIT_PATH,s);
				}
				return (INT_PTR)TRUE;
		}
		break;
	case WM_DESTROY:
		winx_unload_library();
		return TRUE;
	}
	return (INT_PTR)FALSE;
}
