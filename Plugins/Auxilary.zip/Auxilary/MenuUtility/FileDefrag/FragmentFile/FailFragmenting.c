#include "..\SFDefrag\zenwin\ntndk.h"
#include "..\SFDefrag\zenwin\zenwinx.h"
#include "..\SFDefrag\sfdefrag.h"


#define LLINVALID ((ULONGLONG) -1)



HWND hStat,hDrawWnd,hBtnExit,hBtnDfrg,hLB;
HBRUSH bckBrsh,grnBrsh,blueBrsh,redBrsh;
ExtentData *pFileExtData=NULL;
UInt64 LCNmin=0,LCNmax=0,LCNCellsCnt,fileVcnCnt;
wchar_t **strngs;
int frgmntCnt = 1;
wchar_t hStatText[MAX_PATH];


/* Return the number of fragments in the file and the size of the
   file in clusters. If the file could not be opened then return
   zero fragments. Very small files are stored by Windows in the
   MFT and the number of clusters will then be zero. */
DWORD AnalyzeFile(wchar_t *FileName,int Directory,ULONGLONG *Fragments,
				  ULONGLONG *RealClusters,ULONGLONG *UncompressedClusters,ULONG64 *Lcn)
{
  HANDLE FileHandle;
  ULONG64 PreviousVcn,PreviousLcn;
  IO_STATUS_BLOCK iosb;
  DWORD d;
  size_t filemapSize;
  int extSz = 100,Result;

  wsprintf(hStatText,L"%s - analyze file fragmentation level ...",FileName);
  SetWindowText(hStat,hStatText);

  *Fragments = 0;
  *RealClusters = 0;
  *UncompressedClusters = 0;
  *Lcn = 0;

  FileHandle = CreateFileW(FileName,FILE_READ_ATTRIBUTES,//FILE_GENERIC_READ | SYNCHRONIZE
							FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE,
							NULL,OPEN_EXISTING,FILE_FLAG_NO_BUFFERING,NULL);
  if(FileHandle == INVALID_HANDLE_VALUE)//Encrypted file:
  {	FileHandle = CreateFileW(FileName,GENERIC_READ,
							FILE_SHARE_READ | FILE_SHARE_WRITE,
							NULL,OPEN_EXISTING,FILE_FLAG_BACKUP_SEMANTICS,NULL);
	if(FileHandle == INVALID_HANDLE_VALUE)
	{	if(FileHandle == INVALID_HANDLE_VALUE)
		{	//DWORD d = GetLastError();
			wsprintf(hStatText,L"%s - analyze file,can't open file.",FileName);
			SetWindowText(hStat,hStatText);
			return -1;
  }	}	}

  pFileExtData = 0;

  /* Get the clustermap of this file. The loop will repeat if there
     are more datablocks than fit in the Data. */
  PreviousLcn = MAXULONG64;
  PreviousVcn = 0;
  LCNmin = MAXULONG64;
  LCNmax = 0;

  wsprintf(hStatText,L"%s - analyze file,open successfully, go to get retrival pointers ...",FileName);
  SetWindowText(hStat,hStatText);

  do
  { filemapSize = sizeof(ExtentData)+extSz*2*sizeof(ULONG64);
	if(!pFileExtData)
		pFileExtData = (ExtentData*)malloc((size_t)filemapSize);
	else
		pFileExtData = (ExtentData*)realloc(pFileExtData,filemapSize);
	/*Result = DeviceIoControl(FileHandle,FSCTL_GET_RETRIEVAL_POINTERS,&InBuffer,
							   sizeof(InBuffer),pFileExtData,filemapSize,&w,NULL);
    if(Result == 0)
	{ Result = GetLastError();
      if(Result != ERROR_MORE_DATA || ERROR_INSUFFICIENT_BUFFER == Result)
	  {	  extSz += extSz;
		  continue;
    } }*/
	memset(pFileExtData,0,filemapSize);
	Result = NtFsControlFile(FileHandle,NULL,NULL,0,&iosb,FSCTL_GET_RETRIEVAL_POINTERS,
							&pFileExtData->StartingVcn,sizeof(ULONGLONG),pFileExtData,filemapSize);
	if(NT_SUCCESS(Result))
	{	NtWaitForSingleObject(FileHandle,FALSE,NULL);
		Result = iosb.Status;
	}
	if(Result == STATUS_BUFFER_OVERFLOW)
	{	extSz += extSz;
		continue;
	}
	if(Result != STATUS_SUCCESS)
	{	if(Result == STATUS_END_OF_FILE)
			goto End;
	}

    wsprintf(hStatText,L"%s - analyze file,get retrival pointers successfully,analyze data ...",FileName);
    SetWindowText(hStat,hStatText);

    // Count the number of fragments, and calculate the total number of clusters used by this file.
    if(PreviousVcn == 0) PreviousVcn = pFileExtData->StartingVcn;
    for(d=0; d<pFileExtData->ExtentCount; d++)
    { //wsprintf(s1,L"  Extent %u, Lcn=%I64u, Vcn=%I64u, NextVcn=%I64u",
      //  d+1,pFileExtData->Extents[d].Lcn,PreviousVcn,pFileExtData->Extents[d].NextVcn);
      //if(SystemFile == NO) ShowDebugMessage(3,NULL,s1);

	  if(LCNmin > pFileExtData->Extents[d].Lcn)
		LCNmin = pFileExtData->Extents[d].Lcn;

      if(PreviousLcn == MAXULONG64) *Lcn = pFileExtData->Extents[d].Lcn;
      if(pFileExtData->Extents[d].Lcn != MAXULONG64)
      { if(pFileExtData->Extents[d].Lcn != PreviousLcn) *Fragments = *Fragments + 1;
        PreviousLcn = pFileExtData->Extents[d].Lcn + (DWORD)(pFileExtData->Extents[d].NextVcn - PreviousVcn);
        *RealClusters = *RealClusters + (DWORD)(pFileExtData->Extents[d].NextVcn - PreviousVcn);
      }

	  if(LCNmax < pFileExtData->Extents[d].Lcn + (DWORD)(pFileExtData->Extents[d].NextVcn - PreviousVcn))
		LCNmax = pFileExtData->Extents[d].Lcn + (DWORD)(pFileExtData->Extents[d].NextVcn - PreviousVcn);

      *UncompressedClusters = *UncompressedClusters + (DWORD)(pFileExtData->Extents[d].NextVcn - PreviousVcn);
      PreviousVcn = pFileExtData->Extents[d].NextVcn;
    }

    // Next datablock.
  } while(Result == ERROR_MORE_DATA);

End:
  //free(pFileExtData);
  CloseHandle(FileHandle);

  wsprintf(hStatText,L"%s - finish analyzing file.",FileName);
  SetWindowText(hStat,hStatText);

  return pFileExtData->ExtentCount;//(YES);
}

VOID CalcFileSizeParams()
{
DWORD i;
	if(!pFileExtData)return;
	LCNmin = pFileExtData->Extents[0].Lcn;
	LCNmax = LCNmin+(pFileExtData->Extents[0].NextVcn-pFileExtData->StartingVcn);
	fileVcnCnt = pFileExtData->Extents[0].NextVcn - pFileExtData->StartingVcn;
	for(i=1; i<pFileExtData->ExtentCount; i++)
	{	if(LCNmax < pFileExtData->Extents[i].Lcn + 
				(pFileExtData->Extents[i].NextVcn-pFileExtData->Extents[i-1].NextVcn))
			LCNmax = pFileExtData->Extents[i].Lcn + 
				(pFileExtData->Extents[i].NextVcn-pFileExtData->Extents[i-1].NextVcn);
		fileVcnCnt += pFileExtData->Extents[i].NextVcn - pFileExtData->Extents[i-1].NextVcn;
	}
	LCNCellsCnt = LCNmax-LCNmin;
}

BOOL FindFreeSpaceBeforeLcn(wchar_t *fileNameForVolLetter,ULONGLONG *lcnfr,ULONGLONG *lcncnt,ULONGLONG *findlcn)
{
ULONGLONG i,start,sztoend,MN,bisy_rgn_start=LLINVALID,free_rgn_start = LLINVALID;
size_t bitmapsize,bitmapbytes=65535;//65535 * 8 = 524280 ta claster;
BITMAP_DESCRIPTOR *bitmap;
unsigned char bitshift[] = { 1, 2, 4, 8, 16, 32, 64, 128 };//bit shifting array for efficient processing of the bitmap
WINX_FILE *f;
IO_STATUS_BLOCK iosb;
NTSTATUS status;
BOOL bFind=FALSE;
char volume_letter;
#define LLINVALID ((ULONGLONG) -1)

  bitmapsize = bitmapbytes + 2 * sizeof(ULONGLONG);

  //ensure that it will work on w2k
  volume_letter = winx_toupper((char)(*fileNameForVolLetter));
 
  //allocate memory
  bitmap = winx_malloc(bitmapsize);
  bitmap->StartLcn = *lcnfr;
 
  //open volume
  f = winx_vopen(volume_letter);
  if(f == NULL)
  { winx_free(bitmap);
	return FALSE;
  }
 
  start = 0;
  while(1)
  {	memset(bitmap,0,bitmapsize);
    bitmap->StartLcn = start;
	status = NtFsControlFile(winx_fileno(f),NULL,NULL,0,&iosb,FSCTL_GET_VOLUME_BITMAP,
							 &start,sizeof(ULONGLONG),bitmap,bitmapsize);
	if(0x80000005==status)//NT_SUCCESS(status))
	{	NtWaitForSingleObject(winx_fileno(f),FALSE,NULL);
		status = iosb.Status;
	}
	if(status != STATUS_SUCCESS && status != STATUS_BUFFER_OVERFLOW)
	{	wsprintf(hStatText,L"%s:cannot get volume bitmap from %I64u cluster ...",fileNameForVolLetter,start);
		SetWindowText(hStat,hStatText);
		goto End;
	}

	*findlcn = 0;
	bFind = FALSE;
	MN = min(bitmap->ClustersToEndOfVol, 8 * bitmapbytes);
	for(i=0; i<MN; i++)
	{ if(!(bitmap->Map[i/8] & bitshift[i%8]))
	  { if(free_rgn_start == LLINVALID)
		{	free_rgn_start = start + i;
			bisy_rgn_start = LLINVALID;
	  }	}
	  else
	  { if(bisy_rgn_start == LLINVALID)
		{	bisy_rgn_start = start + i;
			if(free_rgn_start != LLINVALID)
			{	if(bisy_rgn_start - free_rgn_start > 1)
				{	*findlcn = free_rgn_start;
					*lcncnt = bisy_rgn_start - free_rgn_start;
					bFind = TRUE;
					wsprintf(hStatText,L"%s:find freespace for %I64u clusters at the %%I64u - cluster ...",
							 fileNameForVolLetter,(*lcncnt),(*findlcn));
					SetWindowText(hStat,hStatText);
					goto End;
			}	}
			free_rgn_start = LLINVALID;
    } } }
    if(!bFind)
    {	if(free_rgn_start!=LLINVALID)
		{	if(bisy_rgn_start==LLINVALID)
			{	if(free_rgn_start < start + i)
				{	if(free_rgn_start - (start + i) > 1)
					{	*findlcn = free_rgn_start;
						*lcncnt = (start + i) - free_rgn_start;
						bFind = TRUE;
						wsprintf(hStatText,L"%s:find freespace at the %I64u-cluster ...",fileNameForVolLetter,*findlcn);
						SetWindowText(hStat,hStatText);
						goto End;
	}	}	}	}	}
	start += bitmapbytes * 8;
	bitmap->StartLcn = start;
  }
End:
  winx_fclose(f);
  winx_free(bitmap);
  return bFind;
}

BOOL MoveFileToLcnOfVolumeFromVcn(wchar_t *fileNameForVolumeLetter,ULONGLONG *frVcn,ULONGLONG *lcnto,ULONGLONG *lcncnt)
{
WINX_FILE *f,*fVol;
NTSTATUS status;
IO_STATUS_BLOCK iosb;
MOVEFILE_DESCRIPTOR mfd;
wchar_t fname[512]={'\\','?','?','\\'};
char volume_letter = winx_toupper((char)(*fileNameForVolumeLetter));
MyStringCpy(&fname[4],511,fileNameForVolumeLetter);
 
  //open volume
  fVol = winx_vopen(volume_letter);
  if(!fVol)
   return FALSE;

  f=winx_fopen(fname,"r");
  if(!f)
  {	f=winx_fopen(fname,"r+");
	if(!f)
	{ winx_fclose(fVol);
	  return FALSE;
  } }
  memset(&mfd,0,sizeof(MOVEFILE_DESCRIPTOR));
  mfd.FileHandle = f->hFile;

  mfd.NumVcns = (ULONG)(*lcncnt);
  mfd.StartVcn.QuadPart = *frVcn;
  mfd.TargetLcn.QuadPart = *lcnto;
  status = NtFsControlFile(fVol->hFile,NULL,NULL,0,&iosb,
					       FSCTL_MOVE_FILE,&mfd,sizeof(MOVEFILE_DESCRIPTOR),NULL,0);
  if(NT_SUCCESS(status))
  {	NtWaitForSingleObject(winx_fileno(f),FALSE,NULL);
  	status = iosb.Status;
  }
  winx_fclose(f);
  winx_fclose(fVol);
  return TRUE;
}

BOOL FragmentFile(wchar_t *fName, int cnt)
{
BOOL r;
	ULONGLONG i,Fragments,RealClusters,UncompressedClusters,Lcn,frVcn,findlcn,lcncnt,divClusters;
	int vcnChunkNums=AnalyzeFile(fName,0,&Fragments,&RealClusters,&UncompressedClusters,&Lcn);
	if(cnt==vcnChunkNums || vcnChunkNums>1)
	{	MessageBox(NULL,L"File already fragmented to ... count...",fName,MB_OK);
		return FALSE;
	}
	CalcFileSizeParams();
	divClusters = fileVcnCnt / frgmntCnt;
	lcncnt = divClusters;
	Lcn = LCNmin;
	frVcn = 0;
	for(i=0; i<frgmntCnt-1; i++)
	{
		r=FindFreeSpaceBeforeLcn(fName,&Lcn,&lcncnt,&findlcn);
		if(!r)
		{	MessageBox(NULL,L"Empty space in volume is not founded",L"Quiting...",MB_OK);
			return FALSE;
		}
		if(!MoveFileToLcnOfVolumeFromVcn(fName,&frVcn,&findlcn,&lcncnt))
		{	MessageBox(NULL,L"Empty space in volume is not founded",L"Quiting...",MB_OK);
			return FALSE;
		}
		frVcn += lcncnt;
	}
	return TRUE;
}

