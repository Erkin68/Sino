// SFDefrag.cpp : Defines the entry point for the application.
//

#include "zenwin/zenwinx.h"
#include "SFDefrag.h"
#include "stdio.h"
#include "strsafe.h"
#include "Shellapi.h"
#include "MyNTDLL64.h"
#include "..\..\..\..\..\Operations\MyShell\MyShellC.h"

#pragma warning(disable:4995)
#pragma warning(disable:4996)

#define MAX_STRINGS		62

extern BOOL bJobActive;

// Global Variables:
int totFiles;
wchar_t **strngs;
HANDLE hThread;
HWND hWnd,hStat,hLB,hBtnDfrg,hBtnExit,hDrawWnd;
HINSTANCE hInst;								// current instance
TCHAR szTitle[MAX_LOADSTRING];					// The title bar text
TCHAR szWindowClass[MAX_LOADSTRING];			// the main window class name
DWORD defrThrdId;
HBRUSH bckBrsh,grnBrsh,blueBrsh,redBrsh;


int icnt=0;
BOOL FindFragmentedFile(wchar_t *path,wchar_t *pout,int N)
{
HANDLE h;
BOOL r=FALSE;
WIN32_FIND_DATA ff;
wchar_t s[2*MAX_PATH];
int l=MyStringCpy(s,MAX_PATH,path);
	if('*'!=s[l-1])
	{	if('\\'==s[l-1])
		{	s[l++]='*';
			s[l]=0;
		}
		else
		{	s[l++]='\\';
			s[l++]='*';
			s[l]=0;
	}	}
	else if('\\'!=s[l-2])
	{	s[l++]='\\';
		s[l++]='*';
		s[l]=0;
	}
	h = FindFirstFileEx(s,FindExInfoStandard,&ff,FindExSearchLimitToDirectories,NULL,0);
	do
	{	ULONGLONG Fragments,RealClusters,UncompressedClusters;ULONG64 Lcn;
		if(INVALID_HANDLE_VALUE==h)
			return FALSE;
		if(FILE_ATTRIBUTE_DIRECTORY & ff.dwFileAttributes)
		{	if('.'==ff.cFileName[0] && 0==ff.cFileName[1])
				goto cont;
			if('.'==ff.cFileName[0] && '.'==ff.cFileName[1] && 0==ff.cFileName[2])
				goto cont;
			MyStringCpy(&s[l-1],2*MAX_PATH-1-l,ff.cFileName);
			r = FindFragmentedFile(s,pout,N);
			if(r) break;
		}
		else
		{	MyStringCpy(&s[l-1],2*MAX_PATH-12,ff.cFileName);
			if(!IsDirExist(s))
			{	DWORD r = AnalyzeFile(s,0,&Fragments,&RealClusters,&UncompressedClusters,&Lcn);
				if(N-1<r && N-1<Fragments)
				{	MyStringCpy(pout,MAX_PATH,s);
					r = TRUE;
					break;
		}	}	}
cont:	if(!FindNextFile(h,&ff))break;
	} while(INVALID_HANDLE_VALUE!=h);
	if(!r)*pout=0;
	FindClose(h);
	return r;
}

int APIENTRY WinMain(HINSTANCE hInstance,
				     HINSTANCE hPrevInstance,
                     LPSTR     lpCmdLine,
                     int       nCmdShow)
{
MSG msg;
HACCEL hAccelTable;
	//wchar_t s[MAX_PATH];FindFragmentedFile(L"D:\\*",&s[0],2);

	UNREFERENCED_PARAMETER(hPrevInstance);
	UNREFERENCED_PARAMETER(lpCmdLine);

	if(!lpCmdLine) return FALSE;
	
	// Initialize global strings
	LoadString(hInstance, IDS_APP_TITLE, szTitle, MAX_LOADSTRING);
	LoadString(hInstance, IDC_SFDEFRAG, szWindowClass, MAX_LOADSTRING);
	MyRegisterClass(hInstance);

	LoadNT64Library();

	//LoadNTProces();

	// Perform application initialization:
	if (!InitInstance (hInstance, nCmdShow))
		return FALSE;

	hAccelTable = LoadAccelerators(hInstance, MAKEINTRESOURCE(IDC_SFDEFRAG));

	// Main message loop:
	while(GetMessage(&msg, NULL, 0, 0))
	{	if(!TranslateAccelerator(msg.hwnd, hAccelTable, &msg))
		{	TranslateMessage(&msg);
			DispatchMessage(&msg);
	}	}

	return (int) msg.wParam;
}



//
//  FUNCTION: MyRegisterClass()
//
//  PURPOSE: Registers the window class.
//
//  COMMENTS:
//
//    This function and its usage are only necessary if you want this code
//    to be compatible with Win32 systems prior to the 'RegisterClassEx'
//    function that was added to Windows 95. It is important to call this function
//    so that the application will get 'well formed' small icons associated
//    with it.
//
ATOM MyRegisterClass(HINSTANCE hInstance)
{
	WNDCLASSEX wcex;

	wcex.cbSize = sizeof(WNDCLASSEX);

	wcex.style			= CS_HREDRAW | CS_VREDRAW;
	wcex.lpfnWndProc	= WndProc;
	wcex.cbClsExtra		= 0;
	wcex.cbWndExtra		= 0;
	wcex.hInstance		= hInstance;
	wcex.hIcon			= LoadIcon(hInstance, MAKEINTRESOURCE(IDI_SFDEFRAG));
	wcex.hCursor		= LoadCursor(NULL, IDC_ARROW);
	wcex.hbrBackground	= (HBRUSH)(COLOR_WINDOW+1);
	wcex.lpszMenuName	= NULL;//MAKEINTRESOURCE(IDC_SFDEFRAG);
	wcex.lpszClassName	= szWindowClass;
	wcex.hIconSm		= LoadIcon(wcex.hInstance, MAKEINTRESOURCE(IDI_SMALL));

	return RegisterClassEx(&wcex);
}

//
//   FUNCTION: InitInstance(HINSTANCE, int)
//
//   PURPOSE: Saves instance handle and creates main window
//
//   COMMENTS:
//
//        In this function, we save the instance handle in a global variable and
//        create and display the main program window.
//
BOOL InitInstance(HINSTANCE hInstance, int nCmdShow)
{
wchar_t mnuStr[260],exename[260],*p;FILE *f;
	hInst = hInstance;
	GetModuleFileNameW(hInstance,exename,260);
	p = wcsrchr(exename,'\\');
	if(p){*p++='\\';*p=0;}

	//if(GetEnvironmentVariable(L"languge",mnuStr,64))//Language instartup qo'yadur;
	if(MyStringCpy(mnuStr,64,GetEnvironmentStrings()))
	{	if(wcsstr(mnuStr,L"russian"))
			wcscat(exename,L"PlugDfrgStrsRus.txt");
		else if(wcsstr(mnuStr,L"uzbekl"))
			wcscat(exename,L"PlugDfrgStrsUZBL.txt");
		else if(wcsstr(mnuStr,L"uzbekk"))
			wcscat(exename,L"PlugDfrgStrsUZBK.txt");
		else//if(wcscmp(mnuStr,L"Exit")
			wcscat(exename,L"PlugDfrgStrsEng.txt");
	}	
	else wcscat(exename,L"PlugDfrgStrsEng.txt");

	strngs = (wchar_t **)malloc(MAX_STRINGS*sizeof(wchar_t*));

	f=_wfopen(exename,L"r,ccs=UNICODE");
	if(f)
	{	int i;wchar_t s[260];
		fwscanf(f,L"%s", s);
		if(wcscmp(s,L"Plugin")) goto NillStr;
		fwscanf(f,L"%s", s);
		if(wcscmp(s,L"filedefrag.dll")) goto NillStr;
		fwscanf(f,L"%s", s);
		if(wcscmp(s,L"Strings:")) goto NillStr;
		for(i=0; i<MAX_STRINGS; i++)
		{	int t,l;fwscanf_s(f,L"%d", &t);
			if(t-1!=i) goto NillStr;
			//l=fscanf(f,"%s", s);
			l=fscanLineString(f,256,s);
			strngs[i]=(wchar_t*)malloc(sizeof(wchar_t)*(l+1));
			memcpy(strngs[i],s,sizeof(wchar_t)*(l+1));
		}
		fclose(f);
	}
	else
	{int l;
NillStr:
		l=(int)wcslen(L"Sino-file defrag plugin,ver.1.0. fr.Erkin Sattorov.Karaulbazar-2013.")+1;
			strngs[0]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[0],l,L"Sino-file defrag plugin,ver.1.0. fr.Erkin Sattorov.Karaulbazar-2013.");
		l=(int)wcslen(L"Files to defrag:")+1;
			strngs[1]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[1],l,L"Files to defrag:");
		l=(int)wcslen(L"Defrag")+1;//strngs[2] bo'sh
			strngs[2]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[2],l,L"Defrag");
		l=(int)wcslen(L"Exit")+1;
			strngs[3]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[3],l,L"Exit");
		l=(int)wcslen(L"File-defrag")+1;
			strngs[4]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[4],l,L"File-defrag");

		l=(int)wcslen(L"build_full_paths started ...")+1;
			strngs[5]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[5],l,L"build_full_paths started ...");
		l=(int)wcslen(L"build_full_paths: cannot allocate %I64u bytes of memory")+1;
			strngs[6]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[6],l,L"build_full_paths: cannot allocate %I64u bytes of memory");
		l=(int)wcslen(L"build_full_paths completed in %I64u ms")+1;
			strngs[7]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[7],l,L"build_full_paths completed in %I64u ms");
		l=(int)wcslen(L"%c: mft scan started ...")+1;
			strngs[8]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[8],l,L"%c: mft scan started ...");
		l=(int)wcslen(L"%c: NTFS SCANNER TEST STARTED ...")+1;
			strngs[9]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[9],l,L"%c: NTFS SCANNER TEST STARTED ...");
		l=(int)wcslen(L"%c: mft scan failed ...")+1;
			strngs[10]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[10],l,L"%c: mft scan failed ...");
		l=(int)wcslen(L"%c: mft scan: cannot allocate %u bytes of memory ...")+1;
			strngs[11]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[11],l,L"%c: mft scan: cannot allocate %u bytes of memory ...");
		l=(int)wcslen(L"%c: mft scan: get_file_record for $Mft failed ...")+1;
			strngs[12]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[12],l,L"%c: mft scan: get_file_record for $Mft failed ...");
		l=(int)wcslen(L"%c: mft scan:%u attribute list entries have been processed totally ...")+1;
			strngs[13]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[13],l,L"%c: mft scan:%u attribute list entries have been processed totally ...");
		l=(int)wcslen(L"%s:can't get volume bitmap from %I64u cluster ...")+1;
			strngs[14]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[14],l,L"%s:can't get volume bitmap from %I64u cluster ...");
		l=(int)wcslen(L"%s:can't get enough space from-%I64u cluster to %I64u-cluster(end)...")+1;
			strngs[15]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[15],l,L"%s:can't get enough space from-%I64u cluster to %I64u-cluster(end)...");
		l=(int)wcslen(L"%s:cannot get volume bitmap from %I64u cluster ...")+1;
			strngs[16]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[16],l,L"%s:cannot get volume bitmap from %I64u cluster ...");
		l=(int)wcslen(L"%s:get volume bitmap,%d %c posted ...")+1;
			strngs[17]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[17],l,L"%s:get volume bitmap,%d %c posted ...");
		l=(int)wcslen(L"%s:find freespace for %I64u clusters at the %%I64u - cluster ...")+1;
			strngs[18]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[18],l,L"%s:find freespace for %I64u clusters at the %%I64u - cluster ...");
		l=(int)wcslen(L"%s:get volume bitmap,%d %c posted,analyze %d %c ...")+1;
			strngs[19]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[19],l,L"%s:get volume bitmap,%d %c posted,analyze %d %c ...");
		l=(int)wcslen(L"s:find freespace at the %I64u-cluster ...")+1;
			strngs[20]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[20],l,L"s:find freespace at the %I64u-cluster ...");
		l=(int)wcslen(L"%s:can't open volume handle ...")+1;
			strngs[21]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[21],l,L"%s:can't open volume handle ...");
		l=(int)wcslen(L"%s:can't get volume bitmap ...")+1;
			strngs[22]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[22],l,L"%s:can't get volume bitmap ...");
		l=(int)wcslen(L"%s:can't get volume bitmap from lcn � %I64u ...")+1;
			strngs[23]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[23],l,L"%s:can't get volume bitmap from lcn � %I64u ...");
		l=(int)wcslen(L"%s:optimize volume about %d %c ...")+1;
			strngs[24]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[24],l,L"%s:optimize volume about %d %c ...");
		l=(int)wcslen(L"%s:optimize volume about %d %c, analyze: %d %c ...")+1;
			strngs[25]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[25],l,L"%s:optimize volume about %d %c, analyze: %d %c ...");
		l=(int)wcslen(L"%s:optimize volume,go scan mft ...")+1;
			strngs[26]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[26],l,L"%s:optimize volume,go scan mft ...");
		l=(int)wcslen(L"%s:optimize volume,moving about %d%, move file %s,clusters-%I64u,to the %I64u-lcn ...")+1;
			strngs[27]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[27],l,L"%s:optimize volume,moving about %d%, move file %s,clusters-%I64u,to the %I64u-lcn ...");
		l=(int)wcslen(L"%s:optimize volume,moving about %d %c ...")+1;
			strngs[28]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[28],l,L"%s:optimize volume,moving about %d %c ...");
		l=(int)wcslen(L"%c: find optimal set for volume hole space %d %c posted ...")+1;
			strngs[29]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[29],l,L"%c: find optimal set for volume hole space %d %c posted ...");
		l=(int)wcslen(L"File %s incorrect,can't defrag...")+1;
			strngs[30]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[30],l,L"File %s incorrect,can't defrag...");
		l=(int)wcslen(L"%s:search for free space in the end of volume about %I64u clusters ...")+1;
			strngs[31]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[31],l,L"%s:search for free space in the end of volume about %I64u clusters ...");
		l=(int)wcslen(L"%s,search for any free space in volume about %I64u clusters ...")+1;
			strngs[32]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[32],l,L"%s,search for any free space in volume about %I64u clusters ...");
		l=(int)wcslen(L"%s:optimise volume for free %I64u clusters...")+1;
			strngs[33]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[33],l,L"%s:optimise volume for free %I64u clusters...");
		l=(int)wcslen(L"%s:free space for %I64u clusters not founded,optimyzing volume ...")+1;
			strngs[34]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[34],l,L"%s:free space for %I64u clusters not founded,optimyzing volume ...");
		l=(int)wcslen(L"%s:optimize finished,search free space for %I64u clusters ...")+1;
			strngs[35]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[35],l,L"%s:optimize finished,search free space for %I64u clusters ...");
		l=(int)wcslen(L"%s:move file %I64u clusters to the %I64u-cluster ...")+1;
			strngs[36]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[36],l,L"%s:move file %I64u clusters to the %I64u-cluster ...");
		l=(int)wcslen(L"�an't move file to %I64u-cluster...")+1;
			strngs[37]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[37],l,L"�an't move file to %I64u-cluster...");
		l=(int)wcslen(L"%s:fill older set holes with other files...")+1;
			strngs[38]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[38],l,L"%s:fill older set holes with other files...");
		l=(int)wcslen(L"%s:fill %I64u clusters from %I64u cluster with file...")+1;
			strngs[39]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[39],l,L"%s:fill %I64u clusters from %I64u cluster with file...");
		l=(int)wcslen(L"%s:search for free space about %I64u clusters in the up of volume ...")+1;
			strngs[40]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[40],l,L"%s:search for free space about %I64u clusters in the up of volume ...");
		l=(int)wcslen(L"%s:analyze for fragmentation before move the file to the up of volume ...")+1;
			strngs[41]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[41],l,L"%s:analyze for fragmentation before move the file to the up of volume ...");
		l=(int)wcslen(L"%s:move defragmented file to the up of volume")+1;
			strngs[42]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[42],l,L"%s:move defragmented file to the up of volume");
		l=(int)wcslen(L"%s - analyze file fragmentation level ...")+1;
			strngs[43]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[43],l,L"%s - analyze file fragmentation level ...");
		l=(int)wcslen(L"%s - analyze file,can't open file.")+1;
			strngs[44]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[44],l,L"%s - analyze file,can't open file.");
		l=(int)wcslen(L"%s - analyze file,open successfully, go to get retrival pointers ...")+1;
			strngs[45]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[45],l,L"%s - analyze file,open successfully, go to get retrival pointers ...");
		l=(int)wcslen(L"%s - analyze file,get retrival pointers successfully,analyze data ...")+1;
			strngs[46]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[46],l,L"%s - analyze file,get retrival pointers successfully,analyze data ...");
		l=(int)wcslen(L"%s - finish analyzing file")+1;
			strngs[47]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[47],l,L"%s - finish analyzing file");
		l=(int)wcslen(L"%s - analyze system file ...")+1;
			strngs[48]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[48],l,L"%s - analyze system file ...");
		l=(int)wcslen(L"%s - analyze system file,start scanning mft ...")+1;
			strngs[49]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[49],l,L"%s - analyze system file,start scanning mft ...");
		l=(int)wcslen(L"%s - analyze system file,finish scanning mft ...")+1;
			strngs[50]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[50],l,L"%s - analyze system file,finish scanning mft ...");
		l=(int)wcslen(L"%s - finishing analyze system file ...")+1;
			strngs[51]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[51],l,L"%s - finishing analyze system file ...");
		l=(int)wcslen(L" is system file and may be accepted on boot time.")+1;
			strngs[52]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[52],l,L" is system file and may be accepted on boot time.");
		l=(int)wcslen(L"Can't free enough space in the volume for ...")+1;
			strngs[53]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[53],l,L"Can't free enough space in the volume for ...");
		l=(int)wcslen(L"Process for all selected files was finished.")+1;
			strngs[54]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[54],l,L"Process for all selected files was finished.");
		l=(int)wcslen(L"File defragmentation...")+1;
			strngs[55]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[55],l,L"File defragmentation...");
		l=(int)wcslen(L"There are not files to defrag.")+1;
			strngs[56]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[56],l,L"There are not files to defrag.");
		l=(int)wcslen(L"Quiting...")+1;
			strngs[57]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[57],l,L"Quiting...");
		l=(int)wcslen(L"Defrag job is in progress.")+1;
			strngs[58]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[58],l,L"Defrag job is in progress.");
		l=(int)wcslen(L"Are you want terminate process?")+1;
			strngs[59]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[59],l,L"Are you want terminate process?");
		l=(int)wcslen(L"Defrag job is in progress.")+1;
			strngs[60]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[60],l,L"Defrag job is in progress.");
		l=(int)wcslen(L"Are you want terminate process?")+1;
			strngs[61]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[61],l,L"Are you want terminate process?");
	}


	hWnd = CreateWindow(szWindowClass, szTitle, WS_OVERLAPPEDWINDOW,
						CW_USEDEFAULT, 0, CW_USEDEFAULT, 0, NULL, NULL, hInstance, NULL);
	if(!hWnd)
		return FALSE;

	ShowWindow(hWnd, nCmdShow);
	UpdateWindow(hWnd);

	return TRUE;
}

LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
int wmId, wmEvent;

static HFONT hf=0;
//static int hfRef=0;//obshiy hf, dinamik uchun emas:
static HBRUSH br=0;
//static LPVOID panel;
static HBRUSH brHtBk=0;
static int endDialogCodeToWM_DESTROY;
static int szQntSlct=0;
wchar_t s[MAX_PATH];
//int left,top,width,height,nxtPnlNum=-1;
LPDRAWITEMSTRUCT lpdis;
LOGFONT fnt;
RECT rc;//,rc1;
UINT uStyle;
HDC dc;


/*	static int i=0;
	char ss[32];sprintf(ss,"\n %d ",i++);
	OutputDebugStringA(ss);
	OutputDebugStringA(GetWinNotifyText(message));*/

	switch (message)
	{

	case WM_CREATE:
		/*GetWindowRect(hDlg, &rc1);
		HWND prnt;prnt = GetParent(hDlg);
		if(!prnt)prnt=GetDesktopWindow();
		GetWindowRect(prnt, &rc);
		width = rc1.right - rc1.left;		
		left = rc.left + (rc.right - rc.left - width)/2;//left = (GetSystemMetrics(SM_CXFULLSCREEN) - width)/2;
		height = rc1.bottom - rc1.top;
		top = rc.top + (rc.bottom - rc.top - height)/2;//top = (GetSystemMetrics(SM_CYFULLSCREEN) - height)/2;
		MoveWindow(hDlg, left, top+20, width, height, TRUE);*/

		bckBrsh = CreateSolidBrush(RGB(127,80,80));
		grnBrsh = CreateSolidBrush(RGB(0,255,0));
		blueBrsh = CreateSolidBrush(RGB(0,0,255));
		redBrsh = CreateSolidBrush(RGB(255,0,0));

		//Load language strings:
		CreateChilds(hWnd);
		if(!FillDefragFilesInfo())
		{	MessageBox(hWnd,strngs[56]/*L"There are not files to defrag."*/,
						strngs[57]/*L"Quiting..."*/,MB_OK);
			PostQuitMessage(0);
			return 0;
		}
		SendMessage(hWnd,WM_USER+1,0,0);
		winx_init_library();
		hThread=CreateThread(NULL,0,(LPTHREAD_START_ROUTINE)FileDefrag,NULL,0,&defrThrdId);
		return 0;
	case WM_CLOSE:
		if(bJobActive)
		{	if(IDYES==MessageBox(hWnd,strngs[58]/*L"Defrag job is in progress."*/,
				strngs[59]/*L"Are you want terminate process?"*/,MB_YESNO))
			{	TerminateThread(hThread,0);
				DestroyWindow(hWnd);
		}	}
		else DestroyWindow(hWnd);
		return 0;
	case WM_COMMAND:
		wmId    = LOWORD(wParam);
		wmEvent = HIWORD(wParam);
		// Parse the menu selections:
		switch (wmId)
		{
		case IDB_DEFRAG:
			break;
		case IDB_EXIT:
			if(bJobActive)
			{	if(IDYES==MessageBox(hWnd,strngs[60]/*L"Defrag job is in progress."*/,
									strngs[61]/*L"Are you want terminate process?"*/,MB_YESNO))
				{	TerminateThread(hThread,0);
					DestroyWindow(hWnd);
			}	}
			else DestroyWindow(hWnd);
			break;
		default:
			return DefWindowProc(hWnd, message, wParam, lParam);
		}
		return 0;
	case WM_SIZE:
		Resize(hWnd,wParam,lParam);
		return 0;
	case WM_CTLCOLORSTATIC:
	case WM_CTLCOLORDLG:dc = (HDC)wParam;
		SetTextColor(dc,RGB(0xea,0xe0,0xff));//SetTextColor(dc,RGB(0x8a,0,0));
		SetBkColor(dc,RGB(0x40,0x21,0x17));//SetBkColor(dc,RGB(0xc0,0x81,0x97));
		return (INT_PTR)br;
	case WM_CTLCOLOREDIT:dc = (HDC)wParam;
		SetTextColor(dc,RGB(0xea,0xe0,0xff));//SetTextColor(dc,RGB(0x8a,0,0));
		SetBkColor(dc,RGB(0x40,0x21,0x17));//SetBkColor(dc,RGB(0xc0,0x81,0x97));
		return (INT_PTR)br;
	case WM_CTLCOLORBTN:dc=(HDC)wParam;
		SetTextColor(dc,RGB(0xd0,0xe0,0xff));
		SetBkColor(dc,RGB(0x64,0x79,0x65));
		return (INT_PTR)brHtBk;
	case WM_DRAWITEM://WM_CTLCOLORBTN dagi knopkalar:
		lpdis = (LPDRAWITEMSTRUCT)lParam;
		if(hDrawWnd==lpdis->hwndItem)
		{	Render(lpdis->hDC);
			return TRUE;
		}
		GetWindowText(lpdis->hwndItem,s,MAX_PATH);
		uStyle = DFCS_BUTTONPUSH;
		rc = lpdis->rcItem;
		if(lpdis->itemState & ODS_SELECTED)
		{	uStyle |= DFCS_PUSHED|DFCS_TRANSPARENT;
			rc.left+=2;rc.top+=2;
		}
		DrawFrameControl(lpdis->hDC, &lpdis->rcItem, DFC_BUTTON, uStyle);
		if(lpdis->itemState & ODS_SELECTED)
			{rc.left+=1;rc.top+=1;rc.bottom-=2;rc.right-=3;}
		else
			{rc.left+=1;rc.top+=2;rc.bottom-=3;rc.right-=3;}
		FillRect(lpdis->hDC,&rc,brHtBk);//DrawText(lpdis->hDC,"",50,&rc,DT_SINGLELINE|DT_VCENTER|DT_INTERNAL|DT_LEFT);
		if(lpdis->itemState & ODS_SELECTED)
			{rc.left-=1;rc.top-=1;rc.bottom+=3;rc.right+=3;}
		else
			{rc.left-=1;rc.top-=2;rc.bottom+=2;rc.right+=3;}
		DrawText(lpdis->hDC,s,MyStringLength(s,MAX_PATH),&rc,DT_SINGLELINE|DT_VCENTER|DT_CENTER);
		return TRUE;
	case WM_USER+1://hf obshiy uchun, dinamik o'zgartirish uchun emas:
		//if(0==hfRef)
		{	InitLOGFONT(&fnt);
			hf = CreateFontIndirect(&fnt);
			br = CreateSolidBrush(RGB(0x40,0x21,0x17));//0xc9,0x81,0x93));
			brHtBk = CreateSolidBrush(RGB(0x64,0x79,0x65));
		}
		SendMessage(GetDlgItem(hWnd,IDB_DEFRAG),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hWnd,IDB_EXIT),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hWnd,IDC_STATIC1),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hWnd,IDC_LIST_FILES),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hWnd,IDC_EDIT_DRAW),WM_SETFONT,(WPARAM)hf,TRUE);			
		//++hfRef;
		return 0;
	case WM_DESTROY:
		winx_unload_library();
		DeleteObject(bckBrsh);
		DeleteObject(grnBrsh);
		DeleteObject(blueBrsh);
		DeleteObject(redBrsh);
		DeleteObject(hf);
		DeleteObject(br);
		DeleteObject(brHtBk);		
		PostQuitMessage(0);
		break;
	default:
		return DefWindowProc(hWnd, message, wParam, lParam);
	}
	return DefWindowProc(hWnd, message, wParam, lParam);
}

wchar_t fileNameForFindFirstEx[MAX_PATH]=L"";

BOOL IsCrntOrPrntDirAttrb(wchar_t* fd)
{//see Naming Conventions in MSDN:
	if('.'==fd[0])
	{	if('\0'==fd[1])//"."
			return FALSE;
		if('.'==fd[1])
			if('\0'==fd[2])//".."
				return FALSE;
	}
	return TRUE;//Hozircha;
}

VOID FillDirDefragFilesInfo(wchar_t *path)
{
HANDLE hf;WIN32_FIND_DATAW ff;wchar_t *p,s[MAX_PATH];
	int l = MyStringCpy(s,MAX_PATH-1,path);
	if('\\' != s[l-2] && '*' != s[l-1])
	{	if('\\'==s[l-1])
		{	s[l]='*';
			s[l+1]=0;
		}
		else
		{	s[l]='\\';
			s[l+1]='*';
			s[l+2]=0;
	}	}
	else if('\\'==s[l-1])
	{	s[l]='*';
		s[l+1]=0;
	}
	
	hf = MyFindFirstFileEx(s,FindExInfoStandard,&ff,FindExSearchLimitToDirectories,NULL,0);
	p=wcsrchr(s,'\\');
	if(p) *(++p)=0;
	do
	{	if(INVALID_HANDLE_VALUE==hf) break;
		if(!IsCrntOrPrntDirAttrb(ff.cFileName)) continue;
		if(FILE_ATTRIBUTE_DIRECTORY & ff.dwFileAttributes)
		{	l=MyStringCpy(p,MAX_PATH-1,ff.cFileName);
			*(p+l) = '\\';
			*(p+l+1) = '*';
			*(p+l+2) = 0;
			FillDirDefragFilesInfo(s);
		}
		else
		{	MyStringCpy(p,MAX_PATH-1,ff.cFileName);
			SendMessageW(hLB,LB_ADDSTRING,0,(LPARAM)s);
	}	}	
	while(FindNextFile(hf, &ff));
	FindClose(hf);
}

/*BOOL FillDefragFilesInfo()
{
LPWSTR *lp;
wchar_t *p,*pout,*pOld;
int i,l,filsListBufLen=0,islp=0;
lp = CommandLineToArgvW(GetCommandLineW(),&totFiles);
	if(totFiles<2) return FALSE;
	--totFiles;

	for(i=0; i<totFiles; i++)//;*p;)
	{	l = MyStringLength(lp[i+1],MAX_PATH);
		filsListBufLen += l+1;
	}

	if(!totFiles)return FALSE;

	filesList = (wchar_t*)malloc(sizeof(wchar_t)*filsListBufLen);
	pout = filesList;pOld = pout;
	for(i=0; i<totFiles; i++)//;*p;)
	{	l = MyStringCpy(pout,MAX_PATH,lp[i+1]);
		pout += l;
		*pout++ = 0;
		if(IsDirExist(pOld)
		{
		}
		else
		{	if(!IsFileExist(pOld)
			{	++islp;
				*(pout-1)=' ';
			}
			else pOld = pout;
	}	}
	totFiles -= islp;

	p = filesList;

	for(i=0; i<totFiles; i++)
	{	if(IsDirExist(p))
			FillDirDefragFilesInfo(p);//DlgDirList(hWnd,p
		else
			SendMessageW(hLB,LB_ADDSTRING,0,(LPARAM)p);
		p += 1+MyStringLength(p,MAX_PATH);
	}
	free(filesList);
	filesList = 0;
	return TRUE;
}*/

BOOL FillDefragFilesInfo()
{
BOOL bAstr=FALSE;
wchar_t *p,*pp;
p = GetCommandLineW();
	
	if(*p==' ')++p;
	totFiles = 0;

	for(;*p;)
	{	if('"'==*p)
		{	bAstr = !bAstr;
			if(!bAstr)
			{	*p++ = 0;
				if(IsDirExist(pp))
					FillDirDefragFilesInfo(pp);
				else if(IsFileExist(pp))
					SendMessageW(hLB,LB_ADDSTRING,0,(LPARAM)pp);
				else break;
				++totFiles;
			}
			else pp = ++p;
		} else ++p;
	}
	return TRUE;
}

LRESULT CALLBACK DrawWndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
PAINTSTRUCT ps;

	switch (message)
	{
	case WM_VSCROLL:
		if(SetScrollInf(wParam,lParam))
			Render(0);
		return 0;
	case WM_PAINT:
		BeginPaint(hWnd,&ps);
			Render(ps.hdc);
		EndPaint(hWnd,&ps);
		return 0;
	default:
		break;
	}
	return DefWindowProc(hWnd, message, wParam, lParam);
}

BOOL CreateChilds(HWND hWnd)
{
WNDCLASSEX wcex;RECT r;
	SetWindowTextW(hWnd,strngs[0]);
	hStat=CreateWindowW(L"STATIC",strngs[1],
				WS_CHILD | WS_VISIBLE,
                0,
				0,
				250,
				66,
                hWnd,
                (HMENU)IDC_STATIC1,
                hInst,
                NULL);
	hLB = CreateWindowW(L"LISTBOX",NULL,
				WS_CHILD | WS_VISIBLE | WS_BORDER | LBS_EXTENDEDSEL | WS_VSCROLL | WS_HSCROLL |
				LBS_MULTIPLESEL | LBS_NOTIFY | LBS_WANTKEYBOARDINPUT,
                0,
				68,
				250,
				586,
                hWnd,
                NULL,
                hInst,
                NULL);
	SendMessage(hLB, LB_SETHORIZONTALEXTENT, 1200, 0);
	hBtnDfrg = CreateWindowW(L"BUTTON",strngs[2],
				WS_CHILD | WS_VISIBLE | WS_BORDER | LBS_EXTENDEDSEL,
                2,
				652,
				122,
				25,
                hWnd,
                (HMENU)IDB_DEFRAG,
                hInst,
                NULL);
	hBtnExit = CreateWindowW(L"BUTTON",strngs[3],
				WS_CHILD | WS_VISIBLE | WS_BORDER | LBS_EXTENDEDSEL,
                125,
				652,
				122,
				25,
                hWnd,
                (HMENU)IDB_EXIT,
                hInst,
                NULL);


	wcex.cbSize = sizeof(WNDCLASSEX);
	wcex.style			= CS_HREDRAW | CS_VREDRAW;
	wcex.lpfnWndProc	= DrawWndProc;
	wcex.cbClsExtra		= 0;
	wcex.cbWndExtra		= 0;
	wcex.hInstance		= hInst;
	wcex.hIcon			= NULL;
	wcex.hCursor		= NULL;//LoadCursor(NULL, IDC_ARROW);
	wcex.hbrBackground	= bckBrsh;
	wcex.lpszMenuName	= NULL;
	wcex.lpszClassName	= L"DefrWindClass";
	wcex.hIconSm		= NULL;
	/*ATOM rcl = */RegisterClassEx(&wcex);

	GetClientRect(hWnd,&r);
	hDrawWnd = CreateWindowW(L"DefrWindClass",L"",
				WS_CHILDWINDOW | WS_VISIBLE | WS_VSCROLL,// | BS_OWNERDRAW,// | WS_HSCROLL,
                252,
				0,
				r.right-252,
				r.bottom,
                hWnd,
                0,
                hInst,
                NULL);
	return TRUE;
}