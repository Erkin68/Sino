#include "windows.h"
#include "SFDefrag.h"


FileListS *pFileList=NULL;
ExtentData *pFileExtData=NULL;
UInt64 LCNmin=0,LCNmax=0;
BOOL bSysFile,bJobActive;
wchar_t hStatText[2*MAX_PATH];

typedef struct _winx_volume_moved_region {
    struct _winx_volume_region *next;  /* pointer to the next region */
    struct _winx_volume_region *prev;  /* pointer to the previous region */
    ULONGLONG lcn;                     /* logical cluster number */
    ULONGLONG length;                  /* size of region, in clusters */
    ULONGLONG lcnto;                   /* logical cluster number */
} winx_volume_moved_region;
typedef struct _winx_volume_region {
    struct _winx_volume_region *next;  /* pointer to the next region */
    struct _winx_volume_region *prev;  /* pointer to the previous region */
    ULONGLONG lcn;                     /* logical cluster number */
    ULONGLONG length;                  /* size of region, in clusters */
} winx_volume_region;
typedef struct _list_entry {
    struct _list_entry *next; /* pointer to next entry */
    struct _list_entry *prev; /* pointer to previous entry */
} list_entry;


VOID CalcFileEntireLCNSize(ULONGLONG*);
extern BOOL FindFreeSpaceFromEndOfVolume(wchar_t*,ULONGLONG*,ULONGLONG*,ULONGLONG*);
extern BOOL OptimizeFreeSpace(wchar_t*,ULONGLONG*,ULONGLONG*);
extern BOOL MoveFileToEndOfVolume(wchar_t*,ULONGLONG*);
extern VOID ScrollToLcn(ULONGLONG*);



/*int GetRealFragmentedInterChunk()
{
DWORD d;ULONG64 PreviousVcn = pFileExtData->StartingVcn;
		ULONG64 PreviousLcn = pFileExtData->Extents[0].Lcn;
    for(d=1; d<pFileExtData->ExtentCount; d++)
    { if(pFileExtData->Extents[d].Lcn != PreviousLcn)
		return d;
      PreviousLcn = pFileExtData->Extents[d].Lcn + (DWORD)(pFileExtData->Extents[d].NextVcn - PreviousVcn);
	  PreviousVcn = pFileExtData->Extents[d].NextVcn;
	}
	return 0;
}*/

BOOL GetFileAttribManiki(wchar_t *s,DWORD *attrb)
{
WIN32_FIND_DATA ff;
HANDLE h = FindFirstFile(s,&ff);
	//BY_HANDLE_FILE_INFORMATION bi;
	//BOOL b=GetFileInformationByHandle(h,&bi);
	if(INVALID_HANDLE_VALUE==h)return FALSE;
	*attrb = ff.dwFileAttributes;
	FindClose(h);
	return TRUE;
}

VOID FileDefrag()
{
ULONGLONG Fragments,RealClusters,UncompressedClusters,Lcn,vcn,LCNminOld,LCNmaxOld,LCNcnt;
wchar_t s[MAX_PATH];
DWORD vcnChunkNums,i,
	tot=(int)SendMessage(hLB,LB_GETCOUNT,0,0);
	bJobActive = TRUE;


	LCNminOld = 0x00000000009c4583;
	LCNcnt=7;

	while(tot>0)
	{	winx_volume_moved_region *mlist=NULL,*rgn=NULL;
		ULONGLONG totMovedChunks=0;
		pFileExtData = 0;
		SendMessageW(hLB,LB_GETTEXT,0,(LPARAM)s);

		bSysFile = FALSE;
		vcnChunkNums=AnalyzeFile(s,0,&Fragments,&RealClusters,&UncompressedClusters,&Lcn);
		if(-1==vcnChunkNums)
		{	DWORD attrb;
			if(!GetFileAttribManiki(s,&attrb))
			{	//MessageBox(NULL,s,L"This is incorrect file, can't defragment.",MB_OK);
				wsprintf(hStatText,strngs[30]/*L"File %s incorrect,can't defrag..."*/,s);
				SetWindowText(hStat,hStatText);
				goto Nxt;//qilib bo'lmaskan;
			}
			if(attrb & FILE_ATTRIBUTE_DIRECTORY)
				goto Nxt;
			vcnChunkNums=AnalyzeSystemFile(s,0,&Fragments,&RealClusters,&UncompressedClusters,&Lcn,attrb);
			if(vcnChunkNums>0)
				bSysFile = TRUE;
		}
		if(Fragments<2)//ExtentCount dan farq qilishi mumkin;
			goto Nxt;
		if(pFileExtData->ExtentCount==0 && pFileExtData->Extents[0].Lcn==0)
			goto Nxt;

		if(bSysFile)
		{	MessageBox(hWnd,s,strngs[52]/*L" is system file and may be accepted on boot time."*/,MB_OK);
			goto Nxt;
		}

		CalcLcnMaxMin(0);
		CalcResizeParams(0);

		Render(0);
		LCNminOld = LCNmin;
		LCNmaxOld = LCNmax;

		//if(Fragments>1)//pFileExtData->ExtentCount>1)
		{	ULONGLONG findlcn,findlcnup;
			//winx_volume_region *interChunkInfoList,*pinterChunkInfoList;

			if(0==RealClusters)goto Nxt;

			//1.Disk oxiridan joy qidiramiz:
			wsprintf(hStatText,strngs[31]/*L"%s:search for free space in the end of volume about %I64u clusters ..."*/,s,RealClusters);
			SetWindowText(hStat,hStatText);
			if(!FindFreeSpaceFromEndOfVolume(s,&pFileExtData->Extents[0].Lcn,&RealClusters,&findlcn))
			{	ULONGLONG fr = 0;
				wsprintf(hStatText,strngs[32]/*L"%s,search for any free space in volume about %I64u clusters ..."*/,s,RealClusters);
				SetWindowText(hStat,hStatText);
				if(!FindFreeSpaceFromEndOfVolume(s,&fr,&RealClusters,&findlcn))
				{	wsprintf(hStatText,strngs[33]/*L"%s:optimise volume for free %I64u clusters..."*/,s,RealClusters);
					SetWindowText(hStat,hStatText);

					wsprintf(hStatText,strngs[34]/*L"%s:free space for %I64u clusters not founded,optimyzing volume ..."*/,s,RealClusters);
					SetWindowText(hStat,hStatText);
					if(!OptimizeFreeSpace(s,&pFileExtData->Extents[0].Lcn,&RealClusters))
					{NotFreSpace:MessageBox(hWnd,s,strngs[53]/*L"Can't free enough space in the volume for ..."*/,MB_OK);
						goto Nxt;//qilib bo'lmaskan;
					}//else:
					wsprintf(hStatText,strngs[35]/*L"%s:optimize finished,search free space for %I64u clusters ..."*/,s,RealClusters);
					SetWindowText(hStat,hStatText);
					if(!FindFreeSpaceFromEndOfVolume(s,&pFileExtData->Extents[0].Lcn,&RealClusters,&findlcn))
						goto NotFreSpace;
			}	}

			//Avval faylni oxiriga bust-butun qilib ko'chiramiz;
			wsprintf(hStatText,strngs[36]/*L"%s:move file %I64u clusters to the %I64u-cluster ..."*/,s,RealClusters,findlcn);
			SetWindowText(hStat,hStatText);
			if(!MoveFileToEndOfVolume(s,&findlcn))
			{	wsprintf(hStatText,strngs[37]/*L"�an't move file to %I64u-cluster..."*/,findlcn);
				MessageBox(hWnd,hStatText,s,MB_OK);
				goto Nxt;
			}

			CalcLcnMaxMin(1);
			CalcResizeParams(0);
			ScrollToLcn(&findlcn);
			Render(0);

			//Endi faylning eski bo'shagan joyiga pastdan mos fayllarni topib ko'chiramiz:
			LCNcnt=LCNmax-LCNmin;
			SetRenderParamsForFullDiskOptimize(&pFileExtData->Extents[0].Lcn,&LCNcnt);
			DrawRects(0,pFileExtData->Extents[0].Lcn,LCNmax-LCNmin,2);

			wsprintf(hStatText,strngs[38]/*L"%s:fill older set holes with other files..."*/,s);
			SetWindowText(hStat,hStatText);
			for(i=0; i<pFileExtData->ExtentCount; i++)
			{	if(0==i)
					vcn = pFileExtData->Extents[0].NextVcn-pFileExtData->StartingVcn;
				else
					vcn = pFileExtData->Extents[i].NextVcn-pFileExtData->Extents[i-1].NextVcn;
				wsprintf(hStatText,strngs[39]/*L"%s:fill %I64u clusters from %I64u cluster with file..."*/,s,vcn,pFileExtData->Extents[i].Lcn);
				SetWindowText(hStat,hStatText);
				FillVolumeHole(s,&pFileExtData->Extents[i].Lcn,&vcn,i==0?0:(i==pFileExtData->ExtentCount-1?2:1));
				DrawRects(0,pFileExtData->Extents[i].Lcn,vcn,1);
			}

			//Endi pastda turgan bust-butun faylimizni tepadan bust-butun joy topib ko'chiramiz;
			wsprintf(hStatText,strngs[40]/*L"%s:search for free space about %I64u clusters in the up of volume ..."*/,s,RealClusters);
			SetWindowText(hStat,hStatText);
			if(!FindFreeSpaceFromLcnVolume(s,&LCNminOld,&RealClusters,&findlcnup))
				goto NotFreSpace;

			//Qaytadan joylarni topamiz:
			wsprintf(hStatText,strngs[41]/*L"%s:analyze for fragmentation before move the file to the up of volume ..."*/,s);
			SetWindowText(hStat,hStatText);
			vcnChunkNums=AnalyzeFile(s,0,&Fragments,&RealClusters,&UncompressedClusters,&Lcn);

			wsprintf(hStatText,strngs[42]/*L"%s:move defragmented file to the up of volume"*/,s);
			SetWindowText(hStat,hStatText);
			if(MoveFileToLcnOfVolume(s,&findlcnup,&RealClusters))
			{
			}
		}//end of if nfragments;
Nxt:	

		if(pFileExtData)
			free(pFileExtData);
  
		bJobActive = FALSE;

		SendMessageW(hLB,LB_DELETESTRING,0,0);
		tot=(int)SendMessage(hLB,LB_GETCOUNT,0,0);
	}

	MessageBox(hWnd,strngs[54]/*L"Process for all selected files was finished."*/,
					strngs[55]/*L"File defragmentation..."*/,MB_OK);
	bJobActive = FALSE;
	PostMessage(hWnd,WM_CLOSE,0,0);
}

VOID CalcLcnMaxMin(int k)
{
DWORD i;
	if(!pFileExtData)return;
	if(k)
	{	LCNmin = pFileExtData->Extents[0].Lcn;
		LCNmax = LCNmin+(pFileExtData->Extents[0].NextVcn-pFileExtData->StartingVcn);
		for(i=1; i<pFileExtData->ExtentCount; i++)
		{	if(LCNmax < pFileExtData->Extents[i].Lcn + 
					(pFileExtData->Extents[i].NextVcn-pFileExtData->Extents[i-1].NextVcn))
				LCNmax = pFileExtData->Extents[i].Lcn + 
					(pFileExtData->Extents[i].NextVcn-pFileExtData->Extents[i-1].NextVcn);
	}	}
	cellsCnt = LCNmax-LCNmin;
}