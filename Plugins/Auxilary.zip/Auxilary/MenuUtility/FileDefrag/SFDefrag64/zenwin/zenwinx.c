/*
* ZenWINX - WIndows Native eXtended library.
* Copyright (c) 2007-2013 Dmitri Arkhangelski (dmitriar@gmail.com).
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 2 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#pragma warning(disable:4005)
#pragma warning(disable:4013)
#pragma warning(disable:4996)

#include "ntfs.h"
#include "..\MyNTDLL64.h"//ntndk.h"
#include "setypes.h"


void winx_init_case_tables(void);
int winx_create_global_heap(void);
void winx_destroy_global_heap(void);
int winx_dbg_init(void);
void winx_dbg_close(void);
void MarkWindowsBootAsSuccessful(void);
char *winx_get_status_description(unsigned long status);
void kb_close(void);


int winx_init_library(void)
{
 winx_init_case_tables();
 if(winx_create_global_heap() < 0)
 return (-1);
 if(winx_dbg_init() < 0)
 return (-1);
 return 0;
}

void winx_unload_library(void)
{
 winx_dbg_close();
 winx_destroy_global_heap();
}

static void print_post_scriptum(char *msg,NTSTATUS Status)
{
 char buffer[256];

 _snprintf(buffer,sizeof(buffer),"\n%s: %x: %s\n\n",
 msg,(UINT)Status,winx_get_status_description(Status));
 buffer[sizeof(buffer) - 1] = 0;
 /* winx_printf cannot be used here */
 winx_print(buffer);
}

void winx_exit(int exit_code)
{
 NTSTATUS Status;

 kb_close();
 winx_flush_dbg_log(0);
  Status = NtTerminateProcess(NtCurrentProcess(),exit_code);
  if(!NT_SUCCESS(Status))
  {
	print_post_scriptum("winx_exit: cannot terminate process",Status);
  }
 }
 
 void winx_reboot(void)
 {
  NTSTATUS Status;
 
  kb_close();
  MarkWindowsBootAsSuccessful();
  (void)winx_enable_privilege(SE_SHUTDOWN_PRIVILEGE);
  winx_flush_dbg_log(0);
  Status = NtShutdownSystem(ShutdownReboot);
  if(!NT_SUCCESS(Status)){
  print_post_scriptum("winx_reboot: cannot reboot the computer",Status);
  }
 }
 
 void winx_shutdown(void)
 {
  NTSTATUS Status;
 
  kb_close();
  MarkWindowsBootAsSuccessful();
  (void)winx_enable_privilege(SE_SHUTDOWN_PRIVILEGE);
  winx_flush_dbg_log(0);
  Status = NtShutdownSystem(ShutdownPowerOff);
  if(!NT_SUCCESS(Status)){
  print_post_scriptum("winx_shutdown: cannot shut down the computer",Status);
  }
 }
 
