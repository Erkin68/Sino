#include "MyNTDLL64.h"


NtAdjustPrivilegesToken_t       NtAdjustPrivilegesToken=NULL;
NtAllocateVirtualMemory_t       NtAllocateVirtualMemory=NULL;
NtCancelIoFile_t                NtCancelIoFile=NULL;
NtClearEvent_t                  NtClearEvent=NULL;
NtClose_t                       NtClose=NULL;
NtCreateEvent_t                 NtCreateEvent=NULL;
NtCreateFile_t                  NtCreateFile=NULL;
NtCreateKey_t                   NtCreateKey=NULL;
NtCreateMutant_t                NtCreateMutant=NULL;
NtDeleteFile_t                  NtDeleteFile=NULL;
NtDelayExecution_t              NtDelayExecution=NULL;
NtDeviceIoControlFile_t         NtDeviceIoControlFile=NULL;
NtDisplayString_t               NtDisplayString=NULL;
NtFlushBuffersFile_t            NtFlushBuffersFile=NULL;
NtFlushKey_t                    NtFlushKey=NULL;
NtFreeVirtualMemory_t           NtFreeVirtualMemory=NULL;
NtFsControlFile_t               NtFsControlFile=NULL;
NtInitializeRegistry_t          NtInitializeRegistry=NULL;
NtLoadDriver_t                  NtLoadDriver=NULL;
NtMapViewOfSection_t            NtMapViewOfSection=NULL;
NtOpenEvent_t                   NtOpenEvent=NULL;
NtOpenKey_t                     NtOpenKey=NULL;
NtOpenMutant_t                  NtOpenMutant=NULL;
NtOpenProcessToken_t            NtOpenProcessToken=NULL;
NtOpenSection_t                 NtOpenSection=NULL;
NtOpenSymbolicLinkObject_t      NtOpenSymbolicLinkObject=NULL;
NtQueryDirectoryFile_t          NtQueryDirectoryFile=NULL;
NtQueryInformationFile_t        NtQueryInformationFile=NULL;
NtQueryInformationProcess_t     NtQueryInformationProcess=NULL;
NtQueryPerformanceCounter_t     NtQueryPerformanceCounter=NULL;
NtQuerySymbolicLinkObject_t     NtQuerySymbolicLinkObject=NULL;
NtQuerySystemTime_t             NtQuerySystemTime=NULL;
NtQueryKey_t                    NtQueryKey=NULL;
NtEnumerateValueKey_t           NtEnumerateValueKey=NULL;
NtQueryValueKey_t               NtQueryValueKey=NULL;
NtQueryVolumeInformationFile_t  NtQueryVolumeInformationFile=NULL;
NtReadFile_t                    NtReadFile=NULL;
NtReleaseMutant_t               NtReleaseMutant=NULL;
NtSetEvent_t                    NtSetEvent=NULL;
NtSetInformationProcess_t       NtSetInformationProcess=NULL;
NtSetSystemPowerState_t         NtSetSystemPowerState=NULL;
NtSetValueKey_t                 NtSetValueKey=NULL;
NtShutdownSystem_t              NtShutdownSystem=NULL;
NtTerminateProcess_t            NtTerminateProcess=NULL;
NtWaitForSingleObject_t         NtWaitForSingleObject=NULL;
NtWriteFile_t                   NtWriteFile=NULL;
NtUnloadDriver_t                NtUnloadDriver=NULL;
NtUnmapViewOfSection_t          NtUnmapViewOfSection=NULL;
								
RtlAdjustPrivilege_t            RtlAdjustPrivilege=NULL;
RtlAllocateHeap_t               RtlAllocateHeap=NULL;
RtlAnsiStringToUnicodeString_t  RtlAnsiStringToUnicodeString=NULL;
RtlCreateHeap_t                 RtlCreateHeap=NULL;
RtlCreateUnicodeString_t        RtlCreateUnicodeString=NULL;
RtlCreateUserThread_t           RtlCreateUserThread=NULL;
RtlDestroyHeap_t                RtlDestroyHeap=NULL;
RtlDosPathNameToNtPathName_U_t  RtlDosPathNameToNtPathName_U=NULL;
//RtlExitUserThread_t           RtlExitUserThread=NULL;
RtlExpandEnvironmentStrings_U_t RtlExpandEnvironmentStrings_U=NULL;
RtlFindMessage_t                RtlFindMessage=NULL;
RtlFreeAnsiString_t             RtlFreeAnsiString=NULL;
RtlFreeHeap_t                   RtlFreeHeap=NULL;
RtlFreeUnicodeString_t          RtlFreeUnicodeString=NULL;
RtlGetVersion_t                 RtlGetVersion=NULL;
RtlInitAnsiString_t             RtlInitAnsiString=NULL;
RtlInitUnicodeString_t          RtlInitUnicodeString=NULL;
RtlNormalizeProcessParams_t     RtlNormalizeProcessParams=NULL;
RtlNtStatusToDosError_t		    RtlNtStatusToDosError=NULL;
RtlQueryEnvironmentVariable_U_t RtlQueryEnvironmentVariable_U=NULL;
RtlQueryRegistryValues_t        RtlQueryRegistryValues=NULL;
RtlSetEnvironmentVariable_t     RtlSetEnvironmentVariable=NULL;
RtlSystemTimeToLocalTime_t      RtlSystemTimeToLocalTime=NULL;
RtlTimeToTimeFields_t           RtlTimeToTimeFields=NULL;
RtlUnicodeStringToAnsiString_t  RtlUnicodeStringToAnsiString=NULL;
RtlUnicodeToMultiByteN_t        RtlUnicodeToMultiByteN=NULL;
RtlWriteRegistryValue_t         RtlWriteRegistryValue=NULL;
								
DbgBreakPoint_t                 DbgBreakPoint=NULL;
LdrGetDllHandle_t               LdrGetDllHandle=NULL;
LdrGetProcedureAddress_t        LdrGetProcedureAddress=NULL;
ZwQuerySystemInformation_t      ZwQuerySystemInformation=NULL;
ZwTerminateThread_t             ZwTerminateThread=NULL;

/*BOOL GetWow6432Path(wchar_t *path,DWORD *pathLen)
{
HKEY k,subk;wchar_t keyName[MAX_PATH],winDir[MAX_PATH];
DWORD ind=0,keyNameSz,pathLn;BOOL bFindPath=FALSE;
	int winDirLen=GetWindowsDirectory(winDir,MAX_PATH);
	//Find for sytem Wow6432 path
	if(ERROR_SUCCESS!=RegOpenKeyExW(HKEY_LOCAL_MACHINE,L"SOFTWARE\\Wow6432Node\\Classes\\CLSID",0,KEY_READ,&k))
		return FALSE;
	while(!bFindPath)
	{	keyNameSz=MAX_PATH;keyName[0]=0;
		if(ERROR_SUCCESS!=RegEnumKeyEx(k,ind++,keyName,&keyNameSz,NULL,NULL,NULL,NULL))break;
		if(0==keyName[0])continue;
		if(ERROR_SUCCESS!=RegOpenKeyExW(k,keyName,0,KEY_READ,&subk))break;
		pathLn = *pathLen;
		if(ERROR_SUCCESS==RegGetValue(subk,L"InprocServer32",NULL,RRF_RT_REG_SZ,NULL,path,&pathLn))
		{	if(0==_wcsnicmp(path,winDir,winDirLen))
			{	wchar_t *p = wcschr(&path[winDirLen+1],'\\');
				if(p)
				{	*p=0;//*(p+1)=0;
					*pathLen = (DWORD)(p-&path[0]);
				}
				else *pathLen = pathLn;
				bFindPath=TRUE;
		}	}
		RegCloseKey(subk);
	}
	RegCloseKey(k);
	return bFindPath;
}*/

BOOL LoadNT64Library()
{
HMODULE hm;DWORD pathLen=MAX_PATH;wchar_t wow6432Path[MAX_PATH];
	pathLen=GetSystemWow64Directory(wow6432Path,MAX_PATH);//if(!GetWow6432Path(wow6432Path,&pathLen))return FALSE;
	MyStringCpy(&wow6432Path[pathLen],MAX_PATH-pathLen,L"\\ntdll.dll");
	//bRet = Wow64EnableWow64FsRedirection(TRUE);
	//bRet = Wow64DisableWow64FsRedirection(FALSE);
	//hm = LoadLibraryEx(wow6432Path,NULL,LOAD_WITH_ALTERED_SEARCH_PATH);
	//pathLen=GetLastError();
	hm = LoadLibraryEx(L"ntdll.dll",NULL,LOAD_WITH_ALTERED_SEARCH_PATH);

	//GetModuleFileName(hm,wow6432Path,MAX_PATH);

	if(!hm)return FALSE;
	NtAdjustPrivilegesToken=(NtAdjustPrivilegesToken_t)GetProcAddress(hm,"NtAdjustPrivilegesToken");
	NtAllocateVirtualMemory=(NtAllocateVirtualMemory_t)GetProcAddress(hm,"NtAllocateVirtualMemory");
	NtCancelIoFile=(NtCancelIoFile_t)GetProcAddress(hm,"NtCancelIoFile");
	NtClearEvent=(NtClearEvent_t)GetProcAddress(hm,"NtClearEvent");
	NtClose=(NtClose_t)GetProcAddress(hm,"NtClose");
	NtCreateEvent=(NtCreateEvent_t)GetProcAddress(hm,"NtCreateEvent");
	NtCreateFile=(NtCreateFile_t)GetProcAddress(hm,"NtCreateFile");
	NtCreateKey=(NtCreateKey_t)GetProcAddress(hm,"NtCreateKey");
	NtCreateMutant=(NtCreateMutant_t)GetProcAddress(hm,"NtCreateMutant");
	NtDeleteFile=(NtDeleteFile_t)GetProcAddress(hm,"NtDeleteFile");
	NtDelayExecution=(NtDelayExecution_t)GetProcAddress(hm,"NtDelayExecution");
	NtDeviceIoControlFile=(NtDeviceIoControlFile_t)GetProcAddress(hm,"NtDeviceIoControlFile");
	NtDisplayString=(NtDisplayString_t)GetProcAddress(hm,"NtDisplayString");
	NtFlushBuffersFile=(NtFlushBuffersFile_t)GetProcAddress(hm,"NtFlushBuffersFile");
	NtFlushKey=(NtFlushKey_t)GetProcAddress(hm,"NtFlushKey");
	NtFreeVirtualMemory=(NtFreeVirtualMemory_t)GetProcAddress(hm,"NtFreeVirtualMemory");
	NtFsControlFile=(NtFsControlFile_t)GetProcAddress(hm,"NtFsControlFile");
	NtInitializeRegistry=(NtInitializeRegistry_t)GetProcAddress(hm,"NtInitializeRegistry");
	NtLoadDriver=(NtLoadDriver_t)GetProcAddress(hm,"NtLoadDriver");
	NtMapViewOfSection=(NtMapViewOfSection_t)GetProcAddress(hm,"NtMapViewOfSection");
	NtOpenEvent=(NtOpenEvent_t)GetProcAddress(hm,"NtOpenEvent");
	NtOpenKey=(NtOpenKey_t)GetProcAddress(hm,"NtOpenKey");
	NtOpenMutant=(NtOpenMutant_t)GetProcAddress(hm,"NtOpenMutant");
	NtOpenProcessToken=(NtOpenProcessToken_t)GetProcAddress(hm,"NtOpenProcessToken");
	NtOpenSection=(NtOpenSection_t)GetProcAddress(hm,"NtOpenSection");
	NtOpenSymbolicLinkObject=(NtOpenSymbolicLinkObject_t)GetProcAddress(hm,"NtOpenSymbolicLinkObject");
	NtQueryDirectoryFile=(NtQueryDirectoryFile_t)GetProcAddress(hm,"NtQueryDirectoryFile");
	NtQueryInformationFile=(NtQueryInformationFile_t)GetProcAddress(hm,"NtQueryInformationFile");
	NtQueryInformationProcess=(NtQueryInformationProcess_t)GetProcAddress(hm,"NtQueryInformationProcess");
	NtQueryPerformanceCounter=(NtQueryPerformanceCounter_t)GetProcAddress(hm,"NtQueryPerformanceCounter");
	NtQuerySymbolicLinkObject=(NtQuerySymbolicLinkObject_t)GetProcAddress(hm,"NtQuerySymbolicLinkObject");
	NtQuerySystemTime=(NtQuerySystemTime_t)GetProcAddress(hm,"NtQuerySystemTime");
	NtQueryKey=(NtQueryKey_t)GetProcAddress(hm,"NtQueryKey");
	NtEnumerateValueKey=(NtEnumerateValueKey_t)GetProcAddress(hm,"NtEnumerateValueKey");
	NtQueryValueKey=(NtQueryValueKey_t)GetProcAddress(hm,"NtQueryValueKey");
	NtQueryVolumeInformationFile=(NtQueryVolumeInformationFile_t)GetProcAddress(hm,"NtQueryVolumeInformationFile");
	NtReadFile=(NtReadFile_t)GetProcAddress(hm,"NtReadFile");
	NtReleaseMutant=(NtReleaseMutant_t)GetProcAddress(hm,"NtReleaseMutant");
	NtSetEvent=(NtSetEvent_t)GetProcAddress(hm,"NtSetEvent");
	NtSetInformationProcess=(NtSetInformationProcess_t)GetProcAddress(hm,"NtSetInformationProcess");
	NtSetSystemPowerState=(NtSetSystemPowerState_t)GetProcAddress(hm,"NtSetSystemPowerState");
	NtSetValueKey=(NtSetValueKey_t)GetProcAddress(hm,"NtSetValueKey");
	NtShutdownSystem=(NtShutdownSystem_t)GetProcAddress(hm,"NtShutdownSystem");
	NtTerminateProcess=(NtTerminateProcess_t)GetProcAddress(hm,"NtTerminateProcess");
	NtWaitForSingleObject=(NtWaitForSingleObject_t)GetProcAddress(hm,"NtWaitForSingleObject");
	NtWriteFile=(NtWriteFile_t)GetProcAddress(hm,"NtWriteFile");
	NtUnloadDriver=(NtUnloadDriver_t)GetProcAddress(hm,"NtUnloadDriver");
	NtUnmapViewOfSection=(NtUnmapViewOfSection_t)GetProcAddress(hm,"NtUnmapViewOfSection");
																					  
	RtlAdjustPrivilege=(RtlAdjustPrivilege_t)GetProcAddress(hm,"RtlAdjustPrivilege");
	RtlAllocateHeap=(RtlAllocateHeap_t)GetProcAddress(hm,"RtlAllocateHeap");
	RtlAnsiStringToUnicodeString=(RtlAnsiStringToUnicodeString_t)GetProcAddress(hm,"RtlAnsiStringToUnicodeString");
	RtlCreateHeap=(RtlCreateHeap_t)GetProcAddress(hm,"RtlCreateHeap");
	RtlCreateUnicodeString=(RtlCreateUnicodeString_t)GetProcAddress(hm,"RtlCreateUnicodeString");
	RtlCreateUserThread=(RtlCreateUserThread_t)GetProcAddress(hm,"RtlCreateUserThread");
	RtlDestroyHeap=(RtlDestroyHeap_t)GetProcAddress(hm,"RtlDestroyHeap");
	RtlDosPathNameToNtPathName_U=(RtlDosPathNameToNtPathName_U_t)GetProcAddress(hm,"RtlDosPathNameToNtPathName_U");
//	RtlExitUserThread=(RtlExitUserThread_t)GetProcAddress(hm,"RtlExitUserThread");
	RtlExpandEnvironmentStrings_U=(RtlExpandEnvironmentStrings_U_t)GetProcAddress(hm,"RtlExpandEnvironmentStrings_U");
	RtlFindMessage=(RtlFindMessage_t)GetProcAddress(hm,"RtlFindMessage");
	RtlFreeAnsiString=(RtlFreeAnsiString_t)GetProcAddress(hm,"RtlFreeAnsiString");
	RtlFreeHeap=(RtlFreeHeap_t)GetProcAddress(hm,"RtlFreeHeap");
	RtlFreeUnicodeString=(RtlFreeUnicodeString_t)GetProcAddress(hm,"RtlFreeUnicodeString");
	RtlGetVersion=(RtlGetVersion_t)GetProcAddress(hm,"RtlGetVersion");
	RtlInitAnsiString=(RtlInitAnsiString_t)GetProcAddress(hm,"RtlInitAnsiString");
	RtlInitUnicodeString=(RtlInitUnicodeString_t)GetProcAddress(hm,"RtlInitUnicodeString");
	RtlNormalizeProcessParams=(RtlNormalizeProcessParams_t)GetProcAddress(hm,"RtlNormalizeProcessParams");
	RtlNtStatusToDosError=(RtlNtStatusToDosError_t)GetProcAddress(hm,"RtlNtStatusToDosError");
	RtlQueryEnvironmentVariable_U=(RtlQueryEnvironmentVariable_U_t)GetProcAddress(hm,"RtlQueryEnvironmentVariable_U");
	RtlQueryRegistryValues=(RtlQueryRegistryValues_t)GetProcAddress(hm,"RtlQueryRegistryValues");
	RtlSetEnvironmentVariable=(RtlSetEnvironmentVariable_t)GetProcAddress(hm,"RtlSetEnvironmentVariable");
	RtlSystemTimeToLocalTime=(RtlSystemTimeToLocalTime_t)GetProcAddress(hm,"RtlSystemTimeToLocalTime");
	RtlTimeToTimeFields=(RtlTimeToTimeFields_t)GetProcAddress(hm,"RtlTimeToTimeFields");
	RtlUnicodeStringToAnsiString=(RtlUnicodeStringToAnsiString_t)GetProcAddress(hm,"RtlUnicodeStringToAnsiString");
	RtlUnicodeToMultiByteN=(RtlUnicodeToMultiByteN_t)GetProcAddress(hm,"RtlUnicodeToMultiByteN");
	RtlWriteRegistryValue=(RtlWriteRegistryValue_t)GetProcAddress(hm,"RtlWriteRegistryValue");
																					  
	DbgBreakPoint=(DbgBreakPoint_t)GetProcAddress(hm,"DbgBreakPoint");
	LdrGetDllHandle=(LdrGetDllHandle_t)GetProcAddress(hm,"LdrGetDllHandle");
	LdrGetProcedureAddress=(LdrGetProcedureAddress_t)GetProcAddress(hm,"LdrGetProcedureAddress");
	ZwQuerySystemInformation=(ZwQuerySystemInformation_t)GetProcAddress(hm,"ZwQuerySystemInformation");
	ZwTerminateThread=(ZwTerminateThread_t)GetProcAddress(hm,"ZwTerminateThread");

	return TRUE;
}