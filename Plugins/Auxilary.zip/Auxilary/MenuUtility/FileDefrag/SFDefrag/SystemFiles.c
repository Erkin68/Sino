#include "zenwin/ntndk.h"
#include "zenwin/ntfs.h"
#include "zenwin/zenwinx.h"
#include "SFDefrag.h"



int filter(winx_file_info*,void*);
void progress_callback(winx_file_info*,void*);
int terminator(void*);
extern wchar_t hStatText[2*MAX_PATH];


/* Return the number of fragments in the file and the size of the
   file in clusters. If the file could not be opened then return
   zero fragments. Very small files are stored by Windows in the
   MFT and the number of clusters will then be zero. */
DWORD AnalyzeFile(wchar_t *FileName,int Directory,ULONGLONG *Fragments,
				  ULONGLONG *RealClusters,ULONGLONG *UncompressedClusters,ULONG64 *Lcn)
{
  HANDLE FileHandle;
  ULONG64 PreviousVcn,PreviousLcn;
  IO_STATUS_BLOCK iosb;
  DWORD d;
  size_t filemapSize;
  int extSz = 100,Result;

  wsprintf(hStatText,strngs[43]/*L"%s - analyze file fragmentation level ..."*/,FileName);
  SetWindowText(hStat,hStatText);

  *Fragments = 0;
  *RealClusters = 0;
  *UncompressedClusters = 0;
  *Lcn = 0;

  FileHandle = CreateFileW(FileName,FILE_READ_ATTRIBUTES,//FILE_GENERIC_READ | SYNCHRONIZE
							FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE,
							NULL,OPEN_EXISTING,FILE_FLAG_NO_BUFFERING,NULL);
  if(FileHandle == INVALID_HANDLE_VALUE)//Encrypted file:
  {	FileHandle = CreateFileW(FileName,GENERIC_READ,
							FILE_SHARE_READ | FILE_SHARE_WRITE,
							NULL,OPEN_EXISTING,FILE_FLAG_BACKUP_SEMANTICS,NULL);
	if(FileHandle == INVALID_HANDLE_VALUE)
	{	if(FileHandle == INVALID_HANDLE_VALUE)
		{	//DWORD d = GetLastError();
			wsprintf(hStatText,strngs[44]/*L"%s - analyze file,can't open file."*/,FileName);
			SetWindowText(hStat,hStatText);
			return -1;
  }	}	}

  pFileExtData = 0;

  /* Get the clustermap of this file. The loop will repeat if there
     are more datablocks than fit in the Data. */
  PreviousLcn = MAXULONG64;
  PreviousVcn = 0;
  LCNmin = MAXULONG64;
  LCNmax = 0;

  wsprintf(hStatText,strngs[45]/*L"%s - analyze file,open successfully, go to get retrival pointers ..."*/,FileName);
  SetWindowText(hStat,hStatText);

  do
  { filemapSize = sizeof(ExtentData)+extSz*2*sizeof(ULONG64);
	if(!pFileExtData)
		pFileExtData = (ExtentData*)malloc((size_t)filemapSize);
	else
		pFileExtData = (ExtentData*)realloc(pFileExtData,filemapSize);
	/*Result = DeviceIoControl(FileHandle,FSCTL_GET_RETRIEVAL_POINTERS,&InBuffer,
							   sizeof(InBuffer),pFileExtData,filemapSize,&w,NULL);
    if(Result == 0)
	{ Result = GetLastError();
      if(Result != ERROR_MORE_DATA || ERROR_INSUFFICIENT_BUFFER == Result)
	  {	  extSz += extSz;
		  continue;
    } }*/
	memset(pFileExtData,0,filemapSize);
	Result = NtFsControlFile(FileHandle,NULL,NULL,0,&iosb,FSCTL_GET_RETRIEVAL_POINTERS,
							&pFileExtData->StartingVcn,sizeof(ULONGLONG),pFileExtData,filemapSize);
	if(NT_SUCCESS(Result))
	{	NtWaitForSingleObject(FileHandle,FALSE,NULL);
		Result = iosb.Status;
	}
	if(Result == STATUS_BUFFER_OVERFLOW)
	{	extSz += extSz;
		continue;
	}
	if(Result != STATUS_SUCCESS)
	{	if(Result == STATUS_END_OF_FILE)
			goto End;
	}

    wsprintf(hStatText,strngs[46]/*L"%s - analyze file,get retrival pointers successfully,analyze data ..."*/,FileName);
    SetWindowText(hStat,hStatText);

    // Count the number of fragments, and calculate the total number of clusters used by this file.
    if(PreviousVcn == 0) PreviousVcn = pFileExtData->StartingVcn;
    for(d=0; d<pFileExtData->ExtentCount; d++)
    { //wsprintf(s1,L"  Extent %u, Lcn=%I64u, Vcn=%I64u, NextVcn=%I64u",
      //  d+1,pFileExtData->Extents[d].Lcn,PreviousVcn,pFileExtData->Extents[d].NextVcn);
      //if(SystemFile == NO) ShowDebugMessage(3,NULL,s1);

	  if(LCNmin > pFileExtData->Extents[d].Lcn)
		LCNmin = pFileExtData->Extents[d].Lcn;

      if(PreviousLcn == MAXULONG64) *Lcn = pFileExtData->Extents[d].Lcn;
      if(pFileExtData->Extents[d].Lcn != MAXULONG64)
      { if(pFileExtData->Extents[d].Lcn != PreviousLcn) *Fragments = *Fragments + 1;
        PreviousLcn = pFileExtData->Extents[d].Lcn + (DWORD)(pFileExtData->Extents[d].NextVcn - PreviousVcn);
        *RealClusters = *RealClusters + (DWORD)(pFileExtData->Extents[d].NextVcn - PreviousVcn);
      }

	  if(LCNmax < pFileExtData->Extents[d].Lcn + (DWORD)(pFileExtData->Extents[d].NextVcn - PreviousVcn))
		LCNmax = pFileExtData->Extents[d].Lcn + (DWORD)(pFileExtData->Extents[d].NextVcn - PreviousVcn);

      *UncompressedClusters = *UncompressedClusters + (DWORD)(pFileExtData->Extents[d].NextVcn - PreviousVcn);
      PreviousVcn = pFileExtData->Extents[d].NextVcn;
    }

    // Next datablock.
  } while(Result == ERROR_MORE_DATA);

End:
  //free(pFileExtData);
  CloseHandle(FileHandle);

  wsprintf(hStatText,strngs[47]/*L"%s - finish analyzing file."*/,FileName);
  SetWindowText(hStat,hStatText);

  return pFileExtData->ExtentCount;//(YES);
}

DWORD AnalyzeSystemFile(wchar_t *FileName,int Directory,ULONGLONG *Fragments,ULONGLONG *RealClusters,
					    ULONGLONG *UncompressedClusters,ULONGLONG *Lcn,DWORD attrb)
{
//open volume
  int	result;
  char f_flags[2]={'r',0};
  wchar_t s[8]=L"\\??\\c:";//,ws[2*MAX_PATH];
  mft_scan_parameters sp;
  winx_file_info *filelist = NULL,*findEntry=NULL;
  sp.filelist = &filelist;
  sp.processed_attr_list_entries = 0;
  sp.errors = 0;
  sp.fcb = filter;
  sp.pcb = progress_callback;
  sp.t = terminator;
  sp.flags = WINX_FTW_SKIP_RESIDENT_STREAMS | WINX_FTW_DUMP_FILES |
			 WINX_FTW_SKIP_RESIDENT_STREAMS | WINX_FTW_ALLOW_PARTIAL_SCAN;

  wsprintf(hStatText,strngs[48]/*L"%s - analyze system file ..."*/,FileName);
  SetWindowText(hStat,hStatText);

  if(FileName[0] >= 'A' && FileName[0] <= 'Z')
	sp.volume_letter = 'A' + (int)(FileName[0]-'A');
  else if(FileName[0] >= 'a' && FileName[0] <= 'z')
	sp.volume_letter = 'a' + (int)(FileName[0]-'a');
  else
	sp.volume_letter = 'c';

  s[4]=sp.volume_letter;

  //sp.user_defined_data = user_defined_data;

  sp.f_volume = winx_fopen(s,f_flags);
  if(sp.f_volume == NULL)
	return 0;

  wsprintf(hStatText,strngs[49]/*L"%s - analyze system file,start scanning mft ..."*/,FileName);
  SetWindowText(hStat,hStatText);

  /* scan mft directly -> add all files to the list */
  result = scan_mft_find_file(&sp,FileName,attrb,&findEntry,TRUE);//FALSE); tezi chala bo'larkan;
  /*if(result < 0)//to'liq kovlasunchi....
  {	wsprintf(ws,L"Fast nrfs search %s fail,try full search...",s);
	SetWindowText(hStat,ws);
	result = scan_mft_find_file(&sp,FileName,attrb,&findEntry,TRUE);
  }*/

  wsprintf(hStatText,strngs[50]/*L"%s - analyze system file,finish scanning mft ..."*/,FileName);
  SetWindowText(hStat,hStatText);

  if(result>-1)//udachno,free bizdan;
  {	
#define nFrgmnts findEntry->disp.fragments
	if(nFrgmnts<1) result = -1;
	else
	{	ULONG64 i,vcnsum;winx_blockmap *b;
		pFileExtData = (ExtentData*)malloc(sizeof(ExtentData)+(size_t)(nFrgmnts*2*sizeof(ULONG64)));
		pFileExtData->ExtentCount = (DWORD)nFrgmnts;
		pFileExtData->StartingVcn = findEntry->disp.blockmap[0].vcn;
		pFileExtData->Extents[0].Lcn = findEntry->disp.blockmap[0].lcn;
		vcnsum = pFileExtData->StartingVcn+findEntry->disp.blockmap[0].length;
		pFileExtData->Extents[0].NextVcn = vcnsum;

        *RealClusters = findEntry->disp.blockmap[0].length;
		*UncompressedClusters = (DWORD)(pFileExtData->Extents[0].NextVcn);
		*Lcn = findEntry->disp.blockmap[0].lcn;

		*Fragments = 1;
		b = findEntry->disp.blockmap->next;			
		for(i=1; i<nFrgmnts; i++)
		{	vcnsum += b->length;
			pFileExtData->Extents[i].NextVcn = vcnsum;
			pFileExtData->Extents[i].Lcn = b->lcn;

			if(pFileExtData->Extents[i].Lcn != pFileExtData->Extents[i-1].Lcn+b->length)
				*Fragments = *Fragments + 1;

			*RealClusters = *RealClusters + findEntry->disp.blockmap[0].length;
			*UncompressedClusters = *UncompressedClusters + (DWORD)(pFileExtData->Extents[i].NextVcn - pFileExtData->Extents[i-1].NextVcn);

			b = b->next;
	}	}


	winx_ftw_release(*sp.filelist);//winx_ftw_release_maniki(&sp.filelist,iNumEntry);
	sp.filelist = NULL;//  glHeap i b-n ochiramiz;
#undef nFrgmnts
  }
  winx_fclose(sp.f_volume);

  wsprintf(hStatText,strngs[51]/*L"%s - finishing analyze system file ..."*/,FileName);
  SetWindowText(hStat,hStatText);

  //winx_unload_library();
  //winx_init_library();
  return pFileExtData->ExtentCount;
}

int filter(winx_file_info *f,void *user_defined_data)
{
//  udefrag_job_parameters *jp = (udefrag_job_parameters*)user_defined_data;
  int length;
 
  /* START OF AUX CODE */
 
  /* skip entries with empty path, as well as their children */
  if(f->path == NULL) goto skip_file_and_children;
  if(f->path[0] == 0) goto skip_file_and_children;
 
  /*
  * Skip resident streams, but not in context menu
  * handler, where they're needed for statistics.
  */
//  if(f->disp.fragments == 0 && !(jp->udo.job_flags & UD_JOB_CONTEXT_MENU_HANDLER))
//  return 0;
 
  /*
  * Remove trailing dot from the root
  * directory path, otherwise we'll not
  * be able to defragment it.
  */
  length = wcslen(f->path);
  if(length >= 2)
  {  if(f->path[length - 1] == '.' && f->path[length - 2] == '\\')
	 {  itrace("root directory detected, its trailing dot will be removed");
		f->path[length - 1] = 0;
  }  }
 
  /* skip resident streams in context menu handler, but count them */
  if(f->disp.fragments == 0)
  {  //if(!exclude_by_path(f,jp))
	 //	update_progress_counters(f,jp);
	  return 0;
  }
 
  /* show debugging information about interesting cases */
  if(is_sparse(f))
  dtrace("sparse file found: %ws",f->path);
  if(is_reparse_point(f))
  dtrace("reparse point found: %ws",f->path);
  /* comment it out after testing to speed things up */
  /*if(winx_wcsistr(f->path,L"$BITMAP"))
  dtrace("bitmap found: %ws",f->path);
  if(winx_wcsistr(f->path,L"$ATTRIBUTE_LIST"))
  dtrace("attribute list found: %ws",f->path);
  */
 
  /* START OF FILTERING */
 
  /* skip files with invalid map */
  if(f->disp.blockmap == NULL)
  goto skip_file;
 
  /* skip temporary files */
  if(is_temporary(f))
  goto skip_file;
 
  /* filter files by their sizes */
//  if(exclude_by_size(f,jp))
//  goto skip_file;
 
  /* filter files by their number of fragments */
//  if(exclude_by_fragments(f,jp))
//  goto skip_file;
 
  /* filter files by their fragment sizes */
//  if(exclude_by_fragment_size(f,jp))
//  goto skip_file;
 
  /* filter files by their paths */
//  if(exclude_by_path(f,jp)){
//  f->user_defined_flags |= UD_FILE_EXCLUDED;
//  f->user_defined_flags |= UD_FILE_EXCLUDED_BY_PATH;
//  }
  /* don't skip children since their paths may match patterns */
  return 0;
 
 skip_file:
//  f->user_defined_flags |= UD_FILE_EXCLUDED;
  return 0;
 
 skip_file_and_children:
 // f->user_defined_flags |= UD_FILE_EXCLUDED;
  return 1;
}

void progress_callback(winx_file_info *f,void *user_defined_data)
{
  //udefrag_job_parameters *jp = (udefrag_job_parameters*)user_defined_data;
 
  /* don't count excluded files in context menu handler */
  //if(!(jp->udo.job_flags & UD_JOB_CONTEXT_MENU_HANDLER))
  //update_progress_counters(f,jp);
}

int terminator(void *user_defined_data)
{
//  udefrag_job_parameters *jp = (udefrag_job_parameters *)user_defined_data;
 
//  return jp->termination_router((void*)jp);
	return 0;
}
