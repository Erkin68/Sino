#include "windows.h"
#include "SFDefrag.h"



FileListS *pFileList=NULL;
ExtentData *pFileExtData=NULL;
UInt64 LCNmin=0,LCNmax=0;


VOID FileDefrag()
{
int tot=SendMessage(hLB,LB_GETCOUNT,0,0);
//	while(tot>0)
	{	wchar_t s[MAX_PATH];
		SendMessageW(hLB,LB_GETTEXT,0,(LPARAM)s);

		DWORD Fragments,RealClusters,UncompressedClusters;ULONG64 Lcn;

		int vcnChunkNums=AnalyzeFile(s,0,&Fragments,&RealClusters,&UncompressedClusters,&Lcn);//,RGB(0,255,255),RGB(0,0,255));
		CalcLcnMaxMin();
		CalcResizeParams(0);

		Render(0);//pFileExtData,vcnChunkNums,&Fragments,&RealClusters,&UncompressedClusters,&Lcn);

		//DefragFile(s);
		
//		if(vcnChunkNums)
//			free(pFileExtData);
//		pFileExtData = 0;

//		SendMessageW(hLB,LB_DELETESTRING,0,0);
//		tot=SendMessage(hLB,LB_GETCOUNT,0,0);
}	}


/* Return the number of fragments in the file and the size of the
   file in clusters. If the file could not be opened then return
   zero fragments. Very small files are stored by Windows in the
   MFT and the number of clusters will then be zero. */
int AnalyzeFile(wchar_t *FileName,int Directory,DWORD *Fragments,DWORD *RealClusters,
				DWORD *UncompressedClusters,ULONG64 *Lcn)
{
  HANDLE FileHandle;
  STARTING_VCN_INPUT_BUFFER InBuffer;
  ULONG64 PreviousVcn;
  ULONG64 PreviousLcn;
  int extSz = 100;
  int Result;
  DWORD d;
  DWORD w;

  SetWindowText(hStat,FileName);	

  *Fragments = 0;
  *RealClusters = 0;
  *UncompressedClusters = 0;
  *Lcn = 0;
  //SystemFile = IsSystemFile(FileName);

  /* Open the item as a file or as a directory. If the item could
     not be opened then exit. */
  //if(Directory == NO)
    FileHandle = CreateFileW(FileName,FILE_READ_ATTRIBUTES,
							FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE,
							NULL,OPEN_EXISTING,FILE_FLAG_NO_BUFFERING,NULL);
  //else
  //  FileHandle = CreateFileW(FileName,GENERIC_READ,
  //							FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE,
  //							NULL,OPEN_EXISTING,FILE_FLAG_BACKUP_SEMANTICS,NULL);
  if(FileHandle == INVALID_HANDLE_VALUE)//Encrypted file:
  {	FileHandle = CreateFileW(FileName,FILE_READ_DATA | FILE_WRITE_DATA | FILE_APPEND_DATA,
							FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE,
							NULL,OPEN_EXISTING,FILE_FLAG_NO_BUFFERING,NULL);
	if(FileHandle == INVALID_HANDLE_VALUE)
	{	FileHandle = CreateFileW(FileName,FILE_EXECUTE,
								FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE,
								NULL,OPEN_EXISTING,FILE_FLAG_NO_BUFFERING,NULL);
		if(FileHandle == INVALID_HANDLE_VALUE)
		{	OFSTRUCT os={sizeof(OFSTRUCT),0,0,0,0};
			INT t=LZOpenFile(FileName,&os,OF_SHARE_DENY_READ|OF_SHARE_EXCLUSIVE|OF_READ);
			if(t<0)
			{	DWORD d = GetLastError();
				return 0;
  }	}	}	}

  pFileExtData = 0;

  /* Get the clustermap of this file. The loop will repeat if there
     are more datablocks than fit in the Data. */
  InBuffer.StartingVcn.QuadPart = 0;
  PreviousLcn = MAXULONG64;
  PreviousVcn = 0;
  LCNmin = MAXULONG64;
  LCNmax = 0;

  do
  { if(!pFileExtData)
		pFileExtData = (ExtentData*)malloc(sizeof(ExtentData)+extSz*2*sizeof(ULONG64));
	else
		pFileExtData = (ExtentData*)realloc(pFileExtData,sizeof(ExtentData)+extSz*2*sizeof(ULONG64));
	  
	Result = DeviceIoControl(FileHandle,FSCTL_GET_RETRIEVAL_POINTERS,&InBuffer,
							 sizeof(InBuffer),pFileExtData,sizeof(ExtentData)+extSz*2*sizeof(ULONG64),&w,NULL);
    if(Result == 0)
	{ Result = GetLastError();
      if(Result != ERROR_MORE_DATA || ERROR_INSUFFICIENT_BUFFER == Result)
	  {	  extSz += extSz;
		  continue;
    } }

    // Count the number of fragments, and calculate the total number of clusters used by this file.
    if(PreviousVcn == 0) PreviousVcn = pFileExtData->StartingVcn;
    for(d=0; d<pFileExtData->ExtentCount; d++)
    { //wsprintf(s1,L"  Extent %u, Lcn=%I64u, Vcn=%I64u, NextVcn=%I64u",
      //  d+1,pFileExtData->Extents[d].Lcn,PreviousVcn,pFileExtData->Extents[d].NextVcn);
      //if(SystemFile == NO) ShowDebugMessage(3,NULL,s1);

	  if(LCNmin > pFileExtData->Extents[d].Lcn)
		LCNmin = pFileExtData->Extents[d].Lcn;

      if(PreviousLcn == MAXULONG64) *Lcn = pFileExtData->Extents[d].Lcn;
      if(pFileExtData->Extents[d].Lcn != MAXULONG64)
      { if(pFileExtData->Extents[d].Lcn != PreviousLcn) *Fragments = *Fragments + 1;
        PreviousLcn = pFileExtData->Extents[d].Lcn + (DWORD)(pFileExtData->Extents[d].NextVcn - PreviousVcn);
        *RealClusters = *RealClusters + (DWORD)(pFileExtData->Extents[d].NextVcn - PreviousVcn);
      }

	  if(LCNmax < pFileExtData->Extents[d].Lcn + (DWORD)(pFileExtData->Extents[d].NextVcn - PreviousVcn))
		LCNmax = pFileExtData->Extents[d].Lcn + (DWORD)(pFileExtData->Extents[d].NextVcn - PreviousVcn);

      *UncompressedClusters = *UncompressedClusters + (DWORD)(pFileExtData->Extents[d].NextVcn - PreviousVcn);
      PreviousVcn = pFileExtData->Extents[d].NextVcn;
    }

    // Next datablock.
    InBuffer.StartingVcn.QuadPart = PreviousVcn;
  } while(Result == ERROR_MORE_DATA);

  //free(pFileExtData);
  CloseHandle(FileHandle);
  return pFileExtData->ExtentCount;//(YES);
}

VOID CalcLcnMaxMin()
{	if(!pFileExtData)return;
/*	LCNmin = pFileExtData->Extents[0].Lcn;
	LCNmax = LCNmin+(pFileExtData->Extents[0].NextVcn-pFileExtData->StartingVcn);
	for(DWORD i=1; i<pFileExtData->ExtentCount; i++)
	{	if(LCNmax < pFileExtData->Extents[i].Lcn + 
				(pFileExtData->Extents[i].NextVcn-pFileExtData->Extents[i-1].NextVcn))
			LCNmax = pFileExtData->Extents[i].Lcn + 
				(pFileExtData->Extents[i].NextVcn-pFileExtData->Extents[i-1].NextVcn);
	}*/
	cellsCnt = LCNmax-LCNmin;
}
