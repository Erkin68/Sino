// SFDefrag.cpp : Defines the entry point for the application.
//

#include "windows.h"
#include "SFDefrag.h"
#include "stdio.h"
#include "strsafe.h"

#pragma warning(disable:4995)
#pragma warning(disable:4996)


// Global Variables:
int totFiles;
wchar_t *filesList;
wchar_t **strngs;
HWND hWnd,hStat,hLB,hBtnDfrg,hBtnExit,hDrawWnd;
HINSTANCE hInst;								// current instance
TCHAR szTitle[MAX_LOADSTRING];					// The title bar text
TCHAR szWindowClass[MAX_LOADSTRING];			// the main window class name
DWORD defrThrdId;
HBRUSH bckBrsh,grnBrsh,blueBrsh,redBrsh;

int APIENTRY WinMain(HINSTANCE hInstance,
				     HINSTANCE hPrevInstance,
                     LPSTR     lpCmdLine,
                     int       nCmdShow)
{
	/*WIN32_FIND_DATA ff;wchar_t s[MAX_PATH]=L"C:\\Windows\\system32\\*"; C:\Windows\system32\msvcp71.dll
	int l=MyStringLengthW(s,MAX_PATH);
	HANDLE h = FindFirstFile(s,&ff);
	do
	{	DWORD Fragments,RealClusters,UncompressedClusters;ULONG64 Lcn;
		MyStringCpyW(&s[l-1],MAX_PATH-12,ff.cFileName);
		if(!IsDirExistW(s))
			if(1<AnalyzeFile(s,0,&Fragments,&RealClusters,&UncompressedClusters,&Lcn))
				break;
		FindNextFile(h,&ff);
	} while(INVALID_HANDLE_VALUE!=h);*/

	UNREFERENCED_PARAMETER(hPrevInstance);
	UNREFERENCED_PARAMETER(lpCmdLine);

	if(!lpCmdLine) return FALSE;
	
 	// TODO: Place code here.
	MSG msg;
	HACCEL hAccelTable;

	// Initialize global strings
	LoadString(hInstance, IDS_APP_TITLE, szTitle, MAX_LOADSTRING);
	LoadString(hInstance, IDC_SFDEFRAG, szWindowClass, MAX_LOADSTRING);
	MyRegisterClass(hInstance);

	// Perform application initialization:
	if (!InitInstance (hInstance, nCmdShow))
	{
		return FALSE;
	}

	hAccelTable = LoadAccelerators(hInstance, MAKEINTRESOURCE(IDC_SFDEFRAG));

	// Main message loop:
	while(GetMessage(&msg, NULL, 0, 0))
	{	if(!TranslateAccelerator(msg.hwnd, hAccelTable, &msg))
		{	TranslateMessage(&msg);
			DispatchMessage(&msg);
	}	}

	return (int) msg.wParam;
}



//
//  FUNCTION: MyRegisterClass()
//
//  PURPOSE: Registers the window class.
//
//  COMMENTS:
//
//    This function and its usage are only necessary if you want this code
//    to be compatible with Win32 systems prior to the 'RegisterClassEx'
//    function that was added to Windows 95. It is important to call this function
//    so that the application will get 'well formed' small icons associated
//    with it.
//
ATOM MyRegisterClass(HINSTANCE hInstance)
{
	WNDCLASSEX wcex;

	wcex.cbSize = sizeof(WNDCLASSEX);

	wcex.style			= CS_HREDRAW | CS_VREDRAW;
	wcex.lpfnWndProc	= WndProc;
	wcex.cbClsExtra		= 0;
	wcex.cbWndExtra		= 0;
	wcex.hInstance		= hInstance;
	wcex.hIcon			= LoadIcon(hInstance, MAKEINTRESOURCE(IDI_SFDEFRAG));
	wcex.hCursor		= LoadCursor(NULL, IDC_ARROW);
	wcex.hbrBackground	= (HBRUSH)(COLOR_WINDOW+1);
	wcex.lpszMenuName	= NULL;//MAKEINTRESOURCE(IDC_SFDEFRAG);
	wcex.lpszClassName	= szWindowClass;
	wcex.hIconSm		= LoadIcon(wcex.hInstance, MAKEINTRESOURCE(IDI_SMALL));

	return RegisterClassEx(&wcex);
}

//
//   FUNCTION: InitInstance(HINSTANCE, int)
//
//   PURPOSE: Saves instance handle and creates main window
//
//   COMMENTS:
//
//        In this function, we save the instance handle in a global variable and
//        create and display the main program window.
//
BOOL InitInstance(HINSTANCE hInstance, int nCmdShow)
{
wchar_t mnuStr[64],exename[260],*p;HANDLE h;WIN32_FIND_DATAW ff;FILE *f;
	hInst = hInstance;
	GetModuleFileNameW(hInstance,exename,260);
	p = wcsrchr(exename,'\\');
	if(p)*p = 0;
	MyFindFirstFileExW=NULL;MyFindNextFile=NULL;
	h = FindFirstFileExW(exename,FindExInfoStandard,&ff,FindExSearchLimitToDirectories,NULL,0);
	if(INVALID_HANDLE_VALUE!=h)
	{	FindClose(h);
		if(FILE_ATTRIBUTE_DIRECTORY & ff.dwFileAttributes)
		{	MyFindFirstFileExW=(FindFirstFileExW_t)FindFirstFileExW;
			MyFindNextFile=(FindNextFile_t)FindNextFile;
	}	}
	if(!MyFindFirstFileExW){MyFindFirstFileExW=MyFindFirstFileExWM;MyFindNextFile=MyFindNextFileM;}
	if(p){*p++='\\';*p=0;}

	//if(GetEnvironmentVariable(L"languge",mnuStr,64))//Language instartup qo'yadur;
	if(MyStringCpyW(mnuStr,64,GetEnvironmentStrings()))
	{	if(wcsstr(mnuStr,L"russian"))
			wcscat(exename,L"PlugDfrgStrsRus.txt");
		else if(wcsstr(mnuStr,L"uzbekl"))
			wcscat(exename,L"PlugDfrgStrsUZBL.txt");
		else if(wcsstr(mnuStr,L"uzbekk"))
			wcscat(exename,L"PlugDfrgStrsUZBK.txt");
		else//if(wcscmp(mnuStr,L"Exit")
			wcscat(exename,L"PlugDfrgStrsEng.txt");
	}	
	else wcscat(exename,L"PlugDfrgStrsEng.txt");

	strngs = (wchar_t **)malloc(MAX_STRINGS*sizeof(wchar_t*));

	f=_wfopen(exename,L"r,ccs=UNICODE");
	if(f)
	{	wchar_t s[260];fwscanf(f,L"%s", s);
		if(wcscmp(s,L"Plugin")) goto NillStr;
		fwscanf(f,L"%s", s);
		if(wcscmp(s,L"filedefrag.dll")) goto NillStr;
		fwscanf(f,L"%s", s);
		if(wcscmp(s,L"Strings:")) goto NillStr;
		for(int i=0; i<MAX_STRINGS; i++)
		{	int t;fwscanf_s(f,L"%d", &t);
			if(t-1!=i) goto NillStr;
			//l=fscanf(f,"%s", s);
			int l=fscanLineString(f,256,s);
			strngs[i]=(wchar_t*)malloc(sizeof(wchar_t)*(l+1));
			memcpy(strngs[i],s,sizeof(wchar_t)*(l+1));
		}
		fclose(f);
	}
	else
	{int l;
NillStr:
		l=wcslen(L"Sino-file defrag plugin,ver.1.0. fr.Erkin Sattorov.Karaulbazar-2013.")+1;
			strngs[0]=(wchar_t*)malloc(2*l);MyStringCpyW(strngs[0],l,L"Sino-file defrag plugin,ver.1.0. fr.Erkin Sattorov.Karaulbazar-2013.");
		l=wcslen(L"Files to defrag:")+1;
			strngs[1]=(wchar_t*)malloc(2*l);MyStringCpyW(strngs[1],l,L"Files to defrag:");
		l=wcslen(L"Defrag")+1;//strngs[2] bo'sh
			strngs[2]=(wchar_t*)malloc(2*l);MyStringCpyW(strngs[2],l,L"Defrag");
		l=wcslen(L"Exit")+1;
			strngs[3]=(wchar_t*)malloc(2*l);MyStringCpyW(strngs[3],l,L"Exit");
		l=wcslen(L"File-defrag")+1;
			strngs[4]=(wchar_t*)malloc(2*l);MyStringCpyW(strngs[4],l,L"File-defrag");
	}


	hWnd = CreateWindow(szWindowClass, szTitle, WS_OVERLAPPEDWINDOW,
						CW_USEDEFAULT, 0, CW_USEDEFAULT, 0, NULL, NULL, hInstance, NULL);
	if(!hWnd)
		return FALSE;

	ShowWindow(hWnd, nCmdShow);
	UpdateWindow(hWnd);

	return TRUE;
}

LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
int wmId, wmEvent;

static HFONT hf=0;
//static int hfRef=0;//obshiy hf, dinamik uchun emas:
static HBRUSH br=0;
//static LPVOID panel;
static HBRUSH brHtBk=0;
static int endDialogCodeToWM_DESTROY;
static int szQntSlct=0;
wchar_t s[MAX_PATH];
//int left,top,width,height,nxtPnlNum=-1;
LPDRAWITEMSTRUCT lpdis;
LOGFONT fnt;
RECT rc;//,rc1;
UINT uStyle;
HDC dc;


/*	static int i=0;
	char ss[32];sprintf(ss,"\n %d ",i++);
	OutputDebugStringA(ss);
	OutputDebugStringA(GetWinNotifyText(message));*/

	switch (message)
	{

	case WM_CREATE:
		/*GetWindowRect(hDlg, &rc1);
		HWND prnt;prnt = GetParent(hDlg);
		if(!prnt)prnt=GetDesktopWindow();
		GetWindowRect(prnt, &rc);
		width = rc1.right - rc1.left;		
		left = rc.left + (rc.right - rc.left - width)/2;//left = (GetSystemMetrics(SM_CXFULLSCREEN) - width)/2;
		height = rc1.bottom - rc1.top;
		top = rc.top + (rc.bottom - rc.top - height)/2;//top = (GetSystemMetrics(SM_CYFULLSCREEN) - height)/2;
		MoveWindow(hDlg, left, top+20, width, height, TRUE);*/

		bckBrsh = CreateSolidBrush(RGB(127,80,80));
		grnBrsh = CreateSolidBrush(RGB(0,255,0));
		blueBrsh = CreateSolidBrush(RGB(0,0,255));
		redBrsh = CreateSolidBrush(RGB(255,0,0));

		//Load language strings:
		CreateChilds(hWnd);
		if(!FillDefragFilesInfo())
		{	MessageBox(hWnd,L"There are not files to defrag.",L"Quiting...",MB_OK);
			PostQuitMessage(0);
			return 0;
		}
		SendMessage(hWnd,WM_USER+1,0,0);
		CreateThread(NULL,0,(LPTHREAD_START_ROUTINE)FileDefrag,NULL,0,&defrThrdId);
		return 0;
	case WM_COMMAND:
		wmId    = LOWORD(wParam);
		wmEvent = HIWORD(wParam);
		// Parse the menu selections:
		switch (wmId)
		{
		case IDB_DEFRAG:
			break;
		case IDB_EXIT:
			DestroyWindow(hWnd);
			break;
		default:
			return DefWindowProc(hWnd, message, wParam, lParam);
		}
		return 0;
	case WM_SIZE:
		Resize(hWnd,wParam,lParam);
		return 0;
	case WM_CTLCOLORSTATIC:
	case WM_CTLCOLORDLG:dc = (HDC)wParam;
		SetTextColor(dc,RGB(0xea,0xe0,0xff));//SetTextColor(dc,RGB(0x8a,0,0));
		SetBkColor(dc,RGB(0x40,0x21,0x17));//SetBkColor(dc,RGB(0xc0,0x81,0x97));
		return (INT_PTR)br;
	case WM_CTLCOLOREDIT:dc = (HDC)wParam;
		SetTextColor(dc,RGB(0xea,0xe0,0xff));//SetTextColor(dc,RGB(0x8a,0,0));
		SetBkColor(dc,RGB(0x40,0x21,0x17));//SetBkColor(dc,RGB(0xc0,0x81,0x97));
		return (INT_PTR)br;
	case WM_CTLCOLORBTN:dc=(HDC)wParam;
		SetTextColor(dc,RGB(0xd0,0xe0,0xff));
		SetBkColor(dc,RGB(0x64,0x79,0x65));
		return (INT_PTR)brHtBk;
	case WM_DRAWITEM://WM_CTLCOLORBTN dagi knopkalar:
		lpdis = (LPDRAWITEMSTRUCT)lParam;
		if(hDrawWnd==lpdis->hwndItem)
		{	Render(lpdis->hDC);
			return TRUE;
		}
		GetWindowText(lpdis->hwndItem,s,MAX_PATH);
		uStyle = DFCS_BUTTONPUSH;
		rc = lpdis->rcItem;
		if(lpdis->itemState & ODS_SELECTED)
		{	uStyle |= DFCS_PUSHED|DFCS_TRANSPARENT;
			rc.left+=2;rc.top+=2;
		}
		DrawFrameControl(lpdis->hDC, &lpdis->rcItem, DFC_BUTTON, uStyle);
		if(lpdis->itemState & ODS_SELECTED)
			{rc.left+=1;rc.top+=1;rc.bottom-=2;rc.right-=3;}
		else
			{rc.left+=1;rc.top+=2;rc.bottom-=3;rc.right-=3;}
		FillRect(lpdis->hDC,&rc,brHtBk);//DrawText(lpdis->hDC,"",50,&rc,DT_SINGLELINE|DT_VCENTER|DT_INTERNAL|DT_LEFT);
		if(lpdis->itemState & ODS_SELECTED)
			{rc.left-=1;rc.top-=1;rc.bottom+=3;rc.right+=3;}
		else
			{rc.left-=1;rc.top-=2;rc.bottom+=2;rc.right+=3;}
		DrawText(lpdis->hDC,s,MyStringLengthW(s,MAX_PATH),&rc,DT_SINGLELINE|DT_VCENTER|DT_CENTER);
		return TRUE;
	case WM_USER+1://hf obshiy uchun, dinamik o'zgartirish uchun emas:
		//if(0==hfRef)
		{	InitLOGFONT(&fnt,0);
			hf = CreateFontIndirect(&fnt);
			br = CreateSolidBrush(RGB(0x40,0x21,0x17));//0xc9,0x81,0x93));
			brHtBk = CreateSolidBrush(RGB(0x64,0x79,0x65));
		}
		SendMessage(GetDlgItem(hWnd,IDB_DEFRAG),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hWnd,IDB_EXIT),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hWnd,IDC_STATIC1),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hWnd,IDC_LIST_FILES),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hWnd,IDC_EDIT_DRAW),WM_SETFONT,(WPARAM)hf,TRUE);			
		//++hfRef;
		return 0;
	case WM_DESTROY:
		DeleteObject(bckBrsh);
		DeleteObject(grnBrsh);
		DeleteObject(blueBrsh);
		DeleteObject(redBrsh);
		DeleteObject(hf);
		DeleteObject(br);
		DeleteObject(brHtBk);		
		PostQuitMessage(0);
		break;
	default:
		return DefWindowProc(hWnd, message, wParam, lParam);
	}
	return DefWindowProc(hWnd, message, wParam, lParam);
}

BOOL IsDirExistW(wchar_t *path)
{
wchar_t s[MAX_PATH];
int r=0;
int l=MyStringCpyW(s,MAX_PATH-1,path);
if('*'==s[l-1])
{	r=1;
	s[l-1]=0;
}
else if('\\'!=s[l-1])
{	s[l++]='\\';
	s[l]=0;
}
HANDLE hDir = CreateFile( s,								  // pointer to the file name
						  FILE_LIST_DIRECTORY,                // access (read/write) mode
						  FILE_SHARE_READ|FILE_SHARE_DELETE,  // share mode
						  NULL,                               // security descriptor
						  OPEN_EXISTING,                      // how to create
						  FILE_FLAG_BACKUP_SEMANTICS,         // file attributes
						  NULL);                              // file with attributes to copy
	if(INVALID_HANDLE_VALUE==hDir) return FALSE;
	CloseHandle(hDir);
	return TRUE;
}

BOOL IsFileExistW(wchar_t *pathAndName)
{
WIN32_FIND_DATA ff;
HANDLE			hf = INVALID_HANDLE_VALUE;
	hf = MyFindFirstFileExW(pathAndName,FindExInfoStandard,&ff,FindExSearchLimitToDirectories,NULL,0);
	if(INVALID_HANDLE_VALUE==hf) return FALSE;
	FindClose(hf);
	return TRUE;
}

wchar_t fileNameForFindFirstEx[MAX_PATH]=L"";
HANDLE WINAPI MyFindFirstFileExWM(__in LPWSTR lpFileName,             // file name
								 __in  FINDEX_INFO_LEVELS fInfoLevelId,// information level
								 __out LPVOID lpFindFileData,          // information buffer
								 __in  FINDEX_SEARCH_OPS fSearchOp,    // filtering type
								 __reserved LPVOID lpSearchFilter,     // search criteria
								 __in DWORD dwAdditionalFlags)			// additional search control
{
HANDLE r=FindFirstFileExW(lpFileName,fInfoLevelId,lpFindFileData,fSearchOp,lpSearchFilter,dwAdditionalFlags);
HANDLE hDir = CreateFileW(lpFileName,FILE_LIST_DIRECTORY,FILE_SHARE_READ|FILE_SHARE_DELETE,NULL,
						 OPEN_EXISTING,FILE_FLAG_BACKUP_SEMANTICS,NULL);
	if(INVALID_HANDLE_VALUE!=hDir)
	{	CloseHandle(hDir);
		((WIN32_FIND_DATA*)lpFindFileData)->dwFileAttributes |= FILE_ATTRIBUTE_DIRECTORY;
	}
	if(INVALID_HANDLE_VALUE!=r)
		MyStringCpyW(fileNameForFindFirstEx,MAX_PATH,(wchar_t*)lpFileName);
	else fileNameForFindFirstEx[0]=0;
	return r;

}

BOOL WINAPI MyFindNextFileM(__in HANDLE hFindFile,__out LPWIN32_FIND_DATA lpFindFileData)
{
BOOL r=FindNextFile(hFindFile,lpFindFileData);
HANDLE hDir = CreateFile(fileNameForFindFirstEx,FILE_LIST_DIRECTORY,FILE_SHARE_READ|FILE_SHARE_DELETE,NULL,
						 OPEN_EXISTING,FILE_FLAG_BACKUP_SEMANTICS,NULL);
	if(INVALID_HANDLE_VALUE!=hDir)
	{	CloseHandle(hDir);
		((WIN32_FIND_DATA*)lpFindFileData)->dwFileAttributes |= FILE_ATTRIBUTE_DIRECTORY;
	}
	return r;
}

BOOL IsCrntOrPrntDirAttrb(wchar_t* fd)
{//see Naming Conventions in MSDN:
	if('.'==fd[0])
	{	if('\0'==fd[1])//"."
			return FALSE;
		if('.'==fd[1])
			if('\0'==fd[2])//".."
				return FALSE;
	}
	return TRUE;//Hozircha;
}

VOID FillDirDefragFilesInfo(wchar_t *path)
{
HANDLE hf;WIN32_FIND_DATAW ff;wchar_t *p,s[MAX_PATH];
	int l = MyStringCpyW(s,MAX_PATH-1,path);
	if('\\' != s[l-2] && '*' != s[l-1])
	{	if('\\'==s[l-1])
		{	s[l]='*';
			s[l+1]=0;
		}
		else
		{	s[l]='\\';
			s[l+1]='*';
			s[l+2]=0;
	}	}
	else if('\\'==s[l-1])
	{	s[l]='*';
		s[l+1]=0;
	}
	
	hf = MyFindFirstFileExW(s,FindExInfoStandard,&ff,FindExSearchLimitToDirectories,NULL,0);
	p=wcsrchr(s,'\\');
	if(p) *(++p)=0;
	do
	{	if(INVALID_HANDLE_VALUE==hf) break;
		if(!IsCrntOrPrntDirAttrb(ff.cFileName)) continue;
		if(FILE_ATTRIBUTE_DIRECTORY & ff.dwFileAttributes)
		{	l=MyStringCpyW(p,MAX_PATH-1,ff.cFileName);
			*(p+l) = '\\';
			*(p+l+1) = '*';
			*(p+l+2) = 0;
			FillDirDefragFilesInfo(s);
		}
		else
		{	MyStringCpyW(p,MAX_PATH-1,ff.cFileName);
			SendMessageW(hLB,LB_ADDSTRING,0,(LPARAM)s);
	}	}	
	while(MyFindNextFile(hf, &ff));
	FindClose(hf);
}

BOOL FillDefragFilesInfo()
{
int i;

LPWSTR *lp = CommandLineToArgvW(GetCommandLineW(),&totFiles);
	if(totFiles<2) return FALSE;
	--totFiles;

	int filsListBufLen=0;
	for(int i=0; i<totFiles; i++)//;*p;)
	{	int l = MyStringLengthW(lp[i+1],MAX_PATH);
		filsListBufLen += l+1;
	}

	if(!totFiles)return FALSE;

	filesList = (wchar_t*)malloc(sizeof(wchar_t)*filsListBufLen);
	wchar_t *pout = filesList,*pOld = pout;
	int islp=0;
	for(int i=0; i<totFiles; i++)//;*p;)
	{	int l = MyStringCpyW(pout,MAX_PATH,lp[i+1]);
		pout += l;
		*pout++ = 0;
		if((!IsFileExistW(pOld)) && (!IsDirExistW(pOld)))
		{	++islp;
			*(pout-1)=' ';
		}
		else pOld = pout;
	}
	totFiles -= islp;

	wchar_t *p = filesList;

	for(i=0; i<totFiles; i++)
	{	if(IsDirExistW(p))
			FillDirDefragFilesInfo(p);//DlgDirList(hWnd,p
		else
			SendMessageW(hLB,LB_ADDSTRING,0,(LPARAM)p);
		p += 1+MyStringLengthW(p,MAX_PATH);
	}
	free(filesList);
	filesList = 0;
	return TRUE;
}

int MyStringCpyW(wchar_t* buf, int mx, wchar_t* src)
{	register int l=-1;
	while(++l<mx)
	{	buf[l] = src[l];
		if(!src[l]) break;//('\0'==src[l])
	}
	if(buf[l])//0 bo'lmasa;
	if(l>=mx)
		buf[l] = 0;
	return l;
}

int MyStringLengthW(wchar_t* buf, int mx)
{	int l=-1;
	if(!buf[0])return 0;
	while(++l<mx)
	{	if(!buf[l])//(0==buf[l])
			return l;
		if(l>=mx)
			return l;
	};
	return l;
}

VOID InitLOGFONT(LOGFONT* lf,int t)
{
	switch(t)
	{case 0://panel
		lf->lfCharSet=204;//Kirill
		lf->lfClipPrecision=2;
		lf->lfEscapement=0;
		StringCchPrintf(lf->lfFaceName,LF_FACESIZE,L"Arial");//"Tahoma");//Arial Narrow");
		lf->lfHeight=-14;//12;
		lf->lfItalic=0;
		lf->lfOrientation=0;
		lf->lfOutPrecision=3;
		lf->lfPitchAndFamily=34;
		lf->lfQuality=1;
		lf->lfStrikeOut=0;
		lf->lfUnderline=0;
		lf->lfWeight=400;//400;
		lf->lfWidth=0;
		break;
}	}

LRESULT CALLBACK DrawWndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
PAINTSTRUCT ps;

	switch (message)
	{
	case WM_VSCROLL:
		if(SetScrollInf(wParam,lParam))
			Render(0);
		return 0;
	case WM_PAINT:
		BeginPaint(hWnd,&ps);
			Render(ps.hdc);
		EndPaint(hWnd,&ps);
		return 0;
	default:
		break;
	}
	return DefWindowProc(hWnd, message, wParam, lParam);
}

BOOL CreateChilds(HWND hWnd)
{
	SetWindowTextW(hWnd,strngs[0]);
	hStat=CreateWindowW(L"STATIC",strngs[1],
				WS_CHILD | WS_VISIBLE,
                0,
				0,
				250,
				22,
                hWnd,
                (HMENU)IDC_STATIC1,
                hInst,
                NULL);
	hLB = CreateWindowW(L"LISTBOX",NULL,
				WS_CHILD | WS_VISIBLE | WS_BORDER | LBS_EXTENDEDSEL | WS_VSCROLL | WS_HSCROLL |
				LBS_MULTIPLESEL | LBS_NOTIFY | LBS_WANTKEYBOARDINPUT,
                0,
				24,
				250,
				630,
                hWnd,
                NULL,
                hInst,
                NULL);
	SendMessage(hLB, LB_SETHORIZONTALEXTENT, 1200, 0);
	hBtnDfrg = CreateWindowW(L"BUTTON",strngs[2],
				WS_CHILD | WS_VISIBLE | WS_BORDER | LBS_EXTENDEDSEL,
                2,
				652,
				122,
				25,
                hWnd,
                (HMENU)IDB_DEFRAG,
                hInst,
                NULL);
	hBtnExit = CreateWindowW(L"BUTTON",strngs[3],
				WS_CHILD | WS_VISIBLE | WS_BORDER | LBS_EXTENDEDSEL,
                125,
				652,
				122,
				25,
                hWnd,
                (HMENU)IDB_EXIT,
                hInst,
                NULL);


	WNDCLASSEX wcex;
	wcex.cbSize = sizeof(WNDCLASSEX);
	wcex.style			= CS_HREDRAW | CS_VREDRAW;
	wcex.lpfnWndProc	= DrawWndProc;
	wcex.cbClsExtra		= 0;
	wcex.cbWndExtra		= 0;
	wcex.hInstance		= hInst;
	wcex.hIcon			= NULL;
	wcex.hCursor		= NULL;//LoadCursor(NULL, IDC_ARROW);
	wcex.hbrBackground	= bckBrsh;
	wcex.lpszMenuName	= NULL;
	wcex.lpszClassName	= L"DefrWindClass";
	wcex.hIconSm		= NULL;
	/*ATOM rcl = */RegisterClassEx(&wcex);

	RECT r;GetClientRect(hWnd,&r);
	hDrawWnd = CreateWindowW(L"DefrWindClass",L"",
				WS_CHILDWINDOW | WS_VISIBLE | WS_VSCROLL,// | BS_OWNERDRAW,// | WS_HSCROLL,
                252,
				0,
				r.right-252,
				r.bottom,
                hWnd,
                0,
                hInst,
                NULL);
	return TRUE;
}