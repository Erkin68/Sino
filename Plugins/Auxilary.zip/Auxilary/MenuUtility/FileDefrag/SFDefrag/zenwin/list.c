/*
* ZenWINX - WIndows Native eXtended library.
* Copyright (c) 2007-2013 Dmitri Arkhangelski (dmitriar@gmail.com).
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 2 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include "ntfs.h"
#include "zenwinx.h"

list_entry *winx_list_insert(list_entry **phead,list_entry *prev,long size)
{
 list_entry *new_item;

 /*
 * Avoid winx_dbg_xxx calls here
 * to avoid recursion.
 */

 if(size < sizeof(list_entry))
 return NULL;

 new_item = (list_entry *)winx_malloc(size);

 /* is list empty? */
 if(*phead == NULL){
 *phead = new_item;
 new_item->prev = new_item->next = new_item;
 return new_item;
 }

 /* insert as the new head? */
 if(prev == NULL){
 prev = (*phead)->prev;
 *phead = new_item;
 }

 /* insert after the item specified by prev argument */
 new_item->prev = prev;
 new_item->next = prev->next;
 new_item->prev->next = new_item;
 new_item->next->prev = new_item;
 return new_item;
}

void winx_list_remove(list_entry **phead,list_entry *item)
{
/*
* Avoid winx_dbg_xxx calls here
* to avoid recursion.
*/

/* validate the item */
if(item == NULL) return;

/* is list empty? */
if(*phead == NULL) return;

/* remove alone first item? */
if(item == *phead && item->next == *phead){
winx_free(item);
*phead = NULL;
return;
}

 /* remove first item? */
 if(item == *phead){
 *phead = (*phead)->next;
 }
 item->prev->next = item->next;
 item->next->prev = item->prev;
 winx_free(item);
}

void winx_list_destroy(list_entry **phead)
{
 list_entry *item, *next, *head;

 /* is list empty? */
 if(*phead == NULL) return;

 head = *phead;
 item = head;

 do {
 next = item->next;
 winx_free(item);
 item = next;
 } while (next != head);

 *phead = NULL;
}

//******************** maniki ********************
//******************** maniki ********************
//******************** maniki ********************
//******************** maniki ********************
//******************** maniki ********************
void winx_list_destroy_maniki(list_entry **phead,ULONG nEntry)
{
 ULONG i=0;
 list_entry *item, *next, *head;

 /* is list empty? */
 if(*phead == NULL) return;

 head = *phead;
 item = head;

 do {
 next = item->next;
 winx_free(item);
 item = next;
 if(i++==nEntry)
	 break;
 } while (next != head);

 *phead = NULL;
}