#include "ntfs.h"
#include "zenwinx.h"


/*int exclude_by_fragment_size(winx_file_info *f,udefrag_job_parameters *jp)
{
winx_blockmap *block;
ULONGLONG fragment_size = 0;
 
	if(jp->udo.fragment_size_threshold == DEFAULT_FRAGMENT_SIZE_THRESHOLD)
		return 0;
	// don't filter out files if threshold is set by algorithm
	if(jp->udo.algorithm_defined_fst)
		return 0;
 
	if(f->disp.blockmap == NULL)
		return 0;
 
	for(block = f->disp.blockmap; block; block = block->next)
	{	if(block == f->disp.blockmap)
			fragment_size += block->length;
		else if(block->lcn == block->prev->lcn + block->prev->length)
			fragment_size += block->length;
		else
		{	if(fragment_size)
			{	if(fragment_size * jp->v_info.bytes_per_cluster < jp->udo.fragment_size_threshold)
					return 0; // file contains little fragments
			}
			fragment_size = block->length;
		}
		if(block->next == f->disp.blockmap)
			break;
	}
 
	if(fragment_size)
	{	if(fragment_size * jp->v_info.bytes_per_cluster < jp->udo.fragment_size_threshold)
			return 0; // file contains little fragments
	}
 	return 1;
}

int exclude_by_fragments(winx_file_info *f,udefrag_job_parameters *jp)
{
  if(jp->udo.fragments_limit == 0)
	  return 0;
  return (f->disp.fragments < jp->udo.fragments_limit) ? 1 : 0;
}

int exclude_by_size(winx_file_info *f,udefrag_job_parameters *jp)
{
  ULONGLONG filesize;
 
  f->user_defined_flags &= ~UD_FILE_OVER_LIMIT;
  filesize = f->disp.clusters * jp->v_info.bytes_per_cluster;
  if(filesize > jp->udo.size_limit)
  {  f->user_defined_flags |= UD_FILE_OVER_LIMIT;
	return 1;
  }
  return 0;
}

struct fs
{ char *name; // name in uppercase
  file_system_type type;
  //
  // On fat the first clusters
  // of directories cannot be moved.
  //
  int is_fat;
};
 
struct fs fs_types[] = {
  {"NTFS", FS_NTFS, 0},
  {"FAT12", FS_FAT12, 1},
  {"FAT", FS_FAT16, 1}, // no need to distinguish better
  {"FAT16", FS_FAT16, 1},
  {"FAT32", FS_FAT32, 1},
  {"EXFAT", FS_EXFAT, 1},
  {"UDF", FS_UDF, 0},
  {NULL, 0, 0}
 };
 
 #define _256K (256LL * 1024LL)
 #define _4M (4LL * 1024LL * 1024LL)
 #define _8M (8LL * 1024LL * 1024LL)
 #define _16M (16LL * 1024LL * 1024LL)
 #define _32M (32LL * 1024LL * 1024LL)
 #define _64M (64LL * 1024LL * 1024LL)
 #define _20G (20LL * 1024LL * 1024LL * 1024LL)
 #define _100G (100LL * 1024LL * 1024LL * 1024LL)
 #define _250G (250LL * 1024LL * 1024LL * 1024LL)
 #define _1T (1024LL * 1024LL * 1024LL * 1024LL)
 #define _2T (2LL * 1024LL * 1024LL * 1024LL * 1024LL)
 
 void adjust_move_at_once_parameter(udefrag_job_parameters *jp)
 {
  ULONGLONG bytes_at_once;
  char buffer[32];
 
  // comply with "one half second to stop defragmentation" rule
  if(jp->v_info.device_capacity < _20G)
    bytes_at_once = _256K;
  else if(jp->v_info.device_capacity < _100G)
    bytes_at_once = _4M;
  else if(jp->v_info.device_capacity < _250G)
    bytes_at_once = _8M;
  else if(jp->v_info.device_capacity < _1T)
	bytes_at_once = _16M;
  else if(jp->v_info.device_capacity < _2T)
    bytes_at_once = _32M;
  else
    bytes_at_once = _64M;
  // nt4 (and maybe w2k) is able to move no more than 256 KB at once
  if(jp->win_version < WINDOWS_XP) bytes_at_once = _256K;
  jp->clusters_at_once = bytes_at_once / jp->v_info.bytes_per_cluster;
  if(jp->clusters_at_once == 0)
  jp->clusters_at_once ++;
  winx_bytes_to_hr(bytes_at_once,0,buffer,sizeof(buffer));
  itrace("the program will move %s (%I64u clusters) at once",
  buffer, jp->clusters_at_once);
}

void update_progress_counters(winx_file_info *f,udefrag_job_parameters *jp)
{
ULONGLONG filesize;
 
  jp->pi.files ++;
  if(is_directory(f))
	  jp->pi.directories ++;
  if(is_compressed(f))
	  jp->pi.compressed ++;
  jp->pi.processed_clusters += f->disp.clusters;
 
  filesize = f->disp.clusters * jp->v_info.bytes_per_cluster;
  if(filesize >= GIANT_FILE_SIZE)
	jp->f_counters.giant_files ++;
  else if(filesize >= HUGE_FILE_SIZE)
	jp->f_counters.huge_files ++;
  else if(filesize >= BIG_FILE_SIZE)
	jp->f_counters.big_files ++;
  else if(filesize >= AVERAGE_FILE_SIZE)
	jp->f_counters.average_files ++;
  else if(filesize >= SMALL_FILE_SIZE)
	jp->f_counters.small_files ++;
  else
	jp->f_counters.tiny_files ++;
}

int exclude_by_path(winx_file_info *f,udefrag_job_parameters *jp)
{
  // note that paths have \??\ internal prefix while patterns haven't
  if(wcslen(f->path) < 0x4)
	return 1; // path is invalid
 
  if(jp->udo.ex_filter.count)
  {	if(winx_patcmp(f->path + 0x4,&jp->udo.ex_filter))
		return 1;
  }
 
  if(jp->udo.cut_filter.count)
  {	if(!winx_patcmp(f->path + 0x4,&jp->udo.cut_filter))
	return 1;
  }
 
  if(jp->udo.in_filter.count == 0)
	  return 0;
  return !winx_patcmp(f->path + 0x4,&jp->udo.in_filter);
}