/*
* ZenWINX - WIndows Native eXtended library.
* Copyright (c) 2007-2013 Dmitri Arkhangelski (dmitriar@gmail.com).
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 2 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include "ntfs.h"
#include "zenwinx.h"
#include "dbg.h"

int winx_create_thread(PTHREAD_START_ROUTINE start_addr,PVOID parameter)
{
 NTSTATUS status;
 HANDLE hThread;

 DbgCheck1(start_addr,-1);

 status = RtlCreateUserThread(NtCurrentProcess(),NULL,
 0,0,0,0,start_addr,parameter,&hThread,NULL);
 if(!NT_SUCCESS(status)){
 strace(status,"cannot create thread");
 return (-1);
 }
 NtCloseSafe(hThread);
 return 0;
}

void winx_exit_thread(NTSTATUS status)
{
 NTSTATUS s = ZwTerminateThread(NtCurrentThread(),status);
 if(!NT_SUCCESS(s)){
 strace(s,"cannot terminate thread");
 }
}

