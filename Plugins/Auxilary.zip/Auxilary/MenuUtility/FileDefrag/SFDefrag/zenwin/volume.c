/*
* ZenWINX - WIndows Native eXtended library.
* Copyright (c) 2007-2013 Dmitri Arkhangelski (dmitriar@gmail.com).
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 2 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include "ntfs.h"
#include "ntndk.h"
#include "zenwinx.h"
#include "dbg.h"
#include "..\SFDefrag.h"

#pragma warning(disable:4996)

extern HWND hStat;
extern wchar_t **strngs;
extern wchar_t hStatText[2*MAX_PATH];

WINX_FILE *winx_vopen(char);
winx_volume_region *FindOptmlAboveSpaceForFile(winx_file_info*,winx_volume_region*);
BOOL MoveFileToOptmlAboveSpace(WINX_FILE*,winx_file_info*,winx_volume_region*);
int scan_mft(mft_scan_parameters*);

static HANDLE OpenRootDirectory(unsigned char volume_letter)
{
 wchar_t rootpath[] = L"\\??\\A:\\";
 HANDLE hRoot;
 NTSTATUS status;
 UNICODE_STRING us;
 OBJECT_ATTRIBUTES ObjectAttributes;
 IO_STATUS_BLOCK IoStatusBlock;

 rootpath[4] = (wchar_t)winx_toupper(volume_letter);
 RtlInitUnicodeString(&us,rootpath);
 InitializeObjectAttributes(&ObjectAttributes,&us,
 FILE_READ_ATTRIBUTES,NULL,NULL);
 status = NtCreateFile(&hRoot,FILE_GENERIC_READ,
 &ObjectAttributes,&IoStatusBlock,NULL,0,
 FILE_SHARE_READ|FILE_SHARE_WRITE,FILE_OPEN,0,
 NULL,0);
 if(!NT_SUCCESS(status)){
 strace(status,"cannot open %ls",rootpath);
 return NULL;
 }
 return hRoot;
}

int winx_get_drive_type(char letter)
{
 wchar_t link_name[] = L"\\??\\A:";
 #define MAX_TARGET_LENGTH 256
 wchar_t link_target[MAX_TARGET_LENGTH];
 PROCESS_DEVICEMAP_INFORMATION pdi;
 FILE_FS_DEVICE_INFORMATION ffdi;
 IO_STATUS_BLOCK iosb;
 NTSTATUS status;
 int drive_type;
 HANDLE hRoot;

 /* The additional checks for DFS were suggested by Stefan Pendl (pendl2megabit@yahoo.de). */
 /* DFS shares have DRIVE_NO_ROOT_DIR type though they are actually remote. */

 letter = winx_toupper(letter); /* possibly required for w2k */
 if(letter < 'A' || letter > 'Z'){
 etrace("invalid letter %c",letter);
 return (-1);
 }

 /* check for the drive existence */
 link_name[4] = (wchar_t)letter;
 if(winx_query_symbolic_link(link_name,link_target,MAX_TARGET_LENGTH) < 0)
 return (-1);

 /* check for an assignment made by subst command */
 if(wcsstr(link_target,L"\\??\\") == (wchar_t *)link_target)
 return DRIVE_ASSIGNED_BY_SUBST_COMMAND;

 /* check for classical floppies */
 if(wcsstr(link_target,L"Floppy"))
 return DRIVE_REMOVABLE;

 /* try to define exactly which type has the specified drive (w2k+) */
 RtlZeroMemory(&pdi,sizeof(PROCESS_DEVICEMAP_INFORMATION));
  status = NtQueryInformationProcess(NtCurrentProcess(),
  ProcessDeviceMap,&pdi,
  sizeof(PROCESS_DEVICEMAP_INFORMATION),
  NULL);
  if(NT_SUCCESS(status)){
  drive_type = (int)pdi.Query.DriveType[letter - 'A'];
  /*
  * Type DRIVE_NO_ROOT_DIR have the following drives:
  * 1. assigned by subst command
  * 2. SCSI external drives
  * 3. RAID volumes
  * 4. DFS shares
  * We need additional checks to know exactly.
  */
  if(drive_type != DRIVE_NO_ROOT_DIR)
  return drive_type;
  } else {
  if(status != STATUS_INVALID_INFO_CLASS){ /* exclude common NT4 error code */
  /* exclude common NT4 Terminal Server Edition error code */
  if(status != STATUS_INFO_LENGTH_MISMATCH){
  strace(status,"cannot get device map");
  return (-1);
  }
  }
  }
 
  /* try to define exactly again which type has the specified drive (nt4+) */
  /* note that the drive motor can be powered on during this check */
  hRoot = OpenRootDirectory(letter);
  if(hRoot == NULL)
  return (-1);
  RtlZeroMemory(&ffdi,sizeof(FILE_FS_DEVICE_INFORMATION));
  status = NtQueryVolumeInformationFile(hRoot,&iosb,
  &ffdi,sizeof(FILE_FS_DEVICE_INFORMATION),
  FileFsDeviceInformation);
  NtClose(hRoot);
  if(!NT_SUCCESS(status)){
  strace(status,"cannot get volume type for \'%c\'",letter);
  return (-1);
  }
 
  /* detect remote/cd/dvd/unknown drives */
  if(ffdi.Characteristics & FILE_REMOTE_DEVICE)
  return DRIVE_REMOTE;
  switch(ffdi.DeviceType){
  case FILE_DEVICE_CD_ROM:
  case FILE_DEVICE_CD_ROM_FILE_SYSTEM:
  case FILE_DEVICE_DVD:
  return DRIVE_CDROM;
  case FILE_DEVICE_NETWORK_FILE_SYSTEM:
  case FILE_DEVICE_NETWORK: /* ? */
  case FILE_DEVICE_NETWORK_BROWSER: /* ? */
  case FILE_DEVICE_DFS_FILE_SYSTEM:
  case FILE_DEVICE_DFS_VOLUME:
  case FILE_DEVICE_DFS:
  return DRIVE_REMOTE;
  case FILE_DEVICE_UNKNOWN:
  return DRIVE_UNKNOWN;
  }
 
  /* detect removable disks */
  if(ffdi.Characteristics & FILE_REMOVABLE_MEDIA)
  return DRIVE_REMOVABLE;
 
  /* detect fixed disks */
  switch(ffdi.DeviceType){
  case FILE_DEVICE_DISK:
  case FILE_DEVICE_FILE_SYSTEM: /* ? */
  /*case FILE_DEVICE_VIRTUAL_DISK:*/
  /*case FILE_DEVICE_MASS_STORAGE:*/
  case FILE_DEVICE_DISK_FILE_SYSTEM:
  return DRIVE_FIXED;
  default:
  break;
  }
 
  /* nothing detected => drive type is unknown */
  return DRIVE_UNKNOWN;
 }
 
 static int get_drive_geometry(HANDLE hRoot,winx_volume_information *v)
 {
  FILE_FS_SIZE_INFORMATION ffs;
  IO_STATUS_BLOCK IoStatusBlock;
  NTSTATUS status;
  WINX_FILE *f;
  DISK_GEOMETRY dg;
  char buffer[32];
 
  /* get drive geometry */
  RtlZeroMemory(&ffs,sizeof(FILE_FS_SIZE_INFORMATION));
  status = NtQueryVolumeInformationFile(hRoot,&IoStatusBlock,&ffs,
  sizeof(FILE_FS_SIZE_INFORMATION),FileFsSizeInformation);
  if(!NT_SUCCESS(status)){
  strace(status,"cannot get geometry of drive %c:",v->volume_letter);
  return (-1);
  }
 
  /* fill all geometry related fields of the output structure */
  v->total_bytes = (ULONGLONG)ffs.TotalAllocationUnits.QuadPart * \
  ffs.SectorsPerAllocationUnit * ffs.BytesPerSector;
  v->free_bytes = (ULONGLONG)ffs.AvailableAllocationUnits.QuadPart * \
  ffs.SectorsPerAllocationUnit * ffs.BytesPerSector;
  v->total_clusters = (ULONGLONG)ffs.TotalAllocationUnits.QuadPart;
  v->bytes_per_cluster = ffs.SectorsPerAllocationUnit * ffs.BytesPerSector;
  v->sectors_per_cluster = ffs.SectorsPerAllocationUnit;
  v->bytes_per_sector = ffs.BytesPerSector;
 
  /* optional: get device capacity */
  v->device_capacity = 0;
  f = winx_vopen(v->volume_letter);
  if(f != NULL){
  if(winx_ioctl(f,IOCTL_DISK_GET_DRIVE_GEOMETRY,
  "get_drive_geometry: device geometry request",NULL,0,
  &dg,sizeof(dg),NULL) >= 0){
  v->device_capacity = dg.Cylinders.QuadPart * \
  dg.TracksPerCylinder * dg.SectorsPerTrack * dg.BytesPerSector;
  winx_bytes_to_hr(v->device_capacity,1,buffer,sizeof(buffer));
  itrace("%c: device capacity = %s",v->volume_letter,buffer);
  }
  winx_fclose(f);
  }
  return 0;
 }
 
 static int get_filesystem_name(HANDLE hRoot,winx_volume_information *v)
 {
  FILE_FS_ATTRIBUTE_INFORMATION *pfa;
  int fs_attr_info_size;
  IO_STATUS_BLOCK IoStatusBlock;
  NTSTATUS status;
  wchar_t fs_name[MAX_FS_NAME_LENGTH + 1];
  int length;
 
  fs_attr_info_size = MAX_PATH * sizeof(WCHAR) + sizeof(FILE_FS_ATTRIBUTE_INFORMATION);
  pfa = winx_malloc(fs_attr_info_size);
 
  RtlZeroMemory(pfa,fs_attr_info_size);
  status = NtQueryVolumeInformationFile(hRoot,&IoStatusBlock,pfa,
  fs_attr_info_size,FileFsAttributeInformation);
  if(!NT_SUCCESS(status)){
  strace(status,"cannot get file system name of drive %c:",v->volume_letter);
  winx_free(pfa);
  return (-1);
  }
 
  /*
  * pfa->FileSystemName.Buffer may be not NULL terminated
  * (theoretically), so name extraction is more tricky
  * than it should be.
  */
  length = min(MAX_FS_NAME_LENGTH,pfa->FileSystemNameLength / sizeof(wchar_t));
  wcsncpy(fs_name,pfa->FileSystemName,length);
  fs_name[length] = 0;
  _snprintf(v->fs_name,MAX_FS_NAME_LENGTH,"%ws",fs_name);
  v->fs_name[MAX_FS_NAME_LENGTH] = 0;
 
  /* cleanup */
  winx_free(pfa);
  return 0;
 }
 
 static int get_ntfs_data(winx_volume_information *v)
 {
  WINX_FILE *f;
  int result;
 
  /* open the volume */
  f = winx_vopen(v->volume_letter);
  if(f == NULL)
  return (-1);
 
  /* get ntfs data */
  result = winx_ioctl(f,FSCTL_GET_NTFS_VOLUME_DATA,
  "get_ntfs_data: ntfs data request",NULL,0,
  &v->ntfs_data,sizeof(NTFS_DATA),NULL);
  winx_fclose(f);
  return result;
 }
 
 static void get_volume_label(HANDLE hRoot,winx_volume_information *v)
 {
  FILE_FS_VOLUME_INFORMATION *ffvi;
  int buffer_size;
  IO_STATUS_BLOCK IoStatusBlock;
  NTSTATUS status;
 
  /* reset label */
  v->label[0] = 0;
 
  /* allocate memory */
  buffer_size = (sizeof(FILE_FS_VOLUME_INFORMATION) - sizeof(wchar_t)) + (MAX_PATH + 1) * sizeof(wchar_t);
  ffvi = winx_malloc(buffer_size);
 
  /* try to get actual label */
  RtlZeroMemory(ffvi,buffer_size);
  status = NtQueryVolumeInformationFile(hRoot,&IoStatusBlock,ffvi,
  buffer_size,FileFsVolumeInformation);
  if(!NT_SUCCESS(status)){
  strace(status,"cannot get volume label of drive %c:",
  v->volume_letter);
  winx_free(ffvi);
  return;
  }
  wcsncpy(v->label,ffvi->VolumeLabel,MAX_PATH);
  v->label[MAX_PATH] = 0;
  winx_free(ffvi);
 }
 
 static void get_volume_dirty_flag(winx_volume_information *v)
 {
  WINX_FILE *f;
  ULONG dirty_flag;
  int result;
 
  /* open the volume */
  f = winx_vopen(v->volume_letter);
  if(f == NULL) return;
 
  /* get dirty flag */
  result = winx_ioctl(f,FSCTL_IS_VOLUME_DIRTY,
  "get_volume_dirty_flag: dirty flag request",
  NULL,0,&dirty_flag,sizeof(ULONG),NULL);
  winx_fclose(f);
  if(result >= 0 && (dirty_flag & VOLUME_IS_DIRTY)){
  etrace("%c: volume is dirty! Run CHKDSK to repair it.",
  v->volume_letter);
  v->is_dirty = 1;
  }
 }
 
 int winx_get_volume_information(char volume_letter,winx_volume_information *v)
 {
  HANDLE hRoot;
 
  /* check input data correctness */
  if(v == NULL)
  return (-1);
 
  /* ensure that it will work on w2k */
  volume_letter = winx_toupper(volume_letter);
 
  /* reset all fields of the structure, except of volume_letter */
  memset(v,0,sizeof(winx_volume_information));
  v->volume_letter = volume_letter;
 
  if(volume_letter < 'A' || volume_letter > 'Z')
  return (-1);
 
  /* open root directory */
  hRoot = OpenRootDirectory(volume_letter);
  if(hRoot == NULL)
  return (-1);
 
  /* get drive geometry */
  if(get_drive_geometry(hRoot,v) < 0){
  NtClose(hRoot);
  return (-1);
  }
 
  /* get the name of contained file system */
  if(get_filesystem_name(hRoot,v) < 0){
  NtClose(hRoot);
  return (-1);
  }
 
  /* get name of the volume */
  get_volume_label(hRoot,v);
 
  /* get NTFS data */
  memset(&v->ntfs_data,0,sizeof(NTFS_DATA));
  if(!strcmp(v->fs_name,"NTFS")){
  if(get_ntfs_data(v) < 0){
  etrace("NTFS data is unavailable for %c:",
  volume_letter);
  }
  }
 
  /* get dirty flag */
  get_volume_dirty_flag(v);
 
  NtClose(hRoot);
  return 0;
 }
 
WINX_FILE *winx_vopen(char volume_letter)
{
  wchar_t path[] = L"\\??\\A:";
 
  path[4] = winx_toupper(volume_letter);
  return winx_fopen(path,"r");
}
 
int winx_vflush(char volume_letter)
{
  wchar_t path[] = L"\\??\\A:";
  WINX_FILE *f;
  int result = -1;
 
  path[4] = winx_toupper(volume_letter);
  f = winx_fopen(path,"r+");
  if(f){
  result = winx_fflush(f);
  winx_fclose(f);
  }
 
  return result;
}
 
winx_volume_region *winx_get_free_volume_regions(char volume_letter,int flags, 
												 volume_region_callback cb, void *user_defined_data)
{
  winx_volume_region *rlist = NULL, *rgn = NULL;
  BITMAP_DESCRIPTOR *bitmap;
  #define LLINVALID ((ULONGLONG) -1)
  #define BITMAPBYTES 4096
  #define BITMAPSIZE (BITMAPBYTES + 2 * sizeof(ULONGLONG))
  /* bit shifting array for efficient processing of the bitmap */
  unsigned char bitshift[] = { 1, 2, 4, 8, 16, 32, 64, 128 };
  WINX_FILE *f;
  ULONGLONG i, start, next, free_rgn_start;
  IO_STATUS_BLOCK iosb;
  NTSTATUS status;
 
  /* ensure that it will work on w2k */
  volume_letter = winx_toupper(volume_letter);
 
  /* allocate memory */
  bitmap = winx_malloc(BITMAPSIZE);
 
  /* open volume */
  f = winx_vopen(volume_letter);
  if(f == NULL){
  winx_free(bitmap);
  return NULL;
  }
 
  /* get volume bitmap */
  next = 0, free_rgn_start = LLINVALID;
  do {
  /* get next portion of the bitmap */
  memset(bitmap,0,BITMAPSIZE);
  status = NtFsControlFile(winx_fileno(f),NULL,NULL,0,&iosb,
  FSCTL_GET_VOLUME_BITMAP,&next,sizeof(ULONGLONG),
  bitmap,BITMAPSIZE);
  if(NT_SUCCESS(status)){
  NtWaitForSingleObject(winx_fileno(f),FALSE,NULL);
  status = iosb.Status;
  }
  if(status != STATUS_SUCCESS && status != STATUS_BUFFER_OVERFLOW){
  strace(status,"cannot get volume bitmap");
  winx_fclose(f);
  winx_free(bitmap);
  if(flags & WINX_GVR_ALLOW_PARTIAL_SCAN){
  return rlist;
  } else {
  winx_list_destroy((list_entry **)(void *)&rlist);
  return NULL;
  }
  }
 
  /* scan through the returned bitmap info */
  start = bitmap->StartLcn;
  for(i = 0; i < min(bitmap->ClustersToEndOfVol, 8 * BITMAPBYTES); i++){
  if(!(bitmap->Map[ i/8 ] & bitshift[ i % 8 ])){
  /* cluster is free */
  if(free_rgn_start == LLINVALID)
  free_rgn_start = start + i;
  } else {
  /* cluster isn't free */
  if(free_rgn_start != LLINVALID){
  /* add free region to the list */
  rgn = (winx_volume_region *)winx_list_insert((list_entry **)(void *)&rlist,
  (list_entry *)rgn,sizeof(winx_volume_region));
  rgn->lcn = free_rgn_start;
  rgn->length = start + i - free_rgn_start;
  if(cb != NULL){
  if(cb(rgn,user_defined_data))
  goto done;
  }
  free_rgn_start = LLINVALID;
  }
  }
  }
 
  /* go to the next portion of data */
  next = bitmap->StartLcn + i;
  } while(status != STATUS_SUCCESS);
 
  if(free_rgn_start != LLINVALID){
  /* add free region to the list */
  rgn = (winx_volume_region *)winx_list_insert((list_entry **)(void *)&rlist,
  (list_entry *)rgn,sizeof(winx_volume_region));
  rgn->lcn = free_rgn_start;
  rgn->length = start + i - free_rgn_start;
  if(cb != NULL){
  if(cb(rgn,user_defined_data))
  goto done;
  }
  free_rgn_start = LLINVALID;
  }
 
 done:
  /* cleanup */
  winx_fclose(f);
  winx_free(bitmap);
  return rlist;
 }
 
 winx_volume_region *winx_add_volume_region(winx_volume_region *rlist,
  ULONGLONG lcn,ULONGLONG length)
 {
  winx_volume_region *r, *rnext, *rprev = NULL;
 
  /* don't insert regions of zero length */
  if(length == 0) return rlist;
 
  for(r = rlist; r; r = r->next){
  if(r->lcn > lcn){
  if(r != rlist) rprev = r->prev;
  break;
  }
  if(r->next == rlist){
  rprev = r;
  break;
  }
  }
 
  /* hits the new region previous one? */
  if(rprev){
  if(rprev->lcn + rprev->length == lcn){
  rprev->length += length;
  if(rprev->lcn + rprev->length == rprev->next->lcn){
  rprev->length += rprev->next->length;
  winx_list_remove((list_entry **)(void *)&rlist,
  (list_entry *)rprev->next);
  }
  return rlist;
  }
  }
 
  /* hits the new region the next one? */
  if(rlist){
  if(rprev == NULL) rnext = rlist;
  else rnext = rprev->next;
  if(lcn + length == rnext->lcn){
  rnext->lcn = lcn;
  rnext->length += length;
  return rlist;
  }
  }
 
  r = (winx_volume_region *)winx_list_insert((list_entry **)(void *)&rlist,
  (list_entry *)rprev,sizeof(winx_volume_region));
  r->lcn = lcn;
  r->length = length;
  return rlist;
 }
 
 winx_volume_region *winx_sub_volume_region(winx_volume_region *rlist,
  ULONGLONG lcn,ULONGLONG length)
 {
  winx_volume_region *r, *head, *next = NULL;
  ULONGLONG remaining_clusters;
  ULONGLONG new_lcn, new_length;
 
  remaining_clusters = length;
  for(r = rlist; r && remaining_clusters; r = next){
  head = rlist;
  next = r->next;
  if(r->lcn >= lcn + length) break;
  if(r->lcn + r->length > lcn){
  /* sure, at least a part of region is inside a specified range */
  if(r->lcn >= lcn && (r->lcn + r->length) <= (lcn + length)){
  /*
  * list entry is inside a specified range
  * |--------------------|
  * |-r-|
  */
  remaining_clusters -= r->length;
  winx_list_remove((list_entry **)(void *)&rlist,
  (list_entry *)r);
  goto next_region;
  }
  if(r->lcn < lcn && (r->lcn + r->length) > lcn && \
  (r->lcn + r->length) <= (lcn + length)){
  /*
  * cut the right side of the list entry
  * |--------------------|
  * |----r----|
  */
  r->length = lcn - r->lcn;
  goto next_region;
  }
  if(r->lcn >= lcn && r->lcn < (lcn + length)){
  /*
  * cut the left side of the list entry
  * |--------------------|
  * |----r----|
  */
  new_lcn = lcn + length;
  new_length = r->lcn + r->length - (lcn + length);
  winx_list_remove((list_entry **)(void *)&rlist,
  (list_entry *)r);
  rlist = winx_add_volume_region(rlist,new_lcn,new_length);
  goto next_region;
  }
  if(r->lcn < lcn && (r->lcn + r->length) > (lcn + length)){
  /*
  * specified range is inside list entry
  * |----|
  * |-------r--------|
  */
  new_lcn = lcn + length;
  new_length = r->lcn + r->length - (lcn + length);
  r->length = lcn - r->lcn;
  rlist = winx_add_volume_region(rlist,new_lcn,new_length);
  goto next_region;
  }
  }
 next_region:
  if(rlist == NULL) break;
  if(next == head) break;
  }
  return rlist;
 }
 
 void winx_release_free_volume_regions(winx_volume_region *rlist)
 {
  winx_list_destroy((list_entry **)(void *)&rlist);
 }
 
//*********** maniki ******************************
//*********** maniki ******************************
//*********** maniki ******************************
//*********** maniki ******************************
//*********** maniki ******************************
//*********** maniki ******************************
//*********** maniki ******************************
//*********** maniki ******************************
BOOL FindFreeSpaceFromEndOfVolume(wchar_t *fileNameForVolLetter,ULONGLONG *lcnfr,ULONGLONG *lcncnt,ULONGLONG *findlcn)
{
ULONGLONG i,start,sztoend,MN,bisy_rgn_start=LLINVALID,free_rgn_end = LLINVALID;
size_t bitmapsize,bitmapbytes=65535;//65535 * 8 = 524280 ta claster;
BITMAP_DESCRIPTOR *bitmap;
unsigned char bitshift[] = { 1, 2, 4, 8, 16, 32, 64, 128 };//bit shifting array for efficient processing of the bitmap
WINX_FILE *f;
IO_STATUS_BLOCK iosb;
NTSTATUS status;
BOOL bFind=FALSE;
char volume_letter;
int percent[2],oldpercent[2];
#define LLINVALID ((ULONGLONG) -1)

  bitmapsize = bitmapbytes + 2 * sizeof(ULONGLONG);

  //ensure that it will work on w2k
  volume_letter = winx_toupper((char)(*fileNameForVolLetter));
 
  //allocate memory
  bitmap = winx_malloc(bitmapsize);
  bitmap->StartLcn = *lcnfr;
 
  //open volume
  f = winx_vopen(volume_letter);
  if(f == NULL)
  { winx_free(bitmap);
	return FALSE;
  }
 
  //1.Volyumini oxiri qayergacha boradi;
  memset(bitmap,0,bitmapsize);
  status = NtFsControlFile( winx_fileno(f),NULL,NULL,0,&iosb,FSCTL_GET_VOLUME_BITMAP,
							lcnfr,sizeof(ULONGLONG),bitmap,32);
  if(0x80000005==status)//NT_SUCCESS(status))
  {	NtWaitForSingleObject(winx_fileno(f),FALSE,NULL);
	status = iosb.Status;
  }
  if(status != STATUS_SUCCESS && status != STATUS_BUFFER_OVERFLOW)
  {	wsprintf(hStatText,strngs[14]/*L"%s:can't get volume bitmap from %I64u cluster ..."*/,fileNameForVolLetter,*lcnfr);
	SetWindowText(hStat,hStatText);
	goto End;
  }

  //2.Endi oxiridan boshiga qarab kelamiz;
  if(bitmap->ClustersToEndOfVol > bitmapbytes * 8)
	sztoend = bitmap->ClustersToEndOfVol - bitmapbytes * 8;
  else
  {	wsprintf(hStatText,strngs[15]/*L"%s:can't get enough space from-%I64u cluster to %I64u-cluster(end)..."*/,fileNameForVolLetter,*lcnfr,bitmap->StartLcn+bitmap->ClustersToEndOfVol);
	SetWindowText(hStat,hStatText);
	goto End;
  }	
  start = *lcnfr + sztoend;
  percent[0]=0;oldpercent[0]=-1;
  while(start > *lcnfr)
  {	memset(bitmap,0,bitmapsize);
    bitmap->StartLcn = start;
	status = NtFsControlFile(winx_fileno(f),NULL,NULL,0,&iosb,FSCTL_GET_VOLUME_BITMAP,
							 &start,sizeof(ULONGLONG),bitmap,bitmapsize);
	if(0x80000005==status)//NT_SUCCESS(status))
	{	NtWaitForSingleObject(winx_fileno(f),FALSE,NULL);
		status = iosb.Status;
	}
	if(status != STATUS_SUCCESS && status != STATUS_BUFFER_OVERFLOW)
	{	wsprintf(hStatText,strngs[16]/*L"%s:cannot get volume bitmap from %I64u cluster ..."*/,fileNameForVolLetter,start);
		SetWindowText(hStat,hStatText);
		goto End;
	}

	percent[0] = 100*(*lcnfr+sztoend-start)/sztoend;
	if(oldpercent[0]!=percent[0])
	{	wsprintf(hStatText,strngs[17]/*L"%s:get volume bitmap,%d %c posted ..."*/,fileNameForVolLetter,percent[0],'%');
		SetWindowText(hStat,hStatText);
	}
	oldpercent[0]=percent[0];

	*findlcn = 0;
	bFind = FALSE;
	MN = min(bitmap->ClustersToEndOfVol, 8 * bitmapbytes);
	oldpercent[1]=-1;
	for(i=MN-1; i>=0; i--)//for(i=0; i<MN; i++)
	{ if(!(bitmap->Map[i/8] & bitshift[i%8]))//cluster is free
	  { if(free_rgn_end == LLINVALID)
		{	free_rgn_end = start + i;//wsprintf(hStatText,L"\nfree_rgn_end: %I64u",free_rgn_end);OutputDebugStringW(hStatText);
			bisy_rgn_start = LLINVALID;
	  }	}
	  else
	  { if(bisy_rgn_start == LLINVALID)
		{	bisy_rgn_start = start + i;//wsprintf(hStatText,L"\nbisy_rgn_start: %I64u",bisy_rgn_start);OutputDebugStringW(hStatText);
			if(free_rgn_end != LLINVALID)
			{	if(free_rgn_end > bisy_rgn_start)
				{	if(free_rgn_end - bisy_rgn_start > (*lcncnt))
					{	*findlcn = free_rgn_end-(*lcncnt)-2;//bisy_rgn_start-2;//free_rgn_end;
						if(*findlcn > bisy_rgn_start-1)
							*findlcn = bisy_rgn_start-1;
						bFind = TRUE;
						wsprintf(hStatText,strngs[18]/*L"%s:find freespace for %I64u clusters at the %%I64u - cluster ..."*/,
								 fileNameForVolLetter,(*lcncnt),(*findlcn));
						SetWindowText(hStat,hStatText);
						goto End;
			}	}	}
			free_rgn_end = LLINVALID;
	  } }
	  percent[1] = 100-100*i/MN;//percent[1] = 100*i/MN;
	  if(percent[1]!=oldpercent[1])
	  {	wsprintf(hStatText,strngs[19]/*L"%s:get volume bitmap,%d %c posted,analyze %d %c ..."*/,
			     fileNameForVolLetter,percent[0],L'%',percent[1],L'%');
		SetWindowText(hStat,hStatText);
	  }
	  oldpercent[1]=percent[1];
	  if(0==i)break;//i int emas, 0dan keyin ham davom etib ketmasligi uchun;
	}
    if(!bFind)
    {	if(free_rgn_end!=LLINVALID)
		{	if(bisy_rgn_start==LLINVALID)
			{	if(free_rgn_end > start + i)
				{	if(free_rgn_end - (start + i) > (*lcncnt))
					{	*findlcn = free_rgn_end - (*lcncnt)-1;//free_rgn_end;
						bFind = TRUE;
						wsprintf(hStatText,strngs[20]/*L"%s:find freespace at the %I64u-cluster ..."*/,fileNameForVolLetter,*findlcn);
						SetWindowText(hStat,hStatText);
						goto End;
	}	}	}	}	}
	start -= bitmapbytes * 8;
	bitmap->StartLcn = start;
  }
End:
  winx_fclose(f);
  winx_free(bitmap);
  return bFind;
}

BOOL FindFreeSpaceFromLcnVolume(wchar_t *fileNameForVolLetter,ULONGLONG *lcnfr,ULONGLONG *lcncnt,ULONGLONG *findlcn)
{
ULONGLONG i,start,bisy_rgn_start=LLINVALID,free_rgn_start = LLINVALID;
size_t bitmapsize,bitmapbytes=65535;//65535 * 8 = 524280 ta claster;
BITMAP_DESCRIPTOR *bitmap;
unsigned char bitshift[] = { 1, 2, 4, 8, 16, 32, 64, 128 };//bit shifting array for efficient processing of the bitmap
WINX_FILE *f;
IO_STATUS_BLOCK iosb;
NTSTATUS status;
BOOL bFind=FALSE;
char volume_letter;
#define LLINVALID ((ULONGLONG) -1)

  bitmapsize = bitmapbytes + 2 * sizeof(ULONGLONG);

  //ensure that it will work on w2k
  volume_letter = winx_toupper((char)(*fileNameForVolLetter));
 
  //allocate memory
  bitmap = winx_malloc(bitmapsize);
  bitmap->StartLcn = *lcnfr;
 
  //open volume
  f = winx_vopen(volume_letter);
  if(f == NULL)
  { winx_free(bitmap);
	return FALSE;
  }
 
  //1.Volyumini oxiri qayergacha boradi;
  memset(bitmap,0,bitmapsize);
  status = NtFsControlFile( winx_fileno(f),NULL,NULL,0,&iosb,FSCTL_GET_VOLUME_BITMAP,
							lcnfr,sizeof(ULONGLONG),bitmap,32);
  if(0x80000005==status)//NT_SUCCESS(status))
  {	NtWaitForSingleObject(winx_fileno(f),FALSE,NULL);
	status = iosb.Status;
  }
  if(status != STATUS_SUCCESS && status != STATUS_BUFFER_OVERFLOW)
  {	//strace(status,"cannot get volume bitmap");
	goto End;
  }

  //2.Endi oxiridan boshiga qarab kelamiz;
  start = *lcnfr;
  while(start < *lcnfr + bitmap->ClustersToEndOfVol)
  {	memset(bitmap,0,bitmapsize);
    bitmap->StartLcn = start;
	status = NtFsControlFile(winx_fileno(f),NULL,NULL,0,&iosb,FSCTL_GET_VOLUME_BITMAP,
							 &start,sizeof(ULONGLONG),bitmap,bitmapsize);
	if(0x80000005==status)//NT_SUCCESS(status))
	{	NtWaitForSingleObject(winx_fileno(f),FALSE,NULL);
		status = iosb.Status;
	}
	if(status != STATUS_SUCCESS && status != STATUS_BUFFER_OVERFLOW)
	{	//strace(status,"cannot get volume bitmap");
		goto End;
	}
	*findlcn = 0;
	bFind = FALSE;
	for(i=0; i<min(bitmap->ClustersToEndOfVol, 8 * bitmapbytes); i++)
	{ if(!(bitmap->Map[i/8] & bitshift[i%8]))//cluster is free
	  { if(free_rgn_start == LLINVALID)
		{	free_rgn_start = start + i;
			bisy_rgn_start = LLINVALID;
	  }	}
	  else
	  { if(bisy_rgn_start == LLINVALID)
		{	bisy_rgn_start = start + i;
			if(free_rgn_start != LLINVALID)
			{	if(free_rgn_start < bisy_rgn_start)
				{	if(bisy_rgn_start - free_rgn_start >= (*lcncnt))
					{	*findlcn = free_rgn_start;
						bFind = TRUE;
						goto End;
			}	}	}
			free_rgn_start = LLINVALID;
	} } }
    if(!bFind)
    {	if(free_rgn_start!=LLINVALID)
		{	if(bisy_rgn_start==LLINVALID)
			{	if(i > (*lcncnt))
				{	*findlcn = start + i - (*lcncnt) - 1;//free_rgn_start;
					if(*findlcn < free_rgn_start)
						*findlcn = free_rgn_start;
					bFind = TRUE;
					goto End;
	}	}	}	}
	start += bitmapbytes * 8;
	bitmap->StartLcn = start;
  }
End:
  winx_fclose(f);
  winx_free(bitmap);
  return bFind;
}

/* Make a 1% free space after the directories, and move all files that
   are in the MFT reserved area. */
BOOL OptimizeFreeSpace(wchar_t *fileNameForVolLetter,ULONGLONG *lcnfr,ULONGLONG *lcncnt)
{
ULONGLONG cnt,start,end,MN,n1,bgn,lcnfree=0,bisy_rgn_start=LLINVALID,free_rgn_start = LLINVALID;
size_t i,bitmapsize,bitmapbytes=65535;//65535 * 8 = 524280 ta claster;
BITMAP_DESCRIPTOR *bitmap;
unsigned char bitshift[] = { 1, 2, 4, 8, 16, 32, 64, 128 };//bit shifting array for efficient processing of the bitmap
WINX_FILE *f;
IO_STATUS_BLOCK iosb;
NTSTATUS status;
BOOL bRet=FALSE;
char volume_letter;
int percent[2],oldpercent[2];
winx_volume_region *freespaselist = NULL, *rgn = NULL,*fndrgn;
mft_scan_parameters sp;
winx_file_info *fi,*filelist=NULL;
ULARGE_INTEGER SystemTime;
WIN32_FILE_ATTRIBUTE_DATA ad;
//winx_blockmap *block;
#define LLINVALID ((ULONGLONG) -1)

  bitmapsize = bitmapbytes + 2 * sizeof(ULONGLONG);

  //ensure that it will work on w2k
  volume_letter = winx_toupper((char)(*fileNameForVolLetter));
 
  //open volume
  f = winx_vopen(volume_letter);
  if(f == NULL)
  { wsprintf(hStatText,strngs[21]/*L"%s:can't open volume handle ..."*/,fileNameForVolLetter);
    SetWindowText(hStat,hStatText);
    return FALSE;
  }

  //1.Volyumini oxiri qayergacha boradi;
  bitmap = winx_malloc(bitmapsize);
  memset(bitmap,0,bitmapsize);
  status = NtFsControlFile( winx_fileno(f),NULL,NULL,0,&iosb,FSCTL_GET_VOLUME_BITMAP,
							lcnfr,sizeof(ULONGLONG),bitmap,32);
  if(0x80000005==status)//NT_SUCCESS(status))
  {	NtWaitForSingleObject(winx_fileno(f),FALSE,NULL);
	status = iosb.Status;
  }
  if(status != STATUS_SUCCESS && status != STATUS_BUFFER_OVERFLOW)
  { wsprintf(hStatText,strngs[22]/*L"%s:can't get volume bitmap ..."*/,fileNameForVolLetter);
    SetWindowText(hStat,hStatText);
	goto End;
  }

  SetRenderParamsForFullDiskOptimize(lcnfr,&bitmap->ClustersToEndOfVol);
  DrawRects(0,lcnfr,bitmap->ClustersToEndOfVol,2);

  //Bo'sh joy qancha????,birdaniga bo'sh joylar spiskasini tuzib chiqsak bo'ladur;
  bgn = bitmap->StartLcn;
  start = bitmap->StartLcn;
  end = start + bitmap->ClustersToEndOfVol;
  oldpercent[0]=-1;
  while(start < end)
  {	memset(bitmap,0,bitmapsize);
    bitmap->StartLcn = start;
	status = NtFsControlFile(winx_fileno(f),NULL,NULL,0,&iosb,FSCTL_GET_VOLUME_BITMAP,
							 &start,sizeof(ULONGLONG),bitmap,bitmapsize);
	if(0x80000005==status)//NT_SUCCESS(status))
	{	NtWaitForSingleObject(winx_fileno(f),FALSE,NULL);
		status = iosb.Status;
	}
	if(status != STATUS_SUCCESS && status != STATUS_BUFFER_OVERFLOW)
	{	wsprintf(hStatText,strngs[23]/*L"%s:can't get volume bitmap from lcn � %I64u ..."*/,fileNameForVolLetter,start);
		SetWindowText(hStat,hStatText);
		goto End;
	}

	percent[0] = 100*(start-bgn)/(end-bgn);
	if(percent[0]!=oldpercent[0])
	{	wsprintf(hStatText,strngs[24]/*L"%s:optimize volume about %d %c ..."*/,fileNameForVolLetter,percent[0],'%');
		SetWindowText(hStat,hStatText);
	}
	oldpercent[0] = percent[0];

	oldpercent[1]=-1;
	MN = min(bitmap->ClustersToEndOfVol, 8 * bitmapbytes);
	for(i=0; i<MN; i++)
	{ if(!(bitmap->Map[i/8] & bitshift[i%8]))//cluster is free
	  { if(free_rgn_start == LLINVALID)
		{	free_rgn_start = start + i;
			bisy_rgn_start = LLINVALID;
	  }	}
	  else
	  { if(bisy_rgn_start == LLINVALID)
		{	bisy_rgn_start = start + i;
			if(free_rgn_start != LLINVALID)
			{	//if(free_rgn_start > bisy_rgn_start)
				{	rgn = (winx_volume_region*)winx_list_insert((list_entry**)(void*)&freespaselist,
															(list_entry*)rgn,sizeof(winx_volume_region));
					rgn->lcn = free_rgn_start;
					rgn->length = start + i - free_rgn_start;
					ScrollToLcn(rgn->lcn);
					DrawRects(0,rgn->lcn,rgn->length,1);
					lcnfree += rgn->length;
			}	}
			free_rgn_start = LLINVALID;
	  } }
	  percent[1]=100*i/MN;
	  if(percent[1]!=oldpercent[1])
	  {	wsprintf(hStatText,strngs[25]/*L"%s:optimize volume about %d %c, analyze: %d %c ..."*/,
				 fileNameForVolLetter,percent[0],'%',percent[1],'%');
		SetWindowText(hStat,hStatText);
	  }
	  oldpercent[1]=percent[1];
	}
	start += bitmapsize*8;
	bitmap->StartLcn = start;
  }
  if(free_rgn_start!=LLINVALID)
  {	rgn = (winx_volume_region*)winx_list_insert((list_entry**)(void*)&freespaselist,
												(list_entry*)rgn,sizeof(winx_volume_region));
	rgn->lcn = free_rgn_start;
	rgn->length = start + i - free_rgn_start;
	ScrollToLcn(rgn->lcn);
	DrawRects(0,rgn->lcn,rgn->length,1);
	lcnfree += rgn->length;
  }
  if(lcnfree<(*lcncnt))
  {	//can'tfree enough space:
	goto End;
  }

  //Avval fayllarni spiskasini tuzib, listdan kerakli bo'sh joyni topib, ko'chirib chiqamiz:
  sp.filelist = &filelist;
  sp.volume_letter = volume_letter;
  sp.processed_attr_list_entries = 0;
  sp.errors = 0;
  sp.flags = WINX_FTW_DUMP_FILES;
  sp.fcb = 0;
  sp.pcb = 0;
  sp.t = 0;
  sp.user_defined_data = NULL;//user_defined_data;
  sp.f_volume = f;

  wsprintf(hStatText,strngs[26]/*L"%s:optimize volume,go scan mft ..."*/,fileNameForVolLetter);
  SetWindowText(hStat,hStatText);
  status = scan_mft(&sp);
  if(status < 0)
  {	goto End;
  }
   
  //1 kungacha o'zgartirilganlariga tegmaslik uchun:
  GetSystemTimeAsFileTime(&SystemTime);
  n1 = 10000000;
  n1 = n1 * 24 * 60 * 60;

  /* call filter callback for each file found */
  cnt=0;
  oldpercent[1]=-1;
  for(fi = filelist; fi != NULL; fi = fi->next)
  { validate_blockmap(fi);
	if(0==fi->disp.fragments)
		goto NxtFileList;
	if(0==fi->disp.clusters)
		goto NxtFileList;
	if(fi->flags & FILE_ATTRIBUTE_DIRECTORY)
		goto NxtFileList;
	if(!IsFileExist(&fi->path[4]))
		goto NxtFileList;
	if(0!=GetFileAttributesEx(&fi->path[4],GetFileExInfoStandard,&ad))
	{	if(*((ULONGLONG*)&ad.ftLastWriteTime) + n1 > SystemTime.QuadPart)
			goto NxtFileList;
	}
    /*block = fi->disp.blockmap;
	for(i=0; i<fi->disp.fragments; i++)
	{	//if(block->lcn < (*lcnfr))
		//	goto NxtFileList;
		block = block->next;
	}*/
	fndrgn = FindOptmlAboveSpaceForFile(fi,freespaselist);
	if(fndrgn)
	{	wsprintf(hStatText,strngs[27]/*L"%s:optimize volume,moving about %d%, move file %s,clusters-%I64u,to the %I64u-lcn ..."*/,
						fileNameForVolLetter,
						sp.processed_attr_list_entries?(cnt/sp.processed_attr_list_entries):0,
						fi->path,fndrgn->length,fndrgn->lcn);
		SetWindowText(hStat,hStatText);
		if(MoveFileToOptmlAboveSpace(f,fi,fndrgn))
		{	winx_blockmap *blck = fi->disp.blockmap;
			winx_list_remove((list_entry**)(void*)&freespaselist,(list_entry*)fndrgn);
			ScrollToLcn(fndrgn->lcn);
			DrawRects(0,fndrgn->lcn,fndrgn->length,1);
			ScrollToLcn(blck->lcn);
			for(i=0; i<fi->disp.fragments; i++)
			{	DrawRects(0,blck->lcn,blck->length,1);
				blck = blck->next;
	}	}	}
NxtFileList:
    if(fi->next == filelist) break;
	++cnt;
	percent[1]=sp.processed_attr_list_entries?(cnt/sp.processed_attr_list_entries):0;
	if(percent[1]!=oldpercent[1])
	{	wsprintf(hStatText,strngs[28]/*L"%s:optimize volume,moving about %d %c ..."*/,fileNameForVolLetter,percent[1],'%');
		SetWindowText(hStat,hStatText);
	}
	oldpercent[1]=percent[1];
  }

  bRet = TRUE;
End:
  winx_fclose(f);
  winx_free(bitmap);
  winx_list_destroy((list_entry**)(void*)&freespaselist);
  winx_list_destroy((list_entry**)(void*)filelist);
  return bRet;
}

BOOL FillVolumeHole(wchar_t *fileNameForVolLetter,ULONGLONG *lcnfr,ULONGLONG *lcncnt,int callNum)
{
ULONGLONG i,optimalDismatch,start = *lcnfr;
WINX_FILE *f;
static WINX_FILE *fVol;//callNum==0 da init,1 da rabochiy, 2-da destroy;
IO_STATUS_BLOCK iosb;
NTSTATUS status;
BOOL bRet=FALSE;
char volume_letter;
int percent,oldpercent;
static mft_scan_parameters sp;
winx_file_info *fi,*optimalfi;
static winx_file_info *filelist=NULL;//callNum==0 da init,1 da rabochiy, 2-da destroy;
winx_blockmap *blck;
MOVEFILE_DESCRIPTOR mfd;
#define LLINVALID ((ULONGLONG) -1)

  if(0==callNum)
  {  //ensure that it will work on w2k
	volume_letter = winx_toupper((char)(*fileNameForVolLetter));
 
	//open volume
	fVol = winx_vopen(volume_letter);
	if(fVol == NULL)
		return FALSE;

    //Avval fayllarni spiskasini tuzib, listdan kerakli bo'sh joyni topib, ko'chirib chiqamiz:
  	sp.filelist = &filelist;
	sp.volume_letter = volume_letter;
	sp.processed_attr_list_entries = 0;
	sp.errors = 0;
	sp.flags = WINX_FTW_DUMP_FILES;
	sp.fcb = 0;
	sp.pcb = 0;
	sp.t = 0;
	sp.user_defined_data = NULL;//user_defined_data;
	sp.f_volume = fVol;
	    
	status = scan_mft(&sp);
	if(status < 0)
		goto End;
  }
   
  optimalDismatch = LLINVALID;
  i=0;
  oldpercent=-1;
  /* call filter callback for each file found */
  for(fi = filelist; fi != NULL; fi = fi->next)
  { validate_blockmap(fi);
	if(0==fi->disp.fragments)
		goto NxtFileList;
	if(0==fi->disp.clusters)
		goto NxtFileList;
	if(*lcncnt < fi->disp.clusters)
		goto NxtFileList;
	if(fi->flags & FILE_ATTRIBUTE_DIRECTORY)
		goto NxtFileList;
	if(!IsFileExist(&fi->path[4]))
		goto NxtFileList;
	if(optimalDismatch > (*lcncnt) - fi->disp.clusters)
	{	optimalDismatch = (*lcncnt) - fi->disp.clusters;
		optimalfi= fi;
		if(0==optimalDismatch)
			break;
  	}
NxtFileList:
    if(fi->next == filelist) break;
	++i;
	percent=sp.processed_attr_list_entries?(i/(10*sp.processed_attr_list_entries)):0;
	if(percent!=oldpercent)
	{	wsprintf(hStatText,strngs[29]/*L"%c: find optimal set for volume hole space %d %c posted ..."*/,
				 sp.volume_letter,percent,'%');
		SetWindowText(hStat,hStatText);
	}
	oldpercent=percent;
  }

  if(optimalDismatch != LLINVALID)
  {	f=winx_fopen(optimalfi->path,"r");
	if(!f)
	{	f=winx_fopen(optimalfi->path,"r+");
		if(!f)
		  goto End;
	}
	memset(&mfd,0,sizeof(MOVEFILE_DESCRIPTOR));
	mfd.FileHandle = f->hFile;

	blck = optimalfi->disp.blockmap;
	for(i=0; i<optimalfi->disp.fragments; i++)
	{ mfd.NumVcns = (ULONG)blck->length;
	  mfd.StartVcn.QuadPart = blck->vcn;
	  mfd.TargetLcn.QuadPart = start;
	  status = NtFsControlFile(fVol->hFile,NULL,NULL,0,&iosb,
						       FSCTL_MOVE_FILE,&mfd,sizeof(MOVEFILE_DESCRIPTOR),NULL,0);
	  if(NT_SUCCESS(status))
	  {	NtWaitForSingleObject(winx_fileno(f),FALSE,NULL);
		status = iosb.Status;
  	  }
	  else
	  {	winx_fclose(f);
		goto End;
	  }
	  start += blck->length;
	  blck = blck->next;
	}
    if(callNum<2)//oxirgi chaqieish bo'lmasa:
		winx_list_remove((list_entry**)(void *)&filelist,(list_entry*)optimalfi);
    winx_fclose(f);
  }
	  
  bRet = TRUE;
End:
  if(2==callNum)
  { winx_fclose(fVol);
	winx_list_destroy((list_entry**)(void*)filelist);
  }
  return bRet;
}

winx_volume_region *FindOptmlAboveSpaceForFile(winx_file_info *fi,winx_volume_region *freespacelist)
{
BOOL bBelove;
ULONGLONG i,minRel=LLINVALID;
winx_blockmap *blck;
winx_volume_region *f = freespacelist,*optimalrecord=NULL;
  for(f = freespacelist; f != NULL; f = f->next)
  {	if(f->next == freespacelist)
		break;
	if(f->length < fi->disp.clusters)
		continue;
	bBelove = TRUE;
	blck = fi->disp.blockmap;
	for(i=0; i<fi->disp.fragments; i++)
	{	if(blck->lcn < f->lcn)
		{	bBelove = FALSE;
			break;
		}
		blck = blck->next;
	}
	if(bBelove)
	{	if(minRel > f->length - fi->disp.clusters)
		{	minRel = f->length - fi->disp.clusters;
			if(0==minRel)return f;
			optimalrecord = f;
  } }	}
  return optimalrecord;
}

BOOL MoveFileToOptmlAboveSpace(WINX_FILE *volHandle,winx_file_info *fi,winx_volume_region *movergn)
{
WINX_FILE *f;
NTSTATUS status;
IO_STATUS_BLOCK iosb;
MOVEFILE_DESCRIPTOR mfd;
winx_blockmap *blck;
ULONGLONG i,cpytolcnbgn = movergn->lcn;//movergn->length

  f=winx_fopen(fi->path,"r");
  if(!f)
  {	f=winx_fopen(fi->path,"r+");
	if(!f)
	  return FALSE;
  }
  memset(&mfd,0,sizeof(MOVEFILE_DESCRIPTOR));
  mfd.FileHandle = f->hFile;

  blck = fi->disp.blockmap;
  for(i=0; i<fi->disp.fragments; i++)
  { mfd.TargetLcn.QuadPart = cpytolcnbgn;
	mfd.StartVcn.QuadPart = blck->vcn;
	mfd.NumVcns = (ULONG)blck->length;
	status = NtFsControlFile(volHandle->hFile,NULL,NULL,0,&iosb,
						     FSCTL_MOVE_FILE,&mfd,sizeof(MOVEFILE_DESCRIPTOR),NULL,0);
	if(NT_SUCCESS(status))
	{	NtWaitForSingleObject(winx_fileno(f),FALSE,NULL);
		status = iosb.Status;
  	}
	else
	{ winx_fclose(f);
	  return FALSE;
	}
	cpytolcnbgn += blck->length;
	blck = blck->next;
  }
  winx_fclose(f);
  return TRUE;
}

BOOL MoveFileToEndOfVolume(wchar_t *fileNameForVolumeLetter,ULONGLONG *lcnto)
{
WINX_FILE *f,*fVol;
NTSTATUS status;
IO_STATUS_BLOCK iosb;
MOVEFILE_DESCRIPTOR mfd;
ULONGLONG i,cpytolcnbgn = *lcnto;
wchar_t fname[512]={'\\','?','?','\\'};
char volume_letter = winx_toupper((char)(*fileNameForVolumeLetter));
MyStringCpy(&fname[4],511,fileNameForVolumeLetter);
 
  //open volume
  fVol = winx_vopen(volume_letter);
  if(fVol == NULL)
   return FALSE;

  f=winx_fopen(fname,"r");//fileNameForVolumeLetter,"r");
  if(!f)
  {	f=winx_fopen(fname,"r");//fileNameForVolumeLetter,"r+");
	if(!f)
	{ winx_fclose(fVol);
	  return FALSE;
  } }
  memset(&mfd,0,sizeof(MOVEFILE_DESCRIPTOR));
  mfd.FileHandle = f->hFile;

  for(i=0; i<pFileExtData->ExtentCount; i++)
  { if(0==i)//Ya'ni 0 dan boshlab
	{	mfd.StartVcn.QuadPart = pFileExtData->StartingVcn;
		mfd.NumVcns = (ULONG)(pFileExtData->Extents[0].NextVcn-pFileExtData->StartingVcn);
	}
	else
	{	mfd.StartVcn.QuadPart = pFileExtData->Extents[i-1].NextVcn;
		mfd.NumVcns = (ULONG)(pFileExtData->Extents[i].NextVcn-pFileExtData->Extents[i-1].NextVcn);
	}
	mfd.TargetLcn.QuadPart = cpytolcnbgn;
	status = NtFsControlFile(fVol->hFile,NULL,NULL,0,&iosb,
						     FSCTL_MOVE_FILE,&mfd,sizeof(MOVEFILE_DESCRIPTOR),NULL,0);
	if(NT_SUCCESS(status))
	{	NtWaitForSingleObject(winx_fileno(f),FALSE,NULL);
		status = iosb.Status;
  	}
	else
	{ winx_fclose(f);
	  winx_fclose(fVol);
	  return FALSE;
	}
	cpytolcnbgn += mfd.NumVcns;
  }

  //FlushFileBuffers(f->hFile);
  winx_fclose(f);
  winx_fclose(fVol);
  return TRUE;
}

//1 ta bo'lak, vcn=0;bo'lak - to'liq;
BOOL MoveFileToLcnOfVolume(wchar_t *fileNameForVolumeLetter,ULONGLONG *lcnto,ULONGLONG *lcncnt)
{
WINX_FILE *f,*fVol;
NTSTATUS status;
IO_STATUS_BLOCK iosb;
MOVEFILE_DESCRIPTOR mfd;
wchar_t fname[512]={'\\','?','?','\\'};
char volume_letter = winx_toupper((char)(*fileNameForVolumeLetter));
MyStringCpy(&fname[4],511,fileNameForVolumeLetter);
 
  //open volume
  fVol = winx_vopen(volume_letter);
  if(!fVol)
   return FALSE;

  f=winx_fopen(fname,"r");
  if(!f)
  {	f=winx_fopen(fname,"r+");
	if(!f)
	{ winx_fclose(fVol);
	  return FALSE;
  } }
  memset(&mfd,0,sizeof(MOVEFILE_DESCRIPTOR));
  mfd.FileHandle = f->hFile;

  mfd.NumVcns = (ULONG)(*lcncnt);
  mfd.StartVcn.QuadPart = 0;
  mfd.TargetLcn.QuadPart = *lcnto;
  status = NtFsControlFile(fVol->hFile,NULL,NULL,0,&iosb,
					       FSCTL_MOVE_FILE,&mfd,sizeof(MOVEFILE_DESCRIPTOR),NULL,0);
  if(NT_SUCCESS(status))
  {	NtWaitForSingleObject(winx_fileno(f),FALSE,NULL);
  	status = iosb.Status;
  }
  winx_fclose(f);
  winx_fclose(fVol);
  return TRUE;
}