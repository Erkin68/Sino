#include "zenwin\ntndk.h"

NTSTATUS (WINAPI * pRtlInitUnicodeString)(PUNICODE_STRING, PCWSTR);
NTSTATUS (WINAPI * pNtCreateFile)(PHANDLE, ACCESS_MASK, POBJECT_ATTRIBUTES, PIO_STATUS_BLOCK, PLARGE_INTEGER, ULONG, ULONG, ULONG, ULONG, PVOID, ULONG);
NTSTATUS (WINAPI * pNtCreateEvent)(PHANDLE, ACCESS_MASK, POBJECT_ATTRIBUTES, EVENT_TYPE, BOOLEAN);
NTSTATUS (WINAPI * pNtQueryDirectoryFile)(HANDLE, HANDLE, PIO_APC_ROUTINE, PVOID, PIO_STATUS_BLOCK, PVOID, ULONG, FILE_INFORMATION_CLASS, BOOLEAN, PUNICODE_STRING, BOOLEAN);
NTSTATUS (WINAPI * pNtWaitForSingleObject)(HANDLE, BOOLEAN, PLARGE_INTEGER);
NTSTATUS (WINAPI * pRtlUnicodeStringToAnsiString)(PANSI_STRING, PCUNICODE_STRING, BOOLEAN);
NTSTATUS (WINAPI * pNtClose)(HANDLE);


BOOL LoadNTProces()
{
	HMODULE hModule = LoadLibrary(L"Ntdll.dll");
	if(!hModule)return FALSE;
	pRtlInitUnicodeString = (NTSTATUS (WINAPI *)(PUNICODE_STRING, PCWSTR)) GetProcAddress (hModule, "RtlInitUnicodeString");
	pNtCreateFile = (NTSTATUS (WINAPI *)(PHANDLE, ACCESS_MASK, POBJECT_ATTRIBUTES, PIO_STATUS_BLOCK, PLARGE_INTEGER, ULONG, ULONG, ULONG, ULONG, PVOID, ULONG)) GetProcAddress (hModule, "NtCreateFile");
	pNtCreateEvent = (NTSTATUS (WINAPI *)(PHANDLE, ACCESS_MASK, POBJECT_ATTRIBUTES, EVENT_TYPE, BOOLEAN)) GetProcAddress (hModule, "NtCreateEvent");
	pNtQueryDirectoryFile = (NTSTATUS (WINAPI *)(HANDLE, HANDLE, PIO_APC_ROUTINE, PVOID, PIO_STATUS_BLOCK, PVOID, ULONG, FILE_INFORMATION_CLASS, BOOLEAN, PUNICODE_STRING, BOOLEAN)) GetProcAddress (hModule, "NtQueryDirectoryFile");
	pNtWaitForSingleObject = (NTSTATUS (WINAPI *)(HANDLE, BOOLEAN, PLARGE_INTEGER)) GetProcAddress (hModule, "NtWaitForSingleObject");
	pRtlUnicodeStringToAnsiString = (NTSTATUS (WINAPI *)(PANSI_STRING, PCUNICODE_STRING, BOOLEAN)) GetProcAddress (hModule, "RtlUnicodeStringToAnsiString");
	pNtClose = (NTSTATUS (WINAPI *)(HANDLE)) GetProcAddress (hModule, "NtClose");

	if((!pRtlInitUnicodeString) || (!pNtCreateFile) || (!pNtCreateEvent) || (!pNtQueryDirectoryFile) ||
		(!pNtWaitForSingleObject) || (!pRtlUnicodeStringToAnsiString) || (!pNtClose))
	{	FreeLibrary(hModule);
		return FALSE;
	}
	return TRUE;
}

/*HANDLE TryNtCreatefILE(wchar_t *fName)
{
UNICODE_STRING RootDirectoryName;
OBJECT_ATTRIBUTES RootDirectoryAttributes;
IO_STATUS_BLOCK Iosb;
HANDLE hFile;

	if(((pRtlInitUnicodeString)(&RootDirectoryName, fName))!= STATUS_SUCCESS)
		return 0;
	
	//InitializeObjectAttributes(&RootDirectoryAttributes, &RootDirectoryName, OBJ_CASE_INSENSITIVE, 0, 0);
	InitializeObjectAttributes(&RootDirectoryAttributes, &RootDirectoryName, OBJ_CASE_INSENSITIVE|OBJ_KERNEL_HANDLE, 0, 0);
	
	if(((pNtCreateFile)(&hFile,
						GENERIC_READ|GENERIC_WRITE|FILE_EXECUTE,
						&RootDirectoryAttributes,
						&Iosb,
						0,
						FILE_READ_DATA,//FILE_ATTRIBUTE_DIRECTORY,
						FILE_SHARE_READ,// | FILE_SHARE_WRITE | FILE_SHARE_DELETE,
						FILE_OPEN,
						FILE_ATTRIBUTE_SYSTEM,//OPEN_EXISTING,//FILE_DIRECTORY_FILE, OPEN_PAGING_FILE
						0, 0)) != STATUS_SUCCESS)
		return 0;
	return hFile;
}

VOID CloseNtCrF(HANDLE FileHandle)
{
	((pNtClose)(FileHandle));
}*/
