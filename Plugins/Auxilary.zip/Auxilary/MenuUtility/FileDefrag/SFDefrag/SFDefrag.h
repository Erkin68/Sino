#ifndef _SFDEFRAG_H_
#define _SFDEFRAG_H_

#include "resource.h"
#include "stdio.h"

typedef unsigned __int64 UInt64;

extern HINSTANCE hInst;
extern HWND hWnd,hStat,hLB,hBtnDfrg,hBtnExit,hDrawWnd;
extern HBRUSH bckBrsh,grnBrsh,blueBrsh,redBrsh;
extern UInt64 LCNmin,LCNmax,cellsCnt;
extern int totFiles,drawScrnDCWidth,drawScrnDCHeight,drawScrnScrlHeight,drawScreenScrollY;
extern wchar_t **strngs;
extern DWORD defrThrdId;

#define MAX_WORD		0xffff
#define cellWidth		4
#define cellHeight		4
#define cellDistX		1
#define cellDistY		1
#define NO				0
#define	YES				1
#define MAX_LOADSTRING	100

typedef unsigned __int64 UInt64;

typedef struct TExtentData
{ DWORD ExtentCount;
  ULONG64 StartingVcn;
  struct
  { ULONG64 NextVcn;
    ULONG64 Lcn;
  } Extents[1];
} ExtentData;
extern ExtentData *pFileExtData;

typedef struct TFileListS
{
  struct TFileListS *Parent;    // Parent item. FileListS
  struct TFileListS *Smaller;   // Next smaller item. FileListS
  struct TFileListS *Bigger;	// Next bigger item. FileListS
  wchar_t *FileName;
  ULONG64 Bytes;
  ULONG64 Lcn;
  DWORD RealClusters;
  DWORD UncompressedClusters;
  char Directory;
  char Unmovable;
  ULARGE_INTEGER Time;
} FileListS;
extern FileListS *FileList;


//**** Render.c *************
extern VOID CalcResizeParams(int);
extern VOID Resize(HWND,WPARAM,LPARAM);
extern VOID Render(HDC);
extern int SetScrollInf(WPARAM,LPARAM);

//**** DefragFile.c ********
extern DWORD AnalyzeFile(wchar_t*,int,ULONGLONG*,ULONGLONG*,ULONGLONG*,ULONGLONG*);
extern DWORD AnalyzeSystemFile(wchar_t*,int,ULONGLONG*,ULONGLONG*,ULONGLONG*,ULONGLONG*,DWORD);

extern VOID FileDefrag();
extern VOID CalcLcnMaxMin();

extern ATOM				MyRegisterClass(HINSTANCE);
extern BOOL				InitInstance(HINSTANCE,int);
extern LRESULT CALLBACK	WndProc(HWND,UINT,WPARAM,LPARAM);
extern VOID				Resize(HWND,WPARAM,LPARAM);
extern VOID				InitLOGFONT(LOGFONTW*,int);
extern BOOL				FillDefragFilesInfo();
extern BOOL				CreateChilds(HWND);

//********* NTDllLoad.c ******
//extern BOOL LoadNTProces();
//extern HANDLE TryNtCreatefILE(wchar_t*);
//extern VOID CloseNtCrF(HANDLE);


#endif