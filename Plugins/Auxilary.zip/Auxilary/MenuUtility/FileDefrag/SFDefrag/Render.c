#include "zenwin/ntndk.h"
#include "SFDefrag.h"



UInt64 cellsCnt=0;
int drawScrnDCWidth=0,drawScrnDCHeight=0,drawScrnScrlHeight=0,xCnt=1,yCnt=1,drawScreenScrollY=0;//-2660;

SCROLLINFO scrlinfo = {sizeof(SCROLLINFO),0,0,0,0,0};//SIF_POS|SIF_RANGE|SIF_PAGE


VOID SetRenderParamsForFullDiskOptimize(ULONGLONG *_LCNmin,ULONGLONG *_LCNtot)
{
int realHeight;
scrlinfo.fMask = SIF_POS|SIF_RANGE|SIF_PAGE;
	LCNmin = *_LCNmin;
	LCNmax = LCNmin + *_LCNtot;
	cellsCnt = LCNmax - LCNmin;
	if(!cellsCnt)return;
	xCnt = (drawScrnDCWidth-30)/(cellWidth+cellDistX);
	yCnt = (int)(cellsCnt/xCnt);
	if(cellsCnt>yCnt*xCnt)++yCnt;
	realHeight = yCnt * (cellHeight+cellDistY);
	if(realHeight <= drawScrnDCHeight)
	{	drawScreenScrollY=0;
		scrlinfo.nMin = 0;
		scrlinfo.nMax = 0;
		scrlinfo.nPos = 0;
		scrlinfo.nPage = scrlinfo.nMax - scrlinfo.nMin + 1;
		SetScrollInfo(hDrawWnd,SB_VERT,&scrlinfo,TRUE);
	}
	else
	{	scrlinfo.nMin = 0;
		scrlinfo.nMax = realHeight < MAX_WORD ? realHeight : MAX_WORD;//realHeight;
		drawScrnScrlHeight=realHeight - drawScrnDCHeight;
		scrlinfo.nPage = drawScrnDCHeight * scrlinfo.nMax / realHeight;
		scrlinfo.nPos = 0;
		SetScrollInfo(hDrawWnd,SB_VERT,&scrlinfo,TRUE);
}	}

VOID CalcResizeParams(int iCall)
{
int realHeight;
scrlinfo.fMask = SIF_POS|SIF_RANGE|SIF_PAGE;
	if(!cellsCnt)return;
	xCnt = (drawScrnDCWidth-30)/(cellWidth+cellDistX);
	yCnt = (int)(cellsCnt/xCnt);
		
	if(cellsCnt>yCnt*xCnt)++yCnt;
	realHeight = yCnt * (cellHeight+cellDistY);
	if(realHeight <= drawScrnDCHeight)
	{	drawScreenScrollY=0;
		scrlinfo.nMin = 0;
		scrlinfo.nMax = 0;
		scrlinfo.nPos = 0;
		scrlinfo.nPage = scrlinfo.nMax - scrlinfo.nMin + 1;
		SetScrollInfo(hDrawWnd,SB_VERT,&scrlinfo,TRUE);
	}
	else
	{	double de;if(iCall)de = ((double)scrlinfo.nPos)/(scrlinfo.nMax-scrlinfo.nMin);
		scrlinfo.nMin = 0;
		scrlinfo.nMax = realHeight < MAX_WORD ? realHeight : MAX_WORD;//realHeight;
		drawScrnScrlHeight=realHeight - drawScrnDCHeight;
		scrlinfo.nPage = drawScrnDCHeight * scrlinfo.nMax / realHeight;
		if(0==iCall)
			scrlinfo.nPos = 0;
		else
			scrlinfo.nPos = (int)(de * (scrlinfo.nMax-scrlinfo.nMin));
		SetScrollInfo(hDrawWnd,SB_VERT,&scrlinfo,TRUE);
}	}

VOID ScrollToLcn(ULONGLONG *lcn)
{
	double de = ((double)(*lcn) / (double)(scrlinfo.nMax - scrlinfo.nMin - scrlinfo.nPage - 1));
	scrlinfo.nPos = (int)(de * (scrlinfo.nMax-scrlinfo.nMin));
	drawScreenScrollY = - (int)(de * scrlinfo.nPage * drawScrnDCHeight);//-2660
	scrlinfo.fMask = SIF_POS;
	SetScrollInfo(hDrawWnd,SB_VERT,&scrlinfo,TRUE);	scrlinfo.nMin = 0;
}

VOID Resize(HWND hDlg,WPARAM wParam,LPARAM lParam)
{
int width = LOWORD(lParam);
int height= HIWORD(lParam);

	if(drawScrnDCWidth==width-252)
		if(drawScrnDCHeight==height)
			return;

	if(width<944 && height<680) return;
	if(width<944)width = 944;
	if(height<680)height = 680;

	MoveWindow(	hLB,0,68,
				250,
				height-94,
                TRUE);
	MoveWindow(	hBtnDfrg,2,height-28,
				122,
				25,
                TRUE);
	MoveWindow(	hBtnExit,125,height-28,
				122,
				25,
                TRUE);
	drawScrnDCWidth=width-252;
	drawScrnDCHeight=height;
	MoveWindow( hDrawWnd,252,0,
				drawScrnDCWidth,
				height,
                TRUE);
	CalcResizeParams(1);
	Render(0);
}

int SetScrollInf(WPARAM wParam,LPARAM lParam)
{
	int oldPos = scrlinfo.nPos;
	switch(LOWORD(wParam))
	{	//case SB_BOTTOM:
		//	break;
		//case SB_ENDSCROLL:
		//	break;
		case SB_LINEDOWN:
			scrlinfo.fMask = SIF_POS;
			GetScrollInfo(hDrawWnd,SB_VERT,&scrlinfo);
			++scrlinfo.nPos;
			if(scrlinfo.nPos > scrlinfo.nMax - (int)scrlinfo.nPage - 1)
				scrlinfo.nPos = scrlinfo.nMax - (int)scrlinfo.nPage - 1;
			break;
		case SB_LINEUP:
			scrlinfo.fMask = SIF_POS;
			GetScrollInfo(hDrawWnd,SB_VERT,&scrlinfo);
			--scrlinfo.nPos;
			if(scrlinfo.nPos < scrlinfo.nMin)
				scrlinfo.nPos = scrlinfo.nMin;
			break;
		case SB_PAGEDOWN:
			scrlinfo.fMask = SIF_POS|SIF_PAGE|SIF_RANGE;
			GetScrollInfo(hDrawWnd,SB_VERT,&scrlinfo);
			scrlinfo.nPos += scrlinfo.nPage;
			if(scrlinfo.nPos > scrlinfo.nMax - (int)scrlinfo.nPage - 1)
				scrlinfo.nPos = scrlinfo.nMax - (int)scrlinfo.nPage - 1;
			break;
		case SB_PAGEUP:
			scrlinfo.fMask = SIF_POS|SIF_PAGE|SIF_RANGE;
			GetScrollInfo(hDrawWnd,SB_VERT,&scrlinfo);
			scrlinfo.nPos -= scrlinfo.nPage;
			if(scrlinfo.nPos < scrlinfo.nMin)
				scrlinfo.nPos = scrlinfo.nMin;
			break;
		case SB_THUMBPOSITION:
			scrlinfo.fMask = SIF_POS|SIF_TRACKPOS;
			GetScrollInfo(hDrawWnd,SB_VERT,&scrlinfo);
			scrlinfo.nPos = scrlinfo.nTrackPos;//HIWORD(wParam);
			break;
		case SB_THUMBTRACK:
			scrlinfo.fMask = SIF_POS|SIF_TRACKPOS;
			GetScrollInfo(hDrawWnd,SB_VERT,&scrlinfo);
			scrlinfo.nPos = scrlinfo.nTrackPos;
			break;
		//case SB_TOP:
		//	++scrlinfo.nPos;
		//	break;
	}
	if(oldPos != scrlinfo.nPos)
	{	double rel = ((double)scrlinfo.nPos / (double)(scrlinfo.nMax - scrlinfo.nMin - scrlinfo.nPage - 1));
		int pages = (yCnt * (cellHeight+cellDistY)) / drawScrnDCHeight;
		drawScreenScrollY = - (int)(rel * pages * drawScrnDCHeight);//-2660
							//min da 0
							//max da max = nPos + (nPage - 1), shunda oxirigacha drawScrnDCHeight qolishi kerak,
							//ya'ni, realHeight - drawScrnDCHeight qolishi kerak;
		scrlinfo.fMask = SIF_POS;
		SetScrollInfo(hDrawWnd,SB_VERT,&scrlinfo,TRUE);
		return 1;
	}
	return 0;
}

int DrawRects(HDC DC,UInt64 fromCell,UInt64 tot,int color)
{
int x,y,thisYCnt;
RECT r;UInt64 i;

HDC dc = DC?DC:GetDC(hDrawWnd);

	//HBRUSH oldBrsh = (HBRUSH)SelectObject(dc,color?(1==color?blueBrsh:redBrsh):grnBrsh);

	fromCell -= LCNmin;
	x = fromCell % xCnt;
	y = (int)(fromCell / xCnt);
	thisYCnt = (int)(tot/xCnt);
	SetRect(&r,	x*(cellWidth+cellDistX),
				y*(cellHeight+cellDistY)+drawScreenScrollY,
				x*(cellWidth+cellDistX) + cellWidth,
				y*(cellHeight+cellDistY)+drawScreenScrollY+cellHeight);

	if(r.top > drawScrnDCHeight) return 1;
	if(r.bottom + thisYCnt*(cellHeight+cellDistY) < 0) return -1;

	for(i=0; i<tot; i++)
	{	if(r.top > drawScrnDCHeight)
		{	return 1;
		}
		if(r.bottom > 0)
		{	//Rectangle(dc,r.left,r.top,r.right,r.bottom);
			switch(color)
			{	case 0:
					FillRect(dc,&r,grnBrsh); break;
				case 1:
					FillRect(dc,&r,blueBrsh); break;
				case 2:
					FillRect(dc,&r,redBrsh); break;
		}	}
		if(++x>xCnt-1)//if(r.left>drawScrnDCWidth-30-cellWidth)
		{	r.left = 0;
			r.right = cellWidth;
			r.top += cellHeight+cellDistY;
			r.bottom = r.top+cellHeight;
			x=0;
		}
		else
		{	r.left += cellWidth+cellDistX;
			r.right = r.left+cellWidth;
	}	}
	if(!DC) ReleaseDC(hDrawWnd,dc);
	//SelectObject(dc,oldBrsh);
	return 0;
}

VOID Render(HDC DC)
{
#define width  r.right
#define height r.bottom
UInt64 lcnEnd;
RECT r;DWORD i;
HDC dc = DC?DC:GetDC(hDrawWnd);
	GetClientRect(hDrawWnd,&r);

	//ClrScrn:
	FillRect(dc,&r,bckBrsh);

	if(!pFileExtData) return;

	if(!pFileExtData->ExtentCount)
		goto End;

	lcnEnd = LCNmin;

	if(pFileExtData->Extents[0].Lcn>LCNmin)
	{	//if(0<DrawRects(dc,LCNmin,pFileExtData->Extents[0].Lcn-LCNmin,2))//red
		//	return;
		DrawRects(dc,LCNmin,pFileExtData->Extents[0].Lcn-LCNmin,2);
	}

	for(i=0; i<pFileExtData->ExtentCount; i++)
	{	UInt64 fileLcnTot;
		if(0==i)
			fileLcnTot = pFileExtData->Extents[0].NextVcn-pFileExtData->StartingVcn;
		else
			fileLcnTot = pFileExtData->Extents[i].NextVcn-pFileExtData->Extents[i-1].NextVcn;
		if(pFileExtData->Extents[i].Lcn>lcnEnd)
		{	//if(0<DrawRects(dc,lcnEnd,pFileExtData->Extents[i].Lcn-lcnEnd,2))//red
			//	return;
			DrawRects(dc,lcnEnd,pFileExtData->Extents[i].Lcn-lcnEnd,2);
		}
		//if(0<DrawRects(dc,pFileExtData->Extents[i].Lcn,fileLcnTot,1))//blue
		//	return;
		DrawRects(dc,pFileExtData->Extents[i].Lcn,fileLcnTot,1);
		lcnEnd = pFileExtData->Extents[i].Lcn+fileLcnTot;
	}

End:
	if(!DC)ReleaseDC(hDrawWnd,dc);
#undef width
#undef height
}