#include "windows.h"
#include "strsafe.h"
#include "shlobj.h"
#include "..\..\..\..\Operations\MyShell\MyShellC.h"



extern wchar_t **strngs;
extern HMODULE plgnDllInst;

INT_PTR CALLBACK DefragDlgProc(HWND,UINT,WPARAM,LPARAM);
BOOL FillDefragFilesInfo(HWND,WIN32_FIND_DATAW*,int);
VOID Resize(HWND,WPARAM,LPARAM);

typedef BOOL (CALLBACK *saveOptions_t)(int,VOID*,int);
typedef BOOL (CALLBACK *readOptions_t)(int,VOID*,int);
typedef int  (CALLBACK *getTotPanels_t)();
typedef int  (CALLBACK *getCrntPanelNum_t)();
typedef wchar_t* (CALLBACK *getPanelPath_t)(int);
typedef LPVOID (CALLBACK *getPanelCrntItem_t)(int,WIN32_FIND_DATAW* );
typedef LPVOID (CALLBACK *getPanelSelectedItems_t)(int,int*);
typedef unsigned __int64* (CALLBACK *getLogicalDriveSpace_t)(int);
//typedef VOID (CALLBACK *MayFreePluginDll_t)(int);

saveOptions_t saveOptions=0;
readOptions_t readOptions=0;
getTotPanels_t getTotPanels=0;
getCrntPanelNum_t getCrntPanelNum=0;
getPanelCrntItem_t getPanelCrntItem=0;
getPanelSelectedItems_t getPanelSelectedItems=0;
getPanelPath_t getPanelPath=0;
getLogicalDriveSpace_t getLogicalDriveSpace=0;
//MayFreePluginDll_t MayFreePluginDll=0;

int plgId = 0;
BOOL bStop=FALSE;

__declspec (dllexport) VOID SetCallbacks$4xxx(LPVOID frstCallback,...)
{
va_list args;
	va_start(args, frstCallback);//1
	saveOptions = (saveOptions_t)frstCallback;//1
	readOptions = (readOptions_t)va_arg(args, LPVOID);//2
	getTotPanels = (getTotPanels_t)va_arg(args, LPVOID);//3
	getCrntPanelNum = (getCrntPanelNum_t)va_arg(args, LPVOID);//4
	getPanelCrntItem = (getPanelCrntItem_t)va_arg(args, LPVOID);//5
	getPanelSelectedItems = (getPanelSelectedItems_t)va_arg(args, LPVOID);//6
	getPanelPath = (getPanelPath_t)va_arg(args, LPVOID);//7
	getLogicalDriveSpace = (getLogicalDriveSpace_t)va_arg(args, LPVOID);//8
	//MayFreePluginDll = (MayFreePluginDll_t)va_arg(args, int);//8
va_end (args);
}

__declspec (dllexport) BOOL Run$4(HWND prnt)
{
int i,ttlPnl,crntPnl,cmndLineLn;wchar_t modName[MAX_PATH],*p,env[32]={L"language="},*cmdLnBuf;
STARTUPINFO si;PROCESS_INFORMATION pi;
WIN32_FIND_DATAW *pFindFileData;
int iTotFindFileData;

	if(!getCrntPanelNum) return FALSE;
	if(!getTotPanels)return FALSE;
	ttlPnl=getTotPanels();
	crntPnl=getCrntPanelNum();
	if(ttlPnl<0) return FALSE;
	if(ttlPnl>3) return FALSE;
	if(crntPnl<0) return FALSE;
	if(crntPnl>ttlPnl-1) return FALSE;
	if(!getPanelCrntItem) return FALSE;


	GetModuleFileNameW(NULL,modName,260);
	p = wcsrchr(modName,'\\');
	if(!p) return FALSE;
	*p = 0;
	SetCurrentDirectory(modName);

	pFindFileData=getPanelSelectedItems(crntPnl,&iTotFindFileData);

	cmndLineLn=0;
	for(i=0; i<iTotFindFileData; i++)
		cmndLineLn += (int)wcslen(pFindFileData[i].cFileName)+3;
	cmdLnBuf = (wchar_t*)malloc(4+cmndLineLn*sizeof(wchar_t));
	p = &cmdLnBuf[0];
	*p++ = ' ';
	for(i=0; i<iTotFindFileData; i++)
	{	*p++ = '"';
		p += MyStringCpy(p,MAX_PATH-1,pFindFileData[i].cFileName);
		*p++ = '"';
	}

	GetModuleFileNameW(plgnDllInst,modName,260);
	p = wcsrchr(modName,'\\');
	if(!p) return FALSE;

#ifdef _WIN64
#ifdef _DEBUG
	MyStringCpy(p+1,17,L"SFDefragDbg64.exe");
#else
	MyStringCpy(p+1,17,L"SFDefragRel64.exe");
#endif
#else
#ifdef _DEBUG
	MyStringCpy(p+1,15,L"SFDefragDbg.exe");
#else
	MyStringCpy(p+1,15,L"SFDefragRel.exe");
#endif
#endif
	if(GetEnvironmentVariable(L"languge",&env[9],23))//Language instartup qo'yadur;
	memset(&si,0,sizeof(si));
	if(!CreateProcessW(modName,cmdLnBuf,NULL,NULL,FALSE,NORMAL_PRIORITY_CLASS|CREATE_UNICODE_ENVIRONMENT,
					   env,0,&si,&pi))
	{	int er=GetLastError();
		free(cmdLnBuf);
		return FALSE;
	}
	//dlg=CreateDialog(plgnDllInst,MAKEINTRESOURCE(IDD_DIALOG_DEFRAG),NULL,DefragDlgProc);
	//ShowWindow(dlg,SW_SHOWNORMAL);
	//UpdateWindow(dlg);
	free(cmdLnBuf);
	return TRUE;
}

__declspec (dllexport) int GetPluginType()
{
	return 102;
}

__declspec (dllexport) const wchar_t* GetPluginName()
{
	return strngs[0];
}

__declspec (dllexport) int GetMenuNum()
{
	return 0;
}

__declspec (dllexport) int GetMenuPos()
{
	return 3;
}

__declspec (dllexport) const wchar_t* GetMenuItemText()
{
	return strngs[4];
}

__declspec (dllexport) const wchar_t* GetMenuText()
{
	return strngs[4];
}

__declspec (dllexport) VOID SetId$4(int id)
{
	plgId = id;
}

__declspec (dllexport) const wchar_t* GetPluginDescription()
{
	return strngs[0];
}

__declspec (dllexport) VOID ShowOptionDialog(HWND prnt)
{
}