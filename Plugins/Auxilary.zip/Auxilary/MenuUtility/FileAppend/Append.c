#include "windows.h"
#include "resource.h"
#include "strsafe.h"
#include "shlobj.h"
#include "..\..\..\..\Operations\MyShell\MyShellC.h"



extern wchar_t **strngs;
extern HMODULE plgnDllInst;

INT_PTR CALLBACK ApndDlgProc(HWND,UINT,WPARAM,LPARAM);
BOOL AppendFiles(HWND);
BOOL CheckStopBtnMsg(HWND);
BOOL FillSptlFilesInfo(HWND hDlg,wchar_t*);
BOOL DeleteSplitFiles(HWND);

typedef BOOL (CALLBACK *saveOptions_t)(int,VOID*,int);
typedef BOOL (CALLBACK *readOptions_t)(int,VOID*,int);
typedef int  (CALLBACK *getTotPanels_t)();
typedef int  (CALLBACK *getCrntPanelNum_t)();
typedef wchar_t* (CALLBACK *getPanelPath_t)(int);
typedef LPVOID (CALLBACK *getPanelCrntItem_t)(int,WIN32_FIND_DATAW* );
typedef LPVOID (CALLBACK *getPanelSelectedItems_t)(int,int*);
typedef unsigned __int64* (CALLBACK *getLogicalDriveSpace_t)(int);


saveOptions_t saveOptions=0;
readOptions_t readOptions=0;
getTotPanels_t getTotPanels=0;
getCrntPanelNum_t getCrntPanelNum=0;
getPanelCrntItem_t getPanelCrntItem=0;
getPanelSelectedItems_t getPanelSelectedItems=0;
getPanelPath_t getPanelPath=0;
getLogicalDriveSpace_t getLogicalDriveSpace=0;

int plgId = 0;
BOOL bStop=FALSE;
WIN32_FIND_DATAW pFindFileData;

__declspec (dllexport) VOID SetCallbacks$4xxx(LPVOID frstCallback,...)
{
va_list args;
	va_start(args, frstCallback);//1
	saveOptions = (saveOptions_t)frstCallback;//1
	readOptions = (readOptions_t)va_arg(args, LPVOID);//2
	getTotPanels = (getTotPanels_t)va_arg(args, LPVOID);//3
	getCrntPanelNum = (getCrntPanelNum_t)va_arg(args, LPVOID);//4
	getPanelCrntItem = (getPanelCrntItem_t)va_arg(args, LPVOID);//5
	getPanelSelectedItems = (getPanelSelectedItems_t)va_arg(args, LPVOID);//6
	getPanelPath = (getPanelPath_t)va_arg(args, LPVOID);//7
	getLogicalDriveSpace = (getLogicalDriveSpace_t)va_arg(args, LPVOID);//8
va_end (args);
}

__declspec (dllexport) BOOL Run$4(HWND prnt)
{
int ttlPnl,crntPnl;
	if(!getCrntPanelNum) return FALSE;
	if(!getTotPanels)return FALSE;
	ttlPnl=getTotPanels();
	crntPnl=getCrntPanelNum();
	if(ttlPnl<0) return FALSE;
	if(ttlPnl>3) return FALSE;
	if(crntPnl<0) return FALSE;
	if(crntPnl>ttlPnl-1) return FALSE;
	if(!getPanelCrntItem) return FALSE;
	DialogBox(plgnDllInst,MAKEINTRESOURCE(IDD_DIALOG_APPEND),prnt,ApndDlgProc);
	return TRUE;
}

__declspec (dllexport) int GetPluginType()
{
	return 102;
}

__declspec (dllexport) const wchar_t* GetPluginName()
{
	return strngs[1];
}

__declspec (dllexport) int GetMenuNum()
{
	return 0;
}

__declspec (dllexport) int GetMenuPos()
{
	return 3;
}

__declspec (dllexport) const wchar_t* GetMenuItemText()
{
	return strngs[0];
}

__declspec (dllexport) const wchar_t* GetMenuText()
{
	return strngs[0];
}

__declspec (dllexport) VOID SetId$4(int id)
{
	plgId = id;
}

__declspec (dllexport) const wchar_t* GetPluginDescription()
{
	return strngs[1];
}

__declspec (dllexport) VOID ShowOptionDialog(HWND prnt)
{
}

BOOL IsCrntOrPrntDirAttrb(wchar_t* fd)
{//see Naming Conventions in MSDN:
	if('.'==fd[0])
	{	if('\0'==fd[1])//"."
			return FALSE;
		if('.'==fd[1])
			if('\0'==fd[2])//".."
				return FALSE;
	}
	return TRUE;//Hozircha;
}

unsigned __int64 MyAtoU64(wchar_t *s)
{
unsigned __int64 rt=0;
wchar_t *ps = s;
	while(*ps!=0)
	{	if(*ps < '0')
			return 0;
		if(*ps > '9')
			return 0;
		rt = rt*10 + (*ps - '0');
		ps++;
	}
	return rt;
}

BOOL MyU64ToA(wchar_t* st,int sLen,unsigned __int64 u)
{
int i,l=0;
unsigned __int64 delit = u;
static wchar_t s[32];
	if(!u)
	{	st[0] = '0';
		st[1] = 0;
		return TRUE;
	}

	while(delit)
	{	s[l++] = delit % 10 + '0';
		delit /= 10;
	}
	for(i=0; i<l; i++)
		st[i] = s[l-i-1];
	st[l] = 0;
	return TRUE;
}

INT_PTR CALLBACK ApndDlgProc(hDlg,message,wParam,lParam)
HWND hDlg;
UINT message;
WPARAM wParam;
LPARAM lParam;
{	//static int i=0;
	//char ss[32];sprintf(ss,"\n %d ",i++);
	//OutputDebugString(ss);
	//OutputDebugString(GetWinNotifyText(message));
	//sprintf(ss," %x %x",wParam,lParam);
	//OutputDebugString(ss);

static HFONT hf=0;
//static int hfRef=0;//obshiy hf, dinamik uchun emas:
static HBRUSH br=0;
//static LPVOID panel;
static HBRUSH brHtBk=0;
static int endDialogCodeToWM_DESTROY;
static int szQntSlct=0;
wchar_t s[MAX_PATH],ss[MAX_PATH],*ps;
__int64 szFile;
int left,top,width,height,nxtPnlNum=-1;
LPITEMIDLIST pidlRoot,pidlSelected;
BROWSEINFO bi;
OPENFILENAME ofn;
LOGFONT fnt;
RECT rc,rc1;
HDC dc;HWND prnt;

	switch(message)
	{	case WM_INITDIALOG:
			GetWindowRect(hDlg, &rc1);prnt = GetParent(hDlg);if(!prnt)prnt=GetDesktopWindow();
			GetWindowRect(prnt, &rc);
			width = rc1.right - rc1.left;		
			left = rc.left + (rc.right - rc.left - width)/2;//left = (GetSystemMetrics(SM_CXFULLSCREEN) - width)/2;
			height = rc1.bottom - rc1.top;
			top = rc.top + (rc.bottom - rc.top - height)/2;//top = (GetSystemMetrics(SM_CYFULLSCREEN) - height)/2;
			MoveWindow(hDlg, left, top+20, width, height, TRUE);

			//Load language strings:
			SetWindowTextW(hDlg,strngs[0]);
			SetDlgItemTextW(hDlg,IDC_STATIC5,strngs[3]);
			SetDlgItemText(hDlg,IDC_STATIC1,strngs[4]);
			SetDlgItemText(hDlg,IDC_STATIC2,strngs[19]);
			//SetDlgItemText(hDlg,IDC_STATIC4,strngs[11]); strng[11] bo'sh
			SetDlgItemText(hDlg,IDOK,strngs[5]);
			SetDlgItemText(hDlg,IDSTOP,strngs[6]);
			SetDlgItemText(hDlg,IDCANCEL,strngs[7]);
			SetDlgItemText(hDlg,IDC_BUTTON_BROWSE,strngs[8]);
			SetDlgItemText(hDlg,IDC_BUTTON_BROWSE2,strngs[8]);
			SetDlgItemText(hDlg,IDC_CHECK_DELETE,strngs[32]);
			
			if(getPanelCrntItem(getCrntPanelNum(),&pFindFileData))
			{	FillSptlFilesInfo(hDlg,pFindFileData.cFileName);
				SetDlgItemTextW(hDlg,IDC_EDIT_SRC,pFindFileData.cFileName);
				ps=wcsrchr(pFindFileData.cFileName,'\\');
				if(ps)
				{	wchar_t ch=*(ps+1);
					*(ps+1) = 0;
					SetDlgItemTextW(hDlg,IDC_EDIT_DEST,pFindFileData.cFileName);
					*(ps+1) = ch;//'\\';
				}
				left=getTotPanels();
				if(left>0 && left<5)
				{	for(top=0; top<left; top++)
					{	StringCchPrintfW(s,MAX_PATH-1,L"%d-panel",top+1);
						SendMessageW(GetDlgItem(hDlg,IDC_COMBO_DEST_PANEL),CB_INSERTSTRING,(WPARAM)-1,(LPARAM)s);
			}	}	}
			SendMessage(hDlg,WM_USER+1,0,0);
			break;
		case WM_CTLCOLORSTATIC:
		case WM_CTLCOLORDLG:dc = (HDC)wParam;
			SetTextColor(dc,RGB(0xea,0xe0,0xff));//SetTextColor(dc,RGB(0x8a,0,0));
			SetBkColor(dc,RGB(0x40,0x21,0x17));//SetBkColor(dc,RGB(0xc0,0x81,0x97));
			return (INT_PTR)br;
		case WM_CTLCOLOREDIT:dc = (HDC)wParam;
			SetTextColor(dc,RGB(0xea,0xe0,0xff));//SetTextColor(dc,RGB(0x8a,0,0));
			SetBkColor(dc,RGB(0x40,0x21,0x17));//SetBkColor(dc,RGB(0xc0,0x81,0x97));
			return (INT_PTR)br;
		case WM_CTLCOLORBTN:dc=(HDC)wParam;
			SetTextColor(dc,RGB(0xd0,0xe0,0xff));
			SetBkColor(dc,RGB(0x64,0x79,0x65));
			return (INT_PTR)brHtBk;
/*		case WM_DRAWITEM://WM_CTLCOLORBTN dagi knopkalar:
			lpdis = (LPDRAWITEMSTRUCT)lParam;
			GetWindowText(lpdis->hwndItem,s,MAX_PATH);
			uStyle = DFCS_BUTTONPUSH;
			rc = lpdis->rcItem;
			if(lpdis->itemState & ODS_SELECTED)
			{	uStyle |= DFCS_PUSHED|DFCS_TRANSPARENT;
				rc.left+=2;rc.top+=2;
			}
			DrawFrameControl(lpdis->hDC, &lpdis->rcItem, DFC_BUTTON, uStyle);
			if(lpdis->itemState & ODS_SELECTED)
				{rc.left+=1;rc.top+=1;rc.bottom-=2;rc.right-=3;}
			else
				{rc.left+=1;rc.top+=2;rc.bottom-=3;rc.right-=3;}
			FillRect(lpdis->hDC,&rc,brHtBk);//DrawText(lpdis->hDC,"",50,&rc,DT_SINGLELINE|DT_VCENTER|DT_INTERNAL|DT_LEFT);
			if(lpdis->itemState & ODS_SELECTED)
				{rc.left-=1;rc.top-=1;rc.bottom+=3;rc.right+=3;}
			else
				{rc.left-=1;rc.top-=2;rc.bottom+=2;rc.right+=3;}
			DrawText(lpdis->hDC,s,MyStringLength(s,MAX_PATH),&rc,DT_SINGLELINE|DT_VCENTER|DT_CENTER);
			return TRUE;*/
		case WM_USER+1://hf obshiy uchun, dinamik o'zgartirish uchun emas:
			//if(0==hfRef)
			{	InitLOGFONT(&fnt,0);
				hf = CreateFontIndirect(&fnt);
				br = CreateSolidBrush(RGB(0x40,0x21,0x17));//0xc9,0x81,0x93));
				brHtBk = CreateSolidBrush(RGB(0x64,0x79,0x65));
			}
			SendMessage(GetDlgItem(hDlg,IDC_BUTTON_BROWSE),WM_SETFONT,(WPARAM)hf,TRUE);
			SendMessage(GetDlgItem(hDlg,IDC_BUTTON_BROWSE2),WM_SETFONT,(WPARAM)hf,TRUE);
			SendMessage(GetDlgItem(hDlg,IDSTOP),WM_SETFONT,(WPARAM)hf,TRUE);
			SendMessage(GetDlgItem(hDlg,IDCANCEL),WM_SETFONT,(WPARAM)hf,TRUE);
			SendMessage(GetDlgItem(hDlg,IDOK),WM_SETFONT,(WPARAM)hf,TRUE);
			SendMessage(GetDlgItem(hDlg,IDCANCEL),WM_SETFONT,(WPARAM)hf,TRUE);
			SendMessage(GetDlgItem(hDlg,IDC_STATIC5),WM_SETFONT,(WPARAM)hf,TRUE);
			SendMessage(GetDlgItem(hDlg,IDC_STATIC1),WM_SETFONT,(WPARAM)hf,TRUE);
			SendMessage(GetDlgItem(hDlg,IDC_STATIC2),WM_SETFONT,(WPARAM)hf,TRUE);
			SendMessage(GetDlgItem(hDlg,IDC_COMBO_EARCH_PART_SIZE),WM_SETFONT,(WPARAM)hf,TRUE);
			SendMessage(GetDlgItem(hDlg,IDC_COMBO_DEST_PANEL),WM_SETFONT,(WPARAM)hf,TRUE);			

			SendMessage(GetDlgItem(hDlg,IDC_EDIT_SRC),WM_SETFONT,(WPARAM)hf,TRUE);
			SendMessage(GetDlgItem(hDlg,IDC_EDIT_DEST),WM_SETFONT,(WPARAM)hf,TRUE);
			//++hfRef;
			return 0;//GWL_USERDATA
		case WM_DESTROY:
			//if(--hfRef<1)
			{	DeleteObject(hf);
				DeleteObject(br);
				DeleteObject(brHtBk);
			}
			return 0;
		case WM_COMMAND:
			switch(LOWORD(wParam))
			{	case IDC_BUTTON_BROWSE:
					bi.hwndOwner = hDlg;
					bi.pszDisplayName = s;
					bi.lpszTitle = strngs[16];//"Browse for build directory ...";
					bi.ulFlags = BIF_NONEWFOLDERBUTTON|BIF_DONTGOBELOWDOMAIN|BIF_NEWDIALOGSTYLE|
						BIF_NOTRANSLATETARGETS|BIF_RETURNFSANCESTORS;
					bi.lpfn = NULL;
					pidlRoot = NULL;
					bi.pidlRoot = pidlRoot;
					pidlSelected = SHBrowseForFolder(&bi);
					if(pidlRoot)
						CoTaskMemFree(pidlRoot);
					if(pidlSelected)
					{	SHGetPathFromIDList(pidlSelected,s);
						SetDlgItemText(hDlg,IDC_EDIT_DEST,s);
						CoTaskMemFree(pidlSelected);
					}
	   				return (INT_PTR)TRUE;
				case IDC_BUTTON_BROWSE2://src file:
					ZeroMemory(&ofn, sizeof(ofn));
					s[0] = '\0';
					ofn.lStructSize = sizeof(ofn);
					ofn.hwndOwner = NULL; 
					ofn.lpstrFile = s; 
					ofn.nMaxFile = MAX_PATH;
					ofn.lpstrFilter = NULL;
					ofn.nFilterIndex = 1;
					ofn.lpstrTitle = strngs[17];//"Search for split files:";
					ofn.lpstrInitialDir = NULL;
					ofn.lpstrCustomFilter = NULL;
					ofn.nMaxCustFilter = 0;
					ofn.lpstrFileTitle = strngs[12];//TEXT("Please Select a File");
					ofn.nMaxFileTitle = 0;
					ofn.nFileOffset = 0;
					ofn.nFileExtension = 0;
					ofn.lpstrDefExt = NULL;
					ofn.lCustData = 0;
					ofn.lpfnHook = 0;
					ofn.lpTemplateName = 0;
					ofn.Flags = OFN_PATHMUSTEXIST | OFN_FILEMUSTEXIST | OFN_HIDEREADONLY |OFN_EXTENSIONDIFFERENT;
					if(GetOpenFileName(&ofn))
					{	if(FillSptlFilesInfo(hDlg,s))
							SetDlgItemText(hDlg,IDC_EDIT_SRC,s);
					}
					return (INT_PTR)TRUE;
				case IDOK:
					left=(int)SendMessage(GetDlgItem(hDlg,IDC_COMBO_EARCH_PART_SIZE),CB_GETCURSEL,0,0);
					SendMessageW(GetDlgItem(hDlg,IDC_COMBO_EARCH_PART_SIZE),CB_GETLBTEXT,left,(LPARAM)s);
					szFile = _wtoi(s);
					for(top=0; top<left; top++)
						szFile *= 1024;
					GetDlgItemText(hDlg,IDC_EDIT_SRC,s,MAX_PATH-1);
					GetDlgItemText(hDlg,IDC_EDIT_DEST,ss,MAX_PATH-1);
					if(AppendFiles(hDlg))
					{	if(BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_DELETE),BM_GETCHECK,0,0))
							DeleteSplitFiles(hDlg);
						EndDialog(hDlg, 1);
					}
					return (INT_PTR)TRUE;
				case IDCANCEL:
					EndDialog(hDlg, 0);
					return (INT_PTR)TRUE;
				case IDSTOP:
					bStop = !bStop;
					SetDlgItemText(hDlg,IDSTOP,bStop?strngs[8]:strngs[15]);
					break;
				case IDC_EDIT_SRC:
					if(EN_KILLFOCUS==HIWORD(wParam))
					{	GetDlgItemText(hDlg,IDC_EDIT_SRC,s,MAX_PATH-1);
						if(!FillSptlFilesInfo(hDlg,s))
						{	MessageBox(hDlg,s,strngs[18],MB_ICONWARNING);
							SendMessage(hDlg,WM_COMMAND,MAKELONG(IDC_BUTTON_BROWSE2,BN_CLICKED),(LPARAM)GetDlgItem(hDlg,IDC_BUTTON_BROWSE2));
					}	}
					break;
				case IDC_COMBO_DEST_PANEL:
					if(CBN_SELCHANGE==HIWORD(wParam))
					{	int l=(int)SendMessage(GetDlgItem(hDlg,IDC_COMBO_DEST_PANEL),CB_GETCURSEL,0,0);
						if(l>-1 && l<4)
						{	wchar_t *s=getPanelPath(l);
							if(s)
							{	ps=wcsrchr(s,'\\');
								if(ps) *(ps+1) = 0;
								SetDlgItemText(hDlg,IDC_EDIT_DEST,s);
					}	}	}
					break;
			}
			break;
	}
	return (INT_PTR)FALSE;
}

DWORD GetCheckSum(HWND dlg,HANDLE h,/*char *fName,*/unsigned __int64 *sz)
{
//unsigned __int64 sz;
//DWORD *psz,
DWORD rd,buf[1024],crc=0;

	SetDlgItemText(dlg,IDC_STATIC6,strngs[11]);

	//HANDLE h=CreateFile(fName,GENERIC_READ,FILE_SHARE_READ,0,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);
	//if(INVALID_HANDLE_VALUE==h) return 0;
	//psz = (DWORD*)&sz;
	//(*psz)=GetFileSize(h,psz+1);
	//if(0==(*(psz+1)))
	//if(((DWORD)-1)==(*psz))
	//	return 0;
	//sz>>=2;//DWORD sz;
	while(1)//for(int i=0; i<500; i++)
	{	DWORD k,rdtail;
		if(!ReadFile(h,buf,4096,&rd,NULL)) break;
		if(0==rd) break;

		rdtail=rd & 0x00000003;
		rd >>= 2;

		for(k=0; k<rd; k++)
			crc ^= buf[k];
		switch(rdtail)
		{	case 0:
				break;
			case 1:
				rdtail = *((BYTE*)&buf[k]);
				break;
			case 2:
				rdtail = *((BYTE*)&buf[k]) << 8  |  *(((BYTE*)&buf[k])+1);
				break;
			case 3:
				rdtail = *((BYTE*)&buf[k]) << 16  |  *(((BYTE*)&buf[k])+1) << 8  |   *(((BYTE*)&buf[k])+2);
				break;
		}crc ^= rdtail;

		SendMessage(GetDlgItem(dlg,IDC_PROGRESS_SPLIT),PBM_SETPOS,(WPARAM)(100*rd/(*sz)),0);
		while(CheckStopBtnMsg(dlg))
			Sleep(25);
	}
	//CloseHandle(h);
	//*szOut = sz;
	return crc;
}

/* Struct of split file:
	orgnl name[...] <null>    ... byte
	split name[...] <null>    ... byte
	orgnl size					8 byte (unsigned __int64)
	this split file size		8 byte (unsigned __int64)
	orgnl file crc			    4 byte (dword)
	this split file crc			4 byte (dword)
*/

BOOL AppendFiles(HWND dlg)
{
wchar_t spltName[MAX_PATH],dst[MAX_PATH],CBTxt[MAX_PATH],*ps,*pps,*p;
int  ln,spltNum;
unsigned __int64 iWrtd,iSpltReaded,spltOrgSz[2],spltSz;
DWORD buf[1024],rd,crc,spltCrc,orgCrcInSplt[2],crcInSplt;
HANDLE hSplt,hDst;
WIN32_FIND_DATA ff;

//1.Check dest directory:
	ln=GetDlgItemTextW(dlg,IDC_EDIT_DEST,dst,MAX_PATH-1);
	if('\\'==dst[ln-1]){dst[--ln]=0;}
	hDst = MyFindFirstFileEx(dst,FindExInfoStandard,&ff,FindExSearchLimitToDirectories,NULL,0);
	if(INVALID_HANDLE_VALUE==hDst)
		{MessageBoxW(dlg,dst,strngs[20],MB_ICONWARNING);return FALSE;}
	FindClose(hDst);
	if(!(FILE_ATTRIBUTE_DIRECTORY & ff.dwFileAttributes))
		{MessageBoxW(dlg,dst,strngs[20],MB_ICONWARNING);return FALSE;}
	if('\\'!=dst[ln-1]){dst[ln++]='\\';dst[ln]=0;}

//2.Open 1-st split file:
	GetDlgItemText(dlg,IDC_EDIT_SRC,spltName,MAX_PATH-1);
	hSplt=CreateFile(spltName,GENERIC_READ,FILE_SHARE_READ,0,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);
	if(INVALID_HANDLE_VALUE==hSplt)
		{MessageBox(dlg,spltName,strngs[13],MB_ICONWARNING);return FALSE;}

//3.Prepare splt dir path:
	ps=wcsrchr(spltName,'\\');
	if(!ps) ps=&spltName[0];
	else ++ps;

//4.Read original name from 1-st split file:
	ReadFile(hSplt,buf,MAX_PATH,&rd,NULL);
	if(!rd) {MessageBox(dlg,spltName,strngs[21],MB_ICONWARNING);CloseHandle(hSplt);return FALSE;}
	MyStringCat(dst,MAX_PATH-1,(wchar_t*)buf);//dest ready!!!

//5.Close 1-st splt:
	CloseHandle(hSplt);

//6. Check dest exist:
	hDst=MyFindFirstFileEx(dst,FindExInfoStandard,&ff,FindExSearchLimitToDirectories,NULL,0);
	if(INVALID_HANDLE_VALUE!=hDst)
	if(!(FILE_ATTRIBUTE_DIRECTORY & ff.dwFileAttributes))
	if(IDNO==MessageBox(dlg,strngs[28],dst,MB_YESNO))
	{	FindClose(hDst);
		return FALSE;
	}
	FindClose(hDst);

//7.Open destination:
	hDst=CreateFile(dst,GENERIC_WRITE,FILE_SHARE_WRITE,0,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,NULL);
	if(INVALID_HANDLE_VALUE==hDst)
		{MessageBox(dlg,dst,strngs[22],MB_ICONWARNING);return FALSE;}

	spltOrgSz[0]=0;
	orgCrcInSplt[0]=0;
	spltNum=0;
	iWrtd=0;
	crc=0;

NextSpltFile:

	SendMessage(GetDlgItem(dlg,IDC_COMBO_EARCH_PART_SIZE),CB_GETLBTEXT,spltNum,(LPARAM)CBTxt);
	
	//probeldan uyog'ini olib tashlaymiz, hajmini;
	p=wcschr(CBTxt,' ');
	if(p)*p=0;

	pps=ps;p=&CBTxt[0];
	do
	{	*pps=*p;
		++pps;++p;
	} while(*p);
	hSplt=CreateFile(spltName,GENERIC_READ,FILE_SHARE_READ,0,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);
	if(INVALID_HANDLE_VALUE==hSplt)
		{MessageBox(dlg,spltName,strngs[13],MB_ICONWARNING);CloseHandle(hDst);return FALSE;}

	ReadFile(hSplt,buf,MAX_PATH,&rd,NULL);
	if(!rd) {MessageBox(dlg,spltName,strngs[21],MB_ICONWARNING);CloseHandle(hSplt);CloseHandle(hDst);return FALSE;}

	//splt header:
	ln=MyStringLength((wchar_t*)buf,MAX_PATH)+1;//fileNameLn+spltFileNameLn+2+2*sizeof(__int64)+2*sizeof(__int32);
	ln+=MyStringLength(((wchar_t*)buf)+ln,MAX_PATH)+1;
	SetFilePointer(hSplt,sizeof(wchar_t)*ln,0,FILE_BEGIN);
	ReadFile(hSplt,&spltOrgSz[1],sizeof(__int64),&rd,NULL);
	if(rd!=sizeof(__int64)) {MessageBox(dlg,spltName,strngs[23],MB_ICONWARNING);CloseHandle(hSplt);CloseHandle(hDst);return FALSE;}
	if(!spltOrgSz[0])spltOrgSz[0]=spltOrgSz[1];
	else if(spltOrgSz[0]!=spltOrgSz[1])
		{MessageBox(dlg,spltName,strngs[24],MB_ICONWARNING);CloseHandle(hSplt);CloseHandle(hDst);return FALSE;}
	ReadFile(hSplt,&spltSz,sizeof(__int64),&rd,NULL);
	if(rd!=sizeof(__int64)) {MessageBox(dlg,spltName,strngs[25],MB_ICONWARNING);CloseHandle(hSplt);CloseHandle(hDst);return FALSE;}
	ReadFile(hSplt,&orgCrcInSplt[1],sizeof(DWORD),&rd,NULL);
	if(rd!=sizeof(DWORD)) {MessageBox(dlg,spltName,strngs[26],MB_ICONWARNING);CloseHandle(hSplt);CloseHandle(hDst);return FALSE;}
	if(!orgCrcInSplt[0])orgCrcInSplt[0]=orgCrcInSplt[1];
	else if(orgCrcInSplt[0]!=orgCrcInSplt[1])
		{MessageBox(dlg,spltName,strngs[29],MB_ICONWARNING);CloseHandle(hSplt);CloseHandle(hDst);return FALSE;}
	ReadFile(hSplt,&crcInSplt,sizeof(DWORD),&rd,NULL);
	if(rd!=sizeof(DWORD)) {MessageBox(dlg,spltName,strngs[27],MB_ICONWARNING);CloseHandle(hSplt);CloseHandle(hDst);return FALSE;}

	spltCrc = 0;
	iSpltReaded = 0;

	while(1)
	{	DWORD k,rdtail,r=4096;//(DWORD)(spltSz-iSpltReaded>4096?4096:(spltSz-iSpltReaded));
		if(!ReadFile(hSplt,buf,r,&rd,NULL)) break;
		if(0==rd) break;
		r=rd;
		iSpltReaded+=rd;
		rdtail=rd & 0x00000003;
		rd >>= 2;
		for(k=0; k<rd; k++)
		{	spltCrc ^= buf[k];
			crc ^= buf[k];
		}
		switch(rdtail)
		{	case 0:
				break;
			case 1:
				rdtail = *((BYTE*)&buf[k]);
				break;
			case 2:
				rdtail = *((BYTE*)&buf[k]) << 8  |  *(((BYTE*)&buf[k])+1);
				break;
			case 3:
				rdtail = *((BYTE*)&buf[k]) << 16  |  *(((BYTE*)&buf[k])+1) << 8  |   *(((BYTE*)&buf[k])+2);
				break;
		}
		spltCrc ^= rdtail;
		crc ^= rdtail;
		
		WriteFile(hDst,buf,r,&rd,NULL);
		SendMessage(GetDlgItem(dlg,IDC_PROGRESS_SPLIT),PBM_SETPOS,(WPARAM)(100*(iSpltReaded+iWrtd)/spltOrgSz[0]),0);
		while(CheckStopBtnMsg(dlg))
			Sleep(25);
	}
	
	CloseHandle(hSplt);

	//Checksum:
	if(spltCrc != crcInSplt)
	{	MessageBox(dlg,spltName,strngs[30],MB_ICONASTERISK);
		CloseHandle(hDst);
		return FALSE;
	}

	iWrtd += iSpltReaded;
	++spltNum;
	if(iWrtd<spltOrgSz[0])
		goto NextSpltFile;

	CloseHandle(hDst);

	//Total checksum:
	if(crc != orgCrcInSplt[0])
	{	MessageBox(dlg,spltName,strngs[31],MB_ICONASTERISK);
		return FALSE;
	}
	return TRUE;
}

BOOL DeleteSplitFiles(HWND dlg)
{
wchar_t spltName[MAX_PATH],*ps,*pps;
int  cbCnt,i;

	GetDlgItemText(dlg,IDC_EDIT_SRC,spltName,MAX_PATH-1);
	ps=wcsrchr(spltName,'\\');
	if(!ps) ps=&spltName[0];
	else ++ps;

	cbCnt = (int)SendMessage(GetDlgItem(dlg,IDC_COMBO_EARCH_PART_SIZE),CB_GETCOUNT,0,0);
	for(i=0; i<cbCnt; i++)
	{	SendMessage(GetDlgItem(dlg,IDC_COMBO_EARCH_PART_SIZE),CB_GETLBTEXT,i,(LPARAM)ps);
		pps=wcsrchr(ps+1,' ');
		if(pps) *pps=0;
		DeleteFile(spltName);
	}
	return TRUE;
}

BOOL CheckStopBtnMsg(HWND dlg)
{
MSG msg;
	while(PeekMessage(&msg,dlg,0,0,PM_REMOVE))
		DispatchMessage(&msg);	
	return bStop;
}

BOOL CheckIsSplitFile(wchar_t* srcFilePathAndName,wchar_t* fileName)
{
int ln;
unsigned __int64 sz,szCrnt;
wchar_t st[MAX_PATH],nmbf[MAX_PATH],*p;
HANDLE h;
DWORD rd,*psz;
	MyStringCpy(st,MAX_PATH-1,srcFilePathAndName);
	p=wcsrchr(st,'\\');
	if(p) *(p+1)=0;
	ln=MyStringLength(st,MAX_PATH-1);
	st[ln-1]='\\';
	MyStringCpy(&st[ln],MAX_PATH-ln-1,fileName);
	h=CreateFile(st,GENERIC_READ,FILE_SHARE_READ,0,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);
	if(INVALID_HANDLE_VALUE==h) return FALSE;

	ReadFile(h,nmbf,MAX_PATH-1,&rd,NULL);
	if(!rd) {CloseHandle(h);return FALSE;}
	ln=MyStringLength(nmbf,MAX_PATH-1);
	if(wcscmp(fileName,&nmbf[ln+1])) {CloseHandle(h);return FALSE;}
	ln+=MyStringLength(&nmbf[ln+1],MAX_PATH-1);

	psz = (DWORD*)&sz;
	(*psz)=GetFileSize(h,psz+1);
	if(0==(*(psz+1)))
	if(((DWORD)-1)==(*psz)) {CloseHandle(h);return FALSE;}

	SetFilePointer(h,sizeof(wchar_t)*(ln+2)+sizeof(__int64),0,FILE_BEGIN);//+2*sizeof(DWORD)+
	ReadFile(h,&szCrnt,sizeof(__int64),&rd,NULL);
	CloseHandle(h);

	if(sizeof(__int64)!=rd) return FALSE;
	if(sz-szCrnt!=sizeof(wchar_t)*(ln+2)+2*sizeof(__int64)+2*sizeof(DWORD)) return FALSE;

	return TRUE;
}

BOOL FillSptlFilesInfo(HWND hDlg,wchar_t *frstSpltFilePathAndName)
{
int nameLn;
WIN32_FIND_DATA ff;
HANDLE hf = INVALID_HANDLE_VALUE;
wchar_t *ps,rootName[MAX_PATH],st[MAX_PATH];//without ext and only name(with ext);

	hf = MyFindFirstFileEx(frstSpltFilePathAndName,FindExInfoStandard,&ff,FindExSearchLimitToDirectories,NULL,0);
	if(INVALID_HANDLE_VALUE==hf) return FALSE;
	FindClose(hf);

	if(!CheckIsSplitFile(frstSpltFilePathAndName,ff.cFileName))
	{	MessageBox(hDlg,strngs[13],ff.cFileName,MB_ICONASTERISK);
		return FALSE;
	}

	SendMessage(GetDlgItem(hDlg,IDC_COMBO_EARCH_PART_SIZE),CB_RESETCONTENT,0,0);
	ps = wcschr(ff.cFileName,'\\');//'.' niyam kiritish kerakmi???
	if(!ps)ps=&ff.cFileName[0];
	StringCchPrintf(st,MAX_PATH-1,L"%s %d",ps,((unsigned __int64)ff.nFileSizeHigh<<32) | ff.nFileSizeLow);
	SendMessage(GetDlgItem(hDlg,IDC_COMBO_EARCH_PART_SIZE),CB_ADDSTRING,0,(LPARAM)st);

	ps = wcsrchr(frstSpltFilePathAndName,'\\');
	if(ps) MyStringCpy(rootName,MAX_PATH-1,ps+1);
	else MyStringCpy(rootName,MAX_PATH-1,frstSpltFilePathAndName);

	ps = wcsrchr(rootName,'.');
	if(ps) *ps=0;

	nameLn=MyStringLength(rootName,MAX_PATH-1);
	for(ps = &rootName[0]+nameLn-1; (*ps) >= '0' && (*ps) <= '9'; ps--);
	*(ps+1)=0;
	nameLn=(int)(ps-&rootName[0]+1);

	//find file ni qaytadan to'grilab olamiz:
	ps = wcsrchr(frstSpltFilePathAndName,'\\');
	if(ps)
	{	wchar_t st=*(ps+1),st1=*(ps+2); *(ps+1)='*'; *(ps+2)=0;
		hf = MyFindFirstFileEx(frstSpltFilePathAndName,FindExInfoStandard,&ff,FindExSearchLimitToDirectories,NULL,0);
		*(ps+1)=st;*(ps+2)=st1;
	}
	else hf = MyFindFirstFileEx(frstSpltFilePathAndName,FindExInfoStandard,&ff,FindExSearchLimitToDirectories,NULL,0);
	
	while(FindNextFile(hf, &ff))
	{	if(!(FILE_ATTRIBUTE_DIRECTORY & ff.dwFileAttributes))
		{	if(wcsstr(frstSpltFilePathAndName,ff.cFileName)) continue;//1-st file;
			if(wcsstr(ff.cFileName,rootName))
			{	if(!CheckIsSplitFile(frstSpltFilePathAndName,ff.cFileName))
				{	MessageBox(hDlg,strngs[13],ff.cFileName,MB_ICONASTERISK);
					continue;
				}
				StringCchPrintf(st,MAX_PATH-1,L"%s %d",ff.cFileName,((unsigned __int64)ff.nFileSizeHigh<<32) | ff.nFileSizeLow);
				SendMessage(GetDlgItem(hDlg,IDC_COMBO_EARCH_PART_SIZE),CB_ADDSTRING,0,(LPARAM)st);
	}	}	}

	FindClose(hf);		
	SendMessage(GetDlgItem(hDlg,IDC_COMBO_EARCH_PART_SIZE),CB_SETCURSEL,0,0);
	return TRUE;
}