#pragma warning(disable:4995)

#define _CRT_SECURE_NO_WARNINGS

#include "windows.h"
//#include "resource.h"
#include "stdio.h"
#include "strsafe.h"



#define MAX_STRINGS 33



wchar_t **strngs=NULL;
HMODULE plgnDllInst;

BOOL APIENTRY DllMain(HMODULE hModule,DWORD ul_reason_for_call,LPVOID lpReserved)
{
FILE *f;
int i,l;
wchar_t *pend;
wchar_t dllname[260],mnuStr[64];
	switch(ul_reason_for_call)
	{	case DLL_PROCESS_ATTACH:
			plgnDllInst=hModule;
			if(strngs)break;
			//GetModuleFileNameW(NULL,dllname,260);
			//pend = wcsrchr(dllname,'\\');
			//if(pend)
			//{	*pend=0;
			//	SetCurrentDirectory(dllname);
			//}

			strngs = (wchar_t **)malloc(MAX_STRINGS*sizeof(wchar_t*));
			GetModuleFileNameW(hModule,dllname,260);
			//LoadNTFuncs();

			pend = wcsrchr(dllname,'\\');
			if(pend){*pend++='\\';*pend=0;}

			if(GetEnvironmentVariable(L"languge",mnuStr,64))//Language instartup qo'yadur;
			{	if(!wcscmp(mnuStr,L"russian"))
					wcscat(dllname,L"PlugApndStrsRus.txt");
				else if(!wcscmp(mnuStr,L"uzbekl"))
					wcscat(dllname,L"PlugApndStrsUZBL.txt");
				else if(!wcscmp(mnuStr,L"uzbekk"))
					wcscat(dllname,L"PlugApndStrsUZBK.txt");
				else//if(wcscmp(mnuStr,L"Exit")
					wcscat(dllname,L"PlugApndStrsEng.txt");
			}	
			else wcscat(dllname,L"PlugApndStrsEng.txt");

			f=_wfopen(dllname,L"r,ccs=UNICODE");
			if(f)
			{	wchar_t s[260];fwscanf(f,L"%s", s);
				if(wcscmp(s,L"Plugin")) goto NillStr;
				fwscanf(f,L"%s", s);
				if(wcscmp(s,L"fileappend.dll")) goto NillStr;
				fwscanf(f,L"%s", s);
				if(wcscmp(s,L"Strings:")) goto NillStr;
				for(i=0; i<MAX_STRINGS; i++)
				{	int t;fwscanf_s(f,L"%d", &t);
					if(t-1!=i) goto NillStr;
					l=fscanLineString(f,256,s);
					strngs[i]=(wchar_t*)malloc(sizeof(wchar_t)*(l+1));
					memcpy(strngs[i],s,sizeof(wchar_t)*(l+1));
				}
				fclose(f);
			}
			else
			{int l;
NillStr:
				l=(int)wcslen(L"Build from splitted files")+1;
					strngs[0]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[0],l,L"Build from splitted files");
				l=(int)wcslen(L"File builder from splitted files")+1;
					strngs[1]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[1],l,L"File builder from splitted files");
				l=(int)wcslen(L"File")+1;//strngs[2] bo'sh
					strngs[2]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[2],l,L"File");
				l=(int)wcslen(L"Source files")+1;
					strngs[3]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[3],l,L"Source files");
				l=(int)wcslen(L"Destination")+1;
					strngs[4]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[4],l,L"Destination");
				l=(int)wcslen(L"Build")+1;
					strngs[5]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[5],l,L"Build");
				l=(int)wcslen(L"Stop")+1;
					strngs[6]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[6],l,L"Stop");
				l=(int)wcslen(L"Cancel")+1;
					strngs[7]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[7],l,L"Cancel");
				l=(int)wcslen(L"Browse")+1;
					strngs[8]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[8],l,L"Browse");
				l=(int)wcslen(L"Calculating file cheksum...")+1;//9 - empty
					strngs[9]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[9],l,L"Calculating file cheksum...");
				l=(int)wcslen(L"Please Select a File")+1;//10- empty
					strngs[10]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[10],l,L"Please Select a File");					
				l=(int)wcslen(L"Error opening source file")+1;
					strngs[11]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[11],l,L"Error opening source file");					
				l=(int)wcslen(L"Checksum error of source file")+1;
					strngs[12]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[12],l,L"Checksum error of source file");					
				l=(int)wcslen(L"Error opening split file")+1;
					strngs[13]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[13],l,L"Error opening split file");					
				l=(int)wcslen(L"Appending file ...")+1;//14 - empty
					strngs[14]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[14],l,L"Appending file ...");
				l=(int)wcslen(L"Stop")+1;
					strngs[15]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[15],l,L"Stop");
				l=(int)wcslen(L"Browse for build directory ...")+1;
					strngs[16]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[16],l,L"Browse for build directory ...");
				l=(int)wcslen(L"Search for split files:")+1;
					strngs[17]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[17],l,L"Search for split files:");
				l=(int)wcslen(L"This is not splitted file")+1;
					strngs[18]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[18],l,L"This is not splitted file");
				l=(int)wcslen(L"Splitted files and sizes:")+1;
					strngs[19]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[19],l,L"Splitted files and sizes:");
				l=(int)wcslen(L"Destination path is invalid")+1;
					strngs[20]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[20],l,L"Destination path is invalid");
				l=(int)wcslen(L"Error reading original file name from 1-st split file")+1;
					strngs[21]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[21],l,L"Error reading original file name from 1-st split file");
				l=(int)wcslen(L"Error creating destination file")+1;
					strngs[22]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[22],l,L"Error creating destination file");
				l=(int)wcslen(L"Original size error in split file")+1;
					strngs[23]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[23],l,L"Original size error in split file");
				l=(int)wcslen(L"Original size mismatch with prior split file")+1;
					strngs[24]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[24],l,L"Original size mismatch with prior split file");
				l=(int)wcslen(L"Split size read error")+1;
					strngs[25]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[25],l,L"Split size read error");
				l=(int)wcslen(L"Original crc read error from split file")+1;
					strngs[26]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[26],l,L"Original crc read error from split file");
				l=(int)wcslen(L"Split crc read error")+1;
					strngs[27]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[27],l,L"Split crc read error");
				l=(int)wcslen(L"Destination file already exist, overwrite?")+1;
					strngs[28]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[28],l,L"Destination file already exist, overwrite?");
				l=(int)wcslen(L"Original crc mismatch with prior split file")+1;
					strngs[29]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[29],l,L"Original crc mismatch with prior split file");
				l=(int)wcslen(L"Split file crc check error")+1;
					strngs[30]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[30],l,L"Split file crc check error");
				l=(int)wcslen(L"Build file crc check error")+1;
					strngs[31]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[31],l,L"Build file crc check error");
				l=(int)wcslen(L"Delete sources")+1;
					strngs[32]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[32],l,L"Delete sources");
			}
			break;
		case DLL_THREAD_ATTACH:
			break;
		case DLL_THREAD_DETACH:
			break;
		case DLL_PROCESS_DETACH:
			if(strngs)
			{	for(i=0; i<MAX_STRINGS; i++)
					free(strngs[i]);
				free(strngs);
				//saveOptCpp();
				strngs=NULL;
			}
			break;
	}
	return TRUE;
}