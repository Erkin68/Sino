//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by FileSplit.rc
//
#define IDSTOP                          3
#define IDOK2                           4
#define IDD_DIALOG_SPLIT                101
#define IDC_EDIT_SRC                    102
#define IDC_EDIT_DEST                   103
#define IDC_BUTTON_BROWSE               104
#define IDC_EDIT_SIZE                   105
#define IDC_SPIN_SIZE                   106
#define IDC_COMBO_SIZE_QUANTITY         107
#define IDC_PROGRESS_SPLIT              108
#define IDC_COMBO_SIZE_QUANTITY2        109
#define IDC_COMBO_SIZE_QUANTITY3        110
#define IDC_COMBO_DEST_PANEL            110
#define IDC_STATIC1                     21570
#define IDC_STATIC2                     21571
#define IDC_STATIC3                     21572
#define IDC_BUTTON_BROWSE2              114
#define IDC_STATIC4                     21574
#define IDC_STATIC5                     21573
#define IDC_STATIC6                     21575

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        114
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1013
#define _APS_NEXT_SYMED_VALUE           115
#endif
#endif
