#include "windows.h"
#include "resource.h"
#include "strsafe.h"
#include "shlobj.h"
#include "..\..\..\..\Operations\MyShell\MyShellC.h"



extern wchar_t **strngs;
extern HMODULE plgnDllInst;

INT_PTR CALLBACK SpltDlgProc(HWND,UINT,WPARAM,LPARAM);
int SplitFile(HWND,wchar_t*,wchar_t*,__int64);
BOOL CheckStopBtnMsg(HWND);

typedef BOOL (CALLBACK *saveOptions_t)(int,VOID*,int);
typedef BOOL (CALLBACK *readOptions_t)(int,VOID*,int);
typedef int  (CALLBACK *getTotPanels_t)();
typedef int  (CALLBACK *getCrntPanelNum_t)();
typedef wchar_t* (CALLBACK *getPanelPath_t)(int);
typedef LPVOID (CALLBACK *getPanelCrntItem_t)(int,WIN32_FIND_DATA*);
typedef LPVOID (CALLBACK *getPanelSelectedItems_t)(int,int*);
typedef unsigned __int64* (CALLBACK *getLogicalDriveSpace_t)(int);


saveOptions_t saveOptions=0;
readOptions_t readOptions=0;
getTotPanels_t getTotPanels=0;
getCrntPanelNum_t getCrntPanelNum=0;
getPanelCrntItem_t getPanelCrntItem=0;
getPanelSelectedItems_t getPanelSelectedItems=0;
getPanelPath_t getPanelPath=0;
getLogicalDriveSpace_t getLogicalDriveSpace=0;

int plgId = 0;
BOOL bStop=FALSE;
WIN32_FIND_DATA pFindFileData;

__declspec (dllexport) VOID SetCallbacks$4xxx(LPVOID frstCallback,...)
{
va_list args;
	va_start(args, frstCallback);//1
	saveOptions = (saveOptions_t)frstCallback;//1
	readOptions = (readOptions_t)va_arg(args, LPVOID);//2
	getTotPanels = (getTotPanels_t)va_arg(args, LPVOID);//3
	getCrntPanelNum = (getCrntPanelNum_t)va_arg(args, LPVOID);//4
	getPanelCrntItem = (getPanelCrntItem_t)va_arg(args, LPVOID);//5
	getPanelSelectedItems = (getPanelSelectedItems_t)va_arg(args, LPVOID);//6
	getPanelPath = (getPanelPath_t)va_arg(args, LPVOID);//7
	getLogicalDriveSpace = (getLogicalDriveSpace_t)va_arg(args, LPVOID);//8
va_end (args);
}

__declspec (dllexport) BOOL Run$4(HWND prnt)
{
int ttlPnl,crntPnl;
	if(!getCrntPanelNum) return FALSE;
	if(!getTotPanels)return FALSE;
	ttlPnl=getTotPanels();
	crntPnl=getCrntPanelNum();
	if(ttlPnl<0) return FALSE;
	if(ttlPnl>3) return FALSE;
	if(crntPnl<0) return FALSE;
	if(crntPnl>ttlPnl-1) return FALSE;
	if(!getPanelCrntItem) return FALSE;
	DialogBox(plgnDllInst,MAKEINTRESOURCE(IDD_DIALOG_SPLIT),prnt,SpltDlgProc);
	return TRUE;
}

__declspec (dllexport) int GetPluginType()
{
	return 102;
}

__declspec (dllexport) const wchar_t* GetPluginName()
{
	return strngs[1];
}

__declspec (dllexport) int GetMenuNum()
{
	return 0;
}

__declspec (dllexport) int GetMenuPos()
{
	return 3;
}

__declspec (dllexport) const wchar_t* GetMenuItemText()
{
	return strngs[0];
}

__declspec (dllexport) const wchar_t* GetMenuText()
{
	return strngs[0];
}

__declspec (dllexport) VOID SetId$4(int id)
{
	plgId = id;
}

__declspec (dllexport) const wchar_t* GetPluginDescription()
{
	return strngs[1];
}

__declspec (dllexport) VOID ShowOptionDialog(HWND prnt)
{
}

BOOL IsCrntOrPrntDirAttrbW(wchar_t* fd)
{//see Naming Conventions in MSDN:
	if('.'==fd[0])
	{	if('\0'==fd[1])//"."
			return FALSE;
		if('.'==fd[1])
			if('\0'==fd[2])//".."
				return FALSE;
	}
	return TRUE;//Hozircha;
}

unsigned __int64 MyAtoU64(wchar_t *s)
{
unsigned __int64 rt=0;
wchar_t *ps = s;
	while(*ps!=0)
	{	if(*ps < '0')
			return 0;
		if(*ps > '9')
			return 0;
		rt = rt*10 + (*ps - '0');
		ps++;
	}
	return rt;
}

BOOL MyU64ToA(wchar_t* st,int sLen,unsigned __int64 u)
{
int i,l=0;
unsigned __int64 delit = u;
static wchar_t s[32];
	if(!u)
	{	st[0] = '0';
		st[1] = 0;
		return TRUE;
	}

	while(delit)
	{	s[l++] = delit % 10 + '0';
		delit /= 10;
	}
	for(i=0; i<l; i++)
		st[i] = s[l-i-1];
	st[l] = 0;
	return TRUE;
}

INT_PTR CALLBACK SpltDlgProc(hDlg,message,wParam,lParam)
HWND hDlg;
UINT message;
WPARAM wParam;
LPARAM lParam;
{	//static int i=0;
	//char ss[32];sprintf(ss,"\n %d ",i++);
	//OutputDebugString(ss);
	//OutputDebugString(GetWinNotifyText(message));
	//sprintf(ss," %x %x",wParam,lParam);
	//OutputDebugString(ss);

static HFONT hf=0;
//static int hfRef=0;//obshiy hf, dinamik uchun emas:
static HBRUSH br=0;
//static LPVOID panel;
static HBRUSH brHtBk=0;
static int endDialogCodeToWM_DESTROY;
static int szQntSlct=0;
wchar_t s[MAX_PATH],ss[MAX_PATH],*ps;
__int64 szFile;
int left,top,width,height,nxtPnlNum=-1;
//LPDRAWITEMSTRUCT lpdis;
LPITEMIDLIST pidlRoot,pidlSelected;
BROWSEINFO bi;
OPENFILENAME ofn;
LOGFONT fnt;
RECT rc,rc1;
//UINT uStyle;
HDC dc;HWND prnt;

	switch(message)
	{	case WM_INITDIALOG:
			GetWindowRect(hDlg, &rc1);
			prnt = GetParent(hDlg);
			if(!prnt)prnt=GetDesktopWindow();
			GetWindowRect(prnt, &rc);
			width = rc1.right - rc1.left;		
			left = rc.left + (rc.right - rc.left - width)/2;//left = (GetSystemMetrics(SM_CXFULLSCREEN) - width)/2;
			height = rc1.bottom - rc1.top;
			top = rc.top + (rc.bottom - rc.top - height)/2;//top = (GetSystemMetrics(SM_CYFULLSCREEN) - height)/2;
			MoveWindow(hDlg, left, top+20, width, height, TRUE);

			//Load language strings:
			SetWindowText(hDlg,strngs[0]);
			SetDlgItemText(hDlg,IDC_STATIC5,strngs[3]);
			SetDlgItemText(hDlg,IDC_STATIC1,strngs[4]);
			SetDlgItemText(hDlg,IDC_STATIC2,strngs[5]);
			SetDlgItemText(hDlg,IDC_STATIC3,strngs[6]);
			//SetDlgItemText(hDlg,IDC_STATIC4,strngs[11]); strng[11] bo'sh
			SetDlgItemText(hDlg,IDOK,strngs[7]);
			SetDlgItemText(hDlg,IDSTOP,strngs[8]);
			SetDlgItemText(hDlg,IDCANCEL,strngs[9]);
			SetDlgItemText(hDlg,IDC_BUTTON_BROWSE,strngs[10]);
			SetDlgItemText(hDlg,IDC_BUTTON_BROWSE2,strngs[10]);

			SendMessage(GetDlgItem(hDlg,IDC_COMBO_SIZE_QUANTITY),CB_ADDSTRING,0,(LPARAM)L"byte");
			SendMessage(GetDlgItem(hDlg,IDC_COMBO_SIZE_QUANTITY),CB_ADDSTRING,0,(LPARAM)L"kByte");
			SendMessage(GetDlgItem(hDlg,IDC_COMBO_SIZE_QUANTITY),CB_ADDSTRING,0,(LPARAM)L"mByte");
			SendMessage(GetDlgItem(hDlg,IDC_COMBO_SIZE_QUANTITY),CB_ADDSTRING,0,(LPARAM)L"gByte");
			SendMessage(GetDlgItem(hDlg,IDC_COMBO_SIZE_QUANTITY),CB_SETCURSEL,0,0);

			left=GetLogicalDriveStrings(MAX_PATH-1,s);
			height=0;
			for(ps=&s[0]; *ps;)
			{	int l;
				unsigned __int64 *freeBytesAvailable;//,totalNumberOfBytes,totalNumberOfFreeBytes;
				l=MyStringCpy(ss,127,ps);	
				top=GetDriveType(ps);
				switch(top)
				{	case DRIVE_REMOVABLE:
						l+=MyStringCpy(&ss[l],127-l,L" removable 1.44 mb");
						break;
					case DRIVE_FIXED:
						l+=MyStringCpy(&ss[l],127-l,L" fixed ");
						if(ps[0]>'a' && ps[0]<'w')
							freeBytesAvailable=getLogicalDriveSpace(ps[0]-'a');
						else
							freeBytesAvailable=getLogicalDriveSpace(ps[0]-'A');
						if(freeBytesAvailable)
							StringCchPrintf(&ss[l],127-l,L"%d b",*freeBytesAvailable);
						break;
					case DRIVE_REMOTE:
						l+=MyStringCpy(&ss[l],127-l,L" remote ");
						break;
					case DRIVE_CDROM:
						l+=MyStringCpy(&ss[l],127-l,L" cdrom ");
						if(ps[0]>'a' && ps[0]<'w')
							freeBytesAvailable=getLogicalDriveSpace(ps[0]-'a');
						else
							freeBytesAvailable=getLogicalDriveSpace(ps[0]-'A');
						if(freeBytesAvailable)
							StringCchPrintf(&ss[l],127-l,L"%d b",*freeBytesAvailable);
						else
							StringCchPrintf(&ss[l],127-l,L"720 mb");
						break;
					case DRIVE_RAMDISK:
						l+=MyStringCpy(&ss[l],127-l,L" ram disk ");
						if(ps[0]>'a' && ps[0]<'w')
							freeBytesAvailable=getLogicalDriveSpace(ps[0]-'a');
						else
							freeBytesAvailable=getLogicalDriveSpace(ps[0]-'A');
						if(freeBytesAvailable)
							StringCchPrintf(&ss[l],127-l,L"%d b",*freeBytesAvailable);
						break;
				}
				//GetDiskFreeSpace(ps,(PULARGE_INTEGER)&freeBytesAvailable,(PULARGE_INTEGER)&totalNumberOfBytes,(PULARGE_INTEGER)&totalNumberOfBytes,(PULARGE_INTEGER)&totalNumberOfFreeBytes);
				SendMessage(GetDlgItem(hDlg,IDC_COMBO_SIZE_QUANTITY2),CB_ADDSTRING,0,(LPARAM)ss);//"Floppy:1.44 mByte");
				width=MyStringLength(ps,MAX_PATH-1-height);
				height+=width+1;
				ps+=width+1;
			}

			if(getPanelCrntItem(getCrntPanelNum(),&pFindFileData))
			{	SetDlgItemText(hDlg,IDC_EDIT_SRC,pFindFileData.cFileName);

				StringCchPrintf(s,MAX_PATH-1,L"%d",((unsigned __int64)pFindFileData.nFileSizeHigh << 32) | pFindFileData.nFileSizeLow);
				SetDlgItemText(hDlg,IDC_EDIT_SIZE,s);

				nxtPnlNum = getTotPanels();
				if(nxtPnlNum>getCrntPanelNum()+1)
					nxtPnlNum=getCrntPanelNum()+1;
				else if(getCrntPanelNum()>0)
					nxtPnlNum=getCrntPanelNum()-1;
				if(nxtPnlNum>-1)
				{	WIN32_FIND_DATA ff;
					HANDLE hf = INVALID_HANDLE_VALUE;
					int l=MyStringCpy(s,MAX_PATH-1,getPanelPath(nxtPnlNum));
					hf = MyFindFirstFileEx(s,FindExInfoStandard,&ff,FindExSearchLimitToDirectories,NULL,0);
					if('*'==s[l-1] && '\\'==s[l-2]) s[l-1]=0;
					if(INVALID_HANDLE_VALUE==hf)
					{	GetCurrentDirectory(MAX_PATH,s);
						SetDlgItemText(hDlg,IDC_EDIT_DEST,s);
					}
					else
					{	FindClose(hf);
						if((FILE_ATTRIBUTE_DIRECTORY & ff.dwFileAttributes) && IsCrntOrPrntDirAttrbW(s))
							SetDlgItemText(hDlg,IDC_EDIT_DEST,s);
						else
						{	GetCurrentDirectory(MAX_PATH,s);
							SetDlgItemText(hDlg,IDC_EDIT_DEST,s);
				}	}	}
				left=getTotPanels();
				if(left>0 && left<5)
				{	for(top=0; top<left; top++)
					{	StringCchPrintf(s,MAX_PATH-1,L"%d-panel",top+1);
						SendMessage(GetDlgItem(hDlg,IDC_COMBO_DEST_PANEL),CB_INSERTSTRING,(WPARAM)-1,(LPARAM)s);
			}	}	}
			SendMessage(hDlg,WM_USER+1,0,0);
			break;
		case WM_CTLCOLORSTATIC:
		case WM_CTLCOLORDLG:dc = (HDC)wParam;
			SetTextColor(dc,RGB(0xea,0xe0,0xff));//SetTextColor(dc,RGB(0x8a,0,0));
			SetBkColor(dc,RGB(0x40,0x21,0x17));//SetBkColor(dc,RGB(0xc0,0x81,0x97));
			return (INT_PTR)br;
		case WM_CTLCOLOREDIT:dc = (HDC)wParam;
			SetTextColor(dc,RGB(0xea,0xe0,0xff));//SetTextColor(dc,RGB(0x8a,0,0));
			SetBkColor(dc,RGB(0x40,0x21,0x17));//SetBkColor(dc,RGB(0xc0,0x81,0x97));
			return (INT_PTR)br;
		case WM_CTLCOLORBTN:dc=(HDC)wParam;
			SetTextColor(dc,RGB(0xd0,0xe0,0xff));
			SetBkColor(dc,RGB(0x64,0x79,0x65));
			return (INT_PTR)brHtBk;
/*		case WM_DRAWITEM://WM_CTLCOLORBTN dagi knopkalar:
			lpdis = (LPDRAWITEMSTRUCT)lParam;
			GetWindowText(lpdis->hwndItem,s,MAX_PATH);
			uStyle = DFCS_BUTTONPUSH;
			rc = lpdis->rcItem;
			if(lpdis->itemState & ODS_SELECTED)
			{	uStyle |= DFCS_PUSHED|DFCS_TRANSPARENT;
				rc.left+=2;rc.top+=2;
			}
			DrawFrameControl(lpdis->hDC, &lpdis->rcItem, DFC_BUTTON, uStyle);
			if(lpdis->itemState & ODS_SELECTED)
				{rc.left+=1;rc.top+=1;rc.bottom-=2;rc.right-=3;}
			else
				{rc.left+=1;rc.top+=2;rc.bottom-=3;rc.right-=3;}
			FillRect(lpdis->hDC,&rc,brHtBk);//DrawText(lpdis->hDC,"",50,&rc,DT_SINGLELINE|DT_VCENTER|DT_INTERNAL|DT_LEFT);
			if(lpdis->itemState & ODS_SELECTED)
				{rc.left-=1;rc.top-=1;rc.bottom+=3;rc.right+=3;}
			else
				{rc.left-=1;rc.top-=2;rc.bottom+=2;rc.right+=3;}
			DrawText(lpdis->hDC,s,MyStringLength(s,MAX_PATH),&rc,DT_SINGLELINE|DT_VCENTER|DT_CENTER);
			return TRUE;*/
		case WM_USER+1://hf obshiy uchun, dinamik o'zgartirish uchun emas:
			//if(0==hfRef)
			{	InitLOGFONT(&fnt);
				hf = CreateFontIndirect(&fnt);
				br = CreateSolidBrush(RGB(0x40,0x21,0x17));//0xc9,0x81,0x93));
				brHtBk = CreateSolidBrush(RGB(0x64,0x79,0x65));
			}
			SendMessage(GetDlgItem(hDlg,IDC_BUTTON_BROWSE),WM_SETFONT,(WPARAM)hf,TRUE);
			SendMessage(GetDlgItem(hDlg,IDC_BUTTON_BROWSE2),WM_SETFONT,(WPARAM)hf,TRUE);
			SendMessage(GetDlgItem(hDlg,IDSTOP),WM_SETFONT,(WPARAM)hf,TRUE);
			SendMessage(GetDlgItem(hDlg,IDCANCEL),WM_SETFONT,(WPARAM)hf,TRUE);
			SendMessage(GetDlgItem(hDlg,IDOK),WM_SETFONT,(WPARAM)hf,TRUE);
			SendMessage(GetDlgItem(hDlg,IDCANCEL),WM_SETFONT,(WPARAM)hf,TRUE);
			SendMessage(GetDlgItem(hDlg,IDC_STATIC5),WM_SETFONT,(WPARAM)hf,TRUE);
			SendMessage(GetDlgItem(hDlg,IDC_STATIC1),WM_SETFONT,(WPARAM)hf,TRUE);
			SendMessage(GetDlgItem(hDlg,IDC_STATIC2),WM_SETFONT,(WPARAM)hf,TRUE);
			SendMessage(GetDlgItem(hDlg,IDC_STATIC3),WM_SETFONT,(WPARAM)hf,TRUE);
			SendMessage(GetDlgItem(hDlg,IDC_COMBO_SIZE_QUANTITY),WM_SETFONT,(WPARAM)hf,TRUE);
			SendMessage(GetDlgItem(hDlg,IDC_COMBO_SIZE_QUANTITY2),WM_SETFONT,(WPARAM)hf,TRUE);

			SendMessage(GetDlgItem(hDlg,IDC_EDIT_SRC),WM_SETFONT,(WPARAM)hf,TRUE);
			SendMessage(GetDlgItem(hDlg,IDC_EDIT_DEST),WM_SETFONT,(WPARAM)hf,TRUE);
			SendMessage(GetDlgItem(hDlg,IDC_EDIT_SIZE),WM_SETFONT,(WPARAM)hf,TRUE);
			SendMessage(GetDlgItem(hDlg,IDC_COMBO_DEST_PANEL),WM_SETFONT,(WPARAM)hf,TRUE);			
			//++hfRef;
			return 0;//GWL_USERDATA
		case WM_DESTROY:
			//if(--hfRef<1)
			{	DeleteObject(hf);
				DeleteObject(br);
				DeleteObject(brHtBk);
			}
			return 0;
		case WM_COMMAND:
			switch(LOWORD(wParam))
			{	case IDC_COMBO_SIZE_QUANTITY:
					if(CBN_SELCHANGE==HIWORD(wParam))
					{	int sz,iq=(int)SendMessage(GetDlgItem(hDlg,IDC_COMBO_SIZE_QUANTITY),CB_GETCURSEL,0,0);
						if(CB_ERR==iq)break;
						GetDlgItemText(hDlg,IDC_EDIT_SIZE,s,MAX_PATH);
						sz=_wtoi(s);
						switch(szQntSlct)
						{	case 0://byte;
								switch(iq)
								{	case 0://byte;
										break;
									case 1://kbyte;
										sz /= 1024;
										break;
									case 2://mbyte;
										sz /= 1024*1024;
										break;
									case 3://gbyte;
										sz /= 1024*1024*1024;
										break;
								}
								break;
							case 1://kbyte;
								switch(iq)
								{	case 0://byte;
										sz *= 1024;
										break;
									case 1://kbyte;
										break;
									case 2://mbyte;
										sz /= 1024;
										break;
									case 3://gbyte;
										sz /= 1024*1024;
										break;
								}
								break;
							case 2://mbyte;
								switch(iq)
								{	case 0://byte;
										sz *= 1024*1024;
										break;
									case 1://kbyte;
										sz *= 1024;
										break;
									case 2://mbyte;
										break;
									case 3://gbyte;
										sz /= 1024;
										break;
								}
								break;
							case 3://gbyte;
								switch(iq)
								{	case 0://byte;
										sz *= 1024*1024*1024;
										break;
									case 1://kbyte;
										sz *= 1024*1024;
										break;
									case 2://mbyte;
										sz *= 1024;
										break;
									case 3://gbyte;
										break;
								}
								break;
						}
						if(!sz)sz=1;
						StringCchPrintf(s,MAX_PATH-1,L"%d",sz);
						SetDlgItemText(hDlg,IDC_EDIT_SIZE,s);
						szQntSlct=iq;
					}
					break;
				case IDC_COMBO_SIZE_QUANTITY2:
					if(CBN_SELCHANGE==HIWORD(wParam))
					{	SendMessage(GetDlgItem(hDlg,IDC_COMBO_SIZE_QUANTITY2),CB_GETLBTEXT,
							(WPARAM)(SendMessage(GetDlgItem(hDlg,IDC_COMBO_SIZE_QUANTITY2),CB_GETCURSEL,0,0)),(LPARAM)s);
						ps = wcsrchr(s,' ');
						if(ps)
						{	switch(*(ps+1))
							{	case 'b':
									SendMessage(GetDlgItem(hDlg,IDC_COMBO_SIZE_QUANTITY),CB_SETCURSEL,0,0);
									break;
								case 'k':
									SendMessage(GetDlgItem(hDlg,IDC_COMBO_SIZE_QUANTITY),CB_SETCURSEL,1,0);
									break;
								case 'm':
									SendMessage(GetDlgItem(hDlg,IDC_COMBO_SIZE_QUANTITY),CB_SETCURSEL,2,0);
									break;
								case 'g':
									SendMessage(GetDlgItem(hDlg,IDC_COMBO_SIZE_QUANTITY),CB_SETCURSEL,3,0);
									break;
							}
							*ps=0;
							ps = wcsrchr(s,' ');
							if(ps)
								SetDlgItemText(hDlg,IDC_EDIT_SIZE,ps+1);
					}	}
					break;
				case IDC_BUTTON_BROWSE:
					bi.hwndOwner = hDlg;
					bi.pszDisplayName = s;
					bi.lpszTitle = L"Create archive to folder ...";
					bi.ulFlags = BIF_NONEWFOLDERBUTTON|BIF_DONTGOBELOWDOMAIN|BIF_NEWDIALOGSTYLE|
						BIF_NOTRANSLATETARGETS|BIF_RETURNFSANCESTORS;
					bi.lpfn = NULL;
					pidlRoot = NULL;
					bi.pidlRoot = pidlRoot;
					pidlSelected = SHBrowseForFolder(&bi);
					if(pidlRoot)
						CoTaskMemFree(pidlRoot);
					if(pidlSelected)
					{	SHGetPathFromIDList(pidlSelected,s);
						SetDlgItemText(hDlg,IDC_EDIT_DEST,s);
						CoTaskMemFree(pidlSelected);
					}
	   				return (INT_PTR)TRUE;
				case IDC_BUTTON_BROWSE2://src file:
					ZeroMemory(&ofn, sizeof(ofn));
					s[0] = '\0';
					ofn.lStructSize = sizeof(ofn);
					ofn.hwndOwner = NULL; 
					ofn.lpstrFile = s; 
					ofn.nMaxFile = MAX_PATH;
					ofn.lpstrFilter = NULL;
					ofn.nFilterIndex = 1;
					ofn.lpstrTitle = strngs[12];//TEXT("Please Select a File");
					ofn.lpstrInitialDir = NULL;
					ofn.lpstrCustomFilter = NULL;
					ofn.nMaxCustFilter = 0;
					ofn.lpstrFileTitle = NULL;
					ofn.nMaxFileTitle = 0;
					ofn.nFileOffset = 0;
					ofn.nFileExtension = 0;
					ofn.lpstrDefExt = NULL;
					ofn.lCustData = 0;
					ofn.lpfnHook = 0;
					ofn.lpTemplateName = 0;
					ofn.Flags = OFN_PATHMUSTEXIST | OFN_FILEMUSTEXIST | OFN_HIDEREADONLY |OFN_EXTENSIONDIFFERENT;
					if(GetOpenFileName(&ofn))
						SetDlgItemText(hDlg,IDC_EDIT_SRC,s);
					return (INT_PTR)TRUE;
				case IDOK:
					left=(int)SendMessage(GetDlgItem(hDlg,IDC_COMBO_SIZE_QUANTITY),CB_GETCURSEL,0,0);
					GetDlgItemText(hDlg,IDC_EDIT_SIZE,s,MAX_PATH-1);
					szFile = _wtoi(s);
					for(top=0; top<left; top++)
						szFile *= 1024;
					GetDlgItemText(hDlg,IDC_EDIT_SRC,s,MAX_PATH-1);
					GetDlgItemText(hDlg,IDC_EDIT_DEST,ss,MAX_PATH-1);
					top=SplitFile(hDlg,s,ss,szFile);
					if(top<0)
						MessageBox(hDlg,s,strngs[12+top],MB_ICONWARNING);
					else
						EndDialog(hDlg, 1);
					return (INT_PTR)TRUE;
				case IDCANCEL:
					EndDialog(hDlg, 0);
					return (INT_PTR)TRUE;
				case IDSTOP:
					bStop = !bStop;
					SetDlgItemText(hDlg,IDSTOP,bStop?strngs[8]:strngs[17]);
					break;
				case IDC_COMBO_DEST_PANEL:
					if(CBN_SELCHANGE==HIWORD(wParam))
					{	int l=(int)SendMessage(GetDlgItem(hDlg,IDC_COMBO_DEST_PANEL),CB_GETCURSEL,0,0);
						if(l>-1 && l<4)
						{	wchar_t *s=getPanelPath(l);
							if(s)
							{	ps=wcsrchr(s,'\\');
								if(ps) *(ps+1) = 0;
								SetDlgItemText(hDlg,IDC_EDIT_DEST,s);
					}	}	}
					break;
			}
			break;
		case WM_VSCROLL:
			if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_SIZE))
			{	if(SB_THUMBPOSITION==LOWORD(wParam) || SB_THUMBTRACK==LOWORD(wParam))
				{	if(HIWORD(wParam)<=50)
					{	if(GetDlgItemText(hDlg,IDC_EDIT_SIZE,s,MAX_PATH))
							szFile = MyAtoU64(s);
						MyU64ToA(s,MAX_PATH,++szFile);//StringCchPrintf(s,MAX_PATH,"%u",++szFile);
						SetDlgItemText(hDlg,IDC_EDIT_SIZE,s);
					} else
					{	if(GetDlgItemText(hDlg,IDC_EDIT_SIZE,s,MAX_PATH))
							szFile = MyAtoU64(s);
						if(szFile>0)szFile--;
						MyU64ToA(s,MAX_PATH,szFile);
						SetDlgItemText(hDlg,IDC_EDIT_SIZE,s);
				}	}
				SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
			}
			break;
	}
	return (INT_PTR)FALSE;
}

DWORD GetCheckSum(HWND dlg,HANDLE h,/*char *fName,*/unsigned __int64 *sz)
{
//unsigned __int64 sz;
//DWORD *psz,
DWORD rd,buf[1024],crc=0;

	SetDlgItemText(dlg,IDC_STATIC6,strngs[11]);

	//HANDLE h=CreateFile(fName,GENERIC_READ,FILE_SHARE_READ,0,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);
	//if(INVALID_HANDLE_VALUE==h) return 0;
	//psz = (DWORD*)&sz;
	//(*psz)=GetFileSize(h,psz+1);
	//if(0==(*(psz+1)))
	//if(((DWORD)-1)==(*psz))
	//	return 0;
	//sz>>=2;//DWORD sz;
	while(1)//for(int i=0; i<500; i++)
	{	DWORD k,rdtail;
		if(!ReadFile(h,buf,4096,&rd,NULL)) break;
		if(0==rd) break;

		rdtail=rd & 0x00000003;
		rd >>= 2;

		for(k=0; k<rd; k++)
			crc ^= buf[k];
		switch(rdtail)
		{	case 0:
				break;
			case 1:
				rdtail = *((BYTE*)&buf[k]);
				break;
			case 2:
				rdtail = *((BYTE*)&buf[k]) << 8  |  *(((BYTE*)&buf[k])+1);
				break;
			case 3:
				rdtail = *((BYTE*)&buf[k]) << 16  |  *(((BYTE*)&buf[k])+1) << 8  |   *(((BYTE*)&buf[k])+2);
				break;
		}crc ^= rdtail;

		SendMessage(GetDlgItem(dlg,IDC_PROGRESS_SPLIT),PBM_SETPOS,(WPARAM)(100*rd/(*sz)),0);

		while(CheckStopBtnMsg(dlg))
			Sleep(25);
	}
	//CloseHandle(h);
	//*szOut = sz;
	return crc;
}

/* Struct of split file:
	orgnl name[...] <null>    ... byte
	split name[...] <null>    ... byte
	orgnl size					8 byte (unsigned __int64)
	this split file size		8 byte (unsigned __int64)
	orgnl file crc			    4 byte (dword)
	this split file crc			4 byte (dword)
*/

int SplitFile(HWND dlg,wchar_t *srcFullPathAndName,wchar_t* destPath,__int64 SpltSz)
{
unsigned __int64 spltSz,fullSz,iWrtd,iReaded;
int fileNum=0,fileNameLn,spltFileNameLn,headerLn;
wchar_t spltFileName[MAX_PATH],fileName[MAX_PATH],extCh=0,*psplt,*ps=wcsrchr(srcFullPathAndName,'\\');
DWORD crc,rd,spltCrc,*psz,buf[1024];
HANDLE h,hSrc;

	hSrc=CreateFile(srcFullPathAndName,GENERIC_READ,FILE_SHARE_READ,0,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);
	if(INVALID_HANDLE_VALUE==hSrc)
		return -1;

	psz = (DWORD*)&fullSz;
	(*psz)=GetFileSize(hSrc,psz+1);
	if(0==(*(psz+1)))
	if(((DWORD)-1)==(*psz))
		return -2;

	crc=GetCheckSum(dlg,hSrc,&fullSz);//srcFullPathAndName,&fullSz);
	//if(!crc) return FALSE;
	SetFilePointer(hSrc,0,0,FILE_BEGIN);

	fileNameLn=MyStringCpy(fileName,MAX_PATH-1,ps+1);
	ps = wcsrchr(fileName,'.');
	iReaded=0;

	SetDlgItemText(dlg,IDC_STATIC6,strngs[16]);

NextSpltFile:
	if(ps)
	{	extCh = (*ps);
		*ps=0;
	}
	StringCchPrintf(spltFileName,MAX_PATH-1,L"%s\\%s%d.splt",destPath,fileName,fileNum);
	psplt = wcsrchr(spltFileName,'\\');
	if(!psplt)psplt=&spltFileName[0];
	else ++psplt;
	spltFileNameLn=MyStringLength(psplt,MAX_PATH-1);

	//splt header:
	headerLn=sizeof(wchar_t)*(fileNameLn+spltFileNameLn+2)+2*sizeof(__int64)+2*sizeof(__int32);
	if(SpltSz<=headerLn)
	{	MessageBox(dlg,strngs[18],L"Error",MB_OK);
	}
	spltSz=SpltSz-headerLn;

	spltCrc = 0; iWrtd=0;
	h=CreateFile(spltFileName,GENERIC_WRITE,FILE_SHARE_WRITE,0,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,NULL);
	if(INVALID_HANDLE_VALUE==h)
	{	CloseHandle(hSrc);
		return -3;
	}

	if(ps) *ps=extCh;
	WriteFile(h,fileName,sizeof(wchar_t)*(fileNameLn+1),&rd,NULL);
	WriteFile(h,psplt,sizeof(wchar_t)*(spltFileNameLn+1),&rd,NULL);
	WriteFile(h,&fullSz,sizeof(__int64),&rd,NULL);
	WriteFile(h,&spltSz,sizeof(__int64),&rd,NULL);
	WriteFile(h,&crc,sizeof(DWORD),&rd,NULL);
	WriteFile(h,&spltCrc,sizeof(DWORD),&rd,NULL);

	while(1)//for(int i=0; i<500; i++)
	{	DWORD k,rdtail,r=(DWORD)(spltSz-iWrtd<4096?(spltSz-iWrtd):4096);
		if(!ReadFile(hSrc,buf,r,&rd,NULL)) break;
		if(0==rd) break;
		r=rd;
		iWrtd+=rd;
		rdtail=rd & 0x00000003;
		rd >>= 2;
		for(k=0; k<rd; k++)
			spltCrc ^= buf[k];
		switch(rdtail)
		{	case 0:
				break;
			case 1:
				rdtail = *((BYTE*)&buf[k]);
				break;
			case 2:
				rdtail = *((BYTE*)&buf[k]) << 8  |  *(((BYTE*)&buf[k])+1);
				break;
			case 3:
				rdtail = *((BYTE*)&buf[k]) << 16  |  *(((BYTE*)&buf[k])+1) << 8  |   *(((BYTE*)&buf[k])+2);
				break;
		}spltCrc ^= rdtail;
		WriteFile(h,buf,r,&rd,NULL);
		SendMessage(GetDlgItem(dlg,IDC_PROGRESS_SPLIT),PBM_SETPOS,(WPARAM)(100*(iReaded+iWrtd)/fullSz),0);
		while(CheckStopBtnMsg(dlg))
			Sleep(25);
	}
	
	//Oxirgisini yozganda size i kichik chiqib qoldi:
	SetFilePointer(h,sizeof(wchar_t)*(fileNameLn+spltFileNameLn+2)+sizeof(__int64),0,FILE_BEGIN);
	WriteFile(h,&iWrtd,sizeof(__int64),&rd,NULL);

	SetFilePointer(h,sizeof(wchar_t)*(fileNameLn+spltFileNameLn+2)+2*sizeof(__int64)+sizeof(DWORD),0,FILE_BEGIN);
	WriteFile(h,&spltCrc,sizeof(DWORD),&rd,NULL);
	CloseHandle(h);
	iReaded+=iWrtd;
	++fileNum;
	if(iReaded<fullSz)
		goto NextSpltFile;

	CloseHandle(hSrc);
	return 0;
}

BOOL CheckStopBtnMsg(HWND dlg)
{
MSG msg;
	while(PeekMessage(&msg,dlg,0,0,PM_REMOVE))
		DispatchMessage(&msg);	
	return bStop;
}