#include <malloc.h>
#include "stdio.h"
#include "..\..\sino.h"
#include "..\..\config.h"
#include "..\..\operations\MyShell\ComboToDisk.h"
#include "selectviaplus.h"

SelectViaPlus fSelViaPlus;
SelectViaPlus::SelectViaPlus()
{
}

SelectViaPlus::~SelectViaPlus()
{
}

/*VOID SelectViaPlus::FindSelectsItems(Panel *pan,char* str,int iFrom,int iTo)
{
	switch(pan->GetEntry()->GetCrntRecType())
	{	default:case unknown:
			return;
		case directFolder:
			char pth[MAX_PATH];
			pan->SetPathLn(MyStringCpy(pth,MAX_PATH,pan->GetPath()));
			int l;l = MyStringLength(pth,MAX_PATH);
			char *p;p = strrchr(pth,'*');
			if(!p)
				p = &pth[l];
			else if('\\'!=*(p-1))
				p = &pth[l];

			for(int i=iFrom; i<=iTo; i++)
				*p++ = str[i];
			if(';'==*(p-1))
				*(p-1) = 0;
			else
				*p = 0;

			WIN32_FIND_DATA ff;
			HANDLE hFind;hFind = INVALID_HANDLE_VALUE;

			hFind = FindFirstFile(pth, &ff);
			if(INVALID_HANDLE_VALUE==hFind) return;

			for(int i=1; i<pan->GetTotItems(); i++)
			{	if(strstr(ff.cFileName,pan->GetItem(i)->Name))
				{	int ln = MyStringLength(ff.cFileName,MAX_PATH);
					if(ln==pan->GetItem(i)->NameCharLen+
						(pan->GetItem(i)->ExtCharLen?pan->GetItem(i)->ExtCharLen+1:0))
						pan->AddToSelection(i);
			}	}

			while(FindNextFile(hFind, &ff))
			{	for(int i=1; i<pan->GetTotItems(); i++)
				{	if(strstr(ff.cFileName,pan->GetItem(i)->Name))
					{	int ln = MyStringLength(ff.cFileName,MAX_PATH);
						if(ln==pan->GetItem(i)->NameCharLen+
							(pan->GetItem(i)->ExtCharLen?pan->GetItem(i)->ExtCharLen+1:0))
							pan->AddToSelection(i);
			}	}	}
			FindClose(hFind);
			return;
		case guidFolder:
		 for(int i=1; i<pan->GetTotItems(); i++)
		 {int j=iFrom,k=0;
		  for(;;)//1-st for;
		  {if(j==iTo)
		   {if(k==pan->GetItem(i)->NameCharLen)
		     break;//to search Ext;
		    if(str[j]=='*')
				goto Select;
		    goto SkipSelect;//Do not select;
		   }
		   else if(k==pan->GetItem(i)->NameCharLen)
		   {
			   goto SkipSelect;//Do not select;
		   }
		   
		   if(str[j]=='.')
		   {if(j==pan->GetItem(i)->NameCharLen)
		   {j++;break;}//Ext;      break fr 1-st for;
		    else goto SkipSelect;
		   }
		   else if(str[j]!='*')
		   {if(pan->GetItem(i)->Name[k]==str[j])
		     {j++;k++;continue;}//cont to 1-st for;
		    else {goto SkipSelect;}//do not select;
		   }
		   else//if(str[j]=='*')
		   {if(str[j+1]=='.'){j+=2;break;}//Goto Ext, skip 1-st for;
		    if(pan->GetItem(i)->Name[k]==str[j+1])
			  {j++;continue;}//go to next, 1-st for;
		    else if(pan->GetItem(i)->Name[k+1]==str[j+1])
			  {k++;j++;continue;}//go to next, 1-st for;
			k++;continue;//Name ni sur;
		  }}

		//Ext:
		  k=0;
		  for(;;)//1-st for;
		  {if(j==iTo || (j==iTo-1 && str[j+1]==';'))
		   {if(k==pan->GetItem(i)->ExtCharLen)
		     break;//to search Ext;
		    if(str[j]=='*')
				goto Select;
		    goto SkipSelect;//Do not select;
		   }
		   else if(k==pan->GetItem(i)->ExtCharLen)
		   {  
			   goto SkipSelect;//Do not select;
		   }
		   		   
		   if(str[j]=='.')
		   {if(j==pan->GetItem(i)->ExtCharLen)
				break;//Ext;      break fr 1-st for;
		    else goto SkipSelect;
		   }
		   else if(str[j]!='*')
		   {if(*(pan->GetItem(i)->GetExt()+k)==str[j])
		     {j++;k++;continue;}//cont to 1-st for;
		    else {goto SkipSelect;}//do not select;
		   }
		   else//if(str[j]=='*')
		   {if(str[j+1]=='.')break;//Goto Ext, skip 1-st for;
		    if(*(pan->GetItem(i)->GetExt()+k)==str[j+1])
			  {j++;continue;}//go to next, 1-st for;
		    else if(*(pan->GetItem(i)->GetExt()+k+1)==str[j+1])
			  {k++;j++;continue;}//go to next, 1-st for;
			k++;continue;//Name ni sur;
		  }}
		Select:
		  pan->AddToSelection(i);
		SkipSelect:
		   ;
		 }
		 return;
		case socketCl:
		case archElem:
		 for(int i=1; i<pan->GetTotItems(); i++)
		 {int j=iFrom,k=0;
		  for(;;)//1-st for;
		  {if(j==iTo)
		   {if(k==pan->GetItem(i)->NameCharLen)
		     break;//to search Ext;
		    if(str[j]=='*')
				goto Select1;
		    goto SkipSelect1;//Do not select;
		   }
		   else if(k==pan->GetItem(i)->NameCharLen)
		   {
			   goto SkipSelect1;//Do not select;
		   }
		   
		   if(str[j]=='.')
		   {if(j==pan->GetItem(i)->NameCharLen)
		   {j++;break;}//Ext;      break fr 1-st for;
		    else goto SkipSelect1;
		   }
		   else if(str[j]!='*')
		   {if(pan->GetItem(i)->Name[k]==str[j])
		     {j++;k++;continue;}//cont to 1-st for;
		    else {goto SkipSelect1;}//do not select;
		   }
		   else//if(str[j]=='*')
		   {if(str[j+1]=='.'){j+=2;break;}//Goto Ext, skip 1-st for;
		    if(pan->GetItem(i)->Name[k]==str[j+1])
			  {j++;continue;}//go to next, 1-st for;
		    else if(pan->GetItem(i)->Name[k+1]==str[j+1])
			  {k++;j++;continue;}//go to next, 1-st for;
			k++;continue;//Name ni sur;
		  }}

		//Ext:
		  k=0;
		  for(;;)//1-st for;
		  {if(j==iTo || (j==iTo-1 && str[j+1]==';'))
		   {if(k==pan->GetItem(i)->ExtCharLen)
		     break;//to search Ext;
		    if(str[j]=='*')
				goto Select1;
		    goto SkipSelect1;//Do not select;
		   }
		   else if(k==pan->GetItem(i)->ExtCharLen)
		   {  
			   goto SkipSelect1;//Do not select;
		   }
		   		   
		   if(str[j]=='.')
		   {if(j==pan->GetItem(i)->ExtCharLen)
				break;//Ext;      break fr 1-st for;
		    else goto SkipSelect1;
		   }
		   else if(str[j]!='*')
		   {if(*(pan->GetItem(i)->GetExt()+k)==str[j])
		     {j++;k++;continue;}//cont to 1-st for;
		    else {goto SkipSelect1;}//do not select;
		   }
		   else//if(str[j]=='*')
		   {if(str[j+1]=='.')break;//Goto Ext, skip 1-st for;
		    if(*(pan->GetItem(i)->GetExt()+k)==str[j+1])
			  {j++;continue;}//go to next, 1-st for;
		    else if(*(pan->GetItem(i)->GetExt()+k+1)==str[j+1])
			  {k++;j++;continue;}//go to next, 1-st for;
			k++;continue;//Name ni sur;
		  }}
		Select1:
		  pan->AddToSelection(i);
		SkipSelect1:
		   ;
		 }
		 return;
}	}*/

HANDLE MyFopenViaCrF(wchar_t *nm,const wchar_t *mode)
{
HANDLE h;
	if(wcsstr(mode,L"rw"))
	{	h = CreateFile(nm,GENERIC_READ|GENERIC_WRITE,
						  FILE_SHARE_READ|FILE_SHARE_WRITE,
						  NULL,
						  OPEN_ALWAYS,
						  FILE_ATTRIBUTE_NORMAL,NULL);
	}
	else if(wcsstr(mode,L"r"))
	{	h = CreateFile(nm,GENERIC_READ,FILE_SHARE_READ,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);
	}
	else if(wcsstr(mode,L"w"))
	{	h = CreateFile(nm,GENERIC_WRITE,FILE_SHARE_WRITE,NULL,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,NULL);
	}
	if(INVALID_HANDLE_VALUE==h)
		return NULL;
	return h;
}

INT_PTR CALLBACK SelectViaPlusDlgProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
static wchar_t str[MAX_SEL_PATH];
static HFONT hf=0;static int hfRef=0;//obshiy hf, dinamik uchun emas:
static HBRUSH br=0;
static HBRUSH brHtBk=0;
	UNREFERENCED_PARAMETER(lParam);
	switch (message)
	{
	case WM_INITDIALOG:
		RECT rc; GetWindowRect(hDlg, &rc);
		int width,left,height,top;

		width = rc.right - rc.left;
		left = conf::wndLeft + (conf::wndWidth - width)/2;

		height = rc.bottom - rc.top;
		top = conf::wndTop + (conf::wndHeight - height)/2;
		
		MoveWindow(hDlg, left, top, width, height, TRUE);

		wchar_t st[MAX_PATH];
		LoadString(hInst,IDS_STRINGSW_62,st,MAX_PATH);
		SetWindowText(hDlg,st);
		LoadString(hInst,IDS_STRINGSW_63,st,MAX_PATH);
		SetDlgItemText(hDlg,IDC_STATIC8,st);
		LoadString(hInst,IDS_STRINGSW_64,st,MAX_PATH);
		SetDlgItemText(hDlg,IDC_STATIC9,st);
		LoadString(hInst,IDS_STRINGSW_65,st,MAX_PATH);
		SetDlgItemText(hDlg,IDB_REMEMBER_SELECTION,st);
		LoadString(hInst,IDS_STRINGSW_41,st,MAX_PATH);
		SetDlgItemText(hDlg,IDOK,st);
		LoadString(hInst,IDS_STRINGSW_13,st,MAX_PATH);
		SetDlgItemText(hDlg,IDCANCEL,st);
		LoadString(hInst,IDS_STRINGSW_66,st,MAX_PATH);
		SetDlgItemText(hDlg,IDB_REMOVE_FROM_SELECTION,st);

		selPlusCB.Read(selPlusCBFName,
						GetDlgItem(hDlg,IDC_COMBO_SELECTION),
						MAX_SAVE_SELECTION_STR,
						MAX_SEL_PATH);

		if(selPlusCB1.Read(selPlusCB1FName,
						 GetDlgItem(hDlg,IDC_EDIT_SELECTION),
						 MAX_SAVE_SELECTION_STR,
						 MAX_SEL_PATH))
			SetDlgItemText(hDlg,IDC_EDIT_SELECTION,L"*.*;");

		SendMessage(hDlg,WM_USER+1,0,0);
		return (INT_PTR)TRUE;

	case WM_KEYDOWN:
		if(wParam==13)
		{	GetDlgItemText(hDlg,IDC_EDIT_SELECTION,str,MAX_SEL_PATH);
			if(wcsstr(str,L"**"))
			{	MessageBox(hDlg,L"Err. symbol sequence is not valid.",L"**",MB_OK);
				return (INT_PTR)TRUE;
			}
			SendMessage(GetDlgItem(hDlg,IDC_EDIT_SELECTION),CB_INSERTSTRING,0,(LPARAM)str);
			selPlusCB1.Save(selPlusCB1FName,GetDlgItem(hDlg,IDC_EDIT_SELECTION),25);
			EndDialog(hDlg, (INT_PTR)str);
			return (INT_PTR)TRUE;
		}
		break;
	case WM_CTLCOLORSTATIC:
	case WM_CTLCOLORDLG:HDC dc;dc = (HDC)wParam;
		SetTextColor(dc,conf::Dlg.dlgRGBs[7][1]);
		SetBkColor(dc,conf::Dlg.dlgRGBs[7][2]);
		return (INT_PTR)br;
	case WM_CTLCOLOREDIT:dc = (HDC)wParam;
		SetTextColor(dc,conf::Dlg.dlgRGBs[7][1]);
		SetBkColor(dc,conf::Dlg.dlgRGBs[7][2]);
		return (INT_PTR)br;
	case WM_CTLCOLORBTN:dc=(HDC)wParam;
		SetTextColor(dc,conf::Dlg.dlgRGBs[7][4]);
		SetBkColor(dc,conf::Dlg.dlgRGBs[7][5]);
		return (INT_PTR)brHtBk;
	case WM_DRAWITEM://WM_CTLCOLORBTN dagi knopkalar:
		LPDRAWITEMSTRUCT lpdis;lpdis = (LPDRAWITEMSTRUCT)lParam;
		wchar_t s[64];GetWindowText(lpdis->hwndItem,s,64);
		UINT uStyle;uStyle = DFCS_BUTTONPUSH;
		rc = lpdis->rcItem;
		if(lpdis->itemState & ODS_SELECTED)
		{	uStyle |= DFCS_PUSHED|DFCS_TRANSPARENT;
			rc.left+=2;rc.top+=2;
		}
		DrawFrameControl(lpdis->hDC, &lpdis->rcItem, DFC_BUTTON, uStyle);
		if(lpdis->itemState & ODS_SELECTED)
			{rc.left+=1;rc.top+=1;rc.bottom-=2;rc.right-=3;}
		else
			{rc.left+=1;rc.top+=2;rc.bottom-=3;rc.right-=3;}
		FillRect(lpdis->hDC,&rc,brHtBk);//DrawText(lpdis->hDC,"                                                  ",50,&rc,DT_SINGLELINE|DT_VCENTER|DT_INTERNAL|DT_LEFT);
		if(lpdis->itemState & ODS_SELECTED)
			{rc.left-=1;rc.top-=1;rc.bottom+=3;rc.right+=3;}
		else
			{rc.left-=1;rc.top-=2;rc.bottom+=2;rc.right+=3;}
		DrawText(lpdis->hDC,s,MyStringLength(s,64),&rc,DT_SINGLELINE|DT_VCENTER|DT_CENTER);
		return TRUE;
	case WM_USER+1://hf obshiy uchun, dinamik o'zgartirish uchun emas:
		if(0==hfRef)
		{	hf = CreateFontIndirect(&conf::Dlg.dlgFnts[7]);
			br = CreateSolidBrush(conf::Dlg.dlgRGBs[7][0]);
			brHtBk = CreateSolidBrush(conf::Dlg.dlgRGBs[7][5]);
		}
		SendMessage(GetDlgItem(hDlg,IDC_STATIC8),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_SELECTION),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_STATIC9),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_SELECTION),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDB_REMOVE_FROM_SELECTION),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDB_REMEMBER_SELECTION),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_SAVE_SELECTION),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDOK),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDCANCEL),WM_SETFONT,(WPARAM)hf,TRUE);
		++hfRef;
		return 0;//GWL_USERDATA
	case WM_DESTROY:
		if(--hfRef<1)
		{	DeleteObject(hf);
			DeleteObject(br);
			DeleteObject(brHtBk);
		}
		return 0;
	case WM_USER+2://Dinamik o'zgartirish uchun:
		DeleteObject(hf);hfRef=1;
		hf = CreateFontIndirect(&conf::Dlg.dlgFnts[7]);
		SendMessage(GetDlgItem(hDlg,IDC_STATIC8),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_SELECTION),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_STATIC9),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_SELECTION),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDB_REMOVE_FROM_SELECTION),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDB_REMEMBER_SELECTION),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_SAVE_SELECTION),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDOK),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDCANCEL),WM_SETFONT,(WPARAM)hf,TRUE);
		return 0;//GWL_USERDATA
	case WM_USER+3://Dinamik o'zgartirish uchun, colorni:
		DeleteObject(br);DeleteObject(brHtBk);hfRef=1;
		br = CreateSolidBrush(conf::Dlg.dlgRGBs[7][0]);
		brHtBk = CreateSolidBrush(conf::Dlg.dlgRGBs[7][5]);
		RedrawWindow(hDlg,NULL,NULL,RDW_INVALIDATE|RDW_ALLCHILDREN);
		return 0;//GWL_USERDATA
	case WM_COMMAND:
		switch(LOWORD(wParam))
		{	case IDOK:
				GetDlgItemText(hDlg,IDC_EDIT_SELECTION,str,MAX_SEL_PATH);
				if(wcsstr(str,L"**"))
				{	MessageBox(hDlg,L"Err. symbol sequence is not valid.",L"**",MB_OK);
					return (INT_PTR)TRUE;
				}
				else if(0==str[0])
					{ str[0]='*'; str[1]='.'; str[2]='*'; str[3]=';'; }
				SendMessage(GetDlgItem(hDlg,IDC_EDIT_SELECTION),CB_INSERTSTRING,0,(LPARAM)str);
				selPlusCB.Save(selPlusCBFName,GetDlgItem(hDlg,IDC_COMBO_SELECTION),MAX_SAVE_SELECTION_STR);
				selPlusCB1.Save(selPlusCB1FName,GetDlgItem(hDlg,IDC_EDIT_SELECTION),MAX_SAVE_SELECTION_STR);
				EndDialog(hDlg, (INT_PTR)str);
				return (INT_PTR)TRUE;
			case IDCANCEL:
				EndDialog(hDlg, (INT_PTR)NULL);
				return (INT_PTR)TRUE;
			case IDB_REMEMBER_SELECTION:
				if(GetDlgItemText(hDlg,IDC_EDIT_SAVE_SELECTION,str,MAX_SEL_PATH))
					CBToDisk::AddToCB(GetDlgItem(hDlg,IDC_COMBO_SELECTION),str);
				return (INT_PTR)TRUE;
			case IDC_COMBO_SELECTION:
				if(CBN_SELCHANGE==HIWORD(wParam))
				{	int selId; selId = (int)
						SendMessage(GetDlgItem(hDlg,IDC_COMBO_SELECTION),CB_GETCURSEL,0,0);
					if(CB_ERR!=selId)
					if(selId>-1)
					{	TCHAR s[MAX_SEL_PATH];
						if(CB_ERR!=SendMessage(GetDlgItem(hDlg,IDC_COMBO_SELECTION),CB_GETLBTEXT,selId,(LPARAM)s))
						{	wchar_t ss[MAX_PATH];
							GetDlgItemText(hDlg,IDC_EDIT_SELECTION,ss,MAX_PATH);
							if(!wcsstr(ss,s))
							{	MyStringCat(ss,MAX_PATH,s);
								SetDlgItemText(hDlg,IDC_EDIT_SELECTION,ss);
				}	}	}	}
				break;
			case IDC_EDIT_SELECTION:
				if(CBN_SELCHANGE==HIWORD(wParam))
				{	int selId; selId = (int) 
						SendMessage(GetDlgItem(hDlg,IDC_EDIT_SELECTION),CB_GETCURSEL,0,0);
					if(CB_ERR!=selId)
					if(selId>-1)
					{	TCHAR s[MAX_SEL_PATH];
						if(CB_ERR!=SendMessage(GetDlgItem(hDlg,IDC_EDIT_SELECTION),CB_GETLBTEXT,selId,(LPARAM)s))
							SetDlgItemText(hDlg,IDC_EDIT_SELECTION,s);
				}	}
				break;
			case IDB_REMOVE_FROM_SELECTION:
				int selId; selId = (int) 
					SendMessage(GetDlgItem(hDlg,IDC_COMBO_SELECTION),CB_GETCURSEL,0,0);
				if(CB_ERR!=selId)
					SendMessage(GetDlgItem(hDlg,IDC_COMBO_SELECTION),CB_DELETESTRING,selId,0);
				break;
		}
		break;
	}
	return (INT_PTR)FALSE;
}

VOID SelectViaPlus::Select(Panel *pan)
{
	if(conf::Dlg.crntSchplg<0) return;
	if(fSearchViaF7::numPlugins<1) return;
	if(conf::Dlg.crntSchplg>fSearchViaF7::numPlugins-1)return;

	wchar_t *fltr = (wchar_t*)DialogBox(hInst,MAKEINTRESOURCE(IDD_DIALOG_SELECT_WIA_PLUS),hWnd,SelectViaPlusDlgProc);
	if(!fltr)return;

	//int fltrStrLen = MyStringLength((char*)fltr,MAX_SEL_PATH);

	int iFrom = 0, oldHot = pan->GetHot();
	pan->FreeSelection();

	//Sozdayom list:
	//1.raschitayem mesto:
	int sz = 0;
	for(int i=0; i<pan->GetTotItems(); i++)
		sz += pan->GetItem(i)->NameCharLen+pan->GetItem(i)->ExtCharLen+2;

	//2.Dayom pamyat:
	wchar_t *buf = (wchar_t*)malloc(sizeof(wchar_t)*sz);

	//3.Zapolnyayem:
	wchar_t *pb = buf;
	for(int i=1; i<pan->GetTotItems(); i++)
	{	int ln = pan->GetItem(i)->NameCharLen;
		int extln = pan->GetItem(i)->ExtCharLen;
		int l = ln + (extln>0?extln+2:1);
		memcpy(pb,pan->GetItem(i)->Name,l*sizeof(wchar_t));
		pb += l;
	}
	*pb = 0;

	//4.Vyzyvaem plagin:
	fSearchViaF7::plgns[conf::Dlg.crntSchplg].LoadPlugin();
	LPVOID rbuf=fSearchViaF7::plgns[conf::Dlg.crntSchplg].QSearchFrList$8(fltr,buf);

	//5.Analiziruyem rezultaty:
	if(buf)
	{	__int16 *ibuf = (__int16*)rbuf;
		__int16 *ib = ibuf;
		while(*ib!=-1)//for(int i=0; i<(*buf); i++)
		{	pan->AddToSelection(*ib+1);
			++ib;
		}
		pan->ScrollItemToView(ibuf[0]);
	}
	else
	{	pan->SetHot(oldHot);
		pan->ScrollItemToView(oldHot);
	}

	//6.Osvobojdayem pamyat:
	free(buf);
	fSearchViaF7::plgns[conf::Dlg.crntSchplg].FreePlugin();
	/*for(int i=0; i<=selStrLen; i++)//Oxirgi 0 niyam olsun, aks holda 1ta qolib ketadur;
	{	if(' '==str[i] ||//CreateFile qoidasiga ko'ra ajratamiz;
		   ';'==str[i] ||//CreateFile qoidasiga ko'ra ajratamiz;
		   '<'==str[i] ||//CreateFile qoidasiga ko'ra ajratamiz;
		   '>'==str[i] ||//CreateFile qoidasiga ko'ra ajratamiz;
		   ':'==str[i] ||//CreateFile qoidasiga ko'ra ajratamiz;
		  '\"'==str[i] ||//CreateFile qoidasiga ko'ra ajratamiz;
		   '/'==str[i] ||//CreateFile qoidasiga ko'ra ajratamiz;
		  '\\'==str[i] ||//CreateFile qoidasiga ko'ra ajratamiz;
		   '|'==str[i] ||//CreateFile qoidasiga ko'ra ajratamiz;
		   '?'==str[i] ||//CreateFile qoidasiga ko'ra ajratamiz;
		   str[i]<32    )//CreateFile qoidasiga ko'ra ajratamiz;  0 ham kiradi, ya'ni oxiri;
		   //'*' ni qoldiramiz, chunki hammasi degani;
		{	if(i-iFrom>0)
			{	FindSelectsItems(pan,(char*)str,iFrom,i);
				iFrom = i+1;
				continue;
	}	}	}*/

/*	if(pan->GetTotSelects()<1 && oldHot>0)
	{	pan->SetHot(oldHot);
		pan->ScrollItemToView(oldHot);
	}
	else
	{
		pan->ScrollItemToView(pan->GetHot());
}*/	}

#undef MAX_SEL_PATH
