#ifndef _SEARCH_H__
#define _SEARCH_H__

#include "windows.h"



class CSearchPlgn;
class Panel;
namespace fSearchViaF7
{
	//Ob'yazatelniye:
	typedef const int (*GetPluginType_t)();
	typedef LPVOID (*QSearchFrList$8_t)(wchar_t*,wchar_t*);
	typedef LPVOID (*ShowSearchDlg$8_t)(HWND,wchar_t*);
	typedef VOID (*SetCallbacks$4xxx_t)(LPVOID,...);
	typedef BOOL (*SearchForContainText$12_t)(wchar_t*,wchar_t*,WIN32_FIND_DATA*);
	typedef BOOL (*SearchForContainTextW$12_t)(wchar_t*,wchar_t*,WIN32_FIND_DATA*);
	typedef BOOL (*SearchForNotContainText$12_t)(wchar_t*,wchar_t*,WIN32_FIND_DATA*);
	typedef BOOL (*SearchForNotContainTextW$12_t)(wchar_t*,wchar_t*,WIN32_FIND_DATA*);
	typedef VOID (*SetId$4_t)(int);
	typedef const wchar_t* (*GetPluginDescription_t)();
	typedef VOID (*ShowOptionDialog_t)();
	typedef VOID (*GetSrchFltr$8_t)(wchar_t*,int);

	extern VOID FreePlugins();
	extern VOID LoadPlugins();
	extern VOID TryLoadPlugin(wchar_t*,wchar_t*);
	extern VOID ShowSearchDlg$8(Panel*);
	extern BOOL SearchForContainText$12(wchar_t*,wchar_t*,WIN32_FIND_DATA*);
	extern BOOL SearchForContainTextW$12(wchar_t*,wchar_t*,WIN32_FIND_DATA*);
	extern BOOL SearchForNotContainText$12(wchar_t*,wchar_t*,WIN32_FIND_DATA*);
	extern BOOL SearchForNotContainTextW$12(wchar_t*,wchar_t*,WIN32_FIND_DATA*);

	extern INT_PTR CALLBACK CstmItemAttrbsDlgProc(HWND,UINT,WPARAM,LPARAM);

	extern CSearchPlgn *plgns;
	extern int numPlugins;
	extern SearchItem item;
	extern wchar_t srchFrFileFltr[MAX_PATH];
}
using namespace fSearchViaF7;

class CSearch;
class CSearchPlgn
{
friend VOID fSearchViaF7::TryLoadPlugin(wchar_t*,wchar_t*);

//First public functns for calling from plugins:
static BOOL  CALLBACK saveOptions(int,VOID*,int);
static BOOL  CALLBACK readOptions(int,VOID*,int);
static int   CALLBACK getPanelSelectedItemsNum();
static wchar_t* CALLBACK getPanelItemPathAndName(int);
static VOID CALLBACK execF3View(wchar_t*);

public:

static int myOwnPlgnNum;

	CSearchPlgn();
	~CSearchPlgn();
	HMODULE hm;
	int idNum;
	//int	dllSize;
	wchar_t pathAndName[MAX_PATH];

	BOOL LoadPlugin();
	VOID FreePlugin();

	fSearchViaF7::GetPluginType_t GetPluginType;
	fSearchViaF7::ShowSearchDlg$8_t ShowSearchDlg$8;
	fSearchViaF7::QSearchFrList$8_t QSearchFrList$8;
	fSearchViaF7::SetCallbacks$4xxx_t SetCallbacks$4xxx;
	fSearchViaF7::SearchForContainText$12_t SearchForContainText$12;
	fSearchViaF7::SearchForContainTextW$12_t SearchForContainTextW$12;
	fSearchViaF7::SearchForNotContainText$12_t SearchForNotContainText$12;
	fSearchViaF7::SearchForNotContainTextW$12_t SearchForNotContainTextW$12;
	fSearchViaF7::SetId$4_t SetId$4;
	fSearchViaF7::GetPluginDescription_t GetPluginDescription;
	fSearchViaF7::ShowOptionDialog_t ShowOptionDialog;
	fSearchViaF7::GetSrchFltr$8_t	GetSrchFltr$8;
};

/*class CSearch
{
friend class Panel;
friend class FillManager;
friend class CSearchPlgn;
public:
			CSearch();
	       ~CSearch();

	//BOOL	AddFile(int);
	//BOOL	Close();
	//BOOL	CreateDirectory(int);
	//int	GetFilesInFolder(char*,ArcStack*);

protected:
	HWND	 hDlg;
	//BOOL	 bStop,bCancel;
	//ArcStack *stack;
	//DWORD	 thrId,beginTickTot,stopTickTot[2],beginTick,stopTick[2];
	//BOOL	 bExcldPath,bDelAftArchiving,bSFXArchive;
	LPVOID   plgObj;
	int		 plgNum;
	int		 srcPanel;//totFiles,nameLn,iCrntFileCopy

	char	 name[MAX_PATH];
	int		 nameLn;
};*/

#endif