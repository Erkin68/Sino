//-----------------------------------------------------------------------------
// --------------------
// File ....: targapch.cpp
// --------------------
// Author...: Tom Hudson
// Date ....: May 1995
// Descr....: Targa File I/O Module Precompiled Header generator
//
// History .: May, 31 1995 - Started
//            Oct, 23 1995 - Continued work (GG)
//            Dec. 07 1995 - Tom created this file to speed compilation
//            
//-----------------------------------------------------------------------------

//-- Includes -----------------------------------------------------------------

#include <Max.h>
#include <bmmlib.h>
