#define _CRT_SECURE_NO_WARNINGS

#include "windows.h"
#include "stdio.h"
#include "strsafe.h"

#define MAX_STRINGS 24

HMODULE plgnDllInst;
int		plgId=0;

extern void saveOpt();
extern void FreeFindData();

BOOL APIENTRY DllMain(HMODULE hModule,DWORD ul_reason_for_call,LPVOID lpReserved)
{
	switch(ul_reason_for_call)
	{	case DLL_PROCESS_ATTACH:
			plgnDllInst=hModule;
			break;
		case DLL_THREAD_ATTACH:
			break;
		case DLL_THREAD_DETACH:
			break;
		case DLL_PROCESS_DETACH:
			saveOpt();
			break;
	}
	return TRUE;
}

void msg(HWND prnt,DWORD e,LPWSTR lpszFunction,LPWSTR msg1)
{ 
    // Retrieve the system error message for the last-error code

    LPVOID lpMsgBuf;
    LPVOID lpDisplayBuf;
	DWORD dw = (e==(DWORD)(-1))?GetLastError():e;

    FormatMessageW(
        FORMAT_MESSAGE_ALLOCATE_BUFFER | 
        FORMAT_MESSAGE_FROM_SYSTEM |
        FORMAT_MESSAGE_IGNORE_INSERTS,
        NULL,
        dw,
        MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
        (LPTSTR) &lpMsgBuf,
        0, NULL );

    // Display the error message and exit the process

    lpDisplayBuf = (LPVOID)LocalAlloc(LMEM_ZEROINIT, 
        (lstrlenW((LPCWSTR)lpMsgBuf)+lstrlenW((LPCWSTR)lpszFunction)+40)*sizeof(WCHAR)); 
    swprintf((LPTSTR)lpDisplayBuf, 
        L"%s failed with error %d: %s", 
        lpszFunction, dw, lpMsgBuf); 
    MessageBoxW(prnt, (LPCTSTR)lpDisplayBuf, msg1, MB_OK|MB_ICONWARNING|MB_SYSTEMMODAL); 


    LocalFree(lpMsgBuf);
    LocalFree(lpDisplayBuf);
    //ExitProcess(dw); 
}
