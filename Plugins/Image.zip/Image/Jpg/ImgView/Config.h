#include "windows.h"


namespace Config
{
extern int width;
extern int height;
extern int xPos;
extern int yPos;
extern int scrnSX;
extern int scrnSY;

extern __int8 originalSize;
extern __int8 horAlign;
extern __int8 verAlign;
extern __int8 drawMethod;
extern __int8 savePosition;
extern __int8 iCmnFileDlgSel;
extern int    rotDegree;


extern BOOL Read();
extern BOOL Save();
extern BOOL DefaultSettings();


};
