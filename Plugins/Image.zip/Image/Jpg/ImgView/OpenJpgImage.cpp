#include "windows.h"
#include "ImgView.h"
#include "stdio.h"
#include "strsafe.h"
#include "Config.h"
#include "..\..\..\..\Operations\MyShell\MyShell.h"

#define f32 float
#define s32 signed __int32
#define u32 unsigned __int32


LoadJPG_t LoadJPG;
LoadJPGWithCmnt_t LoadJPGWithCmnt;
//BYTE *sclPic=0;
extern "C"
{
int imgWidth,imgHeight,imgBpp,imgTmpWidth,imgTmpHeight,imgTmpBpp;
wchar_t cmnt[2*MAX_PATH],cmntTmp[2*MAX_PATH];
HDC dcImgBm=0,dcTmpImgBm=0;
HBITMAP bmImg=0,bmTmpImg=0;
HMODULE hm=0;//image opener module(jpgdbg,dll, as sample)
}


BOOL TryLoadJpg(wchar_t*,HBITMAP*,HDC*,int*,int*,int*);
DWORD getPixelBox(s32,s32,s32,s32);//,s32);
s32 ceil32(f32);
s32 floor32(f32);
s32 s32_max(s32,s32);
s32 s32_min(s32,s32);
s32 s32_clamp (s32,s32,s32);
s32 s32_log2_f32(f32);

void FreeTemp()
{	if(dcTmpImgBm)DeleteObject(dcTmpImgBm);dcTmpImgBm=0;
	if(bmTmpImg)DeleteObject(bmTmpImg);bmTmpImg=0;
	imgTmpWidth=imgTmpHeight=imgTmpBpp=0;
}

void FreeMain()
{	if(dcImgBm)DeleteObject(dcImgBm);dcImgBm=0;
	if(bmImg)DeleteObject(bmImg);bmImg=0;
	imgWidth=imgHeight=imgBpp=0;
}
void Free()
{	FreeMain();
	FreeTemp();
	if(hm)FreeLibrary(hm);
	Config::Save();
}

void ReplaceTemp()
{	FreeMain();
	dcImgBm=dcTmpImgBm;
	bmImg=bmTmpImg;
	imgWidth=imgTmpWidth;
	imgHeight=imgTmpHeight;
	imgBpp=imgTmpBpp;
	dcTmpImgBm=0;
	bmTmpImg=0;
	imgTmpWidth=0;
	imgTmpHeight=0;
	imgTmpBpp=0;
	MyStringCpy(cmnt,MAX_PATH,cmntTmp);
	cmntTmp[0]=0;
}

/*BOOL CreateImgDC()
{
	if(dc) DeleteObject(dc);
	if(bm) DeleteObject(bm);

	HDC d = GetDC(GetDesktopWindow());
	dc = CreateCompatibleDC(d);//d);
	//bm = CreateBitmap(width,height,1,bpp*8,pic);
	bm = CreateCompatibleBitmap(d,width,height);//bm = CreateBitmap(width,height,1,bpp,NULL);
	ReleaseDC(GetDesktopWindow(),d);
	if(!SelectObject(dc,bm))
	{	DeleteObject(dc);
		DeleteObject(bm);
		return FALSE;
	}

	BITMAPINFO bmi; memset(&bmi, 0, sizeof(bmi));
	bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
	bmi.bmiHeader.biWidth = width;
	bmi.bmiHeader.biHeight = -height;
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biBitCount = bpp*8;
	bmi.bmiHeader.biClrUsed = 0;
    bmi.bmiHeader.biCompression = BI_RGB;
	bmi.bmiHeader.biSizeImage = width*height*bpp;
	for(int i=0; i<height; i++)
	{	int scl = SetDIBitsToDevice(dc,0,i,width,1,0,0,0,1,pic+i*width*bpp,&bmi,DIB_RGB_COLORS);
		if(!scl)
			 scl = GetLastError();
	}

/*	BYTE *p= pic;
	for(int h=0; h<height; h++)
	for(int w=0; w<width; w++)
	{	SetPixel(dc,w,h,RGB(*p,*(p+1),*(p+2)));
		p += bpp;
	}*/

	
//	FILE *f = fopen("opwithlib.txt","wb");
//	fwrite(pic,1,bmi.bmiHeader.biSizeImage,f);
//	fclose(f);

	//free(pic);oshibka
	//pic=0;
	//FreeLibrary(hm);
	//hm=0;
//	return TRUE;
//}

BOOL TryLoadJpg(wchar_t* imgFilePathAndName,HBITMAP *pbm,HDC *pdc,
				int *pImgWidth, int *pImgHeight, int *pImgBpp)
{
wchar_t s[MAX_PATH],*p,*pp;
	if(!hm)
	{	GetModuleFileName(NULL,s,MAX_PATH-1);
		p = wcsrchr(s,'\\');
		if(!p)return FALSE;
		*p=0;
		p = wcsrchr(s,'\\');
		if(!p)return FALSE;
#ifndef _WIN64
		MyStringCpy(p+1,MAX_PATH-1-(int)(p-&s[0]),L"Image\\jpg\\jpgFrFileRel.dll");
		if(!IsFileExist(s))
			MyStringCpy(p+1,MAX_PATH-1-(int)(p-&s[0]),L"Image\\jpg\\jpgFrMemRel.dll");
		if(!IsFileExist(s))
			MyStringCpy(p+1,MAX_PATH-1-(int)(p-&s[0]),L"Image\\jpg\\jpgFrFileDbg.dll");
		if(!IsFileExist(s))
			MyStringCpy(p+1,MAX_PATH-1-(int)(p-&s[0]),L"Image\\jpg\\jpgFrMemDbg.dll");
#else
		MyStringCpy(p+1,MAX_PATH-1-(int)(p-&s[0]),L"Image\\jpg\\jpgFrFileRel64.dll");
		if(!IsFileExist(s))
			MyStringCpy(p+1,MAX_PATH-1-(int)(p-&s[0]),L"Image\\jpg\\jpgFrMemRel64.dll");
		if(!IsFileExist(s))
			MyStringCpy(p+1,MAX_PATH-1-(int)(p-&s[0]),L"Image\\jpg\\jpgFrFileDbg64.dll");
		if(!IsFileExist(s))
			MyStringCpy(p+1,MAX_PATH-1-(int)(p-&s[0]),L"Image\\jpg\\jpgFrMemDbg64.dll");
#endif
		if(!IsFileExist(s)) return FALSE;
		hm = LoadLibrary(s);
		if(!hm)	return FALSE;

		LoadJPG = (LoadJPG_t)GetProcAddress(hm,"LoadJPG");
		if(!LoadJPG)
		{	FreeLibrary(hm);
			return FALSE;
		}
		LoadJPGWithCmnt = (LoadJPGWithCmnt_t)GetProcAddress(hm,"LoadJPGWithCmnt");
	}
	//MultiByteToWideChar(AreFileApisANSI()?CP_ACP:CP_OEMCP,MB_PRECOMPOSED,imgFilePathAndName,-1,ws,MAX_PATH);
	//if(pic)free(pic);//oshibka
	//pic = 0;
	pp = &cmnt[0];
	DWORD t1=GetTickCount();
	if(!LoadJPGWithCmnt(imgFilePathAndName, pbm, pdc, pImgWidth, pImgHeight, pImgBpp, &pp))
		return FALSE;
	DWORD t2=GetTickCount();
	int ln = MyStringLength(cmnt,2*MAX_PATH);
	cmnt[ln++] = ' ';
	StringCchPrintfW(&cmnt[ln],MAX_PATH-ln,L"open time: %d ms",t2-t1);
	//if(!sclPic) sclPic = (BYTE*)malloc(width * height * bpp);

	FreeLibrary(hm);
	hm=0;
	return TRUE;
}





//! get a filtered pixel
/*DWORD getPixelBox( s32 x, s32 y, s32 fx, s32 fy)//, s32 bias ) baribir 0;
{
	DWORD c;
	s32 a = 0, r = 0, g = 0, b = 0;
	int widthbpp = width * bpp;
	int width1 = width-1;
	int height1 = height-1;

	for(s32 dx=0; dx!=fx; ++dx)
	{	for(s32 dy=0; dy!=fy; ++dy)
		{	int sxmn = s32_min( x + dx, width1);//width - 1 );
			int symn = s32_min( y + dy, height1);//height - 1);
			BYTE *B = &pic[symn * widthbpp + sxmn * bpp];//BYTE *B = &pic[symn * width * bpp + sxmn * bpp];

			a += *B++;
			r += *B++;
			g += *B++;
			b += *B++;
	}	}

	s32 sdiv = s32_log2_f32(fx * fy);

	//a = s32_clamp( ( a >> sdiv ) + bias, 0, 255 );
	//r = s32_clamp( ( r >> sdiv ) + bias, 0, 255 );
	//g = s32_clamp( ( g >> sdiv ) + bias, 0, 255 );
	//b = s32_clamp( ( b >> sdiv ) + bias, 0, 255 );
	a = s32_clamp( a >> sdiv, 0, 255 );
	r = s32_clamp( r >> sdiv, 0, 255 );
	g = s32_clamp( g >> sdiv, 0, 255 );
	b = s32_clamp( b >> sdiv, 0, 255 );

	c = (b << 24)  | (g << 16) | (r << 8) | a;
	return c;
}*/

/*s32 ceil32 ( f32 x )
{
//#ifdef IRRLICHT_FAST_MATH
		const f32 h = 0.5f;

		s32 t;

#if defined(_MSC_VER)
		__asm
		{
			fld	x
			fadd	h
			fistp	t
		}
#elif defined(__GNUC__)
		__asm__ __volatile__ (
			"fadd %2 \n\t"
			"fistpl %0 \n\t"
			: "=m"(t)
			: "t"(x), "f"(h)
			: "st"
			);
//#else
//#  warn IRRLICHT_FAST_MATH not supported.
//		return (s32) ceilf ( x );
//#endif
//		return t;
//#else // not fast math
//		return (s32) ceilf ( x );
#endif
	return t;
}

s32 floor32(f32 x)
{
//#ifdef IRRLICHT_FAST_MATH
		const f32 h = 0.5f;

		s32 t;

#if defined(_MSC_VER)
		__asm
		{
			fld	x
			fsub	h
			fistp	t
		}
#elif defined(__GNUC__)
		__asm__ __volatile__ (
			"fsub %2 \n\t"
			"fistpl %0"
			: "=m" (t)
			: "t" (x), "f" (h)
			: "st"
			);
//#else
//#  warn IRRLICHT_FAST_MATH not supported.
//		return (s32) floorf ( x );
//#endif
//		return t;
//#else // no fast math
//		return (s32) floorf ( x );
#endif
	return t;
}*/

s32 s32_min(s32 a, s32 b)
{
	const s32 mask = (a - b) >> 31;
	return (a & mask) | (b & ~mask);
}

s32 s32_max(s32 a, s32 b)
{
	const s32 mask = (a - b) >> 31;
	return (b & mask) | (a & ~mask);
}

s32 s32_clamp (s32 value, s32 low, s32 high)
{
	return s32_min(s32_max(value,low), high);
}

//#ifdef IRRLICHT_FAST_MATH
	#define IR(x)                           ((u32&)(x))
//#else
//	inline u32 IR(f32 x) {inttofloat tmp; tmp.f=x; return tmp.u;}
//#endif


// integer log2 of a float ieee 754. TODO: non ieee floating point
s32 s32_log2_f32( f32 f)
{
	u32 x = IR ( f );
	return ((x & 0x7F800000) >> 23) - 127;
}

//s32 s32_log2_s32(u32 x)
//{
//	return s32_log2_f32( (f32) x);
//}