//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by ImgView.rc
//
#define IDC_MYICON                      2
#define IDD_IMGVIEW_DIALOG              102
#define IDS_APP_TITLE                   103
#define IDD_ABOUTBOX                    104
#define IDS_CHILD                       104
#define IDM_ABOUT                       105
#define IDM_EXIT                        106
#define IDD_DIALOG_GET_IMG_FILE         107
#define IDR_MAINFRAME                   108
#define IDR_SINOSTRING                  109
#define ID_FILE_BROWSEFORIMAGE          110
#define IDM_FILE_BROWSEFORIMAGE         111
#define ID_FILE_MOVETO                  114
#define ID_EDIT_COPY                    115
#define ID_FILE_SAVETO                  116
#define ID_IMAGE_ORIGINALSIZE           117
#define ID_Menu                         118
#define ID_IMAGE_ALIGN                  119
#define ID_ALIGN_LEFT                   120
#define ID_ALIGN_CENTER                 121
#define ID_ALIGN_RIGHT                  122
#define ID_IMAGE_VERTICALALIGN          123
#define ID_VERTICALALIGN_TOP            124
#define ID_VERTICALALIGN_CENTER         125
#define ID_VERTICALALIGN_BOTTOM         126
#define ID_IMAGE_DRAWTYPE               127
#define ID_DRAWTYPE_TRANS               128
#define ID_DRAWTYPE_STRETCHBLT          129
#define ID_Trackbar                     130
#define ID_FILE_PRINTIMAGE              131
#define IDI_IMGVIEW                     132
#define IDC_IMGVIEW                     133
#define IDM_ROT90L                      134
#define IDC_STATIC1                     21570
#define IDC_STATIC2                     21571
#define IDC_STATIC3                     21572
#define IDC_STATIC4                     21574
#define IDC_STATIC5                     21573
#define IDC_STATIC6                     21575
#define IDC_LIST_ICON_RES_NUM           21150
#define IDC_CUSTOM_DRAW_ICON            21151
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        135
#define _APS_NEXT_COMMAND_VALUE         32791
#define _APS_NEXT_CONTROL_VALUE         1006
#define _APS_NEXT_SYMED_VALUE           136
#endif
#endif
