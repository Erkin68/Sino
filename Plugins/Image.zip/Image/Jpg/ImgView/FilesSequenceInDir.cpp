#include "windows.h"
#include "ImgView.h"
#include "..\..\..\..\Operations\MyShell\MyShell.h"

static wchar_t imgNameForSearch[MAX_PATH]=L"";
static wchar_t imgPthForSearch[MAX_PATH]=L"";
extern wchar_t imgFilePathAndName[MAX_PATH];


extern BOOL bLoadedFin;
extern VOID CalcScrnOffst();

void SetFileNameForSearch(wchar_t *PathAndName)
{MyStringCpy(imgPthForSearch,MAX_PATH,PathAndName);
 wchar_t *p=wcsrchr(imgPthForSearch,'\\');
 if(p)
 {MyStringCpy(imgNameForSearch,MAX_PATH,p+1);
  *(p+1)=0;  
 }
 else
 { MyStringCpy(imgNameForSearch,MAX_PATH,PathAndName);
   imgNameForSearch[0]=0;
}}

void GoNext(wchar_t *pth,int step)
{
WIN32_FIND_DATA ff;
HANDLE hf = INVALID_HANDLE_VALUE;
int crnt = -1;BOOL bFindOld=FALSE;
wchar_t s[MAX_PATH],preFindName[MAX_PATH]=L"";
int l=MyStringLength(imgNameForSearch,MAX_PATH);
int lpth=MyStringCpy(s,MAX_PATH,pth);
if('\\'==s[lpth-1]){s[lpth++]='*';s[lpth]=0;}
else if('\\'!=s[lpth-1] && (!('*'==s[lpth-1] && '\\'==s[lpth-2])))
	{s[lpth++]='\\';s[lpth++]='*';s[lpth]=0;}

	hf = FindFirstFileEx(s,FindExInfoStandard,&ff,FindExSearchLimitToDirectories,NULL,0);
	do
	{	if(INVALID_HANDLE_VALUE==hf) break;
		if(FILE_ATTRIBUTE_DIRECTORY & ff.dwFileAttributes)continue;//Papkani ichiga kirib o'tirmasun;
		wchar_t *pp = wcsrchr(ff.cFileName,'.');
		if(pp)
		{	++pp;
			if((!_wcsnicmp(pp,L"jpg",3)) || (!_wcsnicmp(pp,L"jpeg",4))  || (!_wcsnicmp(pp,L"png",3)) ||
			   (!_wcsnicmp(pp,L"bmp",3)) || (!_wcsnicmp(pp,L"dib",3)) || (!_wcsnicmp(pp,L"ico",3)) ||
			   (!_wcsnicmp(pp,L"cur",3)) || (!_wcsnicmp(pp,L"ani",3)) ||
			   (!_wcsnicmp(pp,L"gif",3)) ||
			   (!_wcsnicmp(pp,L"tga",3)) ||
			   (!_wcsnicmp(pp,L"tif",3)) ||
			   (!_wcsnicmp(pp,L"dds",3)))
			{	if(bFindOld || (!l))//next founded:
				{	MyStringCpy(imgNameForSearch,MAX_PATH,ff.cFileName);	
					goto End;
				}//else:
				if(!_wcsnicmp(imgNameForSearch,ff.cFileName,l))
				{	bFindOld=TRUE;
					if(-1==step)//1 ta orqadagisi:
					{MyStringCpy(imgNameForSearch,MAX_PATH,preFindName[0]?preFindName:ff.cFileName);
					 goto End;
				}	}
				MyStringCpy(preFindName,MAX_PATH,ff.cFileName);						
	}	}	}
	while(FindNextFile(hf, &ff));
End:
	FindClose(hf);
	if(imgNameForSearch[0])
	{MyStringCpy(&s[lpth-1],MAX_PATH-l,imgNameForSearch);
	 wchar_t *p=wcsrchr(&s[lpth-1],'.');
	 if(p && TryLoadImageWithExtension(s,p+1,&bmTmpImg,&dcTmpImgBm,&imgTmpWidth,&imgTmpHeight,&imgTmpBpp))
	 {	ReplaceTemp();
		CalcScrnOffst();
		imgLoadFail=FALSE;
		Render(0);
		MyStringCpy(imgFilePathAndName,MAX_PATH,s);
	}}
	else imgLoadFail = true;
}

void NextSequanceFiles(WPARAM wParam, LPARAM lParam)//WM_KEYDOWN & WM_SYSKEYDOWN
{if(!bLoadedFin)return;
static bool bFullScrn=false;
static RECT r;
	bLoadedFin=FALSE;
	switch(wParam)
	{	case VK_DOWN:// case VK_PAGE_DOWN:
		case VK_RIGHT:// case VK_PAGE_UP:
			GoNext(imgPthForSearch,1);
			break;
		case VK_UP:// case VK_PAGE_UP:
		case VK_LEFT:// case VK_PAGE_DOWN:
			GoNext(imgPthForSearch,-1);
			break;
		case VK_ESCAPE:
			PostQuitMessage(0);
			break;
		case VK_RETURN:
			if(0x8000 & GetKeyState(VK_LMENU))
			{	bFullScrn = !bFullScrn;
				if(bFullScrn)
				{	GetWindowRect(hWnd,&r);
					SetWindowPos(hWnd,HWND_TOP,0,0,GetSystemMetrics(SM_CXFULLSCREEN),
									 GetSystemMetrics(SM_CYFULLSCREEN),SWP_SHOWWINDOW);
				}
				else
				{	SetWindowPos(hWnd,HWND_TOP,r.left,r.top,r.right-r.left,
								 r.bottom-r.top,SWP_SHOWWINDOW);
			}	}
			break;
	}
	bLoadedFin=TRUE;
}
