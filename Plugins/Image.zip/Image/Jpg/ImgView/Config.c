#pragma warning (disable:4996)

#include "Config.h"
#include "stdio.h"
//#include "..\..\..\..\Operations\MyShell\MyShellC.h"


namespace Config
{

int width=-1;
int height=-1;
int xPos=-1;
int yPos=-1;

__int8 originalSize;
__int8 horAlign;
__int8 verAlign;
__int8 drawMethod;
__int8 savePosition;
__int8 iCmnFileDlgSel;
int    rotDegree;

int scrnSX;
int scrnSY;



BOOL Save()
{
wchar_t *p,s[MAX_PATH];FILE *f;int l=GetModuleFileName(NULL,s,MAX_PATH);
	p=wcsrchr(s,'\\');if(!p)p=&s[l];else++p;
	wcscpy(p,L"ImgVw.cnf");
	f=_wfopen(s,L"wb");
	if(!f)//default settings:
	 return FALSE;
	fwrite(&originalSize,sizeof(originalSize),1,f);
	fwrite(&horAlign,sizeof(horAlign),1,f);
	fwrite(&verAlign,sizeof(verAlign),1,f);
	fwrite(&drawMethod,sizeof(drawMethod),1,f);
	fwrite(&savePosition,sizeof(savePosition),1,f);
	fwrite(&iCmnFileDlgSel,sizeof(iCmnFileDlgSel),1,f);

	fwrite(&width,sizeof(width),1,f);
	fwrite(&height,sizeof(height),1,f);
	fwrite(&xPos,sizeof(xPos),1,f);
	fwrite(&yPos,sizeof(yPos),1,f);
	fwrite(&rotDegree,sizeof(rotDegree),1,f);
	fclose(f);
	return TRUE;
}

BOOL Read()
{
scrnSX=GetSystemMetrics(SM_CXSCREEN);
scrnSY=GetSystemMetrics(SM_CYSCREEN);

wchar_t *p,s[MAX_PATH];FILE *f;int l=GetModuleFileName(NULL,s,MAX_PATH);
	p=wcsrchr(s,'\\');if(!p)p=&s[l];else++p;
	wcscpy(p,L"ImgVw.cnf");
	f=_wfopen(s,L"rb");
	if(!f)//default settings:
	 return DefaultSettings();

	fread(&originalSize,sizeof(originalSize),1,f);
	fread(&horAlign,sizeof(horAlign),1,f);
	fread(&verAlign,sizeof(verAlign),1,f);
	fread(&drawMethod,sizeof(drawMethod),1,f);
	fread(&savePosition,sizeof(savePosition),1,f);
	fread(&iCmnFileDlgSel,sizeof(iCmnFileDlgSel),1,f);
	if(Config::iCmnFileDlgSel<0 || Config::iCmnFileDlgSel>2)Config::iCmnFileDlgSel=0;
	fread(&width,sizeof(width),1,f);
	fread(&height,sizeof(height),1,f);
	fread(&xPos,sizeof(xPos),1,f);
	fread(&yPos,sizeof(yPos),1,f);
	fread(&rotDegree,sizeof(rotDegree),1,f);
	fclose(f);
	return TRUE;
}

BOOL DefaultSettings()
{savePosition=0;
 horAlign=1;
 verAlign=1;
 drawMethod=0;
 originalSize=1;
 iCmnFileDlgSel=0;
 rotDegree=0;
 return TRUE;
}

}