#pragma once

#include "resource.h"


extern HINSTANCE hInst;
extern HWND hWnd;
extern int iInLookUpDirCnt[2];
extern int imgWidth,imgHeight,imgBpp,imgTmpWidth,imgTmpHeight,imgTmpBpp;
extern HDC dcImgBm,dcTmpImgBm;
extern HBITMAP bmImg,bmTmpImg;
extern HMODULE hm;
extern BOOL	   imgLoadFail;
extern wchar_t cmnt[2*MAX_PATH];


typedef enum TImgType
{	jpg=0,
	png=1,
	dib=2,
	gif=3,
	tga=4,
	tif=5,
	dds=6
}ImgType;
extern ImgType imgType;
extern BOOL ImageOnCreateWindow(HWND);
extern BOOL OnLoadingImgFromMenu(HWND,wchar_t*,wchar_t*);
extern BOOL TryLoadImg(wchar_t*,HBITMAP*,HDC*,int*,int*,int*);
extern VOID Render(HDC);
extern void FreeTemp();
extern void ReplaceTemp();


typedef BOOL (*LoadJPG_t)(const wchar_t*,byte**,int*,int*,int*);
extern LoadJPG_t LoadJPG;
typedef BOOL (*LoadJPGWithCmnt_t)(const wchar_t*,HBITMAP*,HDC*,int*,int*,int*,wchar_t**);
extern LoadJPGWithCmnt_t LoadJPGWithCmnt;


extern BOOL LoadPngImageFile(wchar_t*,BYTE**,int*,int*,int*);
extern BOOL TryLoadPng(wchar_t*,HBITMAP*,HDC*,int*,int*,int*);
extern BOOL TryLoadDib(wchar_t*,int,HBITMAP*,HDC*,int*,int*,int*);
extern BOOL TryLoadGif(wchar_t*,int,HBITMAP*,HDC*,int*,int*,int*);
extern BOOL TryLoadTga(wchar_t*,int,HBITMAP*,HDC*,int*,int*,int*);
extern BOOL TryLoadTif(wchar_t*,int,HBITMAP*,HDC*,int*,int*,int*);
extern BOOL TryLoadDds(wchar_t*,int,HBITMAP*,HDC*,int*,int*,int*);


extern BOOL TryLoadImageWithExtension(wchar_t*,wchar_t*,HBITMAP*,HDC*,int*,int*,int*);
extern BOOL TryLoadImageExperAllExtensions(wchar_t*,HBITMAP*,HDC*,int*,int*,int*);
extern VOID DrawImage(HDC,RECT*);