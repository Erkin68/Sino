#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <windows.h>
#include <strsafe.h>
#include "ImgViewC.h"
#include "..\..\..\..\Operations\MyShell\MyShellC.h"




BYTE bkgColor[3] = {127, 127, 127};

typedef BOOL (*LoadPNG_t)(wchar_t*,BYTE**,int*,int*,int*,BYTE*);
LoadPNG_t LoadPNG=NULL;
typedef BOOL (*PngLoadImage_t)(wchar_t*,BYTE**,int*,int*,int*,BYTE*);
PngLoadImage_t PngLoadImage=NULL;


typedef BOOL (*BuildPngImage_t)(BYTE**,BYTE**,int,int,BYTE*,int,int,int,BOOL);
BuildPngImage_t BuildPngImage=NULL;
typedef BOOL (*InitPngBitmap_t)(BYTE*,int,int);
InitPngBitmap_t InitPngBitmap=NULL;
typedef BOOL (*FillPngBitmap_t) (BYTE*,int,int,BYTE*,int,int,int,BOOL);
FillPngBitmap_t FillPngBitmap=NULL;


BOOL LoadPngImageFile(wchar_t* pstrPathName,BYTE **ppbImage,int *pxImgSize,int *pyImgSize,int *piChannels)
{
static TCHAR szTmp [MAX_PATH];

    /* if there's an existing PNG, free the memory */

    if(*ppbImage)
    {   free(*ppbImage);
        *ppbImage = NULL;
    }

    /* Load the entire PNG into memory */

    SetCursor (LoadCursor (NULL, IDC_WAIT));
    ShowCursor (TRUE);

    PngLoadImage(pstrPathName, ppbImage, pxImgSize, pyImgSize, piChannels, bkgColor);

    ShowCursor (FALSE);
    SetCursor (LoadCursor (NULL, IDC_ARROW));

    if(*ppbImage != NULL)
    {
        //sprintf (szTmp, "VisualPng - %s", strrchr(pstrPathName, '\\') + 1);
        //SetWindowText (hwnd, szTmp);
    }
    else
    {
        //MessageBox (hwnd, TEXT ("Error in loading the PNG image"),
        //    szProgName, MB_ICONEXCLAMATION | MB_OK);
        return FALSE;
    }

    return TRUE;
}

BOOL TryLoadPng(wchar_t* imgFilePathAndName,HBITMAP* pbm,HDC *pdc,int *width,int *height,int *bpp)
{BYTE *ppbImage=NULL;HDC DC;wchar_t s[MAX_PATH],*p,*pp;DWORD t1,t2;int ln;
static BYTE *pDib = NULL;static BYTE *pDiData = NULL;
static BOOL bStretched = FALSE;

//BITMAPINFO *pb;
	if(!hm)
	{	GetModuleFileName(NULL,s,MAX_PATH-1);
		p = wcsrchr(s,'\\');
		if(!p)return FALSE;
		*p=0;
		p = wcsrchr(s,'\\');
		if(!p)return FALSE;
		MyStringCpy(p+1,MAX_PATH-1-(int)(p-&s[0]),L"Image\\pngFrFileRel.dll");
		if(!IsFileExist(s))
			MyStringCpy(p+1,MAX_PATH-1-(int)(p-&s[0]),L"Image\\pngFrMemRel.dll");
		if(!IsFileExist(s))
			MyStringCpy(p+1,MAX_PATH-1-(int)(p-&s[0]),L"Image\\pngFrFileDbg.dll");
		if(!IsFileExist(s))
			MyStringCpy(p+1,MAX_PATH-1-(int)(p-&s[0]),L"Image\\pngFrMemDbg.dll");
		if(!IsFileExist(s)) return FALSE;
		hm = LoadLibrary(s);
		if(!hm)	return FALSE;

		LoadPNG = (LoadPNG_t)GetProcAddress(hm,"LoadPNG");
		PngLoadImage = (PngLoadImage_t)GetProcAddress(hm,"PngLoadImage");
		BuildPngImage=(BuildPngImage_t)GetProcAddress(hm,"BuildPngImage");
		InitPngBitmap=(InitPngBitmap_t)GetProcAddress(hm,"InitPngBitmap");
		FillPngBitmap=(FillPngBitmap_t)GetProcAddress(hm,"FillPngBitmap");

		if((!LoadPNG) || (!PngLoadImage) || (!BuildPngImage) || (!InitPngBitmap) || (!FillPngBitmap))
		{	FreeLibrary(hm);
			return FALSE;
	}	}
	pp = &cmnt[0];
	t1=GetTickCount();

	LoadPngImageFile(imgFilePathAndName,&ppbImage,width,height,bpp);

    BuildPngImage(&pDib, &pDiData, *width, *height,
                  ppbImage, *width, *height, *bpp, bStretched);


	DC = GetDC(GetDesktopWindow());
	*pdc = CreateCompatibleDC(DC);
	*pbm = CreateCompatibleBitmap(DC,*width,*height);
	ReleaseDC(GetDesktopWindow(),DC);
	if(!SelectObject(*pdc,*pbm))
	{	DeleteObject(*pdc);
  		DeleteObject(*pbm);
		return FALSE;
	}

    //pb=(BITMAPINFO*)pDib;
    if(pDib)
        t2=SetDIBitsToDevice(*pdc, 0, 0, *width, *height, 0, 0,
                0, *height, pDiData, (BITMAPINFO*)pDib, DIB_RGB_COLORS);
	//t2=GetLastError();

	//free(pDib);//free(pDiData);
	pDib=0;


	t2=GetTickCount();
	ln = MyStringLength(cmnt,2*MAX_PATH);
	cmnt[ln++] = ' ';
	StringCchPrintfW(&cmnt[ln],MAX_PATH-ln,L"open time: %d ms",t2-t1);


	//free(ppbImage);
	FreeLibrary(hm);
	hm=0;
	return TRUE;
}