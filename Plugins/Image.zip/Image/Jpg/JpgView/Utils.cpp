#include "windows.h"


BOOL IsFileExist(wchar_t *name)
{
WIN32_FIND_DATA fd;
HANDLE h=FindFirstFile(name,&fd);
	if(INVALID_HANDLE_VALUE==h)
		return FALSE;
	FindClose(h);
	return TRUE;
}

BOOL IsFileExistA(char *name)
{
WIN32_FIND_DATAA fd;
HANDLE h=FindFirstFileA(name,&fd);
	if(INVALID_HANDLE_VALUE==h)
		return FALSE;
	FindClose(h);
	return TRUE;
}

BOOL IsDirExist(wchar_t *path)
{
HANDLE hDir = CreateFile(
  path,								  // pointer to the file name
  FILE_LIST_DIRECTORY,                // access (read/write) mode
  FILE_SHARE_READ|FILE_SHARE_DELETE,  // share mode
  NULL,                               // security descriptor
  OPEN_EXISTING,                      // how to create
  FILE_FLAG_BACKUP_SEMANTICS,         // file attributes
  NULL);                              // file with attributes to copy
	if(INVALID_HANDLE_VALUE==hDir) return FALSE;
	CloseHandle(hDir);
	return TRUE;
}

BOOL IsDirExistA(char *path)
{
HANDLE hDir = CreateFileA(
  path,								  // pointer to the file name
  FILE_LIST_DIRECTORY,                // access (read/write) mode
  FILE_SHARE_READ|FILE_SHARE_DELETE,  // share mode
  NULL,                               // security descriptor
  OPEN_EXISTING,                      // how to create
  FILE_FLAG_BACKUP_SEMANTICS,         // file attributes
  NULL);                              // file with attributes to copy
	if(INVALID_HANDLE_VALUE==hDir) return FALSE;
	CloseHandle(hDir);
	return TRUE;
}

int MyStringCpy(wchar_t* buf, int mx, wchar_t* src)
{	register int l=-1;
	while(++l<mx)
	{	buf[l] = src[l];
		if(!src[l]) break;//('\0'==src[l])
	}
	if(buf[l])//0 bo'lmasa;
	if(l>=mx)
		buf[l] = 0;
	return l;
}

int MyStringCpyA(char* buf, int mx, char* src)
{	register int l=-1;
	while(++l<mx)
	{	buf[l] = src[l];
		if(!src[l]) break;//('\0'==src[l])
	}
	if(buf[l])//0 bo'lmasa;
	if(l>=mx)
		buf[l] = 0;
	return l;
}

int MyStringLength(wchar_t* buf, int mx)
{	int l=-1;
	if(!buf[0])return 0;
	while(++l<mx)
	{	if(!buf[l])//(0==buf[l])
			return l;
		if(l>=mx)
			return l;
	};
	return l;
}

int MyStringLengthA(char* buf, int mx)
{	int l=-1;
	if(!buf[0])return 0;
	while(++l<mx)
	{	if(!buf[l])//(0==buf[l])
			return l;
		if(l>=mx)
			return l;
	};
	return l;
}