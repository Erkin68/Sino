#pragma once

#include "resource.h"


extern HINSTANCE hInst;
extern HWND hWnd;
extern int width,height,bpp;
extern HDC dc;
extern HBITMAP bm;

extern "C"
{
	typedef BOOL (*LoadJPG_t)(const wchar_t*,byte**,int*,int*,int*);
	extern LoadJPG_t LoadJPG;
	typedef BOOL (*LoadJPGWithCmnt_t)(const wchar_t*,HBITMAP*,HDC*,int*,int*,int*,wchar_t**);
	extern LoadJPGWithCmnt_t LoadJPGWithCmnt;
}


extern BOOL TryLoadImageWithExtension(char*,char*);
extern BOOL TryLoadImageExperAllExtensions(char*);
extern VOID DrawImage(HDC,RECT&);