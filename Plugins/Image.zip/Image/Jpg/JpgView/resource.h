//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by JpgView.rc
//
#define IDC_MYICON                      2
#define IDD_JPGVIEW_DIALOG              102
#define IDS_APP_TITLE                   103
#define IDD_ABOUTBOX                    104
#define IDM_ABOUT                       105
#define IDM_EXIT                        106
#define IDI_JPGVIEW                     107
#define IDI_SMALL                       108
#define IDC_JPGVIEW                     109
#define IDD_DIALOG_GET_JPEG_FILE        110
#define IDR_MAINFRAME                   111
#define IDR_SINOSTRING                  112
#define ID_FILE_BROWSEFORIMAGE          113
#define IDM_FILE_BROWSEFORIMAGE         114
#define IDC_LIST_ICON_RES_NUM			115
#define IDC_CUSTOM_DRAW_ICON			116
#define IDC_EDIT_FILE
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        134
#define _APS_NEXT_COMMAND_VALUE         32774
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           114
#endif
#endif
