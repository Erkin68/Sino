#include "windows.h"
#include "..\..\..\..\Operations\MyShell\MyShell.h"

extern HWND hWnd;
extern bool fail;
static int numJpgFilesInDir=0;
static int crntJpgFileInDir=-1;
static char path[MAX_PATH]={0};
static char name[MAX_PATH]={0};

extern BOOL TryLoadImageWithExtension(char*,char*);
extern VOID Render(HDC,RECT&);


void CalcJpgFilesSequenceInThisDir(char *imgFilePath,char *imgFilePathAndName)
{
WIN32_FIND_DATAA ff;
HANDLE hf = INVALID_HANDLE_VALUE;
int tot = 0,crnt = -1,nmln=0;
int pln = MyStringCpyA(path,MAX_PATH,imgFilePath);

	for(int i=0; i<2; ++i)
		if('*'==path[pln-1] || '\\'==path[pln-1]) path[--pln]=0;
	path[pln++] = '\\';
	path[pln++] = '*';
	path[pln] = 0;

	char *p = strrchr(imgFilePathAndName,'\\');
	if(p) ++p;
	else p = imgFilePathAndName;
	nmln=MyStringCpyA(name,MAX_PATH,p);

	hf = FindFirstFileExA(path,FindExInfoStandard,&ff,FindExSearchLimitToDirectories,NULL,0);
	do
	{	if(INVALID_HANDLE_VALUE==hf) break;
		if(!_strnicmp(name,ff.cFileName,nmln))
			crnt = tot;
		char *pp = strrchr(ff.cFileName,'.');
		if(pp)
		{	++pp;
			if(!_strnicmp(pp,"jpg",3))
				++tot;
			else if(!_strnicmp(pp,"jpeg",4))
				++tot;
	}	}	
	while(FindNextFileA(hf, &ff));
	FindClose(hf);

	numJpgFilesInDir = tot;
	crntJpgFileInDir = crnt;
}

void GoNext(int step)
{
WIN32_FIND_DATAA ff;
HANDLE hf = INVALID_HANDLE_VALUE;
int tot = 0,crnt = -1;
char t[MAX_PATH],*p;

	hf = FindFirstFileExA(path,FindExInfoStandard,&ff,FindExSearchLimitToDirectories,NULL,0);
	do
	{	if(INVALID_HANDLE_VALUE==hf) break;
		char *pp = strrchr(ff.cFileName,'.');
		if(pp)
		{	++pp;
			if((!_strnicmp(pp,"jpg",3)) || (!_strnicmp(pp,"jpeg",4)))
			{	if(tot==crntJpgFileInDir+step)
				{	crnt = tot;
					int l=MyStringCpyA(t,MAX_PATH,path);
					MyStringCpyA(&t[l-1],MAX_PATH,ff.cFileName);
					p=strrchr(t,'.');
				}
				++tot;				
	}	}	}
	while(FindNextFileA(hf, &ff));
	FindClose(hf);
	numJpgFilesInDir = tot;
	if(crnt>-1)
	{	crntJpgFileInDir = crnt;
		if(TryLoadImageWithExtension(t,p+1))
		{	RECT r;GetClientRect(hWnd,&r);
			HDC dc = GetDC(hWnd);
			Render(dc,r);
			ReleaseDC(hWnd,dc);
			fail = false;			
		}
		else fail = true;
}	}

void NextSequanceFiles(WPARAM wParam, LPARAM lParam)//WM_KEYDOWN & WM_SYSKEYDOWN
{
static bool bFullScrn=false;
static RECT r;
	switch(wParam)
	{	case VK_DOWN:// case VK_PAGE_DOWN:
		case VK_RIGHT:// case VK_PAGE_UP:
			GoNext(1);
			break;
		case VK_UP:// case VK_PAGE_UP:
		case VK_LEFT:// case VK_PAGE_DOWN:
			GoNext(-1);
			break;
		case VK_ESCAPE:
			PostQuitMessage(0);
			break;
		case VK_RETURN:
			if(0x8000 & GetKeyState(VK_LMENU))
			{	bFullScrn = !bFullScrn;
				if(bFullScrn)
				{	GetWindowRect(hWnd,&r);
					SetWindowPos(hWnd,HWND_TOP,0,0,GetSystemMetrics(SM_CXFULLSCREEN),
									 GetSystemMetrics(SM_CYFULLSCREEN),SWP_SHOWWINDOW);
				}
				else
				{	SetWindowPos(hWnd,HWND_TOP,r.left,r.top,r.right-r.left,
								 r.bottom-r.top,SWP_SHOWWINDOW);
			}	}
			break;
}	}
