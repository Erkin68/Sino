#include "windows.h"
#include "strsafe.h"
#include "Plugins_C.h"
#include "resource.h"
#include "windows.h"
#include "jpeg-6 frMem\jpeglib.h"


typedef unsigned char byte;


extern wchar_t **strngs;
extern int plgId;
extern HMODULE plgnDllInst;

extern void msg(HWND,DWORD,LPWSTR,LPWSTR);


INT_PTR CALLBACK ExstngActnDlgProc(HWND,UINT,WPARAM,LPARAM);
wchar_t* GetJpgColorSpaceStr(j_decompress_ptr);
wchar_t* GetOutColorSpaceStr(j_decompress_ptr);


typedef void (*UnpackProgressRoutine_t)(unsigned __int64,unsigned __int64);
typedef HANDLE (WINAPI *FindFirstFileEx_t)(LPCTSTR,FINDEX_INFO_LEVELS,LPVOID,FINDEX_SEARCH_OPS,LPVOID,DWORD);
extern FindFirstFileEx_t MyFindFirstFileEx;

saveOptions_t saveOptions;
readOptions_t readOptions;

__declspec (dllexport) int GetPluginType()
{
	return 202;
}

__declspec (dllexport) const wchar_t* GetPluginDescription()
{
wchar_t mnuStr[64];
	if(GetEnvironmentVariableW(L"languge",mnuStr,64))//Language instartup qo'yadur;
	{	if(!wcscmp(mnuStr,L"russian"))
			return L"Sino ������ ��������� jpg-������, ������ 1.1";
		else if(!wcscmp(mnuStr,L"uzbekl"))
			return L"Sino jpg-fayllarni ochuvchi plagin, versiya 1.1";
		else if(!wcscmp(mnuStr,L"uzbekk"))
			return L"Sino jpg-��������� ������ ������, ������ 1.1";
		else//if(wcscmp(mnuStr,L"Exit")
			return L"Sino jpg-image view plugin version 1.1";
	}
	//else 
	return L"Sino jpg-image viewplugin version 1.1";
}

__declspec (dllexport) const wchar_t* GetPluginName()
{
	return strngs[0];
}

__declspec (dllexport) const wchar_t *GetImgExtnsn$4(int t)
{
	switch(t)
	{	case 0:
			return L"jpg";
		case 1:
			return L"jpeg";
	}
	return NULL;//end of enum
}

void saveOpt()
{	
	//saveOptions(plgId,&item,sizeof(item));
}

__declspec (dllexport) void SetId$4(int id)
{
	plgId = id;
	//readOptions(id,&item,sizeof(item));
}

__declspec (dllexport) VOID SetCallbacks$4xxx(LPVOID frstCallback,...)
{
va_list args;
	va_start(args, frstCallback);//1
	saveOptions = (saveOptions_t)va_arg(args, int);//7
	readOptions = (readOptions_t)va_arg(args, int);//8
va_end (args);
}

void jpg_Error( const char *fmt, ... )
{
	va_list		argptr;
	char		msg[2048];

	va_start (argptr,fmt);
	vsprintf (msg,fmt,argptr);
	va_end (argptr);

	MessageBoxA(NULL, "Error", msg, MB_OK );
}

void jpg_Printf( const char *fmt, ... )
{
	va_list		argptr;
	char		msg[2048];

	va_start (argptr,fmt);
	vsprintf (msg,fmt,argptr);
	va_end (argptr);

	MessageBoxA(NULL, "Error", msg, MB_OK );
}

__declspec (dllexport) BOOL LoadJPG(const wchar_t *filename,byte **pic,int *width,int *height, int *bpp)//,FILETIME *timestamp) 
{
  /* This struct contains the JPEG decompression parameters and pointers to
   * working space (which is allocated as needed by the JPEG library).
   */
  struct jpeg_decompress_struct cinfo;
  /* We use our private extension JPEG error handler.
   * Note that this struct must live as long as the main JPEG parameter
   * struct, to avoid dangling-pointer problems.
   */
  /* This struct represents a JPEG error handler.  It is declared separately
   * because applications often want to supply a specialized error handler
   * (see the second half of this file for an example).  But here we just
   * take the easy way out and use the standard error handler, which will
   * print a message on stderr and call exit() if compression fails.
   * Note that this struct must live as long as the main JPEG parameter
   * struct, to avoid dangling-pointer problems.
   */
  struct jpeg_error_mgr jerr;
  /* More stuff */
  int row_stride;		/* physical row width in output buffer */
  byte  *fbuffer;
  DWORD szHigh;

  /* In this example we want to open the input file before doing anything else,
   * so that the setjmp() error recovery below can assume the file is open.
   * VERY IMPORTANT: use "b" option to fopen() if you are on a machine that
   * requires it in order to read binary files.
   */

	// JDC: because fill_input_buffer() blindly copies INPUT_BUF_SIZE bytes,
	// we need to make sure the file buffer is padded or it may crash
  if ( pic ) {
	*pic = NULL;		// until proven otherwise
  }
  {
		int		len;
		HANDLE  f;

		f = CreateFileW(filename,GENERIC_READ,FILE_SHARE_READ,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);
		if ( !f ) {
			return FALSE;
		}
		len = GetFileSize(f, &szHigh);
		//if ( timestamp ) {
			//BY_HANDLE_FILE_INFORMATION fi;
			//GetFileInformationByHandle(f,&fi);
			//*timestamp = fi.ftCreationTime;
		//}
		if ( !pic ) {
			CloseHandle( f );
			return FALSE;	// just getting timestamp
		}
		fbuffer = (byte *)malloc( len + 4096 );
		ReadFile(f, fbuffer, len, &szHigh, NULL );
		CloseHandle( f );
  }


  /* Step 1: allocate and initialize JPEG decompression object */

  /* We have to set up the error handler first, in case the initialization
   * step fails.  (Unlikely, but it could happen if you are out of memory.)
   * This routine fills in the contents of struct jerr, and returns jerr's
   * address which we place into the link field in cinfo.
   */
  cinfo.err = jpeg_std_error(&jerr);

  /* Now we can initialize the JPEG decompression object. */
  jpeg_create_decompress(&cinfo);
  //jpeg_CreateDecompress(&cinfo, JPEG_LIB_VERSION,(size_t) sizeof(struct jpeg_decompress_struct));

  /* Step 2: specify data source (eg, a file) */

  jpeg_stdio_src(&cinfo, fbuffer);

  /* Step 3: read file parameters with jpeg_read_header() */

  (void) jpeg_read_header(&cinfo, TRUE );
  /* We can ignore the return value from jpeg_read_header since
   *   (a) suspension is not possible with the stdio data source, and
   *   (b) we passed TRUE to reject a tables-only JPEG file as an error.
   * See libjpeg.doc for more info.
   */

  /* Step 4: set parameters for decompression */

  /* In this example, we don't need to change any of the defaults set by
   * jpeg_read_header(), so we do nothing here.
   */

  /* Step 5: Start decompressor */

  (void) jpeg_start_decompress(&cinfo);
  /* We can ignore the return value since suspension is not possible
   * with the stdio data source.
   */

  /* We may need to do some setup of our own at this point before reading
   * the data.  After jpeg_start_decompress() we have the correct scaled
   * output image dimensions available, as well as the output colormap
   * if we asked for color quantization.
   * In this example, we need to make an output work buffer of the right size.
   */ 

  row_stride = cinfo.output_width * cinfo.output_components;
  *width = cinfo.output_width;
  *height = cinfo.output_height;
  *bpp = cinfo.output_components;

  if(*pic) *pic = realloc(*pic,cinfo.output_components * cinfo.output_width * cinfo.output_height);
  else *pic = malloc(cinfo.output_components * cinfo.output_width * cinfo.output_height);

  /* Step 6: while (scan lines remain to be read) */
  /*           jpeg_read_scanlines(...); */

  /* Here we use the library's state variable cinfo.output_scanline as the
   * loop counter, so that we don't have to keep track ourselves.
   */
  while (cinfo.output_scanline < cinfo.output_height) {
    /* jpeg_read_scanlines expects an array of pointers to scanlines.
     * Here the array is only one element long, but you could ask for
     * more than one scanline at a time if that's more convenient.
     */
	fbuffer = ((*pic)+(cinfo.output_scanline*cinfo.output_width*cinfo.output_components));
    (void) jpeg_read_scanlines(&cinfo, &fbuffer, 1);
  }

  /* Step 7: Finish decompression */

  (void) jpeg_finish_decompress(&cinfo);
  /* We can ignore the return value since suspension is not possible
   * with the stdio data source.
   */

  /* Step 8: Release JPEG decompression object */

  /* This is an important step since it will release a good deal of memory. */
  jpeg_destroy_decompress(&cinfo);

  /* After finish_decompress, we can close the input file.
   * Here we postpone it until after no more JPEG errors are possible,
   * so as to simplify the setjmp error logic above.  (Actually, I don't
   * think that jpeg_destroy can do an error exit, but why assume anything...)
   */
  //free( fbuffer );

  /* At this point you may want to check to see whether any corrupt-data
   * warnings occurred (test whether jerr.pub.num_warnings is nonzero).
   */

  /* And we're done! */
  return TRUE;
}

static int bufSz=0;
__declspec (dllexport) BOOL LoadJPGWithCmnt(const wchar_t *filename,HBITMAP *bm,HDC *dc,
											int *width,int *height, int *bpp, wchar_t **cmnt)//,FILETIME *timestamp) 
{
  struct jpeg_decompress_struct cinfo;
  struct jpeg_error_mgr jerr;
  int row_stride,cmntLn=0,len;
  byte  *fbuffer,*bbuf;
  BITMAPINFO bmi;
  DWORD szHigh;
  HANDLE f;
  HDC d;

  f = CreateFileW(filename,GENERIC_READ,FILE_SHARE_READ,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);
  if (!f) return FALSE;
  cmntLn = MyStringCpy(*cmnt,MAX_PATH,filename);
  (*cmnt)[cmntLn++] = ' ';

  len = GetFileSize(f, &szHigh);
  StringCchPrintfW(&(*cmnt)[cmntLn],MAX_PATH,L"%d bytes; ",len);
  cmntLn += MyStringLength(&(*cmnt)[cmntLn],MAX_PATH);
  fbuffer = (byte *)malloc( len + 4096 );
  ReadFile(f, fbuffer, len, &szHigh, NULL );
  CloseHandle( f );
  cinfo.err = jpeg_std_error(&jerr);
  jpeg_create_decompress(&cinfo);
  jpeg_stdio_src(&cinfo, fbuffer);
  (void) jpeg_read_header(&cinfo, TRUE );
  (void) jpeg_start_decompress(&cinfo);
  row_stride = cinfo.output_width * cinfo.output_components;
  *width = cinfo.output_width;
  *height = cinfo.output_height;
  *bpp = cinfo.output_components;
  StringCchPrintfW(&(*cmnt)[cmntLn],MAX_PATH,L"dims: %dx%dx%d; jpg col.space: %s; out col.space: %s; sc.num: %d ; sc.denom: %d; gamma: %.3f",
				   *width,*height,*bpp,GetJpgColorSpaceStr(&cinfo),GetOutColorSpaceStr(&cinfo),
				   cinfo.scale_num,cinfo.scale_denom,cinfo.output_gamma);

  d = GetDC(GetDesktopWindow());
  *dc = CreateCompatibleDC(d);//d);
  *bm = CreateCompatibleBitmap(d,*width,*height);//bm = CreateBitmap(width,height,1,bpp,NULL);
  ReleaseDC(GetDesktopWindow(),d);
  if(!SelectObject(*dc,*bm))
  {	DeleteObject(*dc);
  	DeleteObject(*bm);
	return FALSE;
  }
  memset(&bmi, 0, sizeof(bmi));
  bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
  bmi.bmiHeader.biWidth = *width;
  bmi.bmiHeader.biHeight = -(*height);
  bmi.bmiHeader.biPlanes = 1;
  bmi.bmiHeader.biBitCount = (*bpp)*8;
  bmi.bmiHeader.biClrUsed = 0;
  bmi.bmiHeader.biCompression = BI_RGB;
  bmi.bmiHeader.biSizeImage = (*width)*(*height)*(*bpp);
  bbuf = _malloca(row_stride);
  while (cinfo.output_scanline < cinfo.output_height) {
	//bbuf = ((*pic)+(cinfo.output_scanline*cinfo.output_width*cinfo.output_components));
    (void) jpeg_read_scanlines(&cinfo, &bbuf, 1);
	SetDIBitsToDevice(*dc,0,cinfo.output_scanline,*width,1,0,0,0,1,bbuf,&bmi,DIB_RGB_COLORS);
  } 
  _freea(bbuf);
  (void) jpeg_finish_decompress(&cinfo);
  jpeg_destroy_decompress(&cinfo);
  free( fbuffer );
  return TRUE;
}

//===================================================================

__declspec (dllexport) void ProcessView$4(wchar_t *pathAndName)
{
STARTUPINFOW si;PROCESS_INFORMATION pi;
wchar_t s[MAX_PATH];int ln = GetModuleFileName(plgnDllInst,s,MAX_PATH-1);
wchar_t *p=wcsrchr(p,'\\');
	MyStringCpy(p+1,MAX_PATH-ln-1,L"jpgViewRel.exe");
	if(!IsFileExist(s)) return FALSE;
	memset(&si,0,sizeof(si));
	CreateProcessW(s,pathAndName,NULL,NULL,FALSE,NORMAL_PRIORITY_CLASS,NULL,NULL,&si,&pi);
}

__declspec (dllexport) BOOL Load$24(wchar_t* pathAndName,HDC* dc,HBITMAP* bm,int* width,int* height,int* bpp)
{
byte *pic=0;BOOL bLoaded;HDC d;int i,w;BITMAPINFO bmi;
	wchar_t *p = wcsrchr(pathAndName,'.');
	if(!p) return FALSE;
	++p;
	if(!_wcsicmp(p,L"jpg"))
		bLoaded = LoadJPG(pathAndName, &pic, width, height, bpp);
	else if(!_wcsicmp(p,L"jpeg"))
		bLoaded = LoadJPG(pathAndName, &pic, width, height, bpp);
	if(!bLoaded) 
	{	free(pic);
		return bLoaded;
	}

	d = GetDC(GetDesktopWindow());
	*dc = CreateCompatibleDC(d);//d);
	*bm = CreateCompatibleBitmap(d,*width,*height);//bm = CreateBitmap(width,height,1,bpp,NULL);
	ReleaseDC(GetDesktopWindow(),d);
	if(!SelectObject(*dc,*bm))
	{	DeleteObject(*dc);
		DeleteObject(*bm);
		ReleaseDC(GetDesktopWindow(),d);
		return FALSE;
	}

	memset(&bmi, 0, sizeof(bmi));
	bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
	bmi.bmiHeader.biWidth = *width;
	bmi.bmiHeader.biHeight = -(*height);
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biBitCount = (*bpp)*8;
    bmi.bmiHeader.biCompression = BI_RGB;
	bmi.bmiHeader.biSizeImage = (*width)*(*height)*(*bpp);
	for(i=0; i<(*height); i++)//w = SetDIBitsToDevice(*dc,0,0,*width,*height,0,0,0,*height,pic,&bmi,DIB_RGB_COLORS);
		w = SetDIBitsToDevice(*dc,0,i,*width,1,0,0,0,1,pic+i*(*width)*(*bpp),&bmi,DIB_RGB_COLORS);
	free(pic);
	return bLoaded;
}

wchar_t* GetJpgColorSpaceStr(j_decompress_ptr cinfo)
{
	switch(cinfo->jpeg_color_space)
	{	case JCS_YCbCr:
			return L"JCS_YCbCr";
		case JCS_GRAYSCALE:
			return L"JCS_GRAYSCALE";
		case JCS_RGB:
			return L"JCS_RGB";
		case JCS_CMYK:
			return L"JCS_CMYK";
		case JCS_YCCK:
			return L"JCS_YCCK";
	}
	return L"JCS_UNKNOWN";
}

wchar_t* GetOutColorSpaceStr(j_decompress_ptr cinfo)
{
	switch(cinfo->out_color_space)
	{	case JCS_YCbCr:
			return L"JCS_YCbCr";
		case JCS_GRAYSCALE:
			return L"JCS_GRAYSCALE";
		case JCS_RGB:
			return L"JCS_RGB";
		case JCS_CMYK:
			return L"JCS_CMYK";
		case JCS_YCCK:
			return L"JCS_YCCK";
	}
	return L"JCS_UNKNOWN";
}