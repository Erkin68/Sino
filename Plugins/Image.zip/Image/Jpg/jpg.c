#include "windows.h"
#include "strsafe.h"
#include "Plugins_C.h"
#include "resource.h"
#include "windows.h"
#include "jpeglib frFile\jpeglib.h"
#include <malloc.h>
//#include <jpeglib\setjmp.h>



typedef unsigned char byte;


extern int plgId;
extern HMODULE plgnDllInst;

extern void msg(HWND,DWORD,LPWSTR,LPWSTR);

INT_PTR CALLBACK ExstngActnDlgProc(HWND,UINT,WPARAM,LPARAM);
wchar_t* GetJpgColorSpaceStr(j_decompress_ptr);
wchar_t* GetOutColorSpaceStr(j_decompress_ptr);

typedef void (*UnpackProgressRoutine_t)(unsigned __int64,unsigned __int64);
typedef HANDLE (WINAPI *FindFirstFileEx_t)(LPCTSTR,FINDEX_INFO_LEVELS,LPVOID,FINDEX_SEARCH_OPS,LPVOID,DWORD);
extern FindFirstFileEx_t MyFindFirstFileEx;

saveOptions_t saveOptions;
readOptions_t readOptions;

__declspec (dllexport) int GetPluginType()
{
	return 202;
}

__declspec (dllexport) const wchar_t* GetPluginDescription()
{
wchar_t mnuStr[64];
	if(GetEnvironmentVariableW(L"languge",mnuStr,64))//Language instartup qo'yadur;
	{	if(!wcscmp(mnuStr,L"russian"))
			return L"Sino ������ ��������� jpg-������, ������ 1.1";
		else if(!wcscmp(mnuStr,L"uzbekl"))
			return L"Sino jpg-fayllarni ochuvchi plagin, versiya 1.1";
		else if(!wcscmp(mnuStr,L"uzbekk"))
			return L"Sino jpg-��������� ������ ������, ������ 1.1";
		else//if(wcscmp(mnuStr,L"Exit")
			return L"Sino jpg-image view plugin version 1.1";
	}
	//else 
	return L"Sino jpg-image viewplugin version 1.1";
}

__declspec (dllexport) const wchar_t* GetPluginName()
{
	return L"Jpeg plugin for Sino.";
}

__declspec (dllexport) const wchar_t *GetImgExtnsn$4(int t)
{
	switch(t)
	{	case 0:
			return L"jpg";
		case 1:
			return L"jpeg";
	}
	return NULL;//end of enum
}

void saveOpt()
{	
	//saveOptions(plgId,&item,sizeof(item));
}

__declspec (dllexport) void SetId$4(int id)
{
	plgId = id;
	//readOptions(id,&item,sizeof(item));
}

__declspec (dllexport) VOID SetCallbacks$4xxx(LPVOID frstCallback,...)
{
va_list args;
	va_start(args, frstCallback);//1
	saveOptions = (saveOptions_t)va_arg(args, LPVOID);//7
	readOptions = (readOptions_t)va_arg(args, LPVOID);//8
va_end (args);
}

struct my_error_mgr
{
  struct jpeg_error_mgr pub;	/* "public" fields */
  DWORD /*jmp_buf*/ setjmp_buffer;	/* for return to caller */
};

typedef struct my_error_mgr * my_error_ptr;

METHODDEF(void)
my_error_exit (j_common_ptr cinfo)
{
  /* cinfo->err really points to a my_error_mgr struct, so coerce pointer */
  my_error_ptr myerr = (my_error_ptr) cinfo->err;

  /* Always display the message. */
  /* We could postpone this until after returning, if we chose. */
  (*cinfo->err->output_message) (cinfo);

  /* Return control to the setjmp point */
  //longjmp(myerr->setjmp_buffer, 1);
}

void jpg_Error( const char *fmt, ... )
{
	va_list		argptr;
	char		msg[2048];

	va_start (argptr,fmt);
	vsprintf (msg,fmt,argptr);
	va_end (argptr);

	MessageBoxA(NULL, "Error", msg, MB_OK );
}

void jpg_Printf( const char *fmt, ... )
{
	va_list		argptr;
	char		msg[2048];

	va_start (argptr,fmt);
	vsprintf (msg,fmt,argptr);
	va_end (argptr);

	MessageBoxA(NULL, "Error", msg, MB_OK );
}

__declspec (dllexport) BOOL LoadJPG(const wchar_t *filename,byte **pic,int *width,int *height, int *bpp)
{
  /* This struct contains the JPEG decompression parameters and pointers to
   * working space (which is allocated as needed by the JPEG library).
   */
  struct jpeg_decompress_struct cinfo;
  /* We use our private extension JPEG error handler.
   * Note that this struct must live as long as the main JPEG parameter
   * struct, to avoid dangling-pointer problems.
   */
  struct my_error_mgr jerr;
  /* More stuff */
  FILE * infile;		/* source file */
//JSAMPARRAY buffer;		/* Output row buffer */
  int row_stride;
  BYTE *buffer;



  /* In this example we want to open the input file before doing anything else,
   * so that the setjmp() error recovery below can assume the file is open.
   * VERY IMPORTANT: use "b" option to fopen() if you are on a machine that
   * requires it in order to read binary files.
   */

  if ((infile = _wfopen(filename, L"rb")) == NULL)
    return 0;

  /* Step 1: allocate and initialize JPEG decompression object */

  /* We set up the normal JPEG error routines, then override error_exit. */
  cinfo.err = jpeg_std_error(&jerr.pub);
  jerr.pub.error_exit = my_error_exit;
  /* Establish the setjmp return context for my_error_exit to use. */

__try
{
  /* Now we can initialize the JPEG decompression object. */
  jpeg_create_decompress(&cinfo);

  /* Step 2: specify data source (eg, a file) */

  jpeg_stdio_src(&cinfo, infile);

  /* Step 3: read file parameters with jpeg_read_header() */

  (void) jpeg_read_header(&cinfo, TRUE);
  /* We can ignore the return value from jpeg_read_header since
   *   (a) suspension is not possible with the stdio data source, and
   *   (b) we passed TRUE to reject a tables-only JPEG file as an error.
   * See libjpeg.txt for more info.
   */

  /* Step 4: set parameters for decompression */

  /* In this example, we don't need to change any of the defaults set by
   * jpeg_read_header(), so we do nothing here.
   */

  /* Step 5: Start decompressor */

  (void) jpeg_start_decompress(&cinfo);
  /* We can ignore the return value since suspension is not possible
   * with the stdio data source.
   */

  /* We may need to do some setup of our own at this point before reading
   * the data.  After jpeg_start_decompress() we have the correct scaled
   * output image dimensions available, as well as the output colormap
   * if we asked for color quantization.
   * In this example, we need to make an output work buffer of the right size.
   */ 
  *width = cinfo.output_width;
  *height = cinfo.output_height;
  *bpp = cinfo.output_components;
  row_stride = cinfo.output_width * cinfo.output_components;

  if(*pic) *pic = realloc(*pic,cinfo.output_width*cinfo.output_height*cinfo.output_components);
  else *pic = malloc(cinfo.output_width*cinfo.output_height*cinfo.output_components);

  /* Step 6: while (scan lines remain to be read) */
  /*           jpeg_read_scanlines(...); */

  /* Here we use the library's state variable cinfo.output_scanline as the
   * loop counter, so that we don't have to keep track ourselves.
   */
  while (cinfo.output_scanline < cinfo.output_height) {
    /* jpeg_read_scanlines expects an array of pointers to scanlines.
     * Here the array is only one element long, but you could ask for
     * more than one scanline at a time if that's more convenient.
     */
	buffer = (JSAMPARRAY)((*pic)+(row_stride*cinfo.output_scanline));
    (void) jpeg_read_scanlines(&cinfo, &buffer, 1);
  } 

  /* Step 7: Finish decompression */

  (void) jpeg_finish_decompress(&cinfo);
  /* We can ignore the return value since suspension is not possible
   * with the stdio data source.
   */

  /* Step 8: Release JPEG decompression object */

  /* This is an important step since it will release a good deal of memory. */
  jpeg_destroy_decompress(&cinfo);

  /* After finish_decompress, we can close the input file.
   * Here we postpone it until after no more JPEG errors are possible,
   * so as to simplify the setjmp error logic above.  (Actually, I don't
   * think that jpeg_destroy can do an error exit, but why assume anything...)
   */
  fclose(infile);
}
__except(1)
  {
    jpeg_destroy_decompress(&cinfo);
    fclose(infile);
    return 0;
  }
  


  /* At this point you may want to check to see whether any corrupt-data
   * warnings occurred (test whether jerr.pub.num_warnings is nonzero).
   */
  /* And we're done! */
  return 1;
}

static int bufSz=0;
__declspec (dllexport) BOOL LoadJPGWithCmnt(const wchar_t *filename,HBITMAP *bm,HDC *dc,
											int *width,int *height,int *bpp, wchar_t **cmnt)
{
  /* This struct contains the JPEG decompression parameters and pointers to
   * working space (which is allocated as needed by the JPEG library).
   */
  struct jpeg_decompress_struct cinfo;
  /* We use our private extension JPEG error handler.
   * Note that this struct must live as long as the main JPEG parameter
   * struct, to avoid dangling-pointer problems.
   */
  struct my_error_mgr jerr;
  /* More stuff */
  FILE * infile;		/* source file */
//JSAMPARRAY buffer;		/* Output row buffer */
  int row_stride,row_stridePadded,cmntLn=0,i,padding;
  BYTE *buffer,*buffer1;
  HDC d;
  BITMAPINFO bmi;

  /* In this example we want to open the input file before doing anything else,
   * so that the setjmp() error recovery below can assume the file is open.
   * VERY IMPORTANT: use "b" option to fopen() if you are on a machine that
   * requires it in order to read binary files.
   */

  if ((infile = _wfopen(filename, L"rb")) == NULL)
    return 0;
  cmntLn = MyStringCpy(*cmnt,MAX_PATH,filename);
  (*cmnt)[cmntLn++] = ' ';


  /* Step 1: allocate and initialize JPEG decompression object */

  /* We set up the normal JPEG error routines, then override error_exit. */
  cinfo.err = jpeg_std_error(&jerr.pub);
  jerr.pub.error_exit = my_error_exit;
  /* Establish the setjmp return context for my_error_exit to use. */

__try
{
  /* Now we can initialize the JPEG decompression object. */
  jpeg_create_decompress(&cinfo);

  /* Step 2: specify data source (eg, a file) */

  jpeg_stdio_src(&cinfo, infile);

  /* Step 3: read file parameters with jpeg_read_header() */

  (void) jpeg_read_header(&cinfo, TRUE);
  /* We can ignore the return value from jpeg_read_header since
   *   (a) suspension is not possible with the stdio data source, and
   *   (b) we passed TRUE to reject a tables-only JPEG file as an error.
   * See libjpeg.txt for more info.
   */

  /* Step 4: set parameters for decompression */

  /* In this example, we don't need to change any of the defaults set by
   * jpeg_read_header(), so we do nothing here.
   */

  /* Step 5: Start decompressor */

  (void) jpeg_start_decompress(&cinfo);
  /* We can ignore the return value since suspension is not possible
   * with the stdio data source.
   */

  /* We may need to do some setup of our own at this point before reading
   * the data.  After jpeg_start_decompress() we have the correct scaled
   * output image dimensions available, as well as the output colormap
   * if we asked for color quantization.
   * In this example, we need to make an output work buffer of the right size.
   */ 
  *width = cinfo.output_width;
  *height = cinfo.output_height;
  *bpp = cinfo.output_components;
  row_stride = cinfo.output_width * cinfo.output_components;
  StringCchPrintfW(&(*cmnt)[cmntLn],MAX_PATH,L"dims: %dx%dx%d; jpg col.space: %s; out col.space: %s; sc.num: %d; sc.denom: %d; out gamma: %.3f",
				   *width,*height,*bpp,GetJpgColorSpaceStr(&cinfo),GetOutColorSpaceStr(&cinfo),
				   cinfo.scale_num,cinfo.scale_denom,cinfo.output_gamma);

  d = GetDC(GetDesktopWindow());
  *dc = CreateCompatibleDC(d);//d);
  *bm = CreateCompatibleBitmap(d,*width,*height);//bm = CreateBitmap(width,height,1,bpp,NULL);
  ReleaseDC(GetDesktopWindow(),d);
  if(!SelectObject(*dc,*bm))
  {	DeleteObject(*dc);
  	DeleteObject(*bm);
	return FALSE;
  }
  memset(&bmi, 0, sizeof(bmi));
  bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
  bmi.bmiHeader.biWidth = *width;
  bmi.bmiHeader.biHeight = -(*height);
  bmi.bmiHeader.biPlanes = 1;
  bmi.bmiHeader.biBitCount = (*bpp)*8;
  bmi.bmiHeader.biClrUsed = 0;
  bmi.bmiHeader.biCompression = BI_RGB;
  bmi.bmiHeader.biSizeImage = (*width)*(*height)*(*bpp);

  /*buffer = malloc(row_stride);
  while (cinfo.output_scanline < cinfo.output_height)
  {(void) jpeg_read_scanlines(&cinfo, &buffer, 1);
	SetDIBitsToDevice(*dc,0,cinfo.output_scanline,*width,1,0,0,0,1,buffer,&bmi,DIB_RGB_COLORS);
  }*/
  row_stridePadded = (row_stride + 3) & ~3;
  padding=row_stridePadded-row_stride;
  buffer = malloc(row_stridePadded*(*height));
  buffer1=buffer;
  while (cinfo.output_scanline < cinfo.output_height)
  {(void) jpeg_read_scanlines(&cinfo, &buffer1, 1);
   buffer1 += row_stridePadded;
   for(i=0; i<padding; i++)
    *(buffer1-padding+i)=0;
  }
  SetDIBitsToDevice(*dc,0,0,*width,*height,0,0,0,*height,buffer,&bmi,DIB_RGB_COLORS);

  free(buffer);

  /* Step 7: Finish decompression */

}
__except(1)
  {(void) jpeg_finish_decompress(&cinfo);
    jpeg_destroy_decompress(&cinfo);
    fclose(infile);
    return 0;
  }

  (void) jpeg_finish_decompress(&cinfo);
  /* We can ignore the return value since suspension is not possible
   * with the stdio data source.
   */

  /* Step 8: Release JPEG decompression object */

  /* This is an important step since it will release a good deal of memory. */
  jpeg_destroy_decompress(&cinfo);

  /* After finish_decompress, we can close the input file.
   * Here we postpone it until after no more JPEG errors are possible,
   * so as to simplify the setjmp error logic above.  (Actually, I don't
   * think that jpeg_destroy can do an error exit, but why assume anything...)
   */
  fclose(infile);
  


  /* At this point you may want to check to see whether any corrupt-data
   * warnings occurred (test whether jerr.pub.num_warnings is nonzero).
   */
  /* And we're done! */
  return 1;
}

//===================================================================

__declspec (dllexport) BOOL Load$24(wchar_t* pathAndName,HDC* dc,HBITMAP* bm,int* width,int* height,int* bpp)
{
byte *pic=0,*ppic,*buffer,*buffer1;
BOOL bLoaded=FALSE;HDC d;BITMAPINFO bmi;
int i,k,row_stride,row_stridePadded,padding;
	wchar_t *p = wcsrchr(pathAndName,'.');
	if(!p) return FALSE;
	++p;
	if(!_wcsicmp(p,L"jpg"))
		bLoaded = LoadJPG(pathAndName, &pic, width, height, bpp);
	else if(!_wcsicmp(p,L"jpeg"))
		bLoaded = LoadJPG(pathAndName, &pic, width, height, bpp);
	if(!bLoaded) 
	{	free(pic);
		return bLoaded;
	}	

	d = GetDC(GetDesktopWindow());
	*dc = CreateCompatibleDC(d);//d);
	*bm = CreateCompatibleBitmap(d,*width,*height);//bm = CreateBitmap(width,height,1,bpp,NULL);
	ReleaseDC(GetDesktopWindow(),d);
	if(!SelectObject(*dc,*bm))
	{	DeleteObject(*dc);
		DeleteObject(*bm);
		return FALSE;
	}

	memset(&bmi, 0, sizeof(bmi));
	bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
	bmi.bmiHeader.biWidth = *width;
	bmi.bmiHeader.biHeight = -(*height);
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biBitCount = (*bpp)*8;
    bmi.bmiHeader.biCompression = BI_RGB;
	bmi.bmiHeader.biSizeImage = (*width)*(*height)*(*bpp);

//	for(i=0; i<(*height); i++)//w = SetDIBitsToDevice(*dc,0,0,*width,*height,0,0,0,*height,pic,&bmi,DIB_RGB_COLORS);
//		w = SetDIBitsToDevice(*dc,0,i,*width,1,0,0,0,1,pic+i*(*width)*(*bpp),&bmi,DIB_RGB_COLORS);

	row_stride = (*width)*(*bpp);
	row_stridePadded = (row_stride + 3) & ~3;
	padding=row_stridePadded-row_stride;
	buffer = malloc(row_stridePadded*(*height));
	buffer1=buffer;ppic=pic;
	for(i=0; i<(*height); ++i)
	{(void) memcpy(buffer1,ppic,row_stride);
	 ppic+=row_stride;
	 buffer1 += row_stridePadded;
	 for(k=0; k<padding; k++)
      *(buffer1-padding+k)=0;
	}
	SetDIBitsToDevice(*dc,0,0,*width,*height,0,0,0,*height,buffer,&bmi,DIB_RGB_COLORS);

	free(pic);
	free(buffer);
	return bLoaded;
}

__declspec (dllexport) void ProcessView$4(wchar_t *pathAndName)
{
STARTUPINFOW si;PROCESS_INFORMATION pi;
wchar_t s[MAX_PATH],cmndLn[MAX_PATH],mnuStr[64];
//int ln = GetModuleFileName(plgnDllInst,s,MAX_PATH-1);
	MyStringCpy(s,MAX_PATH-1,MyStringAddModulePath(L"Plugins\\Executables\\imgViewRel.exe"));
	if(!IsFileExist(s)) return;
	
	if(GetEnvironmentVariableW(L"languge",mnuStr,64))//Language instartup qo'yadur;
	{	if(!wcscmp(mnuStr,L"russian"))
			MyStringCpy(cmndLn,18,L" language russian");
		else if(!wcscmp(mnuStr,L"uzbekl"))
			MyStringCpy(cmndLn,17,L" language uzbekl");
		else if(!wcscmp(mnuStr,L"uzbekk"))
			MyStringCpy(cmndLn,17,L" language uzbekk");
	}

	memset(&si,0,sizeof(si));
	MyStringCpy(&cmndLn[1],MAX_PATH-1,pathAndName);
	CreateProcessW(s,cmndLn,NULL,NULL,FALSE,NORMAL_PRIORITY_CLASS,NULL,NULL,&si,&pi);
}

wchar_t* GetJpgColorSpaceStr(j_decompress_ptr cinfo)
{
	switch(cinfo->jpeg_color_space)
	{	case JCS_YCbCr:
			return L"JCS_YCbCr";
		case JCS_GRAYSCALE:
			return L"JCS_GRAYSCALE";
		case JCS_RGB:
			return L"JCS_RGB";
		case JCS_CMYK:
			return L"JCS_CMYK";
		case JCS_YCCK:
			return L"JCS_YCCK";
	}
	return L"JCS_UNKNOWN";
}

wchar_t* GetOutColorSpaceStr(j_decompress_ptr cinfo)
{
	switch(cinfo->out_color_space)
	{	case JCS_YCbCr:
			return L"JCS_YCbCr";
		case JCS_GRAYSCALE:
			return L"JCS_GRAYSCALE";
		case JCS_RGB:
			return L"JCS_RGB";
		case JCS_CMYK:
			return L"JCS_CMYK";
		case JCS_YCCK:
			return L"JCS_YCCK";
	}
	return L"JCS_UNKNOWN";
}