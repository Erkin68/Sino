#include "Image.h"
#include "strsafe.h"
#include "..\..\Operations\MyErrors.h"
#include "..\..\Operations\Execution.h"
#include "..\..\Operations\MyShell\MyShell.h"
#include "..\..\config.h"
#include "..\..\Sino.h"
#include <locale.h>
#include <Psapi.h>


namespace image
{
int numPlugins;
CImagePlgn *plgns=NULL;
extern HWND *prgrsDlg;

wchar_t imgName[MAX_PATH],password[MAX_PATH];
int   srcPanel;



VOID ListImageDirLoadPlugins(wchar_t *path)
{
WIN32_FIND_DATA ff;
HANDLE hf = INVALID_HANDLE_VALUE;
wchar_t s[MAX_PATH];
	int l=MyStringCpy(s,MAX_PATH-1,path);
	if(MyStringRemoveLastCharCheckPre(s,MAX_PATH-1,'*','\\'))
		--l;

	hf = MyFindFirstFileEx(path,FindExInfoStandard,&ff,FindExSearchLimitToDirectories,NULL,0);
	do
	{	if(INVALID_HANDLE_VALUE==hf) return;
		if(FILE_ATTRIBUTE_DIRECTORY & ff.dwFileAttributes)//if(IsDirectory(path, &ff, FALSE))
		{	if(IsCrntOrPrntDirAttrb(ff.cFileName))
			{	int n=MyStringCpy(&s[l],MAX_PATH-1,ff.cFileName);
				MyStringCpy(&s[l+n],MAX_PATH-1-l,L"\\*");
				ListImageDirLoadPlugins(s);
		}	}
		else
			TryLoadPlugin(s,ff.cFileName,l);
	}
	while(FindNextFile(hf, &ff));
	FindClose(hf);
}

VOID FreePlugins()//CArch::~CArch ga qara, ochiq qolib ketgan arxivlar qoladur;
{
	//free(plgns);
	//plgns=NULL;
	//numPlugins=0;
}

VOID LoadPlugins()
{
	numPlugins=0;
	wchar_t *imgPlgPth = MyStringAddModulePath(L"Plugins\\Image\\*");
	ListImageDirLoadPlugins(imgPlgPth);
}

VOID TryLoadPlugin(wchar_t *pth,wchar_t* name,int l)
{//LoadLibrary da exception beradur;
	if(numPlugins>conf::Dlg.totalAllovedArchvr * 5)
	{	Err::msg(hWnd,0,L"There are any image plugins(above 100), ignore others...");
		return;
	}

	MyStringCpy(&pth[l],MAX_PATH-1,name);

	if(!Execution::IsThisValidDllFile(pth))
		return;

BEGIN_TRY


HMODULE hm = LoadLibraryEx(pth,NULL,DONT_RESOLVE_DLL_REFERENCES);
	if(!hm)
	{	Err::msg(hWnd,-1,pth);
		return;
	}

	typedef BOOL (*ProcessView$4_t)(wchar_t*);
	Load$24_t Load$24 = (Load$24_t)GetProcAddress(hm,"Load$24");
	if(!Load$24)
	{	Err::msg(0,-1,L"Load$24 procedure is not founded.");
Fall:	FreeLibrary(hm);
		return;
	}
	ProcessView$4_t ProcessView$4 = (ProcessView$4_t)GetProcAddress(hm,"ProcessView$4");
	if(!ProcessView$4) goto Fall;
	GetImgExtnsn$4_t GetImgExtnsn$4 = (GetImgExtnsn$4_t)GetProcAddress(hm,"GetImgExtnsn$4");
	if(!GetImgExtnsn$4)goto Fall;
	GetPluginType_t GetPluginType = (GetPluginType_t)GetProcAddress(hm,"GetPluginType");
	if(!GetPluginType) goto Fall;
	SetCallbacks$4xxx_t SetCallbacks$4xxx = (SetCallbacks$4xxx_t)GetProcAddress(hm,"SetCallbacks$4xxx");
	if(!SetCallbacks$4xxx) goto Fall;
	GetPluginDescription_t GetPluginDescription = (GetPluginDescription_t)GetProcAddress(hm,"GetPluginDescription");
	if(!GetPluginDescription) goto Fall;
	SetId$4_t SetId$4 = (SetId$4_t)GetProcAddress(hm,"SetId$4");
	if(!SetId$4) goto Fall;

	FreeLibrary(hm);
	hm = LoadLibrary(pth);//DllMain ni yuklasin, endi;
	Load$24 = (Load$24_t)GetProcAddress(hm,"Load$24");
	ProcessView$4 = (ProcessView$4_t)GetProcAddress(hm,"ProcessView$4");
	GetImgExtnsn$4 = (GetImgExtnsn$4_t)GetProcAddress(hm,"GetImgExtnsn$4");
	GetPluginType = (GetPluginType_t)GetProcAddress(hm,"GetPluginType");
	SetCallbacks$4xxx = (SetCallbacks$4xxx_t)GetProcAddress(hm,"SetCallbacks$4xxx");
	GetPluginDescription = (GetPluginDescription_t)GetProcAddress(hm,"GetPluginDescription");
	ShowOptionDialog_t ShowOptionDialog = (ShowOptionDialog_t)GetProcAddress(hm,"ShowOptionDialog");
	SetId$4 = (SetId$4_t)GetProcAddress(hm,"SetId$4");

	int t=GetPluginType();
	if(t!=202) goto Fall;
	MODULEINFO mi;
	GetModuleInformation(GetCurrentProcess(),hm,&mi,sizeof(mi));

	if(!plgns) plgns = (CImagePlgn*)malloc((numPlugins+1)*sizeof(CImagePlgn));
	else  plgns = (CImagePlgn*)realloc(plgns,(numPlugins+1)*sizeof(CImagePlgn));
	plgns[numPlugins].CImagePlgn::CImagePlgn();
	plgns[numPlugins].GetImgExtnsn$4 = GetImgExtnsn$4;
	plgns[numPlugins].GetPluginType = GetPluginType;
	plgns[numPlugins].SetCallbacks$4xxx = SetCallbacks$4xxx;
	plgns[numPlugins].GetPluginDescription = GetPluginDescription;
	plgns[numPlugins].Load$24 = Load$24;
	plgns[numPlugins].ProcessView$4 = ProcessView$4;
	plgns[numPlugins].SetId$4 = SetId$4;

	plgns[numPlugins].type = t;
	if(GetPluginDescription)MyStringCpy(plgns[numPlugins].descrpn,MAX_PATH,(wchar_t*)GetPluginDescription());
	else plgns[numPlugins].descrpn[0]=0;
	if(GetImgExtnsn$4)
	{	for(int i=0; i<16; i++)
		{	MyStringCpy(plgns[numPlugins].extnsn[i],32,(wchar_t*)GetImgExtnsn$4(i));
			if(!plgns[numPlugins].extnsn[i][0])
				break;
	}	}
	else plgns[numPlugins].extnsn[0][0]=0;
	SetCallbacks$4xxx(	CImagePlgn::saveOptions,
						CImagePlgn::readOptions);
	MyStringCpy(plgns[numPlugins].pathAndName,MAX_PATH-1,pth);
	plgns[numPlugins].idNum = numPlugins;
	plgns[numPlugins].SetId$4(numPlugins);

	plgns[numPlugins++].FreePlugin();
END_TRY
{
	Err::msg1(NULL,0,pth,L"Err.loading image plgn.");
}}

BOOL Load$24(wchar_t* pathAndName,HDC* dc,HBITMAP* bm,int* width,int* height,int* bpp)
{
wchar_t *p = wcsrchr(pathAndName,'.');
	if(!p) return FALSE;
	else ++p;
	int l = MyStringLength(p,36);
	for(int i=0; i<numPlugins; i++)
	{	plgns[i].LoadPlugin();
		for(int k=0; k<16; ++k)
		{	if(!_wcsnicmp(plgns[i].extnsn[k],p,l))
			{	BOOL r = plgns[i].Load$24(pathAndName,dc,bm,width,height,bpp);
				plgns[i].FreePlugin();
				return r;
			}
			if(0==plgns[i].extnsn[k][0])break;
		}
		plgns[i].FreePlugin();
	}
	return FALSE;
}

}//end of namespace;



CImagePlgn::CImagePlgn():hm(0),idNum(0),mRef(0)
{
}

CImagePlgn::~CImagePlgn()
{
}

BOOL CImagePlgn::LoadPlugin()
{	if(0==mRef)
	{	if(!hm)
		{	hm = LoadLibrary(pathAndName);
			if(!hm) return FALSE;
			GetImgExtnsn$4 = (image::GetImgExtnsn$4_t)GetProcAddress(hm,"GetImgExtnsn$4");
			GetPluginType = (image::GetPluginType_t)GetProcAddress(hm,"GetPluginType");
			SetCallbacks$4xxx = (image::SetCallbacks$4xxx_t)GetProcAddress(hm,"SetCallbacks$4xxx");
			GetPluginDescription = (image::GetPluginDescription_t)GetProcAddress(hm,"GetPluginDescription");
			ShowOptionDialog = (image::ShowOptionDialog_t)GetProcAddress(hm,"ShowOptionDialog");
			SetId$4 = (image::SetId$4_t)GetProcAddress(hm,"SetId$4");
			Load$24 = (image::Load$24_t)GetProcAddress(hm,"Load$24");
			ProcessView$4 = (image::ProcessView$4_t)GetProcAddress(hm,"ProcessView$4");
			
			SetCallbacks$4xxx(saveOptions, readOptions);
			SetId$4(idNum);
	}	}
	++mRef;
	return TRUE;
}

VOID CImagePlgn::FreePlugin()
{	if(0==mRef)
	{	if(hm) FreeLibrary(hm);
		hm = 0;
		GetImgExtnsn$4 = 0;
		GetPluginType = 0;
		SetCallbacks$4xxx = 0;
		GetPluginDescription = 0;
		ShowOptionDialog = 0;
		SetId$4 = 0;
		ProcessView$4 = 0;
		Load$24 = 0;
		bLoaded = false;
	}
	if(mRef>0)--mRef;
}

BOOL CALLBACK CImagePlgn::readOptions(int plgId,VOID *buf,int bufLen)
{
	if(plgId<0) return FALSE;//|| plgId>fSearchViaF7::numPlugins-1) return FALSE; ni qo'ymaymiz, hali numPlugins 1ta oshmagan bo'lishi mumkin;
DWORD rb;
wchar_t s[MAX_PATH];MyStringCpy(s,MAX_PATH-1,image::plgns[plgId].pathAndName);//arc->name);
	wchar_t *p = wcsrchr(s,'.');
	if(p) *(p+1) = 0;
	MyStringCat(s,MAX_PATH-1,L"bin");
	HANDLE f = MyFopenViaCrF(s,L"r");//MyStringAddModulePath
	if(!f) return FALSE;
	if(!ReadFile(f,buf,bufLen,&rb,NULL))
		rb=0;
	CloseHandle(f);
	return (rb!=bufLen)?FALSE:TRUE;
}

BOOL CALLBACK CImagePlgn::saveOptions(int plgId,VOID *buf,int bufLen)
{
	if(plgId<0 || plgId>archive::numPlugins*5-1) return FALSE;
DWORD rb;
wchar_t s[MAX_PATH];MyStringCpy(s,MAX_PATH-1,image::plgns[plgId].pathAndName);//arc->name);
	wchar_t *p = wcsrchr(s,'.');
	if(p) *(p+1) = 0;
	MyStringCat(s,MAX_PATH-1,L"bin");
	HANDLE f = MyFopenViaCrF(s,L"w");//MyStringAddModulePath
	if(!f) return FALSE;
	if(!WriteFile(f,buf,bufLen,&rb,NULL))
		rb=0;
	CloseHandle(f);

	if(0==plgId)//Oxirgi dll
	{	if(image::plgns)
			free(image::plgns);
		image::plgns=NULL;
		image::numPlugins=0;
	}
	return (rb!=bufLen)?FALSE:TRUE;
}