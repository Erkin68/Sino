/*
	Contains Dll entry point routine
*/

#define DXTDECOMPRESSOR_EXPORTS

#include "DXTDecompressor.h"

// Defines image decompressor routine
typedef void (__cdecl *PImageDecompressor)(const DWORD, const DWORD, const LPBYTE, PDWORD);
// External definitions for DXT1 backscan image decompression
extern "C" void __cdecl _DXTDImageBackscanDxt1__PURE(const DWORD, const DWORD, const LPBYTE, PDWORD);
extern "C" void __cdecl _DXTDImageBackscanDxt1__SSE(const DWORD, const DWORD, const LPBYTE, PDWORD);
// External definitions for DXT3 backscan image decompression
extern "C" void __cdecl _DXTDImageBackscanDxt3__PURE(const DWORD, const DWORD, const LPBYTE, PDWORD);
extern "C" void __cdecl _DXTDImageBackscanDxt3__SSE(const DWORD, const DWORD, const LPBYTE, PDWORD);
// External definitions for DXT5 backscan image decompression
extern "C" void __cdecl _DXTDImageBackscanDxt5__PURE(const DWORD, const DWORD, const LPBYTE, PDWORD);
extern "C" void __cdecl _DXTDImageBackscanDxt5__SSE(const DWORD, const DWORD, const LPBYTE, PDWORD);

// Configuration options
DXTD_FLAGS dxtdConfig = 0;
// Current DXT1 decompressor
PImageDecompressor dxtdImageBackscanDxt1 = NULL;
// Current DXT3 decompressor
PImageDecompressor dxtdImageBackscanDxt3 = NULL;
// Current DXT5 decompressor
PImageDecompressor dxtdImageBackscanDxt5 = NULL;

// Dll entry point
BOOL WINAPI DllMain(HINSTANCE hInstanceDll, DWORD dwReason, LPVOID)
{
	switch (dwReason)
	{
	case DLL_PROCESS_ATTACH:
		// When attaching Dll to a process, we determine whether the CPU supports
		// SSE so we can choose optimized routines instead of generic ones
		DXTDSetConfiguration(DXTDHasSseSupport() ? DXTD_CONFIG_SSE : 0);
		break;
	case DLL_PROCESS_DETACH:
	case DLL_THREAD_ATTACH:
	case DLL_THREAD_DETACH:
		break;
	}

	// Dll successfuly loaded
	return TRUE;
}

// Gets internal configuration
DXTD_API DXTD_FLAGS DXTD_CALL DXTDGetConfiguration()
{
	return dxtdConfig;
}

// Sets internal configuration
DXTD_API void DXTD_CALL DXTDSetConfiguration(DXTD_FLAGS flags)
{
	dxtdConfig = flags & DXTD_CONFIG_MASK;
	if (flags & DXTD_CONFIG_SSE)
	{
		dxtdConfig |= DXTD_CONFIG_SSE;
		dxtdImageBackscanDxt1 = _DXTDImageBackscanDxt1__SSE;
		dxtdImageBackscanDxt3 = _DXTDImageBackscanDxt3__SSE;
		dxtdImageBackscanDxt5 = _DXTDImageBackscanDxt5__SSE;
	}
	else
	{
		dxtdImageBackscanDxt1 = _DXTDImageBackscanDxt1__PURE;
		dxtdImageBackscanDxt3 = _DXTDImageBackscanDxt3__PURE;
		dxtdImageBackscanDxt5 = _DXTDImageBackscanDxt5__PURE;
	}
}

// Decompresses entire DXT1 image into a backscan bitmap (ie HBITMAP)
DXTD_API DXTD_BOOL DXTD_CALL DXTDImageBackscanDxt1(const DWORD width, const DWORD height,
												   const LPBYTE inputImage, PDWORD outputPixels)
{
	if (width < 4 || height < 4 || width % 4 != 0 || height % 4 != 0)
		return 0;

	dxtdImageBackscanDxt1(width, height, inputImage, outputPixels);

	return 1;
}

// Decompresses entire DXT3 image into a backscan bitmap (ie HBITMAP)
DXTD_API DXTD_BOOL DXTD_CALL DXTDImageBackscanDxt3(const DWORD width, const DWORD height,
												   const LPBYTE inputImage, PDWORD outputPixels)
{
	if (width < 4 || height < 4 || width % 4 != 0 || height % 4 != 0)
		return 0;

	dxtdImageBackscanDxt3(width, height, inputImage, outputPixels);

	return 1;
}

// Decompresses entire DXT5 image into a backscan bitmap (ie HBITMAP)
DXTD_API DXTD_BOOL DXTD_CALL DXTDImageBackscanDxt5(const DWORD width, const DWORD height,
												   const LPBYTE inputImage, PDWORD outputPixels)
{
	if (width < 4 || height < 4 || width % 4 != 0 || height % 4 != 0)
		return 0;

	dxtdImageBackscanDxt5(width, height, inputImage, outputPixels);

	return 1;
}