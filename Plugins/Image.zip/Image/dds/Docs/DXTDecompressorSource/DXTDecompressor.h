/*
	DXT Decompressor
	Copyright (C) 2013 Matej Tomcik
*/

#pragma once

#define WIN32_LEAN_AND_MEAN
#include <Windows.h>

#ifdef DXTDECOMPRESSOR_EXPORTS
#define DXTD_API extern "C"
#else
#define DXTD_API extern "C" __declspec(dllimport)
#endif

#define DXTD_CALL __cdecl

// Enables SSE implementation
#define DXTD_CONFIG_SSE		0x1
#define DXTD_CONFIG_MASK	0x1

#ifdef _WIN64
typedef DWORD64	DXTD_FLAGS;
typedef DWORD64	DXTD_BOOL;
#else
typedef DWORD	DXTD_FLAGS;
typedef DWORD	DXTD_BOOL;
#endif

#pragma region Miscelaneous functions

// Determines whether the CPU supports SSE instructions
DXTD_API DXTD_BOOL DXTD_CALL DXTDHasSseSupport();

// Get CPU vendor ID
DXTD_API void DXTD_CALL DXTDGetCpuVendorID(LPSTR vendorId);

// Gets internal configuration
DXTD_API DXTD_FLAGS DXTD_CALL DXTDGetConfiguration();

// Sets internal configuration
DXTD_API void DXTD_CALL DXTDSetConfiguration(DXTD_FLAGS flags);

// Unpacks RGB565 to RGB24
DXTD_API DWORD DXTD_CALL DXTDUnpack565(DWORD packed);

// Gets RGB565 lookup table
DXTD_API LPDWORD DXTD_CALL DXTDGet565LookupTable();

// Gets DXT3 alpha lookup table. Alpha values are DWORDs masked 0xFF000000
DXTD_API LPDWORD DXTD_CALL DXTDGetAlphaDxt3LookupTable();

// Gets DXT5 alpha lookup table. Alpha values are in groups of 6 bytes
DXTD_API LPBYTE DXTD_CALL DXTDGetAlphaDxt5LookupTable();

// Gets RGB565 value from the lookup table
DXTD_API DWORD DXTD_CALL DXTDLookup565(DWORD packed);

#pragma endregion

#pragma region DXT1

// Decmopresses single DXT1 block
DXTD_API void DXTD_CALL DXTDBlockDxt1(const LPBYTE block, LPDWORD pixels);

// Decompresses entire DXT1 image into a backscan bitmap (ie HBITMAP)
DXTD_API DXTD_BOOL DXTD_CALL DXTDImageBackscanDxt1(const DWORD width, const DWORD height,
												   const LPBYTE inputImage, LPDWORD outputPixels);

// Decmopresses single DXT3 block
DXTD_API void DXTD_CALL DXTDBlockDxt3(const LPBYTE block, LPDWORD pixels);

// Decompresses entire DXT3 image into a backscan bitmap (ie HBITMAP)
DXTD_API DXTD_BOOL DXTD_CALL DXTDImageBackscanDxt3(const DWORD width, const DWORD height,
												   const LPBYTE inputImage, LPDWORD outputPixels);

// Decmopresses single DXT5 block
DXTD_API void DXTD_CALL DXTDBlockDxt5(const LPBYTE block, LPDWORD pixels);

// Decompresses entire DXT5 image into a backscan bitmap (ie HBITMAP)
DXTD_API DXTD_BOOL DXTD_CALL DXTDImageBackscanDxt5(const DWORD width, const DWORD height,
												   const LPBYTE inputImage, LPDWORD outputPixels);

#pragma endregion