﻿function QueryString() {
    var querystring = location.search.substring(1, location.search.length);
    var args = querystring.split('&');
    for (var i = 0; i < args.length; i++) {
        var pair = args[i].split('=');
        
        // Fix broken unescaping
        temp = unescape(pair[0]).split('+');
        name = temp.join(' ');
        temp = unescape(pair[1]).split('+');
        value = temp.join(' ');
        this[name] = value;
    }

    this.get = function (key, defaultValue) {
        var value = this[key];
        if (value == null) {
            value = defaultValue;
        }
        return value;
    }
}

function getURLParameters() {
    var sURL = window.document.URL.toString();

    if (sURL.indexOf("?") > 0) {
        var arrParams = sURL.split("?");
        var arrURLParams = arrParams[1].split("&");
        var arrParamNames = new Array(arrURLParams.length);
        var arrParamValues = new Array(arrURLParams.length);

        var i = 0;
        for (i = 0; i < arrURLParams.length; i++) {
            var sParam = arrURLParams[i].split("=");

            arrParamNames[i] = sParam[0];
            if (sParam[1] != "")
                arrParamValues[i] = unescape(sParam[1]);
            else
                arrParamValues[i] = "No Value";
        }

        return arrParamNames[0] + "=" + arrParamValues[0];
    }
    else {
        return "";
    }
}

function getURLParametersByName(paramName) {
    var sURL = window.document.URL.toString();
    var foundNameIndex = -1;

    if (sURL.indexOf("?") > 0) {
        var arrParams = sURL.split("?");
        var arrURLParams = arrParams[1].split("&");
        var arrParamNames = new Array(arrURLParams.length);
        var arrParamValues = new Array(arrURLParams.length);

        var i = 0;
        for (i = 0; i < arrURLParams.length; i++) {
            var sParam = arrURLParams[i].split("=");

            arrParamNames[i] = sParam[0];
            if (sParam[1] != "")
                arrParamValues[i] = unescape(sParam[1]);
            else
                arrParamValues[i] = "No Value";

            if (sParam[0] == paramName) {
                foundNameIndex = i;
                break;
            }
        }

        if (foundNameIndex > -1) {
            return arrParamNames[foundNameIndex] + "=" + arrParamValues[foundNameIndex];
        }
        else {
            return "";
        }
    }
    else {
        return "";
    }
}

function ReplaceAll(Source, stringToFind, stringToReplace) {
    var temp = Source;
    var index = temp.indexOf(stringToFind);
    while (index != -1) {
        temp = temp.replace(stringToFind, stringToReplace);
        index = temp.indexOf(stringToFind);
    }
    return temp;
}

function getParams() {
    var params = '';
    var currentlocation = document.location.href;
    try {
        var questionMarkPos = currentlocation.indexOf('?');
        if (questionMarkPos >= 0) {
            params = currentlocation.substring(questionMarkPos+1);
            if (params.length > 0) {
                params = ReplaceAll(params, '=', '-equals-');
                params = ReplaceAll(params, '&', '-ampersand-');
            }
        }
    }
    catch (err) {
        // TODO - exception handling
    }

    return params;
}
