﻿function forceNumbers(e, element) {
    if (e.which == 13) return false;
    c = element.val().replace(/[A-Za-z\s]/g, '');
    element.val(c);
}

function validateCountryCode(str) {
    var flag = false;
    if (str != '') {
      flag = validateTelephoneAreaCode(str);   
    }
    return flag;
}

function validateTelephoneAreaCode(str) {
    var flag = false;

    if (str != '') {
        var filter = /^\d{0,4}$/;
        flag = filter.test(str);
    }
    return flag;
}

function validateTelephoneNumber(str) {
    var filter = /^\d{6,19}$/;
    return (filter.test(str));
}
 
function validateWholeTelephoneNumber(str) {
    var filter = /^\d{6,19}$/;
    return (filter.test(str));
}

function validateEmail(email) {
    var reg = /^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$/;
    return (reg.test(email) && email.length >= 8);
}



function checkEmailDomain(email) {
    if (validateEmail(email)) {
        var remail = email.split("@");
        $.ajax({
            type: "GET",
            url: location.protocol + "//" + apiDomain + "/validation/domain",
            data: "domain=" + remail[1],
            dataType: 'jsonp',
            jsonp: 'callback',
            async: false,
            success: function (result) {
                if (result) {
                    validMailDomain = true;
                }
                else {
                    validMailDomain = false;
                }
            },
            error: function (jqXHR, textStatus, errorThrown) {
                if (errorThrown.indexof("was not called") == -1) {
                    alert('error');
                }
            }

        });
    } else {
        validMailDomain = false;
    }
}