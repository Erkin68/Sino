﻿//Countries
function CountryObject(CountryId, CountryName) { this.CountryId = CountryId; this.CountryName = CountryName; } var arrCountryList = new Array(); arrCountryList[0] = new CountryObject(-1, 'Select Country'); arrCountryList[1] = new CountryObject(3, 'Afghanistan'); arrCountryList[2] = new CountryObject(6, 'Albania'); arrCountryList[3] = new CountryObject(59, 'Algeria'); arrCountryList[4] = new CountryObject(12, 'American Samoa'); arrCountryList[5] = new CountryObject(1, 'Andorra'); arrCountryList[6] = new CountryObject(9, 'Angola'); arrCountryList[7] = new CountryObject(5, 'Anguilla'); arrCountryList[8] = new CountryObject(248, 'Antarctica'); arrCountryList[9] = new CountryObject(4, 'Antigua and Barbuda'); arrCountryList[10] = new CountryObject(11, 'Argentina'); arrCountryList[11] = new CountryObject(7, 'Armenia'); arrCountryList[12] = new CountryObject(15, 'Aruba'); arrCountryList[13] = new CountryObject(251, 'Ascension Island'); arrCountryList[14] = new CountryObject(14, 'Australia'); arrCountryList[15] = new CountryObject(13, 'Austria'); arrCountryList[16] = new CountryObject(16, 'Azerbaijan'); arrCountryList[17] = new CountryObject(30, 'Bahamas'); arrCountryList[18] = new CountryObject(23, 'Bahrain'); arrCountryList[19] = new CountryObject(19, 'Bangladesh'); arrCountryList[20] = new CountryObject(18, 'Barbados'); arrCountryList[21] = new CountryObject(34, 'Belarus'); arrCountryList[22] = new CountryObject(20, 'Belgium'); arrCountryList[23] = new CountryObject(35, 'Belize'); arrCountryList[24] = new CountryObject(25, 'Benin'); arrCountryList[25] = new CountryObject(26, 'Bermuda'); arrCountryList[26] = new CountryObject(31, 'Bhutan'); arrCountryList[27] = new CountryObject(28, 'Bolivia'); arrCountryList[28] = new CountryObject(17, 'Bosnia and Herzegovina'); arrCountryList[29] = new CountryObject(33, 'Botswana'); arrCountryList[30] = new CountryObject(32, 'Bouvet Island'); arrCountryList[31] = new CountryObject(29, 'Brazil'); arrCountryList[32] = new CountryObject(102, 'British Indian Ocean Territory'); arrCountryList[33] = new CountryObject(230, 'British Virgin Islands'); arrCountryList[34] = new CountryObject(27, 'Brunei Darussalam'); arrCountryList[35] = new CountryObject(22, 'Bulgaria'); arrCountryList[36] = new CountryObject(21, 'Burkina Faso'); arrCountryList[37] = new CountryObject(24, 'Burundi'); arrCountryList[38] = new CountryObject(112, 'Cambodia'); arrCountryList[39] = new CountryObject(45, 'Cameroon'); arrCountryList[40] = new CountryObject(36, 'Canada'); arrCountryList[41] = new CountryObject(254, 'Canary Islands'); arrCountryList[42] = new CountryObject(50, 'Cape Verde'); arrCountryList[43] = new CountryObject(119, 'Cayman Islands'); arrCountryList[44] = new CountryObject(39, 'Central African Republic'); arrCountryList[45] = new CountryObject(206, 'Chad'); arrCountryList[46] = new CountryObject(44, 'Chile'); arrCountryList[47] = new CountryObject(46, 'China'); arrCountryList[48] = new CountryObject(51, 'Christmas Island'); arrCountryList[49] = new CountryObject(37, 'Cocos (Keeling) Islands'); arrCountryList[50] = new CountryObject(47, 'Colombia'); arrCountryList[51] = new CountryObject(114, 'Comoros'); arrCountryList[52] = new CountryObject(38, 'Congo'); arrCountryList[53] = new CountryObject(40, 'Congo - The Democratic Republic'); arrCountryList[54] = new CountryObject(43, 'Cook Islands'); arrCountryList[55] = new CountryObject(48, 'Costa Rica'); arrCountryList[56] = new CountryObject(42, 'Cote D"Ivoire (ivory Coast)'); arrCountryList[57] = new CountryObject(95, 'Croatia'); arrCountryList[58] = new CountryObject(49, 'Cuba'); arrCountryList[59] = new CountryObject(52, 'Cyprus'); arrCountryList[60] = new CountryObject(53, 'Czech Republic'); arrCountryList[61] = new CountryObject(56, 'Denmark'); arrCountryList[62] = new CountryObject(252, 'Diego Garcia'); arrCountryList[63] = new CountryObject(55, 'Djibouti'); arrCountryList[64] = new CountryObject(57, 'Dominica'); arrCountryList[65] = new CountryObject(58, 'Dominican Republic'); arrCountryList[66] = new CountryObject(215, 'East Timor'); arrCountryList[67] = new CountryObject(60, 'Ecuador'); arrCountryList[68] = new CountryObject(62, 'Egypt'); arrCountryList[69] = new CountryObject(202, 'El Salvador'); arrCountryList[70] = new CountryObject(85, 'Equatorial Guinea'); arrCountryList[71] = new CountryObject(64, 'Eritrea'); arrCountryList[72] = new CountryObject(61, 'Estonia'); arrCountryList[73] = new CountryObject(66, 'Ethiopia'); arrCountryList[74] = new CountryObject(69, 'Falkland Islands'); arrCountryList[75] = new CountryObject(71, 'Faroe Islands'); arrCountryList[76] = new CountryObject(68, 'Fiji'); arrCountryList[77] = new CountryObject(67, 'Finland'); arrCountryList[78] = new CountryObject(72, 'France'); arrCountryList[79] = new CountryObject(73, 'France - Metropolitan'); arrCountryList[80] = new CountryObject(78, 'French Guiana'); arrCountryList[81] = new CountryObject(169, 'French Polynesia'); arrCountryList[82] = new CountryObject(207, 'French Southern Territories'); arrCountryList[83] = new CountryObject(74, 'Gabon'); arrCountryList[84] = new CountryObject(82, 'Gambia'); arrCountryList[85] = new CountryObject(247, 'Gaza'); arrCountryList[86] = new CountryObject(77, 'Georgia'); arrCountryList[87] = new CountryObject(54, 'Germany'); arrCountryList[88] = new CountryObject(79, 'Ghana'); arrCountryList[89] = new CountryObject(80, 'Gibraltar'); arrCountryList[90] = new CountryObject(86, 'Greece'); arrCountryList[91] = new CountryObject(81, 'Greenland'); arrCountryList[92] = new CountryObject(76, 'Grenada'); arrCountryList[93] = new CountryObject(84, 'Guadeloupe'); arrCountryList[94] = new CountryObject(89, 'Guam'); arrCountryList[95] = new CountryObject(88, 'Guatemala'); arrCountryList[96] = new CountryObject(83, 'Guinea'); arrCountryList[97] = new CountryObject(90, 'Guinea-Bissau'); arrCountryList[98] = new CountryObject(91, 'Guyana'); arrCountryList[99] = new CountryObject(96, 'Haiti'); arrCountryList[100] = new CountryObject(93, 'Heard Island and McDonald Islands'); arrCountryList[101] = new CountryObject(94, 'Honduras'); arrCountryList[102] = new CountryObject(92, 'Hong Kong SAR'); arrCountryList[103] = new CountryObject(97, 'Hungary'); arrCountryList[104] = new CountryObject(105, 'Iceland'); arrCountryList[105] = new CountryObject(101, 'India'); arrCountryList[106] = new CountryObject(98, 'Indonesia'); arrCountryList[107] = new CountryObject(104, 'Iran'); arrCountryList[108] = new CountryObject(103, 'Iraq'); arrCountryList[109] = new CountryObject(99, 'Ireland'); arrCountryList[110] = new CountryObject(100, 'Israel'); arrCountryList[111] = new CountryObject(106, 'Italy'); arrCountryList[112] = new CountryObject(107, 'Jamaica'); arrCountryList[113] = new CountryObject(109, 'Japan'); arrCountryList[114] = new CountryObject(108, 'Jordan'); arrCountryList[115] = new CountryObject(120, 'Kazakstan'); arrCountryList[116] = new CountryObject(110, 'Kenya'); arrCountryList[117] = new CountryObject(113, 'Kiribati'); arrCountryList[118] = new CountryObject(249, 'Kosovo'); arrCountryList[119] = new CountryObject(118, 'Kuwait'); arrCountryList[120] = new CountryObject(111, 'Kyrgyzstan'); arrCountryList[121] = new CountryObject(121, 'Laos'); arrCountryList[122] = new CountryObject(130, 'Latvia'); arrCountryList[123] = new CountryObject(122, 'Lebanon'); arrCountryList[124] = new CountryObject(127, 'Lesotho'); arrCountryList[125] = new CountryObject(126, 'Liberia'); arrCountryList[126] = new CountryObject(131, 'Libya'); arrCountryList[127] = new CountryObject(124, 'Liechtenstein'); arrCountryList[128] = new CountryObject(128, 'Lithuania'); arrCountryList[129] = new CountryObject(129, 'Luxembourg'); arrCountryList[130] = new CountryObject(141, 'Macau SAR'); arrCountryList[131] = new CountryObject(137, 'Macedonia - the Former Yugoslav Republic of'); arrCountryList[132] = new CountryObject(135, 'Madagascar'); arrCountryList[133] = new CountryObject(149, 'Malawi'); arrCountryList[134] = new CountryObject(152, 'Malaysia'); arrCountryList[135] = new CountryObject(148, 'Maldives'); arrCountryList[136] = new CountryObject(138, 'Mali'); arrCountryList[137] = new CountryObject(146, 'Malta'); arrCountryList[138] = new CountryObject(136, 'Marshall Islands'); arrCountryList[139] = new CountryObject(143, 'Martinique'); arrCountryList[140] = new CountryObject(144, 'Mauritania'); arrCountryList[141] = new CountryObject(147, 'Mauritius'); arrCountryList[142] = new CountryObject(237, 'Mayotte'); arrCountryList[143] = new CountryObject(151, 'Mexico'); arrCountryList[144] = new CountryObject(70, 'Micronesia'); arrCountryList[145] = new CountryObject(134, 'Moldova'); arrCountryList[146] = new CountryObject(133, 'Monaco'); arrCountryList[147] = new CountryObject(140, 'Mongolia'); arrCountryList[148] = new CountryObject(250, 'Montenegro'); arrCountryList[149] = new CountryObject(145, 'Montserrat'); arrCountryList[150] = new CountryObject(132, 'Morocco'); arrCountryList[151] = new CountryObject(153, 'Mozambique'); arrCountryList[152] = new CountryObject(139, 'Myanmar'); arrCountryList[153] = new CountryObject(154, 'Namibia'); arrCountryList[154] = new CountryObject(163, 'Nauru'); arrCountryList[155] = new CountryObject(162, 'Nepal'); arrCountryList[156] = new CountryObject(160, 'Netherlands'); arrCountryList[157] = new CountryObject(8, 'Netherlands Antilles'); arrCountryList[158] = new CountryObject(155, 'New Caledonia'); arrCountryList[159] = new CountryObject(165, 'New Zealand'); arrCountryList[160] = new CountryObject(159, 'Nicaragua'); arrCountryList[161] = new CountryObject(156, 'Niger'); arrCountryList[162] = new CountryObject(158, 'Nigeria'); arrCountryList[163] = new CountryObject(164, 'Niue'); arrCountryList[164] = new CountryObject(157, 'Norfolk Island'); arrCountryList[165] = new CountryObject(116, 'North Korea'); arrCountryList[166] = new CountryObject(244, 'Northern Ireland'); arrCountryList[167] = new CountryObject(142, 'Northern Mariana Islands'); arrCountryList[168] = new CountryObject(161, 'Norway'); arrCountryList[169] = new CountryObject(166, 'Oman'); arrCountryList[170] = new CountryObject(172, 'Pakistan'); arrCountryList[171] = new CountryObject(179, 'Palau'); arrCountryList[172] = new CountryObject(167, 'Panama'); arrCountryList[173] = new CountryObject(170, 'Papua New Guinea'); arrCountryList[174] = new CountryObject(180, 'Paraguay'); arrCountryList[175] = new CountryObject(168, 'Peru'); arrCountryList[176] = new CountryObject(171, 'Philippines'); arrCountryList[177] = new CountryObject(175, 'Pitcairn'); arrCountryList[178] = new CountryObject(173, 'Poland'); arrCountryList[179] = new CountryObject(178, 'Portugal'); arrCountryList[180] = new CountryObject(176, 'Puerto Rico'); arrCountryList[181] = new CountryObject(181, 'Qatar'); arrCountryList[182] = new CountryObject(182, 'Reunion'); arrCountryList[183] = new CountryObject(183, 'Romania'); arrCountryList[184] = new CountryObject(184, 'Russia'); arrCountryList[185] = new CountryObject(185, 'Rwanda'); arrCountryList[186] = new CountryObject(115, 'Saint Kitts and Nevis'); arrCountryList[187] = new CountryObject(123, 'Saint Lucia'); arrCountryList[188] = new CountryObject(174, 'Saint Pierre and Miquelon'); arrCountryList[189] = new CountryObject(228, 'Saint Vincent and the Grenadines'); arrCountryList[190] = new CountryObject(235, 'Samoa'); arrCountryList[191] = new CountryObject(197, 'San Marino'); arrCountryList[192] = new CountryObject(201, 'Sao Tome and Principe'); arrCountryList[193] = new CountryObject(186, 'Saudi Arabia'); arrCountryList[194] = new CountryObject(198, 'Senegal'); arrCountryList[195] = new CountryObject(245, 'Serbia'); arrCountryList[196] = new CountryObject(188, 'Seychelles'); arrCountryList[197] = new CountryObject(196, 'Sierra Leone'); arrCountryList[198] = new CountryObject(191, 'Singapore'); arrCountryList[199] = new CountryObject(195, 'Slovakia'); arrCountryList[200] = new CountryObject(193, 'Slovenia'); arrCountryList[201] = new CountryObject(187, 'Solomon Islands'); arrCountryList[202] = new CountryObject(199, 'Somalia'); arrCountryList[203] = new CountryObject(239, 'South Africa'); arrCountryList[204] = new CountryObject(87, 'South Georgia'); arrCountryList[205] = new CountryObject(117, 'South Korea'); arrCountryList[206] = new CountryObject(150, 'South Sudan'); arrCountryList[207] = new CountryObject(65, 'Spain'); arrCountryList[208] = new CountryObject(125, 'Sri Lanka'); arrCountryList[209] = new CountryObject(253, 'St. Pierre and Miquelon'); arrCountryList[210] = new CountryObject(192, 'St.Helena'); arrCountryList[211] = new CountryObject(189, 'Sudan'); arrCountryList[212] = new CountryObject(200, 'Suriname'); arrCountryList[213] = new CountryObject(194, 'Svalbard and Jan Mayen'); arrCountryList[214] = new CountryObject(204, 'Swaziland'); arrCountryList[215] = new CountryObject(190, 'Sweden'); arrCountryList[216] = new CountryObject(41, 'Switzerland'); arrCountryList[217] = new CountryObject(203, 'Syria'); arrCountryList[218] = new CountryObject(219, 'Taiwan'); arrCountryList[219] = new CountryObject(210, 'Tajikistan'); arrCountryList[220] = new CountryObject(220, 'Tanzania'); arrCountryList[221] = new CountryObject(209, 'Thailand'); arrCountryList[222] = new CountryObject(208, 'Togo'); arrCountryList[223] = new CountryObject(211, 'Tokelau'); arrCountryList[224] = new CountryObject(214, 'Tonga'); arrCountryList[225] = new CountryObject(217, 'Trinidad and Tobago'); arrCountryList[226] = new CountryObject(213, 'Tunisia'); arrCountryList[227] = new CountryObject(216, 'Turkey'); arrCountryList[228] = new CountryObject(212, 'Turkmenistan'); arrCountryList[229] = new CountryObject(205, 'Turks and Caicos Islands'); arrCountryList[230] = new CountryObject(218, 'Tuvalu'); arrCountryList[231] = new CountryObject(222, 'Uganda'); arrCountryList[232] = new CountryObject(221, 'Ukraine'); arrCountryList[233] = new CountryObject(2, 'United Arab Emirates'); arrCountryList[234] = new CountryObject(75, 'United Kingdom'); arrCountryList[235] = new CountryObject(224, 'United States'); arrCountryList[236] = new CountryObject(223, 'United States Minor Outlying Islands'); arrCountryList[237] = new CountryObject(225, 'Uruguay'); arrCountryList[238] = new CountryObject(226, 'Uzbekistan'); arrCountryList[239] = new CountryObject(233, 'Vanuatu'); arrCountryList[240] = new CountryObject(227, 'Vatican City'); arrCountryList[241] = new CountryObject(229, 'Venezuela'); arrCountryList[242] = new CountryObject(232, 'Vietnam'); arrCountryList[243] = new CountryObject(231, 'Virgin Islands - U.S.'); arrCountryList[244] = new CountryObject(234, 'Wallis and Futuna'); arrCountryList[245] = new CountryObject(246, 'West Bank'); arrCountryList[246] = new CountryObject(63, 'Western Sahara'); arrCountryList[247] = new CountryObject(236, 'Yemen'); arrCountryList[248] = new CountryObject(238, 'Yugoslavia'); arrCountryList[249] = new CountryObject(241, 'Zaire'); arrCountryList[250] = new CountryObject(240, 'Zambia'); arrCountryList[251] = new CountryObject(242, 'Zimbabwe');
// Variables
var validMailDomain = false;
var queryString = new QueryString();
var InsertedPixel = 0;
var afkName;
var pageLanguage;
var apiDomain = 'api.usagc.org';
var htmlDomain = 'html.usagc.org';
// Constants
var ERR_COUNTRY_CODE_TELEPHONE = "- You must select a country code. \n";
var ERR_MOBILE_COUNTRY_CODE_TELEPHONE = "- You must select a mobile country code. \n";
var ERR_TELEPHONE_NUMBER = " - Enter your phone number!";
var ERR_MOBILE_TELEPHONE_NUMBER = " - Enter your mobile phone number!";

var LANGUAGES = ['eng', 'rom', 'pol', 'ind', 'bul', 'ger', 'fin', 'dut', 'tur', 'fra', 'heb', 'rus', 'ita', 'deu', 'jap', 'tha', 'chi', 'prt', 'man', 'spn', 'arb', 'hun', 'jpn', 'swe'];
var LANGUAGES_CODES = [1, 30, 27, 33, 28, 2, 31, 2, 3, 4, 5, 6, 15, 16, 18, 19, 20, 21, 24, 25, 26, 32, 18, 29];
var DEFAULT_AFFILIATE = 'usagce';
var DEFAULT_LANGUAGE = 'eng';
var clickid = 0;
var showPopupPixel = GetPopupPixelParamValue();


function PhoneCodes(CountryId, PhoneCode) {
    this.CountryId = CountryId;
    this.PhoneCode = PhoneCode;
}
var arrPhoneCodes = new Array();
var iCountry = 0;
var isFireVisitStep1 = false;
var waitForSubmit = false;
var waitForRegPixel = false;

var gmt = "";

arrPhoneCodes[iCountry] = new PhoneCodes(0, 0); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(1, 376); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(2, 971); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(3, 93); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(4, 1268); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(5, 1264); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(6, 355); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(7, 374); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(8, 599); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(9, 244); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(11, 54); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(12, 1684); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(13, 43); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(14, 61); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(15, 297); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(16, 994); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(17, 387); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(18, 1246); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(19, 880); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(20, 32); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(21, 226); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(22, 359); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(23, 973); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(24, 257); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(25, 229); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(26, 1441); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(27, 673); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(28, 591); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(29, 55); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(30, 1242); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(31, 975); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(32, 0); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(33, 267); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(34, 375); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(35, 501); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(36, 1613); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(37, 0); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(38, 242); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(39, 236); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(40, 243); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(41, 41); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(42, 225); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(43, 682); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(44, 56); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(45, 237); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(46, 86); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(47, 57); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(48, 506); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(49, 53); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(50, 238); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(51, 61); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(52, 357); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(53, 420); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(54, 49); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(55, 253); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(56, 45); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(57, 1767); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(58, 1809); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(59, 213); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(60, 593); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(61, 372); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(62, 20); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(63, 212); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(64, 291); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(65, 34); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(66, 251); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(67, 358); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(68, 679); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(69, 500); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(70, 691); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(71, 298); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(72, 33); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(73, 33); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(74, 241); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(75, 44); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(76, 1473); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(77, 995); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(78, 594); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(79, 233); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(80, 350); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(81, 299); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(82, 220); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(83, 224); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(84, 590); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(85, 240); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(86, 30); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(87, 0); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(88, 502); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(89, 1671); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(90, 245); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(91, 592); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(92, 852); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(93, 0); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(94, 504); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(95, 385); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(96, 509); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(97, 36); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(98, 62); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(99, 353); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(100, 972); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(101, 91); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(102, 246); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(103, 964); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(104, 98); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(105, 354); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(106, 39); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(107, 1876); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(108, 962); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(109, 81); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(110, 254); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(111, 996); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(112, 855); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(113, 686); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(114, 269); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(115, 1869); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(116, 850); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(117, 82); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(118, 965); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(119, 1345); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(120, 7); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(121, 856); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(122, 961); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(123, 1758); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(124, 423); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(125, 94); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(126, 231); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(127, 266); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(128, 370); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(129, 352); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(130, 371); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(131, 218); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(132, 212); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(133, 377); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(134, 373); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(135, 261); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(136, 692); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(137, 389); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(138, 223); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(139, 95); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(140, 976); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(141, 853); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(142, 1670); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(143, 596); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(144, 222); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(145, 1664); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(146, 356); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(147, 230); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(148, 960); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(149, 265); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(151, 52); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(152, 60); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(153, 258); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(154, 264); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(155, 687); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(156, 227); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(157, 672); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(158, 234); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(159, 505); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(160, 31); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(161, 47); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(162, 977); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(163, 674); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(164, 683); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(165, 64); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(166, 968); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(167, 507); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(168, 51); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(169, 689); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(170, 675); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(171, 63); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(172, 92); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(173, 48); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(174, 508); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(175, 64); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(176, 1787); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(178, 351); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(179, 680); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(180, 595); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(181, 974); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(182, 262); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(183, 40); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(184, 7); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(185, 250); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(186, 966); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(187, 677); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(188, 248); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(189, 249); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(190, 46); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(191, 65); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(192, 290); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(193, 386); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(194, 47); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(195, 421); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(196, 232); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(197, 378); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(198, 221); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(199, 252); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(200, 597); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(201, 239); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(202, 503); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(203, 963); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(204, 268); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(205, 140); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(206, 235); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(207, 156); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(208, 228); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(209, 66); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(210, 992); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(211, 690); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(212, 993); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(213, 216); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(214, 676); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(215, 670); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(216, 90); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(217, 1868); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(218, 688); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(219, 886); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(220, 255); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(221, 380); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(222, 256); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(223, 0); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(224, 1); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(225, 598); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(226, 998); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(227, 391); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(228, 1784); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(229, 58); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(230, 0); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(231, 1284); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(232, 84); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(233, 678); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(234, 681); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(235, 685); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(236, 967); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(237, 269); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(238, 381); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(239, 27); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(240, 260); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(241, 243); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(242, 263); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(243, 0); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(244, 1670); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(245, 381); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(246, 972); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(247, 972); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(248, 672); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(249, 381); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(250, 381); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(251, 247); iCountry++;
arrPhoneCodes[iCountry] = new PhoneCodes(252, 246); iCountry++;







$(document).ready(function () {

    //get gmt from browser
    getClientGmt();

    // Get language from url
    var path = window.location.pathname;
    var filename = path.match(/.*\/([^/]+)\.([^?]+)/i)[1];
    pageLanguage = filename.substr(filename.length - 3, 3).toString();
    if (!$.inArray(pageLanguage, LANGUAGES)) {
        pageLanguage = DEFAULT_LANGUAGE;
    }

    $('#lang').val(pageLanguage);

    var pageLanguageId = LANGUAGES_CODES[$.inArray(pageLanguage, LANGUAGES)];

    //  auto foward to step2 
    var coupon = getURLParam("coupon");
    var accountid = getURLParam("id");

    if (coupon != undefined) {
        if (coupon.indexOf("st2") > 0) {
            if (accountid != undefined) {
                if (accountid != "") {
                    var sUrl = $('#landingpage-form').attr('action') + "?" + GetAllUrlParams();
                    $('#landingpage-form').attr('action', sUrl);
                    $('#landingpage-form').submit();

                }
            }
        }
    }
    //////////////////




    var loc = window.location.href;
    if (loc.indexOf("localhost") > 0) {
        htmlDomain = 'localhost/html';
        apiDomain = 'localhost/Taurus.Sites.API';
    }
    // Configure input restrictions
    $("#cCountryArea,#cTelephoneArea,#cTelephoneNumber,#cCountryAreaMobile,#cTelephoneAreaMobile,#cTelephoneNumberMobile").keyup(function (e) { forceNumbers(e, $(this)) });
    $('#cEmail2, #cEmail, #cFname, #cLname, #cCountryAreaMobile, #cTelephoneAreaMobile, #cTelephoneNumberMobile, #cCountryArea, #cTelephoneNumber, #cTelephoneArea').change(function () {
        handleLeadPixel();
    });
    $('#cCountryTelephone').change(function () {
        handleTelephoneChange('cCountryTelephone', 'cCountryArea');
        $('#cCountryTelephoneMobile').val($('#cCountryTelephone').val());
        handleTelephoneChange('cCountryTelephoneMobile', 'cCountryAreaMobile')
        handleLeadPixel();
    });
    $('#cCountryTelephoneMobile').change(function () {
        handleTelephoneChange('cCountryTelephoneMobile', 'cCountryAreaMobile')
        handleLeadPixel();
    });
    $('#cMarital').change(function () {
        if ($('#spouse-job') != undefined) {
            $('#spouse-job').css('display', $(this).val() == 2 ? '' : 'none');
        }
    });
    $('#submit-btn').click(function () {
        var resultMsg = validateForm();
        if (resultMsg == "") {
            if (waitForRegPixel) {
                $('body').css('opacity', '0.5');
                $('body').append('<img src="http://html.usagc.org/images/circleWait2.gif" style="z-index: 1000; position: absolute; top: 300px; left: 43% " />');
                return submitForm();
            }
        } else {
            alert(resultMsg);
        }
        return false;
    });

    window.submitForm = function () {
        waitForSubmit = true;
        var sUrl = $('#landingpage-form').attr('action') + "?" + GetAllUrlParams();
        $('#landingpage-form').attr('action', sUrl);
        addMissingFields();
        handleLeadPixel();

    }

    // init country fields
    loadCountries('#cCountry,#cCountryTelephone,#cCountryTelephoneMobile');
    // Configure affiliates
    var plist = GetAllUrlParams();

    if (plist.indexOf('.html?afk=') == -1 || plist.indexOf('&afk=') == -1) {
        afkName = queryString.get("afk", DEFAULT_AFFILIATE);
        if (afkName.indexOf('/?') > 0) {
            afkName = afkName.substr(0, afkName.indexOf('/?'));
        }

    }

    // Handle languages dropdown

    if ($("#pagelang") != undefined) {
        $("#pagelang").change(function () {
            var url = $("#pagelang  option:selected").attr('url');
            if (url.indexOf('.html?afk=') == -1 && url.indexOf('&afk') == -1 && plist == '') {
                window.location.href = url + "?afk=" + afkName;
            }
            else if (url.indexOf('&afk') == -1 && url.indexOf('.html?afk=') == -1 && plist != '') {
                window.location.href = url + "&afk=" + afkName;
            }
            else {
                window.location.href = url;
            }
        });
    }


    var params = '';
    try {
        var questionMarkPos = loc.indexOf('?');
        if (questionMarkPos >= 0) {
            params = loc.substring(questionMarkPos + 1);
            //alert('params='+params);
        }




        //    var seperia1= "<script type='text/javascript'> "+
        //    "var google_conversion_id = 1007251464;  "+
        //    "var google_conversion_label = 'buITCLjplwkQiOCl4AM'; " + 
        //    "var google_custom_params = window.google_tag_params; "+
        //    "var google_remarketing_only = true;  "+
        //    "</script>  "+
        //    "<script type='text/javascript' src='//www.googleadservices.com/pagead/conversion.js'>  "+
        //    "</script>  ";
        //     $('body').append(seperia1);

        //    var seperia;
        //    seperia = "<div style='display:inline;'>  "+
        //    "<img height='1' width='1' style='border-style:none;' alt='' src='//googleads.g.doubleclick.net/pagead/viewthroughconversion/1007251464/?value=0&amp;label=buITCLjplwkQiOCl4AM&amp;guid=ON&amp;script=0'/>  "+
        //    "</div>  "+
        //    "</noscript>  "
        //    $('body').append(seperia);



    }




    catch (ex) { }




    if (loc.indexOf('referrer') < 0) {
        // get referer
        var referer = getReferrer();
        if (referer.length > 0) {
            params += "&referrer=" + referer;
        }
    }

    var mailaff = getURLParam("mailaff");
    var accountid = getURLParam("id");
    try {
        fixUrlParams();
    } catch (ex) {
        //alert(ex);
    }
    var pixelParams = '&showpop=' + showPopupPixel;
    GetMediaPixelsCode(35, -1, FireStartupPagePixel, pixelParams);

    //add by Yaron 13.01.2013 - to support VisitStep1 in MailAff - Dynamic HTML step1 in case     
    $('<input id="cVisitStep1" name="cVisitStep1" type="hidden" value="0"></input>').appendTo('#landingpage-form');
    if (isFireVisitStep1 == false) {
        isFireVisitStep1 = true;
        InsertVisitStep1(accountid, mailaff);
    }
});//end ready event

function InsertVisitStep1(iAccountId, iMailAff) {


    if ((iAccountId != "") && (iMailAff != "") && isNumber(iAccountId) && (iMailAff != "undefined")) {

        jQuery.ajax({
            dataType: 'jsonp',
            jsonp: 'callback',
            url: location.protocol + "//" + apiDomain + "/log/MailByAction?sAccId=" + iAccountId + "&sMailAff=" + iMailAff + "&actionId=1",
            success: function (data) {
                if (data == "1") {
                    $('#cVisitStep1').val('1');
                }
                else {
                    $('#cVisitStep1').val('0');
                }
            },
            error: function (jqXHR, textStatus, errorThrown) {
                $('#cVisitStep1').val('0');
                isFireVisitStep1 = false;
            }
        });
    }
}

function isNumber(n) {
    return !isNaN(parseFloat(n)) && isFinite(n);
}

function validateForm() {
    var CountryTelephone = $('#cCountryTelephone').val(); //dropdown
    var CountryArea = $('#cCountryArea').val();
    var TelephoneNumber = $('#cTelephoneNumber').val();
    var CountryTelephoneMobile = $('#cCountryTelephoneMobile').val(); //dropdown
    var CountryAreaMobile = $('#cCountryAreaMobile').val();
    var TelephoneNumberMobile = $('#cTelephoneNumberMobile').val();
    var email = $('#cEmail').val();
    //var email_validation=$('#cEmail2').val()
    //*** this way email_validation is no needed and it will be like email (since user cant enter his email valdation in those pages)
    var email_validation = email;
    var firstName = $('#cFname').val();
    var lastName = $('#cLname').val();
    var birthCountry = $('#cCountry').val();
    var wholeTelephoneNumber = (CountryArea != undefined ? CountryArea : "") +
								(TelephoneNumber != undefined ? TelephoneNumber : "");
    if (validMailDomain == false || !validateEmail(email) || (email_validation != undefined && !validateEmail(email_validation))) {
        return INCORRECT_EMAIL;
    } else if (email_validation != undefined && email != email_validation) {
        return NOT_EQUAL_EMAILS;
    } else if ($.trim(firstName) == '') {
        return MISSING_FIRSTNAME;
    } else if ($.trim(lastName) == '') {
        return MISSING_LASTNAME;
    }
    var validPhone = false;
    var validMobile = false;
    if (TelephoneNumber != '') {
        if (CountryTelephone == "-1" || validateCountryCode(CountryArea) == false) {
            return ERR_COUNTRY_CODE_TELEPHONE;
        }
        else if (validateWholeTelephoneNumber(CountryArea + TelephoneNumber) == false) {
            return INVALID_PHONENUM;
        }
        else {
            validPhone = true;
        }
    }
    if (TelephoneNumberMobile != '') {
        if (CountryTelephoneMobile == "-1" || validateCountryCode(CountryAreaMobile) == false) {
            return ERR_MOBILE_COUNTRY_CODE_TELEPHONE;
        }
        else if (validateWholeTelephoneNumber(CountryAreaMobile + TelephoneNumberMobile) == false) {
            return ERR_MOBILE_TELEPHONE_NUMBER;
        }
        else {
            validMobile = true;
        }
    }

    if ((validPhone == false && validMobile == false) && (TelephoneNumber != '')) //***
    {

        return INVALID_PHONENUM;
    }
    if (birthCountry != undefined && birthCountry == '-1') {
        return INVALID_BIRTHCOUNTRY;
    }
    return '';
}
function loadCountries(dropdownId) {
    var list = $(dropdownId);

    for (var i = 0; i < arrCountryList.length; i++) {
        list.append('<option value=' + arrCountryList[i].CountryId + '>' + arrCountryList[i].CountryName + '</option>');
    }
    MailAffiliateUrl();
}
function getReferrer() {
    var referer = queryString.get('referer', '');
    if (referer == '' && document.referrer && document.referrer != '') {
        referer = document.referrer;
    }
    referer = ReplaceAll(referer, '=', '-equals-');
    referer = ReplaceAll(referer, '&', '-ampersand-');
    referer = ReplaceAll(referer, '?', '-questionmark-');
    referer = ReplaceAll(referer, '\/', '-slash-');
    referer = ReplaceAll(referer, ':', '-colon-');
    return referer;
}
function getParams() {
    var params = '';
    var currentlocation = document.location.href;

    if (currentlocation.indexOf('?') != -1) {
        if (currentlocation.indexOf('/?') > 0) { // for cases that the parent url is masking the landingpage url
            currentlocation = ReplaceAll(currentlocation, '/?', '&');
        }
        currentlocation = currentlocation.split('?');
        if (currentlocation.length == 2) {
            params = currentlocation[1];
            params = ReplaceAll(params, '=', '-equals-');
            params = ReplaceAll(params, '&', '-ampersand-');
        }
    }
    return params;
}
function addMissingFields() {
    if ($('#cGender').val() == undefined) {
        $('#landingpage-form').append('<input type="hidden" name="cGender" id="cGender" value="1" />');
    }
    if ($('#cMarital').val() == undefined) {
        $('#landingpage-form').append('<input type="hidden" name="cMarital" id="cMarital" value="1" />');
    }
    if ($('#cJobS').val() == undefined) {
        $('#landingpage-form').append('<input type="hidden" name="cJobS" id="cJobS" value="1" />');
    }
    if ($('#cJobM').val() == undefined) {
        $('#landingpage-form').append('<input type="hidden" name="cJobM" id="cJobM" value="1" />');
    }
}
function handleLeadPixel() {



    var email = $('#cEmail').val();

    if (waitForSubmit == false) {
        checkEmailDomain(email);
    }




    var firstName = $('#cFname').val();
    var lastName = $('#cLname').val();

    validMailDomain = true; //did this on commonMin only (so reg pixel will fire asap)

    if (!validateEmail(email) || $.trim(firstName) == "" || $.trim(lastName) == "" || validMailDomain == false) {
        return;
    }

    //*** since  validateEmail takes time to return "true", when user enter his details fast he might cant continume and validateEmail will still be fasle 
    //	if (!validateEmail(email) || $.trim(firstName) == "" || $.trim(lastName) == "") {
    //		return;
    //	}



    var emailEncoded = encodeURI(email);
    var FnameEncoded = encodeURI(firstName);
    var LnameEncoded = encodeURI(lastName);
    var Country = $('#cCountry').val() != undefined ? $('#cCountry').val() : "";
    var marr = $('#cMarital').val() != undefined ? ($('#cMarital').is(':radio') ? $('#cMarital:checked').val() : $('#cMarital').val()) : "";
    var jobs = $('#cJobS').val() != undefined ? ($('#cJobS').is(':radio') ? $('#cJobS:checked').val() : $('#cJobS').val()) : "";
    var jobm = $('#cJobM').val() != undefined ? ($('#cJobM').is(':radio') ? $('#cJobM:checked').val() : $('#cJobM').val()) : "";
    var phone = ($('#cCountryArea').val() != undefined ? $('#cCountryArea').val() : "") +
                ($('#cTelephoneArea').val() != undefined ? $('#cTelephoneArea').val() : "") +
                ($('#cTelephoneNumber').val() != undefined ? $('#cTelephoneNumber').val() : "");
    var phoneMobile = ($('#cCountryAreaMobile').val() != undefined ? $('#cCountryAreaMobile').val() : "") +
                      ($('#cTelephoneAreaMobile').val() != undefined ? $('#cTelephoneAreaMobile').val() : "") +
                      ($('#cTelephoneNumberMobile').val() != undefined ? $('#cTelephoneNumberMobile').val() : "");

    var sPhoneCountryCode = ($('#cCountryArea').val() != undefined ? $('#cCountryArea').val() : "");
    var sPhoneAreaCode = ($('#cTelephoneArea').val() != undefined ? $('#cTelephoneArea').val() : "");
    var sPhoneShort = ($('#cTelephoneNumber').val() != undefined ? $('#cTelephoneNumber').val() : "");

    var sMobilePhoneCountryCode = ($('#cCountryAreaMobile').val() != undefined ? $('#cCountryAreaMobile').val() : "");
    var sMobilePhoneAreaCode = ($('#cTelephoneAreaMobile').val() != undefined ? $('#cTelephoneAreaMobile').val() : "");
    var sMobilePhoneShort = ($('#cTelephoneNumberMobile').val() != undefined ? $('#cTelephoneNumberMobile').val() : "");

    var aid = $("#AID").val();

    var qsMisc = getURLParameters();
    var affParams = qsMisc.substring(0);

    var dataToPass = "Fname=" + FnameEncoded + "&Lname=" + LnameEncoded + "&emaill=" + emailEncoded + "&Country=" + Country + "&Phone=" + phone + "&mobilephone=" + phoneMobile + "&marr=" + marr + "&jobs=" + jobs + "&jobm=" + jobm + "&AID=" + aid + "&afk=" + afkName + pageLanguage + "&afkname=" + afkName + "&pagename=step1.aspx&" + affParams;    
    dataToPass += "&PhoneCountryCode=" + sPhoneCountryCode + "&PhoneAreaCode=" + sPhoneAreaCode + "&PhoneShort=" + sPhoneShort + "&MobilePhoneCountryCode=" + sMobilePhoneCountryCode + "&MobilePhoneAreaCode=" + sMobilePhoneAreaCode + "&MobilePhoneShort=" + sMobilePhoneShort + "&gmt=" + gmt;
    
    try {
        if (dataToPass.toLowerCase().indexOf("bta=") == -1) {
            var tmpBta = getURLParametersByName("bta");
            if (tmpBta != "") {
                dataToPass += "&" + tmpBta;
            }
        }

        if (dataToPass.toLowerCase().indexOf("utm_campaign=") == -1) {
            var tmpUtm = getURLParametersByName("utm_campaign");
            if (tmpUtm != "") {
                dataToPass += "&" + tmpUtm;
            }
        }
    }
    catch (err) { }



    $.ajax({
        type: "GET",
        url: location.protocol + "//" + htmlDomain + "/NewAccountPixel.aspx",
        data: dataToPass,
        success: function (msg) {
            var mySplitResult = msg.split(",");
            $("#AID").val(mySplitResult[0]);
            var id = $("#AID").val();
            if (mySplitResult[1] == 'AlreadyPaid') {
                $('#landingpage-form').submit();
            }
            var isMediaPixel = id != '' && id != null && id.length > 0 && aid != id;
            if (isMediaPixel == true) {
                AccountParams = 'USERID=' + id + '&EMAIL=' + emailEncoded + '&lng=' + pageLanguage;
                AccountParams += '&showpop=' + showPopupPixel;
                AccountParams += '&CID=' + GetCidParam();
                GetMediaPixelsCode(51, -1, FireNewAccountPixel, AccountParams);
            }
            // build pixel 
            sRes = mySplitResult[1];
            if (sRes != undefined && sRes.length >= 1 && InsertedPixel == 0) {
                sPixl = sRes;
                //build div than put it on session..
                var el = document.createElement("div");
                el.setAttribute('id', 'divPixel');
                el.style.setAttribute('display', 'block');
                el.innerHTML = sPixl;
                document.body.appendChild(el);
                //Iframe will show the data of pixel from session..
                ifrm = document.createElement("IFRAME");
                ifrm.src = 'NewAccountPixelResult.aspx';
                ifrm.style.width = 24 + "px";
                ifrm.style.height = 28 + "px";
                el.appendChild(ifrm);
                InsertedPixel = 1; //so we know not to put the pixel for the next time..
            }
            if (isMediaPixel == false && waitForSubmit == true) {
                $('#landingpage-form').submit();
            }
        }
    });
}

function getClientGmt() {
    gmt = new Date().getTimezoneOffset() / -60;
    if (isNaN(gmt) || gmt == null || gmt === undefined)
        gmt = "";
    else if (gmt > 0)
    { gmt = "+" + gmt; }

}

function GetPopupPixelParamValue() {
    var showPop;
    var UrlParams = getURLParameters();
    if (UrlParams.indexOf("showpop") >= 0) {
        showPop = queryString.get('showpop', '');
    }
    else {
        showPop = 1;
    }
    return showPop;

}


function GetMediaPixelsCode(keyCode, companyId, callbackfunc, MediaPopupDp) {
    if (companyId == undefined || companyId == '') {
        companyId = null;
    }
    var ajaxUrl = location.protocol + "//" + apiDomain + "/Media/code/" + keyCode + "/" + companyId + "/?" + MediaPopupDp;
    jQuery.ajax({
        type: 'GET',
        url: ajaxUrl,
        async: false,
        contentType: "application/json",
        dataType: 'jsonp',
        jsonp: 'callback',
        success: function (data) {
            if (data != null && data != '') {
                callbackfunc(data);
            }
        },
        error: function (jqXHR, textStatus, errorThrown) {
            // alert('MediaCodeInjector error');
        }
    });
}

function AppendJavascriptPixelToPage(src) {
    $('body').append(src);
}

//registration
function FireNewAccountPixel(data) {
    AppendJavascriptPixelToPage(data);
    waitForRegPixel = true;
    if (waitForSubmit == true) {
        submitForm();
    }
}

function FireStartupPagePixel(data) {
    AppendJavascriptPixelToPage(data);
}


function getMailAffParam() {

    var sURL = window.document.URL.toString();

    if (sURL.indexOf("?") > 0) {
        var arrParams = sURL.split("?");
        var arrURLParams = arrParams[1].split("&");
        var arrParamNames = new Array(arrURLParams.length);
        var arrParamValues = new Array(arrURLParams.length);
        var i = 0;
        for (i = 0; i < arrURLParams.length; i++) {
            var sParam = arrURLParams[i].split("=");
            arrParamNames[i] = sParam[0];
            if (sParam[0] == "mailaff") {
                return "?mailaff=" + unescape(sParam[1]);
            }
        }
        return "";
    }
}
function getURLParam(sParamName) {
    var sURL = window.document.URL.toString();
    if (sURL.indexOf("?") > 0) {
        var arrParams = sURL.split("?");
        var arrURLParams = arrParams[1].split("&");
        var arrParamNames = new Array(arrURLParams.length);
        var arrParamValues = new Array(arrURLParams.length);
        var i = 0;
        for (i = 0; i < arrURLParams.length; i++) {
            var sParam = arrURLParams[i].split("=");
            arrParamNames[i] = sParam[0];
            if (sParam[0] == sParamName) {
                return unescape(sParam[1]);
            }
        }
        return "";
    }
}
function handleTelephoneChange(elm, target) {
    var o = document.getElementById(target)
    switch (document.getElementById(elm).value) {
        case "0": o.value = '0'; break;
        case "1": o.value = '376'; break;
        case "2": o.value = '971'; break;
        case "3": o.value = '93'; break;
        case "4": o.value = '1268'; break;
        case "5": o.value = '1264'; break;
        case "6": o.value = '355'; break;
        case "7": o.value = '374'; break;
        case "8": o.value = '599'; break;
        case "9": o.value = '244'; break;
        case "11": o.value = '54'; break;
        case "12": o.value = '1684'; break;
        case "13": o.value = '43'; break;
        case "14": o.value = '61'; break;
        case "15": o.value = '297'; break;
        case "16": o.value = '994'; break;
        case "17": o.value = '387'; break;
        case "18": o.value = '1246'; break;
        case "19": o.value = '880'; break;
        case "20": o.value = '32'; break;
        case "21": o.value = '226'; break;
        case "22": o.value = '359'; break;
        case "23": o.value = '973'; break;
        case "24": o.value = '257'; break;
        case "25": o.value = '229'; break;
        case "26": o.value = '1441'; break;
        case "27": o.value = '673'; break;
        case "28": o.value = '591'; break;
        case "29": o.value = '55'; break;
        case "30": o.value = '1242'; break;
        case "31": o.value = '975'; break;
        case "32": o.value = '0'; break;
        case "33": o.value = '267'; break;
        case "34": o.value = '375'; break;
        case "35": o.value = '501'; break;
        case "36": o.value = '1613'; break;
        case "37": o.value = '0'; break;
        case "38": o.value = '242'; break;
        case "39": o.value = '236'; break;
        case "40": o.value = '243'; break;
        case "41": o.value = '41'; break;
        case "42": o.value = '225'; break;
        case "43": o.value = '682'; break;
        case "44": o.value = '56'; break;
        case "45": o.value = '237'; break;
        case "46": o.value = '86'; break;
        case "47": o.value = '57'; break;
        case "48": o.value = '506'; break;
        case "49": o.value = '53'; break;
        case "50": o.value = '238'; break;
        case "51": o.value = '61'; break;
        case "52": o.value = '357'; break;
        case "53": o.value = '420'; break;
        case "54": o.value = '49'; break;
        case "55": o.value = '253'; break;
        case "56": o.value = '45'; break;
        case "57": o.value = '1767'; break;
        case "58": o.value = '1809'; break;
        case "59": o.value = '213'; break;
        case "60": o.value = '593'; break;
        case "61": o.value = '372'; break;
        case "62": o.value = '20'; break;
        case "63": o.value = '212'; break;
        case "64": o.value = '291'; break;
        case "65": o.value = '34'; break;
        case "66": o.value = '251'; break;
        case "67": o.value = '358'; break;
        case "68": o.value = '679'; break;
        case "69": o.value = '500'; break;
        case "70": o.value = '691'; break;
        case "71": o.value = '298'; break;
        case "72": o.value = '33'; break;
        case "73": o.value = '33'; break;
        case "74": o.value = '241'; break;
        case "75": o.value = '44'; break;
        case "76": o.value = '1473'; break;
        case "77": o.value = '995'; break;
        case "78": o.value = '594'; break;
        case "79": o.value = '233'; break;
        case "80": o.value = '350'; break;
        case "81": o.value = '299'; break;
        case "82": o.value = '220'; break;
        case "83": o.value = '224'; break;
        case "84": o.value = '590'; break;
        case "85": o.value = '240'; break;
        case "86": o.value = '30'; break;
        case "87": o.value = '0'; break;
        case "88": o.value = '502'; break;
        case "89": o.value = '1671'; break;
        case "90": o.value = '245'; break;
        case "91": o.value = '592'; break;
        case "92": o.value = '852'; break;
        case "93": o.value = '0'; break;
        case "94": o.value = '504'; break;
        case "95": o.value = '385'; break;
        case "96": o.value = '509'; break;
        case "97": o.value = '36'; break;
        case "98": o.value = '62'; break;
        case "99": o.value = '353'; break;
        case "100": o.value = '972'; break;
        case "101": o.value = '91'; break;
        case "102": o.value = '246'; break;
        case "103": o.value = '964'; break;
        case "104": o.value = '98'; break;
        case "105": o.value = '354'; break;
        case "106": o.value = '39'; break;
        case "107": o.value = '1876'; break;
        case "108": o.value = '962'; break;
        case "109": o.value = '81'; break;
        case "110": o.value = '254'; break;
        case "111": o.value = '996'; break;
        case "112": o.value = '855'; break;
        case "113": o.value = '686'; break;
        case "114": o.value = '269'; break;
        case "115": o.value = '1869'; break;
        case "116": o.value = '850'; break;
        case "117": o.value = '82'; break;
        case "118": o.value = '965'; break;
        case "119": o.value = '1345'; break;
        case "120": o.value = '7'; break;
        case "121": o.value = '856'; break;
        case "122": o.value = '961'; break;
        case "123": o.value = '1758'; break;
        case "124": o.value = '423'; break;
        case "125": o.value = '94'; break;
        case "126": o.value = '231'; break;
        case "127": o.value = '266'; break;
        case "128": o.value = '370'; break;
        case "129": o.value = '352'; break;
        case "130": o.value = '371'; break;
        case "131": o.value = '218'; break;
        case "132": o.value = '212'; break;
        case "133": o.value = '377'; break;
        case "134": o.value = '373'; break;
        case "135": o.value = '261'; break;
        case "136": o.value = '692'; break;
        case "137": o.value = '389'; break;
        case "138": o.value = '223'; break;
        case "139": o.value = '95'; break;
        case "140": o.value = '976'; break;
        case "141": o.value = '853'; break;
        case "142": o.value = '1670'; break;
        case "143": o.value = '596'; break;
        case "144": o.value = '222'; break;
        case "145": o.value = '1664'; break;
        case "146": o.value = '356'; break;
        case "147": o.value = '230'; break;
        case "148": o.value = '960'; break;
        case "149": o.value = '265'; break;
        case "151": o.value = '52'; break;
        case "152": o.value = '60'; break;
        case "153": o.value = '258'; break;
        case "154": o.value = '264'; break;
        case "155": o.value = '687'; break;
        case "156": o.value = '227'; break;
        case "157": o.value = '672'; break;
        case "158": o.value = '234'; break;
        case "159": o.value = '505'; break;
        case "160": o.value = '31'; break;
        case "161": o.value = '47'; break;
        case "162": o.value = '977'; break;
        case "163": o.value = '674'; break;
        case "164": o.value = '683'; break;
        case "165": o.value = '64'; break;
        case "166": o.value = '968'; break;
        case "167": o.value = '507'; break;
        case "168": o.value = '51'; break;
        case "169": o.value = '689'; break;
        case "170": o.value = '675'; break;
        case "171": o.value = '63'; break;
        case "172": o.value = '92'; break;
        case "173": o.value = '48'; break;
        case "174": o.value = '508'; break;
        case "175": o.value = '64'; break;
        case "176": o.value = '1787'; break;
        case "178": o.value = '351'; break;
        case "179": o.value = '680'; break;
        case "180": o.value = '595'; break;
        case "181": o.value = '974'; break;
        case "182": o.value = '262'; break;
        case "183": o.value = '40'; break;
        case "184": o.value = '7'; break;
        case "185": o.value = '250'; break;
        case "186": o.value = '966'; break;
        case "187": o.value = '677'; break;
        case "188": o.value = '248'; break;
        case "189": o.value = '249'; break;
        case "190": o.value = '46'; break;
        case "191": o.value = '65'; break;
        case "192": o.value = '290'; break;
        case "193": o.value = '386'; break;
        case "194": o.value = '47'; break;
        case "195": o.value = '421'; break;
        case "196": o.value = '232'; break;
        case "197": o.value = '378'; break;
        case "198": o.value = '221'; break;
        case "199": o.value = '252'; break;
        case "200": o.value = '597'; break;
        case "201": o.value = '239'; break;
        case "202": o.value = '503'; break;
        case "203": o.value = '963'; break;
        case "204": o.value = '268'; break;
        case "205": o.value = '140'; break;
        case "206": o.value = '235'; break;
        case "207": o.value = '156'; break;
        case "208": o.value = '228'; break;
        case "209": o.value = '66'; break;
        case "210": o.value = '992'; break;
        case "211": o.value = '690'; break;
        case "212": o.value = '993'; break;
        case "213": o.value = '216'; break;
        case "214": o.value = '676'; break;
        case "215": o.value = '670'; break;
        case "216": o.value = '90'; break;
        case "217": o.value = '1868'; break;
        case "218": o.value = '688'; break;
        case "219": o.value = '886'; break;
        case "220": o.value = '255'; break;
        case "221": o.value = '380'; break;
        case "222": o.value = '256'; break;
        case "223": o.value = '0'; break;
        case "224": o.value = '1'; break;
        case "225": o.value = '598'; break;
        case "226": o.value = '998'; break;
        case "227": o.value = '391'; break;
        case "228": o.value = '1784'; break;
        case "229": o.value = '58'; break;
        case "230": o.value = '0'; break;
        case "231": o.value = '1284'; break;
        case "232": o.value = '84'; break;
        case "233": o.value = '678'; break;
        case "234": o.value = '681'; break;
        case "235": o.value = '685'; break;
        case "236": o.value = '967'; break;
        case "237": o.value = '269'; break;
        case "238": o.value = '381'; break;
        case "239": o.value = '27'; break;
        case "240": o.value = '260'; break;
        case "241": o.value = '243'; break;
        case "242": o.value = '263'; break;
        case "243": o.value = '0'; break;
        case "244": o.value = '1670'; break;
        case "245": o.value = '381'; break;
        case "246": o.value = '972'; break;
        case "247": o.value = '972'; break;
        case "248": o.value = '672'; break;
        case "249": o.value = '381'; break;
        case "250": o.value = '381'; break;
        case "251": o.value = '247'; break;
        case "252": o.value = '246'; break;
    }
    o.style.color = "#00cc00";
}

function GetAllUrlParams() {
    var sURL = window.document.URL.toString();
    //alert('sURL='+sURL);
    var paramsList = "?";
    if (sURL.indexOf("?") > 0) {
        var arrParams = sURL.split("?");
        paramsList = arrParams[1];
        return paramsList;
    }
    return '';
}

function fixUrlParams() {
    var p = GetAllUrlParams();
    jQuery('option').each(function (index, value) {
        var url1 = jQuery(this).attr('url');
        if ((typeof (url1) != "undefined") && (url1 != "")) {
            if (url1.indexOf('landingpage_') >= 0 && url1.indexOf('.html') >= 0) {
                jQuery(this).attr('url', url1 + "?" + p);
            }
        }
    });

    jQuery('a').each(function (index, value) {
        var url2 = jQuery(this).attr('href');
        if ((typeof (url2) != "undefined") && (url2 != "")) {
            if (url2.indexOf('landingpage_') >= 0 && url2.indexOf('.html') >= 0) {
                jQuery(this).attr('href', url2 + "?" + p);
            }
        }
    });
}

function GetDetailsAjax(url) {
    var ajaxUrl = location.protocol + "//" + apiDomain + url;
    jQuery.ajax({
        dataType: 'jsonp',
        jsonp: 'callback',
        url: ajaxUrl,
        success: function (data) {
            FillClientDetails(data);
        },
        error: function (jqXHR, textStatus, errorThrown) {
            alert('Error in GetDetailsAjax');
        }
    });
}


function FillClientDetails(data) {
    if (data != null && data != '') {
        $('#cFname').val(data[0]);
        $('#cLname').val(data[1]);
        $('#cEmail').val(Querystring_get('email', ''));
        $('#cEmail2').val(Querystring_get('email', ''));
        $('#cCountry').val(data[2]);
        $('#cMarital').val(data[5]);
        var hasJob = 0;
        if (data[6] == true) {
            $('#cJobM').attr('checked', 'true');
        }
        else {
            $('#cJobM').attr('checked', 'false');
        }

        var PhoneArr = GetFullTelephoneDetails(data[3]);
        $('#cCountryTelephone').val(PhoneArr[0]);
        $('#cCountryArea').val(PhoneArr[1]);
        $('#cTelephoneNumber').val(PhoneArr[2]);
        var PhoneArr = GetFullTelephoneDetails(data[4]);
        $('#cCountryTelephoneMobile').val(PhoneArr[0]);
        $('#cCountryAreaMobile').val(PhoneArr[1]);
        $('#cTelephoneNumberMobile').val(PhoneArr[2]);
        checkEmailDomain(Querystring_get('email', ''));
    }
}

function GetFullTelephoneDetails(num) {
    var code = '';
    var phoneArr = new Array();
    var country = null;
    for (var i = 4; i > 1; i--) {
        code = num.substring(0, i);
        country = SetCountryByCountryAreaCode(code);
        if (country != null) {
            phoneArr[0] = country;
            phoneArr[1] = code;
            phoneArr[2] = num.substring(i, num.length);
            return phoneArr;
        }

    }

}

function SetCountryByCountryAreaCode(PhonePrefix) {
    var countryCode = null;
    for (var iIndex = 0 ; iIndex < arrPhoneCodes.length; iIndex++) {
        if (arrPhoneCodes[iIndex].PhoneCode == PhonePrefix) {
            if (iIndex > 9) iIndex++;
            countryCode = iIndex
            break;
        }
    }
    return countryCode;
}

function MailAffiliateUrl() {
    var params = getParams();
    var url = '';
    if (params.indexOf("id") >= 0 && params.indexOf("num") >= 0 && params.indexOf("email") >= 0) {
        AssignQuerystringValues();//preparing the url parameters
        var id = Querystring_get('id', '');
        var email = Querystring_get('email', '');
        var pass = Querystring_get('num', '');
        url = '/Client/GetClientDetails?applicationId=' + id + '&email=' + email + '&password=' + pass;
        GetDetailsAjax(url);
    }
}

function AssignQuerystringValues() {

    var querystring = location.search.substring(1, location.search.length);

    var args = querystring.split('&');


    for (var i = 0; i < args.length; i++) {
        var pair = args[i].split('=');

        // Fix broken unescaping
        temp = unescape(pair[0]).split('+');
        name = temp.join(' ');

        temp = unescape(pair[1]).split('+');
        value = temp.join(' ');

        this[name] = value;
    }

    this.get = Querystring_get;
}

function Querystring_get(strKey, strDefault) {

    var value = this[strKey];
    if (value == null) {
        value = strDefault;
    }
    return value;
}


function GetCidParam() {
    var retVal = "";

    try {
        retVal = getURLParam("cid");
        if (typeof (retVal) == "undefined") {
            retVal = "";
        }
    }
    catch (err) {
        retVal = "";
    }

    return retVal;
}