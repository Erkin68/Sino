#include "Plugins_CPP.h"
#include "stdio.h"
#include "nv_dds.h"
#include "strsafe.h"
#include "..\..\..\Operations\MyShell\MyShell.h"

//int DDSDecompressARGB8888(unsigned char*,int,int,unsigned char*);
//int DDSDecompressDXT1(unsigned char*,int,int,unsigned char*);
//int DDSDecompressDXT3(unsigned char*,int,int,unsigned char*);
//int DDSDecompressDXT5(unsigned char*,int,int,unsigned char*);

//#define NV_DDS_BIG_ENDIAN
//#define __BIG_ENDIAN__

///////////////////////////////////////////////////////////////////////////////
// Swap the bytes in a 32 bit value
inline void swap_endian(void *val)
{
#if defined(NV_DDS_BIG_ENDIAN)
    unsigned int *ival = (unsigned int *)val;

    *ival = ((*ival >> 24) & 0x000000ff) |
            ((*ival >>  8) & 0x0000ff00) |
            ((*ival <<  8) & 0x00ff0000) |
            ((*ival << 24) & 0xff000000);
#else
	(void)val;
#endif
}


#define MAX_STRINGS 24

HINSTANCE plgnDllInst;
int		plgId=0;

int lookupInDirCnt=0;

extern "C"
{
__declspec (dllexport) int GetLookupInDirCnt(){return lookupInDirCnt;}

extern void saveOpt();
extern void FreeFindData();

saveOptions_t saveOptions;
readOptions_t readOptions;
}

//void decompress8BitRLE(u8*&,s32,s32,s32,s32) const;
//void decompress4BitRLE(u8*&,s32,s32,s32,s32) const;



BOOL APIENTRY DllMain(HMODULE hModule,DWORD ul_reason_for_call,LPVOID lpReserved)
{
	switch(ul_reason_for_call)
	{	case DLL_PROCESS_ATTACH:
			plgnDllInst=hModule;
			HMODULE hm;hm=LoadLibrary(L"DXTDecompressorSource.dll");
			if(hm)
			{DXTDImageBackscanDxt1=(DXTDImageBackscanDxt1_t)GetProcAddress(hm,"DXTDImageBackscanDxt1");
			 DXTDImageBackscanDxt3=(DXTDImageBackscanDxt1_t)GetProcAddress(hm,"DXTDImageBackscanDxt3");
			 DXTDImageBackscanDxt5=(DXTDImageBackscanDxt1_t)GetProcAddress(hm,"DXTDImageBackscanDxt5");
			}
			break;
		case DLL_THREAD_ATTACH:
			break;
		case DLL_THREAD_DETACH:
			break;
		case DLL_PROCESS_DETACH:
			saveOpt();
			break;
	}
	return TRUE;
}

extern "C"
{
__declspec (dllexport) int GetPluginType()
{
	return 202;
}

__declspec (dllexport) const wchar_t* GetPluginDescription()
{
wchar_t mnuStr[64];
	if(GetEnvironmentVariableW(L"languge",mnuStr,64))//Language instartup qo'yadur;
	{	if(!wcscmp(mnuStr,L"russian"))
			return L"Sino ������ ��������� dds-������, ������ 1.1";
		else if(!wcscmp(mnuStr,L"uzbekl"))
			return L"Sino dds-fayllarni ochuvchi plagin, versiya 1.1";
		else if(!wcscmp(mnuStr,L"uzbekk"))
			return L"Sino dds-��������� ������ ������, ������ 1.1";
		else//if(wcscmp(mnuStr,L"Exit")
			return L"Sino dds-image view plugin version 1.1";
	}
	//else 
	return L"Sino dds-image viewplugin version 1.1";
}

__declspec (dllexport) const wchar_t* GetPluginName()
{
	return L"Dds image plugin";
}

__declspec (dllexport) const wchar_t *GetImgExtnsn$4(int t)
{
	switch(t)
	{	case 0:
			return L"dds";
	}
	return NULL;//end of enum
}

void saveOpt()
{	
	//saveOptions(plgId,&item,sizeof(item));
}

__declspec (dllexport) void SetId$4(int id)
{
	plgId = id;
	//readOptions(id,&item,sizeof(item));
}

__declspec (dllexport) VOID SetCallbacks$4xxx(LPVOID frstCallback,...)
{
va_list args;
	va_start(args, frstCallback);//1
	saveOptions = (saveOptions_t)va_arg(args, LPVOID);//7
	readOptions = (readOptions_t)va_arg(args, LPVOID);//8
va_end (args);
}

__declspec (dllexport) BOOL LoadImageInDir$28(wchar_t* pathAndName,int iInDir,HDC* dc,HBITMAP* bm,int* width,int* height,int* bpp)
{
	return TRUE;
}

int DDSDecompressARGB8888( unsigned char *dds, int width, int height, unsigned char *pixels )
{
	/* setup */
	unsigned char* in = dds;
	unsigned char* out = pixels;

	/* walk y */
	for(int y = 0; y < height; y++)
	{
		/* walk x */
		for(int x = 0; x < width; x++)
		{	*out++ = *in++;
			*out++ = *in++;
			*out++ = *in++;
			*out++ = *in++;
		}
	}

	/* return ok */
	return 0;
}

__declspec(align(1)) struct ddsColorBlock
{	unsigned __int16 colors[ 2 ];
	unsigned char	 row[ 4 ];
};// PACK_STRUCT;
__declspec(align(1)) struct ddsColor
{unsigned char b, g, r, a;};

#ifdef __BIG_ENDIAN__

	__int32   DDSBigLong( __int32 src ) { return src; }
	__int16 DDSBigShort( __int16 src ) { return src; }
	float DDSBigFloat( float src ) { return src; }

	__int32 DDSLittleLong( __int32 src )
	{	return ((src & 0xFF000000) >> 24) |
			((src & 0x00FF0000) >> 8) |
			((src & 0x0000FF00) << 8) |
			((src & 0x000000FF) << 24);
	}

	__int16 DDSLittleShort( __int16 src )
	{	return ((src & 0xFF00) >> 8) |
			((src & 0x00FF) << 8);
	}

	typedef union
	{	float f;
		char c[ 4 ];
	}floatSwapUnion;
	float DDSLittleFloat( float src )
	{	floatSwapUnion in,out;
		in.f = src;
		out.c[ 0 ] = in.c[ 3 ];
		out.c[ 1 ] = in.c[ 2 ];
		out.c[ 2 ] = in.c[ 1 ];
		out.c[ 3 ] = in.c[ 0 ];
		return out.f;
	}

#else /*__BIG_ENDIAN__*/

	__int32   DDSLittleLong( __int32 src ) { return src; }
	__int16 DDSLittleShort( __int16 src ) { return src; }
	float DDSLittleFloat( float src ) { return src; }

	__int32 DDSBigLong( __int32 src )
	{
		return ((src & 0xFF000000) >> 24) |
			((src & 0x00FF0000) >> 8) |
			((src & 0x0000FF00) << 8) |
			((src & 0x000000FF) << 24);
	}

	__int16 DDSBigShort( __int16 src )
	{
		return ((src & 0xFF00) >> 8) |
			((src & 0x00FF) << 8);
	}

typedef union TFloatSwapUnion
{	float f;
	char  c[ 4 ];
} floatSwapUnion;

	float DDSBigFloat( float src )
	{
		floatSwapUnion in,out;
		in.f = src;
		out.c[ 0 ] = in.c[ 3 ];
		out.c[ 1 ] = in.c[ 2 ];
		out.c[ 2 ] = in.c[ 1 ];
		out.c[ 3 ] = in.c[ 0 ];
		return out.f;
	}

#endif /*__BIG_ENDIAN__*/

void DDSGetColorBlockColors( ddsColorBlock *block, ddsColor colors[ 4 ] )
{
	unsigned __int16 word;

	/* color 0 */
	word = DDSLittleShort( block->colors[ 0 ] );

	//colors[ 0 ].a = 0xff;

/*	colors[0].r = (word >> 11) & 0x1F;
	colors[0].g =  (word >> 5) & 0x3F;
	colors[0].b =       (word) & 0x1F;
	colors[0].a = 0xFF;
	
	colors[0].r = (colors[0].r << 3) | (colors[0].r >> 2);
	colors[0].g = (colors[0].g << 2) | (colors[0].g >> 4);
	colors[0].b = (colors[0].b << 3) | (colors[0].b >> 2);*/
 

	/* extract rgb bits */
	colors[ 0 ].b = (unsigned char) word;
	colors[ 0 ].b <<= 3;
	colors[ 0 ].b |= (colors[ 0 ].b >> 5);
	word >>= 5;
	colors[ 0 ].g = (unsigned char) word;
	colors[ 0 ].g <<= 2;
	colors[ 0 ].g |= (colors[ 0 ].g >> 5);
	word >>= 6;
	colors[ 0 ].r = (unsigned char) word;
	colors[ 0 ].r <<= 3;
	colors[ 0 ].r |= (colors[ 0 ].r >> 5);



	/* same for color 1 */
	word = DDSLittleShort( block->colors[ 1 ] );
	//colors[ 1 ].a = 0xff;

/*	colors[1].r = (word >> 11) & 0x1F;
	colors[1].g =  (word >> 5) & 0x3F;
	colors[1].b =       (word) & 0x1F;
	colors[1].a = 0xFF;
	
	colors[1].r = (colors[1].r << 3) | (colors[1].r >> 2);
	colors[1].g = (colors[1].g << 2) | (colors[1].g >> 4);
	colors[1].b = (colors[1].b << 3) | (colors[1].b >> 2);*/
 

	/* extract rgb bits */
	colors[ 1 ].b = (unsigned char) word;
	colors[ 1 ].b <<= 3;
	colors[ 1 ].b |= (colors[ 1 ].b >> 5);
	word >>= 5;
	colors[ 1 ].g = (unsigned char) word;
	colors[ 1 ].g <<= 2;
	colors[ 1 ].g |= (colors[ 1 ].g >> 5);
	word >>= 6;
	colors[ 1 ].r = (unsigned char) word;
	colors[ 1 ].r <<= 3;
	colors[ 1 ].r |= (colors[ 1 ].r >> 5);


	/* use this for all but the super-freak math method */
	if( block->colors[ 0 ] > block->colors[ 1 ] )
	{
		/* four-color block: derive the other two colors.
		00 = color 0, 01 = color 1, 10 = color 2, 11 = color 3
		these two bit codes correspond to the 2-bit fields
		stored in the 64-bit block. */

		word = ((unsigned __int16) colors[ 0 ].r * 2 + (unsigned __int16) colors[ 1 ].r) / 3;
		/* no +1 for rounding */
		/* as bits have been shifted to 888 */
		colors[ 2 ].r = (unsigned char) word;
		word = ((unsigned __int16) colors[ 0 ].g * 2 + (unsigned __int16) colors[ 1 ].g) / 3;
		colors[ 2 ].g = (unsigned char) word;
		word = ((unsigned __int16) colors[ 0 ].b * 2 + (unsigned __int16) colors[ 1 ].b) / 3;
		colors[ 2 ].b = (unsigned char) word;
		colors[ 2 ].a = 0xff;

		word = ((unsigned __int16) colors[ 0 ].r + (unsigned __int16) colors[ 1 ].r * 2) / 3;
		colors[ 3 ].r = (unsigned char) word;
		word = ((unsigned __int16) colors[ 0 ].g + (unsigned __int16) colors[ 1 ].g * 2) / 3;
		colors[ 3 ].g = (unsigned char) word;
		word = ((unsigned __int16) colors[ 0 ].b + (unsigned __int16) colors[ 1 ].b * 2) / 3;
		colors[ 3 ].b = (unsigned char) word;
		colors[ 3 ].a = 0xff;
	}
	else
	{
		/* three-color block: derive the other color.
		00 = color 0, 01 = color 1, 10 = color 2,
		11 = transparent.
		These two bit codes correspond to the 2-bit fields
		stored in the 64-bit block */

		word = ((unsigned __int16) colors[ 0 ].b + (unsigned __int16) colors[ 1 ].b) / 2;
		colors[ 2 ].r = (unsigned char) word;
		word = ((unsigned __int16) colors[ 0 ].g + (unsigned __int16) colors[ 1 ].g) / 2;
		colors[ 2 ].g = (unsigned char) word;
		word = ((unsigned __int16) colors[ 0 ].r + (unsigned __int16) colors[ 1 ].r) / 2;
		colors[ 2 ].b = (unsigned char) word;
		colors[ 2 ].a = 0xff;

		/* random color to indicate alpha */
		colors[ 3 ].r = 0xff;
		colors[ 3 ].g = 0xff;
		colors[ 3 ].b = 0x00;
		colors[ 3 ].a = 0x00;
	}
}

void __cdecl DDSDecodeColorBlock( unsigned __int32 *pixel, ddsColorBlock *block, __int32 width, unsigned __int32 colors[ 4 ] )
{
	__int32				r, n;
	unsigned __int32	bits;
	unsigned __int32	masks[] = { 3, 12, 3 << 4, 3 << 6 };	/* bit masks = 00000011, 00001100, 00110000, 11000000 */
	__int32				shift[] = { 0, 2, 4, 6 };


	/* r steps through lines in y */
	for( r = 0; r < 4; r++, pixel += (width - 4) )	/* no width * 4 as u32 ptr inc will * 4 */
	{
		/* width * 4 bytes per pixel per line, each j dxtc row is 4 lines of pixels */

		/* n steps through pixels */
		for( n = 0; n < 4; n++ )
		{
			bits = block->row[ r ] & masks[ n ];
			bits >>= shift[ n ];

			switch( bits )
			{
			case 0:
				*pixel = colors[ 0 ];
				pixel++;
				break;

			case 1:
				*pixel = colors[ 1 ];
				pixel++;
				break;

			case 2:
				*pixel = colors[ 2 ];
				pixel++;
				break;

			case 3:
				*pixel = colors[ 3 ];
				pixel++;
				break;

			default:
				/* invalid */
				pixel++;
				break;
			}
		}
	}
}

int DDSDecompressDXT1( unsigned char *dds, int width, int height, unsigned char *pixels )
{
	int x, y, xBlocks, yBlocks;
	unsigned __int32 *pixel;
	ddsColorBlock *block;
	ddsColor colors[ 4 ];

	/* setup */
	xBlocks = width / 4;
	yBlocks = height / 4;

	/* walk y */
	for( y = 0; y < yBlocks; y++ )
	{
		/* 8 bytes per block */
		block = (ddsColorBlock*) (dds + y * xBlocks * 8);

		/* walk x */
		for( x = 0; x < xBlocks; x++, block++ )
		{
			DDSGetColorBlockColors( block, colors );
			pixel = (unsigned __int32*) (pixels + x * 16 + (y * 4) * width * 4);
			DDSDecodeColorBlock( pixel, block, width, (unsigned __int32*) &colors[0].b );
		}
	}

	/* return ok */
	return 0;
}

__declspec(align(1)) struct ddsAlphaBlockExplicit
{
	unsigned __int16 row[ 4 ];
};
void DDSDecodeAlphaExplicit( unsigned __int32 *pixel, ddsAlphaBlockExplicit *alphaBlock, __int32 width, unsigned __int32 alphaZero )
{
	__int32				row, pix;
	unsigned __int16	word;
	ddsColor		color;


	/* clear color */
	color.r = 0;
	color.g = 0;
	color.b = 0;

	/* walk rows */
	for( row = 0; row < 4; row++, pixel += (width - 4) )
	{
		word = DDSLittleShort( alphaBlock->row[ row ] );

		/* walk pixels */
		for( pix = 0; pix < 4; pix++ )
		{
			/* zero the alpha bits of image pixel */
			*pixel &= alphaZero;
			color.a = word & 0x000F;
			color.a = color.a | (color.a << 4);
			*pixel |= *((unsigned __int32*) &color);
			word >>= 4;		/* move next bits to lowest 4 */
			pixel++;		/* move to next pixel in the row */
		}
	}
}

int DDSDecompressDXT3( unsigned char *dds, int width, int height, unsigned char *pixels )
{
	int x, y, xBlocks, yBlocks;
	unsigned __int32 *pixel, alphaZero;
	ddsColorBlock *block;
	ddsAlphaBlockExplicit *alphaBlock;
	ddsColor colors[ 4 ];

	/* setup */
	xBlocks = width / 4;
	yBlocks = height / 4;

	/* create zero alpha */
	colors[ 0 ].a = 0;
	colors[ 0 ].r = 0xFF;
	colors[ 0 ].g = 0xFF;
	colors[ 0 ].b = 0xFF;
	alphaZero = *((unsigned __int32*) &colors[ 0 ]);

	/* walk y */
	for( y = 0; y < yBlocks; y++ )
	{
		/* 8 bytes per block, 1 block for alpha, 1 block for color */
		block = (ddsColorBlock*) (dds + y * xBlocks * 16);

		/* walk x */
		for( x = 0; x < xBlocks; x++, block++ )
		{
			/* get alpha block */
			alphaBlock = (ddsAlphaBlockExplicit*) block;

			/* get color block */
			block++;
			DDSGetColorBlockColors( block, colors );

			/* decode color block */
			pixel = (unsigned __int32*) (pixels + x * 16 + (y * 4) * width * 4);
			DDSDecodeColorBlock( pixel, block, width, (unsigned __int32*) colors );

			/* overwrite alpha bits with alpha block */
			DDSDecodeAlphaExplicit( pixel, alphaBlock, width, alphaZero );
		}
	}

	/* return ok */
	return 0;
}

__declspec(align(1)) struct ddsAlphaBlock3BitLinear
{	unsigned char		alpha0;
	unsigned char		alpha1;
	unsigned char		stuff[ 6 ];
};
void DDSDecodeAlpha3BitLinear( unsigned __int32 *pixel, ddsAlphaBlock3BitLinear *alphaBlock, __int32 width, unsigned __int32 alphaZero )
{
	__int32 row, pix;
	unsigned __int32 stuff;
	char bits[ 4 ][ 4 ];
	unsigned __int16 alphas[ 8 ];
	ddsColor aColors[ 4 ][ 4 ];

	/* get initial alphas */
	alphas[ 0 ] = alphaBlock->alpha0;
	alphas[ 1 ] = alphaBlock->alpha1;

	/* 8-alpha block */
	if( alphas[ 0 ] > alphas[ 1 ] )
	{
		/* 000 = alpha_0, 001 = alpha_1, others are interpolated */
		alphas[ 2 ] = ( 6 * alphas[ 0 ] +     alphas[ 1 ]) / 7;	/* bit code 010 */
		alphas[ 3 ] = ( 5 * alphas[ 0 ] + 2 * alphas[ 1 ]) / 7;	/* bit code 011 */
		alphas[ 4 ] = ( 4 * alphas[ 0 ] + 3 * alphas[ 1 ]) / 7;	/* bit code 100 */
		alphas[ 5 ] = ( 3 * alphas[ 0 ] + 4 * alphas[ 1 ]) / 7;	/* bit code 101 */
		alphas[ 6 ] = ( 2 * alphas[ 0 ] + 5 * alphas[ 1 ]) / 7;	/* bit code 110 */
		alphas[ 7 ] = (     alphas[ 0 ] + 6 * alphas[ 1 ]) / 7;	/* bit code 111 */
	}

	/* 6-alpha block */
	else
	{
		/* 000 = alpha_0, 001 = alpha_1, others are interpolated */
		alphas[ 2 ] = (4 * alphas[ 0 ] +     alphas[ 1 ]) / 5;	/* bit code 010 */
		alphas[ 3 ] = (3 * alphas[ 0 ] + 2 * alphas[ 1 ]) / 5;	/* bit code 011 */
		alphas[ 4 ] = (2 * alphas[ 0 ] + 3 * alphas[ 1 ]) / 5;	/* bit code 100 */
		alphas[ 5 ] = (    alphas[ 0 ] + 4 * alphas[ 1 ]) / 5;	/* bit code 101 */
		alphas[ 6 ] = 0;										/* bit code 110 */
		alphas[ 7 ] = 255;										/* bit code 111 */
	}

	/* decode 3-bit fields into array of 16 bytes with same value */

	/* first two rows of 4 pixels each */
	stuff = *((unsigned __int32*) &(alphaBlock->stuff[ 0 ]));

	bits[ 0 ][ 0 ] = (unsigned char) (stuff & 0x00000007);
	stuff >>= 3;
	bits[ 0 ][ 1 ] = (unsigned char) (stuff & 0x00000007);
	stuff >>= 3;
	bits[ 0 ][ 2 ] = (unsigned char) (stuff & 0x00000007);
	stuff >>= 3;
	bits[ 0 ][ 3 ] = (unsigned char) (stuff & 0x00000007);
	stuff >>= 3;
	bits[ 1 ][ 0 ] = (unsigned char) (stuff & 0x00000007);
	stuff >>= 3;
	bits[ 1 ][ 1 ] = (unsigned char) (stuff & 0x00000007);
	stuff >>= 3;
	bits[ 1 ][ 2 ] = (unsigned char) (stuff & 0x00000007);
	stuff >>= 3;
	bits[ 1 ][ 3 ] = (unsigned char) (stuff & 0x00000007);

	/* last two rows */
	stuff = *((unsigned __int32*) &(alphaBlock->stuff[ 3 ])); /* last 3 bytes */

	bits[ 2 ][ 0 ] = (unsigned char) (stuff & 0x00000007);
	stuff >>= 3;
	bits[ 2 ][ 1 ] = (unsigned char) (stuff & 0x00000007);
	stuff >>= 3;
	bits[ 2 ][ 2 ] = (unsigned char) (stuff & 0x00000007);
	stuff >>= 3;
	bits[ 2 ][ 3 ] = (unsigned char) (stuff & 0x00000007);
	stuff >>= 3;
	bits[ 3 ][ 0 ] = (unsigned char) (stuff & 0x00000007);
	stuff >>= 3;
	bits[ 3 ][ 1 ] = (unsigned char) (stuff & 0x00000007);
	stuff >>= 3;
	bits[ 3 ][ 2 ] = (unsigned char) (stuff & 0x00000007);
	stuff >>= 3;
	bits[ 3 ][ 3 ] = (unsigned char) (stuff & 0x00000007);

	/* decode the codes into alpha values */
	for( row = 0; row < 4; row++ )
	{
		for( pix=0; pix < 4; pix++ )
		{
			aColors[ row ][ pix ].r = 0;
			aColors[ row ][ pix ].g = 0;
			aColors[ row ][ pix ].b = 0;
			aColors[ row ][ pix ].a = (unsigned char) alphas[ bits[ row ][ pix ] ];
		}
	}

	/* write out alpha values to the image bits */
	for( row = 0; row < 4; row++, pixel += width-4 )
	{
		for( pix = 0; pix < 4; pix++ )
		{
			/* zero the alpha bits of image pixel */
			*pixel &= alphaZero;

			/* or the bits into the prev. nulled alpha */
			*pixel |= *((unsigned __int32*) &(aColors[ row ][ pix ]));
			pixel++;
		}
	}
}

int DDSDecompressDXT5( unsigned char *dds, int width, int height, unsigned char *pixels )
{
	int x, y, xBlocks, yBlocks;
	unsigned __int32 *pixel, alphaZero;
	ddsColorBlock *block;
	ddsAlphaBlock3BitLinear *alphaBlock;
	ddsColor colors[ 4 ];

	/* setup */
	xBlocks = width / 4;
	yBlocks = height / 4;

	/* create zero alpha */
	colors[ 0 ].a = 0;
	colors[ 0 ].r = 0xFF;
	colors[ 0 ].g = 0xFF;
	colors[ 0 ].b = 0xFF;
	alphaZero = *((unsigned __int32*) &colors[ 0 ]);

	/* walk y */
	for( y = 0; y < yBlocks; y++ )
	{
		/* 8 bytes per block, 1 block for alpha, 1 block for color */
		block = (ddsColorBlock*) (dds + y * xBlocks * 16);

		/* walk x */
		for( x = 0; x < xBlocks; x++, block++ )
		{
			/* get alpha block */
			alphaBlock = (ddsAlphaBlock3BitLinear*) block;

			/* get color block */
			block++;
			DDSGetColorBlockColors( block, colors );

			/* decode color block */
			pixel = (unsigned __int32*) (pixels + x * 16 + (y * 4) * width * 4);
			DDSDecodeColorBlock( pixel, block, width, (unsigned __int32*) colors );

			/* overwrite alpha bits with alpha block */
			DDSDecodeAlpha3BitLinear( pixel, alphaBlock, width, alphaZero );
		}
	}

	/* return ok */
	return 0;
}

__declspec (dllexport) BOOL Load$24(wchar_t* pathAndName,HDC* dc,HBITMAP* bm,int* width,int* height,int* bpp)
{/*BitmapIO_GIF fbi;BitmapInfo bi;BMMRES status;
 MyStringCpy(bi.name,MAX_PATH,pathAndName);
 BitmapStorage *strg=fbi.ReadGIFFile(&bi,&status);
 if(!strg)return FALSE;

 *width=strg->bmiHeader.biWidth;
 *height=strg->bmiHeader.biHeight;
 *bpp=strg->bmiHeader.biBitCount;
 
 HDC d = GetDC(GetDesktopWindow());
 *dc = CreateCompatibleDC(d);
 *bm = CreateCompatibleBitmap(d,*width,*height);
 ReleaseDC(GetDesktopWindow(),d);
 SelectObject(*dc,*bm);

 strg->bmiHeader.biHeight = -strg->bmiHeader.biHeight;
 int w=SetDIBitsToDevice(*dc,0,0,*width,*height,
						 0,0,0,*height,
						 strg->RGBs,
						(BITMAPINFO*)&strg->bmiHeader,
						 DIB_RGB_COLORS);//(BMM_PALETTED==strg->type)?DIB_PAL_COLORS:DIB_RGB_COLORS);
 if(0==w)w=GetLastError();
 strg->Free();
 free(strg);
 return TRUE;*/

FILE *f=_wfopen(pathAndName,L"rb");
	if(!f)return FALSE;
	/*nv_dds::CDDSImage img;
	bool r=img.load(f);
	fclose(f);
	if(!r)return FALSE;
	nv_dds::TextureFormat fmt = img.get_format();
	*width=img.get_width();
	*height=img.get_height();
	*bpp=img.get_depth();

	unsigned char *pixels=0,*ddsdatas=0;

	nv_dds::CSurface surf;
	nv_dds::CTexture tt;
	int numMipmaps=img.get_num_mipmaps();
	if(numMipmaps>0)
	{int nmp=(int)(0.25f*numMipmaps);
	 surf = img.get_mipmap(nmp);
	 ddsdatas=surf.operator unsigned char *();
	 for(int m=0; m<nmp; m++)
	 {*width/=2;
	  *height/=2;
	}}
	else if(nv_dds::TextureCubemap==fmt)
	{tt = img.get_cubemap_face(0);
	 ddsdatas=tt.operator unsigned char *();
	}
	else ddsdatas=img.operator unsigned char *();*/

    char filecode[4];
    size_t numRead = fread(filecode, 1, 4, f);
	if(numRead != 4) { fclose(f);return false; }
    if (strncmp(filecode, "DDS ", 4) != 0)
        { fclose(f);return false; }

    // read in DDS header
	nv_dds::DDS_HEADER ddsh;
    numRead = fread(&ddsh, 1, sizeof(nv_dds::DDS_HEADER), f);
	if(numRead != sizeof(nv_dds::DDS_HEADER)) { fclose(f);return false; }

    swap_endian(&ddsh.dwSize);
    swap_endian(&ddsh.dwFlags);
    swap_endian(&ddsh.dwHeight);
    swap_endian(&ddsh.dwWidth);
    swap_endian(&ddsh.dwPitchOrLinearSize);
    swap_endian(&ddsh.dwMipMapCount);
    swap_endian(&ddsh.ddspf.dwSize);
    swap_endian(&ddsh.ddspf.dwFlags);
    swap_endian(&ddsh.ddspf.dwFourCC);
    swap_endian(&ddsh.ddspf.dwRGBBitCount);
    swap_endian(&ddsh.dwCaps1);
    swap_endian(&ddsh.dwCaps2);

	*width = ddsh.dwWidth;
	*height = ddsh.dwHeight;

    // default to flat texture type (1D, 2D, or rectangle)
    nv_dds::TextureType m_type = nv_dds::TextureFlat;
	nv_dds::TextureFormat m_format = nv_dds::TextureUnknown;
	int m_components=0;

    // check if image is a cubemap
    if (ddsh.dwCaps2 & nv_dds::DDSF_CUBEMAP)
        m_type = nv_dds::TextureCubemap;

    // check if image is a volume texture
    if ((ddsh.dwCaps2 & nv_dds::DDSF_VOLUME) && (ddsh.dwDepth > 0))
        m_type = nv_dds::Texture3D;

    // figure out what the image format is
    if (ddsh.ddspf.dwFlags & nv_dds::DDSF_FOURCC) 
    {
        switch(ddsh.ddspf.dwFourCC)
        {
            case nv_dds::FOURCC_DXT1:
                m_format = nv_dds::TextureDXT1;
                m_components = 3;
                break;
            case nv_dds::FOURCC_DXT3:
                m_format = nv_dds::TextureDXT3;
                m_components = 4;
                break;
            case nv_dds::FOURCC_DXT5:
                m_format = nv_dds::TextureDXT5;
                m_components = 4;
                break;
            default:
                return false;
        }
    }
    else if (ddsh.ddspf.dwFlags == nv_dds::DDSF_RGBA && ddsh.ddspf.dwRGBBitCount == 32)
    {
        m_format = nv_dds::TextureBGRA; 
        m_components = 4;
    }
    else if (ddsh.ddspf.dwFlags == nv_dds::DDSF_RGB  && ddsh.ddspf.dwRGBBitCount == 32)
    {
        m_format = nv_dds::TextureBGRA; 
        m_components = 4;
    }
    else if (ddsh.ddspf.dwFlags == nv_dds::DDSF_RGB  && ddsh.ddspf.dwRGBBitCount == 24)
    {
        m_format = nv_dds::TextureBGR; 
        m_components = 3;
    }
	else if (ddsh.ddspf.dwRGBBitCount == 8)
	{
		m_format = nv_dds::TextureLuminance;
		m_components = 1;
	}
    else 
    {
        return false;
    }


	unsigned char *pixels=0,*ddsdatas=0;bool r;

	fpos_t pos=0;fgetpos(f,&pos);
	fseek(f,0,SEEK_END);
	fpos_t endpos=0;fgetpos(f,&endpos);
	__int64 sz = endpos-pos;
	ddsdatas = (unsigned char*)malloc(sz);
	if(!ddsdatas){fclose(f);return false;}
	fsetpos(f,&pos);
	fread(ddsdatas,sz,1,f);

	BITMAPINFOHEADER bi;
	memset(&bi,0,sizeof(bi));
	bi.biSize=sizeof(bi);
	bi.biHeight = -(*height);
	bi.biWidth = *width;
	bi.biPlanes = 1;//*bpp;*/

	switch(m_format)
	{case nv_dds::TextureBGRA://DDS_PF_ARGB8888:
		/* fixme: support other [a]rgb formats */
		pixels=(unsigned char*)malloc((*width)*(*height)*4);
		r = (0==DDSDecompressARGB8888( ddsdatas, *width, *height, pixels ));
		bi.biBitCount = 32;
	    bi.biSizeImage = (*width) * (*height) * 4;
	 break;
	 case nv_dds::TextureDXT1://DDS_PF_DXT1:
		pixels=(unsigned char*)malloc((*width)*(*height)*4);
		//memset(pixels,0,(*width)*(*height)*4);
		if(DXTDImageBackscanDxt1)
		 r = (0==DXTDImageBackscanDxt1( *width, *height, ddsdatas, (LPDWORD)pixels ));
		else
		 r = (0==DDSDecompressDXT1( ddsdatas, *width, *height, pixels ));
		bi.biBitCount = 32;
		//bi.biCompression = BI_RGB;
		//bi.biClrImportant = 0;
		//bi.biClrUsed = 0;		
	 break;
	 case nv_dds::TextureDXT3://DDS_PF_DXT3:
		pixels=(unsigned char*)malloc((*width)*(*height)*4);
		if(DXTDImageBackscanDxt3)
		 r = (0==DXTDImageBackscanDxt3( *width, *height, ddsdatas, (LPDWORD)pixels ));
		else
		 r = (0==DDSDecompressDXT3( ddsdatas, *width, *height, pixels ));		
		bi.biBitCount = 32;
	 break;
	 case nv_dds::TextureDXT5://DDS_PF_DXT5:
		pixels=(unsigned char*)malloc((*width)*(*height)*4);
		if(DXTDImageBackscanDxt5)
		 r = (0==DXTDImageBackscanDxt5( *width, *height, ddsdatas, (LPDWORD)pixels ));
		else
		 r = (0==DDSDecompressDXT5( ddsdatas, *width, *height, pixels ));
		bi.biBitCount = 32;
	 break;
	 default:
	 case nv_dds::TextureBGR://DDS_PF_RGB888:
	 case nv_dds::TextureUnknown://DDS_PF_UNKNOWN:
		//memset( pixels, 0xFF, width * height * 4 );
		r = FALSE;
		bi.biBitCount = 32;
	 break;
	}
	fclose(f);//img.clear();
	free(ddsdatas);
	
	HDC d = GetDC(GetDesktopWindow());
	HDC dt= CreateCompatibleDC(d);
	*dc = dt;
	HBITMAP tbm=CreateCompatibleBitmap(d,*width,*height);
	*bm = tbm;
	ReleaseDC(GetDesktopWindow(),d);
	SelectObject(*dc,*bm);

	int w=SetDIBitsToDevice(*dc,0,0,*width,*height,
							0,0,0,*height,
							pixels,
							(BITMAPINFO*)&bi,
							DIB_RGB_COLORS);//(BMM_PALETTED==strg->type)?DIB_PAL_COLORS:DIB_RGB_COLORS);
	if(pixels)free(pixels);
	if(0==w)return FALSE;
	return TRUE;
}

}