//-----------------------------------------------------------------------------
// --------------------
// File ....: gif.h
// --------------------
// Author...: Tom Hudson
// Date ....: May 1995
// Descr....: Targa File I/O Module
//
// History .: Dec. 09 1995 - Started file
//            
//-----------------------------------------------------------------------------
#include <setjmp.h>
#include "stdio.h"
#include "windows.h"


#define GIFCLASSID 1234

#define DLLEXPORT __declspec(dllexport)

// Reasons for GIF load failure:
#define GIF_INVALID_SIGNATURE 1
#define GIF_TRUNCATED 2
#define GIF_INVALID_FILE 3
#define GIF_OUT_OF_MEMORY 4
#define GIF_WRITE_ERROR 5

#define MAX_CODES   4095
#define LARGEST_CODE	4095
#define TABLE_SIZE	(8*1024)

// GIF file stuff:

#pragma pack(1)		// Gotta pack these structures

typedef struct gif_header
	{
	char giftype[6];
	short w,h;
	unsigned char colpix;	/* flags */
	unsigned char bgcolor;
	unsigned char reserved;
	} GIFHeader;

typedef struct gif_GCB
	{
	unsigned char flags;
	unsigned short delay;
	unsigned char xparent;
	} GIFGraphicControlBlock;

// GCB flags bits
#define GCB_FLAGS_XPARENT 0x01

#define COLTAB	0x80
#define COLMASK 0x70
#define COLSHIFT 4
#define PIXMASK 7
#define COLPIXVGA13 (COLTAB | (5<<COLSHIFT) | 7)

typedef struct gif_image
	{
	short x,y,w,h;
	unsigned char flags;
	} GIFImage;

#define ITLV_BIT 0x40

#pragma pack()		// No more packing!

/* Various error codes used by decoder
 * and my own routines...   It's okay
 * for you to define whatever you want,
 * as long as it's negative...  It will be
 * returned intact up the various subroutine
 * levels...
 */
#define OUT_OF_MEMORY -10
#define BAD_CODE_SIZE -20
#define IMAGE_BUFFER_FULL -30
#define READ_ERROR -1
#define WRITE_ERROR -2
#define OPEN_ERROR -3
#define CREATE_ERROR -4
#define TOO_HIGH	-5

#pragma warning (push)
#pragma warning (disable : 4324 ) //'BitmapIO_GIF' : structure was padded due to __declspec(align())

/*typedef unsigned int HWND;
typedef unsigned int HINSTANCE;
typedef unsigned char    BYTE;
typedef unsigned __int16 WORD;
typedef unsigned __int32 DWORD;
typedef void* LPVOID;
typedef unsigned short USHORT;
typedef wchar_t WCHAR;
typedef unsigned int UINT;
typedef int	BOOL;
#define FALSE 0
#define TRUE 1*/
typedef unsigned char UBYTE;
typedef unsigned char uchar;
typedef unsigned short BMMRES;
#define BMMIO_READER             (1<<0)
#define BMMIO_EXTENSION          (1<<2)
#define BMM_PALETTED             2
#define BMMRES_SUCCESS           0	
#define BMMRES_BADFILEHEADER     13
#define BMM_TRUE_32              6
#define BMM_OPEN_R               1
#define MAP_HAS_ALPHA            ((DWORD)(1<<1))
#define BMM_NOT_OPEN             0
#define BMMRES_INTERNALERROR     12
#define BMMRES_INVALIDFORMAT     6	
#define BMM_OPEN_W               2
#define BMM_SINGLEFRAME -2000000L


typedef struct {
   BYTE r,g,b;
} BMM_Color_24;
typedef struct {
   BYTE r,g,b,a;
} BMM_Color_32;

typedef struct {
   WORD r,g,b;
} BMM_Color_48;

typedef struct {
   WORD r,g,b,a;
} BMM_Color_64;
struct BMM_Color_fl
{
   BMM_Color_fl(float vr = 0.0f, float vg = 0.0f, float vb = 0.0f, float va = 0.0f): r(vr), g(vg), b(vb), a(va) {}
   float r,g,b,a;
};


template <class T> class PixelBufT{//: public MaxHeapOperators {
private:
     T *buf;
     int width;
public:
     inline               PixelBufT(int width) { buf = (T *)malloc(width*sizeof(T)); this->width=width; };//MAX_calloc(width,sizeof(T)); this->width=width; };
     inline               ~PixelBufT() { if(buf) free(buf); };//MAX_free(buf); };
     inline   T*          Ptr() { return buf; };
	 inline   T&          operator[](int i) { return buf[i]; }
           int            Fill(int start, int count, T color) {
                          int ix,jx=start+count;
                          if(jx > width) // MAB - 07/15/03 - changed from >=
                             return 0;
                          for(ix=start; ix<jx; buf[ix++]=color);
                          return 1;
                          };
     };

typedef PixelBufT<UBYTE> PixelBuf8;
typedef PixelBufT<USHORT> PixelBuf16;
typedef PixelBufT<BMM_Color_24> PixelBuf24;
typedef PixelBufT<BMM_Color_32> PixelBuf32;
typedef PixelBufT<BMM_Color_48> PixelBuf48;
typedef PixelBufT<BMM_Color_64> PixelBuf64;
typedef PixelBufT<BMM_Color_fl> PixelBufFloat;
typedef PixelBufT<BMM_Color_64> PixelBuf;


class BitmapInfo
{
public:
	int type;
	int flags;
	int storageType;
	int firstFrame,lastFrame;
	int width,height;
	float gamma,aspect;
	wchar_t name[MAX_PATH];
	VOID SetWidth(int w){width=w;}
	VOID SetHeight(int h){height=h;}
	VOID SetGamma(float g){gamma=g;}
	VOID SetAspect(float a){aspect=a;}
	VOID SetFirstFrame(int f){firstFrame=f;}
	VOID SetLastFrame(int f){lastFrame=f;}
	VOID SetType(int t){type=t;}
	wchar_t* Name(){return &name[0];}
	void SetFlags(int f){flags=f;}
};

class BitmapStorage
{
//protected:
public:
	  int                      openMode;                   // See above
	  UINT                     usageCount;                 // Number of Bitmaps using this storage
	  int                      flags;
	  int                      type;                       // See "Basic bitmap types", below
	  int                      rowBytes,rowPadds;          // See "Basic bitmap types", below

	  BITMAPINFOHEADER		   bmiHeader;	
	  BMM_Color_32             bmiColors[256];             // 256 palette entries max
	  //int                     paletteSlots;
	  UWORD                    *gammaTable;                // Gamma correction table
	  BYTE					   *RGBs;	
	  //BOOL				   Allocate(BitmapInfo*,int){return 1;}
	  void					   Free(){free(RGBs);}

	  int					   SetPalette(int start,int count,BMM_Color_48 *ptr);
//	  GBuffer                  *gbuffer;

	  /* Send a line of pixels to the screen */
	  int PutIndexPixels ( int x,int y,int pixels,BYTE *ptr );
	  int PutPixels ( int x,int y,int pixels,BMM_Color_64 *ptr );

public:
};

//-----------------------------------------------------------------------------
//-- Class Definition ---------------------------------------------------------
//

class BitmapIO_GIF
{  
     //private:
public:
     
        FILE   *inStream;
        //FILE *outStream;

		GIFHeader header;
		GIFImage image;
		GIFGraphicControlBlock GCB;

		int storageType;

		BMM_Color_24 gif_cmap[256];				/* Raw GIF file color map */

		int badGIFReason;
		int bad_code_count;
		int gif_line, gif_colors;
		char iphase;
		int iy;
		WORD curr_size;                     /* The current code size */
		WORD clear;                         /* Value for a clear code */
		WORD ending;                        /* Value for a ending code */
		WORD newcodes;                      /* First available code */
		WORD top_slot;                      /* Highest code for current size */
		WORD slot;                          /* Last read code */

		/* The following static variables are used
		 * for seperating out codes
		 */
		WORD navail_bytes;                  /* # bytes left in block */
		WORD nbits_left;                    /* # bits left in current byte */
		BYTE b1;                            /* Current byte */
		BYTE *pbytes;                       /* Pointer to next byte in block */
		BYTE gif_byte_buff[256+3];          /* Current block */

		// GIF write variables
		BYTE *gif_wpt;
		long gif_wcount;

		jmp_buf recover;

		short *prior_codes;
		short *code_ids;
		BYTE *added_chars;

		short code_size;
		short clear_code;
		short eof_code;
		short bit_offset;
		short max_code;
		short free_code;
		int openMode;

		BitmapStorage *loadStorage;
		
        //-- This handler's private functions

        //BitmapStorage *ReadGIFFile        ( BitmapInfo *fbi, BitmapManager *manager, BMMRES *status);
        BitmapStorage* ReadGIFFile(BitmapInfo *fbi, /*BitmapManager *manager,*/ BMMRES *status);
		int GIFGetByte();
		int GIFOutLine(BYTE *pixels, int linelen);
		WORD InitExp(WORD size);
		WORD GetNextCode();
		int Decoder(WORD linewidth, BYTE *buf, BYTE *stack, BYTE *suffix, USHORT *prefix);
		int GIFDecoder(WORD linewidth);
		int ReadHeader();
		//BitmapStorage * LoadGIFStuff(BitmapInfo *fbi, BitmapManager *manager );
		BitmapStorage* LoadGIFStuff(BitmapInfo *fbi/*, BitmapManager *manager*/);
		int SaveGIF(/*Bitmap *map*/);
		void InitTable(short min_code_size);
		void Flush(short n);
		void WriteCode(short code);
		short CompressData(int min_code_size);
		short GIFCompressData(int min_code_size);
		BitmapStorage *Load(BitmapInfo *fbi, /*Bitmap *map,*/ BMMRES *status);

     public:
     
        //-- Constructors/Destructors
        
                       BitmapIO_GIF       ( );
                      ~BitmapIO_GIF       ( ) {}

        //-- Number of extemsions supported
        
        int            ExtCount           ( )       { return 1;}
        
        //-- Extension #n (i.e. "3DS")
        
        const WCHAR   *Ext                ( int n ) { return L"gif"; }
        
        //-- Descriptions
        
        const WCHAR   *LongDesc           ( );
        const WCHAR   *ShortDesc          ( );

        //-- Miscelaneous Messages
        
        const WCHAR   *AuthorName         ( )       { return L"Tom Hudson";}
        const WCHAR   *CopyrightMessage   ( )       { return L"Copyright 1995 Yost Group";}
        UINT           Version            ( )       { return (100);}

        //-- Driver capabilities
        
        int            Capability         ( )       { return BMMIO_READER    | 
        // Un-comment the following line to enable GIF writing:
//                                                             BMMIO_WRITER    | 
                                                             BMMIO_EXTENSION; }
        
        //-- Driver Configuration
        
        BOOL           LoadConfigure      ( void *ptr ) { return NULL; }
        BOOL           SaveConfigure      ( void *ptr ) { return NULL; }
        DWORD          EvaluateConfigure  ( ) { return 0; }
        
        //-- Return info about image
        
        BMMRES         GetImageInfo       ( BitmapInfo *fbi );        

        //-- Image Input
        
        //BitmapStorage *Load               ( BitmapInfo *fbi, Bitmap *map, BMMRES *status);
        LPVOID Load               ( BMMRES *status);

        //-- Image Output
        
        BMMRES       OpenOutput         ( BitmapInfo *fbi);//, Bitmap *map );
        BMMRES         OpenOutput         ( );
        BMMRES         Write              ( int frame );
        int            Close              ( int flag );
  
};

#pragma warning (pop)
