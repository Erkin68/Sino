//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by epsres.RC
//
#define IDS_AUTHOR_NAME                 1
#define IDS_COPYRIGHT                   2
#define IDS_OTHER_MESSAGE1              3
#define IDS_OTHER_MESSAGE2              4
#define IDS_SHORT_DESC                  5
#define IDS_LONG_DESC                   6
#define IDS_LIB_DESCRIPTION             7
#define IDS_YES                         8
#define IDS_NO                          9
#define IDS_CLASS_NAME                  10
#define IDS_UNKNOWN                     12
#define IDS_CATEGORY                    13
#define IDD_OUTPUT_DIALOG               101
#define IDD_ABOUT_DIALOG                102
#define IDB_BITMAP_LANDSCAPE            103
#define IDB_BITMAP_PORTRAIT             104
#define IDI_ICON_LANDSCAPE              104
#define IDD_INFO                        105
#define IDD_INFO_DIALOG                 105
#define IDI_ICON_PORTRAIT               105
#define IDC_INCHES                      1000
#define IDC_MILLIMETERS                 1001
#define IDC_ORIENTATION                 1002
#define IDC_PORTRAIT                    1003
#define IDC_LANDSCAPE                   1004
#define IDC_DATA_FORMAT                 1005
#define IDC_BINARY                      1006
#define IDC_ASCII                       1007
#define IDC_FILE_TYPE                   1008
#define IDC_COLOR                       1009
#define IDC_GRAY                        1010
#define IDC_PAGE_SIZE                   1011
#define IDC_RESOLUTION                  1012
#define IDC_PREVIEW                     1013
#define IDC_YES_PREVIEW                 1014
#define IDC_NO_PREVIEW                  1015
#define IDC_WIDTH                       1017
#define IDC_HEIGHT                      1019
#define IDC_RES_WIDTH                   1020
#define IDC_RES_HEIGHT                  1022
#define IDC_WIDTH_SPINNER               1025
#define IDC_HEIGHT_SPINNER              1026
#define IDC_RES_WIDTH_SPINNER           1027
#define IDC_RES_HEIGHT_SPINNER          1028
#define IDC_WIDTH_EDIT                  1029
#define IDC_HEIGHT_EDIT                 1030
#define IDC_RES_WIDTH_EDIT              1031
#define IDC_RES_HEIGHT_EDIT             1032
#define IDC_FILENAME                    1032
#define IDC_INCLUDE_PREVIEW             1033
#define IDC_CREATOR                     1033
#define IDC_CREATION_DATE               1034
#define IDC_EPS_TITLE                   1035
#define IDC_DRIVENAME                   1038
#define IDC_AUTHOR                      1039
#define IDC_DRIVEVERSION                1040
#define IDC_COPYRIGHT                   1041
#define IDC_UNITS                       -1
#define IDC_ABOUT_TEXT                  -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        105
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1036
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
