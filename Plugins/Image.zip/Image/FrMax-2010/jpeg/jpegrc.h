//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by jpeg.rc
//
#define IDS_JPEG                        1
#define IDS_JPEG_FILE                   2
#define IDS_BITMAP_IO                   3
#define IDS_READ_ERROR                  4
#define IDS_WRITE_ERROR                 5
#define IDS_LIBDESCRIPTION              6
#define IDS_JPEGIO_INTERFACE            7
#define IDS_JPEGIO_GETQUALITY           14
#define IDS_JPEGIO_SETQUALITY           15
#define IDS_JPEGIO_GETSMOOTHING         16
#define IDS_JPEGIO_SETSMOOTHING         17
#define IDD_JPEG_ABOUT                  101
#define IDD_JPEG_CONTROL                102
#define IDC_ARITH                       1001
#define IDC_HUFFMAN                     1002
#define IDC_QUALITY                     1003
#define IDC_FILE_SIZE                   1004
#define IDC_SMOOTH                      1005
#define IDC_SIZE_TEXT                   1006
#define IDC_QUALITY_TEXT                1007
#define IDC_SMOOTH_TEXT                 1008

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        103
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1010
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
