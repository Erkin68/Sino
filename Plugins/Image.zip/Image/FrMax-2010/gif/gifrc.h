//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by gif.rc
//
#define IDS_GIF                         1
#define IDS_BITMAP_IO                   2
#define IDS_GIF_FILE                    3
#define IDS_WRITE_ERROR                 4
#define IDS_LIBDESCRIPTION              5
#define IDD_ABOUT                       101
#define IDD_TARGA_CONTROL               102
#define IDC_16BITS                      1000
#define IDC_24BITS                      1001
#define IDC_COMPRESS                    1003
#define IDC_32BITS                      1004
#define IDC_AUTHORNAME                  1005
#define IDC_JOBNAME                     1006
#define IDC_COMMENTS1                   1007
#define IDC_COMMENTS2                   1008
#define IDC_COMMENTS3                   1009
#define IDC_COMMENTS4                   1010
#define IDC_DITHER                      1011
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1006
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
