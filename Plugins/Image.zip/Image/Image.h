#ifndef _CIMAGE_H_
#define _CIMAGE_H_

#include <windows.h>



class CImagePlgn;
namespace image
{
	//Ob'yazatelniye:
	typedef const wchar_t* (*GetImgExtnsn$4_t)(int);
	typedef const int (*GetPluginType_t)();
	typedef VOID (*SetCallbacks$4xxx_t)(LPVOID,...);
	typedef VOID (*SetId$4_t)(int);
	typedef BOOL (*ProcessView$4_t)(wchar_t*);
	typedef BOOL (*Load$24_t)(wchar_t*,HDC*,HBITMAP*,int*,int*,int*);

	typedef const wchar_t* (*GetPluginDescription_t)();
	typedef VOID (*ShowOptionDialog_t)(HWND);

	extern VOID FreePlugins();
	extern VOID LoadPlugins();
	extern VOID TryLoadPlugin(wchar_t*,wchar_t*,int);
	extern BOOL Load$24(wchar_t*,HDC*,HBITMAP*,int*,int*,int*);

	extern CImagePlgn *plgns;
	extern int numPlugins;
}
using namespace image;


class CImagePlgn
{
friend VOID image::TryLoadPlugin(wchar_t*,wchar_t*,int);

static BOOL  CALLBACK saveOptions(int,VOID*,int);
static BOOL  CALLBACK readOptions(int,VOID*,int);

public:
			CImagePlgn();
		   ~CImagePlgn();

	image::SetId$4_t SetId$4;
	image::GetImgExtnsn$4_t GetImgExtnsn$4;
	image::GetPluginType_t GetPluginType;
	image::GetPluginDescription_t GetPluginDescription;
	image::SetCallbacks$4xxx_t SetCallbacks$4xxx;
	image::ShowOptionDialog_t ShowOptionDialog;

	image::ProcessView$4_t ProcessView$4;
	image::Load$24_t Load$24;

	HMODULE hm;
	//int	dllSize;
	wchar_t pathAndName[MAX_PATH],descrpn[MAX_PATH],extnsn[16][16];
	int     type,idNum,mRef;
	bool	bLoaded;

	BOOL LoadPlugin();
	VOID FreePlugin();
};

#endif