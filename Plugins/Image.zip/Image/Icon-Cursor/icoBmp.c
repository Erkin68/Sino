#include "Plugins_C.h"
#include "stdio.h"
#include "strsafe.h"
#include "icons.h"
#include "..\..\..\Operations\MyShell\MyShellC.h"

#define MAX_STRINGS 24

HMODULE plgnDllInst;
int		plgId=0;

int lookupInDirCnt=0;
__declspec (dllexport) int GetLookupInDirCnt(){return lookupInDirCnt;}

define_exception_type(const char *);
extern struct exception_context the_exception_context[1];

extern void saveOpt();
extern void FreeFindData();

saveOptions_t saveOptions;
readOptions_t readOptions;

//void decompress8BitRLE(u8*&,s32,s32,s32,s32) const;
//void decompress4BitRLE(u8*&,s32,s32,s32,s32) const;



BOOL APIENTRY DllMain(HMODULE hModule,DWORD ul_reason_for_call,LPVOID lpReserved)
{
	switch(ul_reason_for_call)
	{	case DLL_PROCESS_ATTACH:
			plgnDllInst=hModule;
			break;
		case DLL_THREAD_ATTACH:
			break;
		case DLL_THREAD_DETACH:
			break;
		case DLL_PROCESS_DETACH:
			saveOpt();
			break;
	}
	return TRUE;
}

__declspec (dllexport) int GetPluginType()
{
	return 202;
}

__declspec (dllexport) const wchar_t* GetPluginDescription()
{
wchar_t mnuStr[64];
	if(GetEnvironmentVariableW(L"languge",mnuStr,64))//Language instartup qo'yadur;
	{	if(!wcscmp(mnuStr,L"russian"))
			return L"Sino ������ ��������� bmp-������, ������ 1.1";
		else if(!wcscmp(mnuStr,L"uzbekl"))
			return L"Sino bmp-fayllarni ochuvchi plagin, versiya 1.1";
		else if(!wcscmp(mnuStr,L"uzbekk"))
			return L"Sino bmp-��������� ������ ������, ������ 1.1";
		else//if(wcscmp(mnuStr,L"Exit")
			return L"Sino bmp-image view plugin version 1.1";
	}
	//else 
	return L"Sino bmp-image viewplugin version 1.1";
}

__declspec (dllexport) const wchar_t* GetPluginName()
{
	return L"Dib image plugin";
}

__declspec (dllexport) const wchar_t *GetImgExtnsn$4(int t)
{
	switch(t)
	{	case 0:
			return L"bmp";
		case 1:
			return L"dib";
		case 2:
			return L"ico";
		case 3:
			return L"cur";
		case 4:
			return L"ani";
	}
	return NULL;//end of enum
}

void saveOpt()
{	
	//saveOptions(plgId,&item,sizeof(item));
}

__declspec (dllexport) void SetId$4(int id)
{
	plgId = id;
	//readOptions(id,&item,sizeof(item));
}

__declspec (dllexport) VOID SetCallbacks$4xxx(LPVOID frstCallback,...)
{
va_list args;
	va_start(args, frstCallback);//1
	saveOptions = (saveOptions_t)va_arg(args, LPVOID);//7
	readOptions = (readOptions_t)va_arg(args, LPVOID);//8
va_end (args);
}

__declspec (dllexport) void ProcessView$4(wchar_t *pathAndName)
{
STARTUPINFOW si;PROCESS_INFORMATION pi;
wchar_t s[MAX_PATH],cmndLn[MAX_PATH],mnuStr[64];
//int ln = GetModuleFileName(plgnDllInst,s,MAX_PATH-1);
	MyStringCpy(s,MAX_PATH-1,MyStringAddModulePath(L"Plugins\\Executables\\imgviewrel.exe"));
	if(!IsFileExist(s)) return;	
	if(GetEnvironmentVariableW(L"languge",mnuStr,64))//Language instartup qo'yadur;
	{	if(!wcscmp(mnuStr,L"russian"))
			MyStringCpy(cmndLn,18,L" language russian");
		else if(!wcscmp(mnuStr,L"uzbekl"))
			MyStringCpy(cmndLn,17,L" language uzbekl");
		else if(!wcscmp(mnuStr,L"uzbekk"))
			MyStringCpy(cmndLn,17,L" language uzbekk");
	}
	memset(&si,0,sizeof(si));
	MyStringCpy(&cmndLn[1],MAX_PATH-1,pathAndName);
	CreateProcessW(s,cmndLn,NULL,NULL,FALSE,NORMAL_PRIORITY_CLASS,NULL,NULL,&si,&pi);
}

__declspec (dllexport) BOOL LoadIcon$24(wchar_t* pathAndName,HDC* dc,HBITMAP* bm,int* width,int* height,int* bpp)
{
/*ICONINFO ii;HDC d;
HICON hIcon=LoadImage(0,pathAndName,IMAGE_ICON,0,0,LR_LOADFROMFILE|LR_DEFAULTCOLOR);
if(!hIcon)return FALSE;
	GetIconInfo(hIcon,&ii);
	*width=2*ii.xHotspot;
	*height=2*ii.xHotspot;
	*bpp=3;
	d = GetDC(GetDesktopWindow());
	*dc = CreateCompatibleDC(d);
	*bm = CreateCompatibleBitmap(d,*width,*height);
	ReleaseDC(GetDesktopWindow(),d);
	if(!SelectObject(*dc,*bm))
	{	DeleteObject(*dc);
		DeleteObject(*bm);
		return FALSE;
	}
	if(!DrawIcon(*dc,0,0,hIcon))
		DrawIconEx(*dc,0,0,hIcon,0,0,0,NULL,DI_NORMAL);
	DestroyIcon(hIcon);*/

	int i,ml,sz=0,iMax=-1;HICON hIcon=NULL;BOOL ret=FALSE;RECT rc={0,0};HDC d;
LPICONRESOURCE iconRes = ReadIconFromICOFile(pathAndName);
	if(!iconRes)return FALSE;
	//find max sizes:

	lookupInDirCnt=iconRes->nNumImages;

	for(i=0; i<iconRes->nNumImages; ++i)
	{ml=(iconRes->IconImages[i].Width+iconRes->IconImages[i].Height)*iconRes->IconImages[i].Colors;
	 if(ml>sz)
	 {sz=ml;
	  iMax=i;
	}}
	if(iMax<0) goto End;

	*width=iconRes->IconImages[iMax].Width;
	*height=iconRes->IconImages[iMax].Height;
	*bpp=iconRes->IconImages[iMax].Colors;
	if(*bpp>7)*bpp/=8;

	d = GetDC(GetDesktopWindow());
	*dc = CreateCompatibleDC(d);
	*bm = CreateCompatibleBitmap(d,*width,*height);
	ReleaseDC(GetDesktopWindow(),d);
	if(!SelectObject(*dc,*bm))
	{	DeleteObject(*dc);
		DeleteObject(*bm);
		return FALSE;
	}

	hIcon = MakeIconFromResource(&iconRes->IconImages[iMax]);
	if(!hIcon)goto End;

	rc.right=*width;rc.bottom=*height;
	FillRect(*dc,&rc,GetStockObject(WHITE_BRUSH));

	DrawIconEx(*dc,0,0,hIcon,*width,*height,0,NULL,DI_NORMAL);
	//DrawXORMask(*dc,rc,&iconRes->IconImages[iMax]);
    //DrawANDMask(*dc,rc,&iconRes->IconImages[iMax]);

	//:Freeing
	ret=TRUE;
End:for(i=0; i<iconRes->nNumImages; ++i)
	 free(iconRes->IconImages[i].lpBits);
	free(iconRes);
	if(hIcon)DestroyIcon(hIcon);
	return ret;
}

__declspec (dllexport) BOOL LoadImageInDir$28(wchar_t* pathAndName,int iInDir,HDC* dc,HBITMAP* bm,int* width,int* height,int* bpp)
{
	int i,sz=0;HICON hIcon=NULL;BOOL ret=FALSE;RECT rc={0,0};HDC d;
LPICONRESOURCE iconRes = ReadIconFromICOFile(pathAndName);
	if(!iconRes)return FALSE;
	//find max sizes:

	if(iInDir<0 || iInDir>iconRes->nNumImages)goto End;

	*width=iconRes->IconImages[iInDir].Width;
	*height=iconRes->IconImages[iInDir].Height;
	*bpp=iconRes->IconImages[iInDir].Colors;
	if(*bpp>7)*bpp/=8;

	d = GetDC(GetDesktopWindow());
	*dc = CreateCompatibleDC(d);
	*bm = CreateCompatibleBitmap(d,*width,*height);
	ReleaseDC(GetDesktopWindow(),d);
	if(!SelectObject(*dc,*bm))
	{	DeleteObject(*dc);
		DeleteObject(*bm);
		return FALSE;
	}

	hIcon = MakeIconFromResource(&iconRes->IconImages[iInDir]);
	if(!hIcon)goto End;

	rc.right=*width;rc.bottom=*height;
	FillRect(*dc,&rc,GetStockObject(WHITE_BRUSH));

	DrawIconEx(*dc,0,0,hIcon,*width,*height,0,NULL,DI_NORMAL);

	ret=TRUE;
End:for(i=0; i<iconRes->nNumImages; ++i)
	 free(iconRes->IconImages[i].lpBits);
	free(iconRes);
	if(hIcon)DestroyIcon(hIcon);
	return ret;
}

__declspec (dllexport) BOOL LoadCursor$24(wchar_t* pathAndName,HDC* dc,HBITMAP* bm,int* width,int* height,int* bpp)
{ICONINFO ii;HDC d;HICON hCursor;RECT rc={0,0};//BITMAP BM;int x,y;COLORREF rgb;FILE *f=fopen("1.txt","wb");
UINT r=ExtractIconEx(pathAndName,0,&hCursor,NULL,1);
	if(!hCursor)return FALSE;
	GetIconInfo(hCursor,&ii);

	*width=2*ii.xHotspot;
	*height=2*ii.xHotspot;
	*bpp =1;

	d = GetDC(GetDesktopWindow());
	*dc = CreateCompatibleDC(d);
	*bm = CreateCompatibleBitmap(d,*width,*height);
	ReleaseDC(GetDesktopWindow(),d);
	if(!SelectObject(*dc,*bm))
	{	DeleteObject(*dc);
		DeleteObject(*bm);
		return FALSE;
	}

	rc.right=*width;rc.bottom=*height;
	FillRect(*dc,&rc,GetStockObject(WHITE_BRUSH));

	//DrawIcon(*dc,0,0,hCursor);
	DrawIconEx(*dc,0,0,hCursor,*width,*height,0,0,DI_NORMAL);
	DestroyCursor(hCursor);

	/*for(y=0; y<*height; ++y)
	for(x=0; x<*width; ++x)
	{rgb=GetPixel(*dc,x,y);
	 fwrite(&rgb,1,3,f);
	}fclose(f);*/
	DestroyIcon(hCursor);
	return TRUE;
}

__declspec (dllexport) BOOL Load$24(wchar_t* pathAndName,HDC* dc,HBITMAP* bm,int* width,int* height,int* bpp)
{HDC d;int w=0;WORD nNumColors;DWORD offBits;
HGLOBAL bih;LPBITMAPINFOHEADER lpbi;wchar_t *p;

	lookupInDirCnt=0;

	p = wcsrchr(pathAndName,'.');
	if(!p) return FALSE;
	++p;
	if(!_wcsnicmp(p,L"ico",3))
		return LoadIcon$24(pathAndName,dc,bm,width,height,bpp);
	else if((!_wcsnicmp(p,L"cur",3)) || (!_wcsnicmp(p,L"ani",3)))
		return LoadCursor$24(pathAndName,dc,bm,width,height,bpp);

	bih=ReadDIB(pathAndName,&nNumColors,&offBits);
	if(!bih)return FALSE;
	lpbi=GlobalLock(bih);

	*width = lpbi->biWidth;
	*height = lpbi->biHeight;
	*bpp = lpbi->biBitCount;

	//Agar compressed bo'lsa:
	d = GetDC(GetDesktopWindow());
	*dc = CreateCompatibleDC(d);

	if(BI_RGB!=lpbi->biCompression)
	{*bm = LoadImage(0,pathAndName,IMAGE_BITMAP,0,0,LR_LOADFROMFILE);//CreateCompatibleBitmap(d,*width,*height);
	 SelectObject(*dc,*bm);
	 ReleaseDC(GetDesktopWindow(),d);
	 GlobalUnlock(bih);
	 GlobalFree(bih);
	 return TRUE;
	}
	*bm=CreateCompatibleBitmap(d,*width,*height);
	SelectObject(*dc,*bm);
	ReleaseDC(GetDesktopWindow(),d);

/*	wDIBUse = //lpbi->biClrUsed ?
			  //(lpbi->biBitCount!=24?DIB_PAL_COLORS:DIB_RGB_COLORS) :
			  DIB_RGB_COLORS;*/
	w=SetDIBitsToDevice(*dc, 0, 0, *width, *height,
	    				0, 0, 0, *height, 
						(LPSTR)lpbi + offBits, (LPBITMAPINFO)lpbi, DIB_RGB_COLORS);//wDIBUse);
	GlobalUnlock(bih);
	GlobalFree(bih);
	
	return w>0?TRUE:FALSE;
}

/*void decompress8BitRLE(u8*& bmpData, s32 size, s32 width, s32 height, s32 pitch) const
{
	u8* p = bmpData;
	u8* newBmp = new u8[(width+pitch)*height];
	u8* d = newBmp;
	u8* destEnd = newBmp + (width+pitch)*height;
	s32 line = 0;

	while (bmpData - p < size && d < destEnd)
	{
		if (*p == 0)
		{
			++p;

			switch(*p)
			{
			case 0: // end of line
				++p;
				++line;
				d = newBmp + (line*(width+pitch));
				break;
			case 1: // end of bmp
				delete [] bmpData;
				bmpData = newBmp;
				return;
			case 2:
				++p; d +=(u8)*p;  // delta
				++p; d += ((u8)*p)*(width+pitch);
				++p;
				break;
			default:
				{
					// absolute mode
					s32 count = (u8)*p; ++p;
					s32 readAdditional = ((2-(count%2))%2);
					s32 i;

					for (i=0; i<count; ++i)
					{
						*d = *p;
						++p;
						++d;
					}

					for (i=0; i<readAdditional; ++i)
						++p;
				}
			}
		}
		else
		{
			s32 count = (u8)*p; ++p;
			u8 color = *p; ++p;
			for (s32 i=0; i<count; ++i)
			{
				*d = color;
				++d;
			}
		}
	}

	delete [] bmpData;
	bmpData = newBmp;
}

void decompress4BitRLE(u8*& bmpData, s32 size, s32 width, s32 height, s32 pitch) const
{
	s32 lineWidth = (width+1)/2+pitch;
	u8* p = bmpData;
	u8* newBmp = new u8[lineWidth*height];
	u8* d = newBmp;
	u8* destEnd = newBmp + lineWidth*height;
	s32 line = 0;
	s32 shift = 4;

	while (bmpData - p < size && d < destEnd)
	{
		if (*p == 0)
		{
			++p;

			switch(*p)
			{
			case 0: // end of line
				++p;
				++line;
				d = newBmp + (line*lineWidth);
				shift = 4;
				break;
			case 1: // end of bmp
				delete [] bmpData;
				bmpData = newBmp;
				return;
			case 2:
				{
					++p;
					s32 x = (u8)*p; ++p;
					s32 y = (u8)*p; ++p;
					d += x/2 + y*lineWidth;
					shift = x%2==0 ? 4 : 0;
				}
				break;
			default:
				{
					// absolute mode
					s32 count = (u8)*p; ++p;
					s32 readAdditional = ((2-((count)%2))%2);
					s32 readShift = 4;
					s32 i;

					for (i=0; i<count; ++i)
					{
						s32 color = (((u8)*p) >> readShift) & 0x0f;
						readShift -= 4;
						if (readShift < 0)
						{
							++*p;
							readShift = 4;
						}

						u8 mask = 0x0f << shift;
						*d = (*d & (~mask)) | ((color << shift) & mask);

						shift -= 4;
						if (shift < 0)
						{
							shift = 4;
							++d;
						}

					}

					for (i=0; i<readAdditional; ++i)
						++p;
				}
			}
		}
		else
		{
			s32 count = (u8)*p; ++p;
			s32 color1 = (u8)*p; color1 = color1 & 0x0f;
			s32 color2 = (u8)*p; color2 = (color2 >> 4) & 0x0f;
			++p;

			for (s32 i=0; i<count; ++i)
			{
				u8 mask = 0x0f << shift;
				u8 toSet = (shift==0 ? color1 : color2) << shift;
				*d = (*d & (~mask)) | (toSet & mask);

				shift -= 4;
				if (shift < 0)
				{
					shift = 4;
					++d;
				}
			}
		}
	}

	delete [] bmpData;
	bmpData = newBmp;
}*/