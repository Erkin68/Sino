#pragma warning(disable:4995)
#pragma warning(disable:4047)
#pragma warning(disable:4024)

#define _CRT_SECURE_NO_WARNINGS

#include "Plugins_C.h"
#include "stdio.h"
#include "strsafe.h"
#include "png.h"
#include "contrib\visupng\cexcept.h"
#include "..\..\..\Operations\MyShell\MyShellC.h"

#define MAX_STRINGS 24

HMODULE plgnDllInst;
int		plgId=0;

define_exception_type(const char *);
extern struct exception_context the_exception_context[1];
struct exception_context the_exception_context[1];
png_const_charp msg;
static png_structp png_ptr = NULL;
static png_infop info_ptr = NULL;

extern void saveOpt();
extern void FreeFindData();

saveOptions_t saveOptions;
readOptions_t readOptions;

BOOL APIENTRY DllMain(HMODULE hModule,DWORD ul_reason_for_call,LPVOID lpReserved)
{
	switch(ul_reason_for_call)
	{	case DLL_PROCESS_ATTACH:
			plgnDllInst=hModule;
			break;
		case DLL_THREAD_ATTACH:
			break;
		case DLL_THREAD_DETACH:
			break;
		case DLL_PROCESS_DETACH:
			saveOpt();
			break;
	}
	return TRUE;
}

__declspec (dllexport) int GetPluginType()
{
	return 202;
}

__declspec (dllexport) const wchar_t* GetPluginDescription()
{
wchar_t mnuStr[64];
	if(GetEnvironmentVariableW(L"languge",mnuStr,64))//Language instartup qo'yadur;
	{	if(!wcscmp(mnuStr,L"russian"))
			return L"Sino ������ ��������� png-������, ������ 1.1";
		else if(!wcscmp(mnuStr,L"uzbekl"))
			return L"Sino png-fayllarni ochuvchi plagin, versiya 1.1";
		else if(!wcscmp(mnuStr,L"uzbekk"))
			return L"Sino png-��������� ������ ������, ������ 1.1";
		else//if(wcscmp(mnuStr,L"Exit")
			return L"Sino png-image view plugin version 1.1";
	}
	//else 
	return L"Sino png-image viewplugin version 1.1";
}

__declspec (dllexport) const wchar_t* GetPluginName()
{
	return L"png image plugin";
}

__declspec (dllexport) const wchar_t *GetImgExtnsn$4(int t)
{
	switch(t)
	{	case 0:
			return L"png";
	}
	return NULL;//end of enum
}

void saveOpt()
{	
	//saveOptions(plgId,&item,sizeof(item));
}

__declspec (dllexport) void SetId$4(int id)
{
	plgId = id;
	//readOptions(id,&item,sizeof(item));
}

__declspec (dllexport) VOID SetCallbacks$4xxx(LPVOID frstCallback,...)
{
va_list args;
	va_start(args, frstCallback);//1
	saveOptions = (saveOptions_t)va_arg(args, LPVOID);//7
	readOptions = (readOptions_t)va_arg(args, LPVOID);//8
va_end (args);
}

__declspec (dllexport) void ProcessView$4(wchar_t *pathAndName)
{
STARTUPINFOW si;PROCESS_INFORMATION pi;
wchar_t s[MAX_PATH],cmndLn[MAX_PATH],mnuStr[64];
//int ln = GetModuleFileName(plgnDllInst,s,MAX_PATH-1);
	MyStringCpy(s,MAX_PATH-1,MyStringAddModulePath(L"Plugins\\Executables\\pngViewRel.exe"));
	if(!IsFileExist(s)) return;	
	if(GetEnvironmentVariableW(L"languge",mnuStr,64))//Language instartup qo'yadur;
	{	if(!wcscmp(mnuStr,L"russian"))
			MyStringCpy(cmndLn,18,L" language russian");
		else if(!wcscmp(mnuStr,L"uzbekl"))
			MyStringCpy(cmndLn,17,L" language uzbekl");
		else if(!wcscmp(mnuStr,L"uzbekk"))
			MyStringCpy(cmndLn,17,L" language uzbekk");
	}
	memset(&si,0,sizeof(si));
	MyStringCpy(&cmndLn[1],MAX_PATH-1,pathAndName);
	CreateProcessW(s,cmndLn,NULL,NULL,FALSE,NORMAL_PRIORITY_CLASS,NULL,NULL,&si,&pi);
}

static void png_cexcept_error(png_structp png_ptr, png_const_charp msg)
{	if(png_ptr)
		;
#ifdef PNG_CONSOLE_IO_SUPPORTED
   fprintf(stderr, "libpng error: %s\n", msg);
#endif
	{
      Throw msg;
}	}

__declspec (dllexport) BOOL LoadPNG(wchar_t* pstrFileName, png_byte **ppbImageData,
									int *piWidth, int *piHeight, int *piChannels, png_color *pBkgColor)
{
static FILE        *pfFile;
png_byte            pbSig[8];
int                 iBitDepth;
int                 iColorType;
double              dGamma;
png_color_16       *pBackground;
png_uint_32         ulChannels;
png_uint_32         ulRowBytes;
png_byte           *pbImageData = *ppbImageData;
static png_byte   **ppbRowPointers = NULL;
int                 i;

    // open the PNG input file
    if(!pstrFileName)
    {	*ppbImageData = pbImageData = NULL;
        return FALSE;
    }
    if(!(pfFile = _wfopen(pstrFileName, L"rb")))
    {	*ppbImageData = pbImageData = NULL;
        return FALSE;
    }

    // first check the eight byte PNG signature
    fread(pbSig, 1, 8, pfFile);
    if(png_sig_cmp(pbSig, 0, 8))
    {	*ppbImageData = pbImageData = NULL;
        return FALSE;
    }

    // create the two png(-info) structures
    png_ptr = png_create_read_struct(PNG_LIBPNG_VER_STRING, NULL,
      (png_error_ptr)png_cexcept_error, (png_error_ptr)NULL);
    if(!png_ptr)
    {	*ppbImageData = pbImageData = NULL;
        return FALSE;
    }
    info_ptr = png_create_info_struct(png_ptr);
    if(!info_ptr)
    {	png_destroy_read_struct(&png_ptr, NULL, NULL);
        *ppbImageData = pbImageData = NULL;
        return FALSE;
    }

    Try
    {	// initialize the png structure
#ifdef PNG_STDIO_SUPPORTED
        png_init_io(png_ptr, pfFile);
#else
        png_set_read_fn(png_ptr, (png_voidp)pfFile, png_read_data);
#endif
        png_set_sig_bytes(png_ptr, 8);
        // read all PNG info up to image data
        png_read_info(png_ptr, info_ptr);
        // get width, height, bit-depth and color-type
        png_get_IHDR(png_ptr, info_ptr, piWidth, piHeight, &iBitDepth,
            &iColorType, NULL, NULL, NULL);
        // expand images of all color-type and bit-depth to 3x8-bit RGB
        // let the library process alpha, transparency, background, etc.
#ifdef PNG_READ_16_TO_8_SUPPORTED
    if(iBitDepth == 16)
#  ifdef PNG_READ_SCALE_16_TO_8_SUPPORTED
        png_set_scale_16(png_ptr);
#  else
        png_set_strip_16(png_ptr);
#  endif
#endif
        if(iColorType == PNG_COLOR_TYPE_PALETTE)
            png_set_expand(png_ptr);
        if(iBitDepth < 8)
            png_set_expand(png_ptr);
        if(png_get_valid(png_ptr, info_ptr, PNG_INFO_tRNS))
            png_set_expand(png_ptr);
        if(iColorType == PNG_COLOR_TYPE_GRAY ||
            iColorType == PNG_COLOR_TYPE_GRAY_ALPHA)
            png_set_gray_to_rgb(png_ptr);

        // set the background color to draw transparent and alpha images over
        if(png_get_bKGD(png_ptr, info_ptr, &pBackground))
        {	png_set_background(png_ptr, pBackground, PNG_BACKGROUND_GAMMA_FILE, 1, 1.0);
            pBkgColor->red   = (byte) pBackground->red;
            pBkgColor->green = (byte) pBackground->green;
            pBkgColor->blue  = (byte) pBackground->blue;
        }
        else
            pBkgColor = NULL;

        // if required set gamma conversion
        if(png_get_gAMA(png_ptr, info_ptr, &dGamma))
            png_set_gamma(png_ptr, (double) 2.2, dGamma);

        // after the transformations are registered, update info_ptr data
        png_read_update_info(png_ptr, info_ptr);
        // get again width, height and the new bit-depth and color-type
        png_get_IHDR(png_ptr, info_ptr, piWidth, piHeight, &iBitDepth,
            &iColorType, NULL, NULL, NULL);
        // row_bytes is the width x number of channels
        ulRowBytes = (png_uint_32)png_get_rowbytes(png_ptr, info_ptr);
        ulChannels = (png_uint_32)png_get_channels(png_ptr, info_ptr);
        *piChannels = ulChannels;

		// now we can allocate memory to store the image
        if (pbImageData)
        {	free (pbImageData);
            pbImageData = NULL;
        }
        if((pbImageData = (png_byte *) malloc(ulRowBytes * (*piHeight)
                            * sizeof(png_byte))) == NULL)
            png_error(png_ptr, "Visual PNG: out of memory");
        *ppbImageData = pbImageData;

        // and allocate memory for an array of row-pointers
        if((ppbRowPointers = (png_bytepp) malloc((*piHeight)
                            * sizeof(png_bytep))) == NULL)
            png_error(png_ptr, "Visual PNG: out of memory");

        // set the individual row-pointers to point at the correct offsets
        for (i = 0; i < (*piHeight); i++)
            ppbRowPointers[i] = pbImageData + i * ulRowBytes;
        // now we can go ahead and just read the whole image
        png_read_image(png_ptr, ppbRowPointers);
        // read the additional chunks in the PNG file (not really needed)
        png_read_end(png_ptr, NULL);
        // and we're done
        free (ppbRowPointers);
        ppbRowPointers = NULL;
        // yepp, done
    }

    Catch (msg)
    {	png_destroy_read_struct(&png_ptr, &info_ptr, NULL);
        *ppbImageData = pbImageData = NULL;
        if(ppbRowPointers)
            free (ppbRowPointers);
        fclose(pfFile);
        return FALSE;
    }
    fclose (pfFile);
    return TRUE;
}

__declspec (dllexport) BOOL PngLoadImage(wchar_t* pstrFileName, png_byte **ppbImageData,int *piWidth,
										 int *piHeight,int *piChannels, png_color *pBkgColor)
{
static FILE        *pfFile;
png_byte            pbSig[8];
int                 iBitDepth;
int                 iColorType;
double              dGamma;
png_color_16       *pBackground;
png_uint_32         ulChannels;
png_uint_32         ulRowBytes;
png_byte           *pbImageData = *ppbImageData;
static png_byte   **ppbRowPointers = NULL;
int                 i;

    /* open the PNG input file */

    if (!pstrFileName)
    {
        *ppbImageData = pbImageData = NULL;
        return FALSE;
    }

    if(!(pfFile = _wfopen(pstrFileName, L"rb")))//if(!(pfFile = fopen("D:\\Savar\\Auxilary\\Sino\\Plugins\\Image\\libpng\\pngbar.png", "rb")))
    {
        *ppbImageData = pbImageData = NULL;
        return FALSE;
    }

    fread(pbSig, 1, 8, pfFile);
    if (png_sig_cmp(pbSig, 0, 8))
    {
        *ppbImageData = pbImageData = NULL;
        return FALSE;
    }
    png_ptr = png_create_read_struct(PNG_LIBPNG_VER_STRING, NULL,
      (png_error_ptr)png_cexcept_error, (png_error_ptr)NULL);
    if (!png_ptr)
    {
        *ppbImageData = pbImageData = NULL;
        return FALSE;
    }

    info_ptr = png_create_info_struct(png_ptr);
    if (!info_ptr)
    {
        png_destroy_read_struct(&png_ptr, NULL, NULL);
        *ppbImageData = pbImageData = NULL;
        return FALSE;
    }

    Try
    {

        /* initialize the png structure */

#ifdef PNG_STDIO_SUPPORTED
        png_init_io(png_ptr, pfFile);
#else
        png_set_read_fn(png_ptr, (png_voidp)pfFile, png_read_data);
#endif

        png_set_sig_bytes(png_ptr, 8);

        /* read all PNG info up to image data */

        png_read_info(png_ptr, info_ptr);

        /* get width, height, bit-depth and color-type */

        png_get_IHDR(png_ptr,info_ptr,(png_uint_32*)piWidth,(png_uint_32*)piHeight,&iBitDepth,
            &iColorType, NULL, NULL, NULL);

        /* expand images of all color-type and bit-depth to 3x8-bit RGB */
        /* let the library process alpha, transparency, background, etc. */

#ifdef PNG_READ_16_TO_8_SUPPORTED
    if (iBitDepth == 16)
#  ifdef PNG_READ_SCALE_16_TO_8_SUPPORTED
        png_set_scale_16(png_ptr);
#  else
        png_set_strip_16(png_ptr);
#  endif
#endif
        if (iColorType == PNG_COLOR_TYPE_PALETTE)
            png_set_expand(png_ptr);
        if (iBitDepth < 8)
            png_set_expand(png_ptr);
        if (png_get_valid(png_ptr, info_ptr, PNG_INFO_tRNS))
            png_set_expand(png_ptr);
        if (iColorType == PNG_COLOR_TYPE_GRAY ||
            iColorType == PNG_COLOR_TYPE_GRAY_ALPHA)
            png_set_gray_to_rgb(png_ptr);

        /* set the background color to draw transparent and alpha images over */
        if (png_get_bKGD(png_ptr, info_ptr, &pBackground))
        {
            png_set_background(png_ptr, pBackground, PNG_BACKGROUND_GAMMA_FILE, 1, 1.0);
            pBkgColor->red   = (byte) pBackground->red;
            pBkgColor->green = (byte) pBackground->green;
            pBkgColor->blue  = (byte) pBackground->blue;
        }
        else
        {
            pBkgColor = NULL;
        }

        /* if required set gamma conversion */
        if (png_get_gAMA(png_ptr, info_ptr, &dGamma))
            png_set_gamma(png_ptr, (double) 2.2, dGamma);

        /* after the transformations are registered, update info_ptr data */

        png_read_update_info(png_ptr, info_ptr);

        /* get again width, height and the new bit-depth and color-type */

        png_get_IHDR(png_ptr, info_ptr, (png_uint_32*)piWidth, (png_uint_32*)piHeight, &iBitDepth,
            &iColorType, NULL, NULL, NULL);


        /* row_bytes is the width x number of channels */

        ulRowBytes = png_get_rowbytes(png_ptr, info_ptr);
        ulChannels = png_get_channels(png_ptr, info_ptr);

        *piChannels = ulChannels;

        /* now we can allocate memory to store the image */

        if (pbImageData)
        {
            free (pbImageData);
            pbImageData = NULL;
        }
        if ((pbImageData = (png_byte *) malloc(ulRowBytes * (*piHeight)
                            * sizeof(png_byte))) == NULL)
        {
            png_error(png_ptr, "Visual PNG: out of memory");
        }
        *ppbImageData = pbImageData;

        /* and allocate memory for an array of row-pointers */

        if ((ppbRowPointers = (png_bytepp) malloc((*piHeight)
                            * sizeof(png_bytep))) == NULL)
        {
            png_error(png_ptr, "Visual PNG: out of memory");
        }

        /* set the individual row-pointers to point at the correct offsets */

        for (i = 0; i < (*piHeight); i++)
            ppbRowPointers[i] = pbImageData + i * ulRowBytes;

        /* now we can go ahead and just read the whole image */

        png_read_image(png_ptr, ppbRowPointers);

        /* read the additional chunks in the PNG file (not really needed) */

        png_read_end(png_ptr, NULL);

        /* and we're done */

        free (ppbRowPointers);
        ppbRowPointers = NULL;

        /* yepp, done */
    }

    Catch (msg)
    {
        png_destroy_read_struct(&png_ptr, &info_ptr, NULL);

        *ppbImageData = pbImageData = NULL;

        if(ppbRowPointers)
            free (ppbRowPointers);

        fclose(pfFile);

        return FALSE;
    }

    fclose (pfFile);

    return TRUE;
}

__declspec (dllexport) BOOL FillPngBitmap(BYTE *pDiData,int cxWinSize,int cyWinSize,BYTE *pbImage,
				   int cxImgSize,int cyImgSize,int cImgChannels,BOOL bStretched)
{
BYTE *pStretchedImage;
BYTE *pImg;
BYTE *src, *dst;
BYTE r, g, b, a;
const int cDIChannels = 3;
WORD wImgRowBytes;
WORD wDIRowBytes;
int cxNewSize, cyNewSize;
int xImg, yImg;
int xWin, yWin;
int xOld, yOld;
int xNew, yNew;

    if (bStretched)
    {	cxNewSize = cxWinSize;
        cyNewSize = cyWinSize;

        /* stretch the image to it's window determined size */

        /* the following two are mathematically the same, but the first
         * has side-effects because of rounding
         */
/*      if ((cyNewSize / cxNewSize) > (cyImgSize / cxImgSize)) */
        if ((cyNewSize * cxImgSize) > (cyImgSize * cxNewSize))
        {
            cyNewSize = cxNewSize * cyImgSize / cxImgSize;
        }
        else
        {
            cxNewSize = cyNewSize * cxImgSize / cyImgSize;
        }

        pStretchedImage = (BYTE*)malloc (cImgChannels * cxNewSize * cyNewSize);
        pImg = pStretchedImage;

        for (yNew = 0; yNew < cyNewSize; yNew++)
        {
            yOld = yNew * cyImgSize / cyNewSize;
            for (xNew = 0; xNew < cxNewSize; xNew++)
            {
                xOld = xNew * cxImgSize / cxNewSize;

                r = *(pbImage + cImgChannels * ((yOld * cxImgSize) + xOld) + 0);
                g = *(pbImage + cImgChannels * ((yOld * cxImgSize) + xOld) + 1);
                b = *(pbImage + cImgChannels * ((yOld * cxImgSize) + xOld) + 2);
                *pImg++ = r;
                *pImg++ = g;
                *pImg++ = b;
                if (cImgChannels == 4)
                {
                    a = *(pbImage + cImgChannels * ((yOld * cxImgSize) + xOld)
                        + 3);
                    *pImg++ = a;
                }
            }
        }

        /* calculate row-bytes */

        wImgRowBytes = cImgChannels * cxNewSize;
        wDIRowBytes = (WORD) ((cDIChannels * cxWinSize + 3L) >> 2) << 2;

        /* copy image to screen */

        for (yImg = 0, yWin = 0; yImg < cyNewSize; yImg++, yWin++)
        {
            if (yWin >= cyWinSize)
                break;
            src = pStretchedImage + yImg * wImgRowBytes;
            dst = pDiData + yWin * wDIRowBytes;

            for (xImg = 0, xWin = 0; xImg < cxNewSize; xImg++, xWin++)
            {
                if (xWin >= cxWinSize)
                    break;
                r = *src++;
                g = *src++;
                b = *src++;
                *dst++ = b; /* note the reverse order  */
                *dst++ = g;
                *dst++ = r;
                if (cImgChannels == 4)
                {
                    a = *src++;
                }
            }
        }

        /* free memory */

        if (pStretchedImage != NULL)
        {
            free (pStretchedImage);
            pStretchedImage = NULL;
        }

    }

    /* process the image not-stretched */

    else
    {
        /* calculate the central position */

        wImgRowBytes = cImgChannels * cxImgSize;
        wDIRowBytes = (WORD) ((cDIChannels * cxWinSize + 3L) >> 2) << 2;

        /* copy image to screen */

        for (yImg = 0, yWin = 0; yImg < cyImgSize; yImg++, yWin++)
        {
            if (yWin >= cyWinSize)
                break;
            src = pbImage + yImg * wImgRowBytes;
            dst = pDiData + yWin * wDIRowBytes;

            for (xImg = 0, xWin = 0; xImg < cxImgSize; xImg++, xWin++)
            {
                if (xWin >= cxWinSize)
                    break;
                r = *src++;
                g = *src++;
                b = *src++;
                *dst++ = b; /* note the reverse order  */
                *dst++ = g;
                *dst++ = r;

                if (cImgChannels == 4)
                {
                    a = *src++;
                }
            }
        }
    }

    return TRUE;
}

__declspec (dllexport) BOOL InitPngBitmap(BYTE *pDiData,int cxWinSize,int cyWinSize)
{
    BYTE *dst;
    int x, y, col;

    /* initialize the background with gray */

    dst = pDiData;
    for (y = 0; y < cyWinSize; y++)
    {
        col = 0;
        for (x = 0; x < cxWinSize; x++)
        {
            /* fill with GRAY */
            *dst++ = 127;
            *dst++ = 127;
            *dst++ = 127;
            col += 3;
        }
        /* rows start on 4 byte boundaries */
        while ((col % 4) != 0)
        {
            dst++;
            col++;
        }
    }

    return TRUE;
}

__declspec (dllexport) BOOL BuildPngImage(BYTE **ppDib, BYTE **ppDiData, int cxWinSize, int cyWinSize,
        BYTE *pbImage, int cxImgSize, int cyImgSize, int cImgChannels, BOOL bStretched)
{
BYTE                       *pDib = *ppDib;
BYTE                       *pDiData = *ppDiData;
/* BITMAPFILEHEADER        *pbmfh; */
BITMAPINFOHEADER           *pbmih;
WORD                        wDIRowBytes;
BYTE                        bkgBlack[3] = {0, 0, 0};
BYTE						bkgGray[3]  = {127, 127, 127};
BYTE						bkgWhite[3] = {255, 255, 255};

    /* allocate memory for the Device Independant bitmap */

    wDIRowBytes = (WORD) ((3 * cxWinSize + 3L) >> 2) << 2;

    if (pDib)
    {
        free (pDib);
        pDib = NULL;
    }

    if (!(pDib = (BYTE *) malloc (sizeof(BITMAPINFOHEADER) +
        wDIRowBytes * cyWinSize)))
    {
        MessageBox(NULL, TEXT ("Error in displaying the PNG image"),
            L"ImgView", MB_ICONEXCLAMATION | MB_OK);
        *ppDib = pDib = NULL;
        return FALSE;
    }
    *ppDib = pDib;
    memset (pDib, 0, sizeof(BITMAPINFOHEADER));

    /* initialize the dib-structure */

    pbmih = (BITMAPINFOHEADER *) pDib;
    pbmih->biSize = sizeof(BITMAPINFOHEADER);
    pbmih->biWidth = cxWinSize;
    pbmih->biHeight = -((long) cyWinSize);
    pbmih->biPlanes = 1;
    pbmih->biBitCount = 24;
    pbmih->biCompression = 0;
    pDiData = pDib + sizeof(BITMAPINFOHEADER);
    *ppDiData = pDiData;

    /* first fill bitmap with gray and image border */

    InitPngBitmap (pDiData, cxWinSize, cyWinSize);

    /* then fill bitmap with image */

    if (pbImage)
    {
        FillPngBitmap (
            pDiData, cxWinSize, cyWinSize,
            pbImage, cxImgSize, cyImgSize, cImgChannels,
            bStretched);
    }

    return TRUE;
}

__declspec (dllexport) BOOL Load$24(wchar_t* pathAndName,HDC* pdc,HBITMAP* pbm,int* width,int* height,int* bpp)
{
BYTE bkgColor[3] = {127, 127, 127};
BYTE *ppbImage=NULL;HDC DC;DWORD t2;
BYTE *pDib = NULL;BYTE *pDiData = NULL;
BOOL bLoaded,bStretched = FALSE;
wchar_t *p = wcsrchr(pathAndName,'.');

	if(!p) return FALSE;
	++p;
	if(!_wcsicmp(p,L"png"))
		bLoaded = PngLoadImage(pathAndName, &ppbImage, width, height, bpp, &bkgColor);
	if(!bLoaded) 
		return FALSE;

    BuildPngImage(&pDib, &pDiData, *width, *height,
                  ppbImage, *width, *height, *bpp, bStretched);

	DC = GetDC(GetDesktopWindow());
	*pdc = CreateCompatibleDC(DC);
	*pbm = CreateCompatibleBitmap(DC,*width,*height);
	ReleaseDC(GetDesktopWindow(),DC);
	if(!SelectObject(*pdc,*pbm))
	{	DeleteObject(*pdc);
  		DeleteObject(*pbm);
		return FALSE;
	}

    if(pDib)
        t2=SetDIBitsToDevice(*pdc, 0, 0, *width, *height, 0, 0,
                0, *height, pDiData, (BITMAPINFO*)pDib, DIB_RGB_COLORS);
	free(pDib);
	return bLoaded;
}