//-----------------------------------------------------------------------------
// --------------------
// File ....: tif.h
// --------------------
// Author...: Tom Hudson
// Date ....: Feb 1996
// Descr....: TIF File I/O Module
//
// History .: Feb. 20, 1996 - Started file
//            February, 2001.  Major rewrite for TIFF 6.0 support - GL
//-----------------------------------------------------------------------------

#include "tiffconf.h"//compiler defines for libtiff.
#ifdef LZW_SUPPORT
// Uncomment the following when LZW compression is OK'd
//#define ALLOW_LZW_COMPRESSION
#endif


// Need to bracket the C-based library stuff with an explicit declaration:
#ifdef	__cplusplus
extern "C" {
#endif

#include "tiffio.h"
#include "tiffiop.h"

#ifdef	__cplusplus
	}
#endif

#ifdef GEOREFSYS_UVW_MAPPING 
#include "gtiffio.h"
#endif

// Pack all the tif structs
#pragma pack(1)

#define TIFCLASSID 0xfc12

#define DLLEXPORT __declspec(dllexport)

#define TIFVERSION 103		// 101 = Original release
							// 102 = No-compression fix 7/5/96
							// 103 = Rewrite for tiff 6.0 GL, Feb 2001.

#define TIFCONFIGNAME L"tif.cfg")

#define BLOCKSIZE       65536      // changed from 16384 DS 2/15/99

#ifdef ALLOW_LZW_COMPRESSION
/* LZW decode parameters */

#define BITS_MIN    9           /* start with 9 bits */
#define BITS_MAX    12          /* max of 12 bit strings */

/* predefined codes for LZW compression */

#define CODE_CLEAR  256         /* code to clear string table */
#define CODE_EOI    257         /* end-of-information code */
#define CODE_FIRST  258         /* first free code entry */
#define	CODE_MAX	MAXCODE(BITS_MAX)
#define HSIZE       11252       /* 80% occupancy */
/* #define HSIZE       9001  */      /* 80% occupancy */

#define CHECK_GAP	10000		/* enc_ratio check interval */

static	uchar	 rmask[9] =
	{ 0x00, 0x01, 0x03, 0x07, 0x0f, 0x1f, 0x3f, 0x7f, 0xff };
static	uchar lmask[9] =
    { 0x00, 0x80, 0xc0, 0xe0, 0xf0, 0xf8, 0xfc, 0xfe, 0xff };

#undef HSIZE
#define	HSIZE		5003		/* 80% occupancy */
#define	HSHIFT		(8-(16-12))

/* LZW decompression status structure */
#define	LZW_HORDIFF4	0x01		/* hor. diff w/ 4-bit samples */
#define	LZW_HORDIFF8	0x02		/* hor. diff w/ 8-bit samples */
#define	LZW_HORDIFF16	0x04		/* hor. diff w/ 16-bit samples */
#define	LZW_HORDIFF32	0x08		/* hor. diff w/ 32-bit samples */
#define	LZW_RESTART	0x01		/* restart interrupted decode */

struct encode {
	int checkpoint;		/* point at which to clear table */
	long	ratio;			/* current compression ratio */
	long incount;		/* (input) data bytes encoded */
	long outcount;		/* encoded (output) bytes */
	int htab[HSIZE];		/* hash table */
	short	codetab[HSIZE];		/* code table */
   };

typedef struct {
	int  lzw_oldcode;			/* last code encountered */
	BYTE lzw_hordiff;
	WORD lzw_flags;
	WORD lzw_nbits;				/* number of bits/code */
	WORD lzw_stride;		/* horizontal diferencing stride */
	int   lzw_maxcode;			/* maximum code for lzw_nbits */
	long	lzw_bitoff;			 	/* bit offset into data */
	long	lzw_bitsize;			/* size of strip in bits */
	int	lzw_free_ent;			/* next free entry in hash table */
	union {
		struct encode enc;
		} u;
	} LZWState;

#define	enc_checkpoint	u.enc.checkpoint
#define	enc_ratio	u.enc.ratio
#define	enc_incount	u.enc.incount
#define	enc_outcount	u.enc.outcount
#define	enc_htab	u.enc.htab
#define	enc_codetab	u.enc.codetab

#endif//ALLOW_LZW_COMPRESSION

// Stop packing
#pragma pack()

//-----------------------------------------------------------------------------
//-- TIF data Structure -------------------------------------------------------
//

	//Possible storage types from the user interface
enum photometric
	{
	tif_write_mono,
	tif_write_color,	
	tif_write_logl,
	tif_write_logluv,
	tif_write_16bit
	};

//Possible compression types for a tiff image.
enum compression
	{
	tif_compress_none = 0,
	tif_compress_packbits,//usually bilevel images b/w
#ifdef ALLOW_LZW_COMPRESSION
	tif_compress_lzw//works for greyscale and color.
#endif
	};


//#define WRITE_MONO 0
//#define WRITE_COLOR 1

#ifdef GEOREFSYS_UVW_MAPPING //store geoInfo and matrix in .cfg file.
typedef struct _tifuserdata {
     DWORD  version;
	 BOOL	saved;
     BYTE   writeType;
	 BYTE   compressionType;
	 BOOL	writeAlpha;
	 BOOL	disableControl;//disable the standard tiff format popup dialog.
	 BOOL	lightActive;//if the next (or current) frame is being written for the lighting Analysis utility.
					//also force the data to be written using LogL.
	 float	lumStonits;//This is the physically based units factor for luminance-> used to convert data to candelas/meter^2.
	 BOOL	geoInfo;
	 Matrix3 matrix; 
	 BOOL operator==(const _tifuserdata& other);
	 // added a dpi field to structure
	 // David Cunningham, September 7, 2001
	 double dpi;
} TIFUSERDATA;
#else
typedef struct _tifuserdata {
     DWORD  version;
	 BOOL	saved;
     BYTE   writeType;
	 BYTE	compressionType;
	 BOOL	writeAlpha;

	//Specialized options for VIZ Lighting Analysis features using this format.
	 BOOL	disableControl;//disable the standard tiff format popup dialog.
	 BOOL	lightActive;//if the next (or current) frame is being written for the lighting Analysis utility.
					//also force the data to be written using LogL.
	 float	lumStonits;//This is the physically based units factor for luminance -> used to convert data to candelas/meter^2.
	 BOOL operator==(const _tifuserdata& other);
	 double dpi;
} TIFUSERDATA;
#endif  //not DESIGN_VER (max)

#define NO_STONITS	-1.0f

// Reasons for TIF load failure:

#define TIF_SAVE_OK					1
#define TIF_SAVE_WRITE_ERROR		0

#define TIFF_OPTIONS_INTERFACE Interface_ID(0x2a5f32b0, 0x504e42ef)
#define GetTiffInterface(cd) \
	(TiffInterface *)(cd)->GetFPInterface(TIFF_OPTIONS_INTERFACE)



#define GetTiffIOInterface(cd) \
	(BitmapIO_TIF*)(cd)->GetInterface(Interface_ID(TIFCLASSID,0))


//Enumeration of possible methods on the Tif interface.
enum { tif_get_photometric, 
		tif_set_photometric , 
		tif_get_show_control, 
		tif_set_show_control,
		tif_get_compression,
		tif_set_compression,
		tif_get_alpha,
		tif_set_alpha,
		tif_get_dpi,
		tif_set_dpi
 };

//Properties of the same interface.
enum { tif_photo , tif_show_control, tif_compression, tif_alpha, tif_test};


/************************************************************************
/*	
/*	This interface is mainly for the lighting analysis utility, however,
/*	it could be accessed by any client through MAXScript formatting tiff files properly.
/*	
/************************************************************************/

class TiffInterface// : public FPStaticInterface
{
	public:

	virtual photometric GetPhotometric()=0;
	virtual void SetPhotometric(int newPhotometric)=0;

	virtual BOOL GetShowControl()=0;
	virtual void SetShowControl(BOOL show)=0;

	virtual compression GetCompression()=0;
	virtual void SetCompression(int newCompress)=0;
	
	virtual BOOL GetAlpha()=0;
	virtual void SetAlpha(BOOL onOff)=0;

	virtual double GetDPI()=0;
	virtual void SetDPI(double newDPI)=0;
};

//Tiff error handlers for this class...
static void MAXWarningHandler(const wchar_t* module, const wchar_t* fmt, va_list ap);
//static void MAXErrorHandler(const wchar_t* module, const wchar_t* fmt, va_list ap);

//-----------------------------------------------------------------------------
//-- Class Definition ---------------------------------------------------------
//

typedef struct {
   BYTE r,g,b;
} BMM_Color_24;
typedef struct {
   BYTE r,g,b,a;
} BMM_Color_32;

typedef struct {
   WORD r,g,b;
} BMM_Color_48;

typedef struct {
   WORD r,g,b,a;
} BMM_Color_64;
struct BMM_Color_fl
{
   BMM_Color_fl(float vr = 0.0f, float vg = 0.0f, float vb = 0.0f, float va = 0.0f): r(vr), g(vg), b(vb), a(va) {}
   float r,g,b,a;
};


template <class T> class PixelBufT{//: public MaxHeapOperators {
private:
     T *buf;
     int width;
public:
     inline               PixelBufT(int width) { buf = (T *)malloc(width*sizeof(T)); this->width=width; };//MAX_calloc(width,sizeof(T)); this->width=width; };
     inline               ~PixelBufT() { if(buf) free(buf); };//MAX_free(buf); };
     inline   T*          Ptr() { return buf; };
	 inline   T&          operator[](int i) { return buf[i]; }
           int            Fill(int start, int count, T color) {
                          int ix,jx=start+count;
                          if(jx > width) // MAB - 07/15/03 - changed from >=
                             return 0;
                          for(ix=start; ix<jx; buf[ix++]=color);
                          return 1;
                          };
     };
#define BMMIO_READER             (1<<0)
#define BMMIO_WRITER             (1<<1)
#define BMMIO_EXTENSION          (1<<2)
#define BMMIO_MULTIFRAME         (1<<3)
#define BMMIO_CONTROLWRITE       (1<<30)
#define BMMRES_BADFILEHEADER     13
#define BMM_NO_TYPE              0
#define BMM_LINE_ART             1
#define BMM_GRAY_8               3 
#define BMM_GRAY_16              4   //!<  16-bit grayscale bitmap.
#define BMM_TRUE_16              5   //!<  16-bit true color image.
#define BMM_TRUE_32              6   //!<  32-bit color: 8 bits each for Red, Green, Blue, and Alpha.
#define BMM_TRUE_64              7   //!<  64-bit color: 16 bits each for Red, 
#define BMM_PALETTED             2
#define BMM_LOGLUV_32            13
#define BMMRES_SUCCESS           0
#define MAP_HAS_ALPHA            ((DWORD)(1<<1))
#define BMM_TRUE_24              8    //!< 24-bit color: 8 bits each for Red, Green, and Blue. Cannot be written to.
#define BMM_TRUE_48              9    //!< 48-bit color: 16 bits each for Red, Green, and Blue. Cannot be written to.
#define BMM_YUV_422              10   //!< This is the YUV format - CCIR 601. Cannot be written to.
#define BMM_BMP_4                11   //!< Windows BMP 16-bit color bitmap.  Cannot be written to.
#define BMM_PAD_24               12   //!< Padded 24-bit (in a 32 bit register).  Cannot be written to.
#define BMM_LOGLUV_24A           15
#define BMM_REALPIX_32           16   //!<  The "Real Pixel" format.
#define BMM_FLOAT_RGBA_32        17   //!<  32-bit floating-point per component (non-compressed), RGB with or without alpha
#define BMM_FLOAT_GRAY_32        18   //!<  32-bit floating-point (non-compressed), monochrome/grayscale
#define BMM_FLOAT_RGB_32         19
#define BMM_FLOAT_A_32           20

#define BMM_NOT_OPEN             0	//!< Not opened yet
#define BMM_OPEN_R               1	//!< Read-only
#define BMM_OPEN_W               2	//!< Write-only. No reads will occur.



typedef unsigned short BMMRES;
typedef unsigned char UBYTE;
typedef unsigned char uchar;
typedef PixelBufT<UBYTE> PixelBuf8;
typedef PixelBufT<USHORT> PixelBuf16;
typedef PixelBufT<BMM_Color_24> PixelBuf24;
typedef PixelBufT<BMM_Color_32> PixelBuf32;
typedef PixelBufT<BMM_Color_48> PixelBuf48;
typedef PixelBufT<BMM_Color_64> PixelBuf64;
typedef PixelBufT<BMM_Color_fl> PixelBufFloat;
typedef PixelBufT<BMM_Color_64> PixelBuf;

//-----------------------------------------------------------------------------
//-- Class Definition ---------------------------------------------------------
//
class BitmapInfo
{
public:
	int type;
	int flags;
	int storageType;
	int width,height;
	float gamma,aspect;
	wchar_t name[MAX_PATH];
	VOID SetWidth(int w){width=w;}
	VOID SetHeight(int h){height=h;}
	VOID SetGamma(float g){gamma=g;}
	VOID SetAspect(float a){aspect=a;}
	VOID SetType(int t){type=t;}
	wchar_t* Name(){return &name[0];}
	void SetFlags(int f){flags=f;}
	//void* AllocPiData(int sz){return malloc(sz);};
};

class BitmapStorage
{
//protected:
public:
	  int                      openMode;                   // See above
	  UINT                     usageCount;                 // Number of Bitmaps using this storage
	  int                      flags;
	  int                      type;                       // See "Basic bitmap types", below
	  int                      rowBytes,rowPadds;          // See "Basic bitmap types", below
	  float					   gamma;

	  BITMAPINFOHEADER		   bmiHeader;	
	  BMM_Color_32			   bmiColors[256];             // 256 palette entries max
	  //int                     paletteSlots;
	  UWORD                    *gammaTable;                // Gamma correction table
	  BYTE					   *RGBs;	
	  //BOOL				   Allocate(BitmapInfo*,int){return 1;}
	  void					   Free(){free(RGBs);}

	  int					   SetPalette(int start,int count,BMM_Color_48 *ptr);
//	  GBuffer                  *gbuffer;

	  /* Send a line of pixels to the screen */
	  int  PutIndexPixels ( int x,int y,int pixels,BYTE *ptr );
	  int  PutPixels ( int x,int y,int pixels,BMM_Color_64 *ptr );
	  int  PutPixels ( int x,int y,int pixels,BMM_Color_fl *ptr );
	  void ClearFlags( DWORD f ) { flags &= (~f); }

	  float SetGamma(float c) { float o = gamma;gamma = c; return (o);}
	  int   GetPixels( int x,int y,int pixels,BMM_Color_64 *ptr ){return 0;}
//			{ if (storage) return storage->GetPixels(x,y,pixels,ptr); return 0; };


public:
};

class BitmapIO_TIF// : public BitmapIO{
{    
//   private:
public:
     
//      Bitmap *loadMap;
	    int openMode;
		BitmapStorage *loadStorage;
		BitmapStorage *saveStorage;
        FILE   *inStream;
        FILE   *outStream;
		
		BOOL load_alpha;
		int nsamp;	// Number of samples per pixel
		int width, height;
		BYTE *loadbuf;
		TIFF *tif;
		WCHAR fileName[MAX_PATH];
		TIFFDirectory *td;

      TIFUSERDATA   UserData;

        //-- This handler's private functions

        BitmapStorage *ReadTIFFile( BitmapInfo *fbi, /*BitmapManager *manager,*/ BMMRES *status);
		BitmapStorage *LoadTIFStuff(BitmapInfo *fbi);//, BitmapManager *manager );
     	BitmapStorage *TifReadLineArt(BitmapInfo *fbi);//, BitmapManager *manager);
     	BitmapStorage *TifReadGrayScale(BitmapInfo *fbi);//, BitmapManager *manager);
     	BitmapStorage *TifReadGrayScale16(BitmapInfo *fbi);//, BitmapManager *manager);
     	BitmapStorage *TifReadPlanarRGB(BitmapInfo *fbi);//, BitmapManager *manager);
     	BitmapStorage *TifReadChunkyRGB(BitmapInfo *fbi);//, BitmapManager *manager);
		void ScrunchColorMap(BMM_Color_48 *colpal);
    	BitmapStorage *TifReadColPal(BitmapInfo *fbi);//, BitmapManager *manager);
		BitmapStorage *TifReadLogLUV(BitmapInfo* fbi);//, BitmapManager* manager);

		// Write stuff:
		unsigned short rps, spp;
		long rawcc;
#ifdef ALLOW_LZW_COMPRESSION
		LZWState lzw_state;
		BYTE *comp_buf;
#endif
		BYTE *shortstrip;
		BMM_Color_64 *scanline;
		BMM_Color_fl* scanline_fl;
		BOOL write_alpha;
		void MakeTiffhead();
 		int SaveTIF(/*FILE *stream*/);
		BOOL WriteTIF(FILE *stream);
		int LZWPreEncode(void);
		int LZWEncode(uchar *bp, int cc );
		int LZWPostEncode(void);
		void PutNextCode(int c);
		void ClearBlock(void);
		void ClearHash();

        void           GetCfgFilename     ( WCHAR *filename );
        BOOL           ReadCfg            ( );
        void           WriteCfg           ( );

     public:
     
        //-- Constructors/Destructors
        
                       BitmapIO_TIF       ( );
                      ~BitmapIO_TIF       ( );

        //-- Number of extemsions supported
        
		#ifndef GEOREFSYS_UVW_MAPPING 
        int            ExtCount           ( )       { return 1;}
		#else
		int            ExtCount           ( )       { return 2;}
		#endif 
        
        //-- Extension #n (i.e. "3DS")
        
		#ifndef GEOREFSYS_UVW_MAPPING 
        const WCHAR   *Ext                ( int n ) { return L"tif"; }
		#else
		const WCHAR   *Ext                ( int n ) { return (n==1) ? L"tiff") : L"tif"); }
		#endif 
        
        //-- Descriptions
        
        const WCHAR   *LongDesc           ( );
        const WCHAR   *ShortDesc          ( );

        //-- Miscelaneous Messages
        
        const WCHAR   *AuthorName         ( )       { return L"Tom Hudson";}
        const WCHAR   *CopyrightMessage   ( )       { return L"Copyright 1996 Yost Group";}
        UINT           Version            ( )       { return (101);}//Changed from 100 GL March '01

        //-- Driver capabilities
        // If UserData.lightActive is set, then we will do multi-frame
        // tiff files, so make sure the Capability reflects this. CA - 312242
        int            Capability         ( )       { return UserData.lightActive
														? BMMIO_READER    | 
                                                             BMMIO_WRITER    | 
                                                             BMMIO_EXTENSION |
															 BMMIO_CONTROLWRITE |
															 BMMIO_MULTIFRAME
														: BMMIO_READER    | 
                                                             BMMIO_WRITER    | 
                                                             BMMIO_EXTENSION |
															 BMMIO_CONTROLWRITE; }
        //-- Driver Configuration
        
        BOOL           LoadConfigure      ( void *ptr );
        BOOL           SaveConfigure      ( void *ptr );
        DWORD          EvaluateConfigure  ( );
        
        //-- Show DLL's "About..." box
        
        void           ShowAbout          ( HWND hWnd );  

        //-- Show DLL's Control Panel
        
        BOOL           ShowControl        ( HWND hWnd, DWORD flag );

        //-- Return info about image
        
        BMMRES         GetImageInfo       ( BitmapInfo *fbi );        

        //-- Image Input

        /**
         * Note:
         * To extract LUMINANCE INFORMATION from the tif file, the client should first
         * call this Load method.  The TIFUSERDATA structure is stored in the BitmapInfo
         * parameter passed to the method.  
         * Then extract this data using this call:  
         * TIFUSERDATA* tifInfo= (TIFUSERDATA*)fbi->GetPiData();
         * The luminance value is stored in tifInfo.lumStonits.
         */
        
        BitmapStorage *Load               ( BitmapInfo *fbi/*, Bitmap *map*/, BMMRES *status);

        //-- Image Output
        
        BMMRES         OpenOutput         ( BitmapInfo *fbi);//, Bitmap *map );
        BMMRES         Write              ( int frame );
        int            Close              ( int flag );
  
        //-- This handler's specialized functions
        
        INT_PTR        Control            ( HWND ,UINT ,WPARAM ,LPARAM );

        friend class TiffInterfaceImp;
};
