#include "Plugins_CPP.h"
#include "stdio.h"
#include "strsafe.h"
#include "From MAX-2010\tif.h"
#include "..\..\..\Operations\MyShell\MyShell.h"


#define MAX_STRINGS 24

HINSTANCE plgnDllInst;
int		plgId=0;

int lookupInDirCnt=0;

extern "C"
{
__declspec (dllexport) int GetLookupInDirCnt(){return lookupInDirCnt;}

extern void saveOpt();
extern void FreeFindData();

saveOptions_t saveOptions;
readOptions_t readOptions;
}

//void decompress8BitRLE(u8*&,s32,s32,s32,s32) const;
//void decompress4BitRLE(u8*&,s32,s32,s32,s32) const;



BOOL APIENTRY DllMain(HMODULE hModule,DWORD ul_reason_for_call,LPVOID lpReserved)
{
	switch(ul_reason_for_call)
	{	case DLL_PROCESS_ATTACH:
			plgnDllInst=hModule;
			break;
		case DLL_THREAD_ATTACH:
			break;
		case DLL_THREAD_DETACH:
			break;
		case DLL_PROCESS_DETACH:
			saveOpt();
			break;
	}
	return TRUE;
}

extern "C"
{
__declspec (dllexport) int GetPluginType()
{
	return 202;
}

__declspec (dllexport) const wchar_t* GetPluginDescription()
{
wchar_t mnuStr[64];
	if(GetEnvironmentVariableW(L"languge",mnuStr,64))//Language instartup qo'yadur;
	{	if(!wcscmp(mnuStr,L"russian"))
			return L"Sino ������ ��������� tiff-������, ������ 1.1";
		else if(!wcscmp(mnuStr,L"uzbekl"))
			return L"Sino tiff-fayllarni ochuvchi plagin, versiya 1.1";
		else if(!wcscmp(mnuStr,L"uzbekk"))
			return L"Sino tiff-��������� ������ ������, ������ 1.1";
		else//if(wcscmp(mnuStr,L"Exit")
			return L"Sino tiff-image view plugin version 1.1";
	}
	//else 
	return L"Sino tiff-image viewplugin version 1.1";
}

__declspec (dllexport) const wchar_t* GetPluginName()
{
	return L"Tiff image plugin";
}

__declspec (dllexport) const wchar_t *GetImgExtnsn$4(int t)
{
	switch(t)
	{	case 0:
			return L"tif";
	}
	return NULL;//end of enum
}

void saveOpt()
{	
	//saveOptions(plgId,&item,sizeof(item));
}

__declspec (dllexport) void SetId$4(int id)
{
	plgId = id;
	//readOptions(id,&item,sizeof(item));
}

__declspec (dllexport) VOID SetCallbacks$4xxx(LPVOID frstCallback,...)
{
va_list args;
	va_start(args, frstCallback);//1
	saveOptions = (saveOptions_t)va_arg(args, LPVOID);//7
	readOptions = (readOptions_t)va_arg(args, LPVOID);//8
va_end (args);
}

__declspec (dllexport) BOOL LoadImageInDir$28(wchar_t* pathAndName,int iInDir,HDC* dc,HBITMAP* bm,int* width,int* height,int* bpp)
{
	return TRUE;
}

__declspec (dllexport) BOOL Load$24(wchar_t* pathAndName,HDC* dc,HBITMAP* bm,int* width,int* height,int* bpp)
{
 BitmapIO_TIF fbi;BitmapInfo bi;BMMRES status;
 MyStringCpy(bi.name,MAX_PATH,pathAndName);
 BitmapStorage *strg=fbi.ReadTIFFile(&bi,&status);
 if(!strg)return FALSE;

 *width=strg->bmiHeader.biWidth;
 *height=strg->bmiHeader.biHeight;
 *bpp=strg->bmiHeader.biBitCount;
 
 HDC d = GetDC(GetDesktopWindow());
 *dc = CreateCompatibleDC(d);
 *bm = CreateCompatibleBitmap(d,*width,*height);
 ReleaseDC(GetDesktopWindow(),d);
 SelectObject(*dc,*bm);

 strg->bmiHeader.biHeight = -strg->bmiHeader.biHeight;
 int w=SetDIBitsToDevice(*dc,0,0,*width,*height,
						 0,0,0,*height,
						 strg->RGBs,
						(BITMAPINFO*)&strg->bmiHeader,
						 DIB_RGB_COLORS);//(BMM_PALETTED==strg->type)?DIB_PAL_COLORS:DIB_RGB_COLORS);
 if(0==w)w=GetLastError();
 strg->Free();
 free(strg);
 return TRUE;
}

}