//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by BinEdit.rc
//
#define IDR_SINOSTRING1                 105
#define IDI_ICON2                       106
#define IDR_MENU1                       107
#define IDD_DIALOG_ABOUT                108
#define IDD_DIALOG2                     109
#define IDD_DIALOG_WIDTH_PERCENT        109
#define IDR_SINOSTRING2                 110
#define IDD_DIALOG3                     111
#define IDD_DIALOG_COPY_CLIPBOARD_TO_FILE 111
#define IDD_DIALOG_SEARCH               112
#define IDD_DIALOG_INS_DEL              113
#define IDC_SLIDER1                     1012
#define IDC_BUTTON_BROWSE               1014
#define IDC_EDIT_NUMB_OF_BYTES          1015
#define IDC_EDIT1                       21480
#define IDC_STATIC1                     21570
#define IDC_STATIC2                     21571
#define IDC_STATIC3                     21572
#define IDC_STATIC4                     21574
#define ID_FILE_EXIT                    40001
#define IDM_FILE                        40002
#define IDM_EXIT                        40003
#define IDM_ABOUT                       40005
#define ID_VIEW_TEXT                    40006
#define ID_Menu                         40007
#define ID_VIEW_DIGIT                   40008
#define ID_TEXT_CHAR                    40013
#define ID_TEXT_WIDECHAR                40014
#define ID_FILE_SAVEAS                  40016
#define ID_VIEW_ADDRESS                 40018
#define ID_TEXT_FONT                    40019
#define ID_DIGIT_FONT                   40020
#define ID_ADDRESS_FONT                 40021
#define ID_ADDRESS_WIDTH                40022
#define ID_DIGIT_WIDTH                  40023
#define ID_TEXT_WIDTH                   40024
#define ID_ADDRESS_OCT                  40025
#define ID_ADDRESS_DEC                  40026
#define ID_ADDRESS_HEX                  40027
#define ID_ADDRESS_FILLZERO             40028
#define ID_ADDRESS_ALIGNRIGHT           40029
#define ID_ADDRESS_ALIGNLEFT            40030
#define ID_ADDRESS_ALIGNCENTER          40031
#define ID_VIEW_HORIZONTALSPACE         40032
#define ID_VIEW_VERTICALSPACE           40033
#define ID_ADDRESS_COLOR                40034
#define ID_DIGIT_COLOR                  40035
#define ID_ADDRESS_TEXTCOLOR            40036
#define ID_DIGIT_TEXTCOLOR              40037
#define ID_TEXT_BACKCOLOR               40038
#define ID_TEXT_TEXTCOLOR               40039
#define ID_DIGIT_ALIGNRIGHT             40040
#define ID_DIGIT_ALIGNCENTER            40041
#define ID_DIGIT_ALIGNLEFT              40042
#define ID_DIGIT_ALIGNVERTICALCE        40043
#define ID_ADDRESS_ALIGNVERTICALCENTER  40044
#define ID_TEXT_ALIGNRIGHT              40045
#define ID_TEXT_ALIGNCENTER             40046
#define ID_TEXT_ALIGNLEFT               40047
#define ID_TEXT_ALIGNVERTICALCENTER     40048
#define ID_FILE_OPEN1                   40049
#define ID_FILE_SAVE1                   40050
#define ID_EDIT_COPY40051               40051
#define ID_VIEW_FIND                    40053
#define ID_Menu40054                    40054
#define ID_ADDRESS_HORIZONTALSPACE      40055
#define ID_ADDRESS_HORIZONTALSPACE40056 40056
#define ID_ADDRESS_VERTICAL             40057
#define ID_DIGIT_HORIZONTALSPACE        40058
#define ID_DIGIT_VERTICALSPACE          40059
#define ID_TEXT_HORIZONTALSPACE         40060
#define ID_TEXT_VERTICALSPACE           40061
#define ID_ADDRESS_VERTICALSPACE        40062
#define ID_DIGIT_ALIGNVERTICALCENTER    40063
#define ID_ADDRESS_SHOWROWNUMBER        40064
#define ID_TEXT_WIDECHARFROMODDPOSITION 40065
#define ID_VIEW_FINDNEXT                40067
#define IDC_EDIT_SEARCH_TEXT            40068
#define IDC_CHECK_2                     40069
#define IDC_EDIT_FIND_ADDRESS           40070
#define IDC_EDIT_FIND_LENGTH            40071
#define IDC_EDIT_FIND_CMNT              40072
#define IDC_CHECK_8                     40073
#define IDC_PROGRESS1                   40074
#define IDC_CHECK_10                    40075
#define IDC_CHECK_16                    40076
#define IDC_CHECK_DOWN                  40077
#define IDC_CHECK_UP                    40078
#define IDC_CHECK_FROM_START            40079

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        114
#define _APS_NEXT_COMMAND_VALUE         40080
#define _APS_NEXT_CONTROL_VALUE         1016
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
