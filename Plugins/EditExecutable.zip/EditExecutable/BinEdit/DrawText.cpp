#include "BinEdit.h"
#include "strsafe.h"



COLORREF textColorText=RGB(255,255,255),backColorText=RGB(160,95,157);
HFONT fntText;
LOGFONT textLogFont;
HBRUSH textBackBrsh;
UINT textFmt=DT_CENTER|DT_VCENTER,textFmtDesc=8;

int xSpaceText=8;


VOID DrawTexts(HDC hDC,RECT *rDC)
{wchar_t s[MAX_PATH];
 RECT rc={(perCentOfAddr+perCentOfBin)*rDC->right/100+1,0,rDC->right,rDC->bottom};
 FillRect(hDC,&rc,textBackBrsh);
 
 rc.left=(perCentOfAddr+perCentOfBin)*rDC->right/100+2;
 rc.right = rDC->right-1;
 rc.top=0;
 rc.bottom=ySpaceBin;

 if(textFmt & DT_VCENTER)
	 rc.top += 5;
 if(textFmt & DT_RIGHT)
	 rc.left += 20;
 else if(textFmt & DT_CENTER)
	 rc.left += 10;
 //int left = rc.left;

 SetBkColor(hDC,backColorText);
 SetTextColor(hDC,textColorText);
 HFONT oldFnt=(HFONT)SelectObject(hDC,fntText);

 unsigned char *p = (unsigned char*)pFileBase+iAddressView;
 unsigned __int64 iiAddress=iAddressView;

 INT *dists=(INT*)malloc(nViewColumns*sizeof(INT));
 for(int i=0; i<nViewColumns; dists[i++]=xSpaceText);

 s[nViewColumns]=0;
 for(int row=0; row<nViewRows; ++row)
 {	int colmn;
	for(colmn=0; colmn<(nViewColumns<MAX_PATH?nViewColumns:MAX_PATH); ++colmn)
	{	if(++iiAddress>sz)
			break;
		s[colmn]=*p++;
		if(0==s[colmn])s[colmn]='.';
	}
	ExtTextOut(hDC,rc.left,rc.top,ETO_OPAQUE|ETO_CLIPPED,&rc,s,colmn,dists);//ETO_IGNORELANGUAGE
	//DrawText(hDC,s,nViewColumns<MAX_PATH?nViewColumns:MAX_PATH,&rc,DT_LEFT);
	rc.top += ySpaceBin;
	rc.bottom += ySpaceBin;
 }
 SelectObject(hDC,oldFnt);
 free(dists);
}

VOID DrawTexts16Odd(HDC hDC,RECT *rDC)
{wchar_t s[MAX_PATH];
 RECT rc={(perCentOfAddr+perCentOfBin)*rDC->right/100+1,0,rDC->right,rDC->bottom};
 FillRect(hDC,&rc,textBackBrsh);
 
 rc.left=(perCentOfAddr+perCentOfBin)*rDC->right/100+2;
 rc.right = rDC->right-1;
 rc.top=0;
 rc.bottom=ySpaceBin;

 if(textFmt & DT_VCENTER)
	 rc.top += 5;
 if(textFmt & DT_RIGHT)
	 rc.left += 20;
 else if(textFmt & DT_CENTER)
	 rc.left += 10;
 //int left = rc.left;

 SetBkColor(hDC,backColorText);
 SetTextColor(hDC,textColorText);
 HFONT oldFnt=(HFONT)SelectObject(hDC,fntText);

 wchar_t *p = (wchar_t*)((char*)pFileBase+iAddressView);
 unsigned __int64 iiAddress=iAddressView;

 INT *dists=(INT*)malloc(nViewColumns*sizeof(INT));
 for(int i=0; i<nViewColumns; dists[i++]=xSpaceText);

 s[nViewColumns]=0;
 for(int row=0; row<nViewRows; ++row)
 {	int colmn;
	for(colmn=0; colmn<(nViewColumns<MAX_PATH?nViewColumns:MAX_PATH)/2; ++colmn)
	{	iiAddress += 2;
		if(iiAddress>sz)
			break;
		s[colmn]=*p++;
		if(0==s[colmn])s[colmn]='.';
	}
	if(colmn%2)p=(wchar_t*)(((char*)p)+1);
	ExtTextOut(hDC,rc.left,rc.top,ETO_OPAQUE|ETO_CLIPPED,&rc,s,colmn,dists);
	rc.top += ySpaceBin;
	rc.bottom += ySpaceBin;
 }
 SelectObject(hDC,oldFnt);
 free(dists);
}

VOID DrawTexts16Even(HDC hDC,RECT *rDC)
{wchar_t s[MAX_PATH];
 RECT rc={(perCentOfAddr+perCentOfBin)*rDC->right/100+1,0,rDC->right,rDC->bottom};
 FillRect(hDC,&rc,textBackBrsh);
 
 rc.left=(perCentOfAddr+perCentOfBin)*rDC->right/100+2;
 rc.right = rDC->right-1;
 rc.top=0;
 rc.bottom=ySpaceBin;

 if(textFmt & DT_VCENTER)
	 rc.top += 5;
 if(textFmt & DT_RIGHT)
	 rc.left += 20;
 else if(textFmt & DT_CENTER)
	 rc.left += 10;
 //int left = rc.left;

 SetBkColor(hDC,backColorText);
 SetTextColor(hDC,textColorText);
 HFONT oldFnt=(HFONT)SelectObject(hDC,fntText);

 wchar_t *p = (wchar_t*)((char*)pFileBase+iAddressView+1);
 unsigned __int64 iiAddress=iAddressView+1;

 INT *dists=(INT*)malloc(nViewColumns*sizeof(INT));
 for(int i=0; i<nViewColumns; dists[i++]=xSpaceText);

 s[nViewColumns]=0;
 for(int row=0; row<nViewRows; ++row)
 {	int colmn;
	for(colmn=0; colmn<(nViewColumns<MAX_PATH?nViewColumns:MAX_PATH)/2; ++colmn)
	{	iiAddress += 2;
		if(iiAddress>sz)
			break;
		s[colmn]=*p++;
		if(0==s[colmn])s[colmn]='.';
	}
	if(colmn%2)p=(wchar_t*)(((char*)p)+1);
	ExtTextOut(hDC,rc.left,rc.top,ETO_OPAQUE|ETO_CLIPPED,&rc,s,colmn,dists);
	rc.top += ySpaceBin;
	rc.bottom += ySpaceBin;
 }
 SelectObject(hDC,oldFnt);
 free(dists);
}