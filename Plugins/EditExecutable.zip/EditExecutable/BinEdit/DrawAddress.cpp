#include "BinEdit.h"
#include "strsafe.h"




COLORREF textColorAddr=RGB(0x6a,0xfc,255),backColorAddr=RGB(255,0,255);
int addrMaxWidth8=8,addrMaxWidth10=8,addrMaxWidth16=8;
unsigned __int64 iAddressView=0;
HFONT fntAddr;
LOGFONT addrLogFont;
HBRUSH adrrBackBrsh;
BOOL bAddrShowRowNum=TRUE;

int xSpaceAddr=5;

VOID DrawAddress(HDC hDC,RECT *rDC)
{wchar_t s[MAX_PATH],sfmt[32];
 
 RECT rc={0,0,perCentOfAddr*rDC->right/100,rDC->bottom};
 FillRect(hDC,&rc,adrrBackBrsh);
 
 rc.left=rc.top=0;rc.right=perCentOfAddr*rDC->right/100;rc.bottom=ySpaceBin;

 if(addrFmt & DT_VCENTER)
	 rc.top += 5;
 if(addrFmt & DT_RIGHT)
	 rc.left += 20;
 else if(addrFmt & DT_CENTER)
	 rc.left += 10;

 SetBkColor(hDC,backColorAddr);
 SetTextColor(hDC,textColorAddr);
 HFONT oldFnt=(HFONT)SelectObject(hDC,fntAddr);

 if(bAddrShowRowNum)
 {	switch(addrFmtDesc)
	{	case 8:
			if(addrFillZero)
				StringCchPrintf(sfmt,32,L"%s%d%s",L"%o %0",addrMaxWidth8,L"o");
			else
				StringCchPrintf(sfmt,MAX_PATH-1,L"%s",L"%o %o");
			break;
		case 10:
			if(addrFillZero)
				StringCchPrintf(sfmt,MAX_PATH-1,L"%s%d%s",L"%d %0",addrMaxWidth10,L"d");
			else
				StringCchPrintf(sfmt,MAX_PATH-1,L"%s",L"%d %u");
			break;
		case 16:
			if(addrFillZero)
				StringCchPrintf(sfmt,MAX_PATH-1,L"%s%d%s",L"%0",addrMaxWidth16,L"X");
			else
				StringCchPrintf(sfmt,MAX_PATH-1,L"%s",L"%0X");
			break;
 }	 }
 else
 {	switch(addrFmtDesc)
	{	case 8:
			if(addrFillZero)
				StringCchPrintf(sfmt,32,L"%s%d%s",L"%0",addrMaxWidth8,L"o");
			else
				StringCchPrintf(sfmt,MAX_PATH-1,L"%s",L"%o %o");
			break;
		case 10:
			if(addrFillZero)
				StringCchPrintf(sfmt,MAX_PATH-1,L"%s%d%s",L"%0",addrMaxWidth10,L"d");
			else
				StringCchPrintf(sfmt,MAX_PATH-1,L"%s",L"%u");
			break;
		case 16:
			if(addrFillZero)
				StringCchPrintf(sfmt,MAX_PATH-1,L"%s%d%s",L"%0",addrMaxWidth16,L"X");
			else
				StringCchPrintf(sfmt,MAX_PATH-1,L"%s",L"%0X");
			break;
 }	 }

 unsigned __int64 iiAddressView = iAddressView;
 int orRow = (int)(iAddressView / nViewColumns);
 INT dists[16];for(int i=0; i<16; dists[i++]=xSpaceAddr);
 int l=0;
 for(int row=0; row<nViewRows; ++row)
 {	if(bAddrShowRowNum)
		StringCchPrintf(s,MAX_PATH-1,sfmt,orRow+row,iiAddressView);
 	else
		StringCchPrintf(s,MAX_PATH-1,sfmt,iiAddressView);
	//DrawText(hDC,s,-1,&rc,addrFmt);
    l = (int)wcslen(s);
	ExtTextOut(hDC, rc.left, rc.top, ETO_OPAQUE|ETO_CLIPPED, &rc, s, l, dists); 
	iiAddressView += nViewColumns;
	if(iiAddressView>sz)
		break;
	rc.top += ySpaceBin;
	rc.bottom += ySpaceBin;
 }
 SelectObject(hDC,oldFnt);
}