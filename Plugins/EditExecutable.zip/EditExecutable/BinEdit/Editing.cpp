/*CreateCaret
  DestroyCaret
  GetCaretBlinkTime
  GetCaretPos
  HideCaret
  SetCaretBlinkTime
  SetCaretPos
  ShowCaret */
#include "BinEdit.h"

BOOL bEdit=FALSE;//bCaretShow;
BOOL FindCorrectCaretPos(int*,int*);
//UINT caretBlinkTime=0;
//DWORD showCaretTime=0;
//VOID WaitForBlinkCaret();

/*BOOL CreateMyCaret(HWND prnt)
{	BOOL r=CreateCaret(prnt,(HBITMAP)NULL,2,25);
	if(r)
		SetCaretPos(0,0);
	return r;
}
BOOL DestroyMyCaret()
{
	DestroyCaret();
	return TRUE;
}*/

BOOL OnEditingLBtnUpEvent(WPARAM wParam,LPARAM lParam)
{	int xPos = (int)(__int16)(LOWORD(lParam));
	int yPos = (int)(__int16)(HIWORD(lParam));

	if(xPos>rcBinLeft+rcBinWidth || xPos<rcBinLeft)
	{	if(bEdit)
		{	HideCaret(hWnd);
			bEdit = FALSE;
		}
		return FALSE;
	}

	FindCorrectCaretPos(&xPos,&yPos);
	if(bEdit)
	{	if(!(capturePosX==capturePosToX && capturePosY==capturePosToY))
		{	HideCaret(hWnd);
			bEdit = FALSE;
			return FALSE;
		}
		POINT pt;GetCaretPos(&pt);
		SetCaretPos(xPos,yPos);//DrawOldChar();
		RECT rCrtOld={pt.x,pt.y,pt.x+1,pt.y+ySpaceBin+4};
		//RedrawWindow(hWnd,&rCrtOld,NULL,RDW_INVALIDATE);
		HDC dc=GetDC(hWnd);
		FillRect(dc,&rCrtOld,binBackBrsh);
		ReleaseDC(hWnd,dc);
		//OutputDebugString(L"\nSetPosCaret");
		//ShowCaret(hWnd);
		return TRUE;
	}
	//else:
	SetCaretPos(xPos,yPos);
	ShowCaret(hWnd);
	//OutputDebugString(L"\nShow1");
	bEdit = TRUE;
	return TRUE;
}

/*VOID WaitForBlinkCaret()
{	DWORD t=GetTickCount();
	DWORD dt = t-showCaretTime;
	DWORD ddt=dt%caretBlinkTime;
	Sleep(caretBlinkTime);//-ddt);
}*/

BOOL FindCorrectCaretPos(int *xPos,int *yPos)
{
 int x = xSpaceBin>0?((*xPos - rcBinLeft)/xSpaceBin):0;
 int y = ySpaceBin>0?(*yPos/ySpaceBin):0;//rcBinHeight;
 x*=xSpaceBin;
 y*=ySpaceBin;
/* switch(binFmtDesc)
 {	case 2:
		for(int i=0; i<nViewColumns; i++)
		{	iBinTxtDists[8*i]=widthOfHexChar.cx;
			iBinTxtDists[8*i+1]=widthOfHexChar.cx;
			iBinTxtDists[8*i+2]=widthOfHexChar.cx;
			iBinTxtDists[8*i+3]=widthOfHexChar.cx;
			iBinTxtDists[8*i+4]=widthOfHexChar.cx;
			iBinTxtDists[8*i+5]=widthOfHexChar.cx;
			iBinTxtDists[8*i+6]=widthOfHexChar.cx;
			iBinTxtDists[8*i+7]=(xSpaceBin>7*widthOfHexChar.cx)?(xSpaceBin-7*widthOfHexChar.cx):1;
		}
		break;
 	case 8:
		for(int i=0; i<nViewColumns; i++)
		{	iBinTxtDists[3*i]=widthOfHexChar.cx;
			iBinTxtDists[3*i+1]=widthOfHexChar.cx;
			iBinTxtDists[3*i+2]=(xSpaceBin>2*widthOfHexChar.cx)?(xSpaceBin-2*widthOfHexChar.cx):1;
		}
		break;
	case 10:
		for(int i=0; i<nViewColumns; i++)
		{	iBinTxtDists[3*i]=widthOfHexChar.cx;
			iBinTxtDists[3*i+1]=widthOfHexChar.cx;
			iBinTxtDists[3*i+2]=(xSpaceBin>2*widthOfHexChar.cx)?(xSpaceBin-2*widthOfHexChar.cx):1;
		}
		break;
	case 16:
		for(int i=0; i<nViewColumns; i++)
		{	iBinTxtDists[2*i]=widthOfHexChar.cx;
			iBinTxtDists[2*i+1]=xSpaceBin>widthOfHexChar.cx?(xSpaceBin-widthOfHexChar.cx):1;
		}
		break;
 }*/
 x+=rcBinLeft;
 if(*xPos-x>widthOfHexChar.cx)
	 x+=widthOfHexChar.cx;
 *xPos=x;
 *yPos=y;
 return TRUE;
}

BOOL CaretToDownLine()
{	if(!bEdit)return TRUE;
	if(iAddressView>sz-nViewColumns*(nViewRows-1))return TRUE;
	POINT pt;GetCaretPos(&pt);pt.y+=ySpaceBin;
	SetCaretPos(pt.x,pt.y);
	RECT rCrtOld={pt.x,pt.y-ySpaceBin,pt.x+1,pt.y+4};
	HDC dc=GetDC(hWnd);
	FillRect(dc,&rCrtOld,binBackBrsh);
	ReleaseDC(hWnd,dc);
	if(pt.y>rcBinHeight)return TRUE;
	return FALSE;
}	

BOOL CaretToUpLine()
{	if(!bEdit)return TRUE;
	POINT pt;GetCaretPos(&pt);pt.y-=ySpaceBin;
	if(pt.y<0 && iAddressView<1)return TRUE;
	SetCaretPos(pt.x,pt.y);
	RECT rCrtOld={pt.x,pt.y+ySpaceBin,pt.x+1,pt.y+2*ySpaceBin+4};
	HDC dc=GetDC(hWnd);
	FillRect(dc,&rCrtOld,binBackBrsh);
	ReleaseDC(hWnd,dc);
	if(pt.y<0)return TRUE;
	return FALSE;
}

BOOL OnNumberPressed(int number)
{	POINT pt;GetCaretPos(&pt);
	int iColmn = xSpaceBin>0?((pt.x - rcBinLeft)/xSpaceBin):0;
	int iRow = ySpaceBin>0?(pt.y/ySpaceBin):0;
	int deltaX = (pt.x-rcBinLeft)%xSpaceBin;//toqmi,juft;
	unsigned __int64 iAddressInCaretPos = iAddressView + iRow * nViewColumns + iColmn;
	if(iAddressInCaretPos > sz-1)
		return FALSE;
	u8* p = (u8*)pFileBase + iAddressInCaretPos;
	if(deltaX)
	{	*p = ((*p) & 0xF0) | number;
	}else
	{	*p = ((*p) & 0x0F) | (number << 4);
	}
	//static int is=0;wchar_t s[260];wsprintf(s,L"\n%d %x",is++,c);
	//OutputDebugString(s);
	OnDraw(0);

	RECT rCrtOld={pt.x,pt.y,pt.x+1,pt.y+ySpaceBin+4};
	if(deltaX)
	{	if(iColmn<nViewColumns-1)
			SetCaretPos(pt.x-widthOfHexChar.cx+xSpaceBin,pt.y);
		else
			SetCaretPos(rcBinLeft,pt.y+ySpaceBin);
	}else SetCaretPos(pt.x+widthOfHexChar.cx,pt.y);
	HDC dc=GetDC(hWnd);
	FillRect(dc,&rCrtOld,binBackBrsh);
	ReleaseDC(hWnd,dc);
	return TRUE;
}