#include "windows.h"
#include "commctrl.h"

typedef unsigned char u8;
typedef unsigned __int64 u64;
typedef unsigned __int32 u32;
typedef __int32 s32;


extern HINSTANCE hInst;
extern HWND hWnd;
extern BOOL bLoaded;
extern int language;
extern wchar_t FilePathForSearch[MAX_PATH];

extern LPVOID pFileBase;
extern HANDLE hFile,hFileMap;
extern LPVOID pFileBase;
extern DWORD nFileSizeHigh,nFileSizeLow;
extern unsigned __int64 pageSz,sz,szToEndRow;

extern BOOL bMouseCapture;
extern __int16 capturePosX,capturePosY,capturePosToX,capturePosToY;

extern int nRows,nColumns,nViewRows,nViewColumns,
		   xSpaceAddr,xSpaceBin,ySpaceBin,xSpaceText,
		   nViewFromChar,
		   perCentOfAddr,perCentOfBin,perCentOfText;
extern COLORREF textColorText,backColorText;
extern BOOL addrFillZero;
extern UINT addrFmt,addrFmtDesc;



extern WCHAR rootPathForOutput[64];

extern BOOL OpenBinaryFile();
extern BOOL CloseFileMap();
extern VOID OnVScroll(WPARAM);
extern VOID PageDown();
extern VOID PageUp();
extern VOID LineUp(BOOL);
extern VOID LineDown(BOOL);
extern VOID End();
extern VOID Home();
extern INT_PTR CALLBACK WidthPercentDlgProc(HWND,UINT,WPARAM,LPARAM);
extern VOID FAR PASCAL InitLogFont(LOGFONT*);

extern VOID OnDraw(HDC);


//Config.cpp:
extern BOOL SaveConfig();
extern BOOL ReadConfig();


//DrawAddress.cpp:
extern int  addrMaxWidth8,addrMaxWidth10,addrMaxWidth16;
extern COLORREF textColorAddr,backColorAddr;
extern HFONT fntAddr;
extern LOGFONT addrLogFont;
extern HBRUSH adrrBackBrsh;
extern BOOL bAddrShowRowNum;
extern unsigned __int64 iAddressView;
extern VOID DrawAddress(HDC,RECT*);

//DrawBinary.cpp:
extern SIZE widthOfHexChar;
extern COLORREF textColorBin,backColorBin;
extern HFONT fntBin;
extern INT *iBinTxtDists;
extern int rcBinLeft,rcBinHeight,rcBinWidth;
extern LOGFONT binLogFont;
extern HBRUSH binBackBrsh;
extern UINT binFmt;
extern VOID DrawBin(HDC,RECT*);

//DrawText.cpp:
extern COLORREF textColorText,backColorText;
extern HFONT fntText;
extern LOGFONT textLogFont;
extern HBRUSH textBackBrsh;
extern UINT textFmt,textFmtDesc;
extern VOID DrawTexts(HDC,RECT*);
extern VOID DrawTexts16Even(HDC,RECT*);
extern VOID DrawTexts16Odd(HDC,RECT*);

//Selection.cpp
//typedef struct TSelection
//{	int nColumn;
//	int nRow;
//	unsigned __int64 iAddress;
//} Selection;
//extern Selection selctBgn,selct;
//extern BOOL bBgnSelSuccess;
//extern BOOL bTimerScrollSelection;
//extern BOOL BeginSelection();
//extern BOOL SelectedItemsChanged();
//extern VOID DrawSelectionBack(HDC);
//extern VOID EndSelection();
//extern BOOL OnScrollSelectionTimer();
//extern VOID CopyBinaryToClipboard();
//extern VOID CopyTextToClipboard();

//Editing.cpp:
extern BOOL OnEditingLBtnUpEvent(WPARAM,LPARAM);
extern BOOL CaretToDownLine();
extern BOOL CaretToUpLine();
extern VOID ToLeft();
extern VOID ToRight();
extern BOOL OnNumberPressed(int);
extern BOOL bEdit;

//Search.cpp:
extern INT_PTR CALLBACK SearchDlg(HWND,UINT,WPARAM,LPARAM);
extern BOOL SetSearchResult();
extern u8* MyStrCmpNNAPrgrs(u8*,u8*,int,int,HWND);
extern u8* MyStrCmpNNADirUpPrgrs(u8*,u8*,int,int,HWND);
extern char srchText[MAX_PATH];

//Insert-delete.cpp:
extern INT_PTR CALLBACK InsDelDlg(HWND,UINT,WPARAM,LPARAM);
extern BOOL InsertToFile(int,int,int);
extern BOOL DeleteFrFile(int,int,int);