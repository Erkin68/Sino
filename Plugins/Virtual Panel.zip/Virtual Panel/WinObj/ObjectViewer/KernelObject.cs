﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Microsoft.Win32.SafeHandles;

namespace ObjectViewer
{
    public class KernelObject
    {
        public static Dictionary<string, KernelObject> dict
            = new Dictionary<string, KernelObject>();
        public static KernelObject GetObject(string path)
        {
            KernelObject ret;
            dict.TryGetValue(path, out ret);
            return ret;
        }

        private static KernelObject root = new KernelObject("\\");
        public static KernelObject Root { get { return root; } }

        public KernelObject Parent { get; protected set; }
        public string Name { get; protected set; }
        public string Type { get; protected set; }
        public string Link { get; protected set; }
        public KernelObject[] Objects { get; protected set; }

        public bool IsDirectory { get { return Type == "Directory"; } }
        public bool IsSymbolicLink { get { return Type == "SymbolicLink"; } }

        public KernelObject(KernelObject parent, string name, string type)
        {
            Parent = parent;
            Name = name;
            Type = type;
            Link = GetLink();
            Objects = GetObjects();
            dict[FullName] = this;
        }

        private KernelObject(string dir)
            : this(null, dir, "Directory")
        {
        }

        private KernelObject(KernelObject parent, OBJECT_DIRECTORY_INFORMATION odi)
            : this(parent, odi.Name.ToString(), odi.TypeName.ToString())
        {
        }

        public string FullName
        {
            get
            {
                if (Parent == null)
                    return Name;
                else if (Parent.Parent == null)
                    return "\\" + Name;
                else
                    return Parent.FullName + "\\" + Name;
            }
        }

        private KernelObject[] GetObjects()
        {
            if (!IsDirectory) return null;

            var list = new List<KernelObject>();
            SafeFileHandle h;
            var attr = new OBJECT_ATTRIBUTES(FullName, 0);
            var st = NtOpenDirectoryObject(
                out h, ACCESS_MASK.DIRECTORY_QUERY, ref attr);
            if (st < 0) return null;

            var bufsz = 1024;
            var buf = Marshal.AllocHGlobal(bufsz);
            uint context = 0, len;
            for (; ; )
            {
                st = NtQueryDirectoryObject(h, buf, bufsz,
                    true, context == 0, ref context, out len);
                if (st < 0) break;

                var odi = (OBJECT_DIRECTORY_INFORMATION)
                    Marshal.PtrToStructure(buf, typeof(OBJECT_DIRECTORY_INFORMATION));
                list.Add(new KernelObject(this, odi));
            }
            Marshal.FreeHGlobal(buf);
            h.Dispose();

            var ret = list.ToArray();
            Array.Sort(ret, (a, b) => a.Name.CompareTo(b.Name));
            return ret;
        }

        private string GetLink()
        {
            if (!IsSymbolicLink) return null;

            SafeFileHandle h;
            var attr = new OBJECT_ATTRIBUTES(FullName, 0);
            var st = NtOpenSymbolicLinkObject(
                out h, ACCESS_MASK.GENERIC_READ, ref attr);
            if (st < 0) return null;

            int len;
            var buf = new UNICODE_STRING(new string(' ', 512));
            st = NtQuerySymbolicLinkObject(h, ref buf, out len);

            h.Dispose();
            if (st < 0) return null;
            return buf.ToString();
        }

        #region P/Invoke

        [StructLayout(LayoutKind.Sequential)]
        private struct UNICODE_STRING : IDisposable
        {
            public ushort Length;
            public ushort MaximumLength;
            private IntPtr buffer;

            public UNICODE_STRING(string s)
            {
                Length = (ushort)(s.Length * 2);
                MaximumLength = (ushort)(Length + 2);
                buffer = Marshal.StringToHGlobalUni(s);
            }

            public void Dispose()
            {
                Marshal.FreeHGlobal(buffer);
                buffer = IntPtr.Zero;
            }

            public override string ToString()
            {
                return Marshal.PtrToStringUni(buffer);
            }
        }

        [StructLayout(LayoutKind.Sequential)]
        private struct OBJECT_ATTRIBUTES : IDisposable
        {
            public int Length;
            public IntPtr RootDirectory;
            private IntPtr objectName;
            public uint Attributes;
            public IntPtr SecurityDescriptor;
            public IntPtr SecurityQualityOfService;

            public OBJECT_ATTRIBUTES(string name, uint attrs)
            {
                Length = Marshal.SizeOf(typeof(OBJECT_ATTRIBUTES));
                RootDirectory = IntPtr.Zero;
                objectName = IntPtr.Zero;
                Attributes = attrs;
                SecurityDescriptor = IntPtr.Zero;
                SecurityQualityOfService = IntPtr.Zero;

                ObjectName = new UNICODE_STRING(name);
            }

            public UNICODE_STRING ObjectName
            {
                get
                {
                    return (UNICODE_STRING)Marshal.PtrToStructure(
                        objectName, typeof(UNICODE_STRING));
                }

                set
                {
                    bool fDeleteOld = objectName != IntPtr.Zero;
                    if (!fDeleteOld)
                        objectName = Marshal.AllocHGlobal(Marshal.SizeOf(value));
                    Marshal.StructureToPtr(value, objectName, fDeleteOld);
                }
            }

            public void Dispose()
            {
                if (objectName != IntPtr.Zero)
                {
                    Marshal.DestroyStructure(objectName, typeof(UNICODE_STRING));
                    Marshal.FreeHGlobal(objectName);
                    objectName = IntPtr.Zero;
                }
            }
        }

        [StructLayout(LayoutKind.Sequential)]
        private struct OBJECT_DIRECTORY_INFORMATION
        {
            public UNICODE_STRING Name;
            public UNICODE_STRING TypeName;
        }

        private enum ACCESS_MASK : uint
        {
            DIRECTORY_QUERY = 1,
            DIRECTORY_TRAVERSE = 2,
            GENERIC_READ = 0x80000000,
        }

        [DllImport("ntdll.dll")]
        private static extern int NtOpenDirectoryObject(
            out SafeFileHandle DirectoryHandle,
            ACCESS_MASK DesiredAccess,
            ref OBJECT_ATTRIBUTES ObjectAttributes);

        [DllImport("ntdll.dll")]
        private static extern int NtQueryDirectoryObject(
            SafeFileHandle DirectoryHandle,
            IntPtr Buffer,
            int Length,
            bool ReturnSingleEntry,
            bool RestartScan,
            ref uint Context,
            out uint ReturnLength);

        [DllImport("ntdll.dll")]
        private static extern int NtOpenSymbolicLinkObject(
            out SafeFileHandle LinkHandle,
            ACCESS_MASK DesiredAccess,
            ref OBJECT_ATTRIBUTES ObjectAttributes);

        [DllImport("ntdll.dll")]
        private static extern int NtQuerySymbolicLinkObject(
            SafeFileHandle LinkHandle,
            ref UNICODE_STRING LinkTarget,
            out int ReturnedLength);

        #endregion
    }
}
