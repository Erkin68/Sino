﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ObjectViewer
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            var kroot = KernelObject.Root;
            var troot = CreateTreeNode(kroot);
            troot.Expand();
            treeView1.Nodes.Add(troot);
        }

        public TreeNode CreateTreeNode(KernelObject kobj)
        {
            if (!kobj.IsDirectory) return null;
            if (null==kobj.Objects) return null;

            var ret = new TreeNode(kobj.Name);
            foreach (var ko in kobj.Objects)
            {
                var n = CreateTreeNode(ko);
                if (n != null) ret.Nodes.Add(n);
            }
            ret.Tag = kobj;
            return ret;
        }

        public ListViewItem CreateListViewItem(KernelObject kobj)
        {
            var ret = new ListViewItem(new[] { kobj.Name, kobj.Type });
            if (kobj.IsSymbolicLink) ret.SubItems.Add(kobj.Link);
            ret.Tag = kobj;
            return ret;
        }

        private void treeView1_AfterSelect(object sender, TreeViewEventArgs e)
        {
            listView1.Items.Clear();

            var kobj = e.Node.Tag as KernelObject;
            if (kobj == null) return;

            foreach (var ko in kobj.Objects)
            {
                listView1.Items.Add(CreateListViewItem(ko));
            }
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
