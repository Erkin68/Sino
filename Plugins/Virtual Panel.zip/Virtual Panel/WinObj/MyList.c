#include "MyList.h"
#include <windows.h>
#include <stdio.h>
#include "Plugins_C.h"

list_entry *winx_list_insert(list_entry **phead,list_entry *prev,long size)
{
 list_entry *new_item;

 /*
 * Avoid winx_dbg_xxx calls here
 * to avoid recursion.
 */

 if(size < sizeof(list_entry))
 return NULL;

 new_item = (list_entry*)malloc(size);
 if(!new_item) return NULL;

 /* is list empty? */
 if(*phead == NULL){
 *phead = new_item;
 new_item->prev = new_item->next = new_item;
 return new_item;
 }

 /* insert as the new head? */
 if(prev == NULL){
 prev = (*phead)->prev;
 *phead = new_item;
 }

 /* insert after the item specified by prev argument */
 new_item->prev = prev;
 new_item->next = prev->next;
 new_item->prev->next = new_item;
 new_item->next->prev = new_item;
 return new_item;
}

void winx_list_remove(list_entry **phead,list_entry *item)
{
/*
* Avoid winx_dbg_xxx calls here
* to avoid recursion.
*/

/* validate the item */
if(item == NULL) return;

/* is list empty? */
if(*phead == NULL) return;

/* remove alone first item? */
if(item == *phead && item->next == *phead){
free(item);
*phead = NULL;
return;
}

 /* remove first item? */
 if(item == *phead){
 *phead = (*phead)->next;
 }
 item->prev->next = item->next;
 item->next->prev = item->prev;
 free(item);
}

void winx_list_destroy(list_entry **phead)
{
 list_entry *item, *next, *head;

 /* is list empty? */
 if(*phead == NULL) return;

 head = *phead;
 item = head;

 do {
 next = item->next;
 free(item);
 item = next;
 } while (next != head);

 *phead = NULL;
}

void my_winx_list_destroy(list_entry **phead)
{
 list_entry *item, *next, *head;
 my_list *myitem;

 /* is list empty? */
 if(*phead == NULL) return;

 head = *phead;
 item = head;

 do {
 next = item->next;
 if(next == head)
	 break;
 myitem = (my_list*)item;						//maniki;
 myFreeUnicodeString(&myitem->name);			//maniki;
 myFreeUnicodeString(&myitem->path);			//maniki;
 myFreeUnicodeString(&myitem->symbolicLinkName);//maniki;

 free(item);
 item = next;
 } while (next != head);

 *phead = NULL;
}

my_list *my_winx_list_get_entry(my_list **phead,int e)
{
int c=0;
my_list *item = *phead;
 if(item == NULL) return NULL;
 do {
 if(c++==e)return item;
 item = item->next;
 } while (item != *phead);
}
