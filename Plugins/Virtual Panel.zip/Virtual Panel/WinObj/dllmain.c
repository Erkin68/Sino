#define _CRT_SECURE_NO_WARNINGS

#include "windows.h"
//#include "resource.h"
#include "stdio.h"
#include "strsafe.h"
#include "Plugins_C.h"
#include "..\..\..\Operations\MyShell\MyShellC.h"



#define MAX_STRINGS 5

#pragma warning(disable:4995)

wchar_t **strngs=NULL;
HMODULE plgnDllInst;
BOOL bLoadNT;

LPVOID *plgList = NULL;
int		iPlgList = 0;

BOOL APIENTRY DllMain(HMODULE hModule,DWORD ul_reason_for_call,LPVOID lpReserved)
{
FILE *f;
int i,l;
wchar_t *pend;
wchar_t dllname[260],mnuStr[64];
	switch(ul_reason_for_call)
	{	case DLL_PROCESS_ATTACH:
			plgnDllInst=hModule;
			if(strngs)break;
			strngs = (wchar_t**)malloc(MAX_STRINGS*sizeof(wchar_t*));
			GetModuleFileNameW(hModule,dllname,260);
			bLoadNT = LoadNTFuncs();
			if(!bLoadNT)
				MessageBox(NULL,strngs[2],L"Error...",MB_OK);
			pend = wcsrchr(dllname,'\\');
			if(pend){*pend++='\\';*pend=0;}

			if(GetEnvironmentVariable(L"languge",mnuStr,64))//Language instartup qo'yadur;
			{	if(!wcscmp(mnuStr,L"russian"))
					wcscat(dllname,L"PlugWObjStrsRus.txt");
				else if(!wcscmp(mnuStr,L"uzbekl"))
					wcscat(dllname,L"PlugWObjStrsUZBL.txt");
				else if(!wcscmp(mnuStr,L"uzbekk"))
					wcscat(dllname,L"PlugWObjStrsUZBK.txt");
				else//if(wcscmp(mnuStr,L"Exit")
					wcscat(dllname,L"PlugWObjStrsEng.txt");
			}	
			else wcscat(dllname,L"PlugWObjStrsEng.txt");

			f=_wfopen(dllname,L"r,ccs=UNICODE");
			if(f)
			{	wchar_t s[260];fwscanf(f,L"%s", s);
				if(wcscmp(s,L"Plugin")) goto NillStr;
				fwscanf(f,L"%s", s);
				if(wcscmp(s,L"WinObj.dll")) goto NillStr;
				fwscanf(f,L"%s", s);
				if(wcscmp(s,L"Strings:")) goto NillStr;
				for(i=0; i<MAX_STRINGS; i++)
				{	int t;fwscanf_s(f,L"%d", &t);
					if(t-1!=i) goto NillStr;
					//l=fscanf(f,"%s", s);
					l=fscanLineString(f,256,s);
					strngs[i]=(wchar_t*)malloc(sizeof(wchar_t)*(l+1));
					memcpy(strngs[i],s,sizeof(wchar_t)*(l+1));
				}
				fclose(f);
			}
			else
			{int l;
NillStr:
				l=wcslen(L"Sino Win Object plugin,ver.1.0. fr.Erkin Sattorov.Karaulbazar-2013.")+1;
					strngs[0]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[0],l,L"Sino Win Object plugin,ver.1.0. fr.Erkin Sattorov.Karaulbazar-2013.");
				l=wcslen(L"WinObject")+1;
					strngs[1]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[1],l,L"WinObject");

				l=wcslen(L"Native NT functions are not loaded...")+1;//strngs[2] bo'sh
					strngs[2]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[2],l,L"Native NT functions are not loaded...");
				l=wcslen(L"Can't alloc memory for plugin object")+1;
					strngs[3]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[3],l,L"Can't alloc memory for plugin object");

				l=wcslen(L"File-defrag")+1;
					strngs[4]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[4],l,L"File-defrag");
			}
			break;
		case DLL_THREAD_ATTACH:
			break;
		case DLL_THREAD_DETACH:
			break;
		case DLL_PROCESS_DETACH:
			if(strngs)
			{	for(i=0; i<MAX_STRINGS; i++)
					free(strngs[i]);
				free(strngs);
				strngs = NULL;
			}
			//saveOptCpp();
			break;
	}
	return TRUE;
}