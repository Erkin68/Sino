#include "windows.h"
#include "strsafe.h"
#include "shlobj.h"
#include "Plugins_C.h"
#include "..\..\..\Operations\MyShell\MyShellC.h"



saveOptions_t saveOptions=0;
readOptions_t readOptions=0;
addItemToPanelList_t addItemToPanelList=0;
changeItemInPanelList_t changeItemInPanelList=0;
closeEvent_t closeEvent=0;
setPanelPath_t setPanelPath = 0;
//render_t render = 0;
//freePanel_t freePanel = 0;
//selectItem_t selectItem = 0;

int plgId = 0;
BOOL bStop=FALSE;


__declspec (dllexport) VOID SetCallbacks$4xxx(LPVOID frstCallback,...)
{
va_list args;
	va_start(args, frstCallback);//0
	saveOptions = (saveOptions_t)frstCallback;//1
	readOptions = (readOptions_t)va_arg(args, LPVOID);//2
	addItemToPanelList = (addItemToPanelList_t)va_arg(args, LPVOID);//3
	changeItemInPanelList = (changeItemInPanelList_t)va_arg(args, LPVOID);//4
	closeEvent = (closeEvent_t)va_arg(args, LPVOID);//5
	setPanelPath = (setPanelPath_t)va_arg(args, LPVOID);//6
	//render = (render_t)va_arg(args, int);//7
	//freePanel = (freePanel_t)va_arg(args, int);//8
	//selectItem = (selectItem_t)va_arg(args, int);//9	
va_end (args);
}

__declspec (dllexport) int GetPluginType()
{
	return 402;
}

__declspec (dllexport) const wchar_t* GetPluginName()
{
	return strngs[1];
}

__declspec (dllexport) VOID SetId$4(int id)
{
	plgId = id;
}

__declspec (dllexport) const wchar_t* GetPluginDescription()
{
	return strngs[0];
}

__declspec (dllexport) VOID ShowOptionDialog(HWND prnt)
{
}

__declspec (dllexport) LPVOID AttachPanel$12(HWND prnt,LPVOID host,wchar_t *path)
{
	PluginObj *plg=malloc(sizeof(PluginObj),0);
	if(!plg)
	{	MessageBox(prnt,strngs[3],path,MB_OK);
		return NULL;
	}
	plg->host = host;
	plg->list = NULL;
	plg->pathLn=MyStringCpy(plg->path,MAX_PATH-1,path);

	if(!plgList)
	{	plgList = malloc(sizeof(LPVOID));
		plgList[0] = plg;
		iPlgList = 1;
	}
	else
	{	plgList = realloc(plgList,(iPlgList+1) * sizeof(LPVOID));
		plgList[iPlgList++] = plg;
	}
	return plg;
}

__declspec (dllexport) BOOL EnumDir$12(HWND prnt,LPVOID plgObj,wchar_t *path)
{
BOOL r = EnumObjDir((PluginObj*)plgObj,path[0]?path:L"\\");
	//render(((PluginObj*)plgObj)->host);
	return r;
}

__declspec (dllexport) BOOL GetReadyForEnumDir$12(HWND prnt,LPVOID plgObj,wchar_t *path)
{
	if(0==wcscmp(path,L"\\Device"))
	{	if(IDYES!=MessageBox(prnt,L"Any antivirus program may collapse this directory.\nPlease,first disable antivirus...",L"Are you want to enter this directory?",MB_YESNO))
			return FALSE;
	}
	return GetReadyForEnumObjDir((PluginObj*)plgObj,path[0]?path:L"\\");
}

__declspec (dllexport) VOID DetachPanel$8(LPVOID plgObj,LPVOID host)
{
int n;BOOL bFind=FALSE;
	if(iPlgList>0)
	{	for(n=0; n<iPlgList; ++n)
		{	if(plgList[n]==plgObj)
			{	bFind = TRUE;
				break;
		}	}
		if(!bFind)
		{	
		G:	MessageBox(NULL,L"Attach/Detach panel count mismatching.",L"Err...",MB_OK);
			return;
		}
		my_winx_list_destroy(&((PluginObj*)plgObj)->list);
		free(plgObj);
		if(0==(--iPlgList))
		{	//SaveOptions();
			free(plgList);
			plgList = NULL;
			iPlgList = 0;
	}	}
	else goto G;
}
__declspec (dllexport) BOOL GetItemPathAndName$16(LPVOID plgObj,wchar_t *buf,int bufln,DWORD itemId)
{
int l;//wchar_t *p;
	if(((PluginObj*)plgObj)->listcnt > 0 && itemId != 0 && itemId != 0xffffffff)
	{	my_list *lst = (my_list*)itemId;//my_list *lst = my_winx_list_get_entry(((PluginObj*)plgObj)->list,itemId);
		if(!lst)return FALSE;
		StringCchPrintf(buf,bufln,L"%s",&lst->path.Buffer[0]);
	}
	else
	{	if(((PluginObj*)plgObj)->enumPath[0]==0)
			StringCchPrintf(buf,bufln,L"%s%c",((PluginObj*)plgObj)->enumPath,'\\');
		else
		{	l=MyStringCpy(buf,bufln,((PluginObj*)plgObj)->enumPath);
			if('\\'!=buf[l-1])
			{	buf[l++]='\\';
				buf[l]=0;
			}
			//p = wcsrchr(buf,'\\');
			//if(p) *p= 0;
	}	}
	return TRUE;
}

__declspec (dllexport) BOOL GetStrForTooltip$20(LPVOID plgObj,wchar_t *buf,int bufln,DWORD itemId,int *ln)
{
	if(((PluginObj*)plgObj)->listcnt > 0)
	{	my_list *lst = (my_list*)itemId;//my_list *lst = my_winx_list_get_entry(((PluginObj*)plgObj)->list,itemId);
		if(!lst)return FALSE;
		if(lst->symbolicLinkName.Buffer[0])
		{	StringCchPrintf(buf,
							bufln,
							L"%s %c%cSymbolicLink: %c%c%s",
							&lst->path.Buffer[0],
							0x0d,0x0a,
							0x0d,0x0a,
							&lst->symbolicLinkName.Buffer[0]);
		}
		else
		{	StringCchPrintf(buf,bufln,L"%s",&lst->path.Buffer[0]);
		}
	}
	return TRUE;
}

__declspec (dllexport) BOOL OnPanelResizing$8(HWND prnt,LPVOID plgObj)
{
	return TRUE;
}