#include "ntndk.h"
#include "strsafe.h"
#include "Plugins_C.h"

typedef struct TOBJECT_DIRECTORY_INFORMATION
{
	UNICODE_STRING Name;
    UNICODE_STRING TypeName;
} OBJECT_DIRECTORY_INFORMATION;

#define true  1
#define false 0

typedef NTSTATUS (WINAPI *pRtlInitUnicodeString_t)(PUNICODE_STRING, PCWSTR);
typedef NTSTATUS (WINAPI *pNtCreateFile_t)(PHANDLE, ACCESS_MASK, POBJECT_ATTRIBUTES, PIO_STATUS_BLOCK, PLARGE_INTEGER, ULONG, ULONG, ULONG, ULONG, PVOID, ULONG);
typedef NTSTATUS (WINAPI *pNtCreateEvent_t)(PHANDLE, ACCESS_MASK, POBJECT_ATTRIBUTES, EVENT_TYPE, BOOLEAN);
typedef NTSTATUS (WINAPI *pNtQueryDirectoryFile_t)(HANDLE, HANDLE, PIO_APC_ROUTINE, PVOID, PIO_STATUS_BLOCK, PVOID, ULONG, FILE_INFORMATION_CLASS, BOOLEAN, PUNICODE_STRING, BOOLEAN);
typedef NTSTATUS (WINAPI *pNtWaitForSingleobject_t)(HANDLE, BOOLEAN, PLARGE_INTEGER);
typedef NTSTATUS (WINAPI *pRtlUnicodeStringToAnsiString_t)(PANSI_STRING, PCUNICODE_STRING, BOOLEAN);
typedef NTSTATUS (WINAPI *pRtlAnsiStringToUnicodeString_t)(PCUNICODE_STRING, PANSI_STRING, BOOLEAN);
typedef NTSTATUS (WINAPI *pRtlInitAnsiString_t)(PANSI_STRING, PCSZ);
typedef NTSTATUS (WINAPI *pNtClose_t)(HANDLE);
typedef NTSTATUS (WINAPI *pRtlFreeAnsiString_t)(PANSI_STRING);
typedef NTSTATUS (WINAPI *pRtlFreeUnicodeString_t)(PUNICODE_STRING);
typedef NTSTATUS (WINAPI* pInitializeObjectAttributes_t)(POBJECT_ATTRIBUTES,PUNICODE_STRING,ULONG,HANDLE,PSECURITY_DESCRIPTOR);

//registry:
typedef NTSTATUS (WINAPI *pNtCreateKey_t)(PHANDLE,ACCESS_MASK,POBJECT_ATTRIBUTES,ULONG,PUNICODE_STRING,ULONG,PULONG);
typedef NTSTATUS (WINAPI *pNtDeleteKey_t)(HANDLE);
typedef NTSTATUS (WINAPI *pNtEnumerateKey_t)(HANDLE,ULONG,KEY_INFORMATION_CLASS,PVOID,ULONG,PULONG);
typedef NTSTATUS (WINAPI *pNtEnumerateValueKey_t)(HANDLE,ULONG,KEY_VALUE_INFORMATION_CLASS,PVOID,ULONG,PULONG);
typedef NTSTATUS (WINAPI *pNtFlushKey_t)(HANDLE);
typedef NTSTATUS (WINAPI* pNtOpenKey_t)(PHANDLE,ACCESS_MASK,POBJECT_ATTRIBUTES);
typedef NTSTATUS (WINAPI *pNtSetValueKey_t)(HANDLE,PUNICODE_STRING,ULONG,ULONG,PVOID,ULONG);

typedef NTSTATUS (WINAPI *pNtOpenGeneric_t)(PHANDLE,ACCESS_MASK,const OBJECT_ATTRIBUTES*);
typedef NTSTATUS (WINAPI *pNtOpenFile_t)(OUT PHANDLE,IN ACCESS_MASK,IN POBJECT_ATTRIBUTES,OUT PIO_STATUS_BLOCK,IN ULONG,IN ULONG);
typedef NTSTATUS (WINAPI *pNtOpenEvent_t)(PHANDLE,ACCESS_MASK,const OBJECT_ATTRIBUTES*);
typedef NTSTATUS (WINAPI *pNtOpenJobObject_t)(PHANDLE,ACCESS_MASK,const OBJECT_ATTRIBUTES*); 
typedef NTSTATUS (WINAPI *pNtOpenMutant_t)(PHANDLE,ACCESS_MASK,const OBJECT_ATTRIBUTES*); 
typedef NTSTATUS (WINAPI *pNtOpenTimer_t)(HANDLE*, ACCESS_MASK, const OBJECT_ATTRIBUTES*); 
typedef NTSTATUS (WINAPI *pNtOpenSection_t)(HANDLE*,ACCESS_MASK,const OBJECT_ATTRIBUTES*);
typedef NTSTATUS (WINAPI *pNtOpenSemaphore_t)(PHANDLE,ACCESS_MASK,const OBJECT_ATTRIBUTES*); 
typedef NTSTATUS (WINAPI *pNtOpenSymbolicLinkObject_t)(PHANDLE,ACCESS_MASK,POBJECT_ATTRIBUTES); 
typedef NTSTATUS (WINAPI *pNtOpenKeyedEvent_t)(PHANDLE,ACCESS_MASK,POBJECT_ATTRIBUTES); 
typedef NTSTATUS (WINAPI *pNtOpenDirectoryObject_t)(OUT PHANDLE,IN ACCESS_MASK,IN POBJECT_ATTRIBUTES);

typedef NTSTATUS (WINAPI *pNtQueryKey_t)(HANDLE,KEY_INFORMATION_CLASS,PVOID,ULONG,PULONG);
typedef NTSTATUS (WINAPI *pNtQueryValueKey_t)(HANDLE,PUNICODE_STRING,KEY_VALUE_INFORMATION_CLASS,PVOID,ULONG,PULONG);
typedef NTSTATUS (WINAPI *pNtQueryDirectoryObject_t)(IN HANDLE,OUT PVOID,IN ULONG,IN BOOLEAN,IN BOOLEAN,IN OUT PULONG,OUT PULONG);
typedef NTSTATUS (WINAPI *pRtlQueryRegistryValues_t)(ULONG,PCWSTR,PRTL_QUERY_REGISTRY_TABLE,PVOID,PVOID);
typedef NTSTATUS (WINAPI *pNtQuerySymbolicLinkObject_t)(IN HANDLE, IN OUT PUNICODE_STRING, OUT PULONG);


extern pRtlInitUnicodeString_t pRtlInitUnicodeString;
extern pNtCreateFile_t pNtCreateFile;
extern pNtCreateEvent_t pNtCreateEvent;
extern pNtQueryDirectoryFile_t pNtQueryDirectoryFile;
extern pNtWaitForSingleobject_t pNtWaitForSingleobject;
extern pRtlUnicodeStringToAnsiString_t pRtlUnicodeStringToAnsiString; 
extern pRtlAnsiStringToUnicodeString_t pRtlAnsiStringToUnicodeString;
extern pRtlInitAnsiString_t pRtlInitAnsiString;
extern pNtClose_t pNtClose;
extern pRtlFreeAnsiString_t pRtlFreeAnsiString;
extern pRtlFreeUnicodeString_t pRtlFreeUnicodeString;
extern pInitializeObjectAttributes_t pInitializeObjectAttributes;

extern pNtCreateKey_t pNtCreateKey;
extern pNtDeleteKey_t pNtDeleteKey;
extern pNtEnumerateKey_t pNtEnumerateKey;
extern pNtEnumerateValueKey_t pNtEnumerateValueKey;
extern pNtFlushKey_t pNtFlushKey;
extern pNtOpenKey_t pNtOpenKey;
extern pNtSetValueKey_t pNtSetValueKey;

extern pNtOpenGeneric_t pNtOpenGeneric;
extern pNtOpenFile_t pNtOpenFile;
extern pNtOpenEvent_t pNtOpenEvent;
extern pNtOpenJobObject_t pNtOpenJobObject;
extern pNtOpenMutant_t pNtOpenMutant;
extern pNtOpenTimer_t pNtOpenTimer;
extern pNtOpenSection_t pNtOpenSection;
extern pNtOpenSemaphore_t pNtOpenSemaphore;
extern pNtOpenSymbolicLinkObject_t pNtOpenSymbolicLinkObject;
extern pNtOpenKeyedEvent_t pNtOpenKeyedEvent;
extern pNtOpenDirectoryObject_t pNtOpenDirectoryObject;

extern pNtQueryKey_t pNtQueryKey;
extern pNtQueryValueKey_t pNtQueryValueKey;
extern pNtQueryDirectoryObject_t pNtQueryDirectoryObject;
extern pRtlQueryRegistryValues_t pRtlQueryRegistryValues;
extern pNtQuerySymbolicLinkObject_t pNtQuerySymbolicLinkObject;

extern ULONG GetObjectAccessFlag(OBJECT_DIRECTORY_INFORMATION*);
extern ULONG GetSymbolicLink(OBJECT_DIRECTORY_INFORMATION*,PUCHAR*,PUCHAR*);