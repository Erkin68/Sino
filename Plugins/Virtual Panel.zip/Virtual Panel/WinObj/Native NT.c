#pragma warning(disable:4013)
#pragma warning(disable:4024)
#pragma warning(disable:4047)
#pragma warning(disable:4244)
#pragma warning(disable:4995)
#pragma warning(disable:4996)

#include "Native NT.h"
#include "MyList.h"


pRtlInitUnicodeString_t pRtlInitUnicodeString;
pNtCreateFile_t pNtCreateFile;
pNtCreateEvent_t pNtCreateEvent;
pNtQueryDirectoryFile_t pNtQueryDirectoryFile;
pNtWaitForSingleobject_t pNtWaitForSingleobject;
pRtlUnicodeStringToAnsiString_t pRtlUnicodeStringToAnsiString; 
pRtlAnsiStringToUnicodeString_t pRtlAnsiStringToUnicodeString;
pRtlInitAnsiString_t pRtlInitAnsiString;
pNtClose_t pNtClose;
pRtlFreeAnsiString_t pRtlFreeAnsiString;
pRtlFreeUnicodeString_t pRtlFreeUnicodeString;
pInitializeObjectAttributes_t pInitializeObjectAttributes;

pNtCreateKey_t pNtCreateKey;
pNtDeleteKey_t pNtDeleteKey;
pNtEnumerateKey_t pNtEnumerateKey;
pNtEnumerateValueKey_t pNtEnumerateValueKey;
pNtFlushKey_t pNtFlushKey;
pNtOpenKey_t pNtOpenKey;
pNtSetValueKey_t pNtSetValueKey;

pNtOpenGeneric_t pNtOpenGeneric;
pNtOpenFile_t pNtOpenFile;
pNtOpenEvent_t pNtOpenEvent;
pNtOpenJobObject_t pNtOpenJobObject;
pNtOpenMutant_t pNtOpenMutant;
pNtOpenTimer_t pNtOpenTimer;
pNtOpenSection_t pNtOpenSection;
pNtOpenSemaphore_t pNtOpenSemaphore;
pNtOpenSymbolicLinkObject_t pNtOpenSymbolicLinkObject;
pNtOpenKeyedEvent_t pNtOpenKeyedEvent;
pNtOpenDirectoryObject_t pNtOpenDirectoryObject;

pNtQueryKey_t pNtQueryKey;
pNtQueryValueKey_t pNtQueryValueKey;
pNtQueryDirectoryObject_t pNtQueryDirectoryObject;
pRtlQueryRegistryValues_t pRtlQueryRegistryValues;
pNtQuerySymbolicLinkObject_t pNtQuerySymbolicLinkObject;



BOOL LoadNTFuncs()
{
    HMODULE hModule = LoadLibraryW(L"Ntdll.dll");
	//if(hModule)MessageBox(NULL,L"LoadLibraryW",L"for Ntdll.dll sucsess",MB_OK);
    pRtlInitUnicodeString = (pRtlInitUnicodeString_t)GetProcAddress (hModule, "RtlInitUnicodeString");
    pNtCreateFile = (pNtCreateFile_t)GetProcAddress(hModule,"NtCreateFile");
    //pNtCreateEvent = (pNtCreateEvent_t)GetProcAddress (hModule, "NtCreateEvent");
    pNtQueryDirectoryFile = (pNtQueryDirectoryFile_t)GetProcAddress(hModule,"NtQueryDirectoryFile");
    pNtWaitForSingleobject = (pNtWaitForSingleobject_t)GetProcAddress(hModule,"NtWaitForSingleObject");
    pRtlUnicodeStringToAnsiString = (pRtlUnicodeStringToAnsiString_t)GetProcAddress(hModule,"RtlUnicodeStringToAnsiString");
    pRtlAnsiStringToUnicodeString = (pRtlAnsiStringToUnicodeString_t)GetProcAddress(hModule,"RtlAnsiStringToUnicodeString");
	pRtlInitAnsiString = (pRtlInitAnsiString_t)GetProcAddress(hModule,"RtlInitAnsiString");
    pNtClose = (pNtClose_t)GetProcAddress(hModule,"NtClose");
	pRtlFreeAnsiString = (pRtlFreeAnsiString_t)GetProcAddress(hModule,"RtlFreeAnsiString");
	pRtlFreeUnicodeString = (pRtlFreeUnicodeString_t)GetProcAddress(hModule,"RtlFreeUnicodeString");
	//pInitializeObjectAttributes = (pInitializeObjectAttributes_t) GetProcAddress (hModule, "InitializeObjectAttributes");

	pNtCreateKey = (pNtCreateKey_t)GetProcAddress(hModule,"NtCreateKey");
	//pNtDeleteKey = (pNtDeleteKey_t)GetProcAddress(hModule,"NtDeleteKey");
	pNtEnumerateKey = (pNtEnumerateKey_t)GetProcAddress(hModule,"NtEnumerateKey");
	pNtEnumerateValueKey = (pNtEnumerateValueKey_t)GetProcAddress(hModule,"NtEnumerateValueKey");
	//pNtFlushKey = (pNtFlushKey_t)GetProcAddress(hModule,"NtFlushKey"); yozish uchun 
	//pNtOpenKey = (pNtOpenKey_t)GetProcAddress(hModule,"NtOpenKey");
	//pNtSetValueKey = (pNtSetValueKey_t)GetProcAddres(hModule,"NtSetValueKey"); yozish uchun

	pNtOpenFile = (pNtOpenFile_t)GetProcAddress(hModule,"NtOpenFile");
	pNtOpenDirectoryObject = (pNtOpenDirectoryObject_t)GetProcAddress(hModule,"NtOpenDirectoryObject");

	pRtlQueryRegistryValues = (pRtlQueryRegistryValues_t)GetProcAddress(hModule,"RtlQueryRegistryValues");
	pNtQueryDirectoryObject = (pNtQueryDirectoryObject_t)GetProcAddress(hModule,"NtQueryDirectoryObject");
	pNtQueryKey = (pNtQueryKey_t)GetProcAddress(hModule,"NtQueryKey");
	pNtQueryValueKey = (pNtQueryValueKey_t)GetProcAddress(hModule,"NtQueryValueKey");
	pNtQuerySymbolicLinkObject = (pNtQuerySymbolicLinkObject_t)GetProcAddress(hModule,"NtQuerySymbolicLinkObject");

	pNtOpenEvent = (pNtOpenEvent_t)GetProcAddress(hModule,"NtOpenEvent");
	pNtOpenJobObject = (pNtOpenJobObject_t)GetProcAddress(hModule,"NtOpenJobObject"); 
	pNtOpenMutant = (pNtOpenMutant_t)GetProcAddress(hModule,"NtOpenMutant"); 
	pNtOpenTimer = (pNtOpenTimer_t)GetProcAddress(hModule,"NtOpenTimer");
	pNtOpenSection = (pNtOpenSection_t)GetProcAddress(hModule,"NtOpenSection");
	pNtOpenSemaphore = (pNtOpenSemaphore_t)GetProcAddress(hModule,"NtOpenSemaphore");
	pNtOpenSymbolicLinkObject = (pNtOpenSymbolicLinkObject_t)GetProcAddress(hModule,"NtOpenSymbolicLinkObject");
	pNtOpenKeyedEvent = (pNtOpenKeyedEvent_t)GetProcAddress(hModule,"NtOpenKeyedEvent");

	if( (!pRtlInitUnicodeString) || (!pNtCreateFile) || /*(!pNtCreateEvent) ||*/ (!pNtQueryDirectoryFile) ||
		(!pNtWaitForSingleobject) || (!pRtlUnicodeStringToAnsiString) || (!pNtClose) || (!pRtlFreeAnsiString) || (!pRtlFreeUnicodeString) ||// || (!pInitializeObjectAttributes))
		(!pNtCreateKey) || /*(!pNtDeleteKey)*/ (!pNtEnumerateKey) || (!pNtEnumerateValueKey) ||
		/*(!pNtFlushKey) ||  (!pNtOpenKey) ||*/ (!pNtQueryKey) || (!pNtQueryValueKey) || (!pRtlQueryRegistryValues) ||// || (!pNtSetValueKey))
		(!pNtQueryDirectoryObject) || (!pNtQuerySymbolicLinkObject) ||
		(!pNtOpenFile) || (!pNtOpenDirectoryObject) || (!pNtOpenEvent) ||
		(!pNtOpenJobObject) || (!pNtOpenMutant) || (!pNtOpenTimer) || (!pNtOpenSection) || (!pNtOpenSemaphore) ||
		(!pNtOpenSymbolicLinkObject) || (!pNtOpenKeyedEvent))
	{	pRtlInitUnicodeString = NULL;
		pNtCreateFile = NULL;
		//pNtCreateEvent = NULL;
		pNtQueryDirectoryFile = NULL;
		pNtWaitForSingleobject = NULL;
		pRtlUnicodeStringToAnsiString = NULL;
		pRtlAnsiStringToUnicodeString = NULL;
		pRtlInitAnsiString = NULL;
		pNtClose = NULL;
		pRtlFreeAnsiString = NULL;
		pRtlFreeUnicodeString = NULL;
		//pInitializeObjectAttributes = NULL;

		pNtCreateKey = NULL;
		pNtDeleteKey = NULL;
		pNtEnumerateKey = NULL;
		pNtEnumerateValueKey = NULL;
		//pNtFlushKey = NULL;
		//pNtOpenKey = NULL;
		//pNtSetValueKey = NULL;

		pRtlQueryRegistryValues = NULL;
		pNtQueryDirectoryObject = NULL;
		pNtQueryKey = NULL;
		pNtQueryValueKey = NULL;
		pNtQuerySymbolicLinkObject = NULL;

		pNtOpenFile = NULL;
		pNtOpenDirectoryObject = NULL;
		pNtOpenFile = NULL;
		pNtOpenEvent = NULL;
		pNtOpenJobObject = NULL;
		pNtOpenMutant = NULL;
		pNtOpenTimer = NULL;
		pNtOpenSection = NULL;
		pNtOpenSemaphore = NULL;
		pNtOpenSymbolicLinkObject = NULL;
		pNtOpenKeyedEvent = NULL;
		return FALSE;
	}
	//MessageBox(NULL,L"LoadLibraryW",L"for Ntdll.dll sucsess",MB_OK);
    return TRUE;
}

VOID myInitUnicodeString(PUNICODE_STRING us,wchar_t*s)
{
void *buf;
	int l=lstrlen(s);
	buf = malloc(2*(l+1));
	memcpy(buf,s,2*(l+1));
	pRtlInitUnicodeString(us,buf);
}

VOID myFreeUnicodeString(PUNICODE_STRING us)
{
void *buf = &us->Buffer[0];
	//pRtlFreeUnicodeString(us);
	free(us->Buffer);
}

#define smallBufferSize 512
BOOL EnumObjDir(PluginObj *plg,wchar_t *pth)
{
UNICODE_STRING RootDirectoryName;
OBJECT_ATTRIBUTES RootDirectoryAttributes;
OBJECT_DIRECTORY_INFORMATION *ob; 
HANDLE hDir;
ULONG  Result,dwIndex=0,oldIndex=2,cbBytesReturned;
WIN32_FIND_DATAW ff;
my_list *lst=NULL;
wchar_t Buffer[2*MAX_PATH];
wchar_t symbolicLinkName[smallBufferSize];
wchar_t name[smallBufferSize];
wchar_t path[smallBufferSize];


	plg->enumPathLn = MyStringCpy(plg->enumPath,2*MAX_PATH,pth);
	pRtlInitUnicodeString(&RootDirectoryName,(STRSAFE_LPWSTR)&plg->enumPath[0]);

	InitializeObjectAttributes(&RootDirectoryAttributes,&RootDirectoryName,
							   OBJ_CASE_INSENSITIVE|OBJ_KERNEL_HANDLE|OBJ_OPENIF,0,0);

    Result = pNtOpenDirectoryObject(&hDir,DIRECTORY_QUERY,&RootDirectoryAttributes);
    if(Result < 0)//!= STATUS_SUCCESS)
    { //doserr = RtlNtStatusToDosError(Result);
      goto End;
    }
	

	if(plg->list)
	{	my_winx_list_destroy(plg->list);
		plg->list = NULL;
	}
	plg->listcnt = 0;

	for(;;)
	{ 	oldIndex = dwIndex;
		Result = pNtQueryDirectoryObject(hDir,Buffer,2*MAX_PATH,true,false,&dwIndex,&cbBytesReturned);
		if(Result != 0)
		{	if(oldIndex == dwIndex || Result == 0x8000001a)//STATUS_NO_MORE_FILES)
			{	Result = STATUS_SUCCESS;
				break;
			}
			//write some
			goto End;
		}
		//wprintf(L"\n %33s %12s",&ob->Name.Buffer[0],&ob->TypeName.Buffer[0]);
		//if(objAccesFlag!=0) wprintf(L"%12s",GENERIC_ALL==objAccesFlag?L"GENERIC_ALL":
		//								   (GENERIC_WRITE==objAccesFlag?L"GENERIC_WRITE":L"GENERIC_READ"));
		//StringCchCat((LPWSTR)&path[0],smallBufferSize,L"\\");
		lst = (my_list*)winx_list_insert((list_entry**)&plg->list,
										 (list_entry*)lst,sizeof(my_list));
		if(!lst)
			goto End;
		ob = (OBJECT_DIRECTORY_INFORMATION*)&Buffer[0];
		lst->objAccesFlag = GetObjectAccessFlag(ob);

		StringCchPrintfW(name,smallBufferSize,(LPWSTR)&ob->Name.Buffer[0]);
		if(*pth=='\\' && *(pth+1)==0)
		{	StringCchPrintfW(path,smallBufferSize,L"%s%s",pth,(LPWSTR)&ob->Name.Buffer[0]);
		}
		else
		{	StringCchPrintfW(path,smallBufferSize,L"%s%c%s",pth,L'\\',(LPWSTR)&ob->Name.Buffer[0]);
		}
		Result = GetSymbolicLink(ob,&path[0],&symbolicLinkName[0]);
		if(1!=Result)
			symbolicLinkName[0]=0;
		myInitUnicodeString(&lst->name,name);
		myInitUnicodeString(&lst->path,path);
		myInitUnicodeString(&lst->symbolicLinkName,symbolicLinkName);

		lst->attribute = ff.dwFileAttributes = 
					(0==wcscmp(&ob->TypeName.Buffer[0],L"Directory") ? FILE_ATTRIBUTE_DIRECTORY : 0);		
		//addItemToPanelList(plg->host,'\\'==path[0]?&path[1]:path,&ff,lst,FALSE);
		addItemToPanelList(plg->host,name,NULL,&ff,lst,FALSE);

		//pRtlFreeUnicodeString(&lst->name);
		//pRtlFreeUnicodeString(&lst->path);
		//pRtlFreeUnicodeString(&lst->symbolicLinkName);

		//oldIndex = dwIndex;
	}
End:
	plg->listcnt = dwIndex;
	Result = !CloseHandle(hDir);
	//pRtlFreeUnicodeString(&RootDirectoryName);
	return Result==0?TRUE:FALSE;
}

BOOL GetReadyForEnumObjDir(PluginObj *plg,wchar_t *pth)
{
UNICODE_STRING RootDirectoryName;
OBJECT_ATTRIBUTES RootDirectoryAttributes;
HANDLE hDir;
ULONG  Result,dwIndex,cbBytesReturned;
wchar_t Buffer[2*MAX_PATH];

	pRtlInitUnicodeString(&RootDirectoryName,(STRSAFE_LPWSTR)pth);

	InitializeObjectAttributes(&RootDirectoryAttributes,&RootDirectoryName,
							   OBJ_CASE_INSENSITIVE|OBJ_KERNEL_HANDLE|OBJ_OPENIF,0,0);

    Result = pNtOpenDirectoryObject(&hDir,DIRECTORY_QUERY,&RootDirectoryAttributes);

    if(Result < 0)
      goto End;

	Result = pNtQueryDirectoryObject(hDir,Buffer,2*MAX_PATH,true,false,&dwIndex,&cbBytesReturned);

	//wsprintf(Buffer,L"%d",(int)Result);
	//MessageBox(NULL,L"pNtQueryDirectoryObject",Buffer,MB_OK);

	if(Result != 0)
	{	if(Result == 0x8000001a)
			Result = STATUS_SUCCESS;
	}
End:
	//pRtlFreeUnicodeString(&RootDirectoryName);
	Result = !CloseHandle(hDir);

	return Result==0?TRUE:FALSE;
}
#undef smallBufferSize

ULONG GetObjectAccessFlag(OBJECT_DIRECTORY_INFORMATION *ob)
{
HANDLE handle;
UNICODE_STRING unicode_str;
OBJECT_ATTRIBUTES path_attributes;
NTSTATUS status_code = 0;
	pNtOpenGeneric = NULL;
	//if(!wcscmp(&ob->TypeName.Buffer[0], L"Directory")) return 0;
	//else if(!wcscmp(&ob->TypeName.Buffer[0], L"Device")) return 0;
	if(!wcscmp(&ob->TypeName.Buffer[0], L"Event"))				pNtOpenGeneric = pNtOpenEvent;
	else if(!wcscmp(&ob->TypeName.Buffer[0], L"Job"))			pNtOpenGeneric = pNtOpenJobObject;
	else if(!wcscmp(&ob->TypeName.Buffer[0], L"KeyedEvent"))	pNtOpenGeneric = (pNtOpenGeneric_t)pNtOpenKeyedEvent;
	else if(!wcscmp(&ob->TypeName.Buffer[0], L"Mutant"))		pNtOpenGeneric = pNtOpenMutant;
	else if(!wcscmp(&ob->TypeName.Buffer[0], L"Section"))		pNtOpenGeneric = pNtOpenSection;
	else if(!wcscmp(&ob->TypeName.Buffer[0], L"Semaphore"))		pNtOpenGeneric = pNtOpenSemaphore;
	else if(!wcscmp(&ob->TypeName.Buffer[0], L"Timer"))			pNtOpenGeneric = pNtOpenTimer;
	else if(!wcscmp(&ob->TypeName.Buffer[0], L"SymbolicLink"))	pNtOpenGeneric = (pNtOpenGeneric_t)pNtOpenSymbolicLinkObject;

	if(!pNtOpenGeneric) return 0;

	unicode_str.Length = (USHORT)ob->Name.Length;
	unicode_str.MaximumLength = (USHORT)ob->Name.MaximumLength;
	unicode_str.Buffer = ob->Name.Buffer;

	InitializeObjectAttributes(&path_attributes,&unicode_str,0,NULL,NULL);

	status_code = pNtOpenGeneric(&handle, GENERIC_ALL, &path_attributes);
	if(STATUS_SUCCESS == status_code)
	{	pNtClose(handle);
		return GENERIC_ALL;
	}
	
	//else if(status_code != EXCEPTION_ACCESS_VIOLATION && status_code != STATUS_ACCESS_DENIED)
	status_code = pNtOpenGeneric(&handle, GENERIC_WRITE, &path_attributes);
	if(STATUS_SUCCESS == status_code)
	{	pNtClose(handle);
		return GENERIC_WRITE;
	}
	
	//else if(status_code != EXCEPTION_ACCESS_VIOLATION && status_code != STATUS_ACCESS_DENIED)
	status_code = pNtOpenGeneric(&handle, GENERIC_READ, &path_attributes);
	if(STATUS_SUCCESS == status_code)
	{	pNtClose(handle);
		return GENERIC_READ;
	}
	
	//else if(status_code != EXCEPTION_ACCESS_VIOLATION && status_code != STATUS_ACCESS_DENIED)
	return 0;
}

ULONG GetSymbolicLink(OBJECT_DIRECTORY_INFORMATION *ob, PUCHAR *path, PUCHAR *symlnkName)
{
ULONG len;
LONG st;
HANDLE hLink;
OBJECT_ATTRIBUTES obj_attributes;
UNICODE_STRING unicode_str,lnkNameStr;
NTSTATUS status_code = 0;
PUCHAR buf[512];

	if(wcscmp(&ob->TypeName.Buffer[0], L"SymbolicLink"))
		return 0;

	wcscpy((LPWSTR)buf,(LPWSTR)path);
	len = (ULONG)wcslen((LPWSTR)buf);

	//unicode_str.Length = (USHORT)ob->Name.Length*2;
	//unicode_str.MaximumLength = (USHORT)ob->Name.MaximumLength*2+2;
	//unicode_str.Buffer = ob->Name.Buffer;
	unicode_str.Length = 2*len;
	unicode_str.MaximumLength = 2*512;
	unicode_str.Buffer = (LPWSTR)buf;

	InitializeObjectAttributes(&obj_attributes,&unicode_str,0,NULL,NULL);

    st = pNtOpenSymbolicLinkObject(&hLink, GENERIC_READ, &obj_attributes);
    if(st < 0)
		return 0;

	lnkNameStr.Length = 1024;//2*512;
	lnkNameStr.MaximumLength = 1024;//2*512;
	lnkNameStr.Buffer = (PWSTR)symlnkName;

    st = pNtQuerySymbolicLinkObject(hLink, &lnkNameStr, len);
    if(st < 0)
		return 0;
	
	st = CloseHandle(hLink);
	return 1;
}