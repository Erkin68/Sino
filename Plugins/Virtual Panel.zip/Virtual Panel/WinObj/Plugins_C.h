#ifndef __PLUGINS_C_H__
#define __PLUGINS_C_H__


#include "windows.h"
#include "MyList.h"



//extern "C"
//{

extern BOOL LoadNTFuncs();

extern wchar_t **strngs;
extern HMODULE plgnDllInst;

typedef BOOL (CALLBACK *saveOptions_t)(IN int,VOID*,int);
typedef BOOL (CALLBACK *readOptions_t)(IN int,VOID*,int);
typedef int	 (CALLBACK *addItemToPanelList_t)(IN LPVOID,wchar_t*,HICON,WIN32_FIND_DATAW*,DWORD,BOOL);
typedef int (CALLBACK *changeItemInPanelList_t)(IN LPVOID,wchar_t*,wchar_t*,BOOL);
typedef int	 (CALLBACK *closeEvent_t)(IN int,IN LPVOID);
typedef int (CALLBACK *setPanelPath_t)(IN LPVOID,wchar_t*,int);
//typedef int (CALLBACK *render_t)(IN LPVOID);
//typedef int (CALLBACK *freePanel_t)(IN LPVOID,BOOL);
//typedef int (CALLBACK *selectItem_t)(IN LPVOID,int,wchar_t*);


extern saveOptions_t saveOptions;
extern readOptions_t readOptions;
extern addItemToPanelList_t addItemToPanelList;
extern changeItemInPanelList_t changeItemInPanelList;
extern closeEvent_t closeEvent;
extern setPanelPath_t setPanelPath;
//extern render_t render;
//extern freePanel_t freePanel;
//extern selectItem_t selectItem;

extern LPVOID *plgList;
extern int	  iPlgList;
extern int	  plgId;

typedef struct TPluginObj
{	LPVOID host;//Panel* object;
	int pathLn;
	wchar_t path[MAX_PATH];
	int enumPathLn;
	wchar_t enumPath[2*MAX_PATH];
	my_list *list;
	int listcnt;
} PluginObj;

//****************** Native NT.c **********************
//****************** Native NT.c **********************
//****************** Native NT.c **********************
//****************** Native NT.c **********************
//****************** Native NT.c **********************
//****************** Native NT.c **********************
//****************** Native NT.c **********************
//****************** Native NT.c **********************
extern BOOL  LoadNTFuncs();
extern BOOL  EnumObjDir(LPVOID,wchar_t*);
extern BOOL  GetReadyForEnumObjDir(LPVOID,wchar_t*);

//****************** mem.c ****************************
//****************** mem.c ****************************
//****************** mem.c ****************************
//****************** mem.c ****************************
//****************** mem.c ****************************
//****************** mem.c ****************************
//****************** mem.c ****************************
//****************** mem.c ****************************
//****************** mem.c ****************************


//}
#endif