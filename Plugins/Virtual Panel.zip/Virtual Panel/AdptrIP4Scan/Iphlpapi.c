#pragma warning(disable:42)
#pragma warning(disable:4995)
#pragma warning(disable:4996)

#include <winsock2.h>
#include <iphlpapi.h>
#include <stdio.h>
#include "Plugins_C.h"
#include "WinPCapSrc\driverNT\WpcapNames.h"



int GetAdapterMacAndGatewayIP4XP(char *MAC,char *gatewayIP,char *adptrName)//gatewayIP [4] ta
{
int iFind = 0;
PIP_ADAPTER_INFO pAdapter,pAdapterInfo = (IP_ADAPTER_INFO*)malloc(sizeof(IP_ADAPTER_INFO));
ULONG ulOutBufLen = sizeof(IP_ADAPTER_INFO);
	
// Make an initial call to GetAdaptersInfo to get
// the necessary size into the ulOutBufLen variable
	if(ERROR_BUFFER_OVERFLOW==GetAdaptersInfo(pAdapterInfo, &ulOutBufLen))
	{	free(pAdapterInfo);
		pAdapterInfo = (IP_ADAPTER_INFO*) malloc(ulOutBufLen);
		if(pAdapterInfo == NULL)return 0;
		pAdapter = pAdapterInfo;
		if(NO_ERROR!=GetAdaptersInfo( pAdapterInfo, &ulOutBufLen))
		{	free(pAdapterInfo);		
			return 0;
	}	}
	else pAdapter = pAdapterInfo;
	while(pAdapter)
	{	//printf("\tAdapter Name: \t%s\n", pAdapter->AdapterName);
		//printf("\tGateway: \t%s\n", pAdapter->GatewayList.IpAddress.String);
		//if(pAdapter->DhcpEnabled) pAdapter->DhcpServer.IpAddress.String);
		//if(pAdapter->HaveWins) pAdapter->PrimaryWinsServer.IpAddress.String);
		if(!_stricmp(pAdapter->AdapterName,&adptrName[9+NPF_DRIVER_NAME_LENGTH]))
		{	/*if(!pAdapter->GatewayList)
			{	iFind = -1;
				break;//Ulanmagan;
			}*/
			ulOutBufLen = inet_addr((char*)&pAdapter->GatewayList.IpAddress);
			CopyIp4(gatewayIP,&ulOutBufLen);
			CopyIp6(MAC,pAdapter->Address);
			iFind = 1;
			break;
		}
		pAdapter = pAdapter->Next;
	}
	if(pAdapterInfo)
		free(pAdapterInfo);
	return iFind;
}

__declspec (dllexport) int GetAdapterMacAndGatewayIP4(char *MAC,char *gatewayIP,char *adptrName)//gatewayIP [4] ta
{
PIP_ADAPTER_ADDRESSES AdapterAddresses = NULL;
ULONG OutBufferLength = 0;
ULONG RetVal = 0, i;
int iFind = 0;
OSVERSIONINFOEXW vi;
	vi.dwOSVersionInfoSize = sizeof(OSVERSIONINFOEX);
	GetVersionEx((LPOSVERSIONINFOW)&vi);
	if(vi.dwMajorVersion < 6)
		return GetAdapterMacAndGatewayIP4XP(MAC,gatewayIP,adptrName);
// The size of the buffer can be different 
// between consecutive API calls.
// In most cases, i < 2 is sufficient;
// One call to get the size and one call to get the actual parameters.
// But if one more interface is added or addresses are added, 
// the call again fails with BUFFER_OVERFLOW. 
// So the number is picked slightly greater than 2. 
// We use i <5 in the example
    for(i = 0; i < 5; i++)
	{	RetVal = GetAdaptersAddresses(AF_INET,GAA_FLAG_INCLUDE_GATEWAYS|GAA_FLAG_INCLUDE_ALL_INTERFACES,
									  NULL,AdapterAddresses,&OutBufferLength);
        if(RetVal != ERROR_BUFFER_OVERFLOW) break;
        if(AdapterAddresses != NULL) FREE(AdapterAddresses);
        AdapterAddresses = (PIP_ADAPTER_ADDRESSES)MALLOC(OutBufferLength);
        if(AdapterAddresses == NULL)
		{	RetVal = GetLastError();
            break;
    }	}    
    if(RetVal == NO_ERROR)
	{	// If successful, output some information from the data we received
		PIP_ADAPTER_ADDRESSES AdapterList = AdapterAddresses;
		while(AdapterList)
		{	//printf("\tFriendly name: %S\n", AdapterList->FriendlyName);
			//printf("\tDescription: %S\n", AdapterList->Description);
			CopyIp6(MAC,&AdapterList->PhysicalAddress[0]);
			if(!_stricmp(AdapterList->AdapterName,&adptrName[9+NPF_DRIVER_NAME_LENGTH]))
			{	if(!AdapterList->FirstGatewayAddress)
				{	iFind = -1;
					break;//Ulanmagan;
				}
				if(AF_INET!=AdapterList->FirstGatewayAddress->Address.lpSockaddr->sa_family)
				{	iFind = -2;
					break;
				}
				//CopyIp6(MAC,&AdapterList->PhysicalAddress[0]);
				CopyIp4(gatewayIP,&AdapterList->FirstGatewayAddress->Address.lpSockaddr->sa_data[2]);
				iFind = 1;
				break;
			}
			AdapterList = AdapterList->Next;
	}	}
    else
	{ /*LPVOID MsgBuf;
      printf("Call to GetAdaptersAddresses failed.\n");
      if(FormatMessage( 
        FORMAT_MESSAGE_ALLOCATE_BUFFER | 
        FORMAT_MESSAGE_FROM_SYSTEM | 
        FORMAT_MESSAGE_IGNORE_INSERTS,
        NULL,
        RetVal,
        MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), // Default language
        (LPTSTR) &MsgBuf,
        0,
        NULL))
        printf("\tError: %s", MsgBuf);
      LocalFree(MsgBuf);*/
    }  

    if(AdapterAddresses != NULL)
        FREE(AdapterAddresses);
	return iFind;
}

void getLocalMac(char *localMac,char *localIP)
{
 ULONG numOfAdapter=0;int i,index=0;
 char mac[5][20]={0},IP[5][20]={0};

 GetAdaptersInfo(NULL,&numOfAdapter);
 if(numOfAdapter!=0)
 {
  IP_ADAPTER_INFO *pAdapterInfo=(IP_ADAPTER_INFO *)malloc( numOfAdapter*sizeof(IP_ADAPTER_INFO) );
  memset( pAdapterInfo,0,numOfAdapter*sizeof(IP_ADAPTER_INFO) );
  GetAdaptersInfo(pAdapterInfo,&numOfAdapter);

  printf("Please select the local mac!\n");
  for(i=0;( (i<5) && (pAdapterInfo!=NULL) );i++)
  {sprintf(mac[i],"%02x%02x%02x%02x%02x%02x",pAdapterInfo->Address[0],pAdapterInfo->Address[1],pAdapterInfo->Address[2],
           pAdapterInfo->Address[3],pAdapterInfo->Address[4],pAdapterInfo->Address[5]);
   memcpy( IP[i],pAdapterInfo->IpAddressList.IpAddress.String,strlen(pAdapterInfo->IpAddressList.IpAddress.String) );

   printf("%d, %s--%s\n",i+1,IP[i],mac[i]);
   pAdapterInfo=pAdapterInfo->Next;
 }}

 //scanf("%d",&index);
 index=1;
 memcpy(localMac,mac[index-1],strlen(mac[index-1]));
 memcpy(localIP,IP[index-1],strlen(IP[index-1]));

 return;
}