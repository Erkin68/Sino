#ifndef __PLUGINS_C_H__
#define __PLUGINS_C_H__

#pragma comment(lib,"comctl32.lib")
#pragma comment(lib,"Ws2_32.lib")
#pragma comment(lib,"User32.lib")
#pragma comment(lib,"Advapi32.lib")
#pragma comment(lib,"Version.lib")
#pragma comment(lib,"Iphlpapi.lib")
#pragma comment(lib,"Mpr.lib")
#pragma comment(lib,"Netapi32.lib")


#include "windows.h"
#include "..\WinObj\MyList.h"
#include "Iphlpapi.h"

#define bool BYTE
#define false 0
#define true  1

#define NUM_RECV_PCKTS		8
#define recvBufLen			32764// 4096
#define EHTHdrLen			14
#define IP4HdrLen			20
#define UDPBufLen			58
#define totUDPBufLen		92
#define EHTHAndIP4hdrLen	34
#define ARPReqLen			44
#define ICMPEchoReqLen		76//112 64


#define MALLOC(x) HeapAlloc(GetProcessHeap(), 0, (x)) 
#define FREE(x) HeapFree(GetProcessHeap(), 0, (x))


typedef unsigned char u8;
typedef unsigned __int32 u32;

//extern "C"
//{

extern wchar_t **strngs;
extern HMODULE plgnDllInst;

typedef BOOL (CALLBACK *saveOptions_t)(IN int,VOID*,int);
typedef BOOL (CALLBACK *readOptions_t)(IN int,VOID*,int);
typedef int	 (CALLBACK *addItemToPanelList_t)(IN LPVOID,wchar_t*,HICON,WIN32_FIND_DATAW*,DWORD,BOOL);
typedef int	 (CALLBACK *changeItemInPanelList_t)(IN LPVOID,wchar_t*,wchar_t*,BOOL);
typedef int	 (CALLBACK *closeEvent_t)(IN int,IN LPVOID);
typedef int	 (CALLBACK *setPanelPath_t)(IN LPVOID,wchar_t*,int);
//typedef int	 (CALLBACK *render_t)(IN LPVOID);
//typedef int	 (CALLBACK *freePanel_t)(IN LPVOID,BOOL);
//typedef int	 (CALLBACK *selectItem_t)(IN LPVOID,int,wchar_t*);


extern saveOptions_t saveOptions;
extern readOptions_t readOptions;
extern addItemToPanelList_t addItemToPanelList;
extern changeItemInPanelList_t changeItemInPanelList;
extern closeEvent_t closeEvent;
extern setPanelPath_t setPanelPath;
//extern render_t render;
//extern freePanel_t freePanel;
//extern selectItem_t selectItem;

extern int plgId;
extern LPVOID *plgList;
extern int	   iPlgList;

typedef struct TIP6BYTE
{	
	BYTE b[6];		
} IP6BYTE;
#define CopyIp6(ipto, ipfr) *((DWORD*)ipto) = *((DWORD*)ipfr); \
							*((WORD*)(((DWORD*)ipto)+1)) = *((WORD*)(((DWORD*)ipfr)+1))
typedef struct TIP4BYTE
{	
	BYTE b[4];		
} IP4BYTE;
#define CopyIp4(ipto, ipfr) *((DWORD*)ipto) = *((DWORD*)ipfr)
#define Ip4AsDWORD(ip) ((ip.b[0] << 24) | (ip.b[1] << 16) | (ip.b[2] << 8) | ip.b[3])
//#define Ip4AsDWORD(ip) ntohl(&ip.b[0])
#define ZeroIp4(ip) (*((DWORD*)ip) = 0)

typedef enum TState
{	attachForScan,
	attachWithoutScan,
	scan,					//scan ketopdi;
	wait_for_stopping,
	wait_for_stopandexiting,
	end_scan,				//Xolodniy ostanov thread a;
	in_top,					//NET papkalar ko'rinishida ko'rinadi;
	in_domain_group_folder,	//domain grp papkasida;
	in_WNetEnumResource,	//1-list via WNetEnumResource;
	in_foldersEnum
} State;

#define TOT_RCV_BUF 4
#define RCV_BUF_LEN 262144

typedef struct TIPNodes
{
	DWORD IP;//unsigned __int32 shufled
//	unsigned char MAC[6];
//	unsigned char st[2];
	wchar_t NETBIOSNAME[32];
	wchar_t NETBIOSGROUPNAME[32];
	int nodePtr;
} tIPNodes;

typedef struct TDomainNodes
{
	wchar_t NAME[32];
} tDomainNodes;

typedef struct TPluginObj
{	LPVOID host;//Panel* object;
	HWND prnt;
	HWND tlbrLabelState,tlbrEditState,tlbrBtnOptn,tlbrBtnExit,tlbrBtnResetList,tlbrPrgrs,tlbrWnd;
	HWND tlbrBtnStop;//MyButton tlbrBtnStop;	
	HWND schDlgOkBtn;
	int pathLn;
	wchar_t path[MAX_PATH];
	wchar_t crntDomainGroup[MAX_PATH];
	HANDLE ScanThrd,RecvThrd;
	int TermScanThrd;
	DWORD ScanThrdId,RecvThrdId;

	State state;
	BYTE *SendBitTable;//bit files;
	long totSearchNodes;

	// Topilgan nodelar ro'yxati***
	tIPNodes *IPNodes;			//*
	int IPNodesCnt;				//*
	int IPNodesMaxCnt;			//*
	//*****************************

	//*Topilgan domainlar ro'yxati*
	tDomainNodes *DomainNodes;	//*
	int DomainNodesCnt;			//*
	int DomainNodesMaxCnt;		//*
	//*****************************

	LPTHREAD_START_ROUTINE trd;//via or without gate thread

	IP4BYTE crntAdptrGatewayIP4;
	IP6BYTE crntAdptrMAC;
	IP6BYTE crntAdptrGWMAC;//Gateway
	DWORD   dwCrntAdptrGatewayIP4;
	IP4BYTE crntAdptrMask;
	DWORD dwCrntAdptrMask;
	int crntAdptrIPGroupe;//A,B,C,D NET ning klasslari;

	//confdan oladiganlari:
	IP4BYTE ipFrom,ipTo,myIP,crntListNodeIP,ipWEnum;
	DWORD	dwIPFrom,dwIPTo,dwMyIP,dwIPWEnum;//,dwCrntListNodeIP;
	int		iScanMethod[2];
	char	crntAdptrDesc[MAX_PATH],
			crntAdptrName[MAX_PATH],
			crntAdptrNameInFile[MAX_PATH];
	int iCrntAdapter,iCrntAdapterIPAddress;

	//Search process buffer datas:
	LPVOID srchResltBuf;
	int srchResltBufLn;

	//BOOL bFindDlgFirstCreatedToResizeChld=FALSE;
	//int width,height,minWidth=580,minHeight=486,minHeightAftCrLB=638;
	//HWND hViewBTN=NULL,hEditBTN=NULL,hBrowseBTN=NULL,hToPanelBTN=NULL,hResultsLB=NULL,hInfoEdit=NULL;
	LPVOID search;//TSearch search;
} PluginObj;

typedef struct TConf
{	IP4BYTE ipFrom,ipTo;
	IP4BYTE *IPList;
	long iIPListCnt;
	int  iNumAdapters;
	int  iScanMethod[2];
	int  iSpeed;
	int  iTimeout;
	char crntAdptrDesc[MAX_PATH],crntAdptrName[MAX_PATH],crntAdptrNameInFile[MAX_PATH];
	char *AdaptersName,*pAdatersIPNums;//har 1 adapterda nechtadan IP address borligi;
	LPVOID **pAdaptersIf_addrs;//IP_ADAPTER_INFO *pAdaptersInfo;
	int iCrntAdapter,iCrntAdapterIPAddress;
	bool bFasterIcon;
	bool bUsePredefinedIPList;
} Conf;
extern Conf conf;
//****************** Native NT.c **********************
//****************** Native NT.c **********************
//****************** Native NT.c **********************
//****************** Native NT.c **********************
//****************** Native NT.c **********************
//****************** Native NT.c **********************
//****************** Native NT.c **********************
//****************** Native NT.c **********************
extern BOOL  LoadNTFuncs();
extern BOOL  EnumDir(LPVOID,wchar_t*);

//****************** mem.c ****************************
//****************** mem.c ****************************
//****************** mem.c ****************************
//****************** mem.c ****************************
//****************** mem.c ****************************
//****************** mem.c ****************************
//****************** mem.c ****************************
//****************** mem.c ****************************
//****************** mem.c ****************************



#define ETH_ADD_LEN			6
#define ARP_PRO_IP			0x0800
#define ETH_TYPE_ARP		0x0806
#define ARP_ETH_ADD_SPACE	6
#define ARP_IP_ADD_SPACE	4

#define ARP_OP_REQUEST		0x0001
#define ARP_REPLY			0x0002
#define ARP_HARDWARE		0x0001
#define ETH_PADDING_ARP		0


#pragma pack(push, 1)
typedef struct TET_HEADER
{
unsigned char   eth_dst[ETH_ADD_LEN];  
unsigned char   eth_src[ETH_ADD_LEN];
unsigned short  eth_type;
}ET_HEADER,*PET_HEADER;
typedef struct TARP_HEADER
{
unsigned short  arp_hdr;
unsigned short  arp_pro;
unsigned char   arp_hln;
unsigned char   arp_pln;
unsigned short  arp_opt;
unsigned char   arp_sha[6];
unsigned long   arp_spa;
unsigned char   arp_tha[6];
unsigned long   arp_tpa;
}ARP_HEADER,*PARP_HEADER;
typedef struct TArpPacket
{
ET_HEADER	eth;
ARP_HEADER  arp;
BYTE eth_pad[32];
}ArpPacket,*PArpPacket;
typedef struct TIP_HEADER
{
char m_ver_hlen;
char m_tos;
USHORT m_tlen;
USHORT m_ident;
USHORT m_flag_frag;
char m_ttl;
char m_protocol;
USHORT m_cksum;
ULONG m_sIP;
ULONG m_dIP;
}IP_HEADER,*PIP_HEADER;
typedef struct TTCP_HEADER
{
USHORT m_sport;
USHORT m_dport;
ULONG m_seq;
ULONG m_ack;   
char m_hlen_res4;
char m_res2_flag;
USHORT m_win;
USHORT m_cksum;
USHORT m_urp;
}TCP_HEADER,*PTCP_HEADER;
typedef struct TPSD_HEADER
{
ULONG m_saddr;
ULONG m_daddr;
char m_mbz; 
char m_ptcl;
USHORT m_tcpl;
}PSD_HEADER,*PPSD_HEADER;
typedef struct TTCP_OPTION
{
USHORT unKnown;
USHORT maxSegSize;
char no1;
char no2;
USHORT SACK;
}TCP_OPTION,*PTCP_OPTION;
typedef struct TCHEAT_ARP_INFO
{
char simulateIP[20];
char targetIP[20];
char targetMAC[13];
}CHEAT_ARP_INFO,*PCHEAT_ARP_INFO;

/*__inline VOID CopyIp6(LPVOID ipto, LPVOID ipfr)
{
	((BYTE*)ipto)[0] = ((BYTE*)ipfr)[0];
	((BYTE*)ipto)[1] = ((BYTE*)ipfr)[1];
	((BYTE*)ipto)[2] = ((BYTE*)ipfr)[2];
	((BYTE*)ipto)[3] = ((BYTE*)ipfr)[3];
	((BYTE*)ipto)[4] = ((BYTE*)ipfr)[4];
	((BYTE*)ipto)[5] = ((BYTE*)ipfr)[5];
}*/

extern HICON hIconUnknown,hIconNotAccess;//,hIconFastFile;

extern BOOL	 LoadNTFuncs();
extern __declspec (dllexport) int GetAdapterMacAndGatewayIP4(char*,char*,char*);//gatewayIP [4] ta
extern void  ip_checksum(void*,size_t);
extern void  udp_checksum(void*,size_t);
extern INT_PTR CALLBACK OptnDlgProc(HWND,UINT,WPARAM,LPARAM);
extern BOOL GetAdaptersNumsAndNames();
extern BOOL GetAdaptersAdresses();
extern __declspec (dllexport) int GetAdapterMacAndGatewayIP4(char*,char*,char*);
extern DWORD WINAPI recvThrdRoutine(LPVOID);
//extern DWORD WINAPI WEnumNodeThrdProc(LPVOID);
extern DWORD WINAPI ScanViaGateThrdProc(LPVOID);
extern DWORD WINAPI ScanWithoutGateThrdProc(LPVOID);
extern BOOL SaveOptions();

extern __declspec (dllexport) VOID DetachPanel$8(LPVOID,LPVOID);

extern BOOL addNodeToPlgList(PluginObj*,wchar_t*,wchar_t*,WIN32_FIND_DATA*,DWORD);
extern VOID Ip4Shufl(DWORD*, BYTE*);
extern BOOL Cmp6Byte(BYTE*,BYTE*);
extern BOOL Cmp4Byte(BYTE*,BYTE*);

//AdptrIP4Scan.c
extern BOOL FolderUp(PluginObj*);
extern BOOL FolderIn(PluginObj*,int,wchar_t*);

//**** MySockets.c: ****
//extern BOOL RetriveHostNameAndDomainName(PluginObj*,int,wchar_t*);

extern int FirstEntranceNode(PluginObj*,int,DWORD);
extern BOOL IsCrntOrPrntDirAttrb(wchar_t*);

//extern int FolderInNode(PluginObj*,int,wchar_t*);
//extern int FolderUpNode(PluginObj*,int);
extern int FolderList(PluginObj*,wchar_t*);
extern VOID WaitForScan(PluginObj*,DWORD,int);

extern void OnTop(PluginObj*,wchar_t*);
extern void OnDomainGroup(PluginObj*,wchar_t*,wchar_t*);

extern wchar_t* GetNodeNBUName(PluginObj*,DWORD,int,int*);
extern wchar_t* GetNodeGroupName(PluginObj*,DWORD,int*);
extern int GetNodeFromPlgList(PluginObj*,DWORD);
extern wchar_t* GetPanelItemName(PluginObj*,int,int,wchar_t*);
extern BOOL IsFolderAccessible(wchar_t*);
extern BOOL IsFolderAccessible(wchar_t*);
extern BOOL IsFolderAccessibleWI(wchar_t*);
extern int ProcessRecvPacketGW(BYTE*,int,int*,PluginObj*,wchar_t*,wchar_t*,DWORD*,BYTE*);





#pragma pack(pop)
//}
#endif