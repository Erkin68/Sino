#pragma warning(disable:4005)

#include "Packet32.h"
#include "windows.h"
#include "debug.h"
#include "..\resource.h"
#include "..\Plugins_C.h"
#include "strsafe.h"

#pragma warning(disable:4995)
#pragma warning(disable:4996)
#define PCAP_ERRBUF_SIZE 512

wchar_t s[PCAP_ERRBUF_SIZE];

INT_PTR CALLBACK ShuttedDownAdaptersListFromRegistryDlgProc(HWND,UINT,WPARAM,LPARAM);
int  MyStringCpyA(char*,int,char*);

/*typedef PCHAR (*PacketGetVersion_t)();PacketGetVersion_t PacketGetVersion_;
typedef PCHAR (*PacketGetDriverVersion_t)();PacketGetDriverVersion_t PacketGetDriverVersion_;
typedef BOOLEAN (*PacketSetMinToCopy_t)(LPADAPTER AdapterObject,int nbytes);PacketSetMinToCopy_t PacketSetMinToCopy_;
typedef BOOLEAN (*PacketSetNumWrites_t)(LPADAPTER AdapterObject,int nwrites);PacketSetNumWrites_t PacketSetNumWrites_;
typedef BOOLEAN (*PacketSetMode_t)(LPADAPTER AdapterObject,int mode);PacketSetMode_t PacketSetMode_;
typedef BOOLEAN (*PacketSetReadTimeout_t)(LPADAPTER AdapterObject,int timeout);PacketSetReadTimeout_t PacketSetReadTimeout_;
typedef BOOLEAN (*PacketSetBpf_t)(LPADAPTER AdapterObject,struct bpf_program *fp);PacketSetBpf_t PacketSetBpf_;
typedef BOOLEAN (*PacketSetLoopbackBehavior_t)(LPADAPTER  AdapterObject, UINT LoopbackBehavior);PacketSetLoopbackBehavior_t PacketSetLoopbackBehavior_;
typedef INT (*PacketSetSnapLen_t)(LPADAPTER AdapterObject,int snaplen);PacketSetSnapLen_t PacketSetSnapLen_;
typedef BOOLEAN (*PacketGetStats_t)(LPADAPTER AdapterObject,struct bpf_stat *s);PacketGetStats_t PacketGetStats_;
typedef BOOLEAN (*PacketGetStatsEx_t)(LPADAPTER AdapterObject,struct bpf_stat *s);PacketGetStatsEx_t PacketGetStatsEx_;
typedef BOOLEAN (*PacketSetBuff_t)(LPADAPTER AdapterObject,int dim);PacketSetBuff_t PacketSetBuff_;
typedef BOOLEAN (*PacketGetNetType_t)(LPADAPTER AdapterObject,NetType *type);PacketGetNetType_t PacketGetNetType_;
typedef LPADAPTER (*PacketOpenAdapter_t)(PCHAR AdapterName);PacketOpenAdapter_t PacketOpenAdapter_;
typedef BOOLEAN (*PacketSendPacket_t)(LPADAPTER AdapterObject,LPPACKET pPacket,BOOLEAN Sync);PacketSendPacket_t PacketSendPacket_;
typedef INT (*PacketSendPackets_t)(LPADAPTER AdapterObject,PVOID PacketBuff,ULONG Size, BOOLEAN Sync);PacketSendPackets_t PacketSendPackets_;
typedef LPPACKET (*PacketAllocatePacket_t)(void);PacketAllocatePacket_t PacketAllocatePacket_;
typedef VOID (*PacketInitPacket_t)(LPPACKET lpPacket,PVOID  Buffer,UINT  Length);PacketInitPacket_t PacketInitPacket_;
typedef VOID (*PacketFreePacket_t)(LPPACKET lpPacket);PacketFreePacket_t PacketFreePacket_;
typedef BOOLEAN (*PacketReceivePacket_t)(LPADAPTER AdapterObject,LPPACKET lpPacket,BOOLEAN Sync);PacketReceivePacket_t PacketReceivePacket_;
typedef BOOLEAN (*PacketSetHwFilter_t)(LPADAPTER AdapterObject,ULONG Filter);PacketSetHwFilter_t PacketSetHwFilter_;
typedef BOOLEAN (*PacketGetAdapterNames_t)(PTSTR pStr,PULONG  BufferSize);PacketGetAdapterNames_t PacketGetAdapterNames_;
typedef BOOLEAN (*PacketGetNetInfoEx_t)(PCHAR AdapterName, npf_if_addr* buffer, PLONG NEntries);PacketGetNetInfoEx_t PacketGetNetInfoEx_;
typedef BOOLEAN (*PacketRequest_t)(LPADAPTER  AdapterObject,BOOLEAN Set,PPACKET_OID_DATA  OidData);PacketRequest_t PacketRequest_;
typedef HANDLE (*PacketGetReadEvent_t)(LPADAPTER AdapterObject);PacketGetReadEvent_t PacketGetReadEvent_;
typedef BOOLEAN (*PacketSetDumpName_t)(LPADAPTER AdapterObject, void *name, int len);PacketSetDumpName_t PacketSetDumpName_;
typedef BOOLEAN (*PacketSetDumpLimits_t)(LPADAPTER AdapterObject, UINT maxfilesize, UINT maxnpacks);PacketSetDumpLimits_t PacketSetDumpLimits_;
typedef BOOLEAN (*PacketIsDumpEnded_t)(LPADAPTER AdapterObject, BOOLEAN sync);PacketIsDumpEnded_t PacketIsDumpEnded_;
typedef BOOL (*PacketStopDriver_t)();PacketStopDriver_t PacketStopDriver_;
typedef VOID (*PacketCloseAdapter_t)(LPADAPTER lpAdapter);PacketCloseAdapter_t PacketCloseAdapter_;
typedef BOOLEAN (*PacketStartOem_t)(PCHAR errorString, UINT errorStringLength);PacketStartOem_t PacketStartOem_;
typedef BOOLEAN (*PacketStartOemEx_t)(PCHAR errorString, UINT errorStringLength, ULONG flags);PacketStartOemEx_t PacketStartOemEx_;
typedef PAirpcapHandle (*PacketGetAirPcapHandle_t)(LPADAPTER AdapterObject);PacketGetAirPcapHandle_t PacketGetAirPcapHandle_;
*/
typedef ULONG (WINAPI *GetAdaptersAddresses_t)(__in ULONG,__in ULONG,__in PVOID,PIP_ADAPTER_ADDRESSES,PULONG);
GetAdaptersAddresses_t GetAdaptersAddresses_=NULL;
typedef DWORD (WINAPI *GetAdaptersInfo_t)(__out PIP_ADAPTER_INFO,PULONG);
GetAdaptersInfo_t GetAdaptersInfo_;

BOOL GetAdaptersAdresses();


BOOL IphlpapiLib()
{
HMODULE hm;
//OSVERSIONINFO osvi;
//BOOL bIsWindowsVistaOrLater;
//wchar_t *p;
//	GetModuleFileName(plgnDllInst,s,256);
//	p=wcsrchr(s,'\\');
//	if(p) ++p;
//	else return FALSE;

//    ZeroMemory(&osvi, sizeof(OSVERSIONINFO));
//    osvi.dwOSVersionInfoSize = sizeof(OSVERSIONINFO);
//    GetVersionEx(&osvi);
//    bIsWindowsVistaOrLater = (osvi.dwMajorVersion > 5);// || ( (osvi.dwMajorVersion == 5) && (osvi.dwMinorVersion >= 1) ));

//	wcscpy(p,bIsWindowsVistaOrLater ? L"winpcap\\vista\\x86\\Packet.dll" :
//									  L"winpcap\\nt5\\x86\\Packet.dll");
/*	hm = LoadLibraryW(L"Packet.dll");//hm = LoadLibrary(s);
	if(!hm)
	{	MessageBox(NULL,L"Winpcap utility is not founded...",L"Error...",MB_OK);
		return FALSE;
	}
	PacketGetVersion_ = (PacketGetVersion_t)GetProcAddress(hm,"PacketGetVersion");
	PacketGetDriverVersion_	= (PacketGetDriverVersion_t)GetProcAddress(hm,"PacketGetDriverVersion");
	PacketSetMinToCopy_ = (PacketSetMinToCopy_t)GetProcAddress(hm,"PacketSetMinToCopy");
	PacketSetMinToCopy_ = (PacketSetMinToCopy_t)GetProcAddress(hm,"PacketSetNumWrites");
	PacketSetMode_ = (PacketSetMode_t)GetProcAddress(hm,"PacketSetMode");
	PacketSetReadTimeout_ = (PacketSetReadTimeout_t)GetProcAddress(hm,"PacketSetReadTimeout");
	PacketSetBpf_ = (PacketSetBpf_t)GetProcAddress(hm,"PacketSetBpf");
	PacketSetLoopbackBehavior_ = (PacketSetLoopbackBehavior_t)GetProcAddress(hm,"PacketSetLoopbackBehavior");
	PacketSetSnapLen_ = (PacketSetSnapLen_t)GetProcAddress(hm,"PacketSetSnapLen");
	PacketGetStats_ = (PacketGetStats_t)GetProcAddress(hm,"PacketGetStats");
	PacketGetStatsEx_ = (PacketGetStatsEx_t)GetProcAddress(hm,"PacketGetStatsEx");
	PacketSetBuff_ = (PacketSetBuff_t)GetProcAddress(hm,"PacketSetBuff");
	PacketGetNetType_ = (PacketGetNetType_t)GetProcAddress(hm,"PacketGetNetType");
	PacketOpenAdapter_ = (PacketOpenAdapter_t)GetProcAddress(hm,"PacketOpenAdapter");
	PacketSendPacket_ = (PacketSendPacket_t)GetProcAddress(hm,"PacketSendPacket");
	PacketSendPackets_ = (PacketSendPackets_t)GetProcAddress(hm,"PacketSendPackets");
	PacketAllocatePacket_ = (PacketAllocatePacket_t)GetProcAddress(hm,"PacketAllocatePacket");
	PacketInitPacket_ = (PacketInitPacket_t)GetProcAddress(hm,"PacketInitPacket");
	PacketFreePacket_ = (PacketFreePacket_t)GetProcAddress(hm,"PacketFreePacket");
	PacketReceivePacket_ = (PacketReceivePacket_t)GetProcAddress(hm,"PacketReceivePacket");
	PacketSetHwFilter_ = (PacketSetHwFilter_t)GetProcAddress(hm,"PacketSetHwFilter");
	PacketGetAdapterNames_ = (PacketGetAdapterNames_t)GetProcAddress(hm,"PacketGetAdapterNames");
	PacketGetNetInfoEx_ = (PacketGetNetInfoEx_t)GetProcAddress(hm,"PacketGetNetInfoEx");
	PacketRequest_ = (PacketRequest_t)GetProcAddress(hm,"PacketRequest");
	PacketGetReadEvent_ = (PacketGetReadEvent_t)GetProcAddress(hm,"PacketGetReadEvent");
	PacketSetDumpName_ = (PacketSetDumpName_t)GetProcAddress(hm,"PacketSetDumpName");
	PacketSetDumpLimits_ = (PacketSetDumpLimits_t)GetProcAddress(hm,"PacketSetDumpLimits");
	PacketIsDumpEnded_ = (PacketIsDumpEnded_t)GetProcAddress(hm,"PacketIsDumpEnded");
	PacketStopDriver_ = (PacketStopDriver_t)GetProcAddress(hm,"PacketStopDriver");
	PacketCloseAdapter_ = (PacketCloseAdapter_t)GetProcAddress(hm,"PacketCloseAdapter");
	PacketStartOem_ = (PacketStartOem_t)GetProcAddress(hm,"PacketStartOem");
	PacketStartOemEx_ = (PacketStartOemEx_t)GetProcAddress(hm,"PacketStartOemEx");
	PacketGetAirPcapHandle_ = (PacketGetAirPcapHandle_t)GetProcAddress(hm,"PacketGetAirPcapHandle");
*/
	hm = LoadLibraryW(L"Iphlpapi.dll");
	if(!hm)
	{	MessageBox(NULL,strngs[97]/*L"Iphlpapi.dll is not founded..."*/,strngs[53]/*L"Error..."*/,MB_OK);
		return FALSE;
	}
	GetAdaptersAddresses_ = (GetAdaptersAddresses_t)GetProcAddress(hm,"GetAdaptersAddresses");
	GetAdaptersInfo_ = (GetAdaptersInfo_t)GetProcAddress(hm,"GetAdaptersInfo");
	return TRUE;
}

char *pcap_win32strerror(void)
{
	DWORD error;
	static char errbuf[PCAP_ERRBUF_SIZE+1];
	int errlen;
	char *p;

	error = GetLastError();
	FormatMessageA(FORMAT_MESSAGE_FROM_SYSTEM, NULL, error, 0, errbuf,
					PCAP_ERRBUF_SIZE, NULL);

	errlen = (int)strlen(errbuf);
	if (errlen >= 2) {
		errbuf[errlen - 1] = '\0';
		errbuf[errlen - 2] = '\0';
	}
	p = strchr(errbuf, '\0');
	StringCchPrintfA(p, sizeof(errbuf)-(p-errbuf), " (%lu)", error);
	return (errbuf);
} 

BOOL GetAdaptersNumsAndNames()
{
char *name;
const char *desc;
ULONG NameLength=0;

	conf.iNumAdapters = 0;

	if(!PacketGetAdapterNames(NULL, &NameLength) && 0==NameLength)
	{	DWORD last_error = GetLastError();
		if(122 == last_error)
		{	goto NoNet;//MessageBoxW(NULL,L"Please,setup WINPCAP utility first...",L"Err...",MB_OK);
			return FALSE;
		}
		if(last_error != ERROR_INSUFFICIENT_BUFFER)
		{	StringCchPrintfA((char*)s,PCAP_ERRBUF_SIZE,"PacketGetAdapterNames: %s",pcap_win32strerror());
			MessageBoxA(NULL,(char*)s,"Err...",MB_OK);
			return FALSE;
	}	}
	if(NameLength > 0)
	{	if(conf.AdaptersName)
			conf.AdaptersName = (char*)realloc(conf.AdaptersName,NameLength);
		else
			conf.AdaptersName = (char*)malloc(NameLength);
	}
	else
	{NoNet:DialogBox(plgnDllInst,(LPCWSTR)IDD_DIALOG_ADAPTERS_FAILES,NULL,ShuttedDownAdaptersListFromRegistryDlgProc);
		return FALSE;
	}
	if(conf.AdaptersName == NULL)
	{	StringCchPrintfW(s, PCAP_ERRBUF_SIZE, strngs[90]);//L"Cannot allocate enough memory to list the adapters.");
		MessageBoxW(NULL,s,strngs[53]/*L"Err..."*/,MB_OK);
		return FALSE;
	}			
	if(!PacketGetAdapterNames((PTSTR)conf.AdaptersName, &NameLength))
	{	StringCchPrintf(s, PCAP_ERRBUF_SIZE, L"PacketGetAdapterNames: %s", pcap_win32strerror());
		MessageBox(NULL,s,strngs[53],MB_OK);//"Err..."
		free(conf.AdaptersName);
		conf.iNumAdapters = 0;
		return FALSE;
	}
	desc = &conf.AdaptersName[0];
	while(*desc != '\0' || *(desc + 1) != '\0')
		desc++;	
	desc += 2;	
	name = &conf.AdaptersName[0];
	while (*name != '\0')
	{	name += strlen(name) + 1;
		desc += strlen(desc) + 1;
		++conf.iNumAdapters;
	}
	return TRUE; 
}

/*BOOL CheckNTDriverConsistency(wchar_t *drvNameW)
{
char drvName[MAX_PATH],SymbolicLinkA[MAX_PATH];HANDLE hDrv;

//hDrv=CreateFileA("c:\\windows\\system32\\drivers\\npfSino.sys",GENERIC_READ,0,NULL,OPEN_EXISTING,0,0);
//	if(INVALID_HANDLE_VALUE==hDrv)
//	{	return FALSE;
//	}
//	CloseHandle(hDrv);

	WideCharToMultiByte(CP_ACP,0,drvNameW,-1,drvName,wcslen(drvNameW)+2,NULL,NULL);

	if(LOWORD(GetVersion()) == 4)
		StringCchPrintfA(SymbolicLinkA, MAX_PATH, "\\\\.\\NPF_%s", drvName);
 	else
		StringCchPrintfA(SymbolicLinkA, MAX_PATH, "\\\\.\\Global\\NPF_%s", drvName);
	hDrv=CreateFileA(SymbolicLinkA,GENERIC_WRITE | GENERIC_READ,
						 0,NULL,OPEN_EXISTING,0,0);
	if(INVALID_HANDLE_VALUE==hDrv)
		return FALSE;
	CloseHandle(hDrv);
	return TRUE;
}*///+"\\.\Global\NPF_{E28D896F-9EA8-433A-9C10-66C97C19A921}"

INT_PTR CALLBACK ShuttedDownAdaptersListFromRegistryDlgProc(HWND hDlg,UINT message,WPARAM wParam,LPARAM lParam)
{
LONG i,Status,Result;HKEY AdapKey,LinkageKey,OneAdapKey;DWORD dwBufLen,RegType,RegKeySize;
RECT rc,rcPrnt;int width,height;char TAName[MAX_PATH],*TcpBindingsMultiString;
CHAR npfCompleteDriverPrefix[MAX_PATH] = "\\Device\\";
//BOOL NPF_SYS_notInstalled=FALSE;

	switch(message)
	{
	case WM_INITDIALOG:
		GetWindowRect(hDlg, &rc);GetWindowRect(GetDesktopWindow(),&rcPrnt);
		width = rc.right - rc.left;
		height = rc.bottom - rc.top;
		MoveWindow(hDlg, (rcPrnt.right-width)/2, (rcPrnt.bottom-height)/2, width, height, TRUE);






		Status = RegOpenKeyEx(HKEY_LOCAL_MACHINE,TEXT("SYSTEM\\CurrentControlSet\\Services\\Tcpip\\Linkage"),
							  0,KEY_READ,&LinkageKey);
		if(Status == ERROR_SUCCESS)
		{	Status=RegQueryValueExA(LinkageKey,"bind",NULL,&RegType,NULL,&RegKeySize);
			TcpBindingsMultiString = malloc(RegKeySize + 2);
			if(TcpBindingsMultiString == NULL)
			{	TRACE_PRINT("malloc failed allocating memory for the registry key, returning.");
				TRACE_EXIT("PacketGetAdaptersNPF");
				EndDialog(hDlg,0);
				return FALSE;
			}
			Status = RegQueryValueExA(LinkageKey,"bind",NULL,&RegType,(LPBYTE)TcpBindingsMultiString,&RegKeySize);
			RegCloseKey(LinkageKey);
			for(i = 0;;)
			{	if(TcpBindingsMultiString[i] == '\0')
					break;
				StringCchPrintfA(TAName,sizeof(TAName),"%s%s",npfCompleteDriverPrefix,TcpBindingsMultiString + i + strlen("\\Device\\"));
				i += (INT)strlen(&TcpBindingsMultiString[i]) + 1;
				TRACE_PRINT1("Successfully retrieved info for adapter %s, trying to add it to the global list...", TAName);
				SendMessageA(GetDlgItem(hDlg,IDC_COMBO_ADAPTERS),CB_INSERTSTRING,-1,(LPARAM)TAName);
			}
 			free(TcpBindingsMultiString);
		}




		Status=RegOpenKeyEx(HKEY_LOCAL_MACHINE,
						TEXT("SYSTEM\\CurrentControlSet\\Control\\Class\\{4D36E972-E325-11CE-BFC1-08002BE10318}"),
                        0,
                        KEY_READ,
                        &AdapKey);
		if(Status != ERROR_SUCCESS)
		{	//ODS("PacketGetAdapterNames: RegOpenKeyEx ( Class\{networkclassguid} ) Failed\n");
			return TRUE;
		}
		// Get the size to allocate for the original device names
		i = 0;
		while((Result=RegEnumKey(AdapKey,i++,s,PCAP_ERRBUF_SIZE))==ERROR_SUCCESS)
		{	Status=RegOpenKeyEx(AdapKey,s,0,KEY_READ,&OneAdapKey);
			if(Status != ERROR_SUCCESS)
				break;
			dwBufLen = PCAP_ERRBUF_SIZE;
			Status = RegQueryValueEx(OneAdapKey, TEXT("NetCfgInstanceId"),
									 NULL, NULL,(LPBYTE)s, &dwBufLen);
			if(Status != ERROR_SUCCESS)
				goto HalfBr;
			height = (int)SendMessage(GetDlgItem(hDlg,IDC_COMBO_ADAPTERS),CB_GETCOUNT,0,0);
			for(width=0; width<height; width++)
			{	SendMessageW(GetDlgItem(hDlg,IDC_COMBO_ADAPTERS),CB_GETLBTEXT,width,(LPARAM)TAName);
				if(wcsstr((wchar_t*)TAName,s))
				{	dwBufLen = PCAP_ERRBUF_SIZE;
					Status = RegQueryValueEx(OneAdapKey, TEXT("DriverDesc"),
											 NULL, NULL,(LPBYTE)s, &dwBufLen);
					if(Status == ERROR_SUCCESS)
					{	SendMessage(GetDlgItem(hDlg,IDC_COMBO_ADAPTERS),CB_DELETESTRING,width,0);
						SendMessageW(GetDlgItem(hDlg,IDC_COMBO_ADAPTERS),CB_INSERTSTRING,width,(LPARAM)s);
				}	}
				//if(!NPF_SYS_notInstalled)
				//{	if(!CheckNTDriverConsistency(s))
				//		NPF_SYS_notInstalled = TRUE;
			}	//}
HalfBr:		RegCloseKey(OneAdapKey);
		}// while enum reg key still find keys
		RegCloseKey(AdapKey);
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_ADAPTERS),CB_SETCURSEL,0,0);
		//if(NPF_SYS_notInstalled)
		//	SetDlgItemTextW(hDlg,IDC_STATIC1,L"WinPCap kernel driver(npfSino.sys) is not founded, please reinstall program!!!");
		SetWindowText(hDlg,strngs[53]);
		SetDlgItemText(hDlg,IDC_STATIC4,strngs[54]);
		SetDlgItemText(hDlg,IDC_STATIC3,strngs[55]);
		SetDlgItemText(hDlg,IDC_STATIC1,strngs[56]);
		SetDlgItemText(hDlg,IDC_STATIC2,strngs[57]);
		SetDlgItemText(hDlg,IDC_BUTTON_RESET,strngs[58]);
		SetDlgItemText(hDlg,IDOK,strngs[12]);
		//MyButtonFrRCBtn(hDlg,IDC_BUTTON_RESET,0);
		//MyButtonFrRCBtn(hDlg,IDOK,0);
		return TRUE;
	case WM_COMMAND:
		switch(LOWORD(wParam))
		{	case IDCANCEL:
			case IDOK:
				EndDialog(hDlg,0);
				return (INT_PTR)TRUE;
			case IDC_BUTTON_RESET:
				if(GetModuleFileNameA(NULL,TAName,MAX_PATH))
				{	char *p = strrchr(TAName,'\\');
					if(p)
					{	PROCESS_INFORMATION pi;STARTUPINFOA si;ZeroMemory(&si,sizeof(si));si.cb=sizeof(si);						
						sprintf(p+1,"UninstallAux.exe");
						if(CreateProcessA(TAName,NULL,NULL,NULL,FALSE,0,NULL,NULL,&si,&pi))
						{	EndDialog(hDlg,0);
							return (INT_PTR)TRUE;
				}	}	}
				break;
		}	
		break;
	}
	return (INT_PTR)FALSE;
}

BOOL GetAdaptersAdresses()
{
int i,k;char *name,*desc;
npf_if_addr if_addrs[MAX_NETWORK_ADDRESSES],**pAdAddr;

	if(!conf.iNumAdapters)return FALSE;
	desc = &conf.AdaptersName[0];
	while(*desc != '\0' || *(desc + 1) != '\0')
		desc++;	
	desc += 2;	
	name = &conf.AdaptersName[0];

	pAdAddr = (npf_if_addr**)conf.pAdaptersIf_addrs;
	for(i=0; i<conf.iNumAdapters; ++i)
	{	LONG if_addr_size = MAX_NETWORK_ADDRESSES;
		if(!PacketGetNetInfoEx((void*)name, if_addrs, &if_addr_size))
		{	conf.pAdatersIPNums[i] = 0;
			return (0);
		}conf.pAdatersIPNums[i] = (char)if_addr_size;
		conf.pAdaptersIf_addrs[i] = (LPVOID*)malloc(if_addr_size*sizeof(npf_if_addr));
		for(k=0; k<if_addr_size; ++k)
		{	npf_if_addr *crntAddr = &pAdAddr[i][k];
			memcpy(&crntAddr->IPAddress,
				   &if_addrs[k].IPAddress,
				   sizeof(if_addrs[k].IPAddress));//sockaddr_storage));
			memcpy(&crntAddr->SubnetMask,
				   &if_addrs[k].SubnetMask,
				   sizeof(if_addrs[k].SubnetMask));//sockaddr_storage));
			memcpy(&crntAddr->Broadcast,
				   &if_addrs[k].Broadcast,
				   sizeof(if_addrs[k].Broadcast));//sockaddr_storage));
		}
		if(conf.iCrntAdapter==i)
		{	MyStringCpyA(conf.crntAdptrDesc,MAX_PATH,desc);
			MyStringCpyA(conf.crntAdptrName,MAX_PATH,name);
		}
		name += strlen(name) + 1;
		desc += strlen(desc) + 1;
	}

	if(!conf.ipFrom.b[0])if(!conf.ipFrom.b[1])if(!conf.ipFrom.b[2])if(!conf.ipFrom.b[3])
	{	IN_ADDR *pAddr;npf_if_addr crntAddr = pAdAddr[conf.iCrntAdapter][conf.iCrntAdapterIPAddress];
		pAddr = (IN_ADDR*)&crntAddr.IPAddress.__ss_pad1[2];
		conf.ipFrom.b[0] = pAddr->S_un.S_un_b.s_b1;
		conf.ipFrom.b[1] = pAddr->S_un.S_un_b.s_b2;
		conf.ipFrom.b[2] = 0;
		conf.ipFrom.b[3] = 1;
	}
	if(!conf.ipTo.b[0])if(!conf.ipTo.b[1])if(!conf.ipTo.b[2])if(!conf.ipTo.b[3])
	{	conf.ipTo.b[0] = conf.ipFrom.b[0];
		conf.ipTo.b[1] = conf.ipFrom.b[1];
		conf.ipTo.b[2] = 255;
		conf.ipTo.b[3] = 255;
	}
	return TRUE;
}