
#define NPF_IM_CALLCONV __cdecl

typedef struct TNPF_IM_DEVICE
{
	char Name[MAX_PATH];
	char Description[MAX_PATH];
} NPF_IM_DEVICE,*PNPF_IM_DEVICE;

typedef struct TNPF_IM_DEV_HANDLE
{
	HANDLE NpfImHandle;
} NPF_IM_DEV_HANDLE;