#pragma warning(disable:4005)
#pragma warning(disable:4995)
#pragma comment(lib,"Gdi32.lib")

#define _CRT_SECURE_NO_WARNINGS

#include "Packet\Packet32.h"
#include "windows.h"
//#include "resource.h"
#include "stdio.h"
#include "strsafe.h"
#include "Plugins_C.h"
#include "..\..\..\Operations\MyShell\MyShellC.h"


extern BOOL Packet32_DLL_PROCESS_ATTACH(HANDLE);
extern VOID Packet32_DLL_PROCESS_DETACH();


#define MAX_STRINGS 105

wchar_t **strngs=NULL;
HMODULE plgnDllInst;
BOOL bLoadNT;
HICON hIconUnknown,hIconNotAccess;//,hIconFastFile;
LPVOID pResultsLBtoPanelBuf=NULL;

LPVOID *plgList = NULL;
int		iPlgList = 0;

extern VOID FreeConfig();
extern BOOL GetAdaptersAdresses();
extern BOOL GetAdaptersNumsAndNames();
//extern BOOL LoadPCAPLib();
extern BOOL ReadOptions();
extern BOOL SaveOptions();
extern BOOL SetDefaultOptions();

BOOL APIENTRY DllMain(HMODULE hModule,DWORD ul_reason_for_call,LPVOID lpReserved)
{
FILE *f;
int i,l;
wchar_t *pend;
WSADATA wsaData;
wchar_t dllname[260],mnuStr[64];

	switch(ul_reason_for_call)
	{	case DLL_PROCESS_ATTACH:
			plgnDllInst=hModule;
			if(strngs)break;
			WSAStartup(MAKEWORD(2, 2),&wsaData);
			strngs = (wchar_t**)malloc(MAX_STRINGS*sizeof(wchar_t*));//strngs = (wchar_t **)malloc(MAX_STRINGS*sizeof(wchar_t*));
			GetModuleFileNameW(hModule,dllname,260);
			bLoadNT = LoadNTFuncs();
			if(!bLoadNT)
				MessageBox(NULL,strngs[2],strngs[53]/*L"Error..."*/,MB_OK);
			//if(!IphlpapiLib())
			//	MessageBox(NULL,strngs[2],strngs[53]/*L"Error..."*/,MB_OK);

			conf.iScanMethod[0] = 0; conf.iScanMethod[1] = 0;
			conf.iCrntAdapter = conf.iCrntAdapterIPAddress = conf.iIPListCnt = 0;
			conf.IPList = NULL;conf.bFasterIcon = true;

			pend = wcsrchr(dllname,'\\');
			if(pend){*pend++='\\';*pend=0;}

			if(GetEnvironmentVariable(L"languge",mnuStr,64))//Language instartup qo'yadur;
			{	if(!wcscmp(mnuStr,L"russian"))
					wcscat(dllname,L"PlugISStrsRus.txt");
				else if(!wcscmp(mnuStr,L"uzbekl"))
					wcscat(dllname,L"PlugISStrsUZBL.txt");
				else if(!wcscmp(mnuStr,L"uzbekk"))
					wcscat(dllname,L"PlugISStrsUZBK.txt");
				else//if(wcscmp(mnuStr,L"Exit")
					wcscat(dllname,L"PlugISStrsEng.txt");
			}	
			else wcscat(dllname,L"PlugISStrsEng.txt");

			f=_wfopen(dllname,L"r,ccs=UNICODE");
			if(f)
			{	wchar_t s[260];fwscanf(f,L"%s", s);
				if(wcscmp(s,L"Plugin")) goto NillStr;
				fwscanf(f,L"%s", s);
				if(wcscmp(s,L"IP_Scan.dll")) goto NillStr;
				fwscanf(f,L"%s", s);
				if(wcscmp(s,L"Strings:")) goto NillStr;
				for(i=0; i<MAX_STRINGS; i++)
				{	int t;fwscanf_s(f,L"%d", &t);
					if(t-1!=i) goto NillStr;
					//l=fscanf(f,"%s", s);
					l=fscanLineString(f,256,s);
					strngs[i]=(wchar_t*)malloc(sizeof(wchar_t)*(l+1));//strngs[i]=(wchar_t*)malloc(sizeof(wchar_t)*(l+1));
					memcpy(strngs[i],s,sizeof(wchar_t)*(l+1));
				}
				fclose(f);
			}
			else
			{int l;
NillStr:
				l=(int)wcslen(L"Sino IP_Scan plugin,ver.1.0. fr.Erkin Sattorov.Karaulbazar-2013.")+1;
					strngs[0]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[0],l,L"IP_Scan plugin,ver.1.0. fr.Erkin Sattorov.Karaulbazar-2013.");
				l=(int)wcslen(L"AdptrIP4Scan")+1;
					strngs[1]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[1],l,L"AdptrIP4Scan");
				l=(int)wcslen(L"Find files:")+1;
					strngs[2]=(wchar_t*)malloc(2*l);wcscpy(strngs[2],L"Find files:");
				l=(int)wcslen(L"Filter:")+1;
					strngs[3]=(wchar_t*)malloc(2*l);wcscpy(strngs[3],L"Filter:");
				l=(int)wcslen(L"Storage disks:")+1;
					strngs[4]=(wchar_t*)malloc(2*l);wcscpy(strngs[4],L"Storage disks:");
				l=(int)wcslen(L"Root path:")+1;
					strngs[5]=(wchar_t*)malloc(2*l);wcscpy(strngs[5],L"Root path:");
				l=(int)wcslen(L"Add")+1;
					strngs[6]=(wchar_t*)malloc(2*l);wcscpy(strngs[6],L"Add");
				l=(int)wcslen(L"Find for text(separate-';'):")+1;
					strngs[7]=(wchar_t*)malloc(2*l);wcscpy(strngs[7],L"Find for text(separate-';'):");
				l=(int)wcslen(L"1-byte")+1;
					strngs[8]=(wchar_t*)malloc(2*l);wcscpy(strngs[8],L"1-byte");
				l=(int)wcslen(L"Upper key sensivity")+1;
					strngs[9]=(wchar_t*)malloc(2*l);wcscpy(strngs[9],L"Upper key sensivity");
				l=(int)wcslen(L"Find for not contain text(separate-';'):")+1;
					strngs[10]=(wchar_t*)malloc(2*l);wcscpy(strngs[10],L"Find for not contain text(separate-';'):");
				l=(int)wcslen(L"Start")+1;
					strngs[11]=(wchar_t*)malloc(2*l);wcscpy(strngs[11],L"Start");
				l=(int)wcslen(L"OK")+1;
					strngs[12]=(wchar_t*)malloc(2*l);wcscpy(strngs[12],L"OK");
				l=(int)wcslen(L"Cancel")+1;
					strngs[13]=(wchar_t*)malloc(2*l);wcscpy(strngs[13],L"Cancel");
				l=(int)wcslen(L"Find for alternative name:")+1;
					strngs[14]=(wchar_t*)malloc(2*l);wcscpy(strngs[14],L"Find for alternative name:");
				l=(int)wcslen(L"Creation date and time before:")+1;
					strngs[15]=(wchar_t*)malloc(2*l);wcscpy(strngs[15],L"Creation date and time before:");
				l=(int)wcslen(L"Creation date and time after:")+1;
					strngs[16]=(wchar_t*)malloc(2*l);wcscpy(strngs[16],L"Creation date and time after:");
				l=(int)wcslen(L"Creation date and time between:")+1;
					strngs[17]=(wchar_t*)malloc(2*l);wcscpy(strngs[17],L"Creation date and time between:");
				l=(int)wcslen(L"Last access date and time before:")+1;
					strngs[18]=(wchar_t*)malloc(2*l);wcscpy(strngs[18],L"Last access date and time before:");
				l=(int)wcslen(L"Last access date and time after:")+1;
					strngs[19]=(wchar_t*)malloc(2*l);wcscpy(strngs[19],L"Last access date and time after:");
				l=(int)wcslen(L"Last access date and time between:")+1;
					strngs[20]=(wchar_t*)malloc(2*l);wcscpy(strngs[20],L"Last access date and time between:");
				l=(int)wcslen(L"Last write date and time before:")+1;
					strngs[21]=(wchar_t*)malloc(2*l);wcscpy(strngs[21],L"Last write date and time before:");
				l=(int)wcslen(L"Last write date and time after:")+1;
					strngs[22]=(wchar_t*)malloc(2*l);wcscpy(strngs[22],L"Last write date and time after:");
				l=(int)wcslen(L"Last write date and time between:")+1;
					strngs[23]=(wchar_t*)malloc(2*l);wcscpy(strngs[23],L"Last write date and time between:");
				l=(int)wcslen(L"File size:")+1;
					strngs[24]=(wchar_t*)malloc(2*l);wcscpy(strngs[24],L"File size:");
				l=(int)wcslen(L"File attribute:")+1;
					strngs[25]=(wchar_t*)malloc(2*l);wcscpy(strngs[25],L"File attribute:");
				l=(int)wcslen(L"Archive")+1;
					strngs[26]=(wchar_t*)malloc(2*l);wcscpy(strngs[26],L"Archive");
				l=(int)wcslen(L"Compressed")+1;
					strngs[27]=(wchar_t*)malloc(2*l);wcscpy(strngs[27],L"Compressed");
				l=(int)wcslen(L"Device")+1;
					strngs[28]=(wchar_t*)malloc(2*l);wcscpy(strngs[28],L"Device");
				l=(int)wcslen(L"Directory")+1;
					strngs[29]=(wchar_t*)malloc(2*l);wcscpy(strngs[29],L"Directory");
				l=(int)wcslen(L"Encrypted")+1;
					strngs[30]=(wchar_t*)malloc(2*l);wcscpy(strngs[30],L"Encrypted");
				l=(int)wcslen(L"Hidden")+1;
					strngs[31]=(wchar_t*)malloc(2*l);wcscpy(strngs[31],L"Hidden");
				l=(int)wcslen(L"Normal")+1;
					strngs[32]=(wchar_t*)malloc(2*l);wcscpy(strngs[32],L"Normal");
				l=(int)wcslen(L"Not indexed")+1;
					strngs[33]=(wchar_t*)malloc(2*l);wcscpy(strngs[33],L"Not indexed");
				l=(int)wcslen(L"Offline")+1;
					strngs[34]=(wchar_t*)malloc(2*l);wcscpy(strngs[34],L"Offline");
				l=(int)wcslen(L"Read only")+1;
					strngs[35]=(wchar_t*)malloc(2*l);wcscpy(strngs[35],L"Read only");
				l=(int)wcslen(L"Reparse point")+1;
					strngs[36]=(wchar_t*)malloc(2*l);wcscpy(strngs[36],L"Reparse point");
				l=(int)wcslen(L"Sparse file")+1;
					strngs[37]=(wchar_t*)malloc(2*l);wcscpy(strngs[37],L"Sparse file");
				l=(int)wcslen(L"System")+1;
					strngs[38]=(wchar_t*)malloc(2*l);wcscpy(strngs[38],L"System");
				l=(int)wcslen(L"Temporary")+1;
					strngs[39]=(wchar_t*)malloc(2*l);wcscpy(strngs[39],L"Temporary");
				l=(int)wcslen(L"Virtual")+1;
					strngs[40]=(wchar_t*)malloc(2*l);wcscpy(strngs[40],L"Virtual");
				l=(int)wcslen(L"Enum subdirectories")+1;
					strngs[41]=(wchar_t*)malloc(2*l);wcscpy(strngs[41],L"Enum subdirectories");
				l=(int)wcslen(L"Common parameters:")+1;
					strngs[42]=(wchar_t*)malloc(2*l);wcscpy(strngs[42],L"Common parameters:");
				l=(int)wcslen(L"Size and time parameters:")+1;
					strngs[43]=(wchar_t*)malloc(2*l);wcscpy(strngs[43],L"Size and time parameters:");
				l=(int)wcslen(L"Binary")+1;
					strngs[44]=(wchar_t*)malloc(2*l);wcscpy(strngs[44],L"Binary");
				l=(int)wcslen(L"Stop")+1;
					strngs[45]=(wchar_t*)malloc(2*l);wcscpy(strngs[45],L"Stop");
				l=(int)wcslen(L"Select all")+1;
					strngs[46]=(wchar_t*)malloc(2*l);wcscpy(strngs[46],L"Select all");
				l=(int)wcslen(L"Select all fixed")+1;
					strngs[47]=(wchar_t*)malloc(2*l);wcscpy(strngs[47],L"Select all fixed");					
				l=(int)wcslen(L"Browse")+1;
					strngs[48]=(wchar_t*)malloc(2*l);wcscpy(strngs[48],L"Browse");					
				l=(int)wcslen(L"Edit")+1;
					strngs[49]=(wchar_t*)malloc(2*l);wcscpy(strngs[49],L"Edit");					
				l=(int)wcslen(L"View")+1;
					strngs[50]=(wchar_t*)malloc(2*l);wcscpy(strngs[50],L"View");
				l=(int)wcslen(L"To panel")+1;
					strngs[51]=(wchar_t*)malloc(2*l);wcscpy(strngs[51],L"To panel");
				l=(int)wcslen(L"Save results")+1;
					strngs[52]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[52],l,L"Save results");
				l=(int)wcslen(L"Error!!!")+1;
					strngs[53]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[53],l,L"Error!!!");
				l=(int)wcslen(L"List of network adapters from Windows registry:")+1;
					strngs[54]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[54],l,L"List of network adapters from Windows registry:");
				l=(int)wcslen(L"One of the followed errors occured:")+1;
					strngs[55]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[55],l,L"One of the followed errors occured:");
				l=(int)wcslen(L"1.Worked adapter is not founded, please wake any.")+1;
					strngs[56]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[56],l,L"1.Worked adapter is not founded, please wake any.");
				l=(int)wcslen(L"2.WinPCap kernel driver may by failed,if failed, please reinstall program.")+1;
					strngs[57]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[57],l,L"2.WinPCap kernel driver may by failed,if failed, please reinstall program.");
				l=(int)wcslen(L"Reset adapter driver(You must restart plugin after reset)")+1;
					strngs[58]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[58],l,L"Reset adapter driver(You must restart plugin after reset)");
				l=(int)wcslen(L"AdptrIP4Scan (internal Sino) plugin options:")+1;
					strngs[59]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[59],l,L"AdptrIP4Scan (internal Sino) plugin options:");
				l=(int)wcslen(L"Adapters:")+1;
					strngs[60]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[60],l,L"Adapters:");
				l=(int)wcslen(L"Adapters IP-addresses:")+1;
					strngs[61]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[61],l,L"Adapters IP-addresses:");
				l=(int)wcslen(L"Adapters subnet mask:")+1;
					strngs[62]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[62],l,L"Adapters subnet mask:");
				l=(int)wcslen(L"Adapters broadcast adresses:")+1;
					strngs[63]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[63],l,L"Adapters broadcast adresses:");
				l=(int)wcslen(L"Adapter gateway adresses:")+1;
					strngs[64]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[64],l,L"Adapter gateway adresses:");
				l=(int)wcslen(L"Scan method:")+1;
					strngs[65]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[65],l,L"Scan method:");
				l=(int)wcslen(L"Timeout in ms:")+1;
					strngs[66]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[66],l,L"Timeout in ms:");
				l=(int)wcslen(L"From IP-address:")+1;
					strngs[67]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[67],l,L"From IP-address:");
				l=(int)wcslen(L"To IP-address:")+1;
					strngs[68]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[68],l,L"To IP-address:");
				l=(int)wcslen(L"IP-select method:")+1;
					strngs[69]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[69],l,L"IP-select method:");
				l=(int)wcslen(L"Use predefined IP-list")+1;
					strngs[70]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[70],l,L"Use predefined IP-list");
				l=(int)wcslen(L"Use std.icon(faster)")+1;
					strngs[71]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[71],l,L"Use std.icon(faster)");
				l=(int)wcslen(L"Output:")+1;
					strngs[72]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[72],l,L"Output:");
				l=(int)wcslen(L"Speed/Accuracy")+1;
					strngs[73]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[73],l,L"Speed/Accuracy");
				l=(int)wcslen(L"Clear Windows-reg. (uninstall WinPCap)")+1;
					strngs[74]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[74],l,L"Clear Windows-reg. (uninstall WinPCap)");
				l=(int)wcslen(L"Err. allocating mem.")+1;
					strngs[75]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[75],l,L"Err. allocating mem.");
				l=(int)wcslen(L"For ListBox control")+1;
					strngs[76]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[76],l,L"For ListBox control");
				l=(int)wcslen(L"Please,use only digit symbols without space.")+1;
					strngs[77]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[77],l,L"Please,use only digit symbols without space.");
				l=(int)wcslen(L"Binary filtr string error:")+1;
					strngs[78]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[78],l,L"Binary filtr string error:");
				l=(int)wcslen(L"Please,input pair symbols without space.")+1;
					strngs[79]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[79],l,L"Please,input pair symbols without space.");
				l=(int)wcslen(L"Binary filtr string length error:")+1;
					strngs[80]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[80],l,L"Binary filtr string length error:");
				l=(int)wcslen(L"You can't reset in not root folder.")+1;
					strngs[81]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[81],l,L"You can't reset in not root folder.");
				l=(int)wcslen(L"Please,go to root folder")+1;
					strngs[82]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[82],l,L"Please,go to root folder");
				l=(int)wcslen(L"1.Find node with PING echo signal via port-...")+1;
					strngs[83]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[83],l,L"1.Find node with PING echo signal via port-...");
				l=(int)wcslen(L"2.Enum directory resources in founded node;")+1;
					strngs[84]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[84],l,L"2.Enum directory resources in founded node;");
				l=(int)wcslen(L"1.Use for name recognizing WINS-protocol(via port 137-NETBIOS;)")+1;
					strngs[85]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[85],l,L"1.Use for name recognizing WINS-protocol(via port 137-NETBIOS;)");
				l=(int)wcslen(L"1. SEND NAME RECOGNIZE REQUEST IN PACKETS")+1;
					strngs[86]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[86],l,L"1. SEND NAME RECOGNIZE REQUEST IN PACKETS");
				l=(int)wcslen(L"2. NOT SEND NAME RECOGNIZE REQUEST IN PACKETS")+1;
					strngs[87]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[87],l,L"2. NOT SEND NAME RECOGNIZE REQUEST IN PACKETS");
				l=(int)wcslen(L"1. DIRECT")+1;
					strngs[88]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[88],l,L"1. DIRECT");
				l=(int)wcslen(L"2. RANDOM")+1;
					strngs[89]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[89],l,L"2. RANDOM");
				l=(int)wcslen(L"Cannot allocate enough memory to list the adapters.")+1;
					strngs[90]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[90],l,L"Cannot allocate enough memory to list the adapters.");
				l=(int)wcslen(L"Scanning... %d sec. posted.")+1;
					strngs[91]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[91],l,L"Scanning... %d sec. posted.");
				l=(int)wcslen(L"WARN:...")+1;
					strngs[92]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[92],l,L"WARN:...");
				l=(int)wcslen(L"Are you want stop scanning...")+1;
					strngs[93]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[93],l,L"Are you want stop scanning...");
				l=(int)wcslen(L"Invalid IP list in config file...")+1;
					strngs[94]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[94],l,L"Invalid IP list in config file...");
				l=(int)wcslen(L"Quiting...")+1;
					strngs[95]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[95],l,L"Quiting...");
				l=(int)wcslen(L"Founded folders: %d, Founded files: %d, elapsed time: %d milliseconds.")+1;
					strngs[96]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[96],l,L"Founded folders: %d, Founded files: %d, elapsed time: %d milliseconds.");
				l=(int)wcslen(L"Iphlpapi.dll is not founded...")+1;
					strngs[97]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[97],l,L"Iphlpapi.dll is not founded...");
				l=(int)wcslen(L"Attach/Detach panel count mismatching.")+1;
					strngs[98]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[98],l,L"Attach/Detach panel count mismatching.");
				l=(int)wcslen(L"Err. creating thread...")+1;
					strngs[99]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[99],l,L"Err. creating thread...");
				l=(int)wcslen(L"Scanning for IP4...")+1;
					strngs[100]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[100],l,L"Scanning for IP4...");
				l=(int)wcslen(L"Scanning ...")+1;
					strngs[101]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[101],l,L"Scanning ...");
				l=(int)wcslen(L"Speed/Accuracy: %d ms.")+1;
					strngs[102]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[102],l,L"Speed/Accuracy: %d ms.");
				l=(int)wcslen(L"Scanning is progress...")+1;
					strngs[103]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[103],l,L"Scanning is progress...");
				l=(int)wcslen(L"Options")+1;
					strngs[104]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[104],l,L"Options");

				//l=(int)wcslen(L"")+1;
				//	strngs[]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[],l,L"");
			}
			if(!Packet32_DLL_PROCESS_ATTACH(hModule))
				return FALSE;
			if(!ReadOptions())
				SetDefaultOptions();
			hIconUnknown = GetPanelEntryIcon(NULL,0,25);
			hIconNotAccess = GetPanelEntryIcon(NULL,0,1);
			break;
		case DLL_THREAD_ATTACH:
			break;
		case DLL_THREAD_DETACH:
			break;
		case DLL_PROCESS_DETACH:
			if(!strngs)
			{	for(i=0; i<MAX_STRINGS; i++)
					free(strngs[i]);//free(strngs[i]);
				free(strngs);//free(strngs);
				FreeConfig();
				Packet32_DLL_PROCESS_DETACH();
				WSACleanup();
				DeleteObject(hIconUnknown);
				DeleteObject(hIconNotAccess);
				//DeleteObject(hIconFastFile);
				strngs=NULL;
			}
			if(pResultsLBtoPanelBuf)free(pResultsLBtoPanelBuf);
			pResultsLBtoPanelBuf=0;
			break;
	}
	return TRUE;
}

#define NODELISTHEAPINCCNT 15

BOOL addDomainNameToPlgList(PluginObj *plg,wchar_t *sDomain)
{
int n;

	if(!sDomain) return FALSE;
	if(!sDomain[0]) return FALSE;
	if(!plg->DomainNodes)
	{	plg->DomainNodesMaxCnt = NODELISTHEAPINCCNT;
		plg->DomainNodes = (tDomainNodes*)malloc(plg->IPNodesMaxCnt*sizeof(tIPNodes));
		StringCchPrintfW((STRSAFE_LPWSTR)plg->DomainNodes[0].NAME,32,sDomain);
		plg->DomainNodesCnt = 1;
		return TRUE;
	}
	//else
	for(n=0; n<plg->DomainNodesCnt; ++n)
	{	if(!_wcsicmp(plg->DomainNodes[n].NAME,sDomain))
			return FALSE;
	}

	//Eski spiskada yo'q ekan;
	if(plg->DomainNodesCnt >= plg->DomainNodesMaxCnt)
	{	plg->DomainNodesMaxCnt += NODELISTHEAPINCCNT;
		plg->DomainNodes = (tDomainNodes*)realloc(plg->DomainNodes,plg->DomainNodesMaxCnt*sizeof(tDomainNodes));
	}
	StringCchPrintfW(plg->DomainNodes[plg->DomainNodesCnt].NAME,32,sDomain);

	++plg->DomainNodesCnt;
	return TRUE;
}

BOOL addNodeToPlgList(PluginObj *plg,wchar_t *sName,wchar_t *sDomain,WIN32_FIND_DATA *fd,DWORD ip)
{
int n;wchar_t s[128],sOldName[32];BYTE ipSfl[4];

	//if(sName)
	//if(0==wcscmp(sName,L"EVFRAT"))
	//if(0xc0a86502==ip)
	//	Beep(0,0);

	Ip4Shufl((DWORD*)ipSfl, (BYTE*)&ip);
	if(sName && sDomain)
	{	wsprintf(s,L"%d.%d.%d.%d - %s {%s}",ipSfl[0],ipSfl[1],ipSfl[2],ipSfl[3],sName,sDomain);
		addDomainNameToPlgList(plg,sDomain);
	}
	else wsprintf(s,L"%d.%d.%d.%d",ipSfl[0],ipSfl[1],ipSfl[2],ipSfl[3]);
		
	if(!plg->IPNodes)
	{	plg->IPNodesMaxCnt = NODELISTHEAPINCCNT;
		plg->IPNodes = (tIPNodes*)malloc(plg->IPNodesMaxCnt*sizeof(tIPNodes));
		plg->IPNodes[0].IP = ip;
		plg->IPNodes[0].nodePtr = 0;
		if(sName) StringCchPrintfW(plg->IPNodes[0].NETBIOSNAME,32,sName);
		else plg->IPNodes[0].NETBIOSNAME[0] = 0;
		if(sDomain) StringCchPrintfW(plg->IPNodes[0].NETBIOSGROUPNAME,32,sDomain);
		else plg->IPNodes[0].NETBIOSGROUPNAME[0] = 0;
		addItemToPanelList(plg->host,s,NULL,fd,0xffffffff,TRUE);
		plg->IPNodesCnt = 1;
		return TRUE;
	}
	//else
	for(n=0; n<plg->IPNodesCnt; ++n)
	{	if(ip==plg->IPNodes[n].IP)
		{	if(sName) StringCchPrintfW(plg->IPNodes[n].NETBIOSNAME,32,sName);
			else plg->IPNodes[n].NETBIOSNAME[0] = 0;
			if(sDomain) StringCchPrintfW(plg->IPNodes[n].NETBIOSGROUPNAME,32,sDomain);
			else plg->IPNodes[n].NETBIOSGROUPNAME[0] = 0;
			if(sName && sDomain)
			{	wsprintf(sOldName,L"%d.%d.%d.%d",ipSfl[0],ipSfl[1],ipSfl[2],ipSfl[3]);
				changeItemInPanelList(plg->host,sOldName,s,TRUE);
			}
			return TRUE;
	}	}

	//Eski spiskada yo'q ekan;
	if(plg->IPNodesCnt >= plg->IPNodesMaxCnt)
	{	plg->IPNodesMaxCnt += NODELISTHEAPINCCNT;
		plg->IPNodes = (tIPNodes*)realloc(plg->IPNodes,plg->IPNodesMaxCnt*sizeof(tIPNodes));
	}
	addItemToPanelList(plg->host,s,NULL,fd,plg->IPNodesCnt,TRUE);
	plg->IPNodes[plg->IPNodesCnt].IP = ip;
	plg->IPNodes[plg->IPNodesCnt].nodePtr = plg->IPNodesCnt;
	if(sName) StringCchPrintfW(plg->IPNodes[plg->IPNodesCnt].NETBIOSNAME,32,sName);
	else plg->IPNodes[plg->IPNodesCnt].NETBIOSNAME[0] = 0;
	if(sDomain) StringCchPrintfW(plg->IPNodes[plg->IPNodesCnt].NETBIOSGROUPNAME,32,sDomain);
	else plg->IPNodes[plg->IPNodesCnt].NETBIOSGROUPNAME[0] = 0;

	++plg->IPNodesCnt;
	return TRUE;
}

int GetNodeFromPlgList(PluginObj *plg,DWORD dwIp)
{
int n;
	for(n=0; n<plg->IPNodesCnt; ++n)
	{	if(dwIp==plg->IPNodes[n].IP)
			return n;
	}
	return -1;
}

BOOL IsCrntOrPrntDirAttrb(wchar_t* fd)
{//see Naming Conventions in MSDN:
	if('.'==fd[0])
	{	if('\0'==fd[1])//"."
			return FALSE;
		if('.'==fd[1])
			if('\0'==fd[2])//".."
				return FALSE;
	}
	return TRUE;//Hozircha;
}