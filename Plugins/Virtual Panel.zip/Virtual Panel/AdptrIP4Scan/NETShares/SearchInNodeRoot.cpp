#include "shlobj.h"
#include "strsafe.h"
#include <malloc.h>
#include "..\..\..\Auxilary\SinoSearchF7\FindStrWthFltr.h"
#include "..\..\..\Auxilary\SinoSearchF7\SinSchF7.h"
#include "..\..\..\..\Operations\MyShell\ComboToDisk.h"
#include "..\..\..\..\Operations\MyShell\MyShell.h"
#include "..\Plugins_C.h"

VOID AddToInfoEdit(Search*,wchar_t*,WIN32_FIND_DATA&);
VOID AddToResultsLB(Search*,WIN32_FIND_DATA*,wchar_t*);
int  FindSelectsItemsNodeDir(Search*,wchar_t*,FindStrWthFltr*);

int FindSelectsItemsNodeRoot(Search *search,FindStrWthFltr *fs,DWORD dwIp)
{
	search->iCall++;
struct in_addr IpAddr;
int r=0,ipStrLen=2;
HANDLE hEnum;
DWORD ret,ToGet=100,ResBuf=ToGet*sizeof(NETRESOURCE),OpenResult;
WIN32_FIND_DATA fd={FILE_ATTRIBUTE_DIRECTORY};
NETRESOURCE NetContainer,*ResArr=NULL;
unsigned k;
wchar_t ipStr[32]=L"\\\\";	
char* FAR c;
	IpAddr.S_un.S_addr = dwIp;
	c = inet_ntoa(IpAddr);
	if(!c)
	{	search->iCall--;
		return -1;
	}

	ipStrLen += MultiByteToWideChar(CP_ACP,0,c,-1,&ipStr[2],(DWORD)(strlen(c)+2))-1;
	ResArr=(NETRESOURCE*)malloc(ResBuf);

	NetContainer.dwScope = RESOURCE_GLOBALNET; 
	NetContainer.dwType = RESOURCETYPE_ANY; 
	NetContainer.lpLocalName = NULL; 
	NetContainer.lpRemoteName = ipStr; 
	NetContainer.dwUsage = RESOURCEUSAGE_CONTAINER | RESOURCEUSAGE_CONNECTABLE; 
	NetContainer.lpProvider = NULL; 

	OpenResult = WNetOpenEnum(	RESOURCE_GLOBALNET,
								RESOURCETYPE_ANY,
								RESOURCEUSAGE_CONTAINER | RESOURCEUSAGE_CONNECTABLE,
								&NetContainer,
								&hEnum);
	if(OpenResult == NO_ERROR)
	{	ret = WNetEnumResource(hEnum, &ToGet, ResArr, &ResBuf);
		if(ERROR_NO_MORE_ITEMS==ret)
		{	ToGet = ResBuf/sizeof(NETRESOURCE);
			ResArr=(NETRESOURCE*)realloc(ResArr,ResBuf);
			ret = WNetEnumResource(hEnum, &ToGet, ResArr, &ResBuf);
		}
		if(NO_ERROR==ret && ToGet>0)//hidden sharelar uchun NetShareEnum shart
		{	char itemIP4strA[32];wchar_t *p;int i;
			WideCharToMultiByte(CP_ACP,0,ipStr,-1,itemIP4strA,ipStrLen+2,NULL,NULL);
			for(k=0; k<ToGet; k++)
			{	if(wcsstr(ResArr[k].lpRemoteName,ipStr))
				{	p = &ResArr[k].lpRemoteName[ipStrLen+1];
					for(i=0; i<ipStrLen && '\\'==(*p); ++i)++p;
				}
				else p = &ResArr[k].lpRemoteName[0];
				if((!fs) || fs->CheckNameAndExt(ResArr[k].lpRemoteName))
				{	AddToInfoEdit(search, &ResArr[k].lpRemoteName[2], fd);
					AddToResultsLB(search, &fd, &ResArr[k].lpRemoteName[2]);
				}
				if(item.bEnumSubDir)
					FindSelectsItemsNodeDir(search,&ResArr[k].lpRemoteName[2],fs);
				if(search->bStop)break;
				//static int k=0;
				//if(k++==4)
				{	MSG msg;if(PeekMessage(&msg, NULL, 0U, 0U, PM_REMOVE))
						DispatchMessage(&msg );
				//	k=0;
	}	}	}	}
	else r=-2;//Hech narsa demasun;
	free(ResArr);
	WNetCloseEnum(hEnum);
	search->iCall--;
	return r;
}