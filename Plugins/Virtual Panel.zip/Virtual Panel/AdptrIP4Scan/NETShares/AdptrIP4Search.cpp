#pragma comment(lib,"shell32.lib")

#include "shlobj.h"
#include "strsafe.h"
#include <malloc.h>
#include "..\..\..\Auxilary\SinoSearchF7\FindStrWthFltr.h"
#include "..\..\..\Auxilary\SinoSearchF7\SinSchF7.h"
#include "..\..\..\..\Operations\MyShell\ComboToDisk.h"
#include "..\..\..\..\Operations\MyShell\MyShell.h"
//#include "..\..\..\..\Operations\MyShell\MyButtonC++.h"
#include "..\Plugins.h"


wchar_t initPath[MAX_PATH];
CBToDisk selV7PthCB,selV7NameCB,selV7ExclTxt,selV7TxtCB;
/*BOOL bFindDlgFirstCreatedToResizeChld=FALSE;
int width,height,minWidth=580,minHeight=486,minHeightAftCrLB=638;
HWND hViewBTN=NULL,hEditBTN=NULL,hBrowseBTN=NULL,hToPanelBTN=NULL,hResultsLB=NULL,hInfoEdit=NULL;
TSearch search;*/
TSearchItem item;

INT_PTR CALLBACK FindFileDlgProc(HWND,UINT,WPARAM,LPARAM);
BOOL BeginSearch(LPVOID,Search*);
int  FindSelectsItemsNodeRoot(Search*,FindStrWthFltr*,DWORD);
int  FindSelectsItemsNodeDir(Search*,wchar_t*,FindStrWthFltr*);

//ret value:
//0 - no change, no action in panel space;
//1 - goto first path and selects items in panel;All items in one path;Scanner shouldnt detached;
//2 - clear panel and add random items listed in buffer;All items in the own path;Scanner should be detached;
//buffer - dll allocated memory space. Dll module will destroy the memory in the process detaching time.
// Buffer signature for ending strings is doubled NULL char, length of the buufer in bufferLen.
extern "C" {
extern LPVOID pResultsLBtoPanelBuf;
__declspec(dllexport) int ShowSearchDlg$20(HWND prnt,LPVOID plgObj,wchar_t *path,LPVOID *buffer,DWORD *bufferLen)
{
#ifdef _WIN64
HMODULE hm = LoadLibrary(L"MyShell64.dll");
#else
HMODULE hm = LoadLibrary(L"MyShell.dll");
#endif
	MyStringCpy(initPath,MAX_PATH-1,path);
	int r = (int)DialogBoxParam(hm,MAKEINTRESOURCE(IDD_DIALOG_SEACH_VIA_F7),prnt,FindFileDlgProc,(LPARAM)plgObj);
	if(r<1)
	{	*buffer = 0;
		*bufferLen = 0;
		return 0;
	}
	//else
	*buffer=pResultsLBtoPanelBuf;
	return r;
}

__declspec (dllexport) VOID SetId$4(int id)
{
	plgId = id;
	readOptions(id,&item,sizeof(item));
}

}//extern "C"

INT_PTR CALLBACK FindFileDlgProc(HWND hDlg,UINT message,WPARAM wParam,LPARAM lParam)
{
//static HFONT hf=0;
//static int hfRef=0;//obshiy hf, dinamik uchun emas:
//static HBRUSH br=0;
//static HBRUSH brHtBk=0;
wchar_t s[MAX_PATH];
//static int endDialogCodeToWM_DESTROY;

	LONG plg = (LONG)GetWindowLongPtr(hDlg,GWLP_USERDATA);//GetWindowLong(hDlg,GWL_USERDATA);
	Search *search = plg ? (Search*)((PluginObj*)plg)->search : 0;

	//UNREFERENCED_PARAMETER(lParam);
	switch(message)
	{
	case WM_SIZING:RECT *rc;
		rc = (RECT*)lParam;
		if(rc->right-rc->left < search->minWidth)
			rc->right = rc->left + search->minWidth;
		if(search->hResultsLB)
		{	if(rc->bottom-rc->top < search->minHeightAftCrLB)
				rc->bottom = rc->top + search->minHeightAftCrLB;
		} else
		{	if(rc->bottom-rc->top < search->minHeight)
				rc->bottom = rc->top + search->minHeight;
			else if(rc->bottom-rc->top > search->minHeight)
				rc->bottom = rc->top + search->minHeight;
		}
		return 0;
	case WM_SIZE:
		ResizeChilds(search, LOWORD(lParam), HIWORD(lParam));
		return 0;
	case WM_INITDIALOG:RECT rc1;int left,top;
		search = (Search*)malloc(sizeof(Search));
		search->TSearch::TSearch();
		search->hDlg = hDlg;

		SetWindowLongPtr(hDlg,GWLP_USERDATA,lParam);//SetWindowLong(hDlg,GWL_USERDATA,lParam);//plg;
		((PluginObj*)lParam)->search = search;
		((PluginObj*)lParam)->schDlgOkBtn=GetDlgItem(hDlg,IDOK);//MyButtonGetHWND(MyButtonFrRCBtn(hDlg,IDOK,0));

		search->endDialogCodeToWM_DESTROY=0;
		//panel = (LPVOID)lParam;
		GetWindowRect(hDlg, &rc1);
		search->width = rc1.right - rc1.left;		
		left = (GetSystemMetrics(SM_CXFULLSCREEN) - search->width)/2;
		search->height = search->LBListBuf?(rc1.bottom - rc1.top):search->minHeight;
		top = (GetSystemMetrics(SM_CYFULLSCREEN) - search->height)/2;
		MoveWindow(hDlg, left, top+20, search->width, search->height, TRUE);

		//Load language strings:
		SetWindowText(hDlg,strngs[0]);
		//SetDlgItemText(hDlg,IDC_STATIC_SCH1,strngs[2]);
		//SetDlgItemText(hDlg,IDC_BUTTON_ADD_DISK,strngs[3]);
		SetDlgItemText(hDlg,IDC_STATIC_SCH2,strngs[5]);
		//SetDlgItemText(hDlg,IDC_BUTTON_ADD_PATH,strngs[6]);
		SetDlgItemText(hDlg,IDC_CHECK_TEXT_SEACH,strngs[7]);
		SetDlgItemText(hDlg,IDC_CHECK_UNICODE_OR_MULTIBYTE,strngs[8]);
		//strngs[42]
		SetDlgItemText(hDlg,IDC_CHECK_BINARY_OR_CHARACTER,L"ASCII");
		SetDlgItemText(hDlg,IDC_CHECK_REGISTR_CAPS,strngs[9]);
		SetDlgItemText(hDlg,IDC_CHECK_NO_TEXT_SEACH,strngs[10]);
		SetDlgItemText(hDlg,IDC_CHECK_UNICODE_OR_MULTIBYTE2,strngs[8]);
		//strngs[42]
		SetDlgItemText(hDlg,IDC_CHECK_BINARY_OR_CHARACTER2,L"ASCII");
		SetDlgItemText(hDlg,IDC_CHECK_REGISTR_CAPS2,strngs[8]);
		SetWindowText(((PluginObj*)GetWindowLongPtr(hDlg,GWLP_USERDATA))->schDlgOkBtn,strngs[11]);//GetWindowLong(hDlg,GWL_USERDATA))->schDlgOkBtn,strngs[11]);//SetDlgItemText(hDlg,IDOK,strngs[11]);

		//if(lParam)
			SetDlgItemText(hDlg,IDCANCEL,strngs[13]);
		//else ShowWindow(GetDlgItem(hDlg,IDCANCEL),SW_HIDE);
		SetDlgItemText(hDlg,IDC_CHECK_ALTERNATIVE_NAME,strngs[14]);
		SetDlgItemText(hDlg,IDC_CHECK_CREATE_TIME_BEFORE,strngs[15]);
		SetDlgItemText(hDlg,IDC_CHECK_CREATE_TIME_AFTER,strngs[16]);
		SetDlgItemText(hDlg,IDC_CHECK_CREATE_TIME_BETWEEN,strngs[17]);
		SetDlgItemText(hDlg,IDC_CHECK_LAST_ACCESS_TIME_BEFORE,strngs[18]);
		SetDlgItemText(hDlg,IDC_CHECK_LAST_ACCESS_TIME_AFTER,strngs[19]);
		SetDlgItemText(hDlg,IDC_CHECK_LAST_ACCESS_TIME_BETWEEN,strngs[20]);
		SetDlgItemText(hDlg,IDC_CHECK_LAST_WRITE_TIME_BEFORE,strngs[21]);
		SetDlgItemText(hDlg,IDC_CHECK_LAST_WRITE_TIME_AFTER ,strngs[22]);
		SetDlgItemText(hDlg,IDC_CHECK_LAST_WRITE_TIME_BETWEEN ,strngs[23]);
		SetDlgItemText(hDlg,IDC_CHECK_FILE_SIZE,strngs[24]);
		SetDlgItemText(hDlg,IDC_CHECK_FILE_ATTRIBUTE,strngs[25]);
		SetDlgItemText(hDlg,IDC_CHECK_ATTRIBUTE_ARCHIVE,strngs[26]);
		SetDlgItemText(hDlg,IDC_CHECK_ATTRIBUTE_COMPRESSED,strngs[27]);
		SetDlgItemText(hDlg,IDC_CHECK_ATTRIBUTE_DEVICE,strngs[28]);
		SetDlgItemText(hDlg,IDC_CHECK_ATTRIBUTE_DIRECTORY,strngs[29]);
		SetDlgItemText(hDlg,IDC_CHECK_ATTRIBUTE_ENCRYPTED,strngs[30]);
		SetDlgItemText(hDlg,IDC_CHECK_ATTRIBUTE_HIDDEN,strngs[31]);
		SetDlgItemText(hDlg,IDC_CHECK_ATTRIBUTE_NORMAL,strngs[32]);
		SetDlgItemText(hDlg,IDC_CHECK_ATTRIBUTE_NOT_INDEXED,strngs[33]);
		SetDlgItemText(hDlg,IDC_CHECK_ATTRIBUTE_OFFLINE,strngs[34]);
		SetDlgItemText(hDlg,IDC_CHECK_ATTRIBUTE_READ_ONLY,strngs[35]);
		SetDlgItemText(hDlg,IDC_CHECK_ATTRIBUTE_REPARSE_POINT,strngs[36]);
		SetDlgItemText(hDlg,IDC_CHECK_ATTRIBUTE_SPARSE_FILE,strngs[37]);
		SetDlgItemText(hDlg,IDC_CHECK_ATTRIBUTE_SYSTEM,strngs[38]);
		SetDlgItemText(hDlg,IDC_CHECK_ATTRIBUTE_TEMPORARY,strngs[39]);
		SetDlgItemText(hDlg,IDC_CHECK_ATTRIBUTE_VIRTUAL,strngs[40]);
		SetDlgItemText(hDlg,IDC_CHECK_ENUM_SUBDIR,strngs[41]);
		SetDlgItemText(hDlg,IDC_CHECK_SAVE_RESULTS,strngs[52]);

		UpItem(hDlg,IDC_CHECK_ALTERNATIVE_NAME,462);
		UpItem(hDlg,IDC_EDIT_ALTERNATIVE_FILE_NAME,462);
		UpItem(hDlg,IDC_CHECK_CREATE_TIME_BEFORE,462);
		UpItem(hDlg,IDC_CHECK_CREATE_TIME_AFTER,462);
		UpItem(hDlg,IDC_EDIT_CREATE_DATE,462);
		UpItem(hDlg,IDC_EDIT_CREATE_DATE2,462);
		UpItem(hDlg,IDC_EDIT_CREATE_DATE_AFTER,462);
		UpItem(hDlg,IDC_EDIT_CREATE_DATE_AFTER2,462);
		UpItem(hDlg,IDC_CHECK_CREATE_TIME_BETWEEN,462);
		UpItem(hDlg,IDC_CHECK_LAST_ACCESS_TIME_BEFORE,462);
		UpItem(hDlg,IDC_CHECK_LAST_ACCESS_TIME_AFTER,462);
		UpItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE,462);
		UpItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE2,462);
		UpItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_AFTER,462);
		UpItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_AFTER2,462);
		UpItem(hDlg,IDC_CHECK_LAST_ACCESS_TIME_BETWEEN,462);
		UpItem(hDlg,IDC_CHECK_LAST_WRITE_TIME_BEFORE,462);
		UpItem(hDlg,IDC_CHECK_LAST_WRITE_TIME_AFTER,462);
		UpItem(hDlg,IDC_EDIT_LAST_WRITE_DATE,462);
		UpItem(hDlg,IDC_EDIT_LAST_WRITE_DATE2,462);
		UpItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_AFTER,462);
		UpItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_AFTER2,462);
		UpItem(hDlg,IDC_CHECK_LAST_WRITE_TIME_BETWEEN,462);
		UpItem(hDlg,IDC_CHECK_FILE_SIZE,462);
		UpItem(hDlg,IDC_COMBO_FILE_SIZE_EQUATION,462);
		UpItem(hDlg,IDC_EDIT_FILE_SIZE,462);
		UpItem(hDlg,IDC_SPIN_FILE_SIZE,462);
		UpItem(hDlg,IDC_COMBO_FILE_SIZE_QUANTITY,462);
		UpItem(hDlg,IDC_CHECK_FILE_ATTRIBUTE,462);
 		UpItem(hDlg,IDC_CHECK_ATTRIBUTE_ARCHIVE,462);
 		UpItem(hDlg,IDC_CHECK_ATTRIBUTE_ARCHIVE_EX,462);
 		UpItem(hDlg,IDC_CHECK_ATTRIBUTE_COMPRESSED,462);
 		UpItem(hDlg,IDC_CHECK_ATTRIBUTE_COMPRESSED_EX,462);
 		UpItem(hDlg,IDC_CHECK_ATTRIBUTE_DEVICE,462);
 		UpItem(hDlg,IDC_CHECK_ATTRIBUTE_DEVICE_EX,462);
 		UpItem(hDlg,IDC_CHECK_ATTRIBUTE_DIRECTORY,462);
 		UpItem(hDlg,IDC_CHECK_ATTRIBUTE_DIRECTORY_EX,462);
 		UpItem(hDlg,IDC_CHECK_ATTRIBUTE_ENCRYPTED,462);
 		UpItem(hDlg,IDC_CHECK_ATTRIBUTE_ENCRYPTED_EX,462);
 		UpItem(hDlg,IDC_CHECK_ATTRIBUTE_HIDDEN,462);
 		UpItem(hDlg,IDC_CHECK_ATTRIBUTE_HIDDEN_EX,462);
 		UpItem(hDlg,IDC_CHECK_ATTRIBUTE_NORMAL,462);
 		UpItem(hDlg,IDC_CHECK_ATTRIBUTE_NORMAL_EX,462);
 		UpItem(hDlg,IDC_CHECK_ATTRIBUTE_NOT_INDEXED,462);
 		UpItem(hDlg,IDC_CHECK_ATTRIBUTE_NOT_INDEXED_EX,462);
 		UpItem(hDlg,IDC_CHECK_ATTRIBUTE_OFFLINE,462);
 		UpItem(hDlg,IDC_CHECK_ATTRIBUTE_OFFLINE_EX,462);
 		UpItem(hDlg,IDC_CHECK_ATTRIBUTE_READ_ONLY,462);
 		UpItem(hDlg,IDC_CHECK_ATTRIBUTE_READ_ONLY_EX,462);
 		UpItem(hDlg,IDC_CHECK_ATTRIBUTE_REPARSE_POINT,462);
 		UpItem(hDlg,IDC_CHECK_ATTRIBUTE_REPARSE_POINT_EX,462);
 		UpItem(hDlg,IDC_CHECK_ATTRIBUTE_SPARSE_FILE,462);
 		UpItem(hDlg,IDC_CHECK_ATTRIBUTE_SPARSE_FILE_EX,462);
 		UpItem(hDlg,IDC_CHECK_ATTRIBUTE_SYSTEM,462);
 		UpItem(hDlg,IDC_CHECK_ATTRIBUTE_SYSTEM_EX,462);
 		UpItem(hDlg,IDC_CHECK_ATTRIBUTE_TEMPORARY,462);
 		UpItem(hDlg,IDC_CHECK_ATTRIBUTE_TEMPORARY_EX,462);
 		UpItem(hDlg,IDC_CHECK_ATTRIBUTE_VIRTUAL,462);
 		UpItem(hDlg,IDC_CHECK_ATTRIBUTE_VIRTUAL_EX,462);

 		UpItem(hDlg,IDC_EDIT_CREATE_BETWEEN_DATE,462);
 		UpItem(hDlg,IDC_EDIT_CREATE_BETWEEN_TIME,462);
 		UpItem(hDlg,IDC_EDIT_CREATE_BETWEEN_DATE2,462);
 		UpItem(hDlg,IDC_EDIT_CREATE_BETWEEN_TIME2,462);
		  
 		UpItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_BETWEEN,462);
 		UpItem(hDlg,IDC_EDIT_LAST_ACCESS_TIME_BETWEEN,462);
 		UpItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_BETWEEN2,462);
 		UpItem(hDlg,IDC_EDIT_LAST_ACCESS_TIME_BETWEEN2,462);

 		UpItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_BETWEEN,462);
 		UpItem(hDlg,IDC_EDIT_LAST_WRITE_TIME_BETWEEN,462);
 		UpItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_BETWEEN2,462);
 		UpItem(hDlg,IDC_EDIT_LAST_WRITE_TIME_BETWEEN2,462);

		UpItem(hDlg,IDC_SPIN_CRTBEF_DAY,462);
		UpItem(hDlg,IDC_SPIN_CRTBEF_MOONS,462);
		UpItem(hDlg,IDC_SPIN_CRTBEF_YEAR,462);
		UpItem(hDlg,IDC_SPIN_CRTBET_DAY,462);
		UpItem(hDlg,IDC_SPIN_CRTBET_MOONS,462);
		UpItem(hDlg,IDC_SPIN_CRTBET_YEAR,462);
		UpItem(hDlg,IDC_SPIN_LSTBEF_DAY,462);
		UpItem(hDlg,IDC_SPIN_LSTBEF_MOONS,462);
		UpItem(hDlg,IDC_SPIN_LSTBEF_YEAR,462);
		UpItem(hDlg,IDC_SPIN_LSTBET_DAY,462);
		UpItem(hDlg,IDC_SPIN_LSTBET_MOON,462);
		UpItem(hDlg,IDC_SPIN_LSTBET_YEAR,462);
		UpItem(hDlg,IDC_SPIN_LSWTBEF_DAY,462);
		UpItem(hDlg,IDC_SPIN_LSWTBEF_MOON,462);
		UpItem(hDlg,IDC_SPIN_LSWTBEF_YEAR,462);
		UpItem(hDlg,IDC_SPIN_LSWTBET_DAY,462);
		UpItem(hDlg,IDC_SPIN_LSWTBET_MOON,462);
		UpItem(hDlg,IDC_SPIN_LSWTBET_YEAR,462);
		UpItem(hDlg,IDC_SPIN_CRAFT_DAY,462);
		UpItem(hDlg,IDC_SPIN_CRAFT_MOON,462);
		UpItem(hDlg,IDC_SPIN_CRAFT_YEAR,462);
		UpItem(hDlg,IDC_SPIN_CRBET_DAY,462);
		UpItem(hDlg,IDC_SPIN_CRBET_MOON,462);
		UpItem(hDlg,IDC_SPIN_CRBET_YEAR,462);
		UpItem(hDlg,IDC_SPIN_LSAFT_DAY,462);
		UpItem(hDlg,IDC_SPIN_LSAFT_MOON,462);
		UpItem(hDlg,IDC_SPIN_LSAFT_YEAR,462);
		UpItem(hDlg,IDC_SPIN_LSABET_DAY,462);
		UpItem(hDlg,IDC_SPIN_LSABET_MOON,462);
		UpItem(hDlg,IDC_SPIN_LSABET_YEAR,462);
		UpItem(hDlg,IDC_SPIN_LSWRAFT_DAY,462);
		UpItem(hDlg,IDC_SPIN_LSWRAFT_MOON,462);
		UpItem(hDlg,IDC_SPIN_LSWRAFT_YEAR,462);
		UpItem(hDlg,IDC_SPIN_LSWRBET_DAY,462);
		UpItem(hDlg,IDC_SPIN_LSWRBET_MOON,462);
		UpItem(hDlg,IDC_SPIN_LSWRBET_YEAR,462);
		UpItem(hDlg,IDC_SPIN_CRTBEF_HOUR,462);
		UpItem(hDlg,IDC_SPIN_CRTBEF_MIN,462);
		UpItem(hDlg,IDC_SPIN_CRTBEF_SEC,462);
		UpItem(hDlg,IDC_SPIN_CRTBEF_MILS,462);
		UpItem(hDlg,IDC_SPIN_CRTBET_HOUR,462);
		UpItem(hDlg,IDC_SPIN_CRTBET_MIN,462);
		UpItem(hDlg,IDC_SPIN_CRTBET_SEC,462);
		UpItem(hDlg,IDC_SPIN_CRTBET_MILS,462);
		UpItem(hDlg,IDC_SPIN_LSTBEF_HOUR,462);
		UpItem(hDlg,IDC_SPIN_LSTBEF_MIN,462);
		UpItem(hDlg,IDC_SPIN_LSTBEF_SEC,462);
		UpItem(hDlg,IDC_SPIN_LSTBEF_MILS,462);
		UpItem(hDlg,IDC_SPIN_LSTBET_HOUR,462);
		UpItem(hDlg,IDC_SPIN_LSTBET_MIN,462);
		UpItem(hDlg,IDC_SPIN_LSTBET_SEC,462);
		UpItem(hDlg,IDC_SPIN_LSTBET_MILS,462);
		UpItem(hDlg,IDC_SPIN_LSWTBEF_HOUR,462);
		UpItem(hDlg,IDC_SPIN_LSWTBEF_MIN,462);
		UpItem(hDlg,IDC_SPIN_LSWTBEF_SEC,462);
		UpItem(hDlg,IDC_SPIN_LSWTBEF_MILS,462);
		UpItem(hDlg,IDC_SPIN_LSWTBET_HOUR,462);
		UpItem(hDlg,IDC_SPIN_LSWTBET_MIN,462);
		UpItem(hDlg,IDC_SPIN_LSWTBET_SEC,462);
		UpItem(hDlg,IDC_SPIN_LSWTBET_MILS,462);
		UpItem(hDlg,IDC_SPIN_CRAFT_HOUR,462);
		UpItem(hDlg,IDC_SPIN_CRAFT_MIN,462);
		UpItem(hDlg,IDC_SPIN_CRAFT_SEC,462);
		UpItem(hDlg,IDC_SPIN_CRAFT_MILS,462);
		UpItem(hDlg,IDC_SPIN_CRBET_HOUR,462);
		UpItem(hDlg,IDC_SPIN_CRBET_MIN,462);
		UpItem(hDlg,IDC_SPIN_CRBET_SEC,462);
		UpItem(hDlg,IDC_SPIN_CRBET_MILS,462);
		UpItem(hDlg,IDC_SPIN_LSAFT_HOUR,462);
		UpItem(hDlg,IDC_SPIN_LSAFT_MIN,462);
		UpItem(hDlg,IDC_SPIN_LSAFT_SEC,462);
		UpItem(hDlg,IDC_SPIN_LSAFT_MILS,462);
		UpItem(hDlg,IDC_SPIN_LSABET_HOUR,462);
		UpItem(hDlg,IDC_SPIN_LSABET_MIN,462);
		UpItem(hDlg,IDC_SPIN_LSABET_SEC,462);
		UpItem(hDlg,IDC_SPIN_LSABET_MILS,462);
		UpItem(hDlg,IDC_SPIN_LSWRAFT_HOUR,462);
		UpItem(hDlg,IDC_SPIN_LSWRAFT_MIN,462);
		UpItem(hDlg,IDC_SPIN_LSWRAFT_SEC,462);
		UpItem(hDlg,IDC_SPIN_LSWRAFT_MILS,462);
		UpItem(hDlg,IDC_SPIN_LSWRBET_HOUR,462);
		UpItem(hDlg,IDC_SPIN_LSWRBET_MIN,462);
		UpItem(hDlg,IDC_SPIN_LSWRBET_SEC,462);
		UpItem(hDlg,IDC_SPIN_LSWRBET_MILS,462);

		SetTabPage(hDlg, 0);

		SendMessage(GetDlgItem(hDlg,IDC_CHECK_TEXT_SEACH),BM_SETCHECK,item.bFindForText?BST_CHECKED:BST_UNCHECKED,0);
		EnableWindow(GetDlgItem(hDlg,IDC_COMBO_SEARCH_FOR_TEXT),item.bFindForText?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_CHECK_UNICODE_OR_MULTIBYTE),item.bFindForText?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_CHECK_BINARY_OR_CHARACTER),item.bFindForText?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_CHECK_REGISTR_CAPS),item.bFindForText?TRUE:FALSE);

		SendMessage(GetDlgItem(hDlg,IDC_CHECK_NO_TEXT_SEACH),BM_SETCHECK,item.bFindForExcldText?BST_CHECKED:BST_UNCHECKED,0);
		EnableWindow(GetDlgItem(hDlg,IDC_COMBO_SEARCH_NOT_TEXT),item.bFindForExcldText?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_CHECK_UNICODE_OR_MULTIBYTE2),item.bFindForExcldText?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_CHECK_BINARY_OR_CHARACTER2),item.bFindForExcldText?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_CHECK_REGISTR_CAPS2),item.bFindForExcldText?TRUE:FALSE);

		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ALTERNATIVE_NAME),BM_SETCHECK,item.altName[0]?BST_CHECKED:BST_UNCHECKED,0);
		EnableWindow(GetDlgItem(hDlg,IDC_EDIT_ALTERNATIVE_FILE_NAME),item.altName[0]?TRUE:FALSE);

		SendMessage(GetDlgItem(hDlg,IDC_CHECK_CREATE_TIME_BEFORE),BM_SETCHECK,item.bCrTimeBef?BST_CHECKED:BST_UNCHECKED,0);
		EnableWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_DATE),item.bCrTimeBef?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_DATE2),item.bCrTimeBef?TRUE:FALSE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_CREATE_TIME_AFTER),BM_SETCHECK,item.bCrTimeAft?BST_CHECKED:BST_UNCHECKED,0);
		EnableWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_DATE_AFTER),item.bCrTimeAft?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_DATE_AFTER2),item.bCrTimeAft?TRUE:FALSE);		
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_CREATE_TIME_BETWEEN),BM_SETCHECK,item.bCrTimeBet?BST_CHECKED:BST_UNCHECKED,0);
		EnableWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_BETWEEN_DATE),item.bCrTimeBet?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_BETWEEN_TIME),item.bCrTimeBet?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_BETWEEN_DATE2),item.bCrTimeBet?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_BETWEEN_TIME2),item.bCrTimeBet?TRUE:FALSE);

		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_DAY),item.bCrTimeBef?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_MOONS),item.bCrTimeBef?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_YEAR),item.bCrTimeBef?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_HOUR),item.bCrTimeBef?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_MIN),item.bCrTimeBef?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_SEC),item.bCrTimeBef?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_MILS),item.bCrTimeBef?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_DAY),item.bCrTimeBef?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_MOONS),item.bCrTimeBet?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_YEAR),item.bCrTimeBet?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_HOUR),item.bCrTimeBet?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_MIN),item.bCrTimeBet?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_SEC),item.bCrTimeBet?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_MILS),item.bCrTimeBet?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_DAY),item.bCrTimeBet?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_MOON),item.bCrTimeBet?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_YEAR),item.bCrTimeBet?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_HOUR),item.bCrTimeBet?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_MIN),item.bCrTimeBet?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_SEC),item.bCrTimeBet?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_MILS),item.bCrTimeBet?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_DAY),item.bCrTimeAft?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_MOON),item.bCrTimeAft?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_YEAR),item.bCrTimeAft?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_HOUR),item.bCrTimeAft?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_MIN),item.bCrTimeAft?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_SEC),item.bCrTimeAft?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_MILS),item.bCrTimeAft?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_DAY),item.bCrTimeBef?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_MOONS),item.bCrTimeBef?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_YEAR),item.bCrTimeBef?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_HOUR),item.bCrTimeBef?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_MIN),item.bCrTimeBef?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_SEC),item.bCrTimeBef?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_MILS),item.bCrTimeBef?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_DAY),item.bCrTimeBef?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_MOON),item.bCrTimeBet?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_YEAR),item.bCrTimeBet?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_HOUR),item.bCrTimeBet?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_MIN),item.bCrTimeBet?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_SEC),item.bCrTimeBet?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_MILS),item.bCrTimeBet?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_DAY),item.bCrTimeBet?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_MOON),item.bCrTimeBet?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_YEAR),item.bCrTimeBet?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_HOUR),item.bCrTimeBet?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_MIN),item.bCrTimeBet?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_SEC),item.bCrTimeBet?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_MILS),item.bCrTimeBet?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_FILE_SIZE),item.bFileSz?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_DAY),item.bLstAccTimeAft?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_MOON),item.bLstAccTimeAft?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_YEAR),item.bLstAccTimeAft?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_HOUR),item.bLstAccTimeAft?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_MIN),item.bLstAccTimeAft?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_SEC),item.bLstAccTimeAft?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_MILS),item.bLstAccTimeAft?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_DAY),item.bLstWrTimeBet?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_MOON),item.bLstWrTimeBet?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_YEAR),item.bLstWrTimeBet?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_HOUR),item.bLstWrTimeBet?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_MIN),item.bLstWrTimeBet?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_SEC),item.bLstWrTimeBet?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_MILS),item.bLstWrTimeBet?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_DAY),item.bLstWrTimeBet?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_MOON),item.bLstWrTimeBet?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_YEAR),item.bLstWrTimeBet?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_HOUR),item.bLstWrTimeBet?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_MIN),item.bLstWrTimeBet?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_SEC),item.bLstWrTimeBet?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_MILS),item.bLstWrTimeBet?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_DAY),item.bLstWrTimeBef?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_MOON),item.bLstWrTimeBef?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_YEAR),item.bLstWrTimeBef?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_HOUR),item.bLstWrTimeBef?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_MIN),item.bLstWrTimeBef?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_SEC),item.bLstWrTimeBef?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_MILS),item.bLstWrTimeBef?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_DAY),item.bLstWrTimeAft?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_MOON),item.bLstWrTimeAft?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_YEAR),item.bLstWrTimeAft?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_HOUR),item.bLstWrTimeAft?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_MIN),item.bLstWrTimeAft?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_SEC),item.bLstWrTimeAft?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_MILS),item.bLstWrTimeAft?TRUE:FALSE);
		  
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_ACCESS_TIME_BETWEEN),BM_SETCHECK,item.bLastAccTimeBet?BST_CHECKED:BST_UNCHECKED,0);
		EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_BETWEEN),item.bLastAccTimeBet?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_TIME_BETWEEN),item.bLastAccTimeBet?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_BETWEEN2),item.bLastAccTimeBet?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_TIME_BETWEEN2),item.bLastAccTimeBet?TRUE:FALSE);

		SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_WRITE_TIME_BETWEEN),BM_SETCHECK,item.bLstWrTimeBet?BST_CHECKED:BST_UNCHECKED,0);
		EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_BETWEEN),item.bLstWrTimeBet?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_TIME_BETWEEN),item.bLstWrTimeBet?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_BETWEEN2),item.bLstWrTimeBet?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_TIME_BETWEEN2),item.bLstWrTimeBet?TRUE:FALSE);

		SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_ACCESS_TIME_BEFORE),BM_SETCHECK,item.bLstAccTimeBef?BST_CHECKED:BST_UNCHECKED,0);
		EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE),item.bLstAccTimeBef?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE2),item.bLstAccTimeBef?TRUE:FALSE);
		 
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_ACCESS_TIME_AFTER),BM_SETCHECK,item.bLstAccTimeAft?BST_CHECKED:BST_UNCHECKED,0);
		EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_AFTER),item.bLstAccTimeAft?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_AFTER2),item.bLstAccTimeAft?TRUE:FALSE);
		 
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_WRITE_TIME_BEFORE),BM_SETCHECK,item.bLstWrTimeBef?BST_CHECKED:BST_UNCHECKED,0);
		EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE),item.bLstWrTimeBef?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE2),item.bLstWrTimeBef?TRUE:FALSE);
	
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_WRITE_TIME_AFTER),BM_SETCHECK,item.bLstWrTimeAft?BST_CHECKED:BST_UNCHECKED,0);
		EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_AFTER),item.bLstWrTimeAft?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_AFTER2),item.bLstWrTimeAft?TRUE:FALSE);
	
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_FILE_SIZE),BM_SETCHECK,item.bFileSz?BST_CHECKED:BST_UNCHECKED,0);
		EnableWindow(GetDlgItem(hDlg,IDC_COMBO_FILE_SIZE_EQUATION),item.bFileSz?TRUE:FALSE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_FILE_SIZE),BM_SETCHECK,item.bFileSz?BST_CHECKED:BST_UNCHECKED,0);
		EnableWindow(GetDlgItem(hDlg,IDC_EDIT_FILE_SIZE),item.bFileSz?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_COMBO_FILE_SIZE_QUANTITY),item.bFileSz?TRUE:FALSE);

		SendMessage(GetDlgItem(hDlg,IDC_CHECK_FILE_ATTRIBUTE),BM_SETCHECK,item.bFileAttr?BST_CHECKED:BST_UNCHECKED,0);
		
		EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_ARCHIVE),item.bFileAttr?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_ARCHIVE_EX),item.bFileAttArchive?TRUE:FALSE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_ARCHIVE),BM_SETCHECK,item.bFileAttArchive?BST_CHECKED:BST_UNCHECKED,0);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_ARCHIVE_EX),BM_SETCHECK,item.bFileAttArchiveEx?BST_CHECKED:BST_UNCHECKED,0);
		
		EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_COMPRESSED),item.bFileAttr?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_COMPRESSED_EX),item.bFileAttCompr?TRUE:FALSE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_COMPRESSED),BM_SETCHECK,item.bFileAttCompr?BST_CHECKED:BST_UNCHECKED,0);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_COMPRESSED_EX),BM_SETCHECK,item.bFileAttComprEx?BST_CHECKED:BST_UNCHECKED,0);

		EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_DEVICE),item.bFileAttr?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_DEVICE_EX),item.bFileAttDevice?TRUE:FALSE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_DEVICE),BM_SETCHECK,item.bFileAttDevice?BST_CHECKED:BST_UNCHECKED,0);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_DEVICE_EX),BM_SETCHECK,item.bFileAttDeviceEx?BST_CHECKED:BST_UNCHECKED,0);

		EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_DIRECTORY),item.bFileAttr?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_DIRECTORY_EX),item.bFileAttDir?TRUE:FALSE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_DIRECTORY),BM_SETCHECK,item.bFileAttDir?BST_CHECKED:BST_UNCHECKED,0);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_DIRECTORY_EX),BM_SETCHECK,item.bFileAttDirEx?BST_CHECKED:BST_UNCHECKED,0);

		EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_ENCRYPTED),item.bFileAttr?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_ENCRYPTED_EX),item.bFileAttEncr?TRUE:FALSE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_ENCRYPTED),BM_SETCHECK,item.bFileAttEncr?BST_CHECKED:BST_UNCHECKED,0);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_ENCRYPTED_EX),BM_SETCHECK,item.bFileAttEncrEx?BST_CHECKED:BST_UNCHECKED,0);

		EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_HIDDEN),item.bFileAttr?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_HIDDEN_EX),item.bFileAttHidden?TRUE:FALSE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_HIDDEN),BM_SETCHECK,item.bFileAttHidden?BST_CHECKED:BST_UNCHECKED,0);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_HIDDEN_EX),BM_SETCHECK,item.bFileAttHiddenEx?BST_CHECKED:BST_UNCHECKED,0);

		EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_NORMAL),item.bFileAttr?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_NORMAL_EX),item.bFileAttNormal?TRUE:FALSE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_NORMAL),BM_SETCHECK,item.bFileAttNormal?BST_CHECKED:BST_UNCHECKED,0);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_NORMAL_EX),BM_SETCHECK,item.bFileAttNormalEx?BST_CHECKED:BST_UNCHECKED,0);

		EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_NOT_INDEXED),item.bFileAttr?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_NOT_INDEXED_EX),item.bFileAttNotInd?TRUE:FALSE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_NOT_INDEXED),BM_SETCHECK,item.bFileAttNotInd?BST_CHECKED:BST_UNCHECKED,0);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_NOT_INDEXED_EX),BM_SETCHECK,item.bFileAttNotIndEx?BST_CHECKED:BST_UNCHECKED,0);

		EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_OFFLINE),item.bFileAttr?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_OFFLINE_EX),item.bFileAttOffl?TRUE:FALSE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_OFFLINE),BM_SETCHECK,item.bFileAttOffl?BST_CHECKED:BST_UNCHECKED,0);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_OFFLINE_EX),BM_SETCHECK,item.bFileAttOfflEx?BST_CHECKED:BST_UNCHECKED,0);

		EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_READ_ONLY),item.bFileAttr?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_READ_ONLY_EX),item.bFileAttReadOnly?TRUE:FALSE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_READ_ONLY),BM_SETCHECK,item.bFileAttReadOnly?BST_CHECKED:BST_UNCHECKED,0);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_READ_ONLY_EX),BM_SETCHECK,item.bFileAttReadOnlyEx?BST_CHECKED:BST_UNCHECKED,0);

		EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_REPARSE_POINT),item.bFileAttr?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_REPARSE_POINT_EX),item.bFileAttRepPt?TRUE:FALSE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_REPARSE_POINT),BM_SETCHECK,item.bFileAttRepPt?BST_CHECKED:BST_UNCHECKED,0);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_REPARSE_POINT_EX),BM_SETCHECK,item.bFileAttRepPtEx?BST_CHECKED:BST_UNCHECKED,0);

		EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_SPARSE_FILE),item.bFileAttr?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_SPARSE_FILE_EX),item.bFileAttSparseFile?TRUE:FALSE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_SPARSE_FILE),BM_SETCHECK,item.bFileAttSparseFile?BST_CHECKED:BST_UNCHECKED,0);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_SPARSE_FILE_EX),BM_SETCHECK,item.bFileAttSparseFileEx?BST_CHECKED:BST_UNCHECKED,0);

		EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_SYSTEM),item.bFileAttr?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_SYSTEM_EX),item.bFileAttSys?TRUE:FALSE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_SYSTEM),BM_SETCHECK,item.bFileAttSys?BST_CHECKED:BST_UNCHECKED,0);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_SYSTEM_EX),BM_SETCHECK,item.bFileAttSysEx?BST_CHECKED:BST_UNCHECKED,0);

		EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_TEMPORARY),item.bFileAttr?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_TEMPORARY_EX),item.bFileAttTemp?TRUE:FALSE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_TEMPORARY),BM_SETCHECK,item.bFileAttTemp?BST_CHECKED:BST_UNCHECKED,0);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_TEMPORARY_EX),BM_SETCHECK,item.bFileAttTempEx?BST_CHECKED:BST_UNCHECKED,0);

		EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_VIRTUAL),item.bFileAttr?TRUE:FALSE);
		EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_VIRTUAL_EX),item.bFileAttVirt?TRUE:FALSE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_VIRTUAL),BM_SETCHECK,item.bFileAttVirt?BST_CHECKED:BST_UNCHECKED,0);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_VIRTUAL_EX),BM_SETCHECK,item.bFileAttVirtEx?BST_CHECKED:BST_UNCHECKED,0);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_SAVE_RESULTS),BM_SETCHECK,item.bSaveResultsLB?BST_CHECKED:BST_UNCHECKED,0);
 
		TCITEMW tie;
		tie.mask = TCIF_TEXT;// | TCIF_IMAGE;
		tie.iImage = -1;
		tie.pszText = strngs[43];//"Size and time parameters:";
		TabCtrl_InsertItem(GetDlgItem(hDlg,IDC_TAB_FILE_SEACH),0, &tie);
		tie.pszText = strngs[42];//"Common parameters:";
		//TabCtrl_InsertItem(GetDlgItem(hDlg,IDC_TAB_FILE_SEACH),0, &tie);
		SendMessageW(GetDlgItem(hDlg,IDC_TAB_FILE_SEACH),TCM_INSERTITEM,0,(LPARAM)&tie);

		TabCtrl_SetCurSel(GetDlgItem(hDlg,IDC_TAB_FILE_SEACH),0);

		SendMessage(GetDlgItem(hDlg,IDC_COMBO_FILE_SIZE_EQUATION),CB_INSERTSTRING,(WPARAM)-1,(LPARAM)L"<");
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_FILE_SIZE_EQUATION),CB_INSERTSTRING,(WPARAM)-1,(LPARAM)L">");
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_FILE_SIZE_EQUATION),CB_INSERTSTRING,(WPARAM)-1,(LPARAM)L"==");
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_FILE_SIZE_EQUATION),CB_SETCURSEL,0,0);

		SendMessage(GetDlgItem(hDlg,IDC_COMBO_FILE_SIZE_QUANTITY),CB_INSERTSTRING,(WPARAM)-1,(LPARAM)L"byte");
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_FILE_SIZE_QUANTITY),CB_INSERTSTRING,(WPARAM)-1,(LPARAM)L"kb");
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_FILE_SIZE_QUANTITY),CB_INSERTSTRING,(WPARAM)-1,(LPARAM)L"mb");
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_FILE_SIZE_QUANTITY),CB_INSERTSTRING,(WPARAM)-1,(LPARAM)L"gb");
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_FILE_SIZE_QUANTITY),CB_SETCURSEL,0,0);

		SendMessage(GetDlgItem(hDlg,IDC_SPIN_FILE_SIZE),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_DAY),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_MOONS),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_YEAR),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_HOUR),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_MIN),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_SEC),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_MILS),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRTBET_DAY),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRTBET_MOONS),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRTBET_YEAR),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRTBET_HOUR),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRTBET_MIN),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRTBET_SEC),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRTBET_MILS),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRBET_DAY),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRBET_MOON),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRBET_YEAR),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRBET_HOUR),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRBET_MIN),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRBET_SEC),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRBET_MILS),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRAFT_DAY),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRAFT_MOON),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRAFT_YEAR),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRAFT_HOUR),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRAFT_MIN),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRAFT_SEC),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRAFT_MILS),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_DAY),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_MOONS),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_YEAR),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_HOUR),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_MIN),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_SEC),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_MILS),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_DAY),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_MOON),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_YEAR),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_HOUR),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_MIN),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_SEC),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_MILS),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_DAY),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_MOON),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_YEAR),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_HOUR),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_MIN),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_SEC),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_MILS),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSAFT_DAY),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSAFT_MOON),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSAFT_YEAR),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSAFT_HOUR),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSAFT_MIN),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSAFT_SEC),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSAFT_MILS),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSTBET_DAY),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSTBET_MOON),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSTBET_YEAR),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSTBET_HOUR),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSTBET_MIN),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSTBET_SEC),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSTBET_MILS),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSABET_DAY),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSABET_MOON),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSABET_YEAR),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSABET_HOUR),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSABET_MIN),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSABET_SEC),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSABET_MILS),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_DAY),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_MOON),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_YEAR),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_HOUR),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_MIN),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_SEC),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_MILS),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_DAY),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_MOON),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_YEAR),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_HOUR),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_MIN),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_SEC),UDM_SETRANGE32,0,100);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_MILS),UDM_SETRANGE32,0,100);

		SendMessage(GetDlgItem(hDlg,IDC_SPIN_FILE_SIZE),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_DAY),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_MOONS),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_YEAR),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_HOUR),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_MIN),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_SEC),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_MILS),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRTBET_DAY),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRTBET_MOONS),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRTBET_YEAR),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRTBET_HOUR),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRTBET_MIN),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRTBET_SEC),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRTBET_MILS),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRBET_DAY),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRBET_MOON),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRBET_YEAR),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRBET_HOUR),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRBET_MIN),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRBET_SEC),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRBET_MILS),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRAFT_DAY),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRAFT_MOON),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRAFT_YEAR),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRAFT_HOUR),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRAFT_MIN),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRAFT_SEC),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_CRAFT_MILS),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_DAY),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_MOONS),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_YEAR),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_HOUR),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_MIN),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_SEC),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_MILS),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_DAY),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_MOON),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_YEAR),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_HOUR),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_MIN),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_SEC),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_MILS),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_DAY),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_MOON),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_YEAR),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_HOUR),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_MIN),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_SEC),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_MILS),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSAFT_DAY),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSAFT_MOON),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSAFT_YEAR),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSAFT_HOUR),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSAFT_MIN),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSAFT_SEC),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSAFT_MILS),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSTBET_DAY),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSTBET_MOON),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSTBET_YEAR),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSTBET_HOUR),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSTBET_MIN),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSTBET_SEC),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSTBET_MILS),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSABET_DAY),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSABET_MOON),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSABET_YEAR),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSABET_HOUR),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSABET_MIN),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSABET_SEC),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSABET_MILS),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_DAY),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_MOON),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_YEAR),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_HOUR),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_MIN),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_SEC),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_MILS),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_DAY),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_MOON),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_YEAR),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_HOUR),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_MIN),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_SEC),UDM_SETPOS32,0,50);
		SendMessage(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_MILS),UDM_SETPOS32,0,50);

		LocTimeToEdit(hDlg, IDC_EDIT_CREATE_DATE, IDC_EDIT_CREATE_DATE2);
		LocTimeToEdit(hDlg, IDC_EDIT_CREATE_DATE_AFTER, IDC_EDIT_CREATE_DATE_AFTER2);
		LocTimeToEdit(hDlg, IDC_EDIT_CREATE_BETWEEN_DATE, IDC_EDIT_CREATE_BETWEEN_TIME);
		LocTimeToEdit(hDlg, IDC_EDIT_CREATE_BETWEEN_DATE2, IDC_EDIT_CREATE_BETWEEN_TIME2);
		LocTimeToEdit(hDlg, IDC_EDIT_LAST_ACCESS_DATE, IDC_EDIT_LAST_ACCESS_DATE2);
		LocTimeToEdit(hDlg, IDC_EDIT_LAST_ACCESS_DATE_AFTER, IDC_EDIT_LAST_ACCESS_DATE_AFTER2);
		LocTimeToEdit(hDlg, IDC_EDIT_LAST_ACCESS_DATE_BETWEEN, IDC_EDIT_LAST_ACCESS_TIME_BETWEEN);
		LocTimeToEdit(hDlg, IDC_EDIT_LAST_ACCESS_DATE_BETWEEN2, IDC_EDIT_LAST_ACCESS_TIME_BETWEEN2);
		LocTimeToEdit(hDlg, IDC_EDIT_LAST_WRITE_DATE, IDC_EDIT_LAST_WRITE_DATE2);
		LocTimeToEdit(hDlg, IDC_EDIT_LAST_WRITE_DATE_AFTER, IDC_EDIT_LAST_WRITE_DATE_AFTER2);
		LocTimeToEdit(hDlg, IDC_EDIT_LAST_WRITE_DATE_BETWEEN, IDC_EDIT_LAST_WRITE_TIME_BETWEEN);
		LocTimeToEdit(hDlg, IDC_EDIT_LAST_WRITE_DATE_BETWEEN2, IDC_EDIT_LAST_WRITE_TIME_BETWEEN2);
	
		//if(lParam)
		{	selV7PthCB.Read(selV7PthCBFName,GetDlgItem(hDlg,IDC_COMBO_SEARCH_PATH),25,MAX_PATH);
			selV7TxtCB.Read(selV7TxtCBFName,GetDlgItem(hDlg,IDC_COMBO_SEARCH_FOR_TEXT),25,MAX_PATH);
			selV7ExclTxt.Read(selV7ExclTxtFName,GetDlgItem(hDlg,IDC_COMBO_SEARCH_NOT_TEXT),25,MAX_PATH);

			MyStringCpy(s,MAX_PATH,initPath);
			MyStringRemoveLastChar(s,MAX_PATH,'*');
			MyStringCat(s,MAX_PATH,L";");
			SetDlgItemText(hDlg,IDC_COMBO_SEARCH_PATH,s);
			selV7PthCB.AddToCB(GetDlgItem(hDlg,IDC_COMBO_SEARCH_PATH),s);

			SetDlgItemText(hDlg,IDC_EDIT_FILE_SIZE,L"1");
			if(!selV7NameCB.Read(selV7NameCBFName,
								 GetDlgItem(hDlg,IDC_COMBO_SEARCH_NAME),
								 MAX_SAVE_SELECTION_STR,
								 MAX_SEL_PATH))//fSeachViaF7.FillSearchFilterCB(hDlg,IDC_COMBO_SEARCH_NAME);
				SetDlgItemText(hDlg,IDC_COMBO_SEARCH_NAME,L"*.*;");
		}
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_SEARCH_NAME),CB_SETEDITSEL,0,MAKELPARAM(0,-1));
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ENUM_SUBDIR),BM_SETCHECK,
					item.bEnumSubDir?BST_CHECKED:BST_UNCHECKED,0);
		COMBOBOXINFO ci; ci.cbSize = sizeof(COMBOBOXINFO);
		if(SendMessage(GetDlgItem(hDlg,IDC_COMBO_SEARCH_NAME),CB_GETCOMBOBOXINFO,0,(LPARAM)&ci))
			SetFocus(ci.hwndItem);
		PostMessage(hDlg,WM_NEXTDLGCTL,IDC_COMBO_SEARCH_NAME,MAKELONG(0,TRUE));

		search->iCall = 0;
		search->bStop = TRUE;
		search->bRun = FALSE;
		SendMessage(hDlg,WM_USER+1,0,0);

		if(search->LBListBuf)
		{	CreateResultsLB(search);
			if(item.bSaveResultsLB)
				search->LoadLBList(search->hResultsLB);
			CreateOutptBtns(search);
		}
		ShowWindow(GetDlgItem(hDlg,IDC_STATIC_SCH),SW_HIDE);
		ShowWindow(GetDlgItem(hDlg,IDC_COMBO_METHOD),SW_HIDE);		
		ShowWindow(GetDlgItem(hDlg,IDC_BUTTON_ADD_DISK),SW_HIDE);
		ShowWindow(GetDlgItem(hDlg,IDC_BUTTON_ADD_PATH),SW_HIDE);

		//MyButtonFrRCBtn(hDlg,IDCANCEL,0);
		//MyButtonFrRCBtn(hDlg,IDC_BUTTON_ADD_PATH,0);
		//MyButtonFrRCBtn(hDlg,IDC_BUTTON_ADD_DISK,0);

		return TRUE;
/*	case WM_CTLCOLORSTATIC:
	case WM_CTLCOLORLISTBOX:
	case WM_CTLCOLORSCROLLBAR:
	case WM_CTLCOLORDLG:
		HDC dc;dc = (HDC)wParam;
		SetTextColor(dc,RGB(0x20,0x20,0x00));//conf::Dlg.dlgRGBs[6][1]);
		SetBkColor(dc,RGB(224,231,241));//0xec,0xe1,0xec));//conf::Dlg.dlgRGBs[6][2]);
		return (INT_PTR)br;
	case WM_CTLCOLOREDIT:dc = (HDC)wParam;
		SetTextColor(dc,RGB(0x20,0x20,0));//conf::Dlg.dlgRGBs[6][1]);
		SetBkColor(dc,RGB(224,231,241));//conf::Dlg.dlgRGBs[6][2]);
		return (INT_PTR)br;
	case WM_CTLCOLORBTN:dc=(HDC)wParam;
		SetTextColor(dc,RGB(0x20,0x20,0x00));//conf::Dlg.dlgRGBs[6][1]);
		SetBkColor(dc,RGB(224,231,241));//0xee,0xae,0xd7));//conf::Dlg.dlgRGBs[6][2]);
		return (INT_PTR)brHtBk;
	case WM_DRAWITEM://WM_CTLCOLORBTN dagi knopkalar:
		LPDRAWITEMSTRUCT lpdis;lpdis = (LPDRAWITEMSTRUCT)lParam;
		GetWindowText(lpdis->hwndItem,s,64);
		RECT r;UINT uStyle;uStyle = DFCS_BUTTONPUSH;
		r = lpdis->rcItem;
		if(lpdis->itemState & ODS_SELECTED)
		{	uStyle |= DFCS_PUSHED|DFCS_TRANSPARENT;
			r.left+=2;r.top+=2;
		}
		DrawFrameControl(lpdis->hDC, &lpdis->rcItem, DFC_BUTTON, uStyle);
		if(lpdis->itemState & ODS_SELECTED)
			{r.left+=1;r.top+=1;r.bottom-=2;r.right-=3;}
		else
			{r.left+=1;r.top+=2;r.bottom-=3;r.right-=3;}
		FillRect(lpdis->hDC,&r,brHtBk);//DrawText(lpdis->hDC,"                                                  ",50,&rc,DT_SINGLELINE|DT_VCENTER|DT_INTERNAL|DT_LEFT);
		if(lpdis->itemState & ODS_SELECTED)
			{r.left-=1;r.top-=1;r.bottom+=3;r.right+=3;}
		else
			{r.left-=1;r.top-=2;r.bottom+=2;r.right+=3;}
		DrawText(lpdis->hDC,s,MyStringLength(s,64),&r,DT_SINGLELINE|DT_VCENTER|DT_CENTER);
		return TRUE;*/
	case WM_USER+1://hf obshiy uchun, dinamik o'zgartirish uchun emas:
		/*if(0==hfRef)
		{	LOGFONT lf;InitLOGFONT(&lf);
			hf = CreateFontIndirect(&lf);
			//br = CreateSolidBrush(RGB(224,231,241));//0xeb,0xe0,0xeb));//conf::Dlg.dlgRGBs[6][0]);
			//brHtBk = CreateSolidBrush(RGB(224,231,241));//conf::Dlg.dlgRGBs[6][5]);
		}
		SendMessage(GetDlgItem(hDlg,IDC_TAB_FILE_SEACH),WM_SETFONT,(WPARAM)hf,TRUE);
		//SendMessage(GetDlgItem(hDlg,IDC_STATIC_SCH),WM_SETFONT,(WPARAM)hf,TRUE);
		//SendMessage(GetDlgItem(hDlg,IDC_COMBO_METHOD),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_STATIC_SCH1),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_SEARCH_NAME),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_STATIC_SCH2),WM_SETFONT,(WPARAM)hf,TRUE);
		//SendMessage(GetDlgItem(hDlg,IDC_BUTTON_ADD_PATH),WM_SETFONT,(WPARAM)hf,TRUE);
		//SendMessage(GetDlgItem(hDlg,IDC_BUTTON_ADD_DISK),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_SEARCH_PATH),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_TEXT_SEACH),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_SEARCH_FOR_TEXT),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_UNICODE_OR_MULTIBYTE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_BINARY_OR_CHARACTER),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_REGISTR_CAPS),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_NO_TEXT_SEACH),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_UNICODE_OR_MULTIBYTE2),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_BINARY_OR_CHARACTER2),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_REGISTR_CAPS2),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDOK),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDCANCEL),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ALTERNATIVE_NAME),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_ALTERNATIVE_FILE_NAME),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_CREATE_TIME_BEFORE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_CREATE_TIME_AFTER),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_CREATE_DATE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_CREATE_DATE2),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_CREATE_DATE_AFTER),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_CREATE_DATE_AFTER2),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_CREATE_TIME_BETWEEN),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_CREATE_BETWEEN_DATE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_CREATE_BETWEEN_TIME),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_CREATE_BETWEEN_DATE2),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_CREATE_BETWEEN_TIME2),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_ACCESS_TIME_BEFORE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_ACCESS_TIME_AFTER),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE2),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_AFTER),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_AFTER2),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_ACCESS_TIME_BETWEEN),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_BETWEEN),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_TIME_BETWEEN),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_BETWEEN2),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_TIME_BETWEEN2),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_WRITE_TIME_BEFORE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_WRITE_TIME_AFTER),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE2),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_AFTER),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_AFTER2),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_WRITE_TIME_BETWEEN),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_BETWEEN),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_TIME_BETWEEN),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_BETWEEN2),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_TIME_BETWEEN2),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_FILE_SIZE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_FILE_SIZE_EQUATION),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_FILE_SIZE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_FILE_SIZE_QUANTITY),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_FILE_ATTRIBUTE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_ARCHIVE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_COMPRESSED),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_DEVICE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_DIRECTORY),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_ENCRYPTED),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_HIDDEN),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_NORMAL),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_NOT_INDEXED),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_OFFLINE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_READ_ONLY),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_REPARSE_POINT),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_SPARSE_FILE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_SYSTEM),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_TEMPORARY),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_VIRTUAL),WM_SETFONT,(WPARAM)hf,TRUE);
		++hfRef;*/
		return 0;//GWL_USERDATA
	case WM_DESTROY:
		//if(--hfRef<1)
		//{	DeleteObject(hf);
			//DeleteObject(br);
			//DeleteObject(brHtBk);
		//}
		//if(item.bSaveResultsLB)
			search->SaveLBListBuf(search->hResultsLB,0);
		if(2==search->endDialogCodeToWM_DESTROY || 3==search->endDialogCodeToWM_DESTROY)//rndPath va Enter to select
		{	//saveOptions();
			if(pResultsLBtoPanelBuf)free(pResultsLBtoPanelBuf);
			pResultsLBtoPanelBuf = search->LBListBuf;
		}
		else
			free(search->LBListBuf);
		//search->hResultsLB = NULL;
		//search->hToPanelBTN=NULL;
		//search->width = 0;
		return 0;
	case WM_VKEYTOITEM://LBS_WANTKEYBOARDINPUT stylr LB bo'lsa;
		if(0x41==LOWORD(wParam))//VK_A
		{	if(0x8000 & GetKeyState(VK_LCONTROL))
			{	int tot=(int)SendMessage(search->hResultsLB,LB_GETCOUNT,0,0);
				SendMessage(search->hResultsLB,LB_SELITEMRANGE,TRUE, MAKELPARAM(0,tot));				
				return -2;
		}	}
		else if(VK_DELETE==LOWORD(wParam))
		{	int tot=(int)SendMessage(search->hResultsLB,LB_GETCOUNT,0,0);
			int totSeltn=(int)SendMessage(search->hResultsLB,LB_GETSELCOUNT,0,0);
			if(LB_ERR==totSeltn) return -1;//Boshqa oparatsiyasini qilsun LB;
			if(tot==totSeltn)
			{	RECT r;int lr;
				SendMessage(search->hResultsLB,LB_RESETCONTENT,0,0);
				GetWindowRect(search->hResultsLB,&r);
				ScreenToClient(hDlg,LPPOINT(&r.left));
				ScreenToClient(hDlg,LPPOINT(&r.right));
				lr=r.bottom-r.top;if(lr>130)lr-=130;
				r.bottom = r.top+130;
				MoveWindow(search->hResultsLB,r.left,r.top,r.right-r.left,r.bottom-r.top,TRUE);
				GetWindowRect(hDlg,&r);
				HWND prnt;prnt = GetParent(hDlg);
				if(!prnt)prnt=GetDesktopWindow();
				ScreenToClient(prnt,LPPOINT(&r.left));
				ScreenToClient(prnt,LPPOINT(&r.right));
				MoveWindow(hDlg,r.left,r.top,r.right-r.left,r.bottom-r.top-lr,TRUE);
			}
			else if(1==totSeltn)
			{	int sel=(int)SendMessage(search->hResultsLB,LB_GETCURSEL,0,0);
				if(LB_ERR==sel) return -1;
				SendMessage(search->hResultsLB,LB_DELETESTRING,sel,0);
				SendMessage(search->hResultsLB,LB_SETSEL,FALSE,-1);
				SendMessage(search->hResultsLB,LB_SELITEMRANGE,TRUE,MAKELONG(sel,sel));
				SendMessage(search->hResultsLB,LB_SETCARETINDEX,sel,TRUE);
			}
			else
			{	int *sels=(int*)malloc(sizeof(int)*totSeltn);
				if(!sels)
				{	MessageBox(hDlg,strngs[75],strngs[76],MB_OK);//L"Err. allocating mem.",L"For ListBox control",MB_OK);
					return -1;
				}
				if(LB_ERR!=SendMessage(search->hResultsLB,LB_GETSELITEMS,totSeltn,(LPARAM)sels))//int crSel=SendMessage(hResultLB,LB_GETCURSEL,0,0);
				{	for(int i=0; i<totSeltn; i++)//boshidan pastga qarab borilsa 1tadan kamaytirib borish kerak,
						SendMessage(search->hResultsLB,LB_DELETESTRING,sels[i]-i,0);//shu uchun teskarisidan kelamiz:
				}
				SendMessage(search->hResultsLB,LB_SETSEL,FALSE,-1);
				SendMessage(search->hResultsLB,LB_SELITEMRANGE,TRUE,MAKELONG(sels[0],sels[0]));
				SendMessage(search->hResultsLB,LB_SETCARETINDEX,sels[0],TRUE);
				free(sels);
			}
			return -2;
		}
		return -1;
	case WM_COMMAND:
		if(search->hResultsLB==(HWND)lParam)
		{	if(LBN_DBLCLK==HIWORD(wParam))
			{	int rr;POINT pt;GetCursorPos(&pt);
				ScreenToClient(search->hResultsLB,&pt);
				rr=(int)SendMessage(search->hResultsLB,LB_ITEMFROMPOINT,0,MAKELONG(pt.x,pt.y));
				rr &= 0xffff;
				rr=(int)SendMessage(search->hResultsLB,LB_GETTEXT,rr,(LPARAM)&s[2]);
				if(LB_ERR!=rr)
				{	if(s[2]=='<')
					{	s[rr+1]=0;s[1]=s[2]='\\';
						ShellExecute(hDlg,L"explore",&s[1],NULL,&s[1],SW_SHOWNORMAL);
					} else
					{	s[0]=s[1]='\\';
						if(33>(int)ShellExecute(hDlg,L"open",s,NULL,s,SW_SHOWNORMAL))
						{	wchar_t *p=wcsrchr(s,'\\');
							if(p)*p=0;
							ShellExecute(hDlg,L"explore",s,NULL,s,SW_SHOWNORMAL);
				}	}	}
				return 0;
		}	}
		switch(LOWORD(wParam))
		{	case IDOK:
				if(!search->bRun)//Start:
				{	SHORT kEnter=GetKeyState(VK_RETURN);
					if(kEnter & 0x8000)
					{int sel=(int)SendMessage(search->hResultsLB,LB_GETCURSEL,0,0);
					 if(LB_ERR!=sel)
					 {search->endDialogCodeToWM_DESTROY=3;//Goto first;
					  search->SaveLBListBuf(search->hResultsLB,1);
					  EndDialog(hDlg,3);
					  return 0;
					}}
					SetWindowText(((PluginObj*)GetWindowLongPtr(hDlg,GWLP_USERDATA))->schDlgOkBtn,strngs[45]);//GetWindowLong(hDlg,GWL_USERDATA))->schDlgOkBtn,strngs[45]);//SetWindowText(GetDlgItem(hDlg,IDOK),strngs[45]);//SetDlgItemText(hDlg,IDOK,strngs[45]);
					if(search->iCall)return FALSE;
					if(GetDlgItemText(hDlg,IDC_COMBO_SEARCH_PATH,s,MAX_PATH))
						selV7PthCB.AddToCB(GetDlgItem(hDlg,IDC_COMBO_SEARCH_PATH),s);
					if(GetDlgItemText(hDlg,IDC_COMBO_SEARCH_FOR_TEXT,s,MAX_PATH))
						selV7TxtCB.AddToCB(GetDlgItem(hDlg,IDC_COMBO_SEARCH_FOR_TEXT),s);
					if(GetDlgItemText(hDlg,IDC_COMBO_SEARCH_NOT_TEXT,s,MAX_PATH))
						selV7ExclTxt.AddToCB(GetDlgItem(hDlg,IDC_COMBO_SEARCH_NOT_TEXT),s);
					if(GetDlgItemText(hDlg,IDC_COMBO_SEARCH_NAME,s,MAX_PATH))
						selV7NameCB.AddToCB(GetDlgItem(hDlg,IDC_COMBO_SEARCH_NAME),s);
					selV7PthCB.Save(selV7PthCBFName,GetDlgItem(hDlg,IDC_COMBO_SEARCH_PATH),25);
					selV7TxtCB.Save(selV7TxtCBFName,GetDlgItem(hDlg,IDC_COMBO_SEARCH_FOR_TEXT),25);
					selV7ExclTxt.Save(selV7ExclTxtFName,GetDlgItem(hDlg,IDC_COMBO_SEARCH_NOT_TEXT),25);
					selV7NameCB.Save(selV7NameCBFName,GetDlgItem(hDlg,IDC_COMBO_SEARCH_NAME),25);

					SendMessage(search->hResultsLB,LB_RESETCONTENT,0,0);	
					CreateResultsLB(search);

					SetFocus(GetDlgItem(hDlg,IDOK));
					search->bRun = TRUE;
					BeginSearch((LPVOID)GetWindowLongPtr(hDlg,GWLP_USERDATA),search);//GetWindowLong(hDlg,GWL_USERDATA),search);
					search->bRun = FALSE;
					SetWindowText(((PluginObj*)GetWindowLongPtr(hDlg,GWLP_USERDATA))->schDlgOkBtn,strngs[11]);//GetWindowLong(hDlg,GWL_USERDATA))->schDlgOkBtn,strngs[11]);//SetDlgItemText(hDlg,IDOK,strngs[11]);
					CreateOutptBtns(search);
				}
				else search->bStop = TRUE;
				return FALSE;
			case IDCANCEL:
				if(!search->iCall)
				{	search->endDialogCodeToWM_DESTROY=2;//baribir yozsin;
					EndDialog(hDlg,0);
				}
				return FALSE;
			case IDC_CHECK_TEXT_SEACH:
				if(BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_TEXT_SEACH),BM_GETCHECK,0,0))
				{	EnableWindow(GetDlgItem(hDlg,IDC_COMBO_SEARCH_FOR_TEXT),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_UNICODE_OR_MULTIBYTE),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_BINARY_OR_CHARACTER),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_REGISTR_CAPS),TRUE);
				}
				else
				{	EnableWindow(GetDlgItem(hDlg,IDC_COMBO_SEARCH_FOR_TEXT),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_UNICODE_OR_MULTIBYTE),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_BINARY_OR_CHARACTER),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_REGISTR_CAPS),FALSE);
				}
				return (INT_PTR)TRUE;
			case IDC_CHECK_NO_TEXT_SEACH:
				if(BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_NO_TEXT_SEACH),BM_GETCHECK,0,0))
				{	EnableWindow(GetDlgItem(hDlg,IDC_COMBO_SEARCH_NOT_TEXT),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_UNICODE_OR_MULTIBYTE2),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_BINARY_OR_CHARACTER2),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_REGISTR_CAPS2),TRUE);
				}
				else
				{	EnableWindow(GetDlgItem(hDlg,IDC_COMBO_SEARCH_NOT_TEXT),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_UNICODE_OR_MULTIBYTE2),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_BINARY_OR_CHARACTER2),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_REGISTR_CAPS2),FALSE);
				}
				return (INT_PTR)TRUE;
			case IDC_CHECK_UNICODE_OR_MULTIBYTE:
				if(BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_UNICODE_OR_MULTIBYTE),BM_GETCHECK,0,0))
				{	//strngs[6]
					if(BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_BINARY_OR_CHARACTER),BM_GETCHECK,0,0))
						SendMessage(GetDlgItem(hDlg,IDC_CHECK_UNICODE_OR_MULTIBYTE),BM_SETCHECK,BST_UNCHECKED,0);
					else SetDlgItemText(hDlg,IDC_CHECK_UNICODE_OR_MULTIBYTE,L"Unicode");
				}
				else
					SetDlgItemText(hDlg,IDC_CHECK_UNICODE_OR_MULTIBYTE,strngs[6]);
				return (INT_PTR)TRUE;
			case IDC_CHECK_UNICODE_OR_MULTIBYTE2:
				if(BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_UNICODE_OR_MULTIBYTE2),BM_GETCHECK,0,0))
				{	//strngs[6]
					if(BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_BINARY_OR_CHARACTER2),BM_GETCHECK,0,0))
						SendMessage(GetDlgItem(hDlg,IDC_CHECK_UNICODE_OR_MULTIBYTE2),BM_SETCHECK,BST_UNCHECKED,0);
					else SetDlgItemText(hDlg,IDC_CHECK_UNICODE_OR_MULTIBYTE2,L"Unicode");
				}
				else
					SetDlgItemText(hDlg,IDC_CHECK_UNICODE_OR_MULTIBYTE2,strngs[6]);
				return (INT_PTR)TRUE;
			case IDC_CHECK_BINARY_OR_CHARACTER:
				if(BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_BINARY_OR_CHARACTER),BM_GETCHECK,0,0))
				{	SetDlgItemText(hDlg,IDC_CHECK_BINARY_OR_CHARACTER,strngs[44]);
					SendMessage(GetDlgItem(hDlg,IDC_CHECK_UNICODE_OR_MULTIBYTE),BM_SETCHECK,BST_UNCHECKED,0);
					SetDlgItemText(hDlg,IDC_CHECK_UNICODE_OR_MULTIBYTE,L"1-byte");
					item.bFindForText_Unicode=0;
				}
				else SetDlgItemText(hDlg,IDC_CHECK_BINARY_OR_CHARACTER,L"ASCII");
				break;
			case IDC_CHECK_BINARY_OR_CHARACTER2:
				if(BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_BINARY_OR_CHARACTER2),BM_GETCHECK,0,0))
				{	SetDlgItemText(hDlg,IDC_CHECK_BINARY_OR_CHARACTER2,strngs[44]);
					SendMessage(GetDlgItem(hDlg,IDC_CHECK_UNICODE_OR_MULTIBYTE2),BM_SETCHECK,BST_UNCHECKED,0);
					SetDlgItemText(hDlg,IDC_CHECK_UNICODE_OR_MULTIBYTE2,L"1-byte");
					item.bFindForExcldText_Unicode=0;
				}
				else SetDlgItemText(hDlg,IDC_CHECK_BINARY_OR_CHARACTER2,L"ASCII");
				break;
			case IDC_CHECK_ALTERNATIVE_NAME:
				if(BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_ALTERNATIVE_NAME),BM_GETCHECK,0,0))
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_ALTERNATIVE_FILE_NAME),TRUE);
				else
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_ALTERNATIVE_FILE_NAME),FALSE);
				break;
			case IDC_CHECK_CREATE_TIME_BEFORE:
				if(BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_CREATE_TIME_BEFORE),BM_GETCHECK,0,0))
				{	//SendMessage(GetDlgItem(hDlg,IDC_CHECK_CREATE_TIME_AFTER),BM_SETCHECK,BST_UNCHECKED,0);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_DATE),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_DATE2),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_DAY),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_MOONS),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_YEAR),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_HOUR),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_MIN),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_SEC),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_MILS),TRUE);
					//item.bCrTimeBef = 1;
				}
				else
				{	EnableWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_DATE),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_DATE2),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_DAY),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_MOONS),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_YEAR),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_HOUR),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_MIN),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_SEC),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_MILS),FALSE);
					//item.bCrTimeBef = 0;
				}
				break;
			case IDC_CHECK_CREATE_TIME_AFTER:
				if(BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_CREATE_TIME_AFTER),BM_GETCHECK,0,0))
				{	//SendMessage(GetDlgItem(hDlg,IDC_CHECK_CREATE_TIME_BEFORE),BM_SETCHECK,BST_UNCHECKED,0);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_DATE_AFTER),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_DATE_AFTER2),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_DAY),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_MOON),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_YEAR),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_HOUR),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_MIN),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_SEC),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_MILS),TRUE);
					//item.bCrTimeAft = 1;
				}
				else
				{	EnableWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_DATE_AFTER),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_DATE_AFTER2),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_DAY),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_MOON),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_YEAR),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_HOUR),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_MIN),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_SEC),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_MILS),FALSE);
					//item.bCrTimeAft = 1;
				}
				break;				 
			case IDC_CHECK_CREATE_TIME_BETWEEN:
				if(BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_CREATE_TIME_BETWEEN),BM_GETCHECK,0,0))
				{	EnableWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_BETWEEN_DATE),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_BETWEEN_TIME),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_BETWEEN_DATE2),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_BETWEEN_TIME2),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_DAY),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_MOONS),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_YEAR),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_HOUR),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_MIN),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_SEC),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_MILS),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_DAY),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_MOON),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_YEAR),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_HOUR),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_MIN),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_SEC),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_MILS),TRUE);
					//item.bCrTimeBef = 1;
				}
				else
				{	EnableWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_BETWEEN_DATE),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_BETWEEN_TIME),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_BETWEEN_DATE2),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_BETWEEN_TIME2),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_DAY),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_MOONS),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_YEAR),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_HOUR),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_MIN),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_SEC),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_MILS),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_DAY),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_MOON),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_YEAR),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_HOUR),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_MIN),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_SEC),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_MILS),FALSE);
					//item.bCrTimeBef = 0;
				}
				break;
			case IDC_CHECK_LAST_ACCESS_TIME_BETWEEN:
				if(BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_ACCESS_TIME_BETWEEN),BM_GETCHECK,0,0))
				{	EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_BETWEEN),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_TIME_BETWEEN),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_BETWEEN2),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_TIME_BETWEEN2),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_DAY),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_MOON),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_YEAR),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_HOUR),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_MIN),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_SEC),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_MILS),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_DAY),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_MOON),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_YEAR),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_HOUR),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_MIN),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_SEC),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_MILS),TRUE);
					//item.bLastAccTimeBet = 1;
				}
				else
				{	EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_BETWEEN),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_TIME_BETWEEN),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_BETWEEN2),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_TIME_BETWEEN2),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_DAY),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_MOON),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_YEAR),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_HOUR),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_MIN),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_SEC),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_MILS),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_DAY),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_MOON),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_YEAR),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_HOUR),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_MIN),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_SEC),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_MILS),FALSE);
					//item.bLastAccTimeBet = 0;
				}
				break;
			case IDC_CHECK_LAST_WRITE_TIME_BETWEEN:
				if(BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_WRITE_TIME_BETWEEN),BM_GETCHECK,0,0))
				{	EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_BETWEEN),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_TIME_BETWEEN),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_BETWEEN2),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_TIME_BETWEEN2),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_DAY),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_MOON),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_YEAR),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_HOUR),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_MIN),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_SEC),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_MILS),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_DAY),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_MOON),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_YEAR),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_HOUR),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_MIN),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_SEC),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_MILS),TRUE);
					//item.bLstWrTimeBet = 1;
				}
				else
				{	EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_BETWEEN),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_TIME_BETWEEN),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_BETWEEN2),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_TIME_BETWEEN2),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_DAY),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_MOON),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_YEAR),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_HOUR),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_MIN),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_SEC),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_MILS),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_DAY),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_MOON),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_YEAR),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_HOUR),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_MIN),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_SEC),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_MILS),FALSE);
					//item.bLstWrTimeBet = 1;
				}
				break;
			case IDC_CHECK_LAST_ACCESS_TIME_BEFORE:
				if(BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_ACCESS_TIME_BEFORE),BM_GETCHECK,0,0))
				{	//SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_ACCESS_TIME_AFTER),BM_SETCHECK,BST_UNCHECKED,0);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE2),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_DAY),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_MOONS),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_YEAR),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_HOUR),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_MIN),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_SEC),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_MILS),TRUE);
					//item.bLstAccTimeBef = 1;
				}
				else
				{	EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE2),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_DAY),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_MOONS),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_YEAR),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_HOUR),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_MIN),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_SEC),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_MILS),FALSE);
					//item.bLstAccTimeBef = 0;
				}
				break;
			case IDC_CHECK_LAST_ACCESS_TIME_AFTER:
				if(BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_ACCESS_TIME_AFTER),BM_GETCHECK,0,0))
				{	//SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_ACCESS_TIME_BEFORE),BM_SETCHECK,BST_UNCHECKED,0);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_AFTER),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_AFTER2),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_DAY),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_MOON),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_YEAR),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_HOUR),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_MIN),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_SEC),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_MILS),TRUE);
					//item.bLstAccTimeAft = 1;
				}
				else
				{	EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_AFTER),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_AFTER2),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_DAY),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_MOON),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_YEAR),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_HOUR),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_MIN),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_SEC),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_MILS),FALSE);
					//item.bLstAccTimeAft = 0;
				}
				break;
			case IDC_CHECK_LAST_WRITE_TIME_BEFORE:
				if(BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_WRITE_TIME_BEFORE),BM_GETCHECK,0,0))
				{	//SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_WRITE_TIME_AFTER),BM_SETCHECK,BST_UNCHECKED,0);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE2),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_DAY),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_MOON),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_YEAR),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_HOUR),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_MIN),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_SEC),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_MILS),TRUE);
					//item.bLstWrTimeBef = 1;
				}
				else
				{	EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE2),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_DAY),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_MOON),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_YEAR),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_HOUR),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_MIN),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_SEC),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_MILS),FALSE);
					//item.bLstWrTimeBef = 0;
				}
				break;
			case IDC_CHECK_LAST_WRITE_TIME_AFTER:
				if(BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_WRITE_TIME_AFTER),BM_GETCHECK,0,0))
				{	//SendMessage(GetDlgItem(hDlg,IDC_CHECK_LAST_WRITE_TIME_BEFORE),BM_SETCHECK,BST_UNCHECKED,0);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_AFTER),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_AFTER2),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_DAY),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_MOON),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_YEAR),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_HOUR),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_MIN),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_SEC),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_MILS),TRUE);
					//item.bLstWrTimeAft = 1;
				}
				else
				{	EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_AFTER),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_AFTER2),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_DAY),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_MOON),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_YEAR),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_HOUR),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_MIN),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_SEC),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_MILS),FALSE);
					//item.bLstWrTimeAft = 0;
				}
				break;
			case IDC_CHECK_FILE_SIZE:
				if(BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_FILE_SIZE),BM_GETCHECK,0,0))
				{	EnableWindow(GetDlgItem(hDlg,IDC_COMBO_FILE_SIZE_EQUATION),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_FILE_SIZE),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_FILE_SIZE),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_COMBO_FILE_SIZE_QUANTITY),TRUE);
					//item.bFileSz = 1;
				}
				else
				{	EnableWindow(GetDlgItem(hDlg,IDC_COMBO_FILE_SIZE_EQUATION),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_FILE_SIZE),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_SPIN_FILE_SIZE),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_COMBO_FILE_SIZE_QUANTITY),FALSE);
					//item.bFileSz = 0;
				}
				break;
			case IDC_CHECK_FILE_ATTRIBUTE:
				if(BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_FILE_ATTRIBUTE),BM_GETCHECK,0,0))
				{	EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_ARCHIVE),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_ARCHIVE_EX),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_COMPRESSED),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_COMPRESSED_EX),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_DEVICE),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_DEVICE_EX),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_DIRECTORY),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_DIRECTORY_EX),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_ENCRYPTED),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_ENCRYPTED_EX),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_HIDDEN),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_HIDDEN_EX),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_NORMAL),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_NORMAL_EX),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_NOT_INDEXED),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_NOT_INDEXED_EX),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_OFFLINE),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_OFFLINE_EX),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_READ_ONLY),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_READ_ONLY_EX),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_REPARSE_POINT),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_REPARSE_POINT_EX),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_SPARSE_FILE),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_SPARSE_FILE_EX),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_SYSTEM),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_SYSTEM_EX),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_TEMPORARY),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_TEMPORARY_EX),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_VIRTUAL),TRUE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_VIRTUAL_EX),TRUE);
					//item.bFileAttr = 1;
				}
				else
				{	EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_ARCHIVE),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_ARCHIVE_EX),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_COMPRESSED),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_COMPRESSED_EX),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_DEVICE),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_DEVICE_EX),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_DIRECTORY),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_DIRECTORY_EX),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_ENCRYPTED),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_ENCRYPTED_EX),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_HIDDEN),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_HIDDEN_EX),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_NORMAL),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_NORMAL_EX),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_NOT_INDEXED),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_NOT_INDEXED_EX),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_OFFLINE),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_OFFLINE_EX),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_READ_ONLY),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_READ_ONLY_EX),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_REPARSE_POINT),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_REPARSE_POINT_EX),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_SPARSE_FILE),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_SPARSE_FILE_EX),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_SYSTEM),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_SYSTEM_EX),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_TEMPORARY),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_TEMPORARY_EX),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_VIRTUAL),FALSE);
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_VIRTUAL_EX),FALSE);
					//item.bFileAttr = 0;
				}
				break;
				case IDC_CHECK_ATTRIBUTE_ARCHIVE:
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_ARCHIVE_EX),(BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_ARCHIVE),BM_GETCHECK,0,0)));
					break;
				case IDC_CHECK_ATTRIBUTE_COMPRESSED:
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_COMPRESSED_EX),(BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_COMPRESSED),BM_GETCHECK,0,0)));
					break;
				case IDC_CHECK_ATTRIBUTE_DEVICE:
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_DEVICE_EX),(BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_DEVICE),BM_GETCHECK,0,0)));
					break;
				case IDC_CHECK_ATTRIBUTE_DIRECTORY:
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_DIRECTORY_EX),(BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_DIRECTORY),BM_GETCHECK,0,0)));
					break;
				case IDC_CHECK_ATTRIBUTE_ENCRYPTED:
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_ENCRYPTED_EX),(BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_ENCRYPTED),BM_GETCHECK,0,0)));
					break;
				case IDC_CHECK_ATTRIBUTE_HIDDEN:
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_HIDDEN_EX),(BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_HIDDEN),BM_GETCHECK,0,0)));
					break;
				case IDC_CHECK_ATTRIBUTE_NORMAL:
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_NORMAL_EX),(BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_NORMAL),BM_GETCHECK,0,0)));
					break;
				case IDC_CHECK_ATTRIBUTE_NOT_INDEXED:
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_NOT_INDEXED_EX),(BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_NOT_INDEXED),BM_GETCHECK,0,0)));
					break;
				case IDC_CHECK_ATTRIBUTE_OFFLINE:
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_OFFLINE_EX),(BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_OFFLINE),BM_GETCHECK,0,0)));
					break;
				case IDC_CHECK_ATTRIBUTE_READ_ONLY:
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_READ_ONLY_EX),(BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_READ_ONLY),BM_GETCHECK,0,0)));
					break;
				case IDC_CHECK_ATTRIBUTE_REPARSE_POINT:
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_REPARSE_POINT_EX),(BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_REPARSE_POINT),BM_GETCHECK,0,0)));
					break;
				case IDC_CHECK_ATTRIBUTE_SPARSE_FILE:
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_SPARSE_FILE_EX),(BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_SPARSE_FILE),BM_GETCHECK,0,0)));
					break;
				case IDC_CHECK_ATTRIBUTE_SYSTEM:;
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_SYSTEM_EX),(BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_SYSTEM),BM_GETCHECK,0,0)));
					break;
				case IDC_CHECK_ATTRIBUTE_TEMPORARY:
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_TEMPORARY_EX),(BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_TEMPORARY),BM_GETCHECK,0,0)));
					break;
				case IDC_CHECK_ATTRIBUTE_VIRTUAL:
					EnableWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_VIRTUAL_EX),(BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_VIRTUAL),BM_GETCHECK,0,0)));
					break;
				case IDC_CHECK_SAVE_RESULTS:
					item.bSaveResultsLB = (BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_SAVE_RESULTS),BM_GETCHECK,0,0));
					break;
				case IDC_CHECK_ENUM_SUBDIR:
					item.bEnumSubDir=(BST_CHECKED==SendMessage(
							GetDlgItem(hDlg,IDC_CHECK_ENUM_SUBDIR),BM_GETCHECK,0,0)) ? 1 : 0;
					break;
			/*case IDC_COMBO_METHOD:
				item.iEnumMethod = SendMessage(GetDlgItem(hDlg,IDC_COMBO_METHOD),CB_GETCURSEL,0,0);
				if(item.iEnumMethod<0)item.iEnumMethod=0;
				if(item.iEnumMethod>1)item.iEnumMethod=1;
				break;*/
			case IDC_EDIT_CREATE_DATE:
			case IDC_EDIT_CREATE_DATE_AFTER:
			case IDC_EDIT_CREATE_BETWEEN_DATE:
			case IDC_EDIT_CREATE_BETWEEN_DATE2:
			case IDC_EDIT_LAST_ACCESS_DATE:
			case IDC_EDIT_LAST_ACCESS_DATE_AFTER:
			case IDC_EDIT_LAST_ACCESS_DATE_BETWEEN:
			case IDC_EDIT_LAST_ACCESS_DATE_BETWEEN2:
			case IDC_EDIT_LAST_WRITE_DATE:
			case IDC_EDIT_LAST_WRITE_DATE_AFTER:
			case IDC_EDIT_LAST_WRITE_DATE_BETWEEN:
			case IDC_EDIT_LAST_WRITE_DATE_BETWEEN2:
				if(EN_KILLFOCUS==HIWORD(wParam))
				{	if(GetWindowText((HWND)lParam,s,MAX_PATH))
					{	//first 2 char before '.' - day of month
						if(s[0] < '0') s[0] = '0';
						if(s[0] > '3') s[0] = '3';
						if(s[1] < (s[0]<'1'?'1':'0')) s[1] = s[0]<'1'?'1':'0';
						if(s[1] > (s[0]<'3'?'9':'1')) s[1] = s[0]<'3'?'9':'1';
						if(s[2] != '.') s[2] = '.';
						//second 2 char after first '.' - month
						if(s[3] < '0') s[3] = '0';
						if(s[3] > '1') s[3] = '1';
						if(s[4] < (s[3]<'1'?'1':'0')) s[4] = s[3]<'1'?'1':'0';
						if(s[4] > (s[3]<'1'?'9':'2')) s[4] = s[3]<'1'?'9':'2';
						if(s[5] != '.') s[5] = '.';
						//last 2 char after second '.' - year
						if(s[6] < '0') s[6] = '0';
						if(s[6] > '9') s[6] = '9';
						if(s[7] < '0') s[7] = '0';
						if(s[7] > '9') s[7] = '9';
						if(s[8] < '0') s[8] = '0';
						if(s[8] > '9') s[8] = '9';
						if(s[9] < '0') s[9] = '0';
						if(s[9] > '9') s[9] = '9';
						s[10] = 0;
						SetWindowText((HWND)lParam,s);
				}	}
				break;
			case IDC_EDIT_CREATE_DATE2:
			case IDC_EDIT_CREATE_DATE_AFTER2:
			case IDC_EDIT_CREATE_BETWEEN_TIME:
			case IDC_EDIT_CREATE_BETWEEN_TIME2:
			case IDC_EDIT_LAST_ACCESS_DATE2:
			case IDC_EDIT_LAST_ACCESS_DATE_AFTER2:
			case IDC_EDIT_LAST_ACCESS_TIME_BETWEEN:
			case IDC_EDIT_LAST_ACCESS_TIME_BETWEEN2:
			case IDC_EDIT_LAST_WRITE_DATE2:
			case IDC_EDIT_LAST_WRITE_DATE_AFTER2:
			case IDC_EDIT_LAST_WRITE_TIME_BETWEEN:
			case IDC_EDIT_LAST_WRITE_TIME_BETWEEN2:
				if(EN_KILLFOCUS==HIWORD(wParam))
				{	if(GetWindowText((HWND)lParam,s,MAX_PATH))
					{	//first 2 char before '.' - hour
						if(s[0] < '0') s[0] = '0';
						if(s[0] > '2') s[0] = '2';
						if(s[1] < '0') s[1] = '0';
						if(s[1] > (s[0]<'2'?'9':'4')) s[1] = s[0]<'2'?'9':'4';
						if(s[2] != '.') s[2] = '.';
						//second 2 char after first '.' - minute
						if(s[3] < '0') s[3] = '0';
						if(s[3] > '6') s[3] = '6';
						if(s[4] < '0') s[4] = '0';
						if(s[4] > (s[3]<'6'?'9':'0')) s[4] = s[3]<'6'?'9':'0';
						if(s[5] != '.') s[5] = '.';
						//third 2 char after second '.' - second
						if(s[6] < '0') s[6] = '0';
						if(s[6] > '6') s[6] = '6';
						if(s[7] < '0') s[7] = '0';
						if(s[7] > (s[6]<'6'?'9':'0')) s[7] = s[6]<'6'?'9':'0';
						if(s[8] != '.') s[8] = '.';
						//last 2 char - millisecond
						if(s[9] < '0') s[9] = '0';
						if(s[9] > '9') s[9] = '9';
						if(s[10] < '0') s[10] = '0';
						if(s[10] > '9') s[10] = '9';
						if(s[11] < '0') s[11] = '0';
						if(s[11] > '9') s[11] = '9';
						s[12] = 0;
						SetWindowText((HWND)lParam,s);
				}	}
				break;
			case IDC_BUTTON_BROWSE_SCH://hBrowseBTN
				if(search->hBrowseBTN)
				{	int sel,ln;if(LB_ERR!=SendMessage(search->hResultsLB,LB_GETSELITEMS,1,(LPARAM)&sel))
					ln=(int)SendMessage(search->hResultsLB,LB_GETTEXTLEN,sel,0);
					if(LB_ERR!=ln)
					{WCHAR *buf; buf = (WCHAR*)_malloca((ln+4)*sizeof(WCHAR));
					 if(LB_ERR!=SendMessage(search->hResultsLB,LB_GETTEXT,sel,(LPARAM)&buf[2]))
					 {	//EndDialog(hDlg,0);
						if('<'==buf[2])//Directory:
						{	buf[1+ln] = 0;
							buf[1]='\\';buf[2]='\\';
							ShellExecute(hDlg,L"explore",&buf[1],NULL,&buf[1],SW_SHOW);//SW_SHOWNORMAL);
						}
						else //file:
						{	wchar_t *p = wcsrchr(&buf[2],'\\');
							if(p)*p = 0;
							else buf[ln+2] = 0;
							buf[0]='\\';buf[1]='\\';
							ShellExecute(hDlg,L"explore",buf,NULL,buf,SW_SHOW);
				 	 }	}
					 _freea(buf);
				 }	}
				break;
			case IDC_BUTTON_TO_PANEL://hToPanelBTN
				if(search->hToPanelBTN)
				{	search->endDialogCodeToWM_DESTROY=2;
					EndDialog(hDlg,2);//BuildSearchResultsToPanel(hDlg));
				}
				break;
			case IDC_BUTTON_EDIT_SCH:
				if(search->hEditBTN)
				{	int sel,ln;if(LB_ERR!=SendMessage(search->hResultsLB,LB_GETSELITEMS,1,(LPARAM)&sel))
					ln=(int)SendMessage(search->hResultsLB,LB_GETTEXTLEN,sel,0);
					if(LB_ERR!=ln)
					{WCHAR *buf; buf = (TCHAR*)_malloca((ln+4)*sizeof(WCHAR));
					 if(LB_ERR!=SendMessage(search->hResultsLB,LB_GETTEXT,sel,(LPARAM)&buf[2]))
					 {	if('<'!=buf[2])//file:
						{	buf[0]=buf[1]='\\';
							ShellExecute(hDlg,L"edit",buf,NULL,buf,SW_SHOW);
					 }	}
					 _freea(buf);
				 }	}
				break;
			case IDC_BUTTON_VIEW_SCH:
				if(search->hViewBTN)
				{	int sel,ln;if(LB_ERR!=SendMessage(search->hResultsLB,LB_GETSELITEMS,1,(LPARAM)&sel))
					ln=(int)SendMessage(search->hResultsLB,LB_GETTEXTLEN,sel,0);
					if(LB_ERR!=ln)
					{WCHAR *buf; buf = (TCHAR*)_malloca((ln+4)*sizeof(WCHAR));
					 if(LB_ERR!=SendMessage(search->hResultsLB,LB_GETTEXT,sel,(LPARAM)&buf[2]))
					 {	if('<'!=buf[0])//file:
						{	buf[0]=buf[1]='\\';
							ShellExecute(hDlg,L"open",buf,NULL,buf,SW_SHOW);
					 }	}
					 _freea(buf);
				 }	}
				break;
		}
		break;
	case WM_NOTIFY:
			//static int x;
			//wchar_t s[256];StringCchPrintf(s,256,L"%d %x %x",x++,wParam,lParam);
			//OutputDebugString(L"\n");
			//OutputDebugString(s);
		NMHDR *lpnmhdr;lpnmhdr = (LPNMHDR)lParam;
		switch(lpnmhdr->idFrom)
		{	case IDC_TAB_FILE_SEACH:
				if(TCN_SELCHANGE == lpnmhdr->code)
				{	int id;
					id = TabCtrl_GetCurSel(GetDlgItem(hDlg,IDC_TAB_FILE_SEACH));
					SetTabPage(hDlg,id);
				}
				break;
			//case IDC_SPIN_FILE_SIZE:
				//OutputDebugString(" IDC_SPIN_FILE_SIZE");
			//	break;
		}
		break;
	case WM_VSCROLL:
		unsigned __int64 szFile;szFile = 0;
		if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_FILE_SIZE))
		{	if(SB_THUMBPOSITION==LOWORD(wParam) || SB_THUMBTRACK==LOWORD(wParam))
			{	if(HIWORD(wParam)>50)
				{	if(GetDlgItemText(hDlg,IDC_EDIT_FILE_SIZE,s,MAX_PATH))
						szFile = MyAtoU64(s);
					MyU64To(s,MAX_PATH,++szFile);//StringCchPrintf(s,MAX_PATH,"%u",++szFile);
					SetDlgItemText(hDlg,IDC_EDIT_FILE_SIZE,s);
				} else
				{	if(GetDlgItemText(hDlg,IDC_EDIT_FILE_SIZE,s,MAX_PATH))
						szFile = MyAtoU64(s);
					if(szFile>0)szFile--;
					MyU64To(s,MAX_PATH,szFile);
					SetDlgItemText(hDlg,IDC_EDIT_FILE_SIZE,s);
			}	}
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_CRTBEF_DAY))
		{	AlignDayFrSpin(hDlg,wParam,IDC_EDIT_CREATE_DATE,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_CRTBEF_MOONS))
		{	AlignMoonFrSpin(hDlg,wParam,IDC_EDIT_CREATE_DATE,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_CRTBEF_YEAR))
		{	AlignYearFrSpin(hDlg,wParam,IDC_EDIT_CREATE_DATE,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_CRTBEF_HOUR))
		{	AlignHourFrSpin(hDlg,wParam,IDC_EDIT_CREATE_DATE2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_CRTBEF_MIN))
		{	AlignMinFrSpin(hDlg,wParam,IDC_EDIT_CREATE_DATE2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_CRTBEF_SEC))
		{	AlignSecFrSpin(hDlg,wParam,IDC_EDIT_CREATE_DATE2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_CRTBEF_MILS))
		{	AlignMilsFrSpin(hDlg,wParam,IDC_EDIT_CREATE_DATE2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_CRTBET_DAY))
		{	AlignDayFrSpin(hDlg,wParam,IDC_EDIT_CREATE_BETWEEN_DATE,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_CRTBET_MOONS))
		{	AlignMoonFrSpin(hDlg,wParam,IDC_EDIT_CREATE_BETWEEN_DATE,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_CRTBET_YEAR))
		{	AlignYearFrSpin(hDlg,wParam,IDC_EDIT_CREATE_BETWEEN_DATE,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_CRTBET_HOUR))
		{	AlignHourFrSpin(hDlg,wParam,IDC_EDIT_CREATE_BETWEEN_TIME,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_CRTBET_MIN))
		{	AlignMinFrSpin(hDlg,wParam,IDC_EDIT_CREATE_BETWEEN_TIME,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_CRTBET_SEC))
		{	AlignSecFrSpin(hDlg,wParam,IDC_EDIT_CREATE_BETWEEN_TIME,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_CRTBET_MILS))
		{	AlignMilsFrSpin(hDlg,wParam,IDC_EDIT_CREATE_BETWEEN_TIME,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_CRBET_DAY))
		{	AlignDayFrSpin(hDlg,wParam,IDC_EDIT_CREATE_BETWEEN_DATE2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_CRBET_MOON))
		{	AlignMoonFrSpin(hDlg,wParam,IDC_EDIT_CREATE_BETWEEN_DATE2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_CRBET_YEAR))
		{	AlignYearFrSpin(hDlg,wParam,IDC_EDIT_CREATE_BETWEEN_DATE2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_CRBET_HOUR))
		{	AlignHourFrSpin(hDlg,wParam,IDC_EDIT_CREATE_BETWEEN_TIME2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_CRBET_MIN))
		{	AlignMinFrSpin(hDlg,wParam,IDC_EDIT_CREATE_BETWEEN_TIME2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_CRBET_SEC))
		{	AlignSecFrSpin(hDlg,wParam,IDC_EDIT_CREATE_BETWEEN_TIME2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_CRBET_MILS))
		{	AlignMilsFrSpin(hDlg,wParam,IDC_EDIT_CREATE_BETWEEN_TIME2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_CRAFT_DAY))
		{	AlignDayFrSpin(hDlg,wParam,IDC_EDIT_CREATE_DATE_AFTER,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_CRAFT_MOON))
		{	AlignMoonFrSpin(hDlg,wParam,IDC_EDIT_CREATE_DATE_AFTER,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_CRAFT_YEAR))
		{	AlignYearFrSpin(hDlg,wParam,IDC_EDIT_CREATE_DATE_AFTER,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_CRAFT_HOUR))
		{	AlignHourFrSpin(hDlg,wParam,IDC_EDIT_CREATE_DATE_AFTER2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_CRAFT_MIN))
		{	AlignMinFrSpin(hDlg,wParam,IDC_EDIT_CREATE_DATE_AFTER2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_CRAFT_SEC))
		{	AlignSecFrSpin(hDlg,wParam,IDC_EDIT_CREATE_DATE_AFTER2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_CRAFT_MILS))
		{	AlignMilsFrSpin(hDlg,wParam,IDC_EDIT_CREATE_DATE_AFTER2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSTBEF_DAY))
		{	AlignDayFrSpin(hDlg,wParam,IDC_EDIT_LAST_ACCESS_DATE,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSTBEF_MOONS))
		{	AlignMoonFrSpin(hDlg,wParam,IDC_EDIT_LAST_ACCESS_DATE,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSTBEF_YEAR))
		{	AlignYearFrSpin(hDlg,wParam,IDC_EDIT_LAST_ACCESS_DATE,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSTBEF_HOUR))
		{	AlignHourFrSpin(hDlg,wParam,IDC_EDIT_LAST_ACCESS_DATE2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSTBEF_MIN))
		{	AlignMinFrSpin(hDlg,wParam,IDC_EDIT_LAST_ACCESS_DATE2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSTBEF_SEC))
		{	AlignSecFrSpin(hDlg,wParam,IDC_EDIT_LAST_ACCESS_DATE2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSTBEF_MILS))
		{	AlignMilsFrSpin(hDlg,wParam,IDC_EDIT_LAST_ACCESS_DATE2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSWTBET_DAY))
		{	AlignDayFrSpin(hDlg,wParam,IDC_EDIT_LAST_WRITE_DATE_BETWEEN,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSWTBET_MOON))
		{	AlignMoonFrSpin(hDlg,wParam,IDC_EDIT_LAST_WRITE_DATE_BETWEEN,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSWTBET_YEAR))
		{	AlignYearFrSpin(hDlg,wParam,IDC_EDIT_LAST_WRITE_DATE_BETWEEN,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSWTBET_HOUR))
		{	AlignHourFrSpin(hDlg,wParam,IDC_EDIT_LAST_WRITE_TIME_BETWEEN,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSWTBET_MIN))
		{	AlignMinFrSpin(hDlg,wParam,IDC_EDIT_LAST_WRITE_TIME_BETWEEN,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSWTBET_SEC))
		{	AlignSecFrSpin(hDlg,wParam,IDC_EDIT_LAST_WRITE_TIME_BETWEEN,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSWTBET_MILS))
		{	AlignMilsFrSpin(hDlg,wParam,IDC_EDIT_LAST_WRITE_TIME_BETWEEN,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSWRBET_DAY))
		{	AlignDayFrSpin(hDlg,wParam,IDC_EDIT_LAST_WRITE_DATE_BETWEEN2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSWRBET_MOON))
		{	AlignMoonFrSpin(hDlg,wParam,IDC_EDIT_LAST_WRITE_DATE_BETWEEN2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSWRBET_YEAR))
		{	AlignYearFrSpin(hDlg,wParam,IDC_EDIT_LAST_WRITE_DATE_BETWEEN2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSWRBET_HOUR))
		{	AlignHourFrSpin(hDlg,wParam,IDC_EDIT_LAST_WRITE_TIME_BETWEEN2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSWRBET_MIN))
		{	AlignMinFrSpin(hDlg,wParam,IDC_EDIT_LAST_WRITE_TIME_BETWEEN2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSWRBET_SEC))
		{	AlignSecFrSpin(hDlg,wParam,IDC_EDIT_LAST_WRITE_TIME_BETWEEN2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSWRBET_MILS))
		{	AlignMilsFrSpin(hDlg,wParam,IDC_EDIT_LAST_WRITE_TIME_BETWEEN2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSAFT_DAY))
		{	AlignDayFrSpin(hDlg,wParam,IDC_EDIT_LAST_ACCESS_DATE_AFTER,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSAFT_MOON))
		{	AlignMoonFrSpin(hDlg,wParam,IDC_EDIT_LAST_ACCESS_DATE_AFTER,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSAFT_YEAR))
		{	AlignYearFrSpin(hDlg,wParam,IDC_EDIT_LAST_ACCESS_DATE_AFTER,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSAFT_HOUR))
		{	AlignHourFrSpin(hDlg,wParam,IDC_EDIT_LAST_ACCESS_DATE_AFTER2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSAFT_MIN))
		{	AlignMinFrSpin(hDlg,wParam,IDC_EDIT_LAST_ACCESS_DATE_AFTER2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSAFT_SEC))
		{	AlignSecFrSpin(hDlg,wParam,IDC_EDIT_LAST_ACCESS_DATE_AFTER2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSAFT_MILS))
		{	AlignMilsFrSpin(hDlg,wParam,IDC_EDIT_LAST_ACCESS_DATE_AFTER2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSTBET_DAY))
		{	AlignDayFrSpin(hDlg,wParam,IDC_EDIT_LAST_ACCESS_DATE_BETWEEN,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSTBET_MOON))
		{	AlignMoonFrSpin(hDlg,wParam,IDC_EDIT_LAST_ACCESS_DATE_BETWEEN,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSTBET_YEAR))
		{	AlignYearFrSpin(hDlg,wParam,IDC_EDIT_LAST_ACCESS_DATE_BETWEEN,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSTBET_HOUR))
		{	AlignHourFrSpin(hDlg,wParam,IDC_EDIT_LAST_ACCESS_TIME_BETWEEN,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSTBET_MIN))
		{	AlignMinFrSpin(hDlg,wParam,IDC_EDIT_LAST_ACCESS_TIME_BETWEEN,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSTBET_SEC))
		{	AlignSecFrSpin(hDlg,wParam,IDC_EDIT_LAST_ACCESS_TIME_BETWEEN,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSTBET_MILS))
		{	AlignMilsFrSpin(hDlg,wParam,IDC_EDIT_LAST_ACCESS_TIME_BETWEEN,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSABET_DAY))
		{	AlignDayFrSpin(hDlg,wParam,IDC_EDIT_LAST_ACCESS_DATE_BETWEEN2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSABET_MOON))
		{	AlignMoonFrSpin(hDlg,wParam,IDC_EDIT_LAST_ACCESS_DATE_BETWEEN2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSABET_YEAR))
		{	AlignYearFrSpin(hDlg,wParam,IDC_EDIT_LAST_ACCESS_DATE_BETWEEN2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSABET_HOUR))
		{	AlignHourFrSpin(hDlg,wParam,IDC_EDIT_LAST_ACCESS_TIME_BETWEEN2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSABET_MIN))
		{	AlignMinFrSpin(hDlg,wParam,IDC_EDIT_LAST_ACCESS_TIME_BETWEEN2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSABET_SEC))
		{	AlignSecFrSpin(hDlg,wParam,IDC_EDIT_LAST_ACCESS_TIME_BETWEEN2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSABET_MILS))
		{	AlignMilsFrSpin(hDlg,wParam,IDC_EDIT_LAST_ACCESS_TIME_BETWEEN2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_DAY))
		{	AlignDayFrSpin(hDlg,wParam,IDC_EDIT_LAST_WRITE_DATE,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_MOON))
		{	AlignMoonFrSpin(hDlg,wParam,IDC_EDIT_LAST_WRITE_DATE,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_YEAR))
		{	AlignYearFrSpin(hDlg,wParam,IDC_EDIT_LAST_WRITE_DATE,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_HOUR))
		{	AlignHourFrSpin(hDlg,wParam,IDC_EDIT_LAST_WRITE_DATE2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_MIN))
		{	AlignMinFrSpin(hDlg,wParam,IDC_EDIT_LAST_WRITE_DATE2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_SEC))
		{	AlignSecFrSpin(hDlg,wParam,IDC_EDIT_LAST_WRITE_DATE2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_MILS))
		{	AlignMilsFrSpin(hDlg,wParam,IDC_EDIT_LAST_WRITE_DATE2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_DAY))
		{	AlignDayFrSpin(hDlg,wParam,IDC_EDIT_LAST_WRITE_DATE_AFTER,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_MOON))
		{	AlignMoonFrSpin(hDlg,wParam,IDC_EDIT_LAST_WRITE_DATE_AFTER,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_YEAR))
		{	AlignYearFrSpin(hDlg,wParam,IDC_EDIT_LAST_WRITE_DATE_AFTER,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_HOUR))
		{	AlignHourFrSpin(hDlg,wParam,IDC_EDIT_LAST_WRITE_DATE_AFTER2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_MIN))
		{	AlignMinFrSpin(hDlg,wParam,IDC_EDIT_LAST_WRITE_DATE_AFTER2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_SEC))
		{	AlignSecFrSpin(hDlg,wParam,IDC_EDIT_LAST_WRITE_DATE_AFTER2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		else if(lParam==(LPARAM)GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_MILS))
		{	AlignMilsFrSpin(hDlg,wParam,IDC_EDIT_LAST_WRITE_DATE_AFTER2,s);
			SendMessage((HWND)lParam,UDM_SETPOS32,0,50);			
		}
		break;
	case WM_CONTEXTMENU:
		wchar_t us[MAX_PATH]=L"\\\\";//?\\UNC\\"; ParseDisplayName shunday olar ekan;
		if(wParam==(WPARAM)search->hResultsLB)
		{	POINT pt;pt.x = LOWORD(lParam);
			pt.y = HIWORD(lParam);
			ScreenToClient(search->hResultsLB,&pt);
			int r=(int)SendMessage(search->hResultsLB,LB_ITEMFROMPOINT,0,MAKELONG(pt.x,pt.y));
			r &= 0xffff;
			r=(int)SendMessage(search->hResultsLB,LB_GETTEXT,r,(LPARAM)s);
			if(LB_ERR!=r)
			{	if('<'==s[0])
				{	r=1+MyStringCpy(&us[2],MAX_PATH-2,&s[1]);//8
					us[r]=0;
				}
				else r=1+MyStringCpy(&us[2],MAX_PATH-2,s);
				//myWMI::TAddtnMenuItems it;
				if(s[0]=='<')
				{	//s[r-1]=0;
					//it.pNext = NULL;
					//it.itemStr = s;
					//it.iPan = this-&panel[0];
					//it.iPanItem = id;
					 //it.iMsg = IDM_FILE_STREAM;
					//DoExplorerMenu(search->hResultsLB,&s[1],&pt,NULL);
				}
				//else DoExplorerMenu(search->hResultsLB,s,&pt,NULL);
				DoExplorerMenu(search->hResultsLB,us,&pt,NULL);
		}	}
		break;
	}
	return (INT_PTR)FALSE;
}

void ResizeChilds(Search *search, int w, int h)
{
	if(search->bFindDlgFirstCreatedToResizeChld)
	{	if((!search->LBListBuf) || (*((int*)search->LBListBuf) < 25))
		{	RECT r;h = search->minHeight+130+14;
			GetWindowRect(search->hDlg,&r);
			ScreenToClient(GetParent(search->hDlg),LPPOINT(&r.left));
			ScreenToClient(GetParent(search->hDlg),LPPOINT(&r.right));
			MoveWindow(search->hDlg,r.left,r.top,r.right-r.left,h,TRUE);
		}
		search->bFindDlgFirstCreatedToResizeChld = FALSE;
	}
	search->width = w; search->height = h;

	SetWindowPos(GetDlgItem(search->hDlg,IDC_TAB_FILE_SEACH),HWND_BOTTOM,3,3,w-7,420,SWP_SHOWWINDOW);//MoveWindow(GetDlgItem(dlg,IDC_TAB_FILE_SEACH),3,3,w-7,420,TRUE);//3 3 370 260
	//SetWindowPos(GetDlgItem(dlg,IDC_STATIC_SCH),HWND_TOP,w-170,5,47,14,SWP_SHOWWINDOW);//268 5 27 8
	//SetWindowPos(GetDlgItem(dlg,IDC_COMBO_METHOD),HWND_TOP,w-108,4,108,12,SWP_SHOWWINDOW);//297 1 78 12

	if(search->hResultsLB)
	{	SetWindowPos(search->hInfoEdit,HWND_TOP,2,448,w-4,22,SWP_SHOWWINDOW);
		SetWindowPos(search->hResultsLB,HWND_TOP,2,472,w-4,h-search->minHeight+14,SWP_SHOWWINDOW);
	}

	int id = TabCtrl_GetCurSel(GetDlgItem(search->hDlg,IDC_TAB_FILE_SEACH));
	//if(0==id)
	//{
		//SetWindowPos(GetDlgItem(dlg,IDC_BUTTON_ADD_PATH),HWND_TOP,w-204,78,95,17,SWP_SHOWWINDOW);//210 46 77 13
		//SetWindowPos(GetDlgItem(dlg,IDC_BUTTON_ADD_DISK),HWND_TOP,w-106,78,95,17,SWP_SHOWWINDOW);//288 46 77 13

		SetWindowPos(GetDlgItem(search->hDlg,IDC_COMBO_SEARCH_FOR_TEXT),HWND_TOP,7,138,w-14,12,id?SWP_HIDEWINDOW:SWP_SHOWWINDOW);//7 85 361 12
		SetWindowPos(GetDlgItem(search->hDlg,IDC_COMBO_SEARCH_NOT_TEXT),HWND_TOP,7,268,w-14,12,id?SWP_HIDEWINDOW:SWP_SHOWWINDOW);
	
		SetWindowPos(GetDlgItem(search->hDlg,IDC_COMBO_SEARCH_PATH),HWND_TOP,7,95,w-14,12,id?SWP_HIDEWINDOW:SWP_SHOWWINDOW);//7 59 361 12
	
		SetWindowPos(GetDlgItem(search->hDlg,IDC_COMBO_SEARCH_NAME),HWND_TOP,7,50,w-14,12,
			id?SWP_HIDEWINDOW:SWP_SHOWWINDOW);//7 30 361 12
	//}
}

VOID GetDlgItems(Search *search)
{
	item.bEnumSubDir=(BST_CHECKED==SendMessage(
						GetDlgItem(search->hDlg,IDC_CHECK_ENUM_SUBDIR),BM_GETCHECK,0,0)) ? 1 : 0;
	//item.iEnumMethod = SendMessage(GetDlgItem(hDlg,IDC_COMBO_METHOD),CB_GETCURSEL,0,0);
	//if(item.iEnumMethod<0)item.iEnumMethod=0;
	//if(item.iEnumMethod>1)item.iEnumMethod=1;

	if(!GetDlgItemText(search->hDlg,IDC_COMBO_SEARCH_NAME,item.filtr,MAX_PATH))
		item.filtr[0]=item.filtr[1] = 0;
	if(!GetDlgItemText(search->hDlg,IDC_COMBO_SEARCH_PATH,item.rootPath,MAX_PATH))
		item.rootPath[0] = 0;

	item.bFindForText = (BST_CHECKED==SendMessage(GetDlgItem(search->hDlg,IDC_CHECK_TEXT_SEACH),BM_GETCHECK,0,0));
	item.bFindForExcldText = (BST_CHECKED==SendMessage(GetDlgItem(search->hDlg,IDC_CHECK_NO_TEXT_SEACH),BM_GETCHECK,0,0));

	item.bFindForText_Unicode = (BST_CHECKED==SendMessage(GetDlgItem(search->hDlg,IDC_CHECK_UNICODE_OR_MULTIBYTE),BM_GETCHECK,0,0));
	if(item.bFindForText_Unicode)
	{item.FindForTextLn = GetDlgItemTextW(search->hDlg,IDC_COMBO_SEARCH_FOR_TEXT,(LPWSTR)item.FindForText,MAX_PATH);
	 if(!item.FindForTextLn)	
		item.FindForText[0] = item.FindForText[1] = 0;
	}else
	{item.FindForTextLn = GetDlgItemText(search->hDlg,IDC_COMBO_SEARCH_FOR_TEXT,item.FindForText,MAX_PATH);
	 if(!item.FindForTextLn)	
		item.FindForText[0] = 0;
	}

	item.bFindForExcldText_Unicode = (BST_CHECKED==SendMessage(GetDlgItem(search->hDlg,IDC_CHECK_UNICODE_OR_MULTIBYTE2),BM_GETCHECK,0,0));
	if(item.bFindForExcldText_Unicode)
	{item.FindForExcldTextLn = GetDlgItemTextW(search->hDlg,IDC_COMBO_SEARCH_NOT_TEXT,(LPWSTR)item.FindForExcldText,MAX_PATH);
	 if(!item.FindForExcldTextLn)	
		item.FindForExcldText[0] = item.FindForExcldText[1] = 0;
	}else
	{ item.FindForExcldTextLn = GetDlgItemText(search->hDlg,IDC_COMBO_SEARCH_NOT_TEXT,item.FindForExcldText,MAX_PATH);
	 if(!item.FindForTextLn)	
		item.FindForExcldText[0] = 0;
	}

	item.bFindForText_ASCII = (BST_CHECKED==SendMessage(GetDlgItem(search->hDlg,IDC_CHECK_BINARY_OR_CHARACTER),BM_GETCHECK,0,0));
	item.bFindForExcldText_ASCII = (BST_CHECKED==SendMessage(GetDlgItem(search->hDlg,IDC_CHECK_BINARY_OR_CHARACTER2),BM_GETCHECK,0,0));

	item.bFindForText_UpperCase = (BST_CHECKED==SendMessage(GetDlgItem(search->hDlg,IDC_CHECK_REGISTR_CAPS),BM_GETCHECK,0,0));
	item.bFindForExcldText_UpperCase = (BST_CHECKED==SendMessage(GetDlgItem(search->hDlg,IDC_CHECK_REGISTR_CAPS2),BM_GETCHECK,0,0));

	item.bFindForAlterName = (BST_CHECKED==SendMessage(GetDlgItem(search->hDlg,IDC_CHECK_ALTERNATIVE_NAME),BM_GETCHECK,0,0));

	if(!GetDlgItemTextW(search->hDlg,IDC_EDIT_ALTERNATIVE_FILE_NAME,item.altName,MAX_PATH))
		item.altName[0] = 0;

	wchar_t sd[32]=L"";wchar_t st[32]=L"";
	item.bCrTimeBef = (BST_CHECKED==SendMessage(GetDlgItem(search->hDlg,IDC_CHECK_CREATE_TIME_BEFORE),BM_GETCHECK,0,0));
	if(item.bCrTimeBef)
	{	GetDlgItemText(search->hDlg,IDC_EDIT_CREATE_DATE,sd,MAX_PATH);
		GetDlgItemText(search->hDlg,IDC_EDIT_CREATE_DATE2,st,MAX_PATH);
		if(!EditsToFileTime(&item.CrTimeBef,sd,st))
			item.bCrTimeBef = FALSE;
	}
	
	item.bCrTimeAft = (BST_CHECKED==SendMessage(GetDlgItem(search->hDlg,IDC_CHECK_CREATE_TIME_AFTER),BM_GETCHECK,0,0));
	if(item.bCrTimeAft)
	{	GetDlgItemText(search->hDlg,IDC_EDIT_CREATE_DATE_AFTER,sd,MAX_PATH);
		GetDlgItemText(search->hDlg,IDC_EDIT_CREATE_DATE_AFTER2,st,MAX_PATH);
		if(!EditsToFileTime(&item.CrTimeAft,sd,st))
			item.bCrTimeAft = FALSE;
	}
	
	item.bCrTimeBet = (BST_CHECKED==SendMessage(GetDlgItem(search->hDlg,IDC_CHECK_CREATE_TIME_BETWEEN),BM_GETCHECK,0,0));
	if(item.bCrTimeBet)
	{	GetDlgItemText(search->hDlg,IDC_EDIT_CREATE_BETWEEN_DATE,sd,MAX_PATH);
		GetDlgItemText(search->hDlg,IDC_EDIT_CREATE_BETWEEN_TIME,st,MAX_PATH);
		if(!EditsToFileTime(&item.CrTimeBet[0],sd,st))
			item.bCrTimeBet = FALSE;
		GetDlgItemText(search->hDlg,IDC_EDIT_CREATE_BETWEEN_DATE2,sd,MAX_PATH);
		GetDlgItemText(search->hDlg,IDC_EDIT_CREATE_BETWEEN_TIME2,st,MAX_PATH);
		if(!EditsToFileTime(&item.CrTimeBet[1],sd,st))
			item.bCrTimeBet = FALSE;
	}

	item.bLstAccTimeBef = (BST_CHECKED==SendMessage(GetDlgItem(search->hDlg,IDC_CHECK_LAST_ACCESS_TIME_BEFORE),BM_GETCHECK,0,0));
	if(item.bLstAccTimeBef)
	{	GetDlgItemText(search->hDlg,IDC_EDIT_LAST_ACCESS_DATE,sd,MAX_PATH);
		GetDlgItemText(search->hDlg,IDC_EDIT_LAST_ACCESS_DATE2,st,MAX_PATH);
		if(!EditsToFileTime(&item.LstAccTimeBef,sd,st))
			item.bLstAccTimeBef = FALSE;
	}
	
	item.bLstAccTimeAft = (BST_CHECKED==SendMessage(GetDlgItem(search->hDlg,IDC_CHECK_LAST_ACCESS_TIME_AFTER),BM_GETCHECK,0,0));
	if(item.bLstAccTimeAft)
	{	GetDlgItemText(search->hDlg,IDC_EDIT_LAST_ACCESS_DATE_AFTER,sd,MAX_PATH);
		GetDlgItemText(search->hDlg,IDC_EDIT_LAST_ACCESS_DATE_AFTER2,st,MAX_PATH);
		if(!EditsToFileTime(&item.LstAccTimeAft,sd,st))
			item.bLstAccTimeAft = FALSE;
	}

	item.bLastAccTimeBet = (BST_CHECKED==SendMessage(GetDlgItem(search->hDlg,IDC_CHECK_LAST_ACCESS_TIME_BETWEEN),BM_GETCHECK,0,0));
	if(item.bLastAccTimeBet)
	{	GetDlgItemText(search->hDlg,IDC_EDIT_LAST_ACCESS_DATE_BETWEEN,sd,MAX_PATH);
		GetDlgItemText(search->hDlg,IDC_EDIT_LAST_ACCESS_TIME_BETWEEN,st,MAX_PATH);
		if(!EditsToFileTime(&item.LastAccTimeBet[0],sd,st))
			item.bLastAccTimeBet = FALSE;
		GetDlgItemText(search->hDlg,IDC_EDIT_LAST_ACCESS_DATE_BETWEEN2,sd,MAX_PATH);
		GetDlgItemText(search->hDlg,IDC_EDIT_LAST_ACCESS_TIME_BETWEEN2,st,MAX_PATH);
		if(!EditsToFileTime(&item.LastAccTimeBet[1],sd,st))
			item.bLastAccTimeBet = FALSE;
	}

	item.bLstWrTimeBef = (BST_CHECKED==SendMessage(GetDlgItem(search->hDlg,IDC_CHECK_LAST_WRITE_TIME_BEFORE),BM_GETCHECK,0,0));
	if(item.bLstWrTimeBef)
	{	GetDlgItemText(search->hDlg,IDC_EDIT_LAST_WRITE_DATE,sd,MAX_PATH);
		GetDlgItemText(search->hDlg,IDC_EDIT_LAST_WRITE_DATE2,st,MAX_PATH);
		if(!EditsToFileTime(&item.LstWrTimeBef,sd,st))
			item.bLstWrTimeBef = FALSE;
	}
	
	item.bLstWrTimeAft = (BST_CHECKED==SendMessage(GetDlgItem(search->hDlg,IDC_CHECK_LAST_WRITE_TIME_AFTER),BM_GETCHECK,0,0));
	if(item.bLstWrTimeAft)
	{	GetDlgItemText(search->hDlg,IDC_EDIT_LAST_WRITE_DATE_AFTER,sd,MAX_PATH);
		GetDlgItemText(search->hDlg,IDC_EDIT_LAST_WRITE_DATE_AFTER2,st,MAX_PATH);
		if(!EditsToFileTime(&item.LstWrTimeAft,sd,st))
			item.bLstWrTimeAft = FALSE;
	}
	
	item.bLstWrTimeBet = (BST_CHECKED==SendMessage(GetDlgItem(search->hDlg,IDC_CHECK_LAST_WRITE_TIME_BETWEEN),BM_GETCHECK,0,0));
	if(item.bLstWrTimeBet)
	{	GetDlgItemText(search->hDlg,IDC_EDIT_LAST_WRITE_DATE_BETWEEN,sd,MAX_PATH);
		GetDlgItemText(search->hDlg,IDC_EDIT_LAST_WRITE_TIME_BETWEEN,st,MAX_PATH);
		if(!EditsToFileTime(&item.LstWrTimeBet[0],sd,st))
			item.bLstWrTimeBet = FALSE;
		GetDlgItemText(search->hDlg,IDC_EDIT_LAST_WRITE_DATE_BETWEEN2,sd,MAX_PATH);
		GetDlgItemText(search->hDlg,IDC_EDIT_LAST_WRITE_TIME_BETWEEN2,st,MAX_PATH);
		if(!EditsToFileTime(&item.LstWrTimeBet[1],sd,st))
			item.bLstWrTimeBet = FALSE;
	}

	item.bFileSz = (BST_CHECKED==SendMessage(GetDlgItem(search->hDlg,IDC_CHECK_FILE_SIZE),BM_GETCHECK,0,0));
	if(!GetDlgItemText(search->hDlg,IDC_COMBO_FILE_SIZE_EQUATION,item.sFileSzEqu	,MAX_PATH))
		item.sFileSzEqu[0] = 0;

	if(!GetDlgItemText(search->hDlg,IDC_EDIT_FILE_SIZE,item.sFileSz	,MAX_PATH))
		item.sFileSz[0] = 0;

	item.iFileSzQual = (int)SendMessage(GetDlgItem(search->hDlg,IDC_COMBO_FILE_SIZE_QUANTITY),CB_GETCURSEL,0,0);

	item.bFileAttr = (BST_CHECKED==SendMessage(GetDlgItem(search->hDlg,IDC_CHECK_FILE_ATTRIBUTE),BM_GETCHECK,0,0));
	item.bFileAttArchive = (BST_CHECKED==SendMessage(GetDlgItem(search->hDlg,IDC_CHECK_ATTRIBUTE_ARCHIVE_EX),BM_GETCHECK,0,0));
	item.bFileAttArchiveEx = (BST_CHECKED==SendMessage(GetDlgItem(search->hDlg,IDC_CHECK_ATTRIBUTE_ARCHIVE),BM_GETCHECK,0,0));
	item.bFileAttCompr = (BST_CHECKED==SendMessage(GetDlgItem(search->hDlg,IDC_CHECK_ATTRIBUTE_COMPRESSED),BM_GETCHECK,0,0));
	item.bFileAttComprEx = (BST_CHECKED==SendMessage(GetDlgItem(search->hDlg,IDC_CHECK_ATTRIBUTE_COMPRESSED_EX),BM_GETCHECK,0,0));
	item.bFileAttDevice = (BST_CHECKED==SendMessage(GetDlgItem(search->hDlg,IDC_CHECK_ATTRIBUTE_DEVICE),BM_GETCHECK,0,0));
	item.bFileAttDeviceEx = (BST_CHECKED==SendMessage(GetDlgItem(search->hDlg,IDC_CHECK_ATTRIBUTE_DEVICE_EX),BM_GETCHECK,0,0));
	item.bFileAttDir = (BST_CHECKED==SendMessage(GetDlgItem(search->hDlg,IDC_CHECK_ATTRIBUTE_DIRECTORY),BM_GETCHECK,0,0));
	item.bFileAttDirEx = (BST_CHECKED==SendMessage(GetDlgItem(search->hDlg,IDC_CHECK_ATTRIBUTE_DIRECTORY_EX),BM_GETCHECK,0,0));
	item.bFileAttEncr= (BST_CHECKED==SendMessage(GetDlgItem(search->hDlg,IDC_CHECK_ATTRIBUTE_ENCRYPTED),BM_GETCHECK,0,0));
	item.bFileAttEncrEx= (BST_CHECKED==SendMessage(GetDlgItem(search->hDlg,IDC_CHECK_ATTRIBUTE_ENCRYPTED_EX),BM_GETCHECK,0,0));
	item.bFileAttHidden = (BST_CHECKED==SendMessage(GetDlgItem(search->hDlg,IDC_CHECK_ATTRIBUTE_HIDDEN),BM_GETCHECK,0,0));
	item.bFileAttHiddenEx = (BST_CHECKED==SendMessage(GetDlgItem(search->hDlg,IDC_CHECK_ATTRIBUTE_HIDDEN_EX),BM_GETCHECK,0,0));
	item.bFileAttNormal = (BST_CHECKED==SendMessage(GetDlgItem(search->hDlg,IDC_CHECK_ATTRIBUTE_NORMAL),BM_GETCHECK,0,0));
	item.bFileAttNormalEx = (BST_CHECKED==SendMessage(GetDlgItem(search->hDlg,IDC_CHECK_ATTRIBUTE_NORMAL_EX),BM_GETCHECK,0,0));
	item.bFileAttNotInd = (BST_CHECKED==SendMessage(GetDlgItem(search->hDlg,IDC_CHECK_ATTRIBUTE_NOT_INDEXED),BM_GETCHECK,0,0));
	item.bFileAttNotIndEx = (BST_CHECKED==SendMessage(GetDlgItem(search->hDlg,IDC_CHECK_ATTRIBUTE_NOT_INDEXED_EX),BM_GETCHECK,0,0));
	item.bFileAttOffl = (BST_CHECKED==SendMessage(GetDlgItem(search->hDlg,IDC_CHECK_ATTRIBUTE_OFFLINE),BM_GETCHECK,0,0));
	item.bFileAttOfflEx = (BST_CHECKED==SendMessage(GetDlgItem(search->hDlg,IDC_CHECK_ATTRIBUTE_OFFLINE_EX),BM_GETCHECK,0,0));
	item.bFileAttReadOnly = (BST_CHECKED==SendMessage(GetDlgItem(search->hDlg,IDC_CHECK_ATTRIBUTE_READ_ONLY),BM_GETCHECK,0,0));
	item.bFileAttReadOnlyEx = (BST_CHECKED==SendMessage(GetDlgItem(search->hDlg,IDC_CHECK_ATTRIBUTE_READ_ONLY_EX),BM_GETCHECK,0,0));
	item.bFileAttRepPt = (BST_CHECKED==SendMessage(GetDlgItem(search->hDlg,IDC_CHECK_ATTRIBUTE_REPARSE_POINT),BM_GETCHECK,0,0));
	item.bFileAttRepPtEx = (BST_CHECKED==SendMessage(GetDlgItem(search->hDlg,IDC_CHECK_ATTRIBUTE_REPARSE_POINT_EX),BM_GETCHECK,0,0));
	item.bFileAttSparseFile = (BST_CHECKED==SendMessage(GetDlgItem(search->hDlg,IDC_CHECK_ATTRIBUTE_SPARSE_FILE),BM_GETCHECK,0,0));
	item.bFileAttSparseFileEx = (BST_CHECKED==SendMessage(GetDlgItem(search->hDlg,IDC_CHECK_ATTRIBUTE_SPARSE_FILE_EX),BM_GETCHECK,0,0));
	item.bFileAttSys = (BST_CHECKED==SendMessage(GetDlgItem(search->hDlg,IDC_CHECK_ATTRIBUTE_SYSTEM),BM_GETCHECK,0,0));
	item.bFileAttSysEx = (BST_CHECKED==SendMessage(GetDlgItem(search->hDlg,IDC_CHECK_ATTRIBUTE_SYSTEM_EX),BM_GETCHECK,0,0));
	item.bFileAttTemp = (BST_CHECKED==SendMessage(GetDlgItem(search->hDlg,IDC_CHECK_ATTRIBUTE_TEMPORARY),BM_GETCHECK,0,0));
	item.bFileAttTempEx = (BST_CHECKED==SendMessage(GetDlgItem(search->hDlg,IDC_CHECK_ATTRIBUTE_TEMPORARY_EX),BM_GETCHECK,0,0));
	item.bFileAttVirt = (BST_CHECKED==SendMessage(GetDlgItem(search->hDlg,IDC_CHECK_ATTRIBUTE_VIRTUAL),BM_GETCHECK,0,0));
	item.bFileAttVirtEx = (BST_CHECKED==SendMessage(GetDlgItem(search->hDlg,IDC_CHECK_ATTRIBUTE_VIRTUAL_EX),BM_GETCHECK,0,0));
	item.bSaveResultsLB = (BST_CHECKED==SendMessage(GetDlgItem(search->hDlg,IDC_CHECK_SAVE_RESULTS),BM_GETCHECK,0,0));
}

VOID CreateResultsLB(Search *search)
{
	if(search->hResultsLB) return;

	//DC_COMBO_SEARCH_NAME
	//2 265
	RECT rc; GetWindowRect(search->hDlg, &rc);
	if(rc.bottom-rc.top<search->minHeightAftCrLB)
		MoveWindow(search->hDlg,rc.left, 
						rc.top,
						rc.right-rc.left,
						search->minHeightAftCrLB,
						TRUE);
	//Create List:
	search->hInfoEdit = CreateWindowEx(WS_EX_CLIENTEDGE,
							L"EDIT",
                            NULL,
                            WS_CHILD | WS_VISIBLE | ES_LEFT | ES_AUTOHSCROLL,
                            0,
							450,
							rc.right-rc.left-14,
							20,
                            search->hDlg,
                            NULL,
                            plgnDllInst,
                            NULL);
	search->hResultsLB = CreateWindowEx(WS_EX_CLIENTEDGE,
							L"LISTBOX",
                            NULL,
                            WS_CHILD | WS_VISIBLE | WS_BORDER | LBS_EXTENDEDSEL | WS_VSCROLL | WS_HSCROLL |
							LBS_HASSTRINGS | LBS_MULTIPLESEL | LBS_NOTIFY | LBS_SORT | LBS_WANTKEYBOARDINPUT,
                            0,
							472,
							rc.right-rc.left-12,
							136,
                            search->hDlg,
                            NULL,
                            plgnDllInst,
                            NULL);
	SendMessage(search->hResultsLB, LB_SETHORIZONTALEXTENT, (rc.right-rc.left)*4, 0);
	SendMessage(search->hInfoEdit,EM_SETLIMITTEXT,55,0);
	//hInfoEditDC = GetDC(hInfoEdit);
	//hInfoEditRC.left = hInfoEditRC.top = 0;
	//hInfoEditRC.right = rc.right-rc.left-12;
	//hInfoEditRC.bottom = 20;
}

VOID CreateOutptBtns(Search *search)
{
 if(!search->hToPanelBTN)
 {	search->hBrowseBTN = CreateWindowEx(WS_EX_CLIENTEDGE,
							L"BUTTON",
                            strngs[48],//"Browse",
                            WS_TABSTOP | WS_VISIBLE | WS_CHILD | WS_BORDER | BS_OWNERDRAW,
                            302,
							426,
							100,
							24,
                            search->hDlg,
                            (HMENU)(IDC_BUTTON_BROWSE_SCH),
                            plgnDllInst,
                            NULL);
	//search->hBrowseBTN=MyButtonGetHWND(MyButtonInit(search->hDlg,strngs[48],IDC_BUTTON_BROWSE_SCH,0,302,426,100,24));
	search->hToPanelBTN = CreateWindowEx(WS_EX_CLIENTEDGE,
							L"BUTTON",
                            strngs[51],//to panel
                            WS_TABSTOP | WS_VISIBLE | WS_CHILD | WS_BORDER | BS_OWNERDRAW,
                            202,
							426,
							100,
							24,
                            search->hDlg,
                            (HMENU)(IDC_BUTTON_TO_PANEL),
                            plgnDllInst,
                            NULL);
	//search->hToPanelBTN=MyButtonGetHWND(MyButtonInit(search->hDlg,strngs[51],IDC_BUTTON_TO_PANEL,0,202,426,100,24));
	search->hEditBTN = CreateWindowEx(WS_EX_CLIENTEDGE,
							L"BUTTON",
                            strngs[49],//"Edit",
                            WS_TABSTOP | WS_VISIBLE | WS_CHILD | WS_BORDER | BS_OWNERDRAW,
                            102,
							426,
							100,
							24,
                            search->hDlg,
							(HMENU)(IDC_BUTTON_EDIT_SCH),
                            plgnDllInst,
                            NULL);
	//search->hEditBTN=MyButtonGetHWND(MyButtonInit(search->hDlg,strngs[49],IDC_BUTTON_EDIT_SCH,0,102,426,100,24));
	search->hViewBTN = CreateWindowEx(WS_EX_CLIENTEDGE,
							L"BUTTON",
                            strngs[50],//"View",
                            WS_TABSTOP | WS_VISIBLE | WS_CHILD | WS_BORDER | BS_OWNERDRAW,
                            2,
							426,
							100,
							24,
                            search->hDlg,
                            (HMENU)IDC_BUTTON_VIEW_SCH,
                            plgnDllInst,
                            NULL);
	//search->hViewBTN=MyButtonGetHWND(MyButtonInit(search->hDlg,strngs[50],IDC_BUTTON_VIEW_SCH,0,2,426,100,24));
 }
 SendMessage(search->hResultsLB,LB_SETSEL,TRUE,0);
 //PostMessage(hDlg,WM_NEXTDLGCTL,IDC_BUTTON_VIEW-3,TRUE);
 //SetFocus(hBrowseBTN);
 //SendMessage(hDlg,DM_SETDEFID,IDC_BUTTON_VIEW-3,0);
}

BOOL BeginSearch(LPVOID pl,Search *search)
{
	search->bStop = FALSE;
	search->iFoundFiles = 0;
	search->iFoundFolders = 0;
	search->iCall++;
	search->ticks[0] = GetTickCount();
	PluginObj *plg=(PluginObj*)pl;

	EnableWindow(GetDlgItem(search->hDlg,IDCANCEL),FALSE);
	GetDlgItems(search);
	FindStrWthFltr fs(item.filtr);
	wchar_t name[MAX_PATH],*pn=&name[0];
	for(wchar_t *rp=&item.rootPath[0]; *rp; rp++)
	{	if(*rp!=0 && *rp!=';')
		{	*pn = *rp;
			++pn;
			continue;
		}
		if(*rp==';')
		{	*pn = 0;
			char ipstrA[32];DWORD dwIp;int iRootStep=3;//3-local node subdir,0-glob net,1-domain grp.,2-local root;
			if(MyInet4StrToDword(name,ipstrA,&dwIp))
			{	int l=MyStringLengthA(ipstrA,32);
				if('\\'==name[0] && '\\'==name[1] && '?'==name[2] && '\\'==name[3] && 
					'U'==name[4] && 'N'==name[5] && 'C'==name[6] && '\\'==name[7] && 
					(0==name[8+l] || ('\\'==name[8+l] && 0==name[9+l])))
				    iRootStep=2;
				else iRootStep=3;
			}
			else iRootStep = plg->state==in_domain_group_folder?1:0;
			//Find filtr match for pn:
			switch(iRootStep)
			{	case 0://global net:
					for(int n=0; n<plg->IPNodesCnt; ++n)
					{	DWORD dw;Ip4Shufl(&dw,(BYTE*)&plg->IPNodes[n].IP);
						FindSelectsItemsNodeRoot(search,fs.GetFullStrLn()?&fs:NULL,dw);
						if(search->bStop) break;
					}
					break;
				case 1://in domain group:
					for(int n=0; n<plg->IPNodesCnt; ++n)
					{	if(plg->IPNodes[n].NETBIOSGROUPNAME[0])
						if(wcsstr(plg->IPNodes[n].NETBIOSGROUPNAME,plg->crntDomainGroup))
						{	DWORD dw;Ip4Shufl(&dw,(BYTE*)&plg->IPNodes[n].IP);
							FindSelectsItemsNodeRoot(search,fs.GetFullStrLn()?&fs:NULL,dw);
						}
						if(search->bStop) break;
					}
					break;
				case 2://local node root:
					FindSelectsItemsNodeRoot(search,fs.GetFullStrLn()?&fs:NULL,dwIp);
					break;
				case 3://local node subdir:
					FindSelectsItemsNodeDir(search,&name[8],fs.GetFullStrLn()?&fs:NULL);
					break;
			}
			pn = &name[0];
			while(*rp==';')
				++rp;
	}	}
	EnableWindow(GetDlgItem(search->hDlg,IDCANCEL),TRUE);
	search->iCall--;wchar_t s[256];
	search->ticks[1] = GetTickCount();
	StringCchPrintf(s,MAX_PATH,strngs[96]/*L"Founded folders: %d, Founded files: %d, elapsed time: %d milliseconds."*/,
					search->iFoundFolders,search->iFoundFiles,search->ticks[1]-search->ticks[0]);
	SetWindowText(search->hInfoEdit,s);
	//ExitThread(0); avval alohida thread edi, shu uchun turibdi.Hozir tez ishlashi
	return TRUE;//uchun asosiy threadga kiritilagn, ya'ni funk qilib chaqiriladur!!!
}

VOID AddToInfoEdit(Search *search,wchar_t* rootPath, WIN32_FIND_DATA& ff)
{
wchar_t s[3*MAX_PATH];
	MyStringCpy(s,MAX_PATH,rootPath);
	wchar_t *p = wcsrchr(s,'\\');
	if(p)++p;else p=&s[0];//if(p) *(p+1) = 0;
	MyStringCpy(p,(int)(MAX_PATH-(p-&s[0])),ff.cFileName);//MyStringCat(s,MAX_PATH,ff.cFileName);
	SetWindowText(search->hInfoEdit,s);
	SendMessage(search->hInfoEdit,WM_PAINT,0,0);
	//DrawText(search->hInfoEditDC,s,-1,&search->hInfoEditRC,DT_RIGHT);
}

extern "C"
{
//rootPath - multibyte, sub - unicode;
BOOL SearchForContainTextW$16(Search *search,wchar_t *rootPath,wchar_t *sub,WIN32_FIND_DATA *pf)
{
	int lnSub = MyStringLength(sub,MAX_PATH);
	if(!lnSub)return FALSE;

	wchar_t path[MAX_PATH];int l=MyStringCpy(path,MAX_PATH,rootPath);
	MyStringCpy(&path[l],MAX_PATH-l,pf->cFileName);//MyStringCat(path,MAX_PATH,pf->cFileName);

	if(item.bFindForText_ASCII)
	{	for(int i=0; i<lnSub; i++)
		{	if(!IsBin(sub[i]))
			{	MessageBox(search->hDlg,strngs[77],strngs[78],MB_OK);//L"Please,use only digit symbols without space.",L"Binary filtr string error:",MB_OK);
				search->bStop=TRUE;
				return FALSE;
		}	}
		if(lnSub%2)
		{	MessageBox(search->hDlg,strngs[79],strngs[80],MB_OK);//L"Please,input pair symbols without space.",L"Binary filtr string length error:",MB_OK);
			search->bStop=TRUE;
			return FALSE;
		}
		lnSub /= 2;
	}

	HANDLE h = CreateFile(path,GENERIC_READ,
						  FILE_SHARE_READ,
						  NULL,
						  OPEN_EXISTING,
						  pf->dwFileAttributes,//|FILE_FLAG_SEQUENTIAL_SCAN,
						  NULL);
	if(INVALID_HANDLE_VALUE==h) return FALSE;

	wchar_t buf[32768];

	int nr = 0, rb = 1, dumLn = lnSub-1;
	while(rb>0)
	{	if(nr)
		{	if(!ReadFile(h,buf+dumLn,32768-dumLn,(DWORD*)&rb,NULL))
				break;
		} else
		{	if(!ReadFile(h,buf,32768,(DWORD*)&rb,NULL))
				break;
		} wchar_t *pbuf = buf;
		if(rb>0)
		{	while(pbuf<buf+rb-dumLn)
			{	BOOL r; if(item.bFindForText_ASCII)
				{	r = (NULL==MyStrCmpBinNW(buf,sub,nr?rb:rb-dumLn,lnSub));
					pbuf += rb-dumLn;
				}
				else
				{	if(item.bFindForText_UpperCase)r=(NULL!=MyStrCmpNotRelUpRegNW(pbuf++,(wchar_t*)sub,lnSub));
					else
					{	r=(NULL!=MyStrCmpNNW(buf,(wchar_t*)sub,nr?rb:rb-dumLn,lnSub));
						pbuf += rb-dumLn;
				}	}
				if(r)
				{	CloseHandle(h);
					//_freea(buf);
					return TRUE;
			}	}
			//Qolgan dumini boshiga ko'chiramiz:
			if(rb) {memcpy(buf, buf + rb - dumLn, dumLn); ++nr;}
			else nr = 0;
	}	}

	CloseHandle(h);
	return FALSE;
}

BOOL SearchForContainText$16(Search *search,wchar_t *rootPath,wchar_t *sub,WIN32_FIND_DATA *pf)
{
	int lnSub = MyStringLength(sub,MAX_PATH);
	if(!lnSub)return FALSE;

	wchar_t path[MAX_PATH];int l=MyStringCpy(path,MAX_PATH,rootPath);
	MyStringCpy(&path[l],MAX_PATH-l,pf->cFileName);//MyStringCat(path,MAX_PATH,pf->cFileName);

	if(item.bFindForText_ASCII)
	{	for(int i=0; i<lnSub; i++)
		{	if(!IsBin(sub[i]))
			{	MessageBox(search->hDlg,strngs[77],strngs[78],MB_OK);//L"Please,use only digit symbols without space.",L"Binary filtr string error:",MB_OK);
				search->bStop=TRUE;
				return FALSE;
		}	}
		if(lnSub%2)
		{	MessageBox(search->hDlg,L"Please,input pair symbols without space.",L"Binary filtr string length error:",MB_OK);
			search->bStop=TRUE;
			return FALSE;
		}
		lnSub /= 2;
	}

	HANDLE h = CreateFile(path,GENERIC_READ,
						  FILE_SHARE_READ,
						  NULL,
						  OPEN_EXISTING,
						  pf->dwFileAttributes,//|FILE_FLAG_SEQUENTIAL_SCAN,
						  NULL);
	if(INVALID_HANDLE_VALUE==h) return FALSE;

	//char *buf = (char*)_malloca(32768);
	//if(!buf) return FALSE;
	wchar_t buf[32768];
//static __declspec(align(32)) char buf[4096];

	int nr = 0, rb = 1, dumLn = lnSub-1;
	while(rb>0)
	{	if(nr)
		{	if(!ReadFile(h,buf+dumLn,32768-dumLn,(DWORD*)&rb,NULL))
				break;
		} else
		{	if(!ReadFile(h,buf,32768,(DWORD*)&rb,NULL))
				break;
		} wchar_t *pbuf = buf;
		if(rb>0)
		{	while(pbuf<buf+rb-dumLn)
			{	BOOL r; if(item.bFindForText_ASCII)
				{	r = (NULL!=MyStrCmpBinNW(buf,sub,nr?rb:rb-dumLn,lnSub));
					pbuf += rb-dumLn;
				}
				else
				{	if(item.bFindForText_UpperCase)r=MyStrCmpNotRelUpRegNW(pbuf++,sub,lnSub);
					else
					{	r=(NULL!=MyStrCmpNNW(buf,sub,nr?rb:rb-dumLn,lnSub));
						pbuf += rb-dumLn;
				}	}
				if(r)
				{	CloseHandle(h);
					//_freea(buf);
					return TRUE;
			}	}
			//Qolgan dumini boshiga ko'chiramiz:
			if(rb) {memcpy(buf, buf + rb - dumLn, dumLn); ++nr;}
			else nr = 0;
	}	}

	CloseHandle(h);
	//pNtClose(h);
	//_freea(buf);
	return FALSE;
}

BOOL SearchForNotContainTextW$16(Search *search,wchar_t *rootPath,wchar_t *sub,WIN32_FIND_DATA *pf)
{
	int lnSub = MyStringLength(sub,MAX_PATH);
	if(!lnSub)return FALSE;

	wchar_t path[MAX_PATH];int l=MyStringCpy(path,MAX_PATH,rootPath);
	MyStringCpy(&path[l],MAX_PATH-l,pf->cFileName);//MyStringCat(path,MAX_PATH,pf->cFileName);

	if(item.bFindForExcldText_ASCII)
	{	for(int i=0; i<lnSub; i++)
		{	if(sub[i]<'0' || sub[i]>'9')
			{	MessageBox(search->hDlg,strngs[77],strngs[78],MB_OK);//L"Please,use only digit symbols without space.",L"Binary filtr string error:",MB_OK);
				search->bStop=TRUE;
				return FALSE;
		}	}
		if(lnSub%2)
		{	MessageBox(search->hDlg,L"Please,input pair symbols without space.",L"Binary filtr string length error:",MB_OK);
			search->bStop=TRUE;
			return FALSE;
		}
		lnSub /= 2;
	}

	HANDLE h = CreateFile(path,GENERIC_READ,
						  FILE_SHARE_READ,
						  NULL,
						  OPEN_EXISTING,
						  pf->dwFileAttributes,
						  NULL);
	if(!h) return FALSE;

	wchar_t *buf = (wchar_t*)_malloca(2*4096);
	if(!buf) return FALSE;
	wchar_t *wbuf = (wchar_t*)_malloca(2*4096);
	if(!wbuf) return FALSE;

	int nr = 4096, rb = 1, dum = 0; wchar_t *pwbuf = wbuf;
	while(rb)
	{	if(!ReadFile(h,buf,nr,(DWORD*)&rb,NULL))break;
		if(!MultiByteToWideChar(AreFileApisANSI()?CP_ACP:CP_OEMCP,MB_PRECOMPOSED,(LPCSTR)buf,rb,pwbuf,rb)) break;
		wchar_t *pwbufCmp = wbuf;
		while(pwbufCmp<wbuf+dum+rb-lnSub+1)//for(int i=0; i<rb-lnSub+1; i++)//if(rb >= lnSub) ning o'zi edi;
		{	BOOL r;/*if(item.bFindForExcldText_ASCII)
				r = MyStrCmpBinN(pwbufCmp++,(wchar_t*)sub,(wchar_t*)(buf+dum+rb-lnSub+1)-pwbufCmp,lnSub);
			else*/
			{	if(item.bFindForExcldText_UpperCase)r=MyStrCmpNotRelUpRegNW(pwbufCmp++,sub,lnSub);
				else r=MyStrCmpNW(pwbufCmp++,sub,lnSub);
			}
			if(r)
			{	CloseHandle(h);
				_freea(buf);
				_freea(wbuf);
				return FALSE;
		}	}
		//Qolgan dumini boshiga ko'chiramiz:
		int ddum = 0;
		while(pwbufCmp<wbuf+dum+rb)//for(int k=rb-lnSub+1; k<rb; k++)
			wbuf[ddum++] = *pwbufCmp++;
		dum = ddum;
		pwbuf = wbuf + dum;
		nr = 4096 - dum;
	}

	CloseHandle(h);
	_freea(buf);
	_freea(wbuf);
	return TRUE;
}

BOOL SearchForNotContainText$16(Search *search,wchar_t *rootPath,wchar_t *sub,WIN32_FIND_DATA *pf)
{
	int lnSub = MyStringLength(sub,MAX_PATH);
	if(!lnSub)return FALSE;

	wchar_t path[MAX_PATH];int l=MyStringCpy(path,MAX_PATH,rootPath);
	MyStringCpy(&path[l],MAX_PATH-l,pf->cFileName);//MyStringCat(path,MAX_PATH,pf->cFileName);

	if(item.bFindForExcldText_ASCII)
	{	for(int i=0; i<lnSub; i++)
		{	if(sub[i]<'0' || sub[i]>'9')
			{	MessageBox(search->hDlg,strngs[77],strngs[78],MB_OK);//L"Please,use only digit symbols without space.",L"Binary filtr string error:",MB_OK);
				search->bStop=TRUE;
				return FALSE;
		}	}
		if(lnSub%2)
		{	MessageBox(search->hDlg,L"Please,input pair symbols without space.",L"Binary filtr string length error:",MB_OK);
			search->bStop=TRUE;
			return FALSE;
		}
		lnSub /= 2;
	}

	HANDLE h = CreateFile(path,GENERIC_READ,
						  FILE_SHARE_READ,
						  NULL,
						  OPEN_EXISTING,
						  pf->dwFileAttributes,
						  NULL);
	if(!h) return FALSE;

	wchar_t *buf = (wchar_t*)_malloca(2*4096);
	if(!buf) return FALSE;

	int nr = 4096, rb = 1, dum = 0; wchar_t *pbuf = buf;
	while(rb)
	{	if(!ReadFile(h,pbuf,nr,(DWORD*)&rb,NULL))break;
		wchar_t *pbufCmp = buf;
		while(pbufCmp<buf+dum+rb-lnSub+1)//for(int i=0; i<rb-lnSub+1; i++)//if(rb >= lnSub) ning o'zi edi;
		{	BOOL r; if(item.bFindForExcldText_ASCII)
			{	r = (NULL!=MyStrCmpBinNW(pbufCmp,sub,(int)(buf+dum+rb-lnSub+1-pbufCmp),lnSub));
				pbufCmp += buf+dum+rb-lnSub+1-pbufCmp;
			}
			else
			{	if(item.bFindForExcldText_UpperCase)r=MyStrCmpNotRelUpRegNW(pbufCmp++,sub,lnSub);
				else r=MyStrCmpNW(pbufCmp++,sub,lnSub);
			}
			if(r)
			{	CloseHandle(h);
				_freea(buf);
				return FALSE;
		}	}
		//Qolgan dumini boshiga ko'chiramiz:
		int ddum = 0;
		while(pbufCmp<buf+dum+rb)//for(int k=rb-lnSub+1; k<rb; k++)
			buf[ddum++] = *pbufCmp++;
		dum = ddum;
		pbuf = buf + dum;
		nr = 4096 - dum;
	}

	CloseHandle(h);
	_freea(buf);
	return TRUE;
}
}//extern "C"

//Qo'shimcha parametrlar asosida qidirish:
BOOL CheckOtherSearchConditionsDirectFolder(Search *search,wchar_t* rootPath,WIN32_FIND_DATA *pf, int type)
{
DWORD bCndtns = 0x00000000, bCndtnsMustbe = 0x00000000;

	if(0==type)//file
	{//1.1-Page, Filtr va RootPath -->> BeginSearch da;
	 //2.1-Page, Find for text:
	 if(item.bFindForText)
	 {if(item.FindForTextLn)
	  {bCndtnsMustbe |= 1;
	   FindStrWthFltr fs(item.FindForText);
	   for(int s=0; s<fs.GetNumStrs(); s++)
	   {	wchar_t *sub=fs.GetSubstr(s);
			if(item.bFindForText_Unicode?SearchForContainTextW$16(search,rootPath,(wchar_t*)sub,pf):SearchForContainText$16(search,rootPath,sub,pf))
			{	bCndtns |= 1;//[0] = TRUE;
		 		goto ToNotContainText;
	  }}}	}
	 //3.1-Page, Find for do not contain text:
ToNotContainText:
	 if(item.bFindForExcldText)
	 {if(item.FindForExcldTextLn)
	  {bCndtnsMustbe |= 2;
	   FindStrWthFltr fs(item.FindForExcldText);
	   for(int s=0; s<fs.GetNumStrs(); s++)
	   {	wchar_t *sub=fs.GetSubstr(s);
			if(item.bFindForExcldText_Unicode?SearchForNotContainTextW$16(search,rootPath,(wchar_t*)sub,pf):SearchForNotContainText$16(search,rootPath,sub,pf))
		    {	bCndtns |= 2;//[0] = TRUE;
		 		goto ToNotContainText;
	  }}}   }

	 if(item.bFileSz)
	 {if(item.sFileSzEqu[0])
	  { if(item.sFileSz[0])
		{	bCndtnsMustbe |= 4;
	  		if(CB_ERR==item.iFileSzQual) bCndtns |= 0x00000003;//[2] = TRUE;
			else
			{	unsigned __int64 sz = MyAtoU64(item.sFileSz);
				for(int i=0; i<item.iFileSzQual; i++)
					sz = sz <<  10;
				unsigned __int64 fsz = ((unsigned __int64)pf->nFileSizeHigh << 32) + (unsigned __int64)pf->nFileSizeLow;
				if('>'==item.sFileSzEqu[0])
				{	if(sz < fsz)
						bCndtns |= 4;
					//bCndtns[2] = (sz < fsz);
				}
				else if('<'==item.sFileSzEqu[0])
				{	if(sz > fsz)
						bCndtns |= 4;
					//bCndtns[2] = (sz > fsz);
				}
				else //if('='==item.sFileSzEqu[0])
				{	if(sz == fsz)
						bCndtns |= 4;
					//bCndtns[2] = (sz == fsz);
	} }}}	}	}
	else//if(1==0)//folder
	{//1.1-Page, Filtr va RootPath -->> BeginSearch da;
	 //2.1-Page, Find for text:
	 //if(BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_TEXT_SEACH),BM_GETCHECK,0,0))
	 if(item.bFindForText)
		 return FALSE;
	 //3.1-Page, Find for do not contain text:
	 if(item.bFindForExcldText)
		 return FALSE;
	 //4.2-Page, Find for alternative name:
	 if(item.bFindForAlterName)
		 return FALSE;
	 if(item.bFileSz)
		 return FALSE;
	}

	//4.2-Page, Find for alternative name:
//FindAlternName:
	if(item.bFindForAlterName)
	{if(item.altName[0])
	 {	bCndtnsMustbe |= 8;
		if(0==wcscmp(pf->cAlternateFileName,item.altName))
			bCndtns |= 8;
	}}

	//5.2-Page, Find for creation time before:
	if(item.bCrTimeBef)
	{	bCndtnsMustbe |= 16;
		if(-1!=CmpFILETIMEs(&item.CrTimeBef,&pf->ftCreationTime))
			bCndtns |= 16;
	}

	//6.2-Page, Find for creation time after:
	if(item.bCrTimeAft)
	{	bCndtnsMustbe |= 32;
		if(1!=CmpFILETIMEs(&item.CrTimeAft,&pf->ftCreationTime))
			bCndtns |= 32;
	}

	//7.2-Page, Find for creation time between:
	if(item.bCrTimeBet)
	{	bCndtnsMustbe |= 64;
		if(1==CmpFILETIMEsBetween(&item.CrTimeBet[0],&item.CrTimeBet[1],&pf->ftCreationTime))
			bCndtns |= 64;
	}

	//8.2-Page, Find for last access time before:
	if(item.bLstAccTimeBef)
	{	bCndtnsMustbe |= 128;
		if(-1!=CmpFILETIMEs(&item.LstAccTimeBef,&pf->ftCreationTime))
			bCndtns |= 128;
	}

	//9.2-Page, Find last access time after:
	if(item.bLstAccTimeAft)
	{	bCndtnsMustbe |= 256;
		if(1!=CmpFILETIMEs(&item.LstAccTimeAft,&pf->ftLastAccessTime))
			bCndtns |= 256;
	}

	//10.2-Page, Find for last access time between:
	if(item.bLastAccTimeBet)
	{	bCndtnsMustbe |= 512;
		if(1==CmpFILETIMEsBetween(&item.LastAccTimeBet[0],&item.LastAccTimeBet[1],&pf->ftLastAccessTime))
			bCndtns |= 512;
	}

	//11.2-Page, Find for last write time before:
	if(item.bLstWrTimeBef)
	{	bCndtnsMustbe |= 1024;
		if(-1!=CmpFILETIMEs(&item.LstWrTimeBef,&pf->ftLastWriteTime))
			bCndtns |= 1024;
	}

	//12.2-Page, Find last write time after:
	if(item.bLstWrTimeAft)
	{	bCndtnsMustbe |= 2048;
		if(1!=CmpFILETIMEs(&item.LstWrTimeAft,&pf->ftLastWriteTime))
			bCndtns |= 2048;
	}

	//13.2-Page, Find for last write time between:
	if(item.bLstWrTimeBet)
	{	bCndtnsMustbe |= 4096;
		if(1==CmpFILETIMEsBetween(&item.LstWrTimeBet[0],&item.LstWrTimeBet[1],&pf->ftLastWriteTime))
			bCndtns |= 4096;
	}

	//14.2-Page, Find for file attribute:
	if(item.bFileAttr)
	{	if(item.bFileAttArchive)
		{	bCndtnsMustbe |= 8192;
			if(item.bFileAttArchiveEx)
			{	if((FILE_ATTRIBUTE_ARCHIVE & pf->dwFileAttributes) == 0)
					bCndtns |= 8192;
			}
			else
			{	if((FILE_ATTRIBUTE_ARCHIVE & pf->dwFileAttributes) != 0)
					bCndtns |= 8192;
		}	}
		if(item.bFileAttCompr)
		{	bCndtnsMustbe |= 16384;
			if(item.bFileAttComprEx)
			{	if((FILE_ATTRIBUTE_COMPRESSED & pf->dwFileAttributes) == 0)
					bCndtns |= 16384;
			}
			else
			{	if((FILE_ATTRIBUTE_COMPRESSED & pf->dwFileAttributes) != 0)
					bCndtns |= 16384;
		}	}
		if(item.bFileAttDevice)
		{	bCndtnsMustbe |= 32768;
			if(item.bFileAttDeviceEx)
			{	if((FILE_ATTRIBUTE_DEVICE & pf->dwFileAttributes) == 0)
					bCndtns |= 32768;
			}
			else
			{	if((FILE_ATTRIBUTE_DEVICE & pf->dwFileAttributes) != 0)
					bCndtns |= 32768;
			}
		}
		if(item.bFileAttDir)
		{	bCndtnsMustbe |= 65536;
			if(item.bFileAttDirEx)
			{	if((FILE_ATTRIBUTE_DIRECTORY & pf->dwFileAttributes) == 0)
					bCndtns |= 65536;
			}
			else
			{	if((FILE_ATTRIBUTE_DIRECTORY & pf->dwFileAttributes) != 0)
					bCndtns |= 65536;
		}	}
		if(item.bFileAttEncr)
		{	bCndtnsMustbe |= 132072;
			if(item.bFileAttEncrEx)
			{	if((FILE_ATTRIBUTE_ENCRYPTED & pf->dwFileAttributes) == 0)
					bCndtns |= 132072;
			}
			else
			{	if((FILE_ATTRIBUTE_ENCRYPTED & pf->dwFileAttributes) != 0)
					bCndtns |= 132072;
		}	}
		if(item.bFileAttHidden)
		{	bCndtnsMustbe |= 262144;
			if(item.bFileAttHiddenEx)
			{	if((FILE_ATTRIBUTE_HIDDEN & pf->dwFileAttributes) == 0)
					bCndtnsMustbe |= 262144;
			}
			else
			{	if((FILE_ATTRIBUTE_HIDDEN & pf->dwFileAttributes) != 0)
					bCndtnsMustbe |= 262144;
		}	}
		if(item.bFileAttNormal)
		{	bCndtnsMustbe |= 524288;
			if(item.bFileAttNormalEx)
			{	if((FILE_ATTRIBUTE_NORMAL & pf->dwFileAttributes) == 0)
					bCndtns |= 524288;
			}
			else
			{	if((FILE_ATTRIBUTE_NORMAL & pf->dwFileAttributes) != 0)
					bCndtns |= 524288;
		}	}
		if(item.bFileAttNotInd)
		{	bCndtnsMustbe |= 1048576;
			if(item.bFileAttNotIndEx)
			{	if((FILE_ATTRIBUTE_NOT_CONTENT_INDEXED & pf->dwFileAttributes) == 0)
					bCndtns |= 1048576;
			}
			else
			{	if((FILE_ATTRIBUTE_NOT_CONTENT_INDEXED & pf->dwFileAttributes) != 0)
					bCndtns |= 1048576;
		}	}
		if(item.bFileAttOffl)
		{	bCndtnsMustbe |= 2097152;
			if(item.bFileAttOfflEx)
			{	if((FILE_ATTRIBUTE_OFFLINE & pf->dwFileAttributes) == 0)
					bCndtns |= 2097152;
			}
			else
			{	if((FILE_ATTRIBUTE_OFFLINE & pf->dwFileAttributes) != 0)
					bCndtns |= 2097152;
		}	}
		if(item.bFileAttReadOnly)
		{	bCndtnsMustbe |= 4194304;
			if(item.bFileAttReadOnlyEx)
			{	if((FILE_ATTRIBUTE_READONLY & pf->dwFileAttributes) == 0)
					bCndtns |= 4194304;
			}
			else
			{	if((FILE_ATTRIBUTE_READONLY & pf->dwFileAttributes) != 0)
					bCndtns |= 4194304;
		}	}
		if(item.bFileAttRepPt)
		{	bCndtnsMustbe |= 8388608;
			if(item.bFileAttRepPtEx)
			{	if((FILE_ATTRIBUTE_REPARSE_POINT & pf->dwFileAttributes) == 0)
					bCndtns |= 8388608;
			}
			else
			{	if((FILE_ATTRIBUTE_REPARSE_POINT & pf->dwFileAttributes) != 0)
					bCndtns |= 8388608;
		}	}
		if(item.bFileAttSparseFile)
		{	bCndtnsMustbe |= 16777216;
			if(item.bFileAttSparseFileEx)
			{	if((FILE_ATTRIBUTE_SPARSE_FILE & pf->dwFileAttributes) == 0)
					bCndtns |= 16777216;
			}
			else
			{	if((FILE_ATTRIBUTE_SPARSE_FILE & pf->dwFileAttributes) != 0)
					bCndtns |= 16777216;
		}	}
		if(item.bFileAttSys)
		{	bCndtnsMustbe |= 33554432;
			if(item.bFileAttSysEx)
			{	if((FILE_ATTRIBUTE_SYSTEM & pf->dwFileAttributes) == 0)
					bCndtns |= 33554432;
			}
			else
			{	if((FILE_ATTRIBUTE_SYSTEM & pf->dwFileAttributes) != 0)
					bCndtns |= 33554432;
		}	}
		if(item.bFileAttTemp)
		{	bCndtnsMustbe |= 67108864;
			if(item.bFileAttTempEx)
			{	if((FILE_ATTRIBUTE_TEMPORARY & pf->dwFileAttributes) == 0)
					bCndtns |= 67108864;
			}
			else
			{	if((FILE_ATTRIBUTE_TEMPORARY & pf->dwFileAttributes) != 0)
					bCndtns |= 67108864;
		}	}
		if(item.bFileAttVirt)
		{	bCndtnsMustbe |= 134217728;
			if(item.bFileAttVirtEx)
			{	if((FILE_ATTRIBUTE_VIRTUAL & pf->dwFileAttributes) == 0)
					bCndtns |= 134217728;
			}
			else
			{	if((FILE_ATTRIBUTE_VIRTUAL & pf->dwFileAttributes) != 0)
					bCndtns |= 134217728;
	}	}	}

	//Hamma usloviyalarni tekshirib chiqdik, endi qaytamiz:
	return (bCndtnsMustbe^bCndtns ? FALSE : TRUE);
}

VOID AddToResultsLB(Search *search,WIN32_FIND_DATA* ff,wchar_t *rootPath)
{
	if(!search->hResultsLB) return;
	wchar_t fullName[MAX_PATH+36];
	if(FILE_ATTRIBUTE_DIRECTORY & ff->dwFileAttributes)//dir
	{	if(!-CheckOtherSearchConditionsDirectFolder(search,rootPath,ff,1)) return;
		fullName[0]='<';//'[';
		int l=1+MyStringCpy(&fullName[1],MAX_PATH,rootPath);
		fullName[l++]='>';fullName[l]=0;
		++search->iFoundFolders;
	}
	else//file
	{	if(!-CheckOtherSearchConditionsDirectFolder(search,rootPath,ff,1)) return;
		MyStringCpy(fullName,MAX_PATH,rootPath);
		++search->iFoundFolders;
	}
	SendMessageW(search->hResultsLB,LB_ADDSTRING,0,(LPARAM)fullName);
	//SendMessage(search->hResultsLB,WM_PAINT,0,0);
}

VOID SetTabPage(HWND hDlg, int iTabPage)
{
switch(iTabPage)
{
 case 0: default:
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ALTERNATIVE_NAME),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_ALTERNATIVE_FILE_NAME),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_CREATE_TIME_BEFORE),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_CREATE_TIME_AFTER),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_DATE),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_DATE2),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_DATE_AFTER),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_DATE_AFTER2),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_CREATE_TIME_BETWEEN),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_LAST_ACCESS_TIME_BEFORE),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_LAST_ACCESS_TIME_AFTER),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE2),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_AFTER),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_AFTER2),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_LAST_ACCESS_TIME_BETWEEN),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_LAST_WRITE_TIME_BEFORE),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_LAST_WRITE_TIME_AFTER),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE2),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_AFTER),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_AFTER2),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_LAST_WRITE_TIME_BETWEEN),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_FILE_SIZE),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_COMBO_FILE_SIZE_EQUATION),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_FILE_SIZE),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_FILE_SIZE),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_COMBO_FILE_SIZE_QUANTITY),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_FILE_ATTRIBUTE),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_ARCHIVE),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_ARCHIVE_EX),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_COMPRESSED),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_COMPRESSED_EX),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_DEVICE),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_DEVICE_EX),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_DIRECTORY),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_DIRECTORY_EX),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_ENCRYPTED),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_ENCRYPTED_EX),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_HIDDEN),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_HIDDEN_EX),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_NORMAL),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_NORMAL_EX),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_NOT_INDEXED),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_NOT_INDEXED_EX),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_OFFLINE),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_OFFLINE_EX),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_READ_ONLY),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_READ_ONLY_EX),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_REPARSE_POINT),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_REPARSE_POINT_EX),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_SPARSE_FILE),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_SPARSE_FILE_EX),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_SYSTEM),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_SYSTEM_EX),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_TEMPORARY),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_TEMPORARY_EX),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_VIRTUAL),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_VIRTUAL_EX),SW_HIDE);

 	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_BETWEEN_DATE),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_BETWEEN_TIME),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_BETWEEN_DATE2),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_BETWEEN_TIME2),SW_HIDE);
		  
 	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_BETWEEN),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_TIME_BETWEEN),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_BETWEEN2),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_TIME_BETWEEN2),SW_HIDE);

 	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_BETWEEN),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_TIME_BETWEEN),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_BETWEEN2),SW_HIDE);
 	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_TIME_BETWEEN2),SW_HIDE);

	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_DAY),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_MOONS),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_YEAR),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_DAY),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_MOONS),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_YEAR),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_DAY),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_MOONS),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_YEAR),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_DAY),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_MOON),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_YEAR),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_DAY),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_MOON),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_YEAR),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_DAY),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_MOON),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_YEAR),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_DAY),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_MOON),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_YEAR),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_DAY),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_MOON),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_YEAR),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_DAY),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_MOON),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_YEAR),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_DAY),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_MOON),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_YEAR),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_DAY),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_MOON),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_YEAR),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_DAY),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_MOON),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_YEAR),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_HOUR),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_MIN),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_SEC),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_MILS),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_HOUR),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_MIN),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_SEC),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_MILS),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_HOUR),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_MIN),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_SEC),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_MILS),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_HOUR),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_MIN),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_SEC),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_MILS),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_HOUR),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_MIN),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_SEC),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_MILS),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_HOUR),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_MIN),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_SEC),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_MILS),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_HOUR),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_MIN),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_SEC),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_MILS),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_HOUR),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_MIN),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_SEC),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_MILS),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_HOUR),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_MIN),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_SEC),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_MILS),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_HOUR),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_MIN),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_SEC),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_MILS),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_HOUR),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_MIN),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_SEC),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_MILS),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_HOUR),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_MIN),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_SEC),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_MILS),SW_HIDE);

	//Page1:
	ShowWindow(GetDlgItem(hDlg,IDC_STATIC_SCH1),SW_SHOW); 
	ShowWindow(GetDlgItem(hDlg,IDC_STATIC_SCH2),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_COMBO_SEARCH_NAME),SW_SHOW);
	//ShowWindow(GetDlgItem(hDlg,IDC_BUTTON_ADD_PATH),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_COMBO_SEARCH_PATH),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_TEXT_SEACH),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_COMBO_SEARCH_FOR_TEXT),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_UNICODE_OR_MULTIBYTE),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_BINARY_OR_CHARACTER),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_REGISTR_CAPS),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_NO_TEXT_SEACH),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_COMBO_SEARCH_NOT_TEXT),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_UNICODE_OR_MULTIBYTE2),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_BINARY_OR_CHARACTER2),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_REGISTR_CAPS2),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_SAVE_RESULTS),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ENUM_SUBDIR),SW_SHOW);
		
	//ShowWindow(GetDlgItem(hDlg,IDC_BUTTON_ADD_DISK),SW_SHOW);
	//ShowWindow(GetDlgItem(hDlg,IDC_COMBO_METHOD),SW_SHOW);	
 break;
 case 1:
	ShowWindow(GetDlgItem(hDlg,IDC_STATIC_SCH1),SW_HIDE); 
	ShowWindow(GetDlgItem(hDlg,IDC_STATIC_SCH2),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_COMBO_SEARCH_NAME),SW_HIDE);
	//ShowWindow(GetDlgItem(hDlg,IDC_BUTTON_ADD_PATH),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_COMBO_SEARCH_PATH),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_TEXT_SEACH),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_COMBO_SEARCH_FOR_TEXT),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_UNICODE_OR_MULTIBYTE),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_BINARY_OR_CHARACTER),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_REGISTR_CAPS),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_NO_TEXT_SEACH),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_COMBO_SEARCH_NOT_TEXT),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_UNICODE_OR_MULTIBYTE2),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_BINARY_OR_CHARACTER2),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_REGISTR_CAPS2),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_BUTTON_ADD_DISK),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_SAVE_RESULTS),SW_HIDE);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ENUM_SUBDIR),SW_HIDE);
	//ShowWindow(GetDlgItem(hDlg,IDC_COMBO_METHOD),SW_SHOW);

	//Page1:
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ALTERNATIVE_NAME),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_ALTERNATIVE_FILE_NAME),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_CREATE_TIME_BEFORE),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_CREATE_TIME_AFTER),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_DATE),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_DATE2),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_DATE_AFTER),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_DATE_AFTER2),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_CREATE_TIME_BETWEEN),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_LAST_ACCESS_TIME_BEFORE),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_LAST_ACCESS_TIME_AFTER),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE2),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_AFTER),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_AFTER2),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_LAST_ACCESS_TIME_BETWEEN),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_LAST_WRITE_TIME_BEFORE),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_LAST_WRITE_TIME_AFTER),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE2),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_AFTER),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_AFTER2),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_LAST_WRITE_TIME_BETWEEN),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_FILE_SIZE),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_COMBO_FILE_SIZE_EQUATION),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_FILE_SIZE),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_FILE_SIZE),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_COMBO_FILE_SIZE_QUANTITY),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_FILE_ATTRIBUTE),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_ARCHIVE),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_ARCHIVE_EX),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_COMPRESSED),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_COMPRESSED_EX),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_DEVICE),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_DEVICE_EX),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_DIRECTORY),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_DIRECTORY_EX),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_ENCRYPTED),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_ENCRYPTED_EX),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_HIDDEN),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_HIDDEN_EX),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_NORMAL),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_NORMAL_EX),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_NOT_INDEXED),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_NOT_INDEXED_EX),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_OFFLINE),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_OFFLINE_EX),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_READ_ONLY),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_READ_ONLY_EX),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_REPARSE_POINT),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_REPARSE_POINT_EX),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_SPARSE_FILE),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_SPARSE_FILE_EX),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_SYSTEM),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_SYSTEM_EX),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_TEMPORARY),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_TEMPORARY_EX),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_VIRTUAL),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_CHECK_ATTRIBUTE_VIRTUAL_EX),SW_SHOW);

 	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_BETWEEN_DATE),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_BETWEEN_TIME),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_BETWEEN_DATE2),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_CREATE_BETWEEN_TIME2),SW_SHOW);
		  
 	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_BETWEEN),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_TIME_BETWEEN),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_DATE_BETWEEN2),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_ACCESS_TIME_BETWEEN2),SW_SHOW);

 	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_BETWEEN),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_TIME_BETWEEN),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_DATE_BETWEEN2),SW_SHOW);
 	ShowWindow(GetDlgItem(hDlg,IDC_EDIT_LAST_WRITE_TIME_BETWEEN2),SW_SHOW);

	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_DAY),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_MOONS),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_YEAR),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_DAY),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_MOONS),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_YEAR),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_DAY),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_MOONS),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_YEAR),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_DAY),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_MOON),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_YEAR),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_DAY),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_MOON),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_YEAR),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_DAY),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_MOON),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_YEAR),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_DAY),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_MOON),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_YEAR),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_DAY),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_MOON),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_YEAR),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_DAY),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_MOON),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_YEAR),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_DAY),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_MOON),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_YEAR),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_DAY),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_MOON),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_YEAR),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_DAY),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_MOON),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_YEAR),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_HOUR),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_MIN),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_SEC),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBEF_MILS),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_HOUR),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_MIN),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_SEC),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRTBET_MILS),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_HOUR),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_MIN),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_SEC),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBEF_MILS),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_HOUR),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_MIN),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_SEC),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSTBET_MILS),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_HOUR),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_MIN),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_SEC),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBEF_MILS),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_HOUR),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_MIN),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_SEC),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWTBET_MILS),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_HOUR),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_MIN),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_SEC),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRAFT_MILS),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_HOUR),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_MIN),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_SEC),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_CRBET_MILS),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_HOUR),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_MIN),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_SEC),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSAFT_MILS),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_HOUR),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_MIN),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_SEC),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSABET_MILS),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_HOUR),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_MIN),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_SEC),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRAFT_MILS),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_HOUR),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_MIN),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_SEC),SW_SHOW);
	ShowWindow(GetDlgItem(hDlg,IDC_SPIN_LSWRBET_MILS),SW_SHOW);

break;
}}

//ret int for EndDialog code,1-all items in the one path,plg shouldnt be detached;
//							 2-all items not in the one path,plg should be detached;
/*int BuildSearchResultsToPanel(HWND hDlg)
{
PluginObj *plg = GetWindowLong(hDlg,GWL_USERDATA);
	if(!plg)return 0;//no change, EndDialog(0);

//1.Calc the size:
	int sz=sizeof(int);
	int iLBCnt=SendMessage(hLB,(UINT)LB_GETCOUNT,0,0);
	if(LB_ERR==iLBCnt) return;
	for(int i=0; i<iLBCnt; i++)
		sz += sizeof(wchar_t)*(1+SendMessage(hLB,(UINT)LB_GETTEXTLEN,i,0));
	sz += 2*sizeof(wchar_t);//for double null termination;
	//2.Allocateing buffer:
	if(LBListBuf)LBListBuf=(wchar_t*)realloc(LBListBuf,sz);
	else LBListBuf = (wchar_t*)malloc(sz);
	//3.Fill memory:
	wchar_t *pBuf = (wchar_t*)LBListBuf;
	*((int*)(pBuf))=iLBCnt;
	pBuf = (wchar_t*)(((char*)pBuf) + sizeof(int));
	for(int i=0; i<iLBCnt; i++)
	{	int r = SendMessage(hLB,(UINT)LB_GETTEXT,i,(LPARAM)pBuf);
		if(LB_ERR==r) break;
		pBuf += r+1;
		if(pBuf>=LBListBuf+sz)break;
	}
	*pBuf++ = 0;
	*pBuf = 0;


	if(plg->srchResltBuf)
}*/

TSearch::TSearch():LBListBuf(NULL),hInfoEdit(0),hToPanelBTN(0),hViewBTN(0),hEditBTN(0),hBrowseBTN(0),
		minWidth(580),minHeight(486),minHeightAftCrLB(638),hResultsLB(0)
{
}

TSearch::~TSearch()
{
	if(LBListBuf) free(LBListBuf);
	LBListBuf=NULL;
}

VOID TSearch::LoadLBList(HWND hLB)
{
	//1.Calc the size:
	wchar_t *pBuf = LBListBuf;
	int *cnt = (int*)pBuf;
	pBuf = (wchar_t*)((char*)pBuf + sizeof(int));
	for(int i=0; i<(*cnt); i++)
	{	int ln=(int)wcslen(pBuf);
		if(*pBuf!='<')//dir
		{	if(IsFileExist(pBuf))
				if(LB_ERR==SendMessageW(hLB,(UINT)LB_ADDSTRING,0,(LPARAM)pBuf))break;
		}
		else
		{	*(pBuf+ln-1)=0;
			if(IsDirExist(pBuf+1))
			{	*(pBuf+ln-1)='>';
				if(LB_ERR==SendMessageW(hLB,(UINT)LB_ADDSTRING,0,(LPARAM)pBuf))break;
		}	}
		pBuf += ln+1;
}	}

VOID TSearch::SaveLBListBuf(HWND hLB,int selectToUp)
{
	//1.Calc the size:
	int sz=sizeof(int);
	int iLBCnt=(int)SendMessage(hLB,(UINT)LB_GETCOUNT,0,0);
	if(LB_ERR==iLBCnt) return;
	for(int i=0; i<iLBCnt; i++)
		sz += sizeof(wchar_t)*(1+(int)SendMessage(hLB,(UINT)LB_GETTEXTLEN,i,0));
	sz += 2*sizeof(wchar_t);//for double null termination;
	//2.Allocateing buffer:
	if(LBListBuf)LBListBuf=(wchar_t*)realloc(LBListBuf,sz);
	else LBListBuf = (wchar_t*)malloc(sz);
	//3.Fill memory:
	wchar_t *pBuf = (wchar_t*)LBListBuf;
	*((int*)(pBuf))=iLBCnt;
	pBuf = (wchar_t*)(((char*)pBuf) + sizeof(int));
	int sel=-1;if(1==selectToUp)
	{	sel=(int)SendMessage(hLB,LB_GETCURSEL,0,0);
		int r = (int)SendMessage(hLB,(UINT)LB_GETTEXT,sel,(LPARAM)pBuf);
		pBuf += r+1;
	}
	for(int i=0; i<iLBCnt; i++)
	{	if(sel==i)continue;
		int r = (int)SendMessage(hLB,(UINT)LB_GETTEXT,i,(LPARAM)pBuf);
		if(LB_ERR==r) break;
		pBuf += r+1;
		if(pBuf>=LBListBuf+sz)break;
	}
	*pBuf++ = 0;
	*pBuf = 0;
}

TSearchItem::TSearchItem():bFindForText(FALSE),FindForTextLn(0),
	bFindForText_Unicode(FALSE),bFindForText_ASCII(FALSE),
	bFindForText_UpperCase(FALSE),bFindForExcldText(FALSE),
	FindForExcldTextLn(0),bFindForExcldText_Unicode(FALSE),
	bFindForExcldText_ASCII(FALSE),bFindForExcldText_UpperCase(FALSE),
	bFindForAlterName(FALSE),bCrTimeBef(FALSE),bCrTimeAft(FALSE),
	bCrTimeBet(FALSE),bLastAccTimeBet(FALSE),bLstAccTimeBef(FALSE),
	bLstAccTimeAft(FALSE),bLstWrTimeBef(FALSE),bLstWrTimeAft(FALSE),
	bLstWrTimeBet(FALSE),bFileSz(FALSE),iFileSzQual(0),
	bFileAttr(FALSE),bFileAttArchive(FALSE),bFileAttCompr(FALSE),
	bFileAttDevice(FALSE),bFileAttDir(FALSE),bFileAttEncr(FALSE),
	bFileAttHidden(FALSE),bFileAttNormal(FALSE),bFileAttNotInd(FALSE),
	bFileAttOffl(FALSE),bFileAttReadOnly(FALSE),bFileAttRepPt(FALSE),
	bFileAttSparseFile(FALSE),bFileAttSys(FALSE),bFileAttTemp(FALSE),
	bFileAttVirt(FALSE),
	bFileAttArchiveEx(FALSE),bFileAttComprEx(FALSE),
	bFileAttDeviceEx(FALSE),bFileAttDirEx(FALSE),bFileAttEncrEx(FALSE),
	bFileAttHiddenEx(FALSE),bFileAttNormalEx(FALSE),bFileAttNotIndEx(FALSE),
	bFileAttOfflEx(FALSE),bFileAttReadOnlyEx(FALSE),bFileAttRepPtEx(FALSE),
	bFileAttSparseFileEx(FALSE),bFileAttSysEx(FALSE),bFileAttTempEx(FALSE),
	bFileAttVirtEx(FALSE)
{
	filtr[0]=0;
	rootPath[0]=0;
	FindForText[0]=0;
	FindForExcldText[0]=0;
	altName[0]=0;
	GetSystemTimeAsFileTime(&CrTimeBef);
	GetSystemTimeAsFileTime(&CrTimeAft);
	GetSystemTimeAsFileTime(&CrTimeBet[0]);
	GetSystemTimeAsFileTime(&CrTimeBet[1]);
	GetSystemTimeAsFileTime(&LstAccTimeBef);
	GetSystemTimeAsFileTime(&LstAccTimeAft);
	GetSystemTimeAsFileTime(&LastAccTimeBet[0]);
	GetSystemTimeAsFileTime(&LastAccTimeBet[1]);
	GetSystemTimeAsFileTime(&LstWrTimeBef);
	GetSystemTimeAsFileTime(&LstWrTimeAft);
	GetSystemTimeAsFileTime(&LstWrTimeBet[0]);
	GetSystemTimeAsFileTime(&LstWrTimeBet[1]);
	sFileSzEqu[0]=0;
	sFileSz[0]=0;
}