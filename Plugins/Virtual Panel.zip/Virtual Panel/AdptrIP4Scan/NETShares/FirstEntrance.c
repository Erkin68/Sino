#include "Winsock2.h"
#include <ws2tcpip.h>
#include "Lm.h"
#include "..\Plugins_C.h"
#include "..\..\..\..\Operations\MyShell\MyShellC.h"


wchar_t* GetNodeNBUName(PluginObj* plg,DWORD dwIP,int itemId,int *nodeNumInList)
{
int n;DWORD dw;
	if(itemId>0 && itemId<plg->IPNodesCnt)
	{	if(0!=plg->IPNodes[itemId].NETBIOSNAME[0])
		{	*nodeNumInList = itemId;
			return &plg->IPNodes[itemId].NETBIOSNAME[0];
		}
		return 0;
	}
	//else
//tIPNodes *P = &plg->IPNodes[itemId];
	Ip4Shufl(&dw,(BYTE*)&dwIP);
	for(n=0; n<plg->IPNodesCnt; ++n)
	{	if(plg->IPNodes[n].IP == dw)
		{	if(0!=plg->IPNodes[n].NETBIOSNAME[0])
			{	*nodeNumInList = n;
				return &plg->IPNodes[n].NETBIOSNAME[0];//-1;
			}//else
			return 0;
	}	}
	return 0;//-2;

/*	if(dw < plg->dwIPFrom)return -1;
	if(dw > plg->dwIPTo)return -2;
	n = dw-plg->dwIPFrom;
	if(0!=plg->IPNodes[n].NETBIOSNAME[0])
	{	*nodeNumInList = n;
		return -3;
	}
	return 0;*/
}

wchar_t* GetNodeGroupName(PluginObj* plg,DWORD dwIP,int *nodeNumInList)
{
//tIPNodes *P;
int n;DWORD dw;Ip4Shufl(&dw,(BYTE*)&dwIP);
	for(n=0; n<plg->IPNodesCnt; ++n)
	{	if(plg->IPNodes[n].IP == dw)
		{	//P=&plg->IPNodes[n];
			if(0!=plg->IPNodes[n].NETBIOSGROUPNAME[0])
			{	*nodeNumInList = n;
				return &plg->IPNodes[n].NETBIOSGROUPNAME[0];
			}//else
			return 0;
	}	}
	return 0;

/*	if(dw < plg->dwIPFrom)return -1;
	if(dw > plg->dwIPTo)return -2;
	n = dw-plg->dwIPFrom;
	if(0!=plg->IPNodes[n].NETBIOSNAME[0])
	{	*nodeNumInList = n;
		return -3;
	}
	return 0;*/
}

BOOL IsFolderAccessible(wchar_t *s)
{
int i;HANDLE h;WIN32_FIND_DATA fd;
wchar_t *p=s,path[MAX_PATH]=L"\\\\?\\UNC\\";//\\";
	for(i=0; i<MAX_PATH && (*p=='\\'); ++i,++p);
	if(*p==0)return FALSE;
	if(i==MAX_PATH)return FALSE;
	i=8+MyStringCpy(&path[8],MAX_PATH-8,p);
	i+=MyStringCpy(&path[i],MAX_PATH-i,L"\\*");
	h=FindFirstFile(path,&fd);
	if(INVALID_HANDLE_VALUE==h)return FALSE;
	FindClose(h);
	return TRUE;
}

BOOL IsFolderAccessibleWI(wchar_t *ipStr)
{
HANDLE hEnum;
DWORD ret=ERROR_NO_MORE_ITEMS,ToGet=100,ResBuf=ToGet*sizeof(NETRESOURCE),OpenResult;
WIN32_FIND_DATA fd={FILE_ATTRIBUTE_DIRECTORY};
NETRESOURCE NetContainer,*ResArr=NULL;
wchar_t IPStr[32]=L"\\\\";
MyStringCpy(&IPStr[2],30,ipStr);

	NetContainer.dwScope = RESOURCE_GLOBALNET;
	NetContainer.dwType = RESOURCETYPE_ANY;
	NetContainer.lpLocalName = NULL;
	NetContainer.lpRemoteName = IPStr;
	NetContainer.dwUsage = RESOURCEUSAGE_CONTAINER | RESOURCEUSAGE_CONNECTABLE;
	NetContainer.lpProvider = NULL;
	NetContainer.dwDisplayType = NULL;
	NetContainer.lpComment = NULL;

	OpenResult = WNetOpenEnum(	RESOURCE_GLOBALNET,
								RESOURCETYPE_ANY,
								RESOURCEUSAGE_CONTAINER | RESOURCEUSAGE_CONNECTABLE,
								&NetContainer,
								&hEnum);
	if(OpenResult == NO_ERROR)
	{	ret = WNetEnumResource(hEnum, &ToGet, ResArr, &ResBuf);
		if(ERROR_MORE_DATA==ret || 487==ret || ERROR_NO_MORE_ITEMS==ret)
			ret = NO_ERROR;
	}
	WNetCloseEnum(hEnum);
	if(ret==NO_ERROR)
		return TRUE;
	return FALSE;
}

int FirstEntranceNode(PluginObj* plg,int itemId,DWORD ip4)//wchar_t *itemIPName)
{
struct in_addr IpAddr;
int r=0,ipStrLen=2,nodeNumInList;
HANDLE hEnum;
DWORD ret,ToGet=100,ResBuf=ToGet*sizeof(NETRESOURCE),OpenResult;
WIN32_FIND_DATA fd={FILE_ATTRIBUTE_DIRECTORY};
NETRESOURCE NetContainer,*ResArr=NULL;
unsigned k;
wchar_t ipStr[32]=L"\\\\";	
char* FAR c;
	IpAddr.S_un.S_addr = ip4;
	c = inet_ntoa(IpAddr);
	if(!c) return -1;

	if(scan==plg->state)
	if(!GetNodeNBUName(plg,ip4,itemId,&nodeNumInList))
	{	struct hostent *Host = gethostbyaddr((char*)&ip4, 4, AF_INET);
		if(Host)
		{	MultiByteToWideChar(CP_ACP,0,Host->h_name,-1,plg->IPNodes[nodeNumInList].NETBIOSNAME,(DWORD)(strlen(Host->h_name)+2));
			if(0==plg->IPNodes[nodeNumInList].NETBIOSGROUPNAME[0])
			{	LPBYTE buf;wchar_t srvrName[64]=L"\\\\";MyStringCpy(&srvrName[2],62,plg->IPNodes[nodeNumInList].NETBIOSNAME);
				if(0==NetGroupGetInfo(srvrName,NULL,0,&buf))
				{	LPGROUP_INFO_0 pb = (LPGROUP_INFO_0)buf;
					MyStringCpy(plg->IPNodes[nodeNumInList].NETBIOSGROUPNAME,32,pb->grpi0_name);
					NetApiBufferFree(buf);
	}	}	}	}

	ipStrLen += MultiByteToWideChar(CP_ACP,0,c,-1,&ipStr[2],(DWORD)(strlen(c)+2))-1;
	ResArr=(NETRESOURCE*)malloc(ResBuf);

	NetContainer.dwScope = RESOURCE_GLOBALNET; 
	NetContainer.dwType = RESOURCETYPE_ANY; 
	NetContainer.lpLocalName = NULL; 
	NetContainer.lpRemoteName = ipStr; 
	NetContainer.dwUsage = RESOURCEUSAGE_CONTAINER | RESOURCEUSAGE_CONNECTABLE; 
	NetContainer.lpProvider = NULL; 

	OpenResult = WNetOpenEnum(	RESOURCE_GLOBALNET,
								RESOURCETYPE_ANY,
								RESOURCEUSAGE_CONTAINER | RESOURCEUSAGE_CONNECTABLE,
								&NetContainer,
								&hEnum);
	if(OpenResult == NO_ERROR)
	{	ret = WNetEnumResource(hEnum, &ToGet, ResArr, &ResBuf);
		if(ERROR_NO_MORE_ITEMS==ret)
		{	ToGet = ResBuf/sizeof(NETRESOURCE);
			ResArr=(NETRESOURCE*)realloc(ResArr,ResBuf);
			ret = WNetEnumResource(hEnum, &ToGet, ResArr, &ResBuf);
		}
		if(NO_ERROR==ret && ToGet>0)//hidden sharelar uchun NetShareEnum shart
		{	char itemIP4strA[32];wchar_t *p;int i;
			//freePanel(plg->host,TRUE);
			WideCharToMultiByte(CP_ACP,0,ipStr,-1,itemIP4strA,ipStrLen+2,NULL,NULL);
			//plg->dwCrntListNodeIP = inet_addr(itemIP4strA);
			//Ip4Shufl((DWORD*)&plg->crntListNodeIP.b[0],(BYTE*)&plg->dwCrntListNodeIP);
			plg->state = in_WNetEnumResource;
			for(k=0; k<ToGet; k++)
			{	if(wcsstr(ResArr[k].lpRemoteName,ipStr))
				{	p = &ResArr[k].lpRemoteName[ipStrLen+1];
					for(i=0; i<ipStrLen && '\\'==(*p); ++i)++p;
				}
				else p = &ResArr[k].lpRemoteName[0];
				addItemToPanelList(plg->host,p,IsFolderAccessible(ResArr[k].lpRemoteName)?NULL:hIconNotAccess,&fd,0xffffffff,FALSE);
			}
			ipStr[ipStrLen++] = '\\'; ipStr[ipStrLen] = 0;
			plg->pathLn = MyStringCpy(plg->path,ipStrLen,ipStr);
			SetWindowText(plg->tlbrEditState,ipStr);
			MyStringCpy(&ipStr[2],30,L"?\\UNC");
			ipStrLen = 7+MyStringCpy(&ipStr[7],24,&plg->path[1]);
			ipStr[ipStrLen++] = '*'; ipStr[ipStrLen] = 0;
			setPanelPath(plg->host,ipStr,ipStrLen);
			//render(plg->host);//Agar alohida thread bo'lmasa,if(scan==plg->state) bo'lishi kerak;
	}	}
	else r=-2;//Hech narsa demasun;
	free(ResArr);
	WNetCloseEnum(hEnum);
	return r;
}