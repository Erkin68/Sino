#include "shlobj.h"
#include "strsafe.h"
#include <malloc.h>
#include "..\..\..\Auxilary\SinoSearchF7\FindStrWthFltr.h"
#include "..\..\..\Auxilary\SinoSearchF7\SinSchF7.h"
#include "..\..\..\..\Operations\MyShell\ComboToDisk.h"
#include "..\..\..\..\Operations\MyShell\MyShell.h"

extern "C" {BOOL IsCrntOrPrntDirAttrb(wchar_t*);}
VOID AddToInfoEdit(Search*,wchar_t*,WIN32_FIND_DATA&);
VOID AddToResultsLB(Search*,WIN32_FIND_DATA*,wchar_t*);

//Rekursiv proc:
int FindSelectsItemsNodeDir(Search* search,wchar_t *dir,FindStrWthFltr *fs)
{
	search->iCall++;
	int r=0;wchar_t path[MAX_PATH]=L"\\\\?\\UNC\\";
	int ln = 8+MyStringCpy(&path[8],MAX_PATH,dir);
	if('\\'==path[ln-1])
		{path[ln++]='*';path[ln]=0;}
	else if('*'!=path[ln-1] && '//'!=path[ln-2])
		{path[ln++]='\\';path[ln++]='*';path[ln]=0;}

	WIN32_FIND_DATA fd;ZeroMemory(&fd,sizeof(fd));
	HANDLE h=FindFirstFile(path,&fd);
	if(INVALID_HANDLE_VALUE!=h)
	{	do
		{	if(IsCrntOrPrntDirAttrb(fd.cFileName))
			{	++r;
				MyStringCpy(&path[ln-1],MAX_PATH-ln,fd.cFileName);
				if((!fs) || fs->CheckNameAndExt(fd.cFileName))
				{	AddToInfoEdit(search, &path[8], fd);
					AddToResultsLB(search, &fd, &path[8]);
				}
				if(item.bEnumSubDir)
				if(FILE_ATTRIBUTE_DIRECTORY & fd.dwFileAttributes)
					r += FindSelectsItemsNodeDir(search,&path[8],fs);
			}
			if(search->bStop)break;
			//static int k=0;
			//if(k++==4)
			{	MSG msg;if(PeekMessage(&msg, NULL, 0U, 0U, PM_REMOVE))
					DispatchMessage(&msg );
			//	k=0;
		}	}
		while(FindNextFile(h,&fd));
	}
	search->iCall--;
	return r;
}