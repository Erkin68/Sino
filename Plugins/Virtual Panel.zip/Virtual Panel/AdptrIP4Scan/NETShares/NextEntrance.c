#include "Winsock2.h"
#include <ws2tcpip.h>
#include "..\Plugins_C.h"
#include "..\..\..\..\Operations\MyShell\MyShellC.h"


/*int FolderInNode(PluginObj* plg,int itemId,wchar_t *nextPath)
{
HANDLE h;
WIN32_FIND_DATA fd;
int ln=7;
wchar_t path[MAX_PATH]=L"\\\\?\\UNC";//\\";
	ln += MyStringCpy(&path[7],plg->pathLn-1,&plg->path[1]);

//1.panel.path to'gri stringligini tekshiramiz:
//	if('\\'!=plg->path[0])
//	{
//Err1:	MessageBox(plg->tlbrWnd,L"Incorrect panel path for IP4 space...",L"Error:",MB_OK);
//		return -1;
//	}
//	if('\\'!=plg->path[1]) goto Err1;
//	if(plg->path[2]<'0') goto Err1;
//	if(plg->path[2]>'9') goto Err1;

//	if(!MyInet4StrToDword(&plg->path[2],&ipstrA[0],&dwPanelPathIP))
//	{
//Err2:	MessageBox(plg->tlbrWnd,L"Incorrect IP4 address in panel path string...",L"Error:",MB_OK);
//		return -2;
//	}
//2.IP4 ni qayta stringlaymiz:
	//ipstrA = inet_ntoa(dwPanelPathIP);
	//if(!ipstrA) return -3;
//	ln = strlen(ipstrA);
//	MultiByteToWideChar(CP_ACP,0,ipstrA,-1,&path[8],ln);
//	ln += 8;

//	if(nextPath[0]!='\\')
//		path[ln++]='\\';
//	ln += MyStringCpy(&path[ln],MAX_PATH,nextPath);

	ln += MyStringCpy(&path[ln],MAX_PATH,nextPath[0]!='\\'?nextPath:(nextPath+1));

	if('\\'!=path[ln-1])
		path[ln++] = '\\';
	path[ln++] = '*'; path[ln] = 0;
		
	ZeroMemory(&fd,sizeof(fd));
	h=FindFirstFile(path,&fd);
	if(INVALID_HANDLE_VALUE!=h)
	{	//freePanel(plg->host,TRUE);
		do
		{	if(IsCrntOrPrntDirAttrb(fd.cFileName))
				addItemToPanelList(plg->host,fd.cFileName,NULL,&fd,0xffffffff,FALSE);//TRUE);
			fd.dwFileAttributes = 0;
		}
		while(FindNextFile(h,&fd));
		FindClose(h);

		//render(plg->host);
		setPanelPath(plg->host,path,ln);
		path[6] = '\\';
		path[--ln] = 0;
		plg->pathLn = MyStringCpy(plg->path,ln-6,&path[6]);
		SetWindowText(plg->tlbrEditState,&path[6]);
		return 0;
	}
	return -1;
}

int FolderUpNode(PluginObj* plg,int itemId)
{
HANDLE h;
WIN32_FIND_DATA fd;
BOOL bFindOldItem = FALSE;
int oldPathLn,ln=7;
wchar_t *pb,*p,oldPath[MAX_PATH],path[MAX_PATH]=L"\\\\?\\UNC";//\\";

	MyStringCpy(&path[7],plg->pathLn-1,&plg->path[1]);
	p = wcsrchr(path,'\\');
	if(!p) return -3;
	//Agar oxirgisi '\\' bo'lsa, yana 1 ta olish kerak;
	if(*(p+1)==0)
	{	*p = 0;
		p = wcsrchr(path,'\\');
	}
	if(!p) return -2;
	*p = 0;

	if(p < &path[8])
	{	//if(!plg->bEntrScan)
		{	plg->path[0]=0;
			closeEvent(plgId,plg->host);
			//DetachPanel$8((LPVOID)plg,plg->host); host chaqiradi;
		}
		return -3;
	}

	//** eski path ini save qilamiz, keyinchalik select qilsh uchun.
	oldPathLn = MyStringCpy(oldPath,MAX_PATH,p+1);

	//Boshlanishi:
	pb = wcschr(&path[8],'\\');
	if((!pb) || p < pb+1)
	{	//if(plg->bEntrScan)
		//	return -1;
		//else
		{	ln = FirstEntranceNode(plg,0,plg->dwIPWEnum);
			//selectItem(plg->host,0,oldPath);
			return ln;
	}	}

	ln = p - &path[0];

	if('\\'!=path[ln-1])
		path[ln++] = '\\';
	path[ln++] = '*'; path[ln] = 0;
		
	ZeroMemory(&fd,sizeof(fd));
	h=FindFirstFile(path,&fd);
	if(INVALID_HANDLE_VALUE!=h)
	{	//freePanel(plg->host,TRUE);
		do
		{	if(IsCrntOrPrntDirAttrb(fd.cFileName))
			{	addItemToPanelList(plg->host,fd.cFileName,NULL,&fd,0xffffffff,FALSE);//TRUE);
				if(0==_wcsnicmp(fd.cFileName,oldPath,oldPathLn))
					bFindOldItem = TRUE;
			}
			fd.dwFileAttributes = 0;
		}
		while(FindNextFile(h,&fd));
		FindClose(h);

		//render(plg->host);
		path[6] = '\\';
		setPanelPath(plg->host,&path[6],ln-6);
		path[--ln] = 0;
		plg->pathLn = MyStringCpy(plg->path,ln-6,&path[6]);
		//if(bFindOldItem)
		//	selectItem(plg->host,0,oldPath);
		//render(plg->host);
		return 0;
	}
	return -1;
}*/

int FolderList(PluginObj* plg,wchar_t *nextPath)
{
HANDLE h;
WIN32_FIND_DATA fd;
wchar_t path[MAX_PATH];
int ln = MyStringCpy(path,MAX_PATH,nextPath);
	if('\\'==path[ln-1])
		{path[ln++] = '*';path[ln] = 0;}
	else if('*'!=path[ln-1] && '\\'!=path[ln-2])
		{path[ln++] = '\\';path[ln++] = '*';path[ln] = 0;}
		
	ZeroMemory(&fd,sizeof(fd));
	h=FindFirstFile(path,&fd);
	if(INVALID_HANDLE_VALUE!=h)
	{	//freePanel(plg->host,TRUE);
		do
		{	if(IsCrntOrPrntDirAttrb(fd.cFileName))
				addItemToPanelList(	plg->host,
									fd.cFileName,
									(FILE_ATTRIBUTE_DIRECTORY & fd.dwFileAttributes) ? NULL :
									(conf.bFasterIcon?0xffffffff:NULL),//(conf.bFasterIcon?hIconFastFile:NULL),
									&fd,
									0xffffffff,
									FALSE);
			fd.dwFileAttributes = 0;
		}
		while(FindNextFile(h,&fd));
		FindClose(h);

		//render(plg->host);
		setPanelPath(plg->host,path,ln);
		path[6] = '\\';
		path[--ln] = 0;
		plg->pathLn = MyStringCpy(plg->path,ln-6,&path[6]);
		SetWindowText(plg->tlbrEditState,&path[6]);
		return 0;
	}
	return -1;
}