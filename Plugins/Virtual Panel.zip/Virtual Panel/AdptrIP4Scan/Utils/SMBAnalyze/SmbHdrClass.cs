﻿using System;
using System.Collections.Generic;



public struct SmbHdr
{   
    public UInt32  MagicVal;
	public Byte    Command;
	public Byte    ErrorClass;
    public Byte    Reserved;
	public UInt16  ErrorCode;

	// flags field
	public Byte Flag;
    /*BYTE bLockAndReadWriteAndUnlock;
	BYTE bSendWithoutAck:1;
	BYTE bReservedBit:1;
	BYTE bNoCaseSensitivePaths:1;
	BYTE bCanonicalizedPaths:1;
	BYTE bOpportunisticLocks:1;
	BYTE bChangeNotify:1;
	BYTE bResponse:1;*/
     
	// 2nd flags field
    public UInt16 Flag2;
	/*BYTE bLongFilenames:1;
	BYTE bExtendedAttributes:1;
	BYTE bFlags2IsLongName:1;
	BYTE bUnknown1:1;
	BYTE bUnknown2:1;
	BYTE bUnknown3:1; //***
	BYTE bUnknown4:1;
	BYTE bUnknown5:1; //***

	BYTE bUnknown6:1;
	BYTE bUnknown7:1;
	BYTE bUnknown8:1;
	BYTE bExtendedSecurity:1;
	BYTE bResolveViaDFS:1;
	BYTE bReadGrantedWithExecPerms:1;
	BYTE bNTErrorCodes:1;
	BYTE bUnicodeStrings:1;*/

	public UInt16   PID;
	public UInt32   HdrReserved;
	public UInt16   SessionID;
	public UInt16   SequenceNumber;

    public UInt16   Padding;//Byte Padding[2]
	public UInt16   TreeID;
	public UInt16   CallersProcess;
	public UInt16   UserID;
	public UInt16   MultiplexID;
};