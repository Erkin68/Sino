﻿namespace SMBAnalyze
{
    partial class FormMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormMain));
            this.label1 = new System.Windows.Forms.Label();
            this.AnalyzeBtn = new System.Windows.Forms.Button();
            this.SaveAsBtn = new System.Windows.Forms.Button();
            this.textBoxInpSMB = new System.Windows.Forms.RichTextBox();
            this.SMBOut = new System.Windows.Forms.RichTextBox();
            this.SmbAsText = new System.Windows.Forms.RichTextBox();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.inputLoadToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sample1ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sample2ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sample3ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.ForeColor = System.Drawing.Color.Blue;
            this.label1.Location = new System.Drawing.Point(225, -3);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(169, 24);
            this.label1.TabIndex = 1;
            this.label1.Text = "SMB input in hex";
            // 
            // AnalyzeBtn
            // 
            this.AnalyzeBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.AnalyzeBtn.ForeColor = System.Drawing.Color.Blue;
            this.AnalyzeBtn.Location = new System.Drawing.Point(7, 197);
            this.AnalyzeBtn.Name = "AnalyzeBtn";
            this.AnalyzeBtn.Size = new System.Drawing.Size(75, 23);
            this.AnalyzeBtn.TabIndex = 2;
            this.AnalyzeBtn.Text = "Analyze";
            this.AnalyzeBtn.UseVisualStyleBackColor = true;
            this.AnalyzeBtn.Click += new System.EventHandler(this.AnalyzeBtn_Click);
            // 
            // SaveAsBtn
            // 
            this.SaveAsBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.SaveAsBtn.ForeColor = System.Drawing.Color.Blue;
            this.SaveAsBtn.Location = new System.Drawing.Point(699, 200);
            this.SaveAsBtn.Name = "SaveAsBtn";
            this.SaveAsBtn.Size = new System.Drawing.Size(82, 23);
            this.SaveAsBtn.TabIndex = 4;
            this.SaveAsBtn.Text = "Save As...";
            this.SaveAsBtn.UseVisualStyleBackColor = true;
            this.SaveAsBtn.Click += new System.EventHandler(this.SaveAsBtn_Click);
            // 
            // textBoxInpSMB
            // 
            this.textBoxInpSMB.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.1F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxInpSMB.ForeColor = System.Drawing.Color.Blue;
            this.textBoxInpSMB.Location = new System.Drawing.Point(1, 18);
            this.textBoxInpSMB.Name = "textBoxInpSMB";
            this.textBoxInpSMB.Size = new System.Drawing.Size(439, 179);
            this.textBoxInpSMB.TabIndex = 5;
            this.textBoxInpSMB.Text = resources.GetString("textBoxInpSMB.Text");
            // 
            // SMBOut
            // 
            this.SMBOut.Font = new System.Drawing.Font("Microsoft Sans Serif", 18.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.SMBOut.ForeColor = System.Drawing.Color.Green;
            this.SMBOut.Location = new System.Drawing.Point(1, 225);
            this.SMBOut.Name = "SMBOut";
            this.SMBOut.Size = new System.Drawing.Size(780, 305);
            this.SMBOut.TabIndex = 6;
            this.SMBOut.Text = "";
            // 
            // SmbAsText
            // 
            this.SmbAsText.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.1F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.SmbAsText.ForeColor = System.Drawing.Color.Blue;
            this.SmbAsText.Location = new System.Drawing.Point(440, 18);
            this.SmbAsText.Name = "SmbAsText";
            this.SmbAsText.Size = new System.Drawing.Size(341, 179);
            this.SmbAsText.TabIndex = 7;
            this.SmbAsText.Text = "";
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.menuStrip1.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.inputLoadToolStripMenuItem,
            this.aboutToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(784, 24);
            this.menuStrip1.TabIndex = 8;
            this.menuStrip1.Text = "Input load:";
            // 
            // inputLoadToolStripMenuItem
            // 
            this.inputLoadToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.sample1ToolStripMenuItem,
            this.sample2ToolStripMenuItem,
            this.sample3ToolStripMenuItem});
            this.inputLoadToolStripMenuItem.Name = "inputLoadToolStripMenuItem";
            this.inputLoadToolStripMenuItem.Size = new System.Drawing.Size(78, 20);
            this.inputLoadToolStripMenuItem.Text = "Input load:";
            // 
            // sample1ToolStripMenuItem
            // 
            this.sample1ToolStripMenuItem.Name = "sample1ToolStripMenuItem";
            this.sample1ToolStripMenuItem.Size = new System.Drawing.Size(291, 22);
            this.sample1ToolStripMenuItem.Text = "Sample 1 (NT LM 0.12 server response)";
            this.sample1ToolStripMenuItem.Click += new System.EventHandler(this.sample1ToolStripMenuItem_Click);
            // 
            // sample2ToolStripMenuItem
            // 
            this.sample2ToolStripMenuItem.Name = "sample2ToolStripMenuItem";
            this.sample2ToolStripMenuItem.Size = new System.Drawing.Size(291, 22);
            this.sample2ToolStripMenuItem.Text = "Sample2 (SMB_COM_CLOSE)";
            this.sample2ToolStripMenuItem.Click += new System.EventHandler(this.sample2ToolStripMenuItem_Click);
            // 
            // sample3ToolStripMenuItem
            // 
            this.sample3ToolStripMenuItem.Name = "sample3ToolStripMenuItem";
            this.sample3ToolStripMenuItem.Size = new System.Drawing.Size(291, 22);
            this.sample3ToolStripMenuItem.Text = "Sample 3 (SMB_COM_TRANSACTION)";
            this.sample3ToolStripMenuItem.Click += new System.EventHandler(this.sample3ToolStripMenuItem_Click);
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(65, 20);
            this.aboutToolStripMenuItem.Text = "About ...";
            this.aboutToolStripMenuItem.Click += new System.EventHandler(this.aboutToolStripMenuItem_Click);
            // 
            // FormMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(784, 528);
            this.Controls.Add(this.SmbAsText);
            this.Controls.Add(this.SMBOut);
            this.Controls.Add(this.textBoxInpSMB);
            this.Controls.Add(this.SaveAsBtn);
            this.Controls.Add(this.AnalyzeBtn);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "FormMain";
            this.Text = "SMBAnalyze";
            this.Resize += new System.EventHandler(this.Form1_Resize);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button AnalyzeBtn;
        private System.Windows.Forms.Button SaveAsBtn;
        private System.Windows.Forms.RichTextBox textBoxInpSMB;
        private System.Windows.Forms.RichTextBox SMBOut;
        private System.Windows.Forms.RichTextBox SmbAsText;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem inputLoadToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sample1ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sample2ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sample3ToolStripMenuItem;
    }
}

