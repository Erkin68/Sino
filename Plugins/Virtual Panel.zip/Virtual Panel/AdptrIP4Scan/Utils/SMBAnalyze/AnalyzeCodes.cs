﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;


class AnalyzeCode
{
    public AnalyzeCode(RichTextBox s, Globals g) { SMBOut = s; glbl = g; }
    public RichTextBox SMBOut;
    public Globals glbl;
    public int AnalyzeSmbComClose(Byte[] buf, int phdr, int maxBuxLen, out Byte AndXCommand)
    {
        int oldhdr = phdr;
        AndXCommand = 0;

        Byte WordCount = buf[phdr++];
        SMBOut.Text += "\n" + "\n" + "SMB_COM_CLOSE: ";

        switch (WordCount)
        {
            case 3://clnt req:
                SMBOut.Text += "\n" + "   client request:";
                SMBOut.Text += "\n" + "      WordCount - Count of parameter words: " + glbl.ToDecAndHexString(WordCount, 1);
                UInt16 FileID = glbl.smbWORD(buf, phdr);
                SMBOut.Text += "\n" + "      FileID: " + FileID.ToString();
                phdr += 2;
                UInt32 LastWriteTime = glbl.smbDWORD(buf, phdr);
                SMBOut.Text += "\n" + "      LastWriteTime should be zero or -1: " + LastWriteTime.ToString();
                phdr += 4;
                UInt16 ByteCount = glbl.smbWORD(buf, phdr);
                SMBOut.Text += "\n" + "      ByteCount: " + ByteCount.ToString();
                phdr += 2;
                break;
            case 0://srvr rspns:
                SMBOut.Text += "\n" + "   server response:";
                SMBOut.Text += "\n" + "      WordCount - Count of parameter words, should be zero: " + glbl.ToDecAndHexString(WordCount, 1);
                ByteCount = glbl.smbWORD(buf, phdr);
                SMBOut.Text += "\n" + "      ByteCount, should be zero: " + ByteCount.ToString();
                phdr += 2;
                break;
            default:
                SMBOut.Text += "\n" + "      Unknown SMB_COM_CLOSE packet: ";
                break;
        }
        AndXCommand = 0xff;//cancel continuing;
        return 0;
    }

    public int AnalyzeSmbComTransaction(SmbHdr smbhdr,Byte[] buf, int phdr, int maxBuxLen, out Byte AndXCommand)
    {
        int oldhdr = phdr;
        AndXCommand = 0;

        Byte WordCount = buf[phdr++];
        SMBOut.Text += "\n" + "\n" + "SMB_COM_TRANSACTION: ";
        SMBOut.Text += "\n" + "   WordCount - " + glbl.ToDecAndHexString(WordCount, 1);
        
        switch(WordCount)
        {   case 23:
                SMBOut.Text += "\n" + "   client request:";
                SMBOut.Text += "\n" + "      WordCount - Count of parameter words: " + glbl.ToDecAndHexString(WordCount, 1);
                Byte MaxSetupCount = buf[phdr++];
                SMBOut.Text += "\n" + "      MaxSetupCount - " + glbl.ToDecAndHexString(MaxSetupCount,1);
                UInt16 Reserved = glbl.smbWORD(buf, phdr);
                SMBOut.Text += "\n" + "      Reserved - " + Reserved.ToString();
                phdr += 2;
                UInt32 TotalParameterCount = glbl.smbDWORD(buf, phdr);
                SMBOut.Text += "\n" + "      TotalParameterCount - " + TotalParameterCount.ToString();
                phdr += 4;
                UInt32 TotalDataCount = glbl.smbDWORD(buf, phdr);
                SMBOut.Text += "\n" + "      TotalDataCount - " + TotalDataCount.ToString();
                phdr += 4;
                UInt32 MaxParameterCount = glbl.smbDWORD(buf, phdr);
                SMBOut.Text += "\n" + "      MaxParameterCount - " + MaxParameterCount.ToString();
                phdr += 4;
                UInt32 MaxDataCount = glbl.smbDWORD(buf, phdr);
                SMBOut.Text += "\n" + "      MaxDataCount - " + MaxDataCount.ToString();
                phdr += 4;
                UInt32 ParameterCount = glbl.smbDWORD(buf, phdr);
                SMBOut.Text += "\n" + "      ParameterCount - " + ParameterCount.ToString();
                phdr += 4;
                UInt32 ParameterOffset = glbl.smbDWORD(buf, phdr);
                SMBOut.Text += "\n" + "      ParameterOffset - " + ParameterOffset.ToString();
                phdr += 4;
                UInt32 DataCount = glbl.smbDWORD(buf, phdr);
                SMBOut.Text += "\n" + "      DataCount - " + DataCount.ToString();
                phdr += 4;
                UInt32 DataOffset = glbl.smbDWORD(buf, phdr);
                SMBOut.Text += "\n" + "      DataOffset - " + DataOffset.ToString();
                phdr += 4;
                Byte SetupCount = buf[phdr++];//four setup words follow subcommand
                SMBOut.Text += "\n" + "      SetupCount - " + SetupCount.ToString();

                //SNIA spec incorrectly included spurious pad here
                UInt16 SubCommand = glbl.smbWORD(buf, phdr);
                SMBOut.Text += "\n" + "      SubCommand, 2 = IOCTL/FSCTL - " + SubCommand.ToString();
                phdr += 2;
                UInt32 FunctionCode = glbl.smbDWORD(buf, phdr);
                SMBOut.Text += "\n" + "      FunctionCode - " + FunctionCode.ToString();
                phdr += 4;
                UInt16 Fid = glbl.smbWORD(buf, phdr);
                SMBOut.Text += "\n" + "      Fid - " + Fid.ToString();
                phdr += 2;
                Byte IsFsctl = buf[phdr++];//four setup words follow subcommand
                SMBOut.Text += "\n" + "      IsFsctl, 1 = File System Control 0 = device control (IOCTL) - " + IsFsctl.ToString();
                Byte IsRootFlag = buf[phdr++];//four setup words follow subcommand
                SMBOut.Text += "\n" + "      IsRootFlag, 1 = apply command to root of share (must be DFS) - " + IsRootFlag.ToString();
                UInt16 ByteCount = glbl.smbWORD(buf, phdr);
                SMBOut.Text += "\n" + "      ByteCount - " + ByteCount.ToString();
                phdr += 2;
                SMBOut.Text += "\n" + "      Pad - 0x" + buf[phdr].ToString("X2") + "0X" + buf[phdr+1].ToString("X2") + "0X" + buf[phdr+2].ToString("X2");
                phdr += 3;
                Byte Data = buf[phdr++];//four setup words follow subcommand
                SMBOut.Text += "\n" + "      Data - " + Data.ToString();
            break;
            case 19:
                SMBOut.Text += "\n" + "   server response:";
                SMBOut.Text += "\n" + "      WordCount - Count of parameter words: " + glbl.ToDecAndHexString(WordCount, 1);
                SMBOut.Text += "\n" + "      Reserved - 0x" + buf[phdr].ToString("X2") + "0X" + buf[phdr + 1].ToString("X2") + "0X" + buf[phdr + 2].ToString("X2");
                phdr += 3;
                TotalParameterCount = glbl.smbDWORD(buf, phdr);
                SMBOut.Text += "\n" + "      TotalParameterCount - " + TotalParameterCount.ToString();
                phdr += 4;
                TotalDataCount = glbl.smbDWORD(buf, phdr);
                SMBOut.Text += "\n" + "      TotalDataCount - " + TotalDataCount.ToString();
                phdr += 4;
                ParameterCount = glbl.smbDWORD(buf, phdr);
                SMBOut.Text += "\n" + "      ParameterCount - " + ParameterCount.ToString();
                phdr += 4;
                ParameterOffset = glbl.smbDWORD(buf, phdr);
                SMBOut.Text += "\n" + "      ParameterOffset - " + ParameterOffset.ToString();
                phdr += 4;
                UInt32 ParameterDisplacement = glbl.smbDWORD(buf, phdr);
                SMBOut.Text += "\n" + "      ParameterDisplacement - " + ParameterDisplacement.ToString();
                phdr += 4;
                DataCount = glbl.smbDWORD(buf, phdr);
                SMBOut.Text += "\n" + "      DataCount - " + DataCount.ToString();
                phdr += 4;
                DataOffset = glbl.smbDWORD(buf, phdr);
                SMBOut.Text += "\n" + "      DataOffset - " + DataOffset.ToString();
                phdr += 4;
                UInt32 DataDisplacement = glbl.smbDWORD(buf, phdr);
                SMBOut.Text += "\n" + "      DataDisplacement - " + DataDisplacement.ToString();
                phdr += 4;
                SetupCount = buf[phdr++];
                SMBOut.Text += "\n" + "      SetupCount, 1 - " + SetupCount.ToString();
                UInt16 ReturnedDataLen = glbl.smbWORD(buf, phdr);
                SMBOut.Text += "\n" + "      ReturnedDataLen - " + ReturnedDataLen.ToString();
                phdr += 2;
                ByteCount = glbl.smbWORD(buf, phdr);
                SMBOut.Text += "\n" + "      ByteCount - " + ByteCount.ToString();
                phdr += 2;
                break;
            default:
                SetupCount = buf[phdr + 26];
                if (SetupCount == WordCount - 14)//request
                {
                    SMBOut.Text += "\n" + "   client request:";
                    TotalParameterCount = glbl.smbWORD(buf, phdr);
                    SMBOut.Text += "\n" + "      TotalParameterCount,total parameter bytes being sent - " + TotalParameterCount.ToString() + " (0x" + TotalParameterCount.ToString("X4") + ");";
                    phdr += 2;
                    TotalDataCount = glbl.smbWORD(buf, phdr);
                    SMBOut.Text += "\n" + "      TotalDataCount,Total data bytes being sent - " + TotalDataCount.ToString() + " (0x" + TotalDataCount.ToString("X4") + ");";
                    phdr += 2;
                    MaxParameterCount = glbl.smbWORD(buf, phdr);
                    SMBOut.Text += "\n" + "      MaxParameterCount,Max parameter bytes to return - " + MaxParameterCount.ToString() + " (0x" + MaxParameterCount.ToString("X4") + ");";
                    phdr += 2;
                    MaxDataCount = glbl.smbWORD(buf, phdr);
                    SMBOut.Text += "\n" + "      MaxDataCount,Max data bytes to return - " + MaxDataCount.ToString() + " (0x" + MaxDataCount.ToString("X4") + ");";
                    phdr += 2;
                    MaxSetupCount = buf[phdr++];
                    SMBOut.Text += "\n" + "      MaxSetupCount,Max setup words to return - " + MaxSetupCount.ToString() + " (0x" + MaxSetupCount.ToString("X4") + ");";
                    Reserved = buf[phdr++];
                    SMBOut.Text += "\n" + "      Reserved1 - " + Reserved.ToString();
                    UInt16 Flags = glbl.smbWORD(buf, phdr);
                    SMBOut.Text += "\n" + "      Flags,Additional information - " + Flags.ToString() + " (0x" + Flags.ToString("X4") + ");";
                    if (0 != ((Byte)(Flags & 0x01)))
                        SMBOut.Text += "\n" + "         also disconnect TID in Tid;";
                    if (0 != ((Byte)(Flags & 0x02)))
                        SMBOut.Text += "\n" + "         one-way transacion (no resp);";
                    phdr += 2;
                    UInt32 Timeout = glbl.smbDWORD(buf, phdr);
                    SMBOut.Text += "\n" + "      Timeout - " + Timeout.ToString() + " (0x" + Timeout.ToString("X8") + ");";
                    phdr += 4;
                    UInt16 Reserved2 = glbl.smbWORD(buf, phdr);
                    SMBOut.Text += "\n" + "      Reserved2 - " + Reserved2.ToString();
                    phdr += 2;
                    ParameterCount = glbl.smbWORD(buf, phdr);
                    SMBOut.Text += "\n" + "      ParameterCount,Parameter bytes sent this buffer - " + ParameterCount.ToString() + " (0x" + ParameterCount.ToString("X4") + ");";
                    phdr += 2;
                    ParameterOffset = glbl.smbWORD(buf, phdr);
                    SMBOut.Text += "\n" + "      ParameterOffset,Offset (from header start) to params - " + ParameterOffset.ToString() + " (0x" + ParameterOffset.ToString("X4") + ");";
                    phdr += 2;
                    DataCount = glbl.smbWORD(buf, phdr);
                    SMBOut.Text += "\n" + "      DataCount,Data bytes sent this buffer - " + DataCount.ToString() + " (0x" + DataCount.ToString("X4") + ");";
                    phdr += 2;
                    DataOffset = glbl.smbWORD(buf, phdr);
                    SMBOut.Text += "\n" + "      DataOffset,Offset (from header start) to data - " + DataOffset.ToString() + " (0x" + DataOffset.ToString("X4") + ");";
                    phdr += 2;
                    phdr++;//for SetupCount = buf[phdr++];
                    SMBOut.Text += "\n" + "      SetupCount,Count of setup words - " + SetupCount.ToString() + " (0x" + SetupCount.ToString("X4") + ");";

                    UInt16 subCmnd=0;
                    Byte Reserved3 = buf[phdr++];
                    SMBOut.Text += "\n" + "      Reserved3,Reserved (pad above to word) - " + Reserved3.ToString() + " (0x" + Reserved3.ToString("X2") + ");";
                    SMBOut.Text += "\n" + "      Setup words[SetupCount] - ";
                    for (int i = 0; i < SetupCount; ++i)
                    {
                        UInt16 w = glbl.smbWORD(buf, phdr);
                        if (0 == i)
                        {
                            subCmnd = w;
                        }
                        SMBOut.Text += " 0x" + w.ToString("X4");
                        phdr += 2;
                    }

                    ByteCount = glbl.smbWORD(buf, phdr);
                    SMBOut.Text += "\n" + "      ByteCount,Count of data bytes - " + ByteCount.ToString() + " (0x" + ByteCount.ToString("X4") + ");";
                    phdr += 2;
                    SMBOut.Text += "\n" + "      Name[],Name of transaction (NULL if SMB_COM_TRANSACTION2) - ";
                    if (0!=(UInt16)(smbhdr.Flag2 & 0x8000))//SMB_FLAGS2_UNICODE
                    {
                        for (int i = 0; i < ByteCount; ++i)
                        {
                            UInt16 c = glbl.smbWORDRec(buf, phdr);
                            SMBOut.Text += Char.ConvertFromUtf32(c);
                            if (0 == c) break;
                            phdr += 2;
                        }
                    }
                    else
                    {
                        for (int i = 0; i < ByteCount && buf[phdr] > 0; ++i)
                        {
                            SMBOut.Text += buf[phdr++];
                        }
                    }
                    //Padding SMBHdr boshidan boshlab 4 bayt chegarasida b-shi kerak, bizda 4 bayt paket boshiyam bor,shu uchun 4 ga farqi yo'q;
                    SMBOut.Text += "\n" + "      Padding1,4-byte boundary. relative to the start of the SMB Header - ";
                    for(int i=0; i<phdr % 4; ++i)
                        SMBOut.Text += " 0X" + buf[phdr+i].ToString("X2");
                    phdr += phdr % 4;
                    SMBOut.Text += "\n" + "      Trans_Parameters - ";
                    for (int i = 0; i < ParameterCount; ++i)
                        SMBOut.Text += " 0X" + buf[phdr + i].ToString("X2");
                    phdr += (int)ParameterCount;
                    SMBOut.Text += "\n" + "      Padding2,4-byte boundary. relative to the start of the SMB Header - ";
                    for (int i = 0; i < phdr % 4; ++i)
                        SMBOut.Text += " 0X" + buf[phdr + i].ToString("X2");
                    phdr += phdr % 4;
                    /*SMBOut.Text += "\n" + "      Trans_Data - ";
                    for (int i = 0; i < DataCount; ++i)
                        SMBOut.Text += " 0X" + buf[phdr + i].ToString("X2");
                    phdr += (int)DataCount;*/

                    return AnalyzeSmbTransactionSubCommand(smbhdr, buf, phdr, maxBuxLen, out AndXCommand, subCmnd);
                }
                SetupCount = buf[phdr + 18];
                if (SetupCount == WordCount - 10)//response
                {
                    SMBOut.Text += "\n" + "   server response:";
                    break;
                }
                SMBOut.Text += "\n" + "   invalid SMB_COM_TRANSACTION packet:";
                AndXCommand = 0xff;//Cancel;
                break;
        }
        AndXCommand = 0xff;//Cancel;
        return 0;
    }

    public int AnalyzeSmbTransactionSubCommand(SmbHdr smbhdr,Byte[] buf,int phdr, int maxBuxLen, out Byte AndXCommand, UInt16 subCmnd)
    {
        AndXCommand = 0;
        switch (subCmnd)
        {
            case 0x0001://SMBOut.Text += "\n" + "   SMB_COM_TRANSACTION subcommand TRANS_MAILSLOT_WRITE (0x0001)";
                SMBOut.Text += "\n" + "   SMB_COM_TRANSACTION subcommand TRANS_SET_NMPIPE_STATE (0x0001)";
                break;
            case 0x0011:
                SMBOut.Text += "\n" + "   SMB_COM_TRANSACTION subcommand TRANS_RAW_READ_NMPIPE (0x0011)";
                break;
            case 0x0021:
                SMBOut.Text += "\n" + "   SMB_COM_TRANSACTION subcommand TRANS_QUERY_NMPIPE_STATE (0x0021)";
                break;
            case 0x0022:
                SMBOut.Text += "\n" + "   SMB_COM_TRANSACTION subcommand TRANS_QUERY_NMPIPE_INFO (0x0022)";
                break;
            case 0x0023:
                SMBOut.Text += "\n" + "   SMB_COM_TRANSACTION subcommand TRANS_PEEK_NMPIPE (0x0023)";
                break;
            case 0x0026:
                SMBOut.Text += "\n" + "   SMB_COM_TRANSACTION subcommand TRANS_TRANSACT_NMPIPE (0x0026)";
                break;
            case 0x0031:
                SMBOut.Text += "\n" + "   SMB_COM_TRANSACTION subcommand TRANS_RAW_WRITE_NMPIPE (0x0031)";
                break;
            case 0x0036:
                SMBOut.Text += "\n" + "   SMB_COM_TRANSACTION subcommand TRANS_READ_NMPIPE (0x0036)";
                break;
            case 0x0037:
                SMBOut.Text += "\n" + "   SMB_COM_TRANSACTION subcommand TRANS_WRITE_NMPIPE (0x0037)";
                break;
            case 0x0053:
                SMBOut.Text += "\n" + "   SMB_COM_TRANSACTION subcommand TRANS_WAIT_NMPIPE (0x0053)";
                break;
            case 0x0054:
                SMBOut.Text += "\n" + "   SMB_COM_TRANSACTION subcommand TRANS_CALL_NMPIPE (0x0054)";
                break;
        }
        AndXCommand = 0xff;        
        return 0;
    }

    public int AnalyzeSmbSessionSetupAndX(Byte[] buf, int phdr, int maxBuxLen, out Byte AndXCommand)
    {
        int oldhdr = phdr;
        AndXCommand = 0;

        Byte WordCount = buf[phdr++];
        switch (WordCount)
        {
            case 10:
                SMBOut.Text += "\n" + "\n" + "prior NT LM 0.12, client request:";
                SMBOut.Text += "\n" + "      WordCount - Count of parameter words: " + glbl.ToDecAndHexString(WordCount, 1);
                AndXCommand = buf[phdr++];
                SMBOut.Text += "\n" + "      AndXCommand - Secondary (X) command: " + glbl.ToDecAndHexString(AndXCommand, 1);
                if (0xff == AndXCommand) SMBOut.Text += "(NONE)";
                Byte AndXReserved = buf[phdr++];
                SMBOut.Text += "\n" + "      AndXReserved - Reserved (should be zero): " + glbl.ToDecAndHexString(AndXReserved, 1);
                UInt16 AndXOffset = glbl.smbWORD(buf, phdr); phdr += 2;
                SMBOut.Text += "\n" + "      AndXOffset - Offset to next command WordCount: " + glbl.ToDecAndHexString(AndXOffset, 2);
                UInt16 MaxBufferSize = glbl.smbWORD(buf, phdr); phdr += 2;
                SMBOut.Text += "\n" + "      MaxBufferSize - Client maximum buffer size: " + glbl.ToDecAndHexString(MaxBufferSize, 2);
                UInt16 MaxMpxCount = glbl.smbWORD(buf, phdr); phdr += 2;
                SMBOut.Text += "\n" + "      MaxMpxCount - Actual maximum multiplexed pending requests: " + glbl.ToDecAndHexString(MaxMpxCount, 2);
                UInt16 VcNumber = glbl.smbWORD(buf, phdr); phdr += 2;
                SMBOut.Text += "\n" + "      VcNumber - 0 = first (only), nonzero=additional VC number: " + glbl.ToDecAndHexString(VcNumber, 2);
                UInt32 SessionKey = glbl.smbDWORD(buf, phdr); phdr += 4;
                SMBOut.Text += "\n" + "      SessionKey - 0 = Session key (valid iff VcNumber != 0): " + glbl.ToDecAndHexString(SessionKey, 3);
                UInt16 PasswordLength = glbl.smbWORD(buf, phdr); phdr += 2;
                SMBOut.Text += "\n" + "      PasswordLength - Account password size: " + glbl.ToDecAndHexString(PasswordLength, 2);
                UInt32 Reserved = glbl.smbDWORD(buf, phdr); phdr += 4;
                SMBOut.Text += "\n" + "      Reserved - should be zero" + glbl.ToDecAndHexString(Reserved, 3);
                UInt16 ByteCount = glbl.smbWORD(buf, phdr); phdr += 2;
                SMBOut.Text += "\n" + "      ByteCount - Count of data bytes; min = 0: " + glbl.ToDecAndHexString(ByteCount, 2);
                SMBOut.Text += "\n" + "      Account Password: ";
                for (int i = 0; i < PasswordLength; ++i) SMBOut.Text += glbl.HexToCharString(buf[phdr + i]);
                phdr += PasswordLength;
                SMBOut.Text += "\n" + "      Account Name: ";
                for (int i = 0; i < 256 && buf[phdr] > 0; ++i) SMBOut.Text += glbl.HexToCharString(buf[phdr++]);
                SMBOut.Text += "\n" + "      Client's Primary Domain Name: ";
                for (int i = 0; i < 256 && buf[phdr] > 0; ++i) SMBOut.Text += glbl.HexToCharString(buf[phdr++]);
                SMBOut.Text += "\n" + "      Client's Native Operating System Name: ";
                for (int i = 0; i < 256 && buf[phdr] > 0; ++i) SMBOut.Text += glbl.HexToCharString(buf[phdr++]);
                SMBOut.Text += "\n" + "      Client's native LAN Manager type: ";
                for (int i = 0; i < 256 && buf[phdr] > 0; ++i) SMBOut.Text += glbl.HexToCharString(buf[phdr++]);
                break;
            case 3:
                SMBOut.Text += "\n" + "\n" + "prior NT LM 0.12, server response:";
                SMBOut.Text += "\n" + "      WordCount - Count of parameter words: " + glbl.ToDecAndHexString(WordCount, 1);
                AndXCommand = buf[phdr++];
                SMBOut.Text += "\n" + "      AndXCommand - Secondary (X) command: " + glbl.ToDecAndHexString(AndXCommand, 1);
                if (0xff == AndXCommand) SMBOut.Text += "(NONE)";
                AndXReserved = buf[phdr++];
                SMBOut.Text += "\n" + "      Reserved - (should be zero): " + glbl.ToDecAndHexString(AndXReserved, 1);
                AndXOffset = glbl.smbWORD(buf, phdr); phdr += 2;
                SMBOut.Text += "\n" + "      AndXOffset - Offset to next command WordCount: " + glbl.ToDecAndHexString(AndXOffset, 2);
                UInt16 Action = glbl.smbWORD(buf, phdr); phdr += 2;
                SMBOut.Text += "\n" + "      Action - Request mode, bit0 = logged in as GUEST: " + glbl.ToDecAndHexString(Action, 2);
                ByteCount = glbl.smbWORD(buf, phdr); phdr += 2;
                SMBOut.Text += "\n" + "      ByteCount - Count of data bytes: " + glbl.ToDecAndHexString(ByteCount, 2);
                SMBOut.Text += "\n" + "      Server's native operating system: ";
                for (int i = 0; i < 256 && buf[phdr] > 0; ++i) SMBOut.Text += glbl.HexToCharString(buf[phdr++]);
                SMBOut.Text += "\n" + "      Server's native LAN Manager type: ";
                for (int i = 0; i < 256 && buf[phdr] > 0; ++i) SMBOut.Text += glbl.HexToCharString(buf[phdr++]);
                SMBOut.Text += "\n" + "      Server's primary domain: ";
                for (int i = 0; i < 256 && buf[phdr] > 0; ++i) SMBOut.Text += glbl.HexToCharString(buf[phdr++]);
                break;
            case 12:
                SMBOut.Text += "\n" + "\n" + "NT LM 0.12 server supports ExtendedSecurity, client request:";
                SMBOut.Text += "\n" + "      WordCount - Count of parameter words: " + glbl.ToDecAndHexString(WordCount, 1);
                AndXCommand = buf[phdr++];
                if (0xff == AndXCommand) SMBOut.Text += "(NONE)";
                SMBOut.Text += "\n" + "      AndXCommand - Secondary (X) command: " + glbl.ToDecAndHexString(AndXCommand, 1);
                AndXReserved = buf[phdr++];
                SMBOut.Text += "\n" + "      Reserved - (should be zero): " + glbl.ToDecAndHexString(AndXReserved, 1);
                AndXOffset = glbl.smbWORD(buf, phdr); phdr += 2;
                SMBOut.Text += "\n" + "      AndXOffset - Offset to next command WordCount: " + glbl.ToDecAndHexString(AndXOffset, 2);
                MaxBufferSize = glbl.smbWORD(buf, phdr); phdr += 2;
                SMBOut.Text += "\n" + "      MaxBufferSize - Client maximum buffer size: " + glbl.ToDecAndHexString(MaxBufferSize, 2);
                MaxMpxCount = glbl.smbWORD(buf, phdr); phdr += 2;
                SMBOut.Text += "\n" + "      MaxMpxCount - Actual maximum multiplexed pending requests: " + glbl.ToDecAndHexString(MaxMpxCount, 2);
                VcNumber = glbl.smbWORD(buf, phdr); phdr += 2;
                SMBOut.Text += "\n" + "      VcNumber - 0 = first (only), nonzero=additional VC number: " + glbl.ToDecAndHexString(VcNumber, 2);
                SessionKey = glbl.smbDWORD(buf, phdr); phdr += 4;
                SMBOut.Text += "\n" + "      SessionKey - 0 = Session key (valid iff VcNumber != 0): " + glbl.ToDecAndHexString(SessionKey, 3);
                UInt16 SecurityBlobLength = glbl.smbWORD(buf, phdr); phdr += 2;
                SMBOut.Text += "\n" + "      SecurityBlobLength - Length of opaque security blob: " + glbl.ToDecAndHexString(SecurityBlobLength, 2);
                Reserved = glbl.smbDWORD(buf, phdr); phdr += 4;
                SMBOut.Text += "\n" + "      Reserved - should be zero: " + glbl.ToDecAndHexString(Reserved, 3);
                ByteCount = glbl.smbWORD(buf, phdr); phdr += 2;
                SMBOut.Text += "\n" + "      ByteCount - Count of data bytes; min = 0: " + glbl.ToDecAndHexString(ByteCount, 2);
                SMBOut.Text += "\n" + "      The opaque security blob: ";
                for (int i = 0; i < SecurityBlobLength; ++i) SMBOut.Text += glbl.HexToCharString(buf[phdr + i]);
                phdr += SecurityBlobLength;
                SMBOut.Text += "\n" + "      Client's Native Operating System Name: ";
                for (int i = 0; i < 256 && buf[phdr] > 0; ++i) { SMBOut.Text += glbl.HexToWCharString(glbl.smbWORD(buf, phdr)); phdr += 2; }
                SMBOut.Text += "\n" + "      Client's native LAN Manager type: ";
                for (int i = 0; i < 256 && buf[phdr] > 0; ++i) { SMBOut.Text += glbl.HexToWCharString(glbl.smbWORD(buf, phdr)); phdr += 2; }
                break;
            case 13:
                SMBOut.Text += "\n" + "\n" + "NT LM 0.12 server does not support Extended Security, client request:";
                SMBOut.Text += "\n" + "      WordCount - Count of parameter words: " + glbl.ToDecAndHexString(WordCount, 1);
                AndXCommand = buf[phdr++];
                SMBOut.Text += "\n" + "      AndXCommand - Secondary (X) command: " + glbl.ToDecAndHexString(AndXCommand, 1);
                if (0xff == AndXCommand) SMBOut.Text += "(NONE)";
                AndXReserved = buf[phdr++];
                SMBOut.Text += "\n" + "      AndXReserved - Reserved (should be zero): " + glbl.ToDecAndHexString(AndXReserved, 1);
                AndXOffset = glbl.smbWORD(buf, phdr); phdr += 2;
                SMBOut.Text += "\n" + "      AndXOffset - Offset to next command WordCount: " + glbl.ToDecAndHexString(AndXOffset, 2);
                MaxBufferSize = glbl.smbWORD(buf, phdr); phdr += 2;
                SMBOut.Text += "\n" + "      MaxBufferSize - Client maximum buffer size: " + glbl.ToDecAndHexString(MaxBufferSize, 2);
                MaxMpxCount = glbl.smbWORD(buf, phdr); phdr += 2;
                SMBOut.Text += "\n" + "      MaxMpxCount - Actual maximum multiplexed pending requests: " + glbl.ToDecAndHexString(MaxMpxCount, 2);
                VcNumber = glbl.smbWORD(buf, phdr); phdr += 2;
                SMBOut.Text += "\n" + "      VcNumber - 0 = first (only), nonzero=additional VC number: " + glbl.ToDecAndHexString(VcNumber, 2);
                SessionKey = glbl.smbDWORD(buf, phdr); phdr += 4;
                SMBOut.Text += "\n" + "      SessionKey - (valid iff VcNumber != 0): " + glbl.ToDecAndHexString(SessionKey, 3);
                PasswordLength = glbl.smbWORD(buf, phdr); phdr += 2;
                SMBOut.Text += "\n" + "      PasswordLength - Account password size, ANSI CaseInsensitivePasswordLength: " + glbl.ToDecAndHexString(PasswordLength, 2);
                UInt16 UnicodePasswordLength = glbl.smbWORD(buf, phdr); phdr += 2;
                SMBOut.Text += "\n" + "      UnicodePasswordLength - Account password size, Unicode CaseInsensitivePasswordLength: " + glbl.ToDecAndHexString(UnicodePasswordLength, 2);
                Reserved = glbl.smbDWORD(buf, phdr); phdr += 4;
                SMBOut.Text += "\n" + "      Reserved - should be zero: " + glbl.ToDecAndHexString(Reserved, 3);
                UInt32 Capabilities = glbl.smbDWORD(buf, phdr); phdr += 4;
                SMBOut.Text += "\n" + "      Capabilities - Client capabilities: " + glbl.ToDecAndHexString(Capabilities, 3);
                if (0 != ((UInt32)(Capabilities & 0x01)))
                    SMBOut.Text += "\n" + "         CAP_RAW_MODE flag is setted";
                if (0 != ((UInt32)(Capabilities & 0x02)))
                    SMBOut.Text += "\n" + "         CAP_MPX_MODE flag is setted";
                if (0 != ((UInt32)(Capabilities & 0x04)))
                    SMBOut.Text += "\n" + "         CAP_UNICODE flag is setted";
                if (0 != ((UInt32)(Capabilities & 0x08)))
                    SMBOut.Text += "\n" + "         CAP_LARGE_FILES flag is setted";
                if (0 != ((UInt32)(Capabilities & 0x10)))
                    SMBOut.Text += "\n" + "         CAP_NT_SMBS flag is setted";
                if (0 != ((UInt32)(Capabilities & 0x20)))
                    SMBOut.Text += "\n" + "         CAP_RPC_REMOTE_APIS flag is setted";
                if (0 != ((UInt32)(Capabilities & 0x40)))
                    SMBOut.Text += "\n" + "         CAP_STATUS32 flag is setted";
                if (0 != ((UInt32)(Capabilities & 0x80)))
                    SMBOut.Text += "\n" + "         CAP_LEVEL_II_OPLOCKS flag is setted";
                if (0 != ((UInt32)(Capabilities & 0x1000)))
                    SMBOut.Text += "\n" + "         CAP_LOCK_AND_READ flag is setted";
                if (0 != ((UInt32)(Capabilities & 0x200)))
                    SMBOut.Text += "\n" + "         CAP_NT_FIND flag is setted";
                if (0 != ((UInt32)(Capabilities & 0x4000)))
                    SMBOut.Text += "\n" + "         CAP_LARGE_READX flag is setted";
                ByteCount = glbl.smbWORD(buf, phdr); phdr += 2;
                SMBOut.Text += "\n" + "      ByteCount - Count of data bytes; min = 0: " + glbl.ToDecAndHexString(ByteCount, 2);
                SMBOut.Text += "\n" + "      Account Password, ANSI: ";
                for (int i = 0; i < PasswordLength; ++i) SMBOut.Text += glbl.HexToCharString(buf[phdr + i]);
                phdr += PasswordLength;
                SMBOut.Text += "\n" + "      Account Password, Unicode: ";
                for (int i = 0; i < UnicodePasswordLength; ++i) SMBOut.Text += glbl.HexToWCharString((ushort)((buf[phdr + 2 * i] << 8) | buf[phdr + 2 * i + 1]));
                phdr += UnicodePasswordLength;
                Byte Reserved2 = buf[phdr++];
                SMBOut.Text += "\n" + "      Reserved2 - Present if Unicode negotiated to even byte boundary: " + glbl.ToDecAndHexString(Reserved2, 1);
                SMBOut.Text += "\n" + "      Account Name, Unicode: ";
                for (int i = 0; i < 256 && buf[phdr] > 0; ++i) { SMBOut.Text += glbl.HexToWCharString(buf[phdr]); phdr += 2; }
                SMBOut.Text += "\n" + "      Account Name, Unicode: ";
                for (int i = 0; i < 256 && buf[phdr] > 0; ++i) { SMBOut.Text += glbl.HexToWCharString(buf[phdr]); phdr += 2; }
                SMBOut.Text += "\n" + "      Client's primary domain, Unicode: ";
                for (int i = 0; i < 256 && buf[phdr] > 0; ++i) { SMBOut.Text += glbl.HexToWCharString(buf[phdr]); phdr += 2; }
                SMBOut.Text += "\n" + "      Client's native operating system, Unicode: ";
                for (int i = 0; i < 256 && buf[phdr] > 0; ++i) { SMBOut.Text += glbl.HexToWCharString(buf[phdr]); phdr += 2; }
                SMBOut.Text += "\n" + "      Client's native LAN Manager type, Unicode: ";
                for (int i = 0; i < 256 && buf[phdr] > 0; ++i) { SMBOut.Text += glbl.HexToWCharString(buf[phdr]); phdr += 2; }
                break;
            case 4:
                SMBOut.Text += "\n" + "\n" + "NT LM 0.12 server response:";
                SMBOut.Text += "\n" + "      WordCount - Count of parameter words: " + glbl.ToDecAndHexString(WordCount, 1);
                AndXCommand = buf[phdr++];
                SMBOut.Text += "\n" + "      AndXCommand - Secondary (X) command: " + glbl.ToDecAndHexString(AndXCommand, 1);
                if (0xff == AndXCommand) SMBOut.Text += "(NONE)";
                AndXReserved = buf[phdr++];
                SMBOut.Text += "\n" + "      AndXReserved - Reserved (should be zero): " + glbl.ToDecAndHexString(AndXReserved, 1);
                AndXOffset = glbl.smbWORD(buf, phdr); phdr += 2;
                SMBOut.Text += "\n" + "      AndXOffset - Offset to next command WordCount: " + glbl.ToDecAndHexString(AndXOffset, 2);
                Action = glbl.smbWORD(buf, phdr); phdr += 2;
                SMBOut.Text += "\n" + "      Action - Request mode, bit0 = logged in as GUEST: " + glbl.ToDecAndHexString(Action, 2);
                if (0 != ((UInt16)(Action & 0x01)))
                    SMBOut.Text += "\n" + "         SMB_SETUP_GUEST action is setted";
                if (0 != ((UInt16)(Action & 0x02)))
                    SMBOut.Text += "\n" + "         SMB_SETUP_USE_LANMAN_KEY action is setted";
                SecurityBlobLength = glbl.smbWORD(buf, phdr); phdr += 2;
                SMBOut.Text += "\n" + "      SecurityBlobLength - Length of opaque security blob: " + glbl.ToDecAndHexString(SecurityBlobLength, 2);
                ByteCount = glbl.smbWORD(buf, phdr); phdr += 2;
                SMBOut.Text += "\n" + "      ByteCount - Count of data bytes: " + glbl.ToDecAndHexString(ByteCount, 2);
                SMBOut.Text += "\n" + "      The opaque security blob: ";

                if (phdr + SecurityBlobLength > maxBuxLen - 1)
                    SMBOut.Text += "\n" + "         Error blob, this may be CAP_EXTENDED_SECURITY flag unsetted in prior server(Negotiate session request) response: " + "\n" + "      ";
                for (int i = 0; i < SecurityBlobLength; ++i)
                {
                    if (phdr + i > maxBuxLen - 1)
                    {
                        SMBOut.Text += "\n" + "         Error packet len overflow,can't continue." + "\n";
                        return phdr - oldhdr;
                    }
                    SMBOut.Text += glbl.HexToCharString(buf[phdr + i]);
                }
                phdr += SecurityBlobLength;


                SMBOut.Text += "\n" + "      Server's native operating system: ";
                for (int i = 0; i < 256 && buf[phdr] > 0; ++i)
                {
                    if (phdr + i > maxBuxLen - 1)
                    {
                        SMBOut.Text += "\n" + "         Error  packet len overflow,can't continue." + "\n";
                        return phdr - oldhdr;
                    }
                    SMBOut.Text += glbl.HexToCharString(buf[phdr++]);
                }

                SMBOut.Text += "\n" + "      Server's native LAN Manager type: ";
                for (int i = 0; i < 256 && buf[phdr] > 0; ++i)
                {
                    if (phdr + i > maxBuxLen - 1)
                    {
                        SMBOut.Text += "\n" + "         Error  packet len overflow,can't continue." + "\n";
                        return phdr - oldhdr;
                    }
                    SMBOut.Text += glbl.HexToCharString(buf[phdr++]);
                }

                SMBOut.Text += "\n" + "      Server's primary domain: ";
                for (int i = 0; i < 256 && buf[phdr] > 0; ++i)
                {
                    if (phdr + i > maxBuxLen - 1)
                    {
                        SMBOut.Text += "\n" + "         Error  packet len overflow,can't continue." + "\n";
                        return phdr - oldhdr;
                    }
                    SMBOut.Text += glbl.HexToCharString(buf[phdr++]);
                }
                break;
        }
        return phdr - oldhdr;
    }

}