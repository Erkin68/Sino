﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace SMBAnalyze
{
    public partial class FormMain : Form
    {
        SmbHdr smbhdr;
        Globals glbl;
        AnalyzeCode analyze;
        public FormMain()
        {   
            InitializeComponent();
            glbl = new Globals();
            analyze = new AnalyzeCode(SMBOut, glbl);
        }

        private void AnalyzeBtn_Click(object sender, EventArgs e)
        {
            string s = textBoxInpSMB.Text;
            int l = s.Length;
            int pl = 0;
            bool bHexHalf = false;
            Byte HexHalfChar = 0;
            Byte[] smbBuf = new Byte[l];
            for (int i = 0; i < l; ++i)
            {   //if (s[i] == '\n') continue;
                if (glbl.IsHexChar(s[i]))
                {
                    if (bHexHalf)
                    {
                        smbBuf[pl++] = (Byte)((HexHalfChar << 4) + glbl.charToHex((Byte)s[i]));
                    }
                    else
                    {
                        HexHalfChar = glbl.charToHex((Byte)s[i]);
                    }
                    bHexHalf = !bHexHalf;
                }
            }
            smbBuf[pl] = 0;
            ShowSmbInptAsText(smbBuf,pl,16);
            AnalyzeSmb(smbBuf, pl);
        }

        private void AnalyzeSmb(Byte[] buf,int ln)
        {
            int phdr = -1;
            for (int pbf = 0; pbf < ln; ++pbf)
            {   if(buf[pbf]==0xff)
                if(buf[pbf+1]=='S')
                if(buf[pbf+2]=='M')
                if(buf[pbf+3]=='B')
                {   phdr = pbf+4;
                    SMBOut.Text = "SMB Header";
                    break;
                }
            }
            if (-1 == phdr)
            {   SMBOut.Text = "SMB header is not founded.";
                return;
            }
            smbhdr.MagicVal = 0xff534d42;
            Byte SmbCommand = buf[phdr];
            int hdrln = AnalyzeSmbHeader(buf,phdr);
            if (32-4 != hdrln) MessageBox.Show("SMB Header length mismatch error...");
            phdr += hdrln;
            Byte AndXCommand = 0;
            while(phdr < ln && 0xff!=AndXCommand)
                phdr += AnalyzeSmbBlock(smbhdr, buf, phdr, ln, SmbCommand, out AndXCommand);
        }

        private int AnalyzeSmbHeader(Byte[] buf, int phdr)
        {
            int oldhdr = phdr;
            SMBOut.Text += "\n" + "   SMB Command: ";
            smbhdr.Command = buf[phdr++];
            SMBOut.Text += SmbCmndAsString(smbhdr.Command);

            smbhdr.ErrorClass = buf[phdr];
            smbhdr.Reserved = buf[phdr+1];
            smbhdr.ErrorCode = glbl.smbWORD(buf, phdr+2);
            SMBOut.Text += SmbErrorAsString(smbhdr.ErrorClass, smbhdr.Reserved, smbhdr.ErrorCode);
            phdr += 4;
            smbhdr.Flag = buf[phdr++];
            smbhdr.Flag2 = glbl.smbWORD(buf, phdr);
            phdr += 2;
            SMBOut.Text += "\n" + "   Flags: " + glbl.ToHexString(smbhdr.Flag, 1);
            if (0 != (Byte)(smbhdr.Flag & 0x01))
                SMBOut.Text += "\n" + "      SMB_FLAGS_LOCK_AND_READ_OK";
            if (0 != (Byte)(smbhdr.Flag & 0x02))
                SMBOut.Text += "\n" + "      SMB_FLAGS_BUF_AVAIL";
            if (0 != (Byte)(smbhdr.Flag & 0x04))
                SMBOut.Text += "\n" + "      Reserved";
            if (0 != (Byte)(smbhdr.Flag & 0x08))
                SMBOut.Text += "\n" + "      SMB_FLAGS_CASE_INSENSITIVE";
            if (0 != (Byte)(smbhdr.Flag & 0x10))
                SMBOut.Text += "\n" + "      SMB_FLAGS_CANONICALIZED_PATHS";
            if (0 != (Byte)(smbhdr.Flag & 0x20))
                SMBOut.Text += "\n" + "      SMB_FLAGS_OPLOCK";
            if (0 != (Byte)(smbhdr.Flag & 0x40))
                SMBOut.Text += "\n" + "      SMB_FLAGS_OPBATCH";
            if (0 != (Byte)(smbhdr.Flag & 0x80))
                SMBOut.Text += "\n" + "      SMB_FLAGS_REPLY";

            SMBOut.Text += "\n" + "   Flags2: " + glbl.ToHexString(smbhdr.Flag2, 2);
            if (0 != (UInt16)(smbhdr.Flag2 & 0x01))
                SMBOut.Text += "\n" + "      SMB_FLAGS2_LONG_NAMES";
            if (0 != (UInt16)(smbhdr.Flag2 & 0x02))
                SMBOut.Text += "\n" + "      SMB_FLAGS2_EAS";
            if (0 != (UInt16)(smbhdr.Flag2 & 0x04))
                SMBOut.Text += "\n" + "      SMB_FLAGS2_SMB_SECURITY_SIGNATURE";
            if (0 != (UInt16)(smbhdr.Flag2 & 0x08))
                SMBOut.Text += "\n" + "      Unknown1";
            if (0 != (UInt16)(smbhdr.Flag2 & 0x10))
                SMBOut.Text += "\n" + "      Unknown2";
            if (0 != (UInt16)(smbhdr.Flag2 & 0x20))
                SMBOut.Text += "\n" + "      Unknown3";
            if (0 != (UInt16)(smbhdr.Flag2 & 0x40))
                SMBOut.Text += "\n" + "      SMB_FLAGS2_IS_LONG_NAME";
            if (0 != (UInt16)(smbhdr.Flag2 & 0x80))
                SMBOut.Text += "\n" + "      Unknown5";
            if (0 != (UInt16)(smbhdr.Flag2 & 0x0100))
                SMBOut.Text += "\n" + "      Unknown6";
            if (0 != (UInt16)(smbhdr.Flag2 & 0x0200))
                SMBOut.Text += "\n" + "      Unknown7";
            if (0 != (UInt16)(smbhdr.Flag2 & 0x0400))
                SMBOut.Text += "\n" + "      Unknown8";
            if (0 != (UInt16)(smbhdr.Flag2 & 0x0800))
                SMBOut.Text += "\n" + "      bExtendedSecurity";
            if (0 != (UInt16)(smbhdr.Flag2 & 0x1000))
                SMBOut.Text += "\n" + "      SMB_FLAGS2_DFS";
            if (0 != (UInt16)(smbhdr.Flag2 & 0x2000))
                SMBOut.Text += "\n" + "      SMB_FLAGS2_PAGING_IO";
            if (0 != (UInt16)(smbhdr.Flag2 & 0x4000))
                SMBOut.Text += "\n" + "      SMB_FLAGS2_NT_STATUS";
            if (0 != (UInt16)(smbhdr.Flag2 & 0x8000))
                SMBOut.Text += "\n" + "      SMB_FLAGS2_UNICODE";

            smbhdr.PID = glbl.smbWORD(buf, phdr);
            SMBOut.Text += "\n" + "   PID: " + glbl.ToHexString(smbhdr.PID, 2);
            phdr += 2;

            smbhdr.HdrReserved = glbl.smbDWORD(buf, phdr);
            SMBOut.Text += "\n" + "   SecurityFeatures for Negotiate protocol";
            SMBOut.Text += "\n" + "      HdrReserved(Crypto key for Negotiate protocol): " + glbl.ToHexString(smbhdr.HdrReserved, 3);
            phdr += 4;

            smbhdr.SessionID = glbl.smbWORD(buf, phdr);
            SMBOut.Text += "\n" + "      SessionID(connection identifier for Negotiate protocol): " + glbl.ToHexString(smbhdr.SessionID, 2);
            phdr += 2;

            smbhdr.SequenceNumber = glbl.smbWORD(buf, phdr);
            SMBOut.Text += "\n" + "      SequenceNumber: " + glbl.ToHexString(smbhdr.SequenceNumber, 2);
            phdr += 2;

            smbhdr.Padding = glbl.smbWORD(buf, phdr);
            SMBOut.Text += "\n" + "      Padding: " + glbl.ToHexString(smbhdr.Padding, 2);
            phdr += 2;

            smbhdr.TreeID = glbl.smbWORD(buf, phdr);
            SMBOut.Text += "\n" + "      TreeID: " + glbl.ToHexString(smbhdr.TreeID, 2);
            phdr += 2;

            smbhdr.CallersProcess = glbl.smbWORD(buf, phdr);
            SMBOut.Text += "\n" + "   PID: " + glbl.ToHexString(smbhdr.CallersProcess, 2);
            phdr += 2;

            smbhdr.UserID = glbl.smbWORD(buf, phdr); ;
            SMBOut.Text += "\n" + "   UID: " + glbl.ToHexString(smbhdr.UserID, 2);
            phdr += 2;

            smbhdr.MultiplexID = glbl.smbWORD(buf, phdr);
            SMBOut.Text += "\n" + "   MID: " + glbl.ToHexString(smbhdr.MultiplexID, 2);
            phdr += 2;

            return phdr - oldhdr;
        }

        private int AnalyzeSmbBlock(SmbHdr smbhdr ,Byte[] buf, int phdr, int maxBufLen, Byte SmbCommand, out Byte AndXCommand)
        {
            AndXCommand = 0;
            switch (SmbCommand)
            {
                case 0x04://SMB_COM_CLOSE
                    return analyze.AnalyzeSmbComClose(buf, phdr, maxBufLen, out AndXCommand);
                case 0x25://SMB_COM_TRANSACTION
                    return analyze.AnalyzeSmbComTransaction(smbhdr,buf, phdr, maxBufLen, out AndXCommand);
                //case 0x72://SMB_COM_NEGOTIATE
                //    return AnalyzeSmbNegotiateSessionRequest(buf,phdr);
                case 0x73://SMB_COM_SESSION_SETUP_ANDX
                    return analyze.AnalyzeSmbSessionSetupAndX(buf, phdr, maxBufLen, out AndXCommand);
            }
            return 0;
        }

        private string SmbCmndAsString(Byte c)
        {
            switch(c)
            {
                case 0x00:
                    return "SMB_COM_CREATE_DIRECTORY (0x00);";
                case 0x01:
                    return "SMB_COM_DELETE_DIRECTORY (0x01);";
                case 0x02:
                    return "SMB_COM_OPEN (0x02);";
                case 0x03:
                    return "SMB_COM_CREATE (0x03);";
                case 0x04:
                    return "SMB_COM_CLOSE (0x04);";
                case 0x05:
                    return "SMB_COM_FLUSH (0x05);";
                case 0x06:
                    return "SMB_COM_DELETE (0x06);";
                case 0x07:
                    return "SMB_COM_RENAME (0x07);";
                case 0x08:
                    return "SMB_COM_QUERY_INFORMATION (0x08);";
                case 0x09:
                    return "SMB_COM_SET_INFORMATION (0x09);";
                case 0x0A:
                    return "SMB_COM_READ (0x0A);";
                case 0x0B:
                    return "SMB_COM_WRITE (0x0B);";
                case 0x0C:
                    return "SMB_COM_LOCK_BYTE_RANGE (0x0C);";
                case 0x0D:
                    return "SMB_COM_UNLOCK_BYTE_RANGE (0x0D);";
                case 0x0E:
                    return "SMB_COM_CREATE_TEMPORARY (0x0E);";
                case 0x0F:
                    return "SMB_COM_CREATE_NEW (0x0F);";
                case 0x10:
                    return "SMB_COM_CHECK_DIRECTORY (0x10);";
                case 0x11:
                    return "SMB_COM_PROCESS_EXIT (0x11);";
                case 0x12:
                    return "SMB_COM_SEEK (0x12);";
                case 0x13:
                    return "SMB_COM_LOCK_AND_READ (0x13);";
                case 0x14:
                    return "SMB_COM_WRITE_AND_UNLOCK (0x14);";
                case 0x1A:
                    return "SMB_COM_READ_RAW (0x1A);";
                case 0x1B:
                    return "SMB_COM_READ_MPX (0x1B);";
                case 0x1C:
                    return "SMB_COM_READ_MPX_SECONDARY (0x1C);";
                case 0x1D:
                    return "SMB_COM_WRITE_RAW (0x1D);";
                case 0x1E:
                    return "SMB_COM_WRITE_MPX (0x1E);";
                case 0x20:
                    return "SMB_COM_WRITE_COMPLETE (0x20);";
                case 0x22:
                    return "SMB_COM_SET_INFORMATION2 (0x22);";
                case 0x23:
                    return "SMB_COM_QUERY_INFORMATION2 (0x23);";
                case 0x24:
                    return "SMB_COM_LOCKING_ANDX (0x24);";
                case 0x25:
                    return "SMB_COM_TRANSACTION (0x25);";
                case 0x26:
                    return "SMB_COM_TRANSACTION_SECONDARY (0x26);";
                case 0x27:
                    return "SMB_COM_IOCTL (0x27);";
                case 0x28:
                    return "SMB_COM_IOCTL_SECONDARY (0x28);";
                case 0x29:
                    return "SMB_COM_COPY (0x29);";
                case 0x2A:
                    return "SMB_COM_MOVE (0x2A);";
                case 0x2B:
                    return "SMB_COM_ECHO (0x2B);";
                case 0x2C:
                    return "SMB_COM_WRITE_AND_CLOSE (0x2C);";
                case 0x2D:
                    return "SMB_COM_OPEN_ANDX (0x2D);";
                case 0x2E:
                    return "SMB_COM_READ_ANDX (0x2E);";
                case 0x2F:
                    return "SMB_COM_WRITE_ANDX (0x2F);";
                case 0x31:
                    return "SMB_COM_CLOSE_AND_TREE_DISC (0x31);";
                case 0x32:
                    return "SMB_COM_TRANSACTION2 (0x32);";
                case 0x33:
                    return "SMB_COM_TRANSACTION2_SECONDARY (0x33);";
                case 0x34:
                    return "SMB_COM_FIND_CLOSE2 (0x34);";
                case 0x35:
                    return "SMB_COM_FIND_NOTIFY_CLOSE (0x35);";
                case 0x70:
                    return "SMB_COM_TREE_CONNECT (0x70);";
                case 0x71:
                    return "SMB_COM_TREE_DISCONNECT (0x71);";
                case 0x72:
                    return "SMB_COM_NEGOTIATE (0x72);";
                case 0x73:
                    return "SMB_COM_SESSION_SETUP_ANDX (0x73);";
                case 0x74:
                    return "SMB_COM_LOGOFF_ANDX (0x74);";
                case 0x75:
                    return "SMB_COM_TREE_CONNECT_ANDX (0x75);";
                case 0x80:
                    return "SMB_COM_QUERY_INFORMATION_DISK (0x80);";
                case 0x81:
                    return "SMB_COM_SEARCH (0x81);";
                case 0x82:
                    return "SMB_COM_FIND (0x82);";
                case 0x83:
                    return "SMB_COM_FIND_UNIQUE (0x83);";
                case 0xA0:
                    return "SMB_COM_NT_TRANSACT (0xA0);";
                case 0xA1:
                    return "SMB_COM_NT_TRANSACT_SECONDARY (0xA1);";
                case 0xA2:
                    return "SMB_COM_NT_CREATE_ANDX (0xA2);";
                case 0xA4:
                    return "SMB_COM_NT_CANCEL (0xA4);";
                case 0xC0:
                    return "SMB_COM_OPEN_PRINT_FILE (0xC0);";
                case 0xC1:
                    return "SMB_COM_WRITE_PRINT_FILE (0xC1);";
                case 0xC2:
                    return "SMB_COM_CLOSE_PRINT_FILE (0xC2);";
                case 0xC3:
                    return "SMB_COM_GET_PRINT_QUEUE (0xC3);";
                case 0xD8:
                    return "SMB_COM_READ_BULK (0xD8);";
                case 0xD9:
                    return "SMB_COM_WRITE_BULK (0xD9);";
                case 0xDA:
                    return "SMB_COM_WRITE_BULK_DATA (0xDA);";
            }
            return "Unknown Smb command;";
        }

        private string SmbErrorAsString(Byte ErrorClass,Byte Reserved,UInt16 ErrorCode)
        {
            string s = "\n" + "   Error:" + "\n" + "      Class: ";
            switch (ErrorClass)
            {
                case 0:
                    s += "SMBSUCCESS (0x00)";
                    break;
                case 1:
                    s += "ERRDOS (0x01)";
                    break;
                case 2:
                    s += "ERRSRV (0x02)";
                    break;
                case 3:
                    s += "ERRHRD (0x03)";
                    break;
                case 0xff:
                    s += "ERRCMD (0xff)";
                    break;
                default:
                    s += "Unknown error class (" + glbl.ToHexString(ErrorClass, 1) + ")";
                    break;
            }
            s += "\n" + "      Reserved: (" + glbl.ToHexString(Reserved, 1) + ")";
            s += "\n" + "      Code:";
            if (1 == ErrorClass)//ERRDOS
            {
                switch (ErrorCode)
                {
                    case 0:
                        s += "      Success (0x00)";
                        break;
                    case 1://Invalid function
                        s += "      ERRbadfunc (0x01)";
                        break;
                    case 2://File not found (last component)
                        s += "      ERRbadfile (0x02)";
                        break;
                    case 3://Directory invalid
                        s += "      ERRbadpath (0x03)";
                        break;
                    case 4://Too many open files
                        s += "      ERRnofids (0x04)";
                        break;
                    case 5://Access denied
                        s += "      ERRnoaccess (0x05)";
                        break;
                    case 6://Invalid file handle
                        s += "      ERRbadfid (0x06)";
                        break;
                    case 7://Memory control blocks destroyed (huh ?)
                        s += "      ERRbadmcb (0x07)";
                        break;
                    case 8://Insufficient memory
                        s += "      ERRnomem (0x08)";
                        break;
                    case 9://Invalid memory block address
                        s += "      ERRbadmem (0x09)";
                        break;
                    case 10://Invalid environment
                        s += "      ERRbadenv (0x0A)";
                        break;
                    case 11://Invalid format
                        s += "      ERRbadformat (0x0B)";
                        break;
                    case 12://Invalid open mode
                        s += "      ERRbadaccess (0x0C)";
                        break;
                    case 13://Invalid data
                        s += "      ERRbaddata (0x0D)";
                        break;
                    case 15://Invalid drive specified
                        s += "      ERRbaddrive (0x0F)";
                        break;
                    case 16://An attempt to delete current directory
                        s += "      ERRremcd (0x10)";
                        break;
                    case 17://cross fs rename/move
                        s += "      ERRdiffdevice (0x11)";
                        break;
                    case 18://no more files found in file search
                        s += "      ERRnofiles (0x12)";
                        break;
                    case 32://Share mode can't be granted
                        s += "      ERRbadshare (0x20)";
                        break;
                    case 33://A lock request conflicts with existing lock
                        s += "      ERRlock (0x21)";
                        break;
                    case 50://unsupported - Win 95
                        s += "      ERRunsup (50";
                        break;
                    case 66://ipc unsupported
                        s += "      ERRnoipc (66";
                        break;
                    case 67://invalid share name
                        s += "      ERRnosuchshare (67";
                        break;
                    case 80://The file named in the request already exists
                        s += "      ERRfilexists (80)";
                        break;
                    case 112://W2K returns this if quota space exceeds
                        s += "      ERRquota (112)";
                        break;
                    case 110://cannot open the file
                        s += "      ERRcannotopen (110)";
                        break;
                    case 123:
                        s += "      ERRinvalidname (123)";
                        break;
                    case 124:
                        s += "      ERRunknownlevel (124)";
                        break;
                    case 158://region was not locked by this context
                        s += "      ERRnotlocked (158)";
                        break;
                    case 183:
                        s += "      ERRrename (183)";
                        break;
                    case 230://named pipe invalid
                        s += "      ERRbadpipe (230)";
                        break;
                    case 231://all pipe instances are busy
                        s += "      ERRpipebusy (231)";
                        break;
                    case 232://close in progress
                        s += "      ERRpipeclosing (232)";
                        break;
                    case 233://nobody on other end of pipe
                        s += "      ERRnotconnected (233)";
                        break;
                    case 234://more data to be returned
                        s += "      ERRmoredata (234)";
                        break;
                    case 267://invalid directory name
                        s += "      ERRbaddirectory (267)";
                        break;
                    case 282://extended attributes not supported
                        s += "     ERReasunsupported  (282)";
                        break;
                    case 2142:
                        s += "      ERRunknownipc (2142)";
                        break;
                    case 2123:
                        s += "      ERRbuftoosmall (2123)";
                        break;
                    case 2151:
                        s += "      ERRnosuchprintjob (2151)";
                        break;
                    default:
                        s += "      Unknown error (" + glbl.ToHexString(ErrorCode, 2) + ")";
                        break;
            }   }
            else if (2 == ErrorClass)//ERRSRV
            {
                switch (ErrorCode)
                {
                    case 1://Non-specific error code
                        s += "      ERRerror (1)";
                        break;
                    case 2://Bad password
                        s += "      ERRbadpw (2)";
                        break;
                    case 3://reserved
                        s += "      ERRbadtype (3)";
                        break;
                    case 4://The client doesn't have enough access rights
                        s += "      ERRaccess (4)";
                        break;
                    case 5://The Tid specified in a command is invalid
                        s += "      ERRinvnid (5)";
                        break;
                    case 6://Invalid server name in the tree connect
                        s += "      ERRinvnetname (6)";
                        break;
                    case 7://Printer and not printer devices are mixed
                        s += "      ERRinvdevice (7)";
                        break;
                    case 49://Print queue full
                        s += "      ERRqfull (49)";
                        break;
                    case 50://Print queue full - no space
                        s += "      ERRqtoobig (50)";
                        break;
                    case 52://Invalid print file FID
                        s += "      ERRinvpfid (52)";
                        break;
                    case 64://The server did not recognize the command
                        s += "      ERRsmbcmd (64)";
                        break;
                    case 65://The server encountered and internal error
                        s += "      ERRsrverror (65)";
                        break;
                    case 67://The Fid and path name contains an invalid combination
                        s += "      ERRfilespecs (67)";
                        break;
                    case 69://Access mode invalid
                        s += "      ERRbadpermits (69)";
                        break;
                    case 71://Attribute mode invalid
                        s += "      ERRsetattrmode (71)";
                        break;
                    case 81://Server is paused
                        s += "      ERRpaused (81)";
                        break;
                    case 82://Not receiving messages
                        s += "      ERRmsgoff (82)";
                        break;
                    case 83://No room to buffer message
                        s += "      ERRnoroom (83)";
                        break;
                    case 87://Too many remote user names
                        s += "      ERRrmuns (87)";
                        break;
                    case 88://Operation timed out
                        s += "      ERRtimeout (88)";
                        break;
                    case 89://No resources currently available for request
                        s += "      ERRnoresource (89)";
                        break;
                    case 90://Too many UIDs active on this session
                        s += "      ERRtoomanyuids (90)";
                        break;
                    case 91://The UID is not known in this session
                        s += "      ERRbaduid (91)";
                        break;
                    case 250://Temporarily unable to support Raw, use MPX mode
                        s += "      ERRusempx (250)";
                        break;
                    case 251://Temporarily unable to support Raw, use standard r/w
                        s += "      ERRusestd (251)";
                        break;
                    case 252://Continue in MPX mode
                        s += "      ERRcontmpx (252)";
                        break;
                    case 254:
                        s += "      ERRbadPassword (254)";
                        break;
                    case 2239:
                        s += "      ERRaccountExpired (2239)";
                        break;
                    case 2240://Cannot access the server from this workstation
                        s += "      ERRbadClient (2240)";
                        break;
                    case 2241://Cannot access the server at this time
                        s += "      ERRbadLogonTime (2241)";
                        break;
                    case 2242:
                        s += "      ERRpasswordExpired (2242)";
                        break;
                    case 65535://Invalid function
                        s += "      ERRnosupport (65535)";
                        break;
                    default:
                        s += "      Unknown error (" + glbl.ToHexString(ErrorCode, 2) + ")";
                        break;
                }
            }
            else if (3 == ErrorClass)//RRHRD 
            {
                switch (ErrorCode)
                {
                    case 19://write protected media
                        s += "      ERRnowrite (19)";
                        break;
                    case 20://Unknown unit
                        s += "      ERRbadunit (20)";
                        break;
                    case 21://Drive not ready
                        s += "      ERRnotready (21)";
                        break;
                    case 22://Unknown command
                        s += "      ERRbadcmd (22)";
                        break;
                    case 23://Data error (CRC)
                        s += "      ERRdata (23)";
                        break;
                    case 24://Bad request structure length
                        s += "      ERRbadreq (24)";
                        break;
                    case 25://Seek error
                        s += "      ERRseek (25)";
                        break;
                    case 26://Unknown media type
                        s += "      ERRbadmedia (26)";
                        break;
                    case 27://Sector not found
                        s += "      ERRbadsector (27)";
                        break;
                    case 28://Printer out of paper
                        s += "      ERRnopaper (28)";
                        break;
                    case 29://Write fault
                        s += "      ERRwrite (29)";
                        break;
                    case 30://Read fault
                        s += "      ERRread (30)";
                        break;
                    case 31://General failure
                        s += "      ERRgeneral (31)";
                        break;
                    case 32://An open conflicts with an existing open
                        s += "      ERRbadshare (32)";
                        break;
                    case 33://lock/unlock conflict
                        s += "      ERRlock (33)";
                        break;
                    case 34://The wrong disk was found in a drive
                        s += "      ERRwrongdisk (34)";
                        break;
                    case 35://No FCBs available
                        s += "      ERRFCBunavail (35)";
                        break;
                    case 36://A sharing buffer has been exceeded
                        s += "      ERRsharebufexc (36)";
                        break;
                    case 39:
                        s += "      ERRdiskfull (39)";
                        break;
                    //RAP ERRORS:
                    case 5:
                        s += "      SMB_ERROR_ACCESS_DENIED (5)";
                        break;
                    case 65:
                        s += "      SMB_ERROR_NETWORK_ACCESS_DENIED (65)";
                        break;
                    case 234:
                        s += "      SMB_ERROR_MORE_DATA (234)";
                        break;                        
                    default:
                        s += "      Unknown error (" + glbl.ToHexString(ErrorCode, 2) + ")";
                        break;
            }    }
            else
                s += "      Unknown error (" + glbl.ToHexString(ErrorCode, 2) + ")";
            return s;
        }

        public void ShowSmbInptAsText(Byte[] buf, int ln, int lineLn)
        {
            SmbAsText.Text = "";
            for (int i = 0; i < ln; ++i)
            {
                SmbAsText.Text += glbl.HexToCharString(buf[i]);
                //if (0 == i % 2) SmbAsText.Text += " ";
                if (i > 0) if (0 == i % lineLn) SmbAsText.Text += "\n";
            }
        }

        private void Form1_Resize(object sender, EventArgs e)
        {
            int w = Size.Width;
            int h = Size.Height;
            if (w<1) return;
            if (h<1) return;
            textBoxInpSMB.SetBounds(1, 18, (int)(0.54875 * w), (int)(0.31625 * h));
            SmbAsText.SetBounds(textBoxInpSMB.Size.Width + 1,18,(int)(0.42625 * w),(int)(0.31625 * h));
            AnalyzeBtn.SetBounds(7, textBoxInpSMB.Size.Height + 18, 75, 23);
            SaveAsBtn.SetBounds((int)(0.87375 * w),AnalyzeBtn.Location.Y,82,23);
            SMBOut.SetBounds(1, AnalyzeBtn.Location.Y + 28, (int)(0.975 * w), (int)(0.53887 * h));            
        }

        private void SaveAsBtn_Click(object sender, EventArgs e)
        {
            if (0 == SMBOut.Text.Length) return;
            OpenFileDialog opfDlg = new OpenFileDialog();
            opfDlg.Filter = "All Files|*.*";//"Cursor Files|*.cur";
            opfDlg.Title = "Select a file to save results...";
            opfDlg.Multiselect = false;
            opfDlg.CheckFileExists = false;
            if (opfDlg.ShowDialog() == DialogResult.OK)//this.set_Cursor(new Cursor(openFileDialog1.OpenFile())); 
            {
                using (System.IO.StreamWriter sw = new System.IO.StreamWriter(opfDlg.FileName))
                {
                    sw.Write(SMBOut.Text);
                    sw.Close();
                }
                opfDlg.Dispose();
            }
        }

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormAbout formAbt = new FormAbout();
            formAbt.ShowDialog();
            formAbt.Dispose();
        }

        private void sample1ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SMBOut.Text = SmbAsText.Text="";
            textBoxInpSMB.Text = 
                "00 00 00 f3 ff 53 4d 42 73 16 00 00 c0 98 07 c8" + "\n" +
                "00 00 00 00 00 00 00 00 00 00 00 00 ff ff ff fe" + "\n" +
                "00 08 10 00 04 ff 00 f3 00 00 00 7e 00 c8 00 4e" + "\n" +
                "54 4c 4d 53 53 50 00 02 00 00 00 06 00 06 00 38" + "\n" +
                "00 00 00 15 82 8a e2 f1 6c c9 75 36 e0 05 02 00" + "\n" +
                "00 00 00 00 00 00 00 40 00 40 00 3e 00 00 00 05" + "\n" +
                "01 28 0a 00 00 00 0f 53 00 45 00 52 00 02 00 06" + "\n" +
                "00 53 00 45 00 52 00 01 00 06 00 53 00 45 00 52" + "\n" +
                "00 04 00 06 00 73 00 65 00 72 00 03 00 06 00 73" + "\n" +
                "00 65 00 72 00 06 00 04 00 01 00 00 00 07 00 08" + "\n" +
                "00 8a 83 85 db 25 d2 ce 01 00 00 00 00 00 57 00" + "\n" +
                "69 00 6e 00 64 00 6f 00 77 00 73 00 20 00 35 00" + "\n" +
                "2e 00 31 00 00 00 57 00 69 00 6e 00 64 00 6f 00" + "\n" +
                "77 00 73 00 20 00 32 00 30 00 30 00 30 00 20 00" + "\n" +
                "4c 00 41 00 4e 00 20 00 4d 00 61 00 6e 00 61 00" + "\n" +
                "67 00 65 00 72 00 00 00 00 00 00 00 00 00 00 00" + "\n" +
                "00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00" + "\n" +
                "00 00 00 00 00 00 00 00 00 00 00 00";
        }

        private void sample2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SMBOut.Text = SmbAsText.Text = "";
            textBoxInpSMB.Text = 
                "00 00 00 23 ff 53 4d 42 04 00 00 00 00 98 07 c8" + "\n" +
                "00 00 00 00 00 00 00 00 00 00 00 00 00 10 ff fe" + "\n" +
                "03 10 90 00 00 00 00 00 00 00 00 00 00 00 00 5c" + "\n" +
                "00 3c 00 00 00 00 00 00 00 00 00 00 00 5d 00 00" + "\n" +
                "05 00 0c 03 10 00 00 00 5c 00 00 00";
        }
        private void sample3ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SMBOut.Text = SmbAsText.Text = "";
            textBoxInpSMB.Text =
                "00 00 00 b8 ff 53 4d 42 25 00 00 00 00 18 07 c8" + "\n" +
                "00 00 00 00 00 00 00 00 00 00 00 00 00 10 2c 1e" + "\n" +
                "03 10 80 00 10 00 00 64 00 00 00 00 04 00 00 00" + "\n" +
                "00 00 00 00 00 00 00 00 00 54 00 64 00 54 00 02" + "\n" +
                "00 26 00 05 40 75 00 00 5c 00 50 00 49 00 50 00" + "\n" +
                "45 00 5c 00 00 00 00 00 05 00 00 03 10 00 00 00" + "\n" +
                "64 00 00 00 02 00 00 00 4c 00 00 00 00 00 0f 00" + "\n" +
                "00 00 02 00 10 00 00 00 00 00 00 00 10 00 00 00" + "\n" +
                "5c 00 5c 00 31 00 39 00 32 00 2e 00 31 00 36 00" + "\n" +
                "38 00 2e 00 31 00 39 00 2e 00 32 00 35 00 00 00" + "\n" +
                "01 00 00 00 01 00 00 00 04 00 02 00 00 00 00 00" + "\n" +
                "00 00 00 00 ff ff ff ff 00 00 00 00 00 00 00 00" + "\n" +
                "57 00 69 00 6e 00 64 00 6f 00 77 00 73 00 20 00" + "\n" +
                "35 00 2e 00 31 00 00 00 57 00 69 00 6e 00 64 00" + "\n";
        }
                
    }
}
