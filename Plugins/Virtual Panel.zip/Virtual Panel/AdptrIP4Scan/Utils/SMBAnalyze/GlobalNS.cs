﻿using System;
using System.Collections.Generic;
using System.ComponentModel;

class Globals
{
    public UInt16 smbWORD(Byte[] buf, int ptr)
    {
        return (UInt16)((buf[ptr + 1] << 8) | buf[ptr]);
    }

    public UInt32 smbDWORD(Byte[] buf, int ptr)
    {
        return (UInt32)((buf[ptr + 3] << 8) | (buf[ptr + 2] << 8) | (buf[ptr + 1] << 8) | buf[ptr]);
    }

    public UInt16 smbWORDRec(Byte[] buf, int ptr)
    {
        return (UInt16)((buf[ptr] << 8) | buf[ptr+1]);
    }

    public UInt32 smbDWORDRec(Byte[] buf, int ptr)
    {
        return (UInt32)((buf[ptr] << 8) | (buf[ptr + 1] << 8) | (buf[ptr + 2] << 8) | buf[ptr+3]);
    }

    public string ToDecAndHexString(UInt32 c, int t)
    {
        if (1 == t)//if (c <= 0xff)//byte:
            return c.ToString() + " (0x" + c.ToString("X2") + ")";
        if (2 == t)//if (c <= 0xffff)//word:
            return c.ToString() + " (0x" + c.ToString("X4") + ")";
        if (3 == t)//if (c <= 0xffff)//word:
            return c.ToString() + " (0x" + c.ToString("X8") + ")";
        return "0x00";
    }

    public string ToHexString(UInt32 c, int t)
    {
        if (1 == t)//if (c <= 0xff)//byte:
            return "0x" + c.ToString("X2");
        if (2 == t)//if (c <= 0xffff)//word:
            return "0x" + c.ToString("X4");
        if (3 == t)//if (c <= 0xffff)//word:
            return "0x" + c.ToString("X8");
        return "0x00";
    }

    public string HexToCharString(Byte c)
    {
        char s = '.';
        if (c > 10)
            s = (char)c;
        return s.ToString();
    }

    public string HexToWCharString(UInt16 c)
    {
        UInt16 s = '.';
        if (c > 10)
            s = (UInt16)c;
        return s.ToString();
    }

    public bool IsHexChar(char c)
    {
        if (c >= '0' && c <= '9')
            return true;
        if (c >= 'a' && c <= 'f')
            return true;
        if (c >= 'A' && c <= 'F')
            return true;
        return false;
    }

    public Byte charToHex(Byte c)
    {
        if (c >= '0' && c <= '9')
            return (Byte)(c - 0x30);
        if (c >= 'a' && c <= 'f')
            return (Byte)(10 + c - 'a');
        if (c >= 'A' && c <= 'F')
            return (Byte)(10 + c - 'A');
        return 0;
    }

}