#pragma warning(disable:4996)

#include "MySmbReq.h"
#include "Lm.h"
#include <time.h>


short cnstTREE_ID, cnstCALLER_PROCESS, cnstUSER_ID, cnstMULTIPLEX_ID;


char dialects[120] =
"\x02PC NETWORK PROGRAM 1.0\x00"
"\x02LANMAN1.0\x00"
"\x02Windows for Workgroups 3.1a\x00"
"\x02LM1.2X002\x00"
"\x02LANMAN2.1\x00"
"\x02NT LM 0.12\x00"
"\x02SMB 2.002\x00"
"\x02SMB 2.???\x00";


void main()
{
WSADATA wsaData;
SOCKET s;
u_long iMode = 0;
int err = 1500;//timeout
struct sockaddr_in src,dest;
char buf[1024];//response datas:
//wchar_t compName[32],domainName[32];

//	if(!GetNetInf(&compName[0],&domainName[0]))
//	{	Beep(0,0);
//	}

	srand((unsigned)time(NULL));
	cnstTREE_ID = 0xffff;// * rand() / (RAND_MAX + 1);
	cnstCALLER_PROCESS = 0xfeff;// * rand() / (RAND_MAX + 1);
	cnstUSER_ID = 0;//0xffff * rand() / (RAND_MAX + 1);
	cnstMULTIPLEX_ID = 0x0010;//0xffff * rand() / (RAND_MAX + 1);

	if(WSAStartup(MAKEWORD(2,2),&wsaData))
		exit(-1);

	s = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
	if(INVALID_SOCKET == s){err=-2;goto End;}

	src.sin_family = AF_INET;
	src.sin_addr.s_addr = inet_addr(SRCIP);
	src.sin_port = htons(srcPort);
	//if(bind(s,&src,sizeof(src))){err=-3;goto End;}

	ioctlsocket(s, FIONBIO, &iMode);
	setsockopt(s,SOL_SOCKET,SO_RCVTIMEO,(char*)&err,sizeof(int));
	err = 0;

	dest.sin_family = AF_INET;
	dest.sin_addr.s_addr = inet_addr(DSTIP);
	dest.sin_port = htons(dstWINSPort);//Agar NBT bo'lsa bunday ishlamaskan;
	if(connect(s, (struct sockaddr*)&dest, sizeof (dest)) < 0)
	{	//dest.sin_port = htons(dstNBTPort);
		//if(connect(s, (struct sockaddr*)&dest, sizeof (dest)) < 0)
			{err=-4;goto End;}
	}

	SendSessionRequest(s);//Init smb session;

	err = recv(s,buf,1024,0);
	if(SOCKET_ERROR ==err || err<sizeof(SMBHEADER)) goto End;
	
	err = AnalyzeSessionResponse1(buf);
	if(err<0) goto End;
	//err number os series dialects which are selected via server:
	//	0-PC NETWORK PROGRAM 1.0;
	//	1-from LANMAN1.0 to LANMAN2.1;
	//	2-from NT LM 0.12 up to SMB...;

	SmbSessionSetupAndX1(s);//Make_SessionSetupX(s);
	//err = recv(s,buf,1024,0);
	//if(SOCKET_ERROR ==err || err<sizeof(SMBHEADER)) goto End;


/*00 00 00 55 ff 53 4d 42 72 00 00 00 00 98 53 c8 00 00 00 00 00 00 00 00 00 00 00 00 ff ff ff  ...U�SMBr.....S�............���
  fe 00 00 00 00 11 05 00 03 0a 00 01 00 04 11 00 00 00 00 01 00 00 00 00 00 fd e3 00 80 84 63  �........................��.�.c
  02 49 76 d1 ce 01 10 ff 00 10 00 11 96 32 ed 40 65 00 4e a9 e3 a1 f1 77 ca f5 32 cc cc cc cc  .Iv��..�....�2�@e.N���w��2����*/

/*00 00 00 55 ff 53 4d 42 72 00 00 00 00 98 53 c8 00 00 00 00 00 00 00 00 00 00 00 00 ff ff ff  ...U�SMBr.....S�............���
  fe 00 00 00 00 11 05 00 03 0a 00 01 00 04 11 00 00 00 00 01 00 00 00 00 00 fd e3 00 80 20 49  �........................��.� I
  3f 97 4a c0 ce 01 10 ff 00 10 00 96 8a e0 9a 3e 58 1b 41 8b fe 11 a0 79 bd 04 d8 */

End:
	WSACleanup();
	exit(err);
}

void SendSessionRequest(SOCKET s)
{
PSMBNEGOTIATE_REQUEST smbreq = malloc(sizeof(SMBNEGOTIATE_REQUEST)+37);
	//Fill SMB request structure:
	smbreq->p.nbtsmb = 0;
	smbreq->p.flag   = 0;
	smbreq->p.smbpacketlen = htons(sizeof(SMBNEGOTIATE_REQUEST)-sizeof(DWORD));
	
	smbreq->p.smbhdr.MagicVal = SMBMAGICVAL;
	smbreq->p.smbhdr.Command = SMB_COM_NEGOTIATE;
	smbreq->p.smbhdr.NTError = 0x00000000;
	smbreq->p.smbhdr.bLockAndReadWriteAndUnlock = 0;
	smbreq->p.smbhdr.bLockAndReadWriteAndUnlock = 0;
	smbreq->p.smbhdr.bSendWithoutAck = 0;
	smbreq->p.smbhdr.bReservedBit = 0;
	smbreq->p.smbhdr.bNoCaseSensitivePaths = 1;
	smbreq->p.smbhdr.bCanonicalizedPaths = 1;
	smbreq->p.smbhdr.bOpportunisticLocks = 0;
	smbreq->p.smbhdr.bChangeNotify = 0;
	smbreq->p.smbhdr.bResponse = 0;
	smbreq->p.smbhdr.bLongFilenames = 1;
	smbreq->p.smbhdr.bExtendedAttributes = 1;
	smbreq->p.smbhdr.bFlags2IsLongName = 0;
	smbreq->p.smbhdr.bUnknown1 = 0;
	smbreq->p.smbhdr.bUnknown2 = 1;
	smbreq->p.smbhdr.bUnknown3 = 0;
	smbreq->p.smbhdr.bUnknown4 = 1;
	smbreq->p.smbhdr.bUnknown5 = 0;
	smbreq->p.smbhdr.bUnknown6 = 0;
	smbreq->p.smbhdr.bUnknown7 = 0;
	smbreq->p.smbhdr.bUnknown8 = 0;
	smbreq->p.smbhdr.bExtendedSecurity = 1;
	smbreq->p.smbhdr.bResolveViaDFS= 0;
	smbreq->p.smbhdr.bReadGrantedWithExecPerms = 0;
	smbreq->p.smbhdr.bNTErrorCodes = 1;
	smbreq->p.smbhdr.bUnicodeStrings = 1;
	smbreq->p.smbhdr.PID = 0;
	smbreq->p.smbhdr.HdrReserved = 0;
	smbreq->p.smbhdr.SessionID = 0;
	smbreq->p.smbhdr.SequenceNumber = 0;
	smbreq->p.smbhdr.Padding[0] = 0;
	smbreq->p.smbhdr.Padding[1] = 0;
	smbreq->p.smbhdr.TreeID = cnstTREE_ID;
	smbreq->p.smbhdr.CallersProcess = cnstCALLER_PROCESS;
	smbreq->p.smbhdr.UserID = cnstUSER_ID;
	smbreq->p.smbhdr.MultiplexID = cnstMULTIPLEX_ID;

	smbreq->structSize = htons(sizeof(smbreq->dialects));
	smbreq->dialectCount = 0;
	memcpy(smbreq->dialects,dialects,sizeof(dialects));
	ZeroMemory(((char*)smbreq)+sizeof(SMBNEGOTIATE_REQUEST),37);
	send(s,(char*)smbreq,sizeof(SMBNEGOTIATE_REQUEST)+37,0);
}

//1-Requestga javobni tekshiradi:
int AnalyzeSessionResponse1(UCHAR *buf)
{
PSMBNEGOTIATE_REQUEST pSlctDlctSmbHdr = (PSMBNEGOTIATE_REQUEST)buf;
PSMBDIALECTSELECTHEADER pSlctDlct = (PSMBDIALECTSELECTHEADER)&buf[sizeof(SMBHEADER)+4];
PPLANMAN2_1_DIALECTSELECTHEADER pPLANMAN2_1_DIALECTSELECTHEADER = 
							(PPLANMAN2_1_DIALECTSELECTHEADER)&buf[sizeof(SMBHEADER)+4];
PNT_LM_0_12_DIALECTSELECTHEADER pPNT_LM_0_12_DIALECTSELECTHEADER = 
							(PNT_LM_0_12_DIALECTSELECTHEADER)&buf[sizeof(SMBHEADER)+4];

	//Check response packet to smb consistence:
	if(0x424d53ff!=pSlctDlctSmbHdr->p.smbhdr.MagicVal)return -1;
	if(0x72!=pSlctDlctSmbHdr->p.smbhdr.Command)return -2;
	
	//Find response which dialect used:
	switch(pSlctDlct->Len)
	{	case 1://PC NETWORK PROGRAM 1.0 dialect choisen or server does not understand any of the dialect strings;
			if(pSlctDlct->Len != 1)return -3;
			if(pSlctDlct->DialectIndex > 0)return -4;
			return 0;
		case 13://Up from PC NETWORK PROGRAM 1.0 to LANMAN2.1 dialect selected;
			if(pPLANMAN2_1_DIALECTSELECTHEADER->DialectIndex < 1)return -5;
			if(pPLANMAN2_1_DIALECTSELECTHEADER->DialectIndex > 4)return -6;
			if(pPLANMAN2_1_DIALECTSELECTHEADER->MaxBufferSize<1024)return -7;
			/*	MaxBufferSize is the size of the largest message which the client can legitimately send to the server. 
				If bit0 of the Flags field is set in the negotiate response, this indicates the server supports
				the obsolescent SMB_COM_LOCK_AND_READ and SMB_COM_WRITE_AND_UNLOCK client requests. 
				If the SecurityMode field indicates the server is running in user mode, the client must send
				appropriate SMB_COM_SESSION_SETUP_ANDX requests before the server will allow the client to access
				resources. If the SecurityMode field indicates the client should use challenge/response
				authentication, the client should use the authentication mechanism specified in the Section 2.8. 
				Clients using the "MICROSOFT NETWORKS 1.03" dialect use a different form of raw reads than
				documented here, and servers are better off setting RawMode in this response to 0 for such sessions.
				If the negotiated dialect is "DOS LANMAN2.1" or "LANMAN2.1", then PrimaryDomain string should be
				included in this response.*/
			return 1;
		case 17://NT LM 0.12 or upper (SMB) dialect selected;
			if(pPNT_LM_0_12_DIALECTSELECTHEADER->DialectIndex < 5)return -8;
			if(pPNT_LM_0_12_DIALECTSELECTHEADER->DialectIndex > 7)return -9;
			/*	In addition to the definitions above, MaxBufferSize is the size of the largest message which the
				client can legitimately send to the server. If the client is using a connectionless protocol,
				MaxBufferSize must be set to the smaller of the server's internal buffer size and the amount of data
				which can be placed in a response packet. MaxRawSize specifies the maximum message size the server
				can send or receive for the obsolescent SMB_COM_WRITE_RAW or SMB_COM_READ_RAW requests. Connectionless
				clients must set Sid to 0 in the SMB request header. The Capabilities field allows the server to
				tell the client what it supports. The client must not ignore any capabilities specified by the
				server. The bit definitions are: 
				Capability Name	Encoding	Meaning 
				CAP_RAW_MODE	0x0001	The server supports SMB_COM_READ_RAW and SMB_COM_WRITE_RAW (obsolescent) 
				CAP_MPX_MODE	0x0002	The server supports SMB_COM_READ_MPX and SMB_COM_WRITE_MPX (obsolescent) 
				CAP_UNICODE		0x0004	The server supports UNICODE strings 
				CAP_LARGE_FILES 0x0008	The server supports large files with 64 bit offsets 
				CAP_NT_SMBS		0x0010	The server supports the SMBs particular to the NT LM 0.12 dialect. Implies CAP_NT_FIND. 
				CAP_RPC_REMOTE_APIS 0x0020 The server supports remote admin API requests via DCE RPC 
				CAP_STATUS32	0x0040	The server can respond with 32 bit status codes in Status.Status 
				CAP_LEVEL_II_OPLOCKS 0x0080 The server supports level 2 oplocks 
				CAP_LOCK_AND_READ 0x0100	The server supports the SMB,SMB_COM_LOCK_AND_READ 
				CAP_NT_FIND		0x0200		Reserved 
				CAP_DFS			0x1000		The server is DFS aware 
				CAP_INFOLEVEL_PASSTHRU 0x2000 The server supports NT information level requests passing through 
				CAP_LARGE_READX 0x4000		The server supports large SMB_COM_READ_ANDX (up to 64k) 
				CAP_LARGE_WRITEX 0x8000		The server supports large SMB_COM_WRITE_ANDX (up to 64k) 
				CAP_UNIX		0x00800000	The server supports CIFS Extensions for UNIX. (See Appendix D for more detail) 
				CAP_RESERVED	0x02000000	Reserved for future use 
				CAP_BULK_TRANSFER 0x20000000 The server supports SMB_BULK_READ, SMB_BULK_WRITE (should be 0, no known implementations ) 
				CAP_COMPRESSED_DATA 0x40000000 The server supports compressed data transfer (BULK_TRANSFER capability is required to support compressed data transfer). 
				CAP_EXTENDED_SECURITY 0x80000000 The server supports extended security exchanges 
					Undefined bit MUST be set to zero by servers, and MUST be ignored by clients. Extended security
				exchanges provide a means of supporting arbitrary authentication protocols within CIFS. Security
				blobs are opaque to the CIFS protocol; they are messages in some authentication protocol that has
				been agreed upon by client and server by some out of band mechanism, for which CIFS merely functions
				as a transport. When CAP_EXTENDED_SECURITY is negotiated, the server includes a first security blob
				in its response; subsequent security blobs are exchanged in SMB_COM_SESSION_SETUP_ANDX requests and
				responses until the authentication protocol terminates. If the negotiated dialect is NT LM 0.12, then
				the capabilities field of the Negotiate protocol response indicates whether the server supports
				Unicode. The server is not required to support Unicode. Unicode is supported in Win9x and NT clients.
				If Unicode is not supported by the server then some localized of these clients may experience
				unexpected behavior with filenames, resource names and user names . ASCII defines the values of 128
				characters (0x00 through 0x7F). The remaining 128 values (0x80 through 0xFF) are mapped into
				different DOS Code Pages (aka the OEM character set). Different localized clients may use different
				code pages. (For example, Code Page 437 is the default in English based systems). Clients can create
				file and folder names in their default code page that follows the file naming rules and may contain
				both ASCII and non-ASCII characters .*/
			return 2;
		default:
			return -10;//Needed dialect not found;
	}
	return -11;
}

int SmbSessionSetupAndX1(SOCKET s)
{
PSMBP Smbp;
PSESSION_SETUP_ANDHEADER2EX SmbSessionSetupX;//PSMBSESSIONSETUPX;
PCHAR szBytes, szBytes1;
USHORT dwSize, dwSize1, dwSize2;
int i;
/*unsigned char sb[0x20] =
{ 0x4E,0x54,0x4C,0x4D,0x53,0x53,0x50,0x00,0x01,0x00,0x00,0x00,0x97,0x82,0x08,0xE0,
  0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00
};
wchar_t navos[]=L"windows 2000 2195";
wchar_t lanman[]=L"windows 2000 5.0";*/


 dwSize1 = sizeof(SMBP);
 dwSize2 = sizeof(SESSION_SETUP_ANDHEADER2EX);//SMBSESSIONSETUPX);0x200;
 dwSize = dwSize1 + dwSize2 + 45;
 
 szBytes = malloc(dwSize+40);
 if(!szBytes)
	return -1;
 Smbp = (PSMBP)szBytes;
 SmbSessionSetupX = (PSESSION_SETUP_ANDHEADER2EX)(((char*)szBytes) + sizeof(SMBP));//PSMBSESSIONSETUPX

 Smbp->nbtsmb = 0;
 Smbp->flag = 0;
 Smbp->smbpacketlen = htons(dwSize - 4);

 Smbp->smbhdr.MagicVal = SMBMAGICVAL;
 Smbp->smbhdr.Command= SMB_COM_SESSION_SETUP_ANDX;
 Smbp->smbhdr.NTError = 0;
 Smbp->_smbhdr.Flags = 0x18;//0x98;
 /*Smbp->smbhdr.bLockAndReadWriteAndUnlock = 0;
 Smbp->smbhdr.bSendWithoutAck = 0;
 Smbp->smbhdr.bReservedBit = 0;
 Smbp->smbhdr.bNoCaseSensitivePaths = 1;
 Smbp->smbhdr.bCanonicalizedPaths = 1;
 Smbp->smbhdr.bOpportunisticLocks = 0;
 Smbp->smbhdr.bChangeNotify = 0;
 Smbp->smbhdr.bResponse = 0;*/

 Smbp->_smbhdr.Flags2 = 0xc807;//0xc853;
 /*Smbp->smbhdr.bLongFilenames = 1;
 Smbp->smbhdr.bExtendedAttributes = 1;
 Smbp->smbhdr.bFlags2IsLongName = 1;
 Smbp->smbhdr.bUnknown1 = 0;
 Smbp->smbhdr.bUnknown2 = 0;
 Smbp->smbhdr.bUnknown3 = 0;
 Smbp->smbhdr.bUnknown4 = 0;
 Smbp->smbhdr.bUnknown5 = 0;

 Smbp->smbhdr.bUnknown6 = 0;
 Smbp->smbhdr.bUnknown7 = 0;
 Smbp->smbhdr.bUnknown8 = 0;
 Smbp->smbhdr.bExtendedSecurity = 1;
 Smbp->smbhdr.bResolveViaDFS = 0;
 Smbp->smbhdr.bReadGrantedWithExecPerms = 0;
 Smbp->smbhdr.bNTErrorCodes = 1;
 Smbp->smbhdr.bUnicodeStrings = 1;*/

 for(i=0; i<12; ++i) Smbp->_smbhdr.Pad[i] = 0;
 Smbp->_smbhdr.TreeID = cnstTREE_ID;				// Tree identifier
 Smbp->_smbhdr.CallersProcess = cnstCALLER_PROCESS;	// Caller's process id
 Smbp->_smbhdr.UserID = cnstUSER_ID;				// Unauthenticated user id
 Smbp->_smbhdr.MultiplexID = cnstMULTIPLEX_ID;		// multiplex id (USHORT)rand()

 SmbSessionSetupX->WordCount = 12;
 SmbSessionSetupX->AndXCommand= 0xFF;//No further commands
 SmbSessionSetupX->AndXReserved = 0;
 SmbSessionSetupX->AndXOffset = 0;
 SmbSessionSetupX->MaxBufferSize = 4356;
 SmbSessionSetupX->MaxMpxCount= 10;
 SmbSessionSetupX->VcNumber= 0;
 SmbSessionSetupX->SessionKey = 0;
 SmbSessionSetupX->SecurityBlobLen = 40;
 SmbSessionSetupX->Reserved = 0;
 SmbSessionSetupX->ClientCaps = 0xa00000d4;
 SmbSessionSetupX->ByteCount = 0x002d;
 memcpy(&SmbSessionSetupX->ByteCount+1,"NTLMSSP\0\1\0\0",12);
 ((char*)&SmbSessionSetupX->ByteCount+1)[13] = 0x97;
 ((char*)&SmbSessionSetupX->ByteCount+1)[14] = 0x82;
 ((char*)&SmbSessionSetupX->ByteCount+1)[15] = 0x08;
 ((char*)&SmbSessionSetupX->ByteCount+1)[16] = 0xe2;
 ZeroMemory(&SmbSessionSetupX->ByteCount+9,16);
 ((char*)&SmbSessionSetupX->ByteCount+1)[33] = 0x06;
 ((char*)&SmbSessionSetupX->ByteCount+1)[34] = 0x01;
 ((char*)&SmbSessionSetupX->ByteCount+1)[35] = 0xb0;
 ((char*)&SmbSessionSetupX->ByteCount+1)[36] = 0x1d;
 ((char*)&SmbSessionSetupX->ByteCount+1)[37] = 0;
 ((char*)&SmbSessionSetupX->ByteCount+1)[38] = 0;
 ((char*)&SmbSessionSetupX->ByteCount+1)[39] = 0;
 ((char*)&SmbSessionSetupX->ByteCount+1)[40] = 0x0f;
 ((char*)&SmbSessionSetupX->ByteCount+1)[41] = 0;
 ((char*)&SmbSessionSetupX->ByteCount+1)[42] = 0;
 ((char*)&SmbSessionSetupX->ByteCount+1)[43] = 0;
 ((char*)&SmbSessionSetupX->ByteCount+1)[44] = 0;
 ((char*)&SmbSessionSetupX->ByteCount+1)[45] = 0;
 ((char*)&SmbSessionSetupX->ByteCount+1)[46] = 0x20;
 ((char*)&SmbSessionSetupX->ByteCount+1)[47] = 0x20;
 ((char*)&SmbSessionSetupX->ByteCount+1)[48] = 0x20;
 ((char*)&SmbSessionSetupX->ByteCount+1)[49] = 0x20;
 ((char*)&SmbSessionSetupX->ByteCount+1)[50] = 0x20;
 ((char*)&SmbSessionSetupX->ByteCount+1)[51] = 0x20;
 ((char*)&SmbSessionSetupX->ByteCount+1)[52] = 0x1e;
 ((char*)&SmbSessionSetupX->ByteCount+1)[53] = 0x84;
 ((char*)&SmbSessionSetupX->ByteCount+1)[54] = 0;
 ((char*)&SmbSessionSetupX->ByteCount+1)[55] = 'D';
 ((char*)&SmbSessionSetupX->ByteCount+1)[56] = 'S';
 ((char*)&SmbSessionSetupX->ByteCount+1)[57] = 'L';
 ((char*)&SmbSessionSetupX->ByteCount+1)[58] = 0x20;
 ((char*)&SmbSessionSetupX->ByteCount+1)[59] = 0x20;
 ((char*)&SmbSessionSetupX->ByteCount+1)[60] = 0x20;
 ((char*)&SmbSessionSetupX->ByteCount+1)[61] = 0x20;
 ((char*)&SmbSessionSetupX->ByteCount+1)[62] = 0x20;
 ((char*)&SmbSessionSetupX->ByteCount+1)[63] = 0x20;
 ((char*)&SmbSessionSetupX->ByteCount+1)[64] = 0x20;
 ((char*)&SmbSessionSetupX->ByteCount+1)[65] = 0x20;
 ((char*)&SmbSessionSetupX->ByteCount+1)[66] = 0x20;
 ((char*)&SmbSessionSetupX->ByteCount+1)[67] = 0x20;
 ((char*)&SmbSessionSetupX->ByteCount+1)[68] = 0x20;
 ((char*)&SmbSessionSetupX->ByteCount+1)[69] = 0x20;
 ((char*)&SmbSessionSetupX->ByteCount+1)[70] = 0x1d;
 ((char*)&SmbSessionSetupX->ByteCount+1)[71] = 0x04;
 ((char*)&SmbSessionSetupX->ByteCount+1)[72] = 0;
 ((char*)&SmbSessionSetupX->ByteCount+1)[73] = 1;
 ((char*)&SmbSessionSetupX->ByteCount+1)[74] = 2;
 //ZeroMemory(&SmbSessionSetupX->ByteCount+23,41);

/* memset(SmbSessionSetupX,0,0x200);
  *(DWORD*)(((char*)SmbSessionSetupX)+21) = 0x800000D4;
  //???????FLAG
  ((char*)SmbSessionSetupX)[0]=0xc;            //WORD ????
  *(WORD*)(((char*)SmbSessionSetupX)+1)=0Xff;  //??????	AndXCommand=ff & AndXReserved=0
  *(WORD*)(((char*)SmbSessionSetupX)+3)=0Xb0;  //??????	AndXOffset=b0
  *(WORD*)(((char*)SmbSessionSetupX)+5)=0X4104;//????		MaxBufferSize=1089
  *(WORD*)(((char*)SmbSessionSetupX)+7)=0X32;  //???MPX		MaxMpxCount=0x32
  *(WORD*)(((char*)SmbSessionSetupX)+9)=0X0;   //????		VcNumber=0
  *(DWORD*)(((char*)SmbSessionSetupX)+11)=0X0; //????		SessionKey=0
  *(DWORD*)(((char*)SmbSessionSetupX)+17)=0X0; //??			Reserved=0

  *(WORD*)(((char*)SmbSessionSetupX)+15)=0x20; //BLOB???		SecurityBlobLen=0x20
  memcpy(((char*)SmbSessionSetupX)+27,sb,0x20);//??BLOB		After ByteCount
  memcpy(((char*)SmbSessionSetupX)+28+0x20,navos,36); //
  memcpy(((char*)SmbSessionSetupX)+66+0x20,lanman,32);//
  *(WORD*)(((char*)SmbSessionSetupX)+25)=73+0x20;	  //		ByteCount
  Smbp->smbpacketlen = htons(132+0x20);*/


/*memcpy(((char*)szBytes) + dwSize1 + dwSize2,"NTLMSSP",8);//"\0x4c\0x4d\0x53\0x53\0x50\0"
 memcpy(((char*)szBytes) + dwSize1 + dwSize2 + 8,"\1\0\0\0",4);
 (((char*)szBytes) + dwSize1 + dwSize2)[12] = 0x97;
 (((char*)szBytes) + dwSize1 + dwSize2)[13] = 0x82;
 (((char*)szBytes) + dwSize1 + dwSize2)[14] = 0x08;
 (((char*)szBytes) + dwSize1 + dwSize2)[15] = 0xe2;
 memcpy(((char*)szBytes) + dwSize1 + dwSize2 + 16,"\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\6\1",18);
 (((char*)szBytes) + dwSize1 + dwSize2)[34] = 0xb0;
 (((char*)szBytes) + dwSize1 + dwSize2)[35] = 0x1d;
 memcpy(((char*)szBytes) + dwSize1 + dwSize2 + 36,"\0\0\0",3);
 (((char*)szBytes) + dwSize1 + dwSize2)[39] = 0x0f;
 memcpy(((char*)szBytes) + dwSize1 + dwSize2 + 40,"\0\0\0\0\0\0\0",7);
 //memcpy(szBytes + dwSize1 + dwSize2 + 2, szDomain, sizeof(szDomain));
 //memcpy(szBytes + dwSize1 + dwSize2 + sizeof(szDomain) + 2, szLanman, sizeof(szLanman));
*/
 i = send(s, (char*)szBytes, dwSize+40, 0);
 free(szBytes);
 if(i<0)
 	return -2;
 
 szBytes1 = malloc(1024);
 if(!szBytes1)
 	return -3;

 i = recv(s, szBytes1, 1024, 0);
 if(i <= 0)
 {	free(szBytes1);
	return -4;
 }

 free(szBytes1);
 return 0;
}

/*int Make_SessionSetupX(SOCKET csock)
{
PSMBP Smbp;
PSMBSESSIONSETUPX SmbSessionSetupX;
PCHAR szBytes, szBytes1;
PCHAR tmp;
USHORT dwSize, dwSize1, dwSize2,User_ID;
UCHAR szDomain[] = "WORKGROUP";
UCHAR szLanman[] = "Unix\0Samba";
int i;

 dwSize1 = sizeof(SMBP);
 dwSize2 = sizeof(SMBSESSIONSETUPX);
 dwSize = dwSize1 + dwSize2 + sizeof(szDomain) + sizeof(szLanman) + 2; 
 
 szBytes = malloc(dwSize);
 if(!szBytes)
	return 1;
 Smbp = (PSMBP)szBytes;
 SmbSessionSetupX = (PSMBSESSIONSETUPX)(((char*)szBytes) + sizeof(SMBP));

 Smbp->nbtsmb = 0;
 Smbp->flag = 0;
 Smbp->smbpacketlen = htons(dwSize - 4);

 Smbp->smbhdr.MagicVal = SMBMAGICVAL;
 Smbp->smbhdr.Command= SMB_COM_SESSION_SETUP_ANDX;
 Smbp->smbhdr.NTError = 0;
 Smbp->_smbhdr.Flags = 0x08;
 Smbp->_smbhdr.Flags2 = 0x01;
 Smbp->_smbhdr.Pid = (USHORT)rand() & 0xFFFF;
 Smbp->_smbhdr.Mid = (USHORT)rand() & 0xFFFF;

 SmbSessionSetupX->WordCount = 13;
 SmbSessionSetupX->AndXCommand= 0xFF;
 SmbSessionSetupX->AndXReserved = 0;
 SmbSessionSetupX->AndXOffset = 0;
 SmbSessionSetupX->MaxBufferSize = 65535;
 SmbSessionSetupX->MaxMpxCount= 2;
 SmbSessionSetupX->VcNumber= 1025; 
 SmbSessionSetupX->SessionKey = 0;
 SmbSessionSetupX->CaseInsensitivePasswordLength = 1;
 SmbSessionSetupX->CaseSensitivePasswordLength= 0;
 SmbSessionSetupX->Reserved= 0;
 SmbSessionSetupX->Capabilities = 0;
 SmbSessionSetupX->ByteCount = sizeof(szDomain) + sizeof(szLanman) + 2;

 memcpy(szBytes + dwSize1 + 2, "\0\0", 2);
 memcpy(szBytes + dwSize1 + dwSize2 + 2, szDomain, sizeof(szDomain));
 memcpy(szBytes + dwSize1 + dwSize2 + sizeof(szDomain) + 2, szLanman, sizeof(szLanman));

 i = send(csock, (char*)szBytes, dwSize, 0);
 if(i<0)
 {	free(szBytes);
	return 1;
 }
 
 memset(Smbp, 0, dwSize1);

 szBytes1 = malloc(1024);
 if(!szBytes1)
 {	free(szBytes);
	return 1;
 }

 i = recv(csock, szBytes1, 1024, 0);
 if(i <= 0)
 {	free(szBytes);
	free(szBytes1);
	return 1;
 }

 tmp = (char*)Smbp;
 Smbp = (SMBP*)szBytes1;
 
 if(Smbp->_smbhdr.Status != 0)
 {	Smbp = (SMBP*)tmp;
	free(szBytes);
	free(szBytes1);
	return 1;
 }
*/ 

BOOL GetNetInf(wchar_t* compName,wchar_t* domainName)
{
LPWKSTA_INFO_101 pBuf = NULL;
DWORD dwLevel = 101;
NET_API_STATUS nStatus = NetWkstaGetInfo(NULL,dwLevel,(LPBYTE*)&pBuf);
	if(nStatus == NERR_Success)
	{	wcscpy(compName, pBuf->wki101_computername);
		wcscpy(domainName, pBuf->wki101_langroup);
	}
	if(pBuf != NULL)
      NetApiBufferFree(pBuf);
	return (nStatus != NERR_Success);
}

/*
00 00 00 a4 ff 53 4d 42 73 00 00 00 00 18 07 c8 00 00 00 00 00 00 00 00 00 00 00 00 ff ff ff  ...��SMBs......�............���
fe 00 00 ff ff 0c ff 00 b0 00 04 41 32 00 00 00 00 00 00 00 20 00 00 00 00 00 d4 00 00 80 69  �..��.�.�..A2....... .....�..�i
00 4e 54 4c 4d 53 53 50 00 01 00 00 00 97 82 08 e0 00 00 00 00 00 00 00 00 00 00 00 00 00 00  .NTLMSSP.....�..�..............
00 00 00 77 00 69 00 6e 00 64 00 6f 00 77 00 73 00 20 00 32 00 30 00 30 00 30 00 20 00 32 00  ...w.i.n.d.o.w.s. .2.0.0.0. .2.
31 00 39 00 35 00 00 00 00 00 77 00 69 00 6e 00 64 00 6f 00 77 00 73 00 20 00 32 00 30 00 30  1.9.5.....w.i.n.d.o.w.s. .2.0.0
00 30 00 20 00 35 00 2e 00 30 00 00 00 00 00 00 00 00 00 00 00 00 0*/