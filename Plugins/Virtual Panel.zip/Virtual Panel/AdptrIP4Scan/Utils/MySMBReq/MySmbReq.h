#include "Winsock2.h"


#define srcPort     50577
#define dstNBTPort  139
#define dstWINSPort 445
#define SRCIP		"192.168.14.35"
#define DSTIP		"192.168.101.5"//14.34"

#define SMBMAGICVAL	MAKELONG(MAKEWORD(0xFF, 'S'), MAKEWORD('M', 'B') )

#define SMB_COM_NEGOTIATE               0x72
#define SMB_COM_SESSION_SETUP_ANDX		0x73

#pragma pack(1)

typedef struct
{	USHORT Day	 : 5;
    USHORT Month : 4;
    USHORT Year	 : 7;
} SMB_DATE;
typedef struct
{	USHORT TwoSeconds: 5;
    USHORT Minutes	 : 6;
    USHORT Hours	 : 5;
} SMB_TIME;
typedef struct
{	ULONG LowTime;
    LONG HighTime;
} TIME;

typedef struct
{	DWORD MagicVal;
	BYTE Command;
	union 
	{	struct 
		{	BYTE ErrorClass;
			BYTE Reserved;
			WORD ErrorCode;
		};
		DWORD NTError;
	};
	// flags field
	BYTE bLockAndReadWriteAndUnlock:1;	//SMB_FLAGS_LOCK_AND_READ_OK
	BYTE bSendWithoutAck:1;				//SMB_FLAGS_BUF_AVAIL
	BYTE bReservedBit:1;				//Reserved
	BYTE bNoCaseSensitivePaths:1;		//SMB_FLAGS_CASE_INSENSITIVE
	BYTE bCanonicalizedPaths:1;			//SMB_FLAGS_CANONICALIZED_PATHS
	BYTE bOpportunisticLocks:1;			//SMB_FLAGS_OPLOCK
	BYTE bChangeNotify:1;				//SMB_FLAGS_OPBATCH
	BYTE bResponse:1;					//SMB_FLAGS_REPLY

	// 2nd flags field
	BYTE bLongFilenames:1;				//SMB_FLAGS2_LONG_NAMES
	BYTE bExtendedAttributes:1;			//SMB_FLAGS2_EAS
	BYTE bFlags2IsLongName:1;			//SMB_FLAGS2_SMB_SECURITY_SIGNATURE
	BYTE bUnknown1:1;
	BYTE bUnknown2:1;
	BYTE bUnknown3:1;
	BYTE bUnknown4:1;					//SMB_FLAGS2_IS_LONG_NAME
	BYTE bUnknown5:1;

	BYTE bUnknown6:1;
	BYTE bUnknown7:1;
	BYTE bUnknown8:1;
	BYTE bExtendedSecurity:1;
	BYTE bResolveViaDFS:1;				//SMB_FLAGS2_DFS
	BYTE bReadGrantedWithExecPerms:1;	//SMB_FLAGS2_PAGING_IO
	BYTE bNTErrorCodes:1;				//SMB_FLAGS2_NT_STATUS
	BYTE bUnicodeStrings:1;				//SMB_FLAGS2_UNICODE

	WORD PID;
	DWORD HdrReserved;
	WORD SessionID;
	WORD SequenceNumber;

	BYTE Padding[2];
	WORD TreeID;
	WORD CallersProcess;
	WORD UserID;
	WORD MultiplexID;
} SMBHEADER, *PSMBHEADER;	//32 bytes;
typedef struct
{	ULONG  Protocol;		// Contains 0xFF,'SMB'
	UCHAR  Command;			// Command code
	ULONG  Status;			// 32-bit error code
	UCHAR  Flags;			// Flags
	USHORT Flags2;			// More flags

	UCHAR  Pad[12];			// Ensure this section is 12 bytes long

	USHORT TreeID;			// Tree identifier
	USHORT CallersProcess;	// Caller's process id
	USHORT UserID;			// Unauthenticated user id
	USHORT MultiplexID;		// multiplex id
} _SMBHEADER, *_PSMBHEADER;	//32 bytes;

typedef struct
{   unsigned char nbtsmb;
    unsigned char flag;
    short smbpacketlen;
	union
	{	SMBHEADER   smbhdr;
		_SMBHEADER _smbhdr;
	};
} SMBP,*PSMBP;

typedef struct
{   SMBP p;
	WORD structSize;
	char dialectCount;
	char dialects[120]; 
} SMBNEGOTIATE_REQUEST,*PSMBNEGOTIATE_REQUEST;//159

typedef struct
{UCHAR WordCount;               //Count of parameter words = 13
 USHORT DialectIndex;           //Index of selected dialect
 USHORT SecurityMode;           //Security mode:
                                // bit 0: 0 = share, 1 = user
                                // bit 1: 1 = use challenge/response
                                // authentication
 USHORT MaxBufferSize;          //Max transmit buffer size (>= 1024)
 USHORT MaxMpxCount;            //Max pending multiplexed requests
 USHORT MaxNumberVcs;           //Max VCs between client and server
 USHORT RawMode;                //Raw modes supported:
                                // bit 0: 1 = Read Raw supported
                                // bit 1: 1 = Write Raw supported
 ULONG SessionKey;              //Unique token identifying this session
 SMB_TIME ServerTime;           //Current time at server
 SMB_DATE ServerDate;           //Current date at server
 USHORT ServerTimeZone;         //Current time zone at server
 USHORT EncryptionKeyLength;    //MUST BE ZERO if not LM2.1
                                // dialect
 USHORT Reserved;               //MUST BE ZERO
 USHORT ByteCount;              //Count of data bytes
 UCHAR  EncryptionKey[2];       //The challenge encryption key
 //STRING PrimaryDomain[];      //The server's primary domain
 UCHAR  PrimaryDomain[32];      //The server's primary domain
} PLANMAN2_1_DIALECTSELECTHEADER, *PPLANMAN2_1_DIALECTSELECTHEADER;

typedef struct
{UCHAR WordCount;                //Count of parameter words = 17
 USHORT DialectIndex;            //Index of selected dialect
 UCHAR SecurityMode;             //Security mode:
                                 // bit 0: 0 = share, 1 = user
                                 // bit 1: 1 = encrypt passwords
                                 // bit 2: 1 = Security Signatures
                                 //  (SMB sequence numbers) enabled
                                 // bit 3: 1 = Security Signatures
                                 // (SMB sequence numbers) required
 USHORT MaxMpxCount;             //Max pending outstanding requests
 USHORT MaxNumberVcs;            //Max VCs between client and server
 ULONG MaxBufferSize;            //Max transmit buffer size
 ULONG MaxRawSize;               //Maximum raw buffer size
 ULONG SessionKey;               //Unique token identifying this session
 ULONG Capabilities;             //Server capabilities
 ULONG SystemTimeLow;            //System (UTC) time of the server (low)
 ULONG SystemTimeHigh;           //System (UTC) time of the server (high)
 USHORT ServerTimeZone;          //Time zone of server (minutes from UTC)
 CHAR EncryptionKeyLength;       //Length of encryption key

//SMB_PARAMETER block:
 USHORT ByteCount;               //Count of data bytes
 UCHAR EncryptionKey[2];         //The challenge encryption key;
                                 //Present only for Non Extended Security i.e.,
                                 //CAP_EXTENDED_SECURITY is off in the Capabilities
                                 // field
 UCHAR OemDomainName[32];        //The name of the domain (in OEM chars);
                                 //Present Only for Non Extended Security i.e.,
                                 // CAP_EXTENDED_SECURITY is off in the Capabilities
                                 // field
 UCHAR GUID[16];                 //A globally unique identifier assigned to the
                                 // server; Present only when
                                 // CAP_EXTENDED_SECURITY is on in Capabilities field
 UCHAR SecurityBlob[];           //Opaque Security Blob associated with the
                                 // security package if CAP_EXTENDED_SECURITY
                                 //  is on in the Capabilities field; else challenge
                                 // for CIFS challenge/response authentication
} NT_LM_0_12_DIALECTSELECTHEADER, *PNT_LM_0_12_DIALECTSELECTHEADER;

typedef struct
{	BYTE Len;			//word count
	WORD DialectIndex;
	BYTE bUserLevelSecurity:1;
	BYTE bEncryptPasswords:1;
	BYTE bSecuritySignaturesEnabled:1;
	BYTE bSecuritySignaturesRequired:1;
	BYTE bReserved:4;
	WORD MaxPendingMpxRequests;
	WORD MaxVCsInClientAndServer;
	DWORD MaxTransmitBufferSize;
	DWORD MaxRawBufferSize;
	DWORD UniqueSessionKey;

	BYTE bReadAndWriteRawMode:1;
	BYTE bReadAndWriteMultiplexMode:1;
	BYTE bUnicode:1;
	BYTE bLargeFiles:1;
	BYTE bNTLM012Dialect:1;
	BYTE bRAPIviaRPC:1;
	BYTE bNT32BitStatus:1;
	BYTE bLevelIIOplocks:1;

	BYTE bLOCK_AND_READ_Command:1;
	BYTE bNT_FIND_SBM_Command:1;
	BYTE Unused1:2;
	BYTE bDFSAware:1;
	BYTE Unused2:3;

	BYTE Unused3;

	BYTE Unused4:5;
	BYTE bBulkTransfer:1;
	BYTE bCompressedData:1;
	BYTE bExtendedSecurity:1;

	DWORD SystemDate;
	DWORD SystemTime;
	WORD TimeZone;
	BYTE EncryptionKeyLen;
	WORD ByteCount;
} SMBDIALECTSELECTHEADER, *PSMBDIALECTSELECTHEADER;
#define SMBDIALECTSELECTHEADER_LEN			17




typedef struct
{UCHAR WordCount;		// Count of parameter words = 10
 UCHAR AndXCommand;		// Secondary (X) command; 0xFF = none
 UCHAR AndXReserved;	// Reserved (must be 0)
 USHORT AndXOffset;		// Offset to next command WordCount
 USHORT MaxBufferSize;	// Client maximum buffer size
 USHORT MaxMpxCount;	// Actual maximum multiplexed pending requests
 USHORT VcNumber;		// 0 = first (only), nonzero=additional VC number
 ULONG SessionKey;		// Session key (valid iff VcNumber != 0)
 USHORT CaseInsensitivePasswordLength;
 USHORT CaseSensitivePasswordLength;
 ULONG Reserved;		// Must be 0
 ULONG Capabilities;	// Client capabilities
 USHORT ByteCount;		// Count of data bytes; min = 0
}SMBSESSIONSETUPX, *PSMBSESSIONSETUPX;

typedef struct 
{	BYTE WordCount;	// should be 10
	BYTE AndXCommand;
	BYTE AndXReserved;
	WORD AndXOffset;
	WORD MaxBufferSize;
	WORD MaxMpxCount;
	WORD VcNumber;	// 0 = first (only), nonzero=additional VC number
	DWORD SessionKey;
	WORD PasswordLen;
	DWORD Reserved;
	WORD ByteCount;
} SESSION_SETUP_ANDHEADER, *PSESSION_SETUP_ANDHEADER;
#define SESSION_SETUP_ANDHEADER_LEN 10

typedef struct 
{	BYTE WordCount;	// should be 13												  0d
	BYTE AndXCommand;															//ff
	BYTE AndXReserved;															//00
	WORD AndXOffset;															//0000
	WORD MaxBufferSize;															//ffff	
	WORD MaxMpxCount;															//0200
	WORD VcNumber;	// 0 = first (only), nonzero=additional VC number			//5c02
	DWORD SessionKey;															//00000000
	WORD CaseInsensitivePasswordLen;											//0000
	WORD CaseSensitivePasswordLen;												//0000
	DWORD Reserved;																//00000000
	DWORD ClientCaps;															//01000000
	WORD ByteCount;																//0b00
} SESSION_SETUP_ANDHEADER2, *PSESSION_SETUP_ANDHEADER2;							
#define SESSION_SETUP_ANDHEADER2_LEN 13

typedef struct 
{	BYTE WordCount;	// should be 12
	BYTE AndXCommand;
	BYTE AndXReserved;
	WORD AndXOffset;
	WORD MaxBufferSize;
	WORD MaxMpxCount;
	WORD VcNumber;	// 0 = first (only), nonzero=additional VC number
	DWORD SessionKey;
	WORD SecurityBlobLen;
	DWORD Reserved;
	DWORD ClientCaps;
	WORD ByteCount;
} SESSION_SETUP_ANDHEADER2EX, *PSESSION_SETUP_ANDHEADER2EX;
#define SESSION_SETUP_ANDHEADER2EX_LEN 12


//        PROTOS:
int  AnalyzeSessionResponse1(UCHAR*);
void SendSessionRequest(SOCKET);
int  SmbSessionSetupAndX1(SOCKET);
int  Make_SessionSetupX(SOCKET);
BOOL GetNetInf(wchar_t*,wchar_t*);
