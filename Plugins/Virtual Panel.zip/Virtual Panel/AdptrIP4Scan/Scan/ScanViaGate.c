//#include "windows.h"

#pragma warning(disable:4005)
#pragma warning(disable:4013)
#pragma warning(disable:4133)
#pragma warning(disable:4995)
#pragma warning(disable:4996)

#include "..\Packet\Packet32.h"
#include "..\Plugins_C.h"
#include <ntddndis.h>
#include <commctrl.h>


WORD checksum_comp(WORD *addr,int len)
{   /*      compute TCP header checksum               */ 
    /*      with the usual algorithm a bit changed    */
    /*      for byte ordering problem resolving       */
    /*      RFC 1071 for more info                    */
    /* Compute Internet Checksum for "count" bytes
    *         beginning at location "addr".
    */
	register long sum = 0;
	int count = len;
	WORD temp,checksum;

	while(count > 1)
	{	temp = htons(*addr++);	// in this line:added -> htons
		sum += temp;
		count -= 2;
	}

           /*  Add left-over byte, if any */
	if(count > 0)
		sum += * (unsigned char*)addr;

           /*  Fold 32-bit sum to 16 bits */
	while(sum>>16)
		sum = (sum & 0xffff) + (sum >> 16);
	
    checksum = (WORD)(~sum);
    return checksum;
}

/*VOID BuildUDPQuery(BYTE *udpMsg,PluginObj *plg,DWORD nNode)
{
WORD id = plg->dwIPFrom+nNode+13527;
DWORD dip = plg->dwIPFrom+nNode;
	*((WORD*)&udpMsg[EHTHdrLen+IP4HdrLen]) = ntohs(54669+nNode);//UDP-port 50000
	*((WORD*)&udpMsg[EHTHdrLen+4]) = ntohs(id);//id
	*((DWORD*)&udpMsg[EHTHdrLen+IP4HdrLen-4]) = ntohl(dip);//dest IP
	//ip_checksum(&udpMsg[EHTHdrLen],20);//IPAndUDPLength);//20);  //*((USHORT*)(&sndBuf[24])) = ip_checksum1((USHORT*)&sndBuf[IPOffstPTR],10);
	//udpMsg[40] = 0x93; udpMsg[41] = 0xd3;
	udp_checksum(&udpMsg[EHTHdrLen],UDPBufLen);//+50);//crc ne bylo raschitano
	*((WORD*)(&udpMsg[EHTHdrLen+26])) = ntohs(checksum_comp((WORD*)&udpMsg[EHTHdrLen+IP4HdrLen],58));
}*/

DWORD WINAPI ScanViaGateThrdProc(LPVOID lpPar)
{
PluginObj *plg = (PluginObj*)lpPar;LPVOID recvThrdPar[8] = {0,0,0};//0-recvThrd,1-recvThrdId,2-bCancelThread,3-adptr,4-pkts,5-numpkts,6-iNumRecvdPckts;
LPADAPTER adptr;LPPACKET pcktArp,pcktICMPEcho,pcktUdp,pcktRecv[NUM_RECV_PCKTS];
long n,N,iRecvdPkts=0,iPcktProced=0;BOOL bCancelRecvThrd=FALSE;
BYTE recvBuf[NUM_RECV_PCKTS][recvBufLen];DWORD GateMaskAndIP,nip,tmBgn,tmSnd;
BYTE arpMsg[ARPReqLen]={
	0xff,0xff,0xff,0xff,0xff,0xff,//plg->crntAdptrGWMAC.b[0],plg->crntAdptrGWMAC.b[1],plg->crntAdptrGWMAC.b[2],plg->crntAdptrGWMAC.b[3],plg->crntAdptrGWMAC.b[4],plg->crntAdptrGWMAC.b[5],
	plg->crntAdptrMAC.b[0],plg->crntAdptrMAC.b[1],plg->crntAdptrMAC.b[2],plg->crntAdptrMAC.b[3],plg->crntAdptrMAC.b[4],plg->crntAdptrMAC.b[5],
	8,6,//ETHTYPE_ARP
	0,1,8,0,6,4,0,1,
	plg->crntAdptrMAC.b[0],plg->crntAdptrMAC.b[1],plg->crntAdptrMAC.b[2],plg->crntAdptrMAC.b[3],plg->crntAdptrMAC.b[4],plg->crntAdptrMAC.b[5],
	plg->myIP.b[0],plg->myIP.b[1],plg->myIP.b[2],plg->myIP.b[3],
	0,0,0,0,0,0,
	0,0,0,0,//dest IP 38
	0,0	  };//padding chars;
BYTE ICMPEchoRequestMsg[ICMPEchoReqLen]={
	plg->crntAdptrGWMAC.b[0],plg->crntAdptrGWMAC.b[1],plg->crntAdptrGWMAC.b[2],plg->crntAdptrGWMAC.b[3],plg->crntAdptrGWMAC.b[4],plg->crntAdptrGWMAC.b[5],
	plg->crntAdptrMAC.b[0],plg->crntAdptrMAC.b[1],plg->crntAdptrMAC.b[2],plg->crntAdptrMAC.b[3],plg->crntAdptrMAC.b[4],plg->crntAdptrMAC.b[5],
	8,0,//ETHTYPE_IPV4
	0x45,0,0,0x3c,0x29,8,0,0,0x80,1,0,0,//ver-4,hdrlen-5,tos-0,totlen-60,id-40a5,froffsfile-0,timetoliv-128,protocol1,chksum-0,
	plg->myIP.b[0],plg->myIP.b[1],plg->myIP.b[2],plg->myIP.b[3],
	0,0,0,0,//dest IP
	8,0,0,0,0,1,0,12,//34-bayt,type-8,code-0,id-1,seq-12,chksum-4d41
	0x61,0x62,0x63,0x64,//DWORD dwTime
	0x65,0x66,0x67,0x68,0x69,0x6a,0x6b,0x6c,0x6d,0x6e,0x6f,0x70,0x71,0x72,0x73,0x74,0x75,0x76,
	0x77,0x61,0x62,0x63,0x64,0x65,0x66,0x67,0x68,0x69,
	0,0};//,0,0,0,0,0,0,0,0,0,0,
	//0,0,0,0,0,0,0,0,0,0,0,0,
	//0,0,0,0,0,0,0,0,0,0,0,0 };
BYTE udpMsg[totUDPBufLen] = {
	plg->crntAdptrGWMAC.b[0],plg->crntAdptrGWMAC.b[1],plg->crntAdptrGWMAC.b[2],plg->crntAdptrGWMAC.b[3],plg->crntAdptrGWMAC.b[4],plg->crntAdptrGWMAC.b[5],
	plg->crntAdptrMAC.b[0],plg->crntAdptrMAC.b[1],plg->crntAdptrMAC.b[2],plg->crntAdptrMAC.b[3],plg->crntAdptrMAC.b[4],plg->crntAdptrMAC.b[5],
	8,0,//6-ARP,0-IPV4
	0x45,0,0,0x4e,0x4f,0xf0,0,0,0x80,0x11,0,0,//id-20464
	plg->myIP.b[0],plg->myIP.b[1],plg->myIP.b[2],plg->myIP.b[3],
	0,0,0,0,//dstIP
	0xc2,0xff,0,0x89,0,//d996-SrcPort,89-137-destport
	0x3a,//3a-len
	0x8f,0xc1,//chksum
	'R','G',//NAME_TRN_ID
	0,0,//flags
	0,1,//question count
	0,0,//answer count
	0,0,//authority count
	0,0,//additional count
	0x20,0x43,0x4b,0x41,
	0x41,0x41,0x41,0x41,0x41,0x41,0x41,0x41,0x41,0x41,0x41,0x41,0x41,0x41,0x41,0x41,
	0x41,0x41,0x41,0x41,0x41,0x41,0x41,0x41,0x41,0x41,0x41,0x41,0x41,0,
	0,0x21,//type=netbios node status
	0,1};//address class=internet
WIN32_FIND_DATA fd={FILE_ATTRIBUTE_DIRECTORY};
BYTE dstMAC[6];
wchar_t s[MAX_PATH];
wchar_t sName[32];
wchar_t sDomain[32];

#ifdef _DEBUG
	OutputDebugStringA("\n");
	sprintf(s,"Adapter IP:          %d.%d.%d.%d",plg->myIP.b[0],plg->myIP.b[1],plg->myIP.b[2],plg->myIP.b[3]);
	OutputDebugStringA(s);
	OutputDebugStringA("\n");
	sprintf(s,"Adapter MAC:         %02x-%02x-%02x-%02x-%02x-%02x",
			plg->crntAdptrMAC.b[0],plg->crntAdptrMAC.b[1],plg->crntAdptrMAC.b[2],
			plg->crntAdptrMAC.b[3],plg->crntAdptrMAC.b[4],plg->crntAdptrMAC.b[5]);
	OutputDebugStringA(s);
	OutputDebugStringA("\n");
	sprintf(s,"Adapter gateway IP:  %d.%d.%d.%d",plg->crntAdptrGatewayIP4.b[0],plg->crntAdptrGatewayIP4.b[1],plg->crntAdptrGatewayIP4.b[2],plg->crntAdptrGatewayIP4.b[3]);
	OutputDebugStringA(s);
	OutputDebugStringA("\n");
	sprintf(s,"Adapter gateway MAC: %02x-%02x-%02x-%02x-%02x-%02x",
			plg->crntAdptrGWMAC.b[0],plg->crntAdptrGWMAC.b[1],plg->crntAdptrGWMAC.b[2],
			plg->crntAdptrGWMAC.b[3],plg->crntAdptrGWMAC.b[4],plg->crntAdptrGWMAC.b[5]);
	OutputDebugStringA(s);
	OutputDebugStringA("\n");
	sprintf(s,"Ping to from: %d.%d.%d.%d",
			plg->ipFrom.b[0],plg->ipFrom.b[1],plg->ipFrom.b[2],plg->ipFrom.b[3]);
	OutputDebugStringA(s);
	OutputDebugStringA("\n");
	sprintf(s,"Ping to from dw: %04x",plg->dwIPFrom);
	OutputDebugStringA(s);
#endif

	plg->state = scan;
	plg->TermScanThrd = 0;
			
	adptr = PacketOpenAdapter((PCHAR)plg->crntAdptrName);
	if(!adptr) return 0;

	PacketSetMyIP4(adptr, *((DWORD*)&plg->myIP.b[0]));
	PacketSetMyMAC(adptr, &plg->crntAdptrMAC.b[0]);
	PacketSetMyGWMAC(adptr, &plg->crntAdptrGWMAC.b[0]);
	PacketSetMyFilter(adptr, 1);//filter-setted,gateway - recognized;

	/* Set hardware filter to directed mode */
	if(PacketSetHwFilter(adptr,NDIS_PACKET_TYPE_DIRECTED)==FALSE)
	{	//msgStatus ="Warning: unable to set directed mode..";SHOWSTAT(msgStatus);
	}

	// set a 512K buffer in the driver
	if(PacketSetBuff(adptr,512000)==FALSE)
	{	//printf("Unable to set the kernel buffer!\n");
	}

	//PacketSetNumWrites(adptr,1);
	PacketSetLoopbackBehavior(adptr, NPF_DISABLE_LOOPBACK);
	//PacketSetSerialized(adptr);

	// set a 1 second read timeout
	if(!PacketSetReadTimeout(adptr,conf.iTimeout))
	{	//printf("Warning: unable to set the read tiemout!\n");
	}

	recvThrdPar[2] = &bCancelRecvThrd;
	recvThrdPar[3] = adptr;
	recvThrdPar[4] = &pcktRecv[0];
	recvThrdPar[5] = (LPVOID)NUM_RECV_PCKTS;
	recvThrdPar[6] = &iRecvdPkts;
	//recvThrdPar[7] = plg;
	for(n=0; n<NUM_RECV_PCKTS; ++n)
	{	pcktRecv[n] = PacketAllocatePacket();
		PacketInitPacket(pcktRecv[n],recvBuf[n],recvBufLen);
	}

	pcktUdp = PacketAllocatePacket();
	PacketInitPacket(pcktUdp,udpMsg,totUDPBufLen);

	pcktArp=PacketAllocatePacket();
	PacketInitPacket(pcktArp,arpMsg,ARPReqLen);

	pcktICMPEcho=PacketAllocatePacket();
	PacketInitPacket(pcktICMPEcho,ICMPEchoRequestMsg,ICMPEchoReqLen);

	plg->SendBitTable = HeapAlloc(GetProcessHeap(), HEAP_ZERO_MEMORY, plg->totSearchNodes);

	plg->RecvThrd = recvThrdPar[0] = (LPVOID)CreateThread(NULL,0,recvThrdRoutine,&recvThrdPar[0],0,(LPDWORD)&recvThrdPar[1]);
	if(!recvThrdPar[0])
	{	
		goto End;
	}SetThreadPriority(recvThrdPar[0],THREAD_PRIORITY_HIGHEST);
	Sleep(50);

	GateMaskAndIP = (*((DWORD*)&plg->dwMyIP)) & (*((DWORD*)&plg->dwCrntAdptrMask));

	//addItemToPanelList(plg->host,L"..",NULL,&fd,0xffffffff,TRUE); SetVirtualda bor
	tmBgn = tmSnd = GetTickCount();

	//1.N=0 da tez topish kerak bo'lgan IPlarni qidirsun,1 da qolganlarini:
	for(N=conf.bUsePredefinedIPList?1:0; N<2; ++N)
	for(n=0; n<(N?plg->totSearchNodes:conf.iIPListCnt); ++n)
	{	if(N)
		{	nip = plg->dwIPFrom + n;
			if(plg->SendBitTable[n] > 0)
				continue;
		}
		else//tez spiska:
		{	Ip4Shufl(&nip,&conf.IPList[n].b[0]);
			if(nip<plg->dwIPFrom)continue;
			if(nip>plg->dwIPFrom+plg->totSearchNodes)continue;
		}

		if(plg->TermScanThrd>0)//1-Exit,2-Stop
			goto End1;
		if(nip==plg->dwMyIP)//own address
			continue;

		//Agar 1ta shlyuzda bo'lsa,MAC-ffffffffffff b-shi kerak, aks holda shlyuz MAC b-shi kerak:
		if(GetTickCount()-tmSnd<(DWORD)conf.iSpeed)
			Sleep(conf.iSpeed);
		if(GateMaskAndIP == (nip & (*((DWORD*)&plg->dwCrntAdptrMask))))
		{	*((DWORD*)&arpMsg[38]) = Ip4AsDWORD((*((IP4BYTE*)&nip)));
			PacketSendPacket(adptr,pcktArp,TRUE);
		}
		else
		{	*((DWORD*)&ICMPEchoRequestMsg[30]) = Ip4AsDWORD((*((IP4BYTE*)&nip)));
			ip_checksum(&ICMPEchoRequestMsg[EHTHdrLen],20);//+22
			*((WORD*)(&ICMPEchoRequestMsg[36])) = 0x0000;
			*((WORD*)(&ICMPEchoRequestMsg[36])) = ntohs(checksum_comp(&ICMPEchoRequestMsg[34],42));
			PacketSendPacket(adptr,pcktICMPEcho,TRUE);
		}
		tmSnd = GetTickCount();

		plg->SendBitTable[n] = 1;
		while(iPcktProced<iRecvdPkts)
		{	long NN;long totalPackets,i = iPcktProced % NUM_RECV_PCKTS;
			int r=ProcessRecvPacketGW(&recvBuf[i][20],pcktRecv[i]->ulBytesReceived-20,
								      &totalPackets,plg,sName,sDomain,&nip,&dstMAC[0]);
			NN = nip-plg->dwIPFrom;
			if(NN>-1)
			if(NN<plg->totSearchNodes)
			switch(r)
			{	case 1://ARP echo 
				case 3://ICMPReply
					if(0==plg->iScanMethod[0])//WINS
					{	*((DWORD*)&udpMsg[30]) = Ip4AsDWORD((*((IP4BYTE*)&nip)));
						memcpy(udpMsg,dstMAC,6);
						ip_checksum(&udpMsg[EHTHdrLen],20);
						*((WORD*)(&udpMsg[40])) = 0x0000;
						udp_checksum(&udpMsg[EHTHdrLen],UDPBufLen);//+50);//crc ne bylo raschitano
						if(GetTickCount()-tmSnd<(DWORD)conf.iSpeed)
							Sleep(conf.iSpeed);
						PacketSendPacket(adptr,pcktUdp,TRUE);
						tmSnd = GetTickCount();
						plg->SendBitTable[NN] = 2;
					}
					else plg->SendBitTable[NN] = 3;
					addNodeToPlgList(plg,NULL,NULL,&fd,nip);
					break;
				case 4://UDP-137 dan kelgan:
					addNodeToPlgList(plg,sName,sDomain,&fd,nip);
					plg->SendBitTable[NN] = 4;
					break;
			}
			++iPcktProced;
		}
		//4 ta oldingisidan xabar kelmagan bo'lsa:
		/*if(n>4)
		{	if(2==plg->SendBitTable[n-4])//WINS zapros yuborilgan, lekin kelmagan;
			{	nip = plg->dwIPFrom + n-4;
				wsprintf(s,L"%d.%d.%d.%d",nip >> 24, (nip >> 16) & 0xff, (nip >> 8) & 0xff, nip  & 0xff);
				addItemToPanelList(plg->host,s,NULL,&fd,0xffffffff,TRUE);
		}	}*/
		//if(0==n%2)Sleep(2);else
		if(1==n%100)
		{	wsprintf(s,L"Scanning... %d sec. posted.",(GetTickCount()-tmBgn)/1000);
			SetWindowText(plg->tlbrEditState,s);
			SendMessage(plg->tlbrPrgrs,PBM_SETPOS,100*n/plg->totSearchNodes,0);
	}	}

	//Oxirida 4 tasi qolgan edi, agar WINS o'rnatilmagan bo'lsa, ping resultatini yuboraylik:
	/*for(n=plg->totSearchNodes-4; n<plg->totSearchNodes; ++n)
	{	if(2==plg->SendBitTable[n])//WINS zapros yuborilgan, lekin kelmagan;
		{	nip = plg->dwIPFrom + n;
			wsprintf(s,L"%d.%d.%d.%d",nip >> 24, (nip >> 16) & 0xff, (nip >> 8) & 0xff, nip  & 0xff);
			addItemToPanelList(plg->host,s,NULL,&fd,0xffffffff,TRUE);
	}	}*/
End1:
	bCancelRecvThrd = TRUE;
	if(WAIT_OBJECT_0!=WaitForSingleObject((HANDLE)recvThrdPar[0],5000))
		TerminateThread((HANDLE)recvThrdPar[0],0);
End:
	PacketFreePacket(pcktUdp);
	PacketFreePacket(pcktArp);
	PacketFreePacket(pcktICMPEcho);
	for(n=0; n<NUM_RECV_PCKTS; ++n)
		PacketFreePacket(pcktRecv[n]);
	PacketCloseAdapter(adptr);
	HeapFree(GetProcessHeap(),0,plg->SendBitTable);
	plg->SendBitTable = NULL;
	plg->ScanThrd = NULL;
	plg->state = end_scan;
	SendMessage(plg->tlbrEditState,WM_SETTEXT,0,(LPARAM)L"");//SetWindowText(plg->tlbrEditState,L"");tormozit !!!!!!!
	SendMessage(plg->tlbrPrgrs, PBM_SETPOS, 0, 0);//tormozit !!!!!!!
	SendMessage(plg->tlbrBtnStop,WM_SETTEXT,0,(LPARAM)strngs[11]);//L"Start");//SetWindowText(plg->tlbrBtnStop,L"Start"); tormozit !!!!!!!
 	return 0;
}

/*int GetIndividuallyHostAndDomainNameViaGate(PluginObj *plg,IP4BYTE Ip)
{
DWORD dwIP;
BYTE recvBuf[256];
BYTE udpMsg[totUDPBufLen] = {
	0xff,0xff,0xff,0xff,0xff,0xff,//plg->crntAdptrGWMAC.b[0],plg->crntAdptrGWMAC.b[1],plg->crntAdptrGWMAC.b[2],plg->crntAdptrGWMAC.b[3],plg->crntAdptrGWMAC.b[4],plg->crntAdptrGWMAC.b[5],
	plg->crntAdptrMAC.b[0],plg->crntAdptrMAC.b[1],plg->crntAdptrMAC.b[2],plg->crntAdptrMAC.b[3],plg->crntAdptrMAC.b[4],plg->crntAdptrMAC.b[5],
	8,0,//6-ARP,0-IPV4
	0x45,0,0,0x4e,0x4f,0xf0,0,0,0x80,0x11,0,0,//id-20464
	plg->myIP.b[0],plg->myIP.b[1],plg->myIP.b[2],plg->myIP.b[3],
	Ip.b[0],Ip.b[1],Ip.b[2],Ip.b[3],//dstIP
	0xc2,0xff,0,0x89,0,//d996-SrcPort,89-137-destport
	0x3a,//3a-len
	0x8f,0xc1,//chksum
	'R','G',//NAME_TRN_ID
	0,0,//flags
	0,1,//question count
	0,0,//answer count
	0,0,//authority count
	0,0,//additional count
	0x20,0x43,0x4b,0x41,
	0x41,0x41,0x41,0x41,0x41,0x41,0x41,0x41,0x41,0x41,0x41,0x41,0x41,0x41,0x41,0x41,
	0x41,0x41,0x41,0x41,0x41,0x41,0x41,0x41,0x41,0x41,0x41,0x41,0x41,0,
	0,0x21,//type=netbios node status
	0,1		};//address class=internet
LPPACKET pcktUdp,pcktRecv;
LPADAPTER adptr = PacketOpenAdapter((PCHAR)plg->crntAdptrName);
	if(!adptr) return 0;
	if(PacketSetHwFilter(adptr,NDIS_PACKET_TYPE_DIRECTED)==FALSE){}
	if(!PacketSetReadTimeout(adptr,1500)){}

	pcktUdp = PacketAllocatePacket();
	PacketInitPacket(pcktUdp,udpMsg,totUDPBufLen);
	pcktRecv = PacketAllocatePacket();
	PacketInitPacket(pcktRecv,recvBuf,256);

	Ip4Shufl(&dwIP,&Ip.b[0]);
	*((DWORD*)&udpMsg[30]) = Ip4AsDWORD((*((IP4BYTE*)&Ip)));
	ip_checksum(&udpMsg[EHTHdrLen],20);
	*((WORD*)(&udpMsg[40])) = 0x0000;
	udp_checksum(&udpMsg[EHTHdrLen],UDPBufLen);
	PacketSendPacket(adptr,pcktUdp,TRUE);

	if(PacketReceivePacket(adptr, pcktRecv, TRUE))
	{	if(pcktRecv->ulBytesReceived > 0)
		{	wchar_t sName[32],sDomain[32];BYTE dstMAC[6];DWORD totalPackets = 1;
			int r=ProcessRecvPacketGW(&recvBuf[20],pcktRecv->ulBytesReceived-20,
								      &totalPackets,plg,sName,sDomain,&dwIP,&dstMAC[0]);
	}	}	
	
	PacketFreePacket(pcktUdp);
	PacketFreePacket(pcktRecv);
	PacketCloseAdapter(adptr);
	return 0;
}*/