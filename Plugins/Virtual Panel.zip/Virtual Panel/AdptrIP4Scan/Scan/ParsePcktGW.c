/*
 * $Id: //devel/tools/main/nbtscan/parse_nbtstat.c#1 $
 *
 * written by :	Stephen J. Friedl
 *		Software Consultant
 *		steve@unixwiz.net
 *
 *	Given a response from the remote end, decode it to learn what we can
 *	about the services it's offering up. The goal here is to move the data
 *	to a reasonable format only, and only later will we try to actually
 *	understand it. The only output from this module is debugging, which
 *	is enabled by the verbose output.
 *
 *	The overall format of this is defined in RFC1002 in section 4.2.18,
 *	"NODE STATUS RESPONSE", and we repeat a bit of it here.
 *
 *	+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 *	|        name trans ID          |1|  0x0  |1|0|0|0|0 0|0|  0x0  |
 *	+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 *	|     num_questions (0x00)      |     num_answers (0x01)        |
 *	+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 *	|       ns_count (0x00)         |     addl_rec_count (0x00)     |
 *	+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 *	|                                                               |
 *	~                      RR_name of question                      ~
 *	|                                                               |
 *	+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 *	|   qtype: "NBSTAT" (0x0021)    |    qclass: "IN" (0x0001)      |
 *	+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 *	|                           0x00000000                          |
 *	+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 *	|         rdlength              |   # names     |               |
 *	+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+               ~
 *	|                                                               ~
 *	~                          NODE_NAME array                      ~
 *	|                                                               |
 *	+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 *	|                                                               |
 *	~                          statistics                           ~
 *	|                                                               |
 *	+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 *
 *	All names are in the stupid encoded format -- what a crock -- and
 *	the RR_name of question (in our case) is always a "*". What we
 *	most care about is the NODE_NAME array, which is the answer to the
 *	question.
 *
 */ 

//#include "windows.h"

#pragma warning(disable:4005)
#pragma warning(disable:4995)
#pragma warning(disable:4996)

/*#include "..\libnetutil\IPv4Header.h"
#include "..\libnetutil\IPv6Header.h"
#include "..\libnetutil\TCPHeader.h"
#include "..\libnetutil\UDPHeader.h"
#include "..\libnetutil\ICMPv4Header.h"
#include "..\libnetutil\ICMPv6Header.h"
#include "..\libnetutil\EthernetHeader.h"
#include "..\libnetutil\DestOptsHeader.h"
#include "..\libnetutil\FragmentHeader.h"
#include "..\libnetutil\RoutingHeader.h"
#include "..\libnetutil\ARPHeader.h"
#include "..\libnetutil\ICMPv6Option.h"*/
#include "..\Plugins_C.h"
#include "nbtdefs.h"
#include "crtdbg.h"

#define NETBIOSNAMEPORT 137



//extern "C"
//{

int	verbose = 0; 


VOID Ip4Shufl(DWORD *outDw, BYTE *src)
{	BYTE *outDb = (BYTE*)outDw;
	*outDb = *(src+3);
	*(outDb+1) = *(src+2);
	*(outDb+2) = *(src+1);
	*(outDb+3) = *src;
}

BOOL Cmp6Byte(BYTE *src,BYTE *dest)
{
  DWORD *pdw=(DWORD*)src;
  DWORD *pdw1=(DWORD*)dest;
  WORD *pw=(WORD*)(src+4);
  WORD *pw1=(WORD*)(dest+4);
  if((*pdw)==(*pdw1))
  if((*pw)==(*pw1))
	  return TRUE;
  return FALSE;
}

BOOL Cmp4Byte(BYTE *src,BYTE *dest)
{
  DWORD *pdw=(DWORD*)src;
  DWORD *pdw1=(DWORD*)dest;
  if((*pdw)==(*pdw1))
	  return TRUE;
  return FALSE;
}

//fast code: scanning occured via gateway;
/*pkt_type_t* FastParsePacketGW(const u8 *pkt,int pktlen,int *totalPackets,bool eth_included)
{
u8 current_header=0;             // Current array position of "this_packet" 
const u8 *curr_pkt=pkt;          // Pointer to current part of the packet   
size_t curr_pktlen=pktlen;       // Remaining packet length                 
int ethlen=0, arplen=0;          // Aux length variables: link layer        
int iplen=0,ip6len=0;            // Aux length variables: network layer     
int tcplen=0,udplen=0,icmplen=0; // Aux length variables: transport layer   
int exthdrlen=0;                 // Aux length variables: extension headers 
int next_layer=0;                // Next header type to process             
int expected=0;                  // Next protocol expected                  
bool finished=false;             // Loop breaking flag                      
bool unknown_hdr=false;          // Indicates unknown header found          
IPv4Header *ip4;
IPv6Header *ip6;
TCPHeader *tcp;
UDPHeader *udp;
ICMPv4Header *icmp4;
ICMPv6Header *icmp6;
EthernetHeader *eth;
DestOptsHeader *ext_dopts;
FragmentHeader *ext_frag;
HopByHopHeader *ext_hopt;
RoutingHeader *ext_routing;
ARPHeader *arp;

  //memset(this_packet, 0, sizeof(this_packet));
  *totalPackets = 0;

  // Decide which layer we have to start from
  if(eth_included)
  { next_layer=LINK_LAYER;
    expected=HEADER_TYPE_ETHERNET;
  }else
    next_layer=NETWORK_LAYER;

  // Header processing loop 
  while(!finished && curr_pktlen>0 && current_header<MAX_HEADERS_IN_PACKET)
  {	// Ethernet and ARP headers **********************************************
    if(next_layer==LINK_LAYER)
	{	if(expected==HEADER_TYPE_ETHERNET)
		{	if(curr_pkt==NULL || curr_pktlen<ETH_HEADER_LEN)//eth.storeRecvData(curr_pkt, curr_pktlen)==OP_FAILURE)
			{	unknown_hdr=true;
                break;
            }
			eth = (EthernetHeader*)curr_pkt;
            //if((ethlen=eth->validate())==OP_FAILURE)
			//{	unknown_hdr=true;
            //    break;
            //}
            // Determine next header type
            switch(eth->getEtherType())
			{	case ETHTYPE_IPV4:
                    expected=HEADER_TYPE_IPv4;
                    next_layer=NETWORK_LAYER;
                break;
                case ETHTYPE_IPV6:
                    expected=HEADER_TYPE_IPv6;
                    next_layer=NETWORK_LAYER;
                break;
                case ETHTYPE_ARP:
                    next_layer=LINK_LAYER;
                    expected=HEADER_TYPE_ARP;
                break;
                default:
                    next_layer=APPLICATION_LAYER;
                    expected=HEADER_TYPE_RAW_DATA;
                break;
            }
            this_packet[current_header].length=ethlen;
            this_packet[current_header].buf=(u8*)curr_pkt;
            this_packet[current_header++].type=HEADER_TYPE_ETHERNET;
            //eth.reset();
            curr_pkt+=ethlen;
            curr_pktlen-=ethlen;
			++(*totalPackets);
        }
		else if(expected==HEADER_TYPE_ARP)
		{	if(curr_pkt==NULL || curr_pktlen<ARP_HEADER_LEN)//arp.storeRecvData(curr_pkt, curr_pktlen)==OP_FAILURE)
			{	unknown_hdr=true;
                break;
            }
			arp = (ARPHeader*)curr_pkt;
            //if((arplen=arp->validate())==OP_FAILURE)
			//{	unknown_hdr=true;
            //    break;
            //}
            this_packet[current_header].length=arplen;
            this_packet[current_header].buf=(u8*)curr_pkt;
            this_packet[current_header++].type=HEADER_TYPE_ARP;
            //arp.reset();
            curr_pkt+=arplen;
            curr_pktlen-=arplen;
			++(*totalPackets);
            if(curr_pktlen>0)
			{	next_layer=APPLICATION_LAYER;
                expected=HEADER_TYPE_RAW_DATA;
            }else
				finished=true;
        }
		else
			return NULL;//_ASSERT(finished==true);
    }
    // IPv4 and IPv6 headers *************************************************
	else if(next_layer==NETWORK_LAYER)
	{	// Determine IP version
        if(curr_pkt==NULL || curr_pktlen<IP_HEADER_LEN)//ip4.storeRecvData(curr_pkt, curr_pktlen)==OP_FAILURE)
		{   unknown_hdr=true;
            break;
        }
		ip4 = (IPv4Header*)curr_pkt;
        // IP version 4 ---------------------------------
        if(ip4->getVersion()==4)
		{	///if((iplen=ip4->validate())==OP_FAILURE)
			//{	unknown_hdr=true;
            //    break;
            //}
            // Determine next header type
            switch(ip4->getNextProto())
			{	case HEADER_TYPE_ICMPv4:
                    next_layer=TRANSPORT_LAYER;
                    expected=HEADER_TYPE_ICMPv4;
                break;
                case HEADER_TYPE_IPv4: // IP in IP
                    next_layer=NETWORK_LAYER;
                    expected=HEADER_TYPE_IPv4;
                break;
                case HEADER_TYPE_TCP:
                    next_layer=TRANSPORT_LAYER;
                    expected=HEADER_TYPE_TCP;
                break;
                case HEADER_TYPE_UDP:
                    next_layer=TRANSPORT_LAYER;
                    expected=HEADER_TYPE_UDP;
                break;
                case HEADER_TYPE_IPv6: // IPv6 in IPv4
                    next_layer=NETWORK_LAYER;
                    expected=HEADER_TYPE_IPv6;
                break;
                default:
                    next_layer=APPLICATION_LAYER;
                    expected=HEADER_TYPE_RAW_DATA;
                break;
            }
            this_packet[current_header].length=iplen;
            this_packet[current_header].buf=(u8*)curr_pkt;
            this_packet[current_header++].type=HEADER_TYPE_IPv4;
            //ip4.reset();
            curr_pkt+=iplen;
            curr_pktlen-=iplen;
			++(*totalPackets);
        }
        // IP version 6 ---------------------------------
		else if(ip4->getVersion()==6)
		{	//ip4.reset();
            if(curr_pkt==NULL || curr_pktlen<IPv6_HEADER_LEN)//ip6.storeRecvData(curr_pkt, curr_pktlen)==OP_FAILURE)
			{	unknown_hdr=true;
                break;
            }
			ip6 = (IPv6Header*)curr_pkt; 
            //if((ip6len=ip6->validate())==OP_FAILURE)
			//{	unknown_hdr=true;
            //    break;
            //}
            switch(ip6->getNextHeader())
			{	case HEADER_TYPE_ICMPv6:
                    next_layer=TRANSPORT_LAYER;
                    expected=HEADER_TYPE_ICMPv6;
                break;
                case HEADER_TYPE_IPv4: // IPv4 in IPv6
                    next_layer=NETWORK_LAYER;
                    expected=HEADER_TYPE_IPv4;
                break;
                case HEADER_TYPE_TCP:
                    next_layer=TRANSPORT_LAYER;
                    expected=HEADER_TYPE_TCP;
                break;
                case HEADER_TYPE_UDP:
                    next_layer=TRANSPORT_LAYER;
                    expected=HEADER_TYPE_UDP;
                break;
                case HEADER_TYPE_IPv6: // IPv6 in IPv6
                    next_layer=NETWORK_LAYER;
                    expected=HEADER_TYPE_IPv6;
                break;
                case HEADER_TYPE_IPv6_HOPOPT:
                    next_layer=EXTHEADERS_LAYER;
                    expected=HEADER_TYPE_IPv6_HOPOPT;
                break;
                case HEADER_TYPE_IPv6_OPTS:
                    next_layer=EXTHEADERS_LAYER;
                    expected=HEADER_TYPE_IPv6_OPTS;
                break;
                case HEADER_TYPE_IPv6_ROUTE:
                    next_layer=EXTHEADERS_LAYER;
                    expected=HEADER_TYPE_IPv6_ROUTE;
                break;
                case HEADER_TYPE_IPv6_FRAG:
                    next_layer=EXTHEADERS_LAYER;
                    expected=HEADER_TYPE_IPv6_FRAG;
                break;
                default:
                    next_layer=APPLICATION_LAYER;
                    expected=HEADER_TYPE_RAW_DATA;
                break;
            }
            this_packet[current_header].length=ip6len;
            this_packet[current_header].buf=(u8*)curr_pkt;
            this_packet[current_header++].type=HEADER_TYPE_IPv6;
            //ip6.reset();
            curr_pkt+=ip6len;
            curr_pktlen-=ip6len;
			++(*totalPackets);
        // Bogus IP version -----------------------------
        }
		else
		{	// Wrong IP version, treat as raw data.
            next_layer=APPLICATION_LAYER;
            expected=HEADER_TYPE_RAW_DATA;
	}	}
    // TCP, UDP, ICMPv4 and ICMPv6 headers ************************************
	else if(next_layer==TRANSPORT_LAYER)
	{	if(expected==HEADER_TYPE_TCP)
		{	if(curr_pkt==NULL || curr_pktlen<TCP_HEADER_LEN)//tcp.storeRecvData(curr_pkt, curr_pktlen)==OP_FAILURE)
			{	unknown_hdr=true;
                break;
            }
			tcp = (TCPHeader*)curr_pkt;
            //if((tcplen=tcp->validate())==OP_FAILURE)
			//{	unknown_hdr=true;
            //    break;
            //}
            expected=HEADER_TYPE_RAW_DATA;
            this_packet[current_header].length=tcplen;
            this_packet[current_header].buf=(u8*)curr_pkt;
            this_packet[current_header++].type=HEADER_TYPE_TCP;
            //tcp.reset();
            curr_pkt+=tcplen;
            curr_pktlen-=tcplen;
			++(*totalPackets);
            next_layer=APPLICATION_LAYER;
        }
		else if(expected==HEADER_TYPE_UDP)
		{	if(curr_pkt==NULL || curr_pktlen<UDP_HEADER_LEN)//udp.storeRecvData(curr_pkt, curr_pktlen)==OP_FAILURE)
			{	unknown_hdr=true;
                break;
            }
			udp = (UDPHeader*)curr_pkt;
            //if((udplen=udp->validate())==OP_FAILURE)
			//{	unknown_hdr=true;
            //    break;
            //}
            expected=HEADER_TYPE_RAW_DATA;
            this_packet[current_header].length=udplen;
            this_packet[current_header].buf=(u8*)curr_pkt;
            this_packet[current_header++].type=HEADER_TYPE_UDP;
            //udp.reset();
            curr_pkt+=udplen;
            curr_pktlen-=udplen;
			++(*totalPackets);
            next_layer=APPLICATION_LAYER;
        }
		else if(expected==HEADER_TYPE_ICMPv4)
		{	if(curr_pkt==NULL || curr_pktlen<ICMP_STD_HEADER_LEN)//icmp4.storeRecvData(curr_pkt, curr_pktlen)==OP_FAILURE)
			{	unknown_hdr=true;
                break;
            }
			icmp4 = (ICMPv4Header*)curr_pkt;
            //if((icmplen=icmp4->validate())==OP_FAILURE)
			//{	unknown_hdr=true;
            //    break;
            //}
            switch(icmp4->getType())
			{	// Types that include an IPv4 packet as payload
                case ICMP_UNREACH:
                case ICMP_TIMXCEED:
                case ICMP_PARAMPROB:
                case ICMP_SOURCEQUENCH:
                case ICMP_REDIRECT:
                    next_layer=NETWORK_LAYER;
                    expected=HEADER_TYPE_IPv4;
                break;
                // ICMP types that include misc payloads (or no payload)
                default:
                    expected=HEADER_TYPE_RAW_DATA;
                    next_layer=APPLICATION_LAYER;
                break;
            }
            this_packet[current_header].length=icmplen;
            this_packet[current_header].buf=(u8*)curr_pkt;
            this_packet[current_header++].type=HEADER_TYPE_ICMPv4;
            //icmp4.reset();
            curr_pkt+=icmplen;
            curr_pktlen-=icmplen;
			++(*totalPackets);
        }
		else if(expected==HEADER_TYPE_ICMPv6)
		{	if(curr_pkt==NULL || curr_pktlen<ICMPv6_MIN_HEADER_LEN)//icmp6.storeRecvData(curr_pkt, curr_pktlen)==OP_FAILURE)
			{	unknown_hdr=true;
                break;
            }
			icmp6 = (ICMPv6Header*)curr_pkt;
            //if((icmplen=icmp6->validate())==OP_FAILURE)
			//{	unknown_hdr=true;
            //    break;
            //}
            switch(icmp6->getType())
			{	// Types that include an IPv6 packet as payload
                case ICMPv6_UNREACH:
                case ICMPv6_PKTTOOBIG:
                case ICMPv6_TIMXCEED:
                case ICMPv6_PARAMPROB:
                    next_layer=NETWORK_LAYER;
                    expected=HEADER_TYPE_IPv6;
                break;
                // ICMPv6 types that include misc payloads (or no payload)
                default:
                    expected=HEADER_TYPE_RAW_DATA;
                    next_layer=APPLICATION_LAYER;
                break;
            }
            this_packet[current_header].length=icmplen;
            this_packet[current_header].buf=(u8*)curr_pkt;
            this_packet[current_header++].type=HEADER_TYPE_ICMPv6;
            //icmp6.reset();
            curr_pkt+=icmplen;
            curr_pktlen-=icmplen;
			++(*totalPackets);
        }
		else
		{	// Wrong application layer protocol, treat as raw data.
            next_layer=APPLICATION_LAYER;
            expected=HEADER_TYPE_RAW_DATA;
    }   }
	// IPv6 Extension Headers
	else if(next_layer==EXTHEADERS_LAYER)
	{	u8 ext_next=0;
        // Hop-by-Hop Options
        if(expected==HEADER_TYPE_IPv6_HOPOPT)
		{	if(curr_pkt==NULL || curr_pktlen<HOPBYHOP_MIN_HEADER_LEN)//ext_hopt.storeRecvData(curr_pkt, curr_pktlen)==OP_FAILURE)
			{	unknown_hdr=true;
                break;
            }
			ext_hopt= (HopByHopHeader*)curr_pkt;
            //if((exthdrlen=ext_hopt->validate())==OP_FAILURE)
			//{	unknown_hdr=true;
            //    break;
            //}
            ext_next=ext_hopt->getNextHeader();
            //ext_hopt.reset();
        }
		// Routing Header
        else if(expected==HEADER_TYPE_IPv6_ROUTE)
		{	if(curr_pkt==NULL || curr_pktlen<ROUTING_HEADER_MIN_LEN)//ext_routing.storeRecvData(curr_pkt, curr_pktlen)==OP_FAILURE)
			{	unknown_hdr=true;
                break;
            }
			ext_routing = (RoutingHeader*)curr_pkt;
            //if((exthdrlen=ext_routing->validate())==OP_FAILURE)
			//{	unknown_hdr=true;
            //    break;
            //}
            ext_next=ext_routing->getNextHeader();
            ext_routing->reset();
        }
		// Fragmentation Header
		else if(expected==HEADER_TYPE_IPv6_FRAG)
		{	if(curr_pkt==NULL || curr_pktlen<FRAGMENT_HEADER_LEN)//ext_frag.storeRecvData(curr_pkt, curr_pktlen)==OP_FAILURE)
			{	unknown_hdr=true;
                break;
            }
			ext_frag = (FragmentHeader*)curr_pkt;
            //if((exthdrlen=ext_frag->validate())==OP_FAILURE)
			//{	unknown_hdr=true;
            //    break;
            //}
            ext_next=ext_frag->getNextHeader();
            //ext_frag.reset();
        }
        // Destination Options Header
		else if(expected==HEADER_TYPE_IPv6_OPTS)
		{	if(curr_pkt==NULL || curr_pktlen<ICMPv6_OPTION_MIN_HEADER_LEN)//ext_dopts.storeRecvData(curr_pkt, curr_pktlen)==OP_FAILURE)
			{	unknown_hdr=true;
                break;
            }
			ext_dopts = (DestOptsHeader*)curr_pkt;
            //if((exthdrlen=ext_dopts->validate())==OP_FAILURE)
			//{	unknown_hdr=true;
            //    break;
            //}
            ext_next=ext_dopts->getNextHeader();
            //ext_dopts.reset();
        }
		else
		{	// Should never happen.
            unknown_hdr=true;
            break;
        }

        // Update the info for this header
        this_packet[current_header].length=exthdrlen;
        this_packet[current_header].buf=(u8*)curr_pkt;
        this_packet[current_header++].type=expected;
        curr_pkt+=exthdrlen;
        curr_pktlen-=exthdrlen;
		++(*totalPackets);

        // Lets's see what comes next
        switch(ext_next)
		{	case HEADER_TYPE_ICMPv6:
                next_layer=TRANSPORT_LAYER;
                expected=HEADER_TYPE_ICMPv6;
            break;
            case HEADER_TYPE_IPv4: // IPv4 in IPv6
                next_layer=NETWORK_LAYER;
                expected=HEADER_TYPE_IPv4;
            break;
            case HEADER_TYPE_TCP:
                next_layer=TRANSPORT_LAYER;
                expected=HEADER_TYPE_TCP;
            break;
            case HEADER_TYPE_UDP:
                next_layer=TRANSPORT_LAYER;
                expected=HEADER_TYPE_UDP;
            break;
            case HEADER_TYPE_IPv6: // IPv6 in IPv6
                next_layer=NETWORK_LAYER;
                expected=HEADER_TYPE_IPv6;
            break;
            case HEADER_TYPE_IPv6_HOPOPT:
                next_layer=EXTHEADERS_LAYER;
                expected=HEADER_TYPE_IPv6_HOPOPT;
            break;
            case HEADER_TYPE_IPv6_OPTS:
                next_layer=EXTHEADERS_LAYER;
                expected=HEADER_TYPE_IPv6_OPTS;
            break;
            case HEADER_TYPE_IPv6_ROUTE:
                next_layer=EXTHEADERS_LAYER;
                expected=HEADER_TYPE_IPv6_ROUTE;
            break;
            case HEADER_TYPE_IPv6_FRAG:
                next_layer=EXTHEADERS_LAYER;
                expected=HEADER_TYPE_IPv6_FRAG;
            break;
            default:
                next_layer=APPLICATION_LAYER;
                expected=HEADER_TYPE_RAW_DATA;
            break;
	}	}
    // Miscellaneous payloads *************************************************
	else
	{ // next_layer==APPLICATION_LAYER
        if(curr_pktlen>0)
		{	//if(expected==HEADER_TYPE_DNS){
            //}else if(expected==HEADER_TYPE_HTTP){
            //}... ETC
            this_packet[current_header].length=curr_pktlen;
            this_packet[current_header].buf=(u8*)curr_pkt;
            this_packet[current_header++].type=HEADER_TYPE_RAW_DATA;
            curr_pktlen=0;
        }
        finished=true;
  } } // End of header processing loop

  // If we couldn't validate some header, treat that header and any remaining
  // data, as raw application data.
  if(unknown_hdr==true)
  {	if(curr_pktlen>0)
	{	this_packet[current_header].length=curr_pktlen;
        this_packet[current_header].buf=(u8*)curr_pkt;
        this_packet[current_header++].type=HEADER_TYPE_RAW_DATA;
  } }

  return this_packet;
} // End of parse_received_packet()*/

/*
 * getshort()
 *
 *	Given a handle to a pointer to two bytes, fetch it as an unsigned short
 *	in network order and convert to host order. We advance the pointer.
 */
static unsigned short getshort(const char **p)
{
unsigned short	s;

	_ASSERT( p != 0);
	_ASSERT(*p != 0);

	memcpy(&s, *p, 2);

	*p += 2;

	return ntohs(s);
}

int ProcessRecvPacketGW(BYTE *pktBuf,int pktlen,int *totalPackets,PluginObj *plg,
						wchar_t *sName,wchar_t *sDomain,DWORD* destIP,BYTE *destMAC)
{
  //1.O'zimiz yuborayotgan paketlarni chiqaramiz:
  //if(Cmp6Byte(pktBuf+6,&plg->crntAdptrMAC.b[0])//MAC ADRESS o'zimizniki b-n 1 xil;
  //  return 0; drayverga qo'yib beramiz;
struct NMB_query_response rsp;
const struct NMBpacket *pak;
int nnames,remaining,rdlength,qclass,qtype,paklen;
const char* pmax;
const char* p;
const char* pstats;
const char *nmax;
//char errbuf[128];
char tmpbuf[256];

  if(Cmp6Byte(pktBuf+6,&plg->crntAdptrGWMAC.b[0]))//Agar shlyuz GW dan kelgan bo'lsa:
  {	  if(0x0008==(*(WORD*)(pktBuf+12)))//ETHTYPE_IPV4
	  {if(1==pktBuf[23])//IP4 protocol-->ICMP4
	   {if(0x0000==(*(WORD*)(pktBuf+34)))//ECHO-REPLY
	    {//wsprintf(s,L"%d.%d.%d.%d",pktBuf[26],pktBuf[27],pktBuf[28],pktBuf[29]);
		 Ip4Shufl(destIP, (BYTE*)&pktBuf[26]);
		 memcpy(destMAC,&pktBuf[6],6);
		 return 3;//Hozircha;
  }   }}}

  if(Cmp6Byte(pktBuf,&plg->crntAdptrMAC.b[0]))//Agar bizning MAC ga kelgan b-sa:
  {	  if(0x0008==(*(WORD*)(pktBuf+12)))//ETHTYPE_IPV4
      {if(17==(*(pktBuf+23)))//IP4 protocol-->UDP
       {if(NETBIOSNAMEPORT==(*(pktBuf+35)))//UDP port-137
        {if(Cmp4Byte(pktBuf+30,&plg->myIP.b[0]))//MyIP ga
		 {
		  pak=(const struct NMBpacket*)&pktBuf[42];
		  paklen = pktlen-42;
		  pmax = paklen + (char*)pak;
		  p = pak->data;
		  NETBIOS_unpack(&p, tmpbuf, sizeof tmpbuf); 
		  memset(&rsp, 0, sizeof rsp); 
		  qtype  = getshort(&p);	/* question type	*/
		  qclass = getshort(&p);	/* question class	*/
		  if(verbose > 1)
		  {	//printf(" QUESTION SECTION:\n");
			//printf("   name  = \"%s\"\n",	tmpbuf);
			//printf("   type  = %s\n",
			//           printable_NETBIOS_question_type(tmpbuf, qtype));
			//printf("   class = %s\n",
			//		   printable_NETBIOS_question_class(tmpbuf, qclass));
		  }

		  p += 4;					/* skip past TTL (always zero)	*/

		  /*----------------------------------------------------------------
		   * Fetch the length of the rest of this packet and make sure that
		   * we actually have this much room left. If we don't, we must have
		   * gotten a short UDP packet and won't be able to finish off this
		   * processing. The max size is ~~500 bytes or so.
		   */
		  rdlength = getshort(&p);
		  remaining = (int)(pmax - p);

		  if(rdlength > remaining)
		  {	//printf(" ERROR: rdlength = %d, remaining bytes = %d\n",
			//	   rdlength,
			//	   remaining);
			return 0;
		  }
		  /*----------------------------------------------------------------
		   * Fetch the number of names to be found in the rest of this node
		   * object. Sometimes we get >zero< and it's not clear why this is.
		   * Perhaps it means that there is no NETBIOS nameserver running
		   * but it will answer status requests. Hmmm.
		   */
		  nnames  = *(unsigned char *)p; p++;

		  //if(verbose > 1)
			//printf(" NODE COUNT = %d\n", nnames);
		  if(nnames < 0)
		  {	//sprintf(errbuf, "bad NETBIOS response (count=%d)", nnames);
			return 0;
		  }
		  pstats = p + (nnames * NODE_RECORD_SIZE);
		  if(nnames > TBLSIZE(rsp.nodes))
		  {	nnames = TBLSIZE(rsp.nodes);
			rsp.nametrunc = TRUE;
		  }
		  nmax   = p + (nnames * NODE_RECORD_SIZE);

		  for(; p<nmax; p+=NODE_RECORD_SIZE)
		  {	struct node_name_record	nr;
		  	struct nodeinfo	*ni = (struct nodeinfo*)&rsp.nodes[ rsp.nnodes++ ];

		 	/* Solaris has alignment problems, gotta copy */
			memcpy(&nr, p, NODE_RECORD_SIZE);
			ni->flags = ntohs(nr.flags);
			ni->type  = nr.type;
			strncpy(ni->name, nr.name, 15)[15] = '\0';
			stripA(ni->name);
		  }

		  /*----------------------------------------------------------------
		   * Now we've finished processing the node information and gathered
		   * up everything we can find, so now look for the statistics. We
		   * ONLY try to gather these stats if there is actually any room
		   * left in our buffer.
		   */
		  if((int)(pmax - pstats) >= NODE_STATS_SIZE)
		  {	//memcpy(&rsp.nodestats, pstats, NODE_STATS_SIZE);
			//byteswap_nodestats( &rsp.nodestats );
			//sprintf(rsp.ether, "%02x:%02x:%02x:%02x:%02x:%02x",
			//		rsp.nodestats.uniqueid[0],
			//		rsp.nodestats.uniqueid[1],
			//		rsp.nodestats.uniqueid[2],
			//		rsp.nodestats.uniqueid[3],
			//		rsp.nodestats.uniqueid[4],
			//		rsp.nodestats.uniqueid[5]);
		  }
		  /* postprocessing for good measure */
		  process_response(&rsp);
		  //sprintf(tmpbuf,"%d.%d.%d.%d - %s {%s}",pktBuf[26],pktBuf[27],pktBuf[28],pktBuf[29],rsp.computer,rsp.domain);
		  sprintf(tmpbuf,"%s",rsp.computer);
	  	  MultiByteToWideChar(CP_ACP, 0, tmpbuf, -1, sName, (DWORD)(strlen(tmpbuf)+2));
		  sprintf(tmpbuf,"%s",rsp.domain);
	  	  MultiByteToWideChar(CP_ACP, 0, tmpbuf, -1, sDomain, (DWORD)(strlen(tmpbuf)+2));
  		  Ip4Shufl(destIP, (BYTE*)&pktBuf[26]);
		  return 4;
  }   }}}}

  if(0x0608==(*(WORD*)(pktBuf+12)))//ETHTYPE_ARP
  {	  if(Cmp6Byte(pktBuf,&plg->crntAdptrMAC.b[0]))
	  {	//wsprintf(s,L"%d.%d.%d.%d",pktBuf[28],pktBuf[29],pktBuf[30],pktBuf[31]);
		Ip4Shufl(destIP, (BYTE*)&pktBuf[28]);
		memcpy(destMAC,&pktBuf[6],6);
		*(destMAC+3)=pktBuf[9];*(destMAC+4)=pktBuf[10];*(destMAC+5)=pktBuf[11];
		return 1;//ARP sended;
  }	  }
  /*else if(0x0008==(*(WORD*)(pktBuf+12)))//ETHTYPE_IPV4
  {	  if(Cmp6Byte(pktBuf+6,&plg->crntAdptrMAC.b[0]))
	  {
		return 0;
  }	  }*/
  return 0;
}

//}//extern "C"