/*
 * $Id: //devel/tools/main/nbtscan/win_sock.h#1 $
 *
 *	This defines the <winsock.h> file we want: 1 or 2.
 */
#include <winsock2.h>
