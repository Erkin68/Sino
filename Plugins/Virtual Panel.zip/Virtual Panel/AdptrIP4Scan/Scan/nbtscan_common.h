/*
 * $Id: //devel/tools/main/nbtscan/nbtscan_common.h#1 $
 *
 *	Anchor file for MSVC precompiled headers.
 */

#ifdef _WIN32
#  include "win_sock.h"
#endif

#include <assert.h>
