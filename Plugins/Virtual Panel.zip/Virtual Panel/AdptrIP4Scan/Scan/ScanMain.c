//#include "windows.h"

#pragma warning(disable:4005)

extern "C"
{
#include "..\Packet\Packet32.h"
#include "..\Plugins_C.h"
#include <ntddndis.h>



BOOL GetAdapterGatewayIP4(char*,char*);//gatewayIP [4] ta
int MyStringCpy(wchar_t*,int,wchar_t*);
int MyStringCpyA(char*,int,char*);

/*BYTE ARPPckt[50] = { 0xff,0xff,0xff,0xff,0xff,0xff,//Ethernet-kadr,shirokoveshatelniy;
					 0,0,0,0,0,0,					//Ethernet-kadr,Nash fizicheskiy address,pust 0 budet;
					 8,6,							//Ethernet-kadr,Tip sredy,po RFC Ethernet tip;
					 0,1,							//ARP-kadr,tip kanala svyazi;
					 8,0,							//ARP-kadr,tip protokola;
					 6,								//ARP-kadr,dlina fizicheskogo adresa,dlya ethe-6;
					 4,								//ARP-kadr,dlina IP-adresa,maks 4;
					 0,1,							//ARP-kadr,tip ARP paketa,po RFC;
					 0,0,0,0,0,0,					//ARP-kadr,nash fizich address;
					 0,0,0,0,						//28,29,30,31-ARP-kadr,nash IP-address;
					 0xff,0xff,0xff,0xff,0xff,0xff, //ARP-kadr,fiz addr poluchatelya;
					 0,0,0,0};						//38,39,40,41-ARP-kadr,IP-address poluchatelya;
*/
class CIP4BYTE
{	
public:
	BYTE b[4];
	CIP4BYTE(BYTE b0,BYTE b1,BYTE b2,BYTE b3){b[0]=b0;b[1]=b1;b[2]=b2;b[3]=b3;};
	CIP4BYTE(CIP4BYTE& cmp){b[0]=cmp.b[0];b[1]=cmp.b[1];b[2]=cmp.b[2];b[3]=cmp.b[3];};
	CIP4BYTE(IP4BYTE& cmp){b[0]=cmp.b[0];b[1]=cmp.b[1];b[2]=cmp.b[2];b[3]=cmp.b[3];};
	void operator++()
	{	if(b[3]++ > 254)
		{	b[3] = 1;
			if(b[2]++ > 254)
			{	b[2] = 0;
				if(b[1]++ > 255)
				{	b[1] = 0;
					if(b[0]<255)
						++b[0];
	}	}	}	}
	void operator--()
	{	if(--b[3]<1)
		{	b[3] = 1;
			if(--b[2]<0)
			{	b[2] = 0;
				if(--b[1]<0)
				{	b[1] = 0;
					if(b[0]>0)
						--b[0];
	}	}	}	}
	int operator-(CIP4BYTE& cmp)
	{	long k = (b[0]<<24) | (b[1]<<16) | (b[2]<<8) | b[3];
		long c = (cmp.b[0]<<24) | (cmp.b[1]<<16) | (cmp.b[2]<<8) | cmp.b[3];
		return (int)(k-c);
	}
	int Cmpr(CIP4BYTE& cmp)
	{	if(b[0]<cmp.b[0])return -1;
		if(b[0]>cmp.b[0])return 1;
		if(b[1]<cmp.b[1])return -1;
		if(b[1]>cmp.b[1])return 1;
		if(b[2]<cmp.b[2])return -1;
		if(b[2]>cmp.b[2])return 1;
		if(b[3]<cmp.b[3])return -1;
		if(b[3]>cmp.b[3])return 1;
		return 0;
	}
};

BOOL ScanIpDir(PluginObj* plg,CIP4BYTE& ip)
{
	return TRUE;
}

VOID AddIpToList(PluginObj* plg,CIP4BYTE& ip)
{
}

int BuildARPPacket(	PArpPacket ArpPacket, unsigned char *dst_etheraddr,
					unsigned char *src_etheraddr, int ar_op, unsigned char *ar_sha, 
					unsigned char *ar_sip, unsigned char *ar_tha,
					unsigned char *ar_tip,unsigned short int ar_hw)
{
	memcpy(&(ArpPacket->eth.eth_dst), dst_etheraddr, ETH_ADD_LEN);
	memcpy(&(ArpPacket->eth.eth_src), src_etheraddr, ETH_ADD_LEN);
	ArpPacket->eth.eth_type = htons(ETH_TYPE_ARP);
	ArpPacket->arp.arp_hdr = htons(ar_hw);
	ArpPacket->arp.arp_pro = htons(ARP_PRO_IP);
	ArpPacket->arp.arp_hln = ARP_ETH_ADD_SPACE;
	ArpPacket->arp.arp_pln = ARP_IP_ADD_SPACE;
	ArpPacket->arp.arp_opt = htons(ar_op);
	memcpy(&(ArpPacket->arp.arp_sha), ar_sha, ARP_ETH_ADD_SPACE);
	memcpy(&(ArpPacket->arp.arp_spa), ar_sip, ARP_IP_ADD_SPACE);
	memcpy(&(ArpPacket->arp.arp_tha), ar_tha, ARP_ETH_ADD_SPACE);
	memcpy(&(ArpPacket->arp.arp_tpa), ar_tip, ARP_IP_ADD_SPACE);
	memset(ArpPacket->eth_pad, 32, ETH_PADDING_ARP);
	return(EXIT_SUCCESS);
}

void GetLocalMAC(LPADAPTER lpAdapter, unsigned char *ether_addr)
{ 
	ULONG IoCtlBufferLength = (sizeof(PACKET_OID_DATA) + sizeof(ULONG) - 1);
	PPACKET_OID_DATA OidData;
	OidData = (struct _PACKET_OID_DATA *)malloc(IoCtlBufferLength);
	OidData->Oid = OID_802_3_CURRENT_ADDRESS;
	OidData->Length = 6;
	if(PacketRequest(lpAdapter, FALSE, OidData) == FALSE)
		memcpy(ether_addr, 0, 6);
	else
		memcpy(ether_addr, OidData->Data, 6);
	free(OidData);
}

/*int GetARPReply(LPPACKET lpPacket, unsigned char *iptarget, unsigned char *result)
{
unsigned short int ether_type;
unsigned char ipsender[4]; 
unsigned int off=0;
unsigned int tlen;
struct bpf_hdr *hdr; 
char *pChar;
char *buf;
	buf = (char *)lpPacket->Buffer; 
	hdr = (struct bpf_hdr *)(buf + off);
	tlen = hdr->bh_caplen;
	off += hdr->bh_hdrlen; 
	pChar = (char*)(buf + off); 
	off = Packet_WORDALIGN(off + tlen);
	memcpy(&ether_type, pChar + 12, 2);
	ether_type = ntohs(ether_type); 
	if(ether_type == ETH_TYPE_ARP)
	{	memcpy(ipsender, pChar + 28, 4);
		if(	(iptarget[0] == ipsender[0])&&(iptarget[1] == ipsender[1])&&
			(iptarget[2] == ipsender[2])&&(iptarget[3] == ipsender[3]))
			memcpy(result, pChar + 22, 6);
		else
			return(EXIT_FAILURE);
	}
	else
		return(EXIT_FAILURE);
	return(EXIT_SUCCESS);
}*/

/*int CheckPROMode(LPADAPTER lpAdapter, unsigned char *iptarget, 
				 unsigned char *remotemac,unsigned char *srcMAC,
				 unsigned char *srcIPAdd)
{
LPPACKET lpPacketRequest;
LPPACKET lpPacketReply;
char buffer[256000];
TArpPacket ArpPacket;
unsigned char magicpack[ETH_ADD_LEN]= {0xFF,0xFF,0xFF,0xFF,0xFF,0xFE};
unsigned char mactarget[ARP_ETH_ADD_SPACE];
DWORD timestamp = 0;
int numPacks = 0;
// Init fields
	memset(mactarget, 0, 6);
	// Allocate PACKET structure for ARP Request packet
	if((lpPacketRequest = PacketAllocatePacket()) == NULL)
	{	//msgStatus = "Error : failed to allocate the LPPACKET structure..";
		//SHOWSTAT(msgStatus);
		return(EXIT_FAILURE);
	}
	// Init packet structure
	memset(&ArpPacket, 0, sizeof(TArpPacket));
	// Build ARP Request packet
	BuildARPPacket(&ArpPacket, magicpack, srcMAC, ARP_OP_REQUEST,
					srcMAC, srcIPAdd, mactarget, iptarget, ARP_HARDWARE);
	// Init ARP Request packet
	PacketInitPacket(lpPacketRequest, &ArpPacket, sizeof(ArpPacket));

	// Set number of ARP Request packets to send
	if(PacketSetNumWrites(lpAdapter, 1) == FALSE)
	{	//msgStatus = "Warning : unable to send more than one packet in a single write..";
		//SHOWSTAT(msgStatus);
	}
	// Set hardware filter to directed mode
	if(PacketSetHwFilter(lpAdapter, NDIS_PACKET_TYPE_DIRECTED) == FALSE)
	{	//msgStatus ="Warning: unable to set directed mode..";
		//SHOWSTAT(msgStatus);
	}
	// Set a 512K buffer in the driver
	if(PacketSetBuff(lpAdapter, 512000) == FALSE)
	{	//msgStatus = "Error: unable to set the kernel buffer..";
		//SHOWSTAT(msgStatus);
		PacketFreePacket(lpPacketRequest);
		return(EXIT_FAILURE);
	}
	// Set a 1 second read timeout
	if(PacketSetReadTimeout(lpAdapter, -1) == FALSE)
	{	//msgStatus = "Warning: unable to set the read tiemout..";
		//SHOWSTAT(msgStatus);
	}
	// Allocate PACKET structure for ARP Reply packet
	if((lpPacketReply = PacketAllocatePacket()) == NULL)
	{	//msgStatus = "Error: failed to allocate the LPPACKET structure..";
		//SHOWSTAT(msgStatus);
		PacketFreePacket(lpPacketRequest);
		return(EXIT_FAILURE);
	}
	// Init ARP Reply packet
	PacketInitPacket(lpPacketReply, (char*)buffer, 256000);
	// Allocate memory for remote MAC address
	timestamp = GetTickCount();
	// Main capture loop
	for(;;)
	{	if(numPacks < numPacks)//wParams.
		{	// Send packet
			if(PacketSendPacket(lpAdapter, lpPacketRequest, TRUE) == FALSE)
			{	//msgStatus ="Error : unable to send the packets..";
				//SHOWSTAT(msgStatus);
				PacketFreePacket(lpPacketRequest);
				PacketFreePacket(lpPacketReply);
				return(EXIT_FAILURE);
			}
			// Free packet
			PacketFreePacket(lpPacketRequest);
			numPacks += 1;
		}
		// Capture the packets
		if(PacketReceivePacket(lpAdapter, lpPacketReply, TRUE) == FALSE)
		{	//msgStatus = "Error: PacketReceivePacket failed..";
			//SHOWSTAT(msgStatus);
			PacketFreePacket(lpPacketReply);
			return(EXIT_FAILURE);
		}
		//if(lpPacketReply->ulBytesReceived > 0)
		//	if(GetARPReply(lpPacketReply, iptarget, remotemac) == EXIT_SUCCESS)
		//		break;
		if((GetTickCount() - timestamp) > 2000)//delay)//wParams.
		{	PacketFreePacket(lpPacketReply);
			return(EXIT_FAILURE);
		}
	}
	// Free packet
	PacketFreePacket(lpPacketReply);
	return(EXIT_SUCCESS);
}*/

DWORD WINAPI ScanThrdProc(LPVOID lpPar)
{
npf_if_addr crntAddr, **pAdAddr;
LPADAPTER adptr;LPPACKET pckt,pcktCame; ArpPacket arpPckt;BYTE cameBuf[512];
PluginObj *plg = (PluginObj*)lpPar;


unsigned char magicpack[ETH_ADD_LEN]= {0xFF,0xFF,0xFF,0xFF,0xFF,0xFF};
//unsigned char mactarget[ARP_ETH_ADD_SPACE];
unsigned char src_etheraddr[ETH_ADD_LEN] = {0,0,0,0,0,0};//45AF-5679951
unsigned char src_ipaddr[4] = {192,168,14,35};
unsigned char dst_ipaddr[4] = {192,168,14,32};


	//1.Avval configni plg ga ko'chirib olamiz,chunki conf o'zgarib ketishi mumkin;
	IPTODWORD(plg->ipFrom) = IPTODWORD(conf.ipFrom);
	IPTODWORD(plg->ipTo) = IPTODWORD(conf.ipTo);
	plg->totSearchARPs = IPTODWORD(plg->ipFrom) - IPTODWORD(plg->ipTo);
	
	pAdAddr = (npf_if_addr**)conf.pAdaptersIf_addrs;

	crntAddr = pAdAddr[conf.iCrntAdapter][conf.iCrntAdapterIPAddress];
	IPTODWORD(plg->myIP) = IPTODWORD(crntAddr.IPAddress.__ss_pad1[2]);
	if(plg->myIP.b[0]<128)plg->crntAdptrIPGroupe = 0;//A
	else if(plg->myIP.b[0]<192)plg->crntAdptrIPGroupe = 1;//B
	else if(plg->myIP.b[0]<224)plg->crntAdptrIPGroupe = 2;//C
	else if(plg->myIP.b[0]<240)plg->crntAdptrIPGroupe = 3;//D
	else /*if(plg->myIP.b[0]<256)*/plg->crntAdptrIPGroupe = 4;//D

	plg->iScanMethod[0] = conf.iScanMethod[0];plg->iScanMethod[1] = conf.iScanMethod[1];
	MyStringCpyA(plg->crntAdptrDesc,MAX_PATH-1,conf.crntAdptrDesc);
	MyStringCpyA(plg->crntAdptrName,MAX_PATH-1,conf.crntAdptrName);
	MyStringCpyA(plg->crntAdptrNameInFile,MAX_PATH-1,conf.crntAdptrNameInFile);
	plg->iCrntAdapter = conf.iCrntAdapter;plg->iCrntAdapterIPAddress = conf.iCrntAdapterIPAddress;

	if(!GetAdapterGatewayIP4(plg->crntAdptrName,(char*)&plg->crntAdptrGatewayIP4.b[0]))
		IPTODWORD(plg->crntAdptrGatewayIP4) = 0;
	IPTODWORD(plg->crntAdptrMask) = IPTODWORD(crntAddr.IPAddress.__ss_pad1[2]);

	//2.Adapterni ochamiz:
	adptr = PacketOpenAdapter((PCHAR)plg->crntAdptrName);
	if(!adptr) return 0;

	// set the network adapter in promiscuous mode	
	//if(PacketSetHwFilter(adptr,NDIS_PACKET_TYPE_ALL_LOCAL)==FALSE)//NDIS_PACKET_TYPE_PROMISCUOUS
	//{	//printf("Warning: unable to set promiscuous mode!\n");
	//}

	/* Set hardware filter to directed mode */
	if(PacketSetHwFilter(adptr,NDIS_PACKET_TYPE_DIRECTED)==FALSE)
	{	//msgStatus ="Warning: unable to set directed mode..";SHOWSTAT(msgStatus);
	}

	// set a 512K buffer in the driver
	if(PacketSetBuff(adptr,512000)==FALSE)
	{	//printf("Unable to set the kernel buffer!\n");
	}

	// set a 1 second read timeout
	if(!PacketSetReadTimeout(adptr,5000))
	{	//printf("Warning: unable to set the read tiemout!\n");
	}

	pckt = PacketAllocatePacket();
	PacketInitPacket(pckt,&arpPckt,50);

	pcktCame = PacketAllocatePacket();
	PacketInitPacket(pcktCame,cameBuf,512);

	BuildARPPacket(	&arpPckt, magicpack, src_etheraddr, ARP_OP_REQUEST,
					src_etheraddr,//unsigned char *ar_sha,
					src_ipaddr, src_etheraddr,//unsigned char *ar_tha,
					dst_ipaddr, ARP_HARDWARE);//unsigned short int ar_hw);

	//ARPPckt[28]=plg->myIP.b[0];ARPPckt[29]=plg->myIP.b[1];ARPPckt[30]=plg->myIP.b[2];ARPPckt[31]=plg->myIP.b[3];

	//3.1-metod bilan,ya'ni 1 boshdan IPlarni scan qilamiz:

	//for(c=0; c<totIp; ++c)//while(crntIp.Cmpr(toIp)<0)

	{	//if(ScanIp(plg,crntIp))
		
		//ARPPckt[38]=crntIp.b[0];ARPPckt[39]=crntIp.b[1];ARPPckt[40]=crntIp.b[2];ARPPckt[41]=crntIp.b[3];
		//ARPPckt[38]=192;ARPPckt[39]=168;ARPPckt[40]=101;ARPPckt[41]=4;
		
		PacketSendPacket(adptr,pckt,TRUE);

		ZeroMemory(cameBuf,512);

		if(PacketReceivePacket(adptr,pcktCame,TRUE)==FALSE)
		{//break;
		}


		//AddIpToList(plg,crntIp);
		//ScanIpDir(plg,crntIp);
		
		//++crntIp;
	}

	PacketFreePacket(pckt);
	PacketFreePacket(pcktCame);
	PacketCloseAdapter(adptr);

	return 0;
}
}//extern "C" niki