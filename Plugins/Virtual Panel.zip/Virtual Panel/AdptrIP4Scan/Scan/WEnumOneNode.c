//#include "windows.h"

#pragma warning(disable:4005)
#pragma warning(disable:4013)
#pragma warning(disable:4133)
#pragma warning(disable:4995)
#pragma warning(disable:4996)

#include "..\Packet\Packet32.h"
#include "..\Plugins_C.h"
#include <ntddndis.h>
#include <commctrl.h>


/*DWORD WINAPI WEnumNodeThrdProc(LPVOID lpPar)
{
PluginObj *plg = (PluginObj*)lpPar;LPVOID recvThrdPar[8] = {0,0,0};//0-recvThrd,1-recvThrdId,2-bCancelThread,3-adptr,4-pkts,5-numpkts,6-iNumRecvdPckts;
int r = FirstEntranceNode(plg,0,plg->dwIPWEnum);
	plg->state = end_scan;
	SetWindowText(plg->tlbrEditState,L"");
	SendMessage(plg->tlbrPrgrs, PBM_SETPOS, 0, 0);
	SetWindowText(plg->tlbrBtnStop,strngs[11]);//L"Start");
	return 0;
}*/
