//#include "windows.h"

#pragma warning(disable:4005)
#pragma warning(disable:4995)
#pragma warning(disable:4996)

/*#include "..\libnetutil\IPv4Header.h"
#include "..\libnetutil\IPv6Header.h"
#include "..\libnetutil\TCPHeader.h"
#include "..\libnetutil\UDPHeader.h"
#include "..\libnetutil\ICMPv4Header.h"
#include "..\libnetutil\ICMPv6Header.h"
#include "..\libnetutil\EthernetHeader.h"
#include "..\libnetutil\DestOptsHeader.h"
#include "..\libnetutil\FragmentHeader.h"
#include "..\libnetutil\RoutingHeader.h"
#include "..\libnetutil\ARPHeader.h"
#include "..\libnetutil\ICMPv6Option.h"*/
#include "..\Plugins_C.h"

#define SLEEP(x) Sleep(x)

#define SOCKS5PROXYPORT 1080
#define NETBIOSNAMEPORT 137
#define WILDCARDNAME "*\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0"
#define LINK_LAYER         2
#define NETWORK_LAYER      3
#define TRANSPORT_LAYER    4
#define APPLICATION_LAYER  5
#define EXTHEADERS_LAYER   6

#define MAX_HEADERS_IN_PACKET 32

typedef struct packet_type
{	u32 type;
    u32 length;
    u8 *buf;
}pkt_type_t; 
static pkt_type_t this_packet[MAX_HEADERS_IN_PACKET+1];

BOOL g_Conflict = FALSE;
BOOL g_Reverse = FALSE;
BOOL g_NoLocal = FALSE;
BOOL g_NoLocalNet = FALSE;
BOOL g_AstatBack = FALSE;
BOOL g_SvcDesc = FALSE;
BOOL g_RandSweep = FALSE;


char *g_OutSvcFile = NULL;
char *g_ASOutFile = NULL;
char *g_SpawnCommand = NULL;
char *g_SpawnArgs = NULL;
char *g_ScanFile = NULL;
char *g_AllowName = NULL;
char *g_DenyName = NULL;
char *g_RespondName = NULL;
char *g_QueryName = NULL;
char *g_ProxyUser = "";
char *g_ProxyPass = "";

BYTE g_OutSvcVal = 0;
BYTE g_SpawnSvcVal = 0;

DWORD g_AstatIP = 0;
DWORD g_LocalIP = 0;
DWORD g_BroadcastIP = INADDR_BROADCAST;
DWORD g_NetmaskIP = 0;
DWORD g_SweepStartIP = 0;
DWORD g_SweepEndIP = 0;
DWORD g_RespondIP = 0;
DWORD g_ProxyIP = 0;
DWORD g_QueryIP = 0;

DWORD g_PacketDelay = 100;
DWORD g_ReceiveTimeout = 0;
DWORD g_DelayDrift = 0;

WORD g_LocalPort = NETBIOSNAMEPORT;
WORD g_DestPort = NETBIOSNAMEPORT;
WORD g_ProxyPort = SOCKS5PROXYPORT;
WORD g_ProxyUDPPort = 0;

int g_Retries = 3;

#define ONT_BNODE 0
#define ONT_PNODE 1
#define ONT_MNODE 2
#define ONT_HNODE 3

typedef struct 
{
	BYTE UnitID[6];				// MAC address
	BYTE Jumpers;
	BYTE TestResult;
	WORD Version;
	WORD StatsPeriod;
	WORD NumCRCs;
	WORD NumAlignmentErrors;
	WORD NumCollisions;
	WORD NumSendAborts;
	DWORD NumGoodSends;
	DWORD NumGoodRcvs;
	WORD NumRetransmits;
	WORD NumResourceConditions;
	WORD NumFreeCommandBlocks;
	WORD NumCommandBlocks;
	WORD NumMaxCommandBlocks;
	WORD NumPendingSessions;
	WORD NumMaxPendingSessions;
	WORD NumMaxTotalSessions;
	WORD SessionDataPacketSize;
} NETBIOSSTATS, *PNETBIOSSTATS;

typedef struct
{	WORD TransactionID;			// transaction id, responses match original packet, requests are random/sequential
	WORD OpcodeFlagsRcode;		// opcode, flags and rcode
	WORD QDCount;				// number of questions
	WORD ANCount;				// number of answer resource records
	WORD NSCount;				// number of name service resource records
	WORD ARCount;				// number of athoratative resource records
} NBNAMEHEADER, *PNBNAMEHEADER;

typedef struct 
{	WORD RCode   : 4;			// response code
	WORD fNM_B   : 1;			// Broadcast flag
	WORD fNM_00  : 2;			// reserved, always 0
	WORD fNM_RA  : 1;			// Recursion Available flag
	WORD fNM_RD  : 1;			// Recursion Desired flag
	WORD fNM_TC  : 1;			// Truncation flag
	WORD fNM_AA  : 1;			// Authoratative answer flag
	WORD OpCode  : 4;			// Operation code
	WORD fResponse:1;			// Response flag
} OPCODEFLAGSRCODE;

typedef struct{
	BYTE Name[34];		// compressed name
	WORD Type;			// question type
	WORD Class;			// question class (always type IN - Internet)
} QUESTION, *PQUESTION;

typedef struct
{
	WORD Reserved:13;
	WORD ONT:2;			// Owner Node Type:
						//  00 = B node
                        //  01 = P node
                        //  10 = M node
                        //  11 = Reserved for future use
                        // For registration requests this is the
                        // claimant's type.
                        // For responses this is the actual owner's type.
	WORD fGroup:1;		// Group Name Flag.
						// If one (1) then the RR_NAME is a GROUP NetBIOS name.
						// If zero (0) then the RR_NAME is a UNIQUE NetBIOS name.
} NBFLAGS;

typedef struct 
{
	WORD Type;			// type of recource record
	WORD Class;			// class of resource record (always IN)
	DWORD TTL;			// Time to live
	WORD RDLength;		// length of following resource data
} RESOURCERECORDHEADER, *PRESOURCERECORDHEADER;

typedef struct
{
	char Name[15];		// uncompressed name
	BYTE BinVal;		// binary value
	WORD Flags;			// flags
} NETBIOSNAME, *PNETBIOSNAME;

typedef struct
{
	WORD Reserved:9;	// Reserved for future use.  Must be zero (0).
	WORD fPermanent:1;	// Permanent Name Flag.  If one (1) then entry is for the permanent node name.  
						//  Flag is zero (0) for all other names.
	WORD fActive:1;		// Active Name Flag.  All entries have this flag set to one (1).
	WORD fConflict:1;	// Conflict Flag.  If one (1) then name on this node is in conflict.
	WORD fDeregister:1;	// Deregister Flag.  If one (1) then this name is in the process of being deleted.
	WORD OwnerType:2;	// Owner Node Type:
                        //  00 = B node
                        //  01 = P node
                        //  10 = M node
                        //  11 = Reserved for future use
	WORD fGroupName:1;	// Group Name Flag.
						//  If one (1) then the name is a GROUP NetBIOS name.
						//  If zero (0) then it is a UNIQUE NetBIOS name.
} NETBIOSNAMEFLAGS;

#define RCODE_FMTERR	0x1
#define RCODE_SRVERR	0x2
#define RCODE_NAMERR	0x3
#define RCODE_IMPERR	0x4
#define RCODE_RFSERR	0x5
#define RCODE_ACTERR	0x6
#define RCODE_CFTERR	0x7

#define OPCODE_QUERY		0
#define OPCODE_REGISTRATION	5
#define OPCODE_RELEASE		6
#define OPCODE_WACK			7
#define OPCODE_REFRESH		8

#define QUESTION_TYPE_NB		0x0020	// general name request
#define QUESTION_TYPE_NBSTAT	0x0021	// stats request

#define QUESTION_CLASS_IN		0x0001	// internet class

#define RRTYPE_A		0x0001
#define RRTYPE_NS		0x0002
#define RRTYPE_NULL		0x000A
#define RRTYPE_NB		0x0020
#define RRTYPE_NBSTAT	0x0021
#define RRCLASS_IN		0x0001

extern "C"
{

inline VOID Ip4Shufl(DWORD *outDw, BYTE *src)
{	BYTE *outDb = (BYTE*)outDw;
	*outDb = *(src+3);
	*(outDb+1) = *(src+2);
	*(outDb+2) = *(src+1);
	*(outDb+3) = *src;
}

inline BOOL Cmp6Byte(BYTE *src,BYTE *dest)
{
  DWORD *pdw=(DWORD*)src;
  DWORD *pdw1=(DWORD*)dest;
  WORD *pw=(WORD*)(src+4);
  WORD *pw1=(WORD*)(dest+4);
  if((*pdw)==(*pdw1))
  if((*pw)==(*pw1))
	  return TRUE;
  return FALSE;
}

inline BOOL Cmp4Byte(BYTE *src,BYTE *dest)
{
  DWORD *pdw=(DWORD*)src;
  DWORD *pdw1=(DWORD*)dest;
  if((*pdw)==(*pdw1))
	  return TRUE;
  return FALSE;
}

//fast code: scanning occured via gateway;
/*pkt_type_t* FastParsePacketGW(const u8 *pkt,int pktlen,int *totalPackets,bool eth_included)
{
u8 current_header=0;             // Current array position of "this_packet" 
const u8 *curr_pkt=pkt;          // Pointer to current part of the packet   
size_t curr_pktlen=pktlen;       // Remaining packet length                 
int ethlen=0, arplen=0;          // Aux length variables: link layer        
int iplen=0,ip6len=0;            // Aux length variables: network layer     
int tcplen=0,udplen=0,icmplen=0; // Aux length variables: transport layer   
int exthdrlen=0;                 // Aux length variables: extension headers 
int next_layer=0;                // Next header type to process             
int expected=0;                  // Next protocol expected                  
bool finished=false;             // Loop breaking flag                      
bool unknown_hdr=false;          // Indicates unknown header found          
IPv4Header *ip4;
IPv6Header *ip6;
TCPHeader *tcp;
UDPHeader *udp;
ICMPv4Header *icmp4;
ICMPv6Header *icmp6;
EthernetHeader *eth;
DestOptsHeader *ext_dopts;
FragmentHeader *ext_frag;
HopByHopHeader *ext_hopt;
RoutingHeader *ext_routing;
ARPHeader *arp;

  //memset(this_packet, 0, sizeof(this_packet));
  *totalPackets = 0;

  // Decide which layer we have to start from
  if(eth_included)
  { next_layer=LINK_LAYER;
    expected=HEADER_TYPE_ETHERNET;
  }else
    next_layer=NETWORK_LAYER;

  // Header processing loop 
  while(!finished && curr_pktlen>0 && current_header<MAX_HEADERS_IN_PACKET)
  {	// Ethernet and ARP headers **********************************************
    if(next_layer==LINK_LAYER)
	{	if(expected==HEADER_TYPE_ETHERNET)
		{	if(curr_pkt==NULL || curr_pktlen<ETH_HEADER_LEN)//eth.storeRecvData(curr_pkt, curr_pktlen)==OP_FAILURE)
			{	unknown_hdr=true;
                break;
            }
			eth = (EthernetHeader*)curr_pkt;
            //if((ethlen=eth->validate())==OP_FAILURE)
			//{	unknown_hdr=true;
            //    break;
            //}
            // Determine next header type
            switch(eth->getEtherType())
			{	case ETHTYPE_IPV4:
                    expected=HEADER_TYPE_IPv4;
                    next_layer=NETWORK_LAYER;
                break;
                case ETHTYPE_IPV6:
                    expected=HEADER_TYPE_IPv6;
                    next_layer=NETWORK_LAYER;
                break;
                case ETHTYPE_ARP:
                    next_layer=LINK_LAYER;
                    expected=HEADER_TYPE_ARP;
                break;
                default:
                    next_layer=APPLICATION_LAYER;
                    expected=HEADER_TYPE_RAW_DATA;
                break;
            }
            this_packet[current_header].length=ethlen;
            this_packet[current_header].buf=(u8*)curr_pkt;
            this_packet[current_header++].type=HEADER_TYPE_ETHERNET;
            //eth.reset();
            curr_pkt+=ethlen;
            curr_pktlen-=ethlen;
			++(*totalPackets);
        }
		else if(expected==HEADER_TYPE_ARP)
		{	if(curr_pkt==NULL || curr_pktlen<ARP_HEADER_LEN)//arp.storeRecvData(curr_pkt, curr_pktlen)==OP_FAILURE)
			{	unknown_hdr=true;
                break;
            }
			arp = (ARPHeader*)curr_pkt;
            //if((arplen=arp->validate())==OP_FAILURE)
			//{	unknown_hdr=true;
            //    break;
            //}
            this_packet[current_header].length=arplen;
            this_packet[current_header].buf=(u8*)curr_pkt;
            this_packet[current_header++].type=HEADER_TYPE_ARP;
            //arp.reset();
            curr_pkt+=arplen;
            curr_pktlen-=arplen;
			++(*totalPackets);
            if(curr_pktlen>0)
			{	next_layer=APPLICATION_LAYER;
                expected=HEADER_TYPE_RAW_DATA;
            }else
				finished=true;
        }
		else
			return NULL;//assert(finished==true);
    }
    // IPv4 and IPv6 headers *************************************************
	else if(next_layer==NETWORK_LAYER)
	{	// Determine IP version
        if(curr_pkt==NULL || curr_pktlen<IP_HEADER_LEN)//ip4.storeRecvData(curr_pkt, curr_pktlen)==OP_FAILURE)
		{   unknown_hdr=true;
            break;
        }
		ip4 = (IPv4Header*)curr_pkt;
        // IP version 4 ---------------------------------
        if(ip4->getVersion()==4)
		{	///if((iplen=ip4->validate())==OP_FAILURE)
			//{	unknown_hdr=true;
            //    break;
            //}
            // Determine next header type
            switch(ip4->getNextProto())
			{	case HEADER_TYPE_ICMPv4:
                    next_layer=TRANSPORT_LAYER;
                    expected=HEADER_TYPE_ICMPv4;
                break;
                case HEADER_TYPE_IPv4: // IP in IP
                    next_layer=NETWORK_LAYER;
                    expected=HEADER_TYPE_IPv4;
                break;
                case HEADER_TYPE_TCP:
                    next_layer=TRANSPORT_LAYER;
                    expected=HEADER_TYPE_TCP;
                break;
                case HEADER_TYPE_UDP:
                    next_layer=TRANSPORT_LAYER;
                    expected=HEADER_TYPE_UDP;
                break;
                case HEADER_TYPE_IPv6: // IPv6 in IPv4
                    next_layer=NETWORK_LAYER;
                    expected=HEADER_TYPE_IPv6;
                break;
                default:
                    next_layer=APPLICATION_LAYER;
                    expected=HEADER_TYPE_RAW_DATA;
                break;
            }
            this_packet[current_header].length=iplen;
            this_packet[current_header].buf=(u8*)curr_pkt;
            this_packet[current_header++].type=HEADER_TYPE_IPv4;
            //ip4.reset();
            curr_pkt+=iplen;
            curr_pktlen-=iplen;
			++(*totalPackets);
        }
        // IP version 6 ---------------------------------
		else if(ip4->getVersion()==6)
		{	//ip4.reset();
            if(curr_pkt==NULL || curr_pktlen<IPv6_HEADER_LEN)//ip6.storeRecvData(curr_pkt, curr_pktlen)==OP_FAILURE)
			{	unknown_hdr=true;
                break;
            }
			ip6 = (IPv6Header*)curr_pkt; 
            //if((ip6len=ip6->validate())==OP_FAILURE)
			//{	unknown_hdr=true;
            //    break;
            //}
            switch(ip6->getNextHeader())
			{	case HEADER_TYPE_ICMPv6:
                    next_layer=TRANSPORT_LAYER;
                    expected=HEADER_TYPE_ICMPv6;
                break;
                case HEADER_TYPE_IPv4: // IPv4 in IPv6
                    next_layer=NETWORK_LAYER;
                    expected=HEADER_TYPE_IPv4;
                break;
                case HEADER_TYPE_TCP:
                    next_layer=TRANSPORT_LAYER;
                    expected=HEADER_TYPE_TCP;
                break;
                case HEADER_TYPE_UDP:
                    next_layer=TRANSPORT_LAYER;
                    expected=HEADER_TYPE_UDP;
                break;
                case HEADER_TYPE_IPv6: // IPv6 in IPv6
                    next_layer=NETWORK_LAYER;
                    expected=HEADER_TYPE_IPv6;
                break;
                case HEADER_TYPE_IPv6_HOPOPT:
                    next_layer=EXTHEADERS_LAYER;
                    expected=HEADER_TYPE_IPv6_HOPOPT;
                break;
                case HEADER_TYPE_IPv6_OPTS:
                    next_layer=EXTHEADERS_LAYER;
                    expected=HEADER_TYPE_IPv6_OPTS;
                break;
                case HEADER_TYPE_IPv6_ROUTE:
                    next_layer=EXTHEADERS_LAYER;
                    expected=HEADER_TYPE_IPv6_ROUTE;
                break;
                case HEADER_TYPE_IPv6_FRAG:
                    next_layer=EXTHEADERS_LAYER;
                    expected=HEADER_TYPE_IPv6_FRAG;
                break;
                default:
                    next_layer=APPLICATION_LAYER;
                    expected=HEADER_TYPE_RAW_DATA;
                break;
            }
            this_packet[current_header].length=ip6len;
            this_packet[current_header].buf=(u8*)curr_pkt;
            this_packet[current_header++].type=HEADER_TYPE_IPv6;
            //ip6.reset();
            curr_pkt+=ip6len;
            curr_pktlen-=ip6len;
			++(*totalPackets);
        // Bogus IP version -----------------------------
        }
		else
		{	// Wrong IP version, treat as raw data.
            next_layer=APPLICATION_LAYER;
            expected=HEADER_TYPE_RAW_DATA;
	}	}
    // TCP, UDP, ICMPv4 and ICMPv6 headers ************************************
	else if(next_layer==TRANSPORT_LAYER)
	{	if(expected==HEADER_TYPE_TCP)
		{	if(curr_pkt==NULL || curr_pktlen<TCP_HEADER_LEN)//tcp.storeRecvData(curr_pkt, curr_pktlen)==OP_FAILURE)
			{	unknown_hdr=true;
                break;
            }
			tcp = (TCPHeader*)curr_pkt;
            //if((tcplen=tcp->validate())==OP_FAILURE)
			//{	unknown_hdr=true;
            //    break;
            //}
            expected=HEADER_TYPE_RAW_DATA;
            this_packet[current_header].length=tcplen;
            this_packet[current_header].buf=(u8*)curr_pkt;
            this_packet[current_header++].type=HEADER_TYPE_TCP;
            //tcp.reset();
            curr_pkt+=tcplen;
            curr_pktlen-=tcplen;
			++(*totalPackets);
            next_layer=APPLICATION_LAYER;
        }
		else if(expected==HEADER_TYPE_UDP)
		{	if(curr_pkt==NULL || curr_pktlen<UDP_HEADER_LEN)//udp.storeRecvData(curr_pkt, curr_pktlen)==OP_FAILURE)
			{	unknown_hdr=true;
                break;
            }
			udp = (UDPHeader*)curr_pkt;
            //if((udplen=udp->validate())==OP_FAILURE)
			//{	unknown_hdr=true;
            //    break;
            //}
            expected=HEADER_TYPE_RAW_DATA;
            this_packet[current_header].length=udplen;
            this_packet[current_header].buf=(u8*)curr_pkt;
            this_packet[current_header++].type=HEADER_TYPE_UDP;
            //udp.reset();
            curr_pkt+=udplen;
            curr_pktlen-=udplen;
			++(*totalPackets);
            next_layer=APPLICATION_LAYER;
        }
		else if(expected==HEADER_TYPE_ICMPv4)
		{	if(curr_pkt==NULL || curr_pktlen<ICMP_STD_HEADER_LEN)//icmp4.storeRecvData(curr_pkt, curr_pktlen)==OP_FAILURE)
			{	unknown_hdr=true;
                break;
            }
			icmp4 = (ICMPv4Header*)curr_pkt;
            //if((icmplen=icmp4->validate())==OP_FAILURE)
			//{	unknown_hdr=true;
            //    break;
            //}
            switch(icmp4->getType())
			{	// Types that include an IPv4 packet as payload
                case ICMP_UNREACH:
                case ICMP_TIMXCEED:
                case ICMP_PARAMPROB:
                case ICMP_SOURCEQUENCH:
                case ICMP_REDIRECT:
                    next_layer=NETWORK_LAYER;
                    expected=HEADER_TYPE_IPv4;
                break;
                // ICMP types that include misc payloads (or no payload)
                default:
                    expected=HEADER_TYPE_RAW_DATA;
                    next_layer=APPLICATION_LAYER;
                break;
            }
            this_packet[current_header].length=icmplen;
            this_packet[current_header].buf=(u8*)curr_pkt;
            this_packet[current_header++].type=HEADER_TYPE_ICMPv4;
            //icmp4.reset();
            curr_pkt+=icmplen;
            curr_pktlen-=icmplen;
			++(*totalPackets);
        }
		else if(expected==HEADER_TYPE_ICMPv6)
		{	if(curr_pkt==NULL || curr_pktlen<ICMPv6_MIN_HEADER_LEN)//icmp6.storeRecvData(curr_pkt, curr_pktlen)==OP_FAILURE)
			{	unknown_hdr=true;
                break;
            }
			icmp6 = (ICMPv6Header*)curr_pkt;
            //if((icmplen=icmp6->validate())==OP_FAILURE)
			//{	unknown_hdr=true;
            //    break;
            //}
            switch(icmp6->getType())
			{	// Types that include an IPv6 packet as payload
                case ICMPv6_UNREACH:
                case ICMPv6_PKTTOOBIG:
                case ICMPv6_TIMXCEED:
                case ICMPv6_PARAMPROB:
                    next_layer=NETWORK_LAYER;
                    expected=HEADER_TYPE_IPv6;
                break;
                // ICMPv6 types that include misc payloads (or no payload)
                default:
                    expected=HEADER_TYPE_RAW_DATA;
                    next_layer=APPLICATION_LAYER;
                break;
            }
            this_packet[current_header].length=icmplen;
            this_packet[current_header].buf=(u8*)curr_pkt;
            this_packet[current_header++].type=HEADER_TYPE_ICMPv6;
            //icmp6.reset();
            curr_pkt+=icmplen;
            curr_pktlen-=icmplen;
			++(*totalPackets);
        }
		else
		{	// Wrong application layer protocol, treat as raw data.
            next_layer=APPLICATION_LAYER;
            expected=HEADER_TYPE_RAW_DATA;
    }   }
	// IPv6 Extension Headers
	else if(next_layer==EXTHEADERS_LAYER)
	{	u8 ext_next=0;
        // Hop-by-Hop Options
        if(expected==HEADER_TYPE_IPv6_HOPOPT)
		{	if(curr_pkt==NULL || curr_pktlen<HOPBYHOP_MIN_HEADER_LEN)//ext_hopt.storeRecvData(curr_pkt, curr_pktlen)==OP_FAILURE)
			{	unknown_hdr=true;
                break;
            }
			ext_hopt= (HopByHopHeader*)curr_pkt;
            //if((exthdrlen=ext_hopt->validate())==OP_FAILURE)
			//{	unknown_hdr=true;
            //    break;
            //}
            ext_next=ext_hopt->getNextHeader();
            //ext_hopt.reset();
        }
		// Routing Header
        else if(expected==HEADER_TYPE_IPv6_ROUTE)
		{	if(curr_pkt==NULL || curr_pktlen<ROUTING_HEADER_MIN_LEN)//ext_routing.storeRecvData(curr_pkt, curr_pktlen)==OP_FAILURE)
			{	unknown_hdr=true;
                break;
            }
			ext_routing = (RoutingHeader*)curr_pkt;
            //if((exthdrlen=ext_routing->validate())==OP_FAILURE)
			//{	unknown_hdr=true;
            //    break;
            //}
            ext_next=ext_routing->getNextHeader();
            ext_routing->reset();
        }
		// Fragmentation Header
		else if(expected==HEADER_TYPE_IPv6_FRAG)
		{	if(curr_pkt==NULL || curr_pktlen<FRAGMENT_HEADER_LEN)//ext_frag.storeRecvData(curr_pkt, curr_pktlen)==OP_FAILURE)
			{	unknown_hdr=true;
                break;
            }
			ext_frag = (FragmentHeader*)curr_pkt;
            //if((exthdrlen=ext_frag->validate())==OP_FAILURE)
			//{	unknown_hdr=true;
            //    break;
            //}
            ext_next=ext_frag->getNextHeader();
            //ext_frag.reset();
        }
        // Destination Options Header
		else if(expected==HEADER_TYPE_IPv6_OPTS)
		{	if(curr_pkt==NULL || curr_pktlen<ICMPv6_OPTION_MIN_HEADER_LEN)//ext_dopts.storeRecvData(curr_pkt, curr_pktlen)==OP_FAILURE)
			{	unknown_hdr=true;
                break;
            }
			ext_dopts = (DestOptsHeader*)curr_pkt;
            //if((exthdrlen=ext_dopts->validate())==OP_FAILURE)
			//{	unknown_hdr=true;
            //    break;
            //}
            ext_next=ext_dopts->getNextHeader();
            //ext_dopts.reset();
        }
		else
		{	// Should never happen.
            unknown_hdr=true;
            break;
        }

        // Update the info for this header
        this_packet[current_header].length=exthdrlen;
        this_packet[current_header].buf=(u8*)curr_pkt;
        this_packet[current_header++].type=expected;
        curr_pkt+=exthdrlen;
        curr_pktlen-=exthdrlen;
		++(*totalPackets);

        // Lets's see what comes next
        switch(ext_next)
		{	case HEADER_TYPE_ICMPv6:
                next_layer=TRANSPORT_LAYER;
                expected=HEADER_TYPE_ICMPv6;
            break;
            case HEADER_TYPE_IPv4: // IPv4 in IPv6
                next_layer=NETWORK_LAYER;
                expected=HEADER_TYPE_IPv4;
            break;
            case HEADER_TYPE_TCP:
                next_layer=TRANSPORT_LAYER;
                expected=HEADER_TYPE_TCP;
            break;
            case HEADER_TYPE_UDP:
                next_layer=TRANSPORT_LAYER;
                expected=HEADER_TYPE_UDP;
            break;
            case HEADER_TYPE_IPv6: // IPv6 in IPv6
                next_layer=NETWORK_LAYER;
                expected=HEADER_TYPE_IPv6;
            break;
            case HEADER_TYPE_IPv6_HOPOPT:
                next_layer=EXTHEADERS_LAYER;
                expected=HEADER_TYPE_IPv6_HOPOPT;
            break;
            case HEADER_TYPE_IPv6_OPTS:
                next_layer=EXTHEADERS_LAYER;
                expected=HEADER_TYPE_IPv6_OPTS;
            break;
            case HEADER_TYPE_IPv6_ROUTE:
                next_layer=EXTHEADERS_LAYER;
                expected=HEADER_TYPE_IPv6_ROUTE;
            break;
            case HEADER_TYPE_IPv6_FRAG:
                next_layer=EXTHEADERS_LAYER;
                expected=HEADER_TYPE_IPv6_FRAG;
            break;
            default:
                next_layer=APPLICATION_LAYER;
                expected=HEADER_TYPE_RAW_DATA;
            break;
	}	}
    // Miscellaneous payloads *************************************************
	else
	{ // next_layer==APPLICATION_LAYER
        if(curr_pktlen>0)
		{	//if(expected==HEADER_TYPE_DNS){
            //}else if(expected==HEADER_TYPE_HTTP){
            //}... ETC
            this_packet[current_header].length=curr_pktlen;
            this_packet[current_header].buf=(u8*)curr_pkt;
            this_packet[current_header++].type=HEADER_TYPE_RAW_DATA;
            curr_pktlen=0;
        }
        finished=true;
  } } // End of header processing loop

  // If we couldn't validate some header, treat that header and any remaining
  // data, as raw application data.
  if(unknown_hdr==true)
  {	if(curr_pktlen>0)
	{	this_packet[current_header].length=curr_pktlen;
        this_packet[current_header].buf=(u8*)curr_pkt;
        this_packet[current_header++].type=HEADER_TYPE_RAW_DATA;
  } }

  return this_packet;
} // End of parse_received_packet()*/
void PrintNetbiosName(unsigned char *name)
{
	BYTE BinVal;
	char PrintName[16];
	int x;

	memcpy(PrintName, name, 15);
	PrintName[15] = 0;

	BinVal = name[15];

	printf("%s", PrintName);

	for (x = 0; x < 16 - (int)strlen(PrintName); x++)
		printf(" ");
	
	printf("<%02x>", BinVal);
}
unsigned char hexvals[16] = {'0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F'};
int NetbiosNameToString(char *dest, const BYTE *src, int PacketLeft)
{
int y;
static unsigned char Name[32];
unsigned char UncompressedName[256];
unsigned char hexbuf[3];
char *ptr;
BYTE len;

	// get length of string
	len = *src;

	if (len & 0xC0) // name pointer or other
	{	len = 0;
		// just return last name read
	} 
	else 
	{	if (len >= PacketLeft)
		{	//puts("[Short name, aborting]");
			return 0;
		}
		memset(UncompressedName, 0, sizeof(UncompressedName));
		memset(Name, ' ', sizeof(Name) );
		memcpy(UncompressedName, src+1, len);
		for (y = 0; y < 16; y++)
		{	hexbuf[0] = hexvals[UncompressedName[y*2] - 'A'];
			hexbuf[1] = hexvals[UncompressedName[y*2+1] - 'A'];
			hexbuf[2] = 0;
			Name[y] = (BYTE)strtoul((char *)hexbuf, &ptr, 16);
	}	}
	memcpy(dest, (const char *)Name , 16);
	return (int)(len+2);
}

int StringToNetbiosName(char *dest, const char *src, BYTE binval)
{
	int x, y;
	unsigned char Name[16];
	unsigned char UncompressedName[256];
	char hexbuf[2];

	
	if (strcmp(src, WILDCARDNAME) == 0)
	{
		// set name to all zeros
		// for some reason Windows seems to want wildcard names to be padded
		//   with zeros instead of spaces
		memset(Name, 0, sizeof(Name));
	} 
	else 
	{
		// set name to all spaces
		memset(Name, ' ', sizeof(Name));
	}

	// get length of name
	x = strlen(src);

	// truncate at 15th char
	if (x > 15) x = 15;

	// copy up to 15 chars leaving the rest space padded
	memcpy(Name, src, x);

	// uppercase the name
	Name[15] = 0;
	for (y = 0; y < 15; y++)
		Name[y] = toupper((int)Name[y]);

	// set 16th binary char
	Name[15] = binval;

	UncompressedName[0] = 32;

	// convert each char to hex
	for (x = 0; x < 16; x++)
		sprintf((char *)&UncompressedName[(x*2)+1], "%02X", (DWORD)Name[x] );

	// add 'A' to each char
	for (x = 1; x <= 32; x++)
	{
		char *ptr;

		hexbuf[0] = UncompressedName[x];
		hexbuf[1] = 0;
		UncompressedName[x] = 'A' + (BYTE)strtoul(hexbuf, &ptr, 16);;
	}

	UncompressedName[33] = 0;
#if 0
	// add SCOPE_ID 
	UncompressedName[33] = 7;
	memcpy((char *)&UncompressedName[34], "NETBIOS", 7);

	UncompressedName[41] = 3;
	memcpy((char *)&UncompressedName[42], "COM", 3);
#endif

	// set the length
	x = 34;

	memcpy(dest, UncompressedName, x);

	return x;
}

DWORD FormPacket(unsigned char *buff, WORD TranID, BYTE Opcode, char *QuestionName, WORD QuestionType, BOOL fResponse, BOOL fBroadcast, BOOL fTruncated, BOOL fRecursionAvailable, BOOL fRecursionDesired, BOOL fAuthoratativeAnswer, WORD RCode, WORD QDCount, WORD ANCount, WORD NSCount, WORD ARCount, DWORD TargetIP, BOOL fGroup, BYTE ONT)
{
	NBFLAGS nbflags;
	PNBNAMEHEADER pnbnameheader = (PNBNAMEHEADER)buff;
	OPCODEFLAGSRCODE Wcode;
	BYTE *ptr, *firstnameptr = NULL;
	DWORD d;
	WORD w;

	memset(pnbnameheader, 0, sizeof(NBNAMEHEADER) );

	pnbnameheader->TransactionID = TranID;	// Transaction ID

	Wcode.fResponse = fResponse;		// request not response
	Wcode.OpCode = Opcode;				// operation code (command)
	Wcode.fNM_00 = 0;					// always 0
	Wcode.fNM_B = fBroadcast;			// broadcast
	Wcode.fNM_RA = fRecursionAvailable;	// always 0 for requests
	Wcode.fNM_RD = fRecursionDesired;	// no recursion requested
	Wcode.fNM_TC = fTruncated;			// not truncated
	Wcode.fNM_AA = fAuthoratativeAnswer;// always 0 for requests
	Wcode.RCode = RCode;

	pnbnameheader->OpcodeFlagsRcode = htons(*((WORD*)&Wcode));

	pnbnameheader->QDCount = htons(QDCount);
	pnbnameheader->ANCount = htons(ANCount);
	pnbnameheader->ARCount = htons(ARCount);
	pnbnameheader->NSCount = htons(NSCount);

	ptr = (BYTE *)(pnbnameheader + 1);

	if (QDCount > 0)
	{
		PQUESTION pquestion = (PQUESTION)ptr;

		StringToNetbiosName((char *)pquestion->Name, QuestionName, QuestionName[15]);

		firstnameptr = pquestion->Name;

		pquestion->Type = htons(QuestionType);
		pquestion->Class = htons(QUESTION_CLASS_IN);
		
		ptr += sizeof(QUESTION);
	}

	if (ANCount > 0)
	{
		d = StringToNetbiosName((char *)ptr, QuestionName, QuestionName[15]);

		ptr += d;

		PRESOURCERECORDHEADER presrecordheader = (PRESOURCERECORDHEADER)ptr;

		presrecordheader->Class = htons(RRCLASS_IN);
		presrecordheader->RDLength = htons(6);
		presrecordheader->TTL = 0;
		presrecordheader->Type = htons(RRTYPE_NB);

		ptr += sizeof(RESOURCERECORDHEADER);

		nbflags.fGroup = fGroup;
		nbflags.Reserved = 0;
		nbflags.ONT = ONT;
		
		memcpy(&w, &nbflags, sizeof(WORD) );

		w = htons(w);

		memcpy(ptr, &w, sizeof(WORD));

		ptr += sizeof(WORD);

		*((DWORD *)ptr) = TargetIP;

		ptr += sizeof(DWORD);
	}

	if (ARCount > 0)
	{
		if (firstnameptr == NULL)
		{
			d = StringToNetbiosName((char *)ptr, QuestionName, QuestionName[15]);
			ptr += d;
		}
		else
		{
			*((WORD *)ptr) = htons(0xC000 | (firstnameptr - buff));
			ptr+=2;
		}

		PRESOURCERECORDHEADER presrecordheader = (PRESOURCERECORDHEADER)ptr;

		presrecordheader->Class = htons(RRCLASS_IN);
		presrecordheader->RDLength = htons(6);
		presrecordheader->TTL = 0;
		presrecordheader->Type = htons(RRTYPE_NB);

		ptr += sizeof(RESOURCERECORDHEADER);

		nbflags.fGroup = fGroup;
		nbflags.Reserved = 0;
		nbflags.ONT = ONT;
		
		memcpy(&w, &nbflags, sizeof(WORD) );

		w = htons(w);

		memcpy(ptr, &w, sizeof(WORD));

		ptr += sizeof(WORD);

		*((DWORD *)ptr) = TargetIP ;
		

		ptr += sizeof(DWORD);
	}

	return (DWORD)(ptr - buff);
}

DWORD FormNBSTATPacket(unsigned char *buff)
{
	return FormPacket(buff, rand(), OPCODE_QUERY, WILDCARDNAME, QUESTION_TYPE_NBSTAT, FALSE, TRUE, FALSE, FALSE, FALSE, FALSE, 0, 1, 0, 0, 0, 0, 0, ONT_BNODE);
}
DWORD FormNegativeQueryResponsePacket(unsigned char *buff, WORD TransactionID, char *NameBuff, WORD Rcode, DWORD RespondIP, BYTE ONT)
{
	return FormPacket(buff, TransactionID, OPCODE_REGISTRATION, NameBuff, QUESTION_TYPE_NB, TRUE, FALSE, FALSE, TRUE, TRUE, TRUE, Rcode, 0, 1, 0, 0, RespondIP , 0, ONT);
}
DWORD FormNameReleasePacket(unsigned char *buff, char *NameBuff, DWORD DestAddr, BOOL bGroupName, BYTE ONT)
{
	return FormPacket(buff, rand(), OPCODE_RELEASE, NameBuff, QUESTION_TYPE_NB, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, 0, 1, 0, 0, 1, DestAddr, bGroupName, ONT);
}

void ParamToNetbiosName(char *dest, char *src)
{
	int x;
	char *tmpptr;
	char *BinValPtr = strchr(src, '\\');

	if (BinValPtr != NULL)
	{
		*BinValPtr = 0;
		tmpptr = BinValPtr - 1;
	} 
	else 
	{
		tmpptr = src + strlen(src) - 1;	// point to last char in string
	}

	while (tmpptr > src && *tmpptr == ' ')
	{
		*tmpptr = 0;
		tmpptr--;
	}

	int len = strlen(src);

	if (len > 15) len = 15;

	if (strcmp(src, WILDCARDNAME) == 0)
		memset(dest, 0, 15);
	else
		memset(dest, ' ', 15);

	memcpy(dest, src, len);

	if (BinValPtr != NULL)
	{
		dest[15] = (unsigned char)strtoul(BinValPtr+1, NULL, 16);
		*BinValPtr = '\\';
	}
	else 
		dest[15] = 0;

	// convert to upper case
	for (x = 0; x <15; x++)
		dest[x] = toupper(dest[x]);
	
}

void PrintServiceDescription(char *Name, BOOL GroupName)
{
	switch ((unsigned char)Name[15])
	{
	case 0x0:
		if (GroupName )
			printf("Domain Name\n");
		else
		{
			if (memcmp(Name, "IS~", 3) == 0)
				printf("IIS\n");
			else
				printf("Workstation service (name)\n");
		}
		break;
	case 0x1:
		if (GroupName )
			printf("Master Browser\n");
		else
			printf("Messenger Service \n");
		break;
	case 0x3:
		if (!GroupName)
			printf("Messenger Service \n");
		break;
	case 0x6:
		if (!GroupName)
			printf("RAS Server Service \n");
		break;
	case 0x1B:
		if (!GroupName)
			printf("Domain Master Browser (PDC name)\n");
		break;
	case 0x1C:
		if (GroupName )
			if (memcmp(Name, "INet~", 5) == 0)
				printf("IIS\n");
			else
				printf("Domain Controller\n");
		break;
	case 0x1D:
		if (!GroupName)
			printf("Master Browser\n");
		break;
	case 0x1E:
		if (GroupName )
			printf("Browser Service Elections\n");
		break;
	case 0x1F:
		if (!GroupName)
			printf ("NetDDE Service \n");
		break;
	case 0x20:
		if (!GroupName)
			printf("File Server Service \n");
		break;
	case 0x21:
		if (!GroupName)
			printf("RAS Client Service \n");
		break;
	case 0x22:
		if (!GroupName)
			printf("Microsoft Exchange Interchange(MSMail Connector)\n");
		break;
	case 0x23:
		if (!GroupName)
			printf("Microsoft Exchange Store\n");
		break;
	case 0x24:
		if (!GroupName)
			printf("Microsoft Exchange Directory\n");
		break;
	case 0x2B:
		if (!GroupName)
			printf("Lotus Notes Server Service\n");
		break;
	case 0x2F:
		if (!GroupName && memcmp(Name, "IRISMULTICAST", 13) == 0)
			printf("Lotus Notes\n");
		break;
	case 0x30:
		if (!GroupName)
			printf("Modem Sharing Server Service\n");
		break;
	case 0x31:
		if (!GroupName)
			printf("Modem Sharing Client Service \n");
		break;
	case 0x33:
		if (!GroupName && memcmp(Name, "IRISNAMESERVER", 14) == 0)
			printf("Lotus Notes\n");
		break;
	case 0x43:
		if (!GroupName)
			printf("SMS Clients Remote Control\n");
		break;
	case 0x44:
		if (!GroupName)
			printf("SMS Administrators Remote Control Tool\n");
		break;
	case 0x45:
		if (!GroupName)
			printf("SMS Clients Remote Chat\n");
		break;
	case 0x46:
		if (!GroupName)
			printf("SMS Clients Remote Transfer\n");
		break;
	case 0x4C:
	case 0x52:
		if (!GroupName)
			printf("DEC Pathworks TCPIP service on Windows NT\n");
		break;
	case 0x6A:
		if (!GroupName)
			printf("Microsoft Exchange IMC\n");
		break;
	case 0x87:
		if (!GroupName)
			printf("Microsoft Exchange MTA\n");
		break;
	case 0xBE:
		if (!GroupName)
			printf("Network Monitor Agent\n");
		break;
	case 0xBF:
		if (!GroupName)
			printf("Network Monitor Application (utility)\n");
		break;
	}

}

DWORD ProcessResourceRecord(PNBNAMEHEADER pnbnameheader, const BYTE *ptr, int Type, SOCKET sock, LPSOCKADDR_IN psockaddr, int PacketLeft)
{
	BYTE outbuff[1024];
	char NameBuff[256];
	WORD w, RRType, RRClass, RRRDLength, NameFlags;
	DWORD d, RRTTL;
	BYTE NumNames;
	BYTE BinVal;
	NETBIOSNAMEFLAGS NameFlagsStruct;
	NBFLAGS nbflags;
	int x;
	static DWORD LastOutIP = 0;
	static DWORD LastSpawnIP = 0;

	d = NetbiosNameToString(NameBuff, ptr, PacketLeft);

	if (d == 0) return 0;

	PrintNetbiosName((BYTE *)NameBuff);
	puts("");
	ptr += d;

	if (PacketLeft - d < sizeof(RESOURCERECORDHEADER) || PacketLeft - d < sizeof(RESOURCERECORDHEADER) + ntohs(((PRESOURCERECORDHEADER)ptr)->RDLength) )
	{
		puts("[Short record, aborting]");
		return 0;
	}

	PRESOURCERECORDHEADER presrecordheader = (PRESOURCERECORDHEADER)ptr;


	RRType = ntohs(presrecordheader->Type);
	RRClass = ntohs(presrecordheader->Class);
	RRTTL = ntohl(presrecordheader->TTL);
	RRRDLength = ntohs(presrecordheader->RDLength);

	ptr = (LPBYTE)(presrecordheader+1);


	switch (RRType)
	{
	case RRTYPE_A:
		printf("IP Address Resource Record:\n");
		break;
	case RRTYPE_NS:
		printf("Name Service Resource Record:\n");
		break;
	case RRTYPE_NULL:
		printf("NULL Resource Record:\n");
		break;
	case RRTYPE_NB	:
		printf("NetBIOS Name Service Resource Record:\n");
		break;
	}


	switch (RRType)
	{
	case RRTYPE_A:
	case RRTYPE_NS:
		break;
	case RRTYPE_NULL:
	case RRTYPE_NB	:

		for (x = 0; x < RRRDLength / 6; x++)
		{
			memcpy(&w, ptr, sizeof(w) );
			w = ntohs(w);
			memcpy(&nbflags, &w, sizeof(w) );
			ptr += sizeof(WORD);

			printf("Owner Node Type: ");
			switch (nbflags.ONT)
			{
			case ONT_BNODE:
				printf("B-NODE ");
				break;
			case ONT_PNODE:
				printf("P-NODE ");
				break;
			case ONT_MNODE:
				printf("M-NODE ");
				break;
			case ONT_HNODE:
				printf("H-NODE ");
			}

			printf("  ");

			if (nbflags.fGroup)
				printf("GROUP  ");
			else
				printf("UNIQUE ");

			printf("  -  ");

			printf("IP: %u.%u.%u.%u", *ptr, *(ptr+1), *(ptr+2),*(ptr+3));

			ptr+=4;

			puts("");

		}

		break;
	case RRTYPE_NBSTAT:
		{
			FILE *outfile = NULL;

			printf("Node Status Resource Record:\n");
			NumNames = *ptr;
			ptr++;
			PNETBIOSNAME pnetbiosname = (PNETBIOSNAME)ptr;

			if (g_ASOutFile != NULL)
			{
				outfile = fopen(g_ASOutFile, "at");
				if (outfile != NULL)
				{
					time_t curtime = time(NULL);
					fprintf(outfile, "ASTAT response from %s at %s", inet_ntoa(psockaddr->sin_addr), ctime(&curtime) );
				}
			}


			for (w = 0; w < NumNames; w++)
			{
				char *tptr;
				BinVal = pnetbiosname->BinVal;
				pnetbiosname->BinVal = 0;

				printf("%s <%02x>  ", pnetbiosname->Name, BinVal );

				if (outfile != NULL)
					fprintf(outfile, "%s <%02x>  ", pnetbiosname->Name, BinVal );

				pnetbiosname->BinVal = BinVal;

				NameFlags = ntohs(pnetbiosname->Flags);
				memcpy(&NameFlagsStruct, &NameFlags, sizeof(NameFlags) );
				if (NameFlagsStruct.fActive)
					tptr = "ACTIVE   ";
				else
					tptr = "INACTIVE ";

				printf("%s", tptr);
				if (outfile != NULL)
					fprintf(outfile, "%s", tptr);

				if (NameFlagsStruct.fGroupName)
					tptr = "GROUP  ";
				else
					tptr = "UNIQUE ";

				printf("%s", tptr);
				if (outfile != NULL)
					fprintf(outfile, "%s", tptr);

				if (NameFlagsStruct.fPermanent)
					tptr = "PERMANENT ";
				else
					tptr = "NOTPERM   ";

				printf("%s", tptr);
				if (outfile != NULL)
					fprintf(outfile, "%s", tptr);

				if (NameFlagsStruct.fConflict)
					tptr = "INCONFLICT ";
				else
					tptr = "NOCONFLICT ";

				printf("%s", tptr);
				if (outfile != NULL)
					fprintf(outfile, "%s", tptr);


				if (NameFlagsStruct.fDeregister)
					tptr = "DEREGISTERED ";
				else
					tptr = "NOTDEREGED   ";

				printf("%s", tptr);
				if (outfile != NULL)
					fprintf(outfile, "%s", tptr);


				switch (NameFlagsStruct.OwnerType)
				{
				case ONT_BNODE:
					tptr = "B-NODE ";
					break;
				case ONT_PNODE:
					tptr = "P-NODE ";
					break;
				case ONT_MNODE:
					tptr = "M-NODE ";
					break;
				case ONT_HNODE:
					tptr = "H-NODE ";
				}

				printf("%s\n", tptr);
				if (outfile != NULL)
					fprintf(outfile, "%s\n", tptr);

				pnetbiosname->BinVal = BinVal;

				if (g_SvcDesc)
					PrintServiceDescription(pnetbiosname->Name, NameFlagsStruct.fGroupName);


				if (!NameFlagsStruct.fGroupName && g_OutSvcFile != NULL && BinVal == g_OutSvcVal && LastOutIP != psockaddr->sin_addr.s_addr && memcmp(pnetbiosname->Name, "IS~", 3) != 0)
				{
					LastOutIP = psockaddr->sin_addr.s_addr;

					FILE *outfile2 = fopen(g_OutSvcFile, "at");

					if (outfile2 != NULL)
					{
						pnetbiosname->BinVal = 0;

						fprintf(outfile2, "%s %s\n", inet_ntoa(psockaddr->sin_addr), pnetbiosname->Name);

						pnetbiosname->BinVal = BinVal;

						fclose(outfile2);

						printf(" **** Machine added to %s\n", g_OutSvcFile );
					}
				}

				if (!NameFlagsStruct.fGroupName && g_OutSvcFile != NULL && BinVal == g_SpawnSvcVal && LastSpawnIP != psockaddr->sin_addr.s_addr && memcmp(pnetbiosname->Name, "IS~", 3) != 0)
				if (!NameFlagsStruct.fGroupName && BinVal == g_SpawnSvcVal )
				{
					LastSpawnIP = psockaddr->sin_addr.s_addr;

					if (g_SpawnCommand != NULL)
					{
						char buff[1024];

						pnetbiosname->BinVal = 0;

						sprintf(buff, "%s", inet_ntoa(psockaddr->sin_addr));
#ifdef WIN32

						//if (_spawnlpe(_P_NOWAIT, g_SpawnCommand, g_SpawnCommand, g_SpawnArgs, pnetbiosname->Name, buff, NULL, NULL) == -1)
							printf(" *** Error spawning \"%s\"\n", g_SpawnCommand);
						//else
						//{
						//	printf(" **** Spawned \"%s\"\n", g_SpawnCommand);
						//}
#else
						if (fork() == 0)
							if (execlp(g_SpawnCommand, g_SpawnCommand, g_SpawnArgs, pnetbiosname->Name, buff, NULL) == -1 )
							{
								printf(" *** Error spawning \"%s %s %s %s\"\n", g_SpawnCommand, g_SpawnArgs, pnetbiosname->Name, buff );
								exit(0);
							}
#endif

						pnetbiosname->BinVal = BinVal;
						SLEEP(20);
					}
				}

				
				if (g_Conflict && !NameFlagsStruct.fConflict )
				{
					d = FormNameReleasePacket(outbuff, pnetbiosname->Name, psockaddr->sin_addr.s_addr, NameFlagsStruct.fGroupName, NameFlagsStruct.OwnerType);

					//SendPacket(sock, (const char *)outbuff, d, psockaddr);

					printf(" **** Name release sent to %s\n", inet_ntoa(psockaddr->sin_addr) );
				}

				pnetbiosname++;
			}


			PNETBIOSSTATS pnetbiosstats = (PNETBIOSSTATS)pnetbiosname;

			printf("MAC Address:             %02X-%02X-%02X-%02X-%02X-%02X\n", pnetbiosstats->UnitID[0], pnetbiosstats->UnitID[1], pnetbiosstats->UnitID[2], pnetbiosstats->UnitID[3], pnetbiosstats->UnitID[4], pnetbiosstats->UnitID[5] );
			if (outfile != NULL)
				fprintf(outfile, "MAC Address:             %02X-%02X-%02X-%02X-%02X-%02X\n\n", pnetbiosstats->UnitID[0], pnetbiosstats->UnitID[1], pnetbiosstats->UnitID[2], pnetbiosstats->UnitID[3], pnetbiosstats->UnitID[4], pnetbiosstats->UnitID[5] );

#ifdef STUFFTHATSUSUALLYALLZERO
			printf("\nStatistics:\n");
			printf("Jumpers:                 0x%02x\n", pnetbiosstats->Jumpers);
			printf("Test result:             0x%02x\n", pnetbiosstats->TestResult);
			printf("Version:                 %d.%d\n", HIBYTE(pnetbiosstats->Version), LOBYTE(pnetbiosstats->Version) );
			printf("Stats period:            0x%04x\n", ntohs(pnetbiosstats->StatsPeriod) );
			printf("Num CRCs:                %u\n", ntohs(pnetbiosstats->NumCRCs ) );
			printf("Num Alignment errs:      %u\n", ntohs(pnetbiosstats->NumAlignmentErrors ) );
			printf("Num Collisions:          %u\n", ntohs(pnetbiosstats->NumCollisions ) );
			printf("Num Send Aborts:         %u\n", ntohs(pnetbiosstats->NumSendAborts ) );
			printf("Num Good Sends:          %u\n", ntohl(pnetbiosstats->NumGoodSends ) );
			printf("Num Good Receives:       %u\n", ntohl(pnetbiosstats->NumGoodRcvs ) );
			printf("Num Retransmits:         %u\n", ntohs(pnetbiosstats->NumRetransmits ) );
			printf("Num Resource Conditions: %u\n", ntohs(pnetbiosstats->NumResourceConditions ) );
			printf("Free Command Blocks:     %u\n", ntohs(pnetbiosstats->NumFreeCommandBlocks ) );
			printf("Total Command Blocks:    %u\n", ntohs(pnetbiosstats->NumCommandBlocks ) );
			printf("Max Command Blocks       %u\n", ntohs(pnetbiosstats->NumMaxCommandBlocks ) );
			printf("Pending Sessions:        %u\n", ntohs(pnetbiosstats->NumPendingSessions ) );
			printf("Max Pending Sessions:    %u\n", ntohs(pnetbiosstats->NumMaxPendingSessions ) );
			printf("Max Total Sessions:      %u\n", ntohs(pnetbiosstats->NumMaxTotalSessions ) );
			printf("Session Data Packet Size:%u\n", ntohs(pnetbiosstats->SessionDataPacketSize ) );
#endif

			if (outfile != NULL)
			{
				fclose(outfile);
				outfile = NULL;
			}

		}
		break;
	default:
		printf("Unknown resource record type: 0x%04x\n", RRType);
		break;
	}

	{
		WORD w;
		OPCODEFLAGSRCODE Wcode;

		w = ntohs(pnbnameheader->OpcodeFlagsRcode);

		memcpy(&Wcode, &w, sizeof(w) );


		if (g_AstatBack && RRType == RRTYPE_NB && Wcode.OpCode == OPCODE_QUERY && Wcode.fResponse)
		{
			d = FormNBSTATPacket(outbuff);

			//SendPacket(sock, (const char *)outbuff, d, psockaddr);

			printf(" **** NBSTAT request packet sent\n");
		}
	}


	return d + RRRDLength + sizeof(RESOURCERECORDHEADER);
}

int ProcessRecvPacketGW(BYTE *pktBuf,int pktlen,int *totalPackets,PluginObj *plg,wchar_t *s, DWORD* destIP,BYTE *destMAC)
{
  //1.O'zimiz yuborayotgan paketlarni chiqaramiz:
  //if(Cmp6Byte(pktBuf+6,&plg->crntAdptrMAC.b[0])//MAC ADRESS o'zimizniki b-n 1 xil;
  //  return 0; drayverga qo'yib beramiz;

  if(Cmp6Byte(pktBuf+6,&plg->crntAdptrGWMAC.b[0]))//Agar shlyuz GW dan kelgan bo'lsa:
  {	  if(0x0008==(*(WORD*)(pktBuf+12)))//ETHTYPE_IPV4
	  {if(1==pktBuf[23])//IP4 protocol-->ICMP4
	   {if(0x0000==(*(WORD*)(pktBuf+34)))//ECHO-REPLY
	    {wsprintf(s,L"%d.%d.%d.%d",pktBuf[26],pktBuf[27],pktBuf[28],pktBuf[29]);
		 Ip4Shufl(destIP, (BYTE*)&pktBuf[26]);
		 memcpy(destMAC,&pktBuf[6],6);
		 return 3;//Hozircha;
  }   }}}

  if(Cmp6Byte(pktBuf,&plg->crntAdptrMAC.b[0]))//Agar bizning MAC ga kelgan b-sa:
  {	  if(0x0008==(*(WORD*)(pktBuf+12)))//ETHTYPE_IPV4
      {if(17==(*(pktBuf+23)))//IP4 protocol-->UDP
       {if(NETBIOSNAMEPORT==(*(pktBuf+35)))//UDP port-137
        {if(Cmp4Byte(pktBuf+30,&plg->myIP.b[0]))//MyIP ga
		 {int l=15,l1=15;for(int i=0; i<15; ++i){if(' '==pktBuf[117+i] || '_'==pktBuf[117+i]){pktBuf[117+i]=0;l=i;break;}}
		  MultiByteToWideChar(CP_OEMCP,MB_PRECOMPOSED,(LPCSTR)&pktBuf[117],l,s,l);
		  s[l] = '{';
		  for(int i=0; i<15; ++i){if(' '==pktBuf[99+i] || '_'==pktBuf[99+i]){pktBuf[99+i]=0;l1=i;break;}}
	      MultiByteToWideChar(CP_OEMCP,MB_PRECOMPOSED,(LPCSTR)&pktBuf[99],15,&s[l+1],l1);
		  wsprintf(&s[l+l1+1],L"}-%d.%d.%d.%d",pktBuf[26],pktBuf[27],pktBuf[28],pktBuf[29]);

		  //NetbiosNameToString((char*)s, &pktBuf[42], pktlen-42);

		  int packetsize = pktlen-42;
		  char *buff = (char*)&pktBuf[42];
			char NameBuff[256];
			PNBNAMEHEADER pnbnameheader = (PNBNAMEHEADER)buff;
			OPCODEFLAGSRCODE Wcode;
			WORD w, QDCount, ANCount, NSCount, ARCount, RCode, OPCode;
			BOOL fResponse, fBroadcast, fRecursionAvailable, fRecursionDesired, fTruncated, fAuthoratativeAnswer;
			const BYTE *ptr;
			DWORD d;

			if(packetsize < sizeof(NBNAMEHEADER) )
			{	//puts("[Short packet, aborting]");
				//return 0;
			}

			QDCount = ntohs(pnbnameheader->QDCount);
			ANCount = ntohs(pnbnameheader->ANCount);
			ARCount = ntohs(pnbnameheader->ARCount);
			NSCount = ntohs(pnbnameheader->NSCount);

			w = ntohs(pnbnameheader->OpcodeFlagsRcode);

			memcpy(&Wcode, &w, sizeof(w) );

			RCode = Wcode.RCode;

			OPCode = Wcode.OpCode;

			fResponse = Wcode.fResponse;
			fBroadcast = Wcode.fNM_B;
			fRecursionAvailable = Wcode.fNM_RA;
			fRecursionDesired = Wcode.fNM_RD;
			fTruncated = Wcode.fNM_TC;
			fAuthoratativeAnswer = Wcode.fNM_AA;

			ptr = (const BYTE *)(pnbnameheader+1);

	if(RCode != 0)
	{
		printf("RCode: ");

		switch (RCode)
		{
		case RCODE_FMTERR:
			printf("Format Error: Request was invalidly formatted");
			break;
		case RCODE_SRVERR:
			printf("Server Failure: Problem with NBNS, cannot process name");
			break;
		case RCODE_NAMERR:
			printf("Name Error: The name requested does not exist.");
			break;
		case RCODE_IMPERR:
			printf("Unsupported Request Error");
			break;
		case RCODE_RFSERR:
			printf("Refused Error.  For policy reasons server will not register this name from this host.");
			break;
		case RCODE_ACTERR:
			printf("Active Error.  Name is owned by another node.");
			break;
		case RCODE_CFTERR:
			printf("Name in Conflict Error.  A UNIQUE name is owned by more than one node.");
			break;
		default:
			printf("Unknown RCODE! 0x%04x", RCode);
			break;
		}

		puts("");
	}


	printf("OPCode: ");
	switch (OPCode)
	{
	case OPCODE_QUERY:
		printf("QUERY");
		break;
	case OPCODE_REGISTRATION:
		printf("REGISTRATION");
		break;
	case OPCODE_RELEASE:
		printf("RELEASE");
		break;
	case OPCODE_WACK:
		printf("WACK");
		break;
	case OPCODE_REFRESH:
		printf("REFRESH");
		break;
	default:
		printf("Unknown OPCODE! 0x%04x", OPCode);
		break;
	}
	puts("");

	printf("Flags: ");
	if (fResponse)
		printf("Response ");

	if (fBroadcast)
		printf("Broadcast ");

	if (fRecursionAvailable)
		printf("RecursionAvailable ");

	if (fRecursionDesired)
		printf("RecursionDesired ");

	if (fTruncated)
		printf("Truncated ");

	if (fAuthoratativeAnswer)
		printf("AuthoratativeAnswer ");

	puts("");

	// all packets I've seen have no more than 1 of any type of record
	if (QDCount > 1 || ANCount > 1 || NSCount > 1 || ARCount > 1)
	{
		puts("[Invalid record count, aborting]");
		return 0;
	}

	for (w = 0; w < QDCount; w++)
	{
		printf("Question[%d]:\n", w);

		if (packetsize - (int)((char *)ptr - buff) < sizeof(QUESTION))
		{
			puts("[Short packet, aborting]");
			return 0;
		}

		PQUESTION pquestion = (PQUESTION)ptr;

		d = NetbiosNameToString(NameBuff, pquestion->Name, packetsize - ((char *)ptr - buff));

		ptr += sizeof(QUESTION);

		PrintNetbiosName((BYTE *)NameBuff);
		puts("");

		switch (ntohs(pquestion->Type))
		{
		case QUESTION_TYPE_NB:
			printf("General name request");
			break;
		case QUESTION_TYPE_NBSTAT:
			printf("Netbios Stats request");
			break;
		default:
			printf("Unknown query type:0x%04x", ntohs(pquestion->Type) );
			break;
		}

		puts("");

		if (ntohs(pquestion->Class) != QUESTION_CLASS_IN )
			printf("Class != TYPE INTERNET!\n");

		if (g_Reverse && !fResponse && ntohs(pquestion->Type) == QUESTION_TYPE_NBSTAT)
		{
			BYTE outbuff[1024];

			d = FormNBSTATPacket(outbuff);

			//SendPacket(sock, (const char *)outbuff, d, psockaddr);

			//printf(" **** NBSTAT QUERY packet sent to %s\n", inet_ntoa(psockaddr->sin_addr));
		}


		if (g_RespondName != NULL && !fResponse && OPCode == OPCODE_QUERY && ntohs(pquestion->Type) == QUESTION_TYPE_NB)
		{
			BYTE outbuff[1024];
			BOOL DoResponce = FALSE;
			char RespNameBuff[16];
			DWORD RespondIP = g_RespondIP;

			ParamToNetbiosName(RespNameBuff, g_RespondName);

			if ( strcmp(g_RespondName, "*") == 0 || memcmp(RespNameBuff, NameBuff, 16) == 0)
				DoResponce = TRUE;
			/*else if (access(g_RespondName, 3) == 0)
			{
				FILE *InFile = fopen(g_RespondName, "rt");

				if (InFile == NULL)
					printf("Unable to open %s\n", g_RespondName);
				else
				{
					char InBuff[1024];

					while (DoResponce == FALSE && fgets(InBuff, 1024, InFile) != NULL)
					{
						char *p = strchr(InBuff, '\n');
						if (p) *p = 0;
						p = strchr(InBuff, '#');
						if (p) *p = 0;

						if (inet_addr(InBuff) != INADDR_NONE)
						{
							RespondIP = inet_addr(InBuff);
							p = strchr(InBuff, ' ');

							if (p == NULL) 
								p = InBuff + strlen(InBuff);
						} 
						else 
						{
							p = InBuff;
						}

						ParamToNetbiosName(RespNameBuff, p);

						if (memcmp(RespNameBuff, NameBuff, 16) == 0)
							DoResponce = TRUE;
					}

					fclose(InFile);
				}
			}*/


			/*if (DoResponce)
			{
				d = FormQueryResponsePacket(outbuff, pnbnameheader->TransactionID, NameBuff, RespondIP, ONT_BNODE );

				SendPacket(sock, (const char *)outbuff, d, psockaddr);

				struct in_addr tmpadr;

				tmpadr.s_addr = RespondIP;

				printf(" **** QUERY responded to with address %s\n", inet_ntoa(tmpadr));
				puts("");
			}*/		
		}

		if (g_AllowName != NULL || g_DenyName != NULL)
		{
			char AllowNameBuff[16];

			if (OPCode == OPCODE_REGISTRATION && ntohs(pquestion->Type) == QUESTION_TYPE_NB)
			{
				BOOL DoDeny = FALSE;

				if (g_DenyName != NULL)
				{
					DoDeny = TRUE;

					ParamToNetbiosName(AllowNameBuff, g_DenyName);

					if (strcmp(g_DenyName, "*") == 0 || memcmp(AllowNameBuff, NameBuff, 16) == 0)
						DoDeny = FALSE;
					/*else if (access(g_DenyName, 4) == 0)
					{
						FILE *InFile = fopen(g_DenyName, "rt");
						char namecheckbuff[1024];

						if (InFile == NULL)
						{
							printf(" **** Unable to open %s\n", g_DenyName);
							DoDeny = FALSE;
						}
						else
						{
							while (DoDeny == TRUE && fgets(namecheckbuff, 1024, InFile) != NULL)
							{
								char *p = strchr(namecheckbuff, '\n');
								if (p) *p = 0;

								ParamToNetbiosName(AllowNameBuff, namecheckbuff);

								if (memcmp(AllowNameBuff, NameBuff, 16) == 0)
									DoDeny = FALSE;
							}

							fclose(InFile);
						}
					}*/


				}

				if (g_AllowName != NULL)
				{
					DoDeny = FALSE;

					ParamToNetbiosName(AllowNameBuff, g_AllowName);

					if (memcmp(NameBuff, AllowNameBuff, 16) == 0)
						DoDeny = TRUE;
					/*else if (access(g_AllowName, 4) == 0)
					{
						FILE *InFile = fopen(g_AllowName, "rt");
						char namecheckbuff[1024];

						if (InFile == NULL)
							printf(" **** Unable to open %s\n", g_AllowName);
						else
						{
							while (DoDeny == FALSE && fgets(namecheckbuff, 1024, InFile) != NULL)
							{
								char *p = strchr(namecheckbuff, '\n');
								if (p) *p = 0;

								ParamToNetbiosName(AllowNameBuff, namecheckbuff);

								if (memcmp(AllowNameBuff, NameBuff, 16) == 0)
									DoDeny = TRUE;
							}

							fclose(InFile);
						}
					}*/
				}

				BYTE outbuff[1024];
				WORD Rcode;

				if (fRecursionDesired)
					Rcode = RCODE_CFTERR;
				else
					Rcode = RCODE_ACTERR;
					
				d = FormNegativeQueryResponsePacket(outbuff, pnbnameheader->TransactionID, NameBuff, Rcode, MAKELONG(rand(), rand()), ONT_BNODE);

				//SendPacket(sock, (const char *)outbuff, d, psockaddr );

				printf(" **** DENY packet sent\n");

			}
		}
	}

	for (w = 0; w < ANCount; w++)
	{
		printf("Answer[%d]:\n", w);

		d = ProcessResourceRecord(pnbnameheader, ptr, 1, 0,0/*sock, psockaddr*/, packetsize - ((char *)ptr - buff));

		if (d == 0) return 0;

		ptr+=d;
	}

	for (w = 0; w < NSCount; w++)
	{
		printf("Authority record[%d]:\n", w);

		//d = ProcessResourceRecord(pnbnameheader, ptr, 2, sock, psockaddr, packetsize - ((char *)ptr - buff));

		if (d == 0) return 0;

		ptr+=d;
	}

	for (w = 0; w < ARCount; w++)
	{
		printf("Additional record[%d]:\n", w);

		//d = ProcessResourceRecord(pnbnameheader, ptr, 3, sock, psockaddr, packetsize - ((char *)ptr - buff));

		if (d == 0) return 0;

		ptr+=d;
	}


		  return 4;
  }   }}}}

  if(0x0608==(*(WORD*)(pktBuf+12)))//ETHTYPE_ARP
  {	  if(Cmp6Byte(pktBuf,&plg->crntAdptrMAC.b[0]))
	  {	wsprintf(s,L"%d.%d.%d.%d",pktBuf[28],pktBuf[29],pktBuf[30],pktBuf[31]);
		Ip4Shufl(destIP, (BYTE*)&pktBuf[28]);
		memcpy(destMAC,&pktBuf[6],6);
		*(destMAC+3)=pktBuf[9];*(destMAC+4)=pktBuf[10];*(destMAC+5)=pktBuf[11];
		return 1;//ARP sended;
  }	  }
  else if(0x0008==(*(WORD*)(pktBuf+12)))//ETHTYPE_IPV4
  {	  if(Cmp6Byte(pktBuf+6,&plg->crntAdptrMAC.b[0]))
	  {
		return 0;
  }	  }
  return 0;
}

}//extern "C"