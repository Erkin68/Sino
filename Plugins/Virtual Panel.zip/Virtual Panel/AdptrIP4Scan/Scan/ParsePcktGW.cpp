//#include "windows.h"

#pragma warning(disable:4005)
#pragma warning(disable:4995)
#pragma warning(disable:4996)

/*#include "..\libnetutil\IPv4Header.h"
#include "..\libnetutil\IPv6Header.h"
#include "..\libnetutil\TCPHeader.h"
#include "..\libnetutil\UDPHeader.h"
#include "..\libnetutil\ICMPv4Header.h"
#include "..\libnetutil\ICMPv6Header.h"
#include "..\libnetutil\EthernetHeader.h"
#include "..\libnetutil\DestOptsHeader.h"
#include "..\libnetutil\FragmentHeader.h"
#include "..\libnetutil\RoutingHeader.h"
#include "..\libnetutil\ARPHeader.h"
#include "..\libnetutil\ICMPv6Option.h"*/
#include "..\Plugins_C.h"


#define LINK_LAYER         2
#define NETWORK_LAYER      3
#define TRANSPORT_LAYER    4
#define APPLICATION_LAYER  5
#define EXTHEADERS_LAYER   6

#define MAX_HEADERS_IN_PACKET 32

typedef struct packet_type
{	u32 type;
    u32 length;
    u8 *buf;
}pkt_type_t; 
static pkt_type_t this_packet[MAX_HEADERS_IN_PACKET+1];

extern "C"
{

//fast code: scanning occured via gateway;
/*pkt_type_t* FastParsePacketGW(const u8 *pkt,int pktlen,int *totalPackets,bool eth_included)
{
u8 current_header=0;             // Current array position of "this_packet" 
const u8 *curr_pkt=pkt;          // Pointer to current part of the packet   
size_t curr_pktlen=pktlen;       // Remaining packet length                 
int ethlen=0, arplen=0;          // Aux length variables: link layer        
int iplen=0,ip6len=0;            // Aux length variables: network layer     
int tcplen=0,udplen=0,icmplen=0; // Aux length variables: transport layer   
int exthdrlen=0;                 // Aux length variables: extension headers 
int next_layer=0;                // Next header type to process             
int expected=0;                  // Next protocol expected                  
bool finished=false;             // Loop breaking flag                      
bool unknown_hdr=false;          // Indicates unknown header found          
IPv4Header *ip4;
IPv6Header *ip6;
TCPHeader *tcp;
UDPHeader *udp;
ICMPv4Header *icmp4;
ICMPv6Header *icmp6;
EthernetHeader *eth;
DestOptsHeader *ext_dopts;
FragmentHeader *ext_frag;
HopByHopHeader *ext_hopt;
RoutingHeader *ext_routing;
ARPHeader *arp;

  //memset(this_packet, 0, sizeof(this_packet));
  *totalPackets = 0;

  // Decide which layer we have to start from
  if(eth_included)
  { next_layer=LINK_LAYER;
    expected=HEADER_TYPE_ETHERNET;
  }else
    next_layer=NETWORK_LAYER;

  // Header processing loop 
  while(!finished && curr_pktlen>0 && current_header<MAX_HEADERS_IN_PACKET)
  {	// Ethernet and ARP headers **********************************************
    if(next_layer==LINK_LAYER)
	{	if(expected==HEADER_TYPE_ETHERNET)
		{	if(curr_pkt==NULL || curr_pktlen<ETH_HEADER_LEN)//eth.storeRecvData(curr_pkt, curr_pktlen)==OP_FAILURE)
			{	unknown_hdr=true;
                break;
            }
			eth = (EthernetHeader*)curr_pkt;
            //if((ethlen=eth->validate())==OP_FAILURE)
			//{	unknown_hdr=true;
            //    break;
            //}
            // Determine next header type
            switch(eth->getEtherType())
			{	case ETHTYPE_IPV4:
                    expected=HEADER_TYPE_IPv4;
                    next_layer=NETWORK_LAYER;
                break;
                case ETHTYPE_IPV6:
                    expected=HEADER_TYPE_IPv6;
                    next_layer=NETWORK_LAYER;
                break;
                case ETHTYPE_ARP:
                    next_layer=LINK_LAYER;
                    expected=HEADER_TYPE_ARP;
                break;
                default:
                    next_layer=APPLICATION_LAYER;
                    expected=HEADER_TYPE_RAW_DATA;
                break;
            }
            this_packet[current_header].length=ethlen;
            this_packet[current_header].buf=(u8*)curr_pkt;
            this_packet[current_header++].type=HEADER_TYPE_ETHERNET;
            //eth.reset();
            curr_pkt+=ethlen;
            curr_pktlen-=ethlen;
			++(*totalPackets);
        }
		else if(expected==HEADER_TYPE_ARP)
		{	if(curr_pkt==NULL || curr_pktlen<ARP_HEADER_LEN)//arp.storeRecvData(curr_pkt, curr_pktlen)==OP_FAILURE)
			{	unknown_hdr=true;
                break;
            }
			arp = (ARPHeader*)curr_pkt;
            //if((arplen=arp->validate())==OP_FAILURE)
			//{	unknown_hdr=true;
            //    break;
            //}
            this_packet[current_header].length=arplen;
            this_packet[current_header].buf=(u8*)curr_pkt;
            this_packet[current_header++].type=HEADER_TYPE_ARP;
            //arp.reset();
            curr_pkt+=arplen;
            curr_pktlen-=arplen;
			++(*totalPackets);
            if(curr_pktlen>0)
			{	next_layer=APPLICATION_LAYER;
                expected=HEADER_TYPE_RAW_DATA;
            }else
				finished=true;
        }
		else
			return NULL;//assert(finished==true);
    }
    // IPv4 and IPv6 headers *************************************************
	else if(next_layer==NETWORK_LAYER)
	{	// Determine IP version
        if(curr_pkt==NULL || curr_pktlen<IP_HEADER_LEN)//ip4.storeRecvData(curr_pkt, curr_pktlen)==OP_FAILURE)
		{   unknown_hdr=true;
            break;
        }
		ip4 = (IPv4Header*)curr_pkt;
        // IP version 4 ---------------------------------
        if(ip4->getVersion()==4)
		{	///if((iplen=ip4->validate())==OP_FAILURE)
			//{	unknown_hdr=true;
            //    break;
            //}
            // Determine next header type
            switch(ip4->getNextProto())
			{	case HEADER_TYPE_ICMPv4:
                    next_layer=TRANSPORT_LAYER;
                    expected=HEADER_TYPE_ICMPv4;
                break;
                case HEADER_TYPE_IPv4: // IP in IP
                    next_layer=NETWORK_LAYER;
                    expected=HEADER_TYPE_IPv4;
                break;
                case HEADER_TYPE_TCP:
                    next_layer=TRANSPORT_LAYER;
                    expected=HEADER_TYPE_TCP;
                break;
                case HEADER_TYPE_UDP:
                    next_layer=TRANSPORT_LAYER;
                    expected=HEADER_TYPE_UDP;
                break;
                case HEADER_TYPE_IPv6: // IPv6 in IPv4
                    next_layer=NETWORK_LAYER;
                    expected=HEADER_TYPE_IPv6;
                break;
                default:
                    next_layer=APPLICATION_LAYER;
                    expected=HEADER_TYPE_RAW_DATA;
                break;
            }
            this_packet[current_header].length=iplen;
            this_packet[current_header].buf=(u8*)curr_pkt;
            this_packet[current_header++].type=HEADER_TYPE_IPv4;
            //ip4.reset();
            curr_pkt+=iplen;
            curr_pktlen-=iplen;
			++(*totalPackets);
        }
        // IP version 6 ---------------------------------
		else if(ip4->getVersion()==6)
		{	//ip4.reset();
            if(curr_pkt==NULL || curr_pktlen<IPv6_HEADER_LEN)//ip6.storeRecvData(curr_pkt, curr_pktlen)==OP_FAILURE)
			{	unknown_hdr=true;
                break;
            }
			ip6 = (IPv6Header*)curr_pkt; 
            //if((ip6len=ip6->validate())==OP_FAILURE)
			//{	unknown_hdr=true;
            //    break;
            //}
            switch(ip6->getNextHeader())
			{	case HEADER_TYPE_ICMPv6:
                    next_layer=TRANSPORT_LAYER;
                    expected=HEADER_TYPE_ICMPv6;
                break;
                case HEADER_TYPE_IPv4: // IPv4 in IPv6
                    next_layer=NETWORK_LAYER;
                    expected=HEADER_TYPE_IPv4;
                break;
                case HEADER_TYPE_TCP:
                    next_layer=TRANSPORT_LAYER;
                    expected=HEADER_TYPE_TCP;
                break;
                case HEADER_TYPE_UDP:
                    next_layer=TRANSPORT_LAYER;
                    expected=HEADER_TYPE_UDP;
                break;
                case HEADER_TYPE_IPv6: // IPv6 in IPv6
                    next_layer=NETWORK_LAYER;
                    expected=HEADER_TYPE_IPv6;
                break;
                case HEADER_TYPE_IPv6_HOPOPT:
                    next_layer=EXTHEADERS_LAYER;
                    expected=HEADER_TYPE_IPv6_HOPOPT;
                break;
                case HEADER_TYPE_IPv6_OPTS:
                    next_layer=EXTHEADERS_LAYER;
                    expected=HEADER_TYPE_IPv6_OPTS;
                break;
                case HEADER_TYPE_IPv6_ROUTE:
                    next_layer=EXTHEADERS_LAYER;
                    expected=HEADER_TYPE_IPv6_ROUTE;
                break;
                case HEADER_TYPE_IPv6_FRAG:
                    next_layer=EXTHEADERS_LAYER;
                    expected=HEADER_TYPE_IPv6_FRAG;
                break;
                default:
                    next_layer=APPLICATION_LAYER;
                    expected=HEADER_TYPE_RAW_DATA;
                break;
            }
            this_packet[current_header].length=ip6len;
            this_packet[current_header].buf=(u8*)curr_pkt;
            this_packet[current_header++].type=HEADER_TYPE_IPv6;
            //ip6.reset();
            curr_pkt+=ip6len;
            curr_pktlen-=ip6len;
			++(*totalPackets);
        // Bogus IP version -----------------------------
        }
		else
		{	// Wrong IP version, treat as raw data.
            next_layer=APPLICATION_LAYER;
            expected=HEADER_TYPE_RAW_DATA;
	}	}
    // TCP, UDP, ICMPv4 and ICMPv6 headers ************************************
	else if(next_layer==TRANSPORT_LAYER)
	{	if(expected==HEADER_TYPE_TCP)
		{	if(curr_pkt==NULL || curr_pktlen<TCP_HEADER_LEN)//tcp.storeRecvData(curr_pkt, curr_pktlen)==OP_FAILURE)
			{	unknown_hdr=true;
                break;
            }
			tcp = (TCPHeader*)curr_pkt;
            //if((tcplen=tcp->validate())==OP_FAILURE)
			//{	unknown_hdr=true;
            //    break;
            //}
            expected=HEADER_TYPE_RAW_DATA;
            this_packet[current_header].length=tcplen;
            this_packet[current_header].buf=(u8*)curr_pkt;
            this_packet[current_header++].type=HEADER_TYPE_TCP;
            //tcp.reset();
            curr_pkt+=tcplen;
            curr_pktlen-=tcplen;
			++(*totalPackets);
            next_layer=APPLICATION_LAYER;
        }
		else if(expected==HEADER_TYPE_UDP)
		{	if(curr_pkt==NULL || curr_pktlen<UDP_HEADER_LEN)//udp.storeRecvData(curr_pkt, curr_pktlen)==OP_FAILURE)
			{	unknown_hdr=true;
                break;
            }
			udp = (UDPHeader*)curr_pkt;
            //if((udplen=udp->validate())==OP_FAILURE)
			//{	unknown_hdr=true;
            //    break;
            //}
            expected=HEADER_TYPE_RAW_DATA;
            this_packet[current_header].length=udplen;
            this_packet[current_header].buf=(u8*)curr_pkt;
            this_packet[current_header++].type=HEADER_TYPE_UDP;
            //udp.reset();
            curr_pkt+=udplen;
            curr_pktlen-=udplen;
			++(*totalPackets);
            next_layer=APPLICATION_LAYER;
        }
		else if(expected==HEADER_TYPE_ICMPv4)
		{	if(curr_pkt==NULL || curr_pktlen<ICMP_STD_HEADER_LEN)//icmp4.storeRecvData(curr_pkt, curr_pktlen)==OP_FAILURE)
			{	unknown_hdr=true;
                break;
            }
			icmp4 = (ICMPv4Header*)curr_pkt;
            //if((icmplen=icmp4->validate())==OP_FAILURE)
			//{	unknown_hdr=true;
            //    break;
            //}
            switch(icmp4->getType())
			{	// Types that include an IPv4 packet as payload
                case ICMP_UNREACH:
                case ICMP_TIMXCEED:
                case ICMP_PARAMPROB:
                case ICMP_SOURCEQUENCH:
                case ICMP_REDIRECT:
                    next_layer=NETWORK_LAYER;
                    expected=HEADER_TYPE_IPv4;
                break;
                // ICMP types that include misc payloads (or no payload)
                default:
                    expected=HEADER_TYPE_RAW_DATA;
                    next_layer=APPLICATION_LAYER;
                break;
            }
            this_packet[current_header].length=icmplen;
            this_packet[current_header].buf=(u8*)curr_pkt;
            this_packet[current_header++].type=HEADER_TYPE_ICMPv4;
            //icmp4.reset();
            curr_pkt+=icmplen;
            curr_pktlen-=icmplen;
			++(*totalPackets);
        }
		else if(expected==HEADER_TYPE_ICMPv6)
		{	if(curr_pkt==NULL || curr_pktlen<ICMPv6_MIN_HEADER_LEN)//icmp6.storeRecvData(curr_pkt, curr_pktlen)==OP_FAILURE)
			{	unknown_hdr=true;
                break;
            }
			icmp6 = (ICMPv6Header*)curr_pkt;
            //if((icmplen=icmp6->validate())==OP_FAILURE)
			//{	unknown_hdr=true;
            //    break;
            //}
            switch(icmp6->getType())
			{	// Types that include an IPv6 packet as payload
                case ICMPv6_UNREACH:
                case ICMPv6_PKTTOOBIG:
                case ICMPv6_TIMXCEED:
                case ICMPv6_PARAMPROB:
                    next_layer=NETWORK_LAYER;
                    expected=HEADER_TYPE_IPv6;
                break;
                // ICMPv6 types that include misc payloads (or no payload)
                default:
                    expected=HEADER_TYPE_RAW_DATA;
                    next_layer=APPLICATION_LAYER;
                break;
            }
            this_packet[current_header].length=icmplen;
            this_packet[current_header].buf=(u8*)curr_pkt;
            this_packet[current_header++].type=HEADER_TYPE_ICMPv6;
            //icmp6.reset();
            curr_pkt+=icmplen;
            curr_pktlen-=icmplen;
			++(*totalPackets);
        }
		else
		{	// Wrong application layer protocol, treat as raw data.
            next_layer=APPLICATION_LAYER;
            expected=HEADER_TYPE_RAW_DATA;
    }   }
	// IPv6 Extension Headers
	else if(next_layer==EXTHEADERS_LAYER)
	{	u8 ext_next=0;
        // Hop-by-Hop Options
        if(expected==HEADER_TYPE_IPv6_HOPOPT)
		{	if(curr_pkt==NULL || curr_pktlen<HOPBYHOP_MIN_HEADER_LEN)//ext_hopt.storeRecvData(curr_pkt, curr_pktlen)==OP_FAILURE)
			{	unknown_hdr=true;
                break;
            }
			ext_hopt= (HopByHopHeader*)curr_pkt;
            //if((exthdrlen=ext_hopt->validate())==OP_FAILURE)
			//{	unknown_hdr=true;
            //    break;
            //}
            ext_next=ext_hopt->getNextHeader();
            //ext_hopt.reset();
        }
		// Routing Header
        else if(expected==HEADER_TYPE_IPv6_ROUTE)
		{	if(curr_pkt==NULL || curr_pktlen<ROUTING_HEADER_MIN_LEN)//ext_routing.storeRecvData(curr_pkt, curr_pktlen)==OP_FAILURE)
			{	unknown_hdr=true;
                break;
            }
			ext_routing = (RoutingHeader*)curr_pkt;
            //if((exthdrlen=ext_routing->validate())==OP_FAILURE)
			//{	unknown_hdr=true;
            //    break;
            //}
            ext_next=ext_routing->getNextHeader();
            ext_routing->reset();
        }
		// Fragmentation Header
		else if(expected==HEADER_TYPE_IPv6_FRAG)
		{	if(curr_pkt==NULL || curr_pktlen<FRAGMENT_HEADER_LEN)//ext_frag.storeRecvData(curr_pkt, curr_pktlen)==OP_FAILURE)
			{	unknown_hdr=true;
                break;
            }
			ext_frag = (FragmentHeader*)curr_pkt;
            //if((exthdrlen=ext_frag->validate())==OP_FAILURE)
			//{	unknown_hdr=true;
            //    break;
            //}
            ext_next=ext_frag->getNextHeader();
            //ext_frag.reset();
        }
        // Destination Options Header
		else if(expected==HEADER_TYPE_IPv6_OPTS)
		{	if(curr_pkt==NULL || curr_pktlen<ICMPv6_OPTION_MIN_HEADER_LEN)//ext_dopts.storeRecvData(curr_pkt, curr_pktlen)==OP_FAILURE)
			{	unknown_hdr=true;
                break;
            }
			ext_dopts = (DestOptsHeader*)curr_pkt;
            //if((exthdrlen=ext_dopts->validate())==OP_FAILURE)
			//{	unknown_hdr=true;
            //    break;
            //}
            ext_next=ext_dopts->getNextHeader();
            //ext_dopts.reset();
        }
		else
		{	// Should never happen.
            unknown_hdr=true;
            break;
        }

        // Update the info for this header
        this_packet[current_header].length=exthdrlen;
        this_packet[current_header].buf=(u8*)curr_pkt;
        this_packet[current_header++].type=expected;
        curr_pkt+=exthdrlen;
        curr_pktlen-=exthdrlen;
		++(*totalPackets);

        // Lets's see what comes next
        switch(ext_next)
		{	case HEADER_TYPE_ICMPv6:
                next_layer=TRANSPORT_LAYER;
                expected=HEADER_TYPE_ICMPv6;
            break;
            case HEADER_TYPE_IPv4: // IPv4 in IPv6
                next_layer=NETWORK_LAYER;
                expected=HEADER_TYPE_IPv4;
            break;
            case HEADER_TYPE_TCP:
                next_layer=TRANSPORT_LAYER;
                expected=HEADER_TYPE_TCP;
            break;
            case HEADER_TYPE_UDP:
                next_layer=TRANSPORT_LAYER;
                expected=HEADER_TYPE_UDP;
            break;
            case HEADER_TYPE_IPv6: // IPv6 in IPv6
                next_layer=NETWORK_LAYER;
                expected=HEADER_TYPE_IPv6;
            break;
            case HEADER_TYPE_IPv6_HOPOPT:
                next_layer=EXTHEADERS_LAYER;
                expected=HEADER_TYPE_IPv6_HOPOPT;
            break;
            case HEADER_TYPE_IPv6_OPTS:
                next_layer=EXTHEADERS_LAYER;
                expected=HEADER_TYPE_IPv6_OPTS;
            break;
            case HEADER_TYPE_IPv6_ROUTE:
                next_layer=EXTHEADERS_LAYER;
                expected=HEADER_TYPE_IPv6_ROUTE;
            break;
            case HEADER_TYPE_IPv6_FRAG:
                next_layer=EXTHEADERS_LAYER;
                expected=HEADER_TYPE_IPv6_FRAG;
            break;
            default:
                next_layer=APPLICATION_LAYER;
                expected=HEADER_TYPE_RAW_DATA;
            break;
	}	}
    // Miscellaneous payloads *************************************************
	else
	{ // next_layer==APPLICATION_LAYER
        if(curr_pktlen>0)
		{	//if(expected==HEADER_TYPE_DNS){
            //}else if(expected==HEADER_TYPE_HTTP){
            //}... ETC
            this_packet[current_header].length=curr_pktlen;
            this_packet[current_header].buf=(u8*)curr_pkt;
            this_packet[current_header++].type=HEADER_TYPE_RAW_DATA;
            curr_pktlen=0;
        }
        finished=true;
  } } // End of header processing loop

  // If we couldn't validate some header, treat that header and any remaining
  // data, as raw application data.
  if(unknown_hdr==true)
  {	if(curr_pktlen>0)
	{	this_packet[current_header].length=curr_pktlen;
        this_packet[current_header].buf=(u8*)curr_pkt;
        this_packet[current_header++].type=HEADER_TYPE_RAW_DATA;
  } }

  return this_packet;
} // End of parse_received_packet()*/

int ProcessRecvPacketGW(const u8 *pktBuf,int pktlen,int *totalPackets,PluginObj *plg,wchar_t *s)
{
  //1.O'zimiz yuborayotgan paketlarni chiqaramiz:
  DWORD *pdw=(DWORD*)(pktBuf+6);
  DWORD *pdw1=(DWORD*)(&plg->crntAdptrMAC.b[0]);
  DWORD *pdw2=(DWORD*)(&plg->crntAdptrGWMAC.b[0]);
  WORD *pw=(WORD*)(pktBuf+10);
  WORD *pw1=(WORD*)(&plg->crntAdptrMAC.b[4]);
  WORD *pw2=(WORD*)(&plg->crntAdptrGWMAC.b[4]);
  if((*pdw)==(*pdw1))
  if((*pw)==(*pw1))
	  return 0;//MAC ADRESS o'zimizniki b-n 1 xil;

  if(((*pdw)==(*pdw2)) && ((*pw)==(*pw2)))//Agar shlyuz GW dan kelgan bo'lsa:
  {	  pw = (WORD*)(pktBuf+12);//Packet ethernet type;
	  if(0x0008==(*pw))//ETHTYPE_IPV4
	  if(1==(*(pktBuf+23)))//IP4 protocol-->ICMP4
	  if(0x0000==(*(WORD*)(pktBuf+34)))//ECHO-REPLY
	  {	wsprintf(s,L"%d.%d.%d.%d",pktBuf[26],pktBuf[27],pktBuf[28],pktBuf[29]);
		return 3;//Hozircha;	
  }	  }

  pw = (WORD*)(pktBuf+12);//Packet ethernet type;
  if(0x0608==(*pw))//ETHTYPE_ARP
  {	  pdw=(DWORD*)pktBuf;
	  pw=(WORD*)(pktBuf+4);
	  if((*pdw)==(*pdw1))//Bizga kelganmi?
	  if((*pw)==(*pw1))
	  {	wsprintf(s,L"%d.%d.%d.%d",pktBuf[28],pktBuf[29],pktBuf[30],pktBuf[31]);
		return 1;//ARP sended;
  }	  }
  else if(0x0008==(*pw))//ETHTYPE_IPV4
  {	  pdw=(DWORD*)(pktBuf+6);
	  pw=(WORD*)(pktBuf+10);
	  if((*pdw)==(*pdw1))//Bizga kelganmi?
	  if((*pw)==(*pw1))
	  {
		return 0;
  }	  }
  return 0;
}

}//extern "C"