//#include "windows.h"
#pragma warning(disable:4005)
#pragma warning(disable:4996)

#include "..\Packet\Packet32.h"
#include "..\Plugins_C.h"
#include <ntddndis.h>
#include <commctrl.h>


DWORD WINAPI ScanWithoutGateThrdProc(LPVOID lpPar)
{
LPVOID recvThrdPar[8] = {0,0,0};//0-recvThrd,1-recvThrdId,2-bCancelThread,3-adptr,4-pkts,5-numpkts,6-iNumRecvdPckts;
LPADAPTER adptr;LPPACKET pcktArp,pcktUdp,pcktRecv[NUM_RECV_PCKTS];
PluginObj *plg = (PluginObj*)lpPar;
long n,N,iRecvdPkts=0,iPcktProced=0;BOOL bCancelRecvThrd=FALSE;
BYTE recvBuf[NUM_RECV_PCKTS][recvBufLen];DWORD nip,tmBgn,tmSnd;
BYTE arpMsg[ARPReqLen]={
	0xff,0xff,0xff,0xff,0xff,0xff,
	plg->crntAdptrMAC.b[0],plg->crntAdptrMAC.b[1],plg->crntAdptrMAC.b[2],plg->crntAdptrMAC.b[3],plg->crntAdptrMAC.b[4],plg->crntAdptrMAC.b[5],
	8,6,//ARP
	0,1,8,0,6,4,0,1,
	plg->crntAdptrMAC.b[0],plg->crntAdptrMAC.b[1],plg->crntAdptrMAC.b[2],plg->crntAdptrMAC.b[3],plg->crntAdptrMAC.b[4],plg->crntAdptrMAC.b[5],
	plg->myIP.b[0],plg->myIP.b[1],plg->myIP.b[2],plg->myIP.b[3],
	0,0,0,0,0,0,//dest MAC
	0,0,0,0,//dest IP 38
	0,0 }; //padding chars, strongly requeried
BYTE udpMsg[totUDPBufLen] = {
	0xff,0xff,0xff,0xff,0xff,0xff,
	plg->crntAdptrMAC.b[0],plg->crntAdptrMAC.b[1],plg->crntAdptrMAC.b[2],plg->crntAdptrMAC.b[3],plg->crntAdptrMAC.b[4],plg->crntAdptrMAC.b[5],
	8,0,//6-ARP,0-IPV4
	0x45,0,0,0x4e,0x34,0xb5,0,0,0x80,0x11,0,0,
	plg->myIP.b[0],plg->myIP.b[1],plg->myIP.b[2],plg->myIP.b[3],
	0,0,0,0,//dstIP
	0xd9,0x96,0,0x89,0,0x3a,0x8f,0xc1,
	0,6,0,0,0,1,0,0,0,0,0,0,0x20,0x43,0x4b,0x41,
	0x41,0x41,0x41,0x41,0x41,0x41,0x41,0x41,0x41,0x41,0x41,0x41,0x41,0x41,0x41,0x41,
	0x41,0x41,0x41,0x41,0x41,0x41,0x41,0x41,0x41,0x41,0x41,0x41,0x41,0,0,0x21,
	0,1					 };
WIN32_FIND_DATA fd={FILE_ATTRIBUTE_DIRECTORY};
BYTE dstMAC[6];
char s[MAX_PATH];
wchar_t sName[32];
wchar_t sDomain[32];
#ifdef _DEBUG
	OutputDebugStringA("\n");
	sprintf(s,"Adapter IP:          %d.%d.%d.%d",plg->myIP.b[0],plg->myIP.b[1],plg->myIP.b[2],plg->myIP.b[3]);
	OutputDebugStringA(s);
	OutputDebugStringA("\n");
	sprintf(s,"Adapter MAC:         %02x-%02x-%02x-%02x-%02x-%02x",
			plg->crntAdptrMAC.b[0],plg->crntAdptrMAC.b[1],plg->crntAdptrMAC.b[2],
			plg->crntAdptrMAC.b[3],plg->crntAdptrMAC.b[4],plg->crntAdptrMAC.b[5]);
	OutputDebugStringA(s);
	OutputDebugStringA("\n");
	sprintf(s,"Ping to from: %d.%d.%d.%d",
			plg->ipFrom.b[0],plg->ipFrom.b[1],plg->ipFrom.b[2],plg->ipFrom.b[3]);
	OutputDebugStringA(s);
	OutputDebugStringA("\n");
	sprintf(s,"Ping to from dw: %04x",plg->dwIPFrom);
	OutputDebugStringA(s);
#endif

	plg->state = scan;
	plg->TermScanThrd = 0;
			
	adptr = PacketOpenAdapter((PCHAR)plg->crntAdptrName);
	if(!adptr) return 0;

	PacketSetMyIP4(adptr, *((DWORD*)&plg->myIP.b[0]));
	PacketSetMyMAC(adptr, &plg->crntAdptrMAC.b[0]);
	PacketSetMyFilter(adptr, 3);//filter-setted,gateway - unrecognized;

	// set the network adapter in promiscuous mode	
	if(PacketSetHwFilter(adptr,NDIS_PACKET_TYPE_PROMISCUOUS)==FALSE)//NDIS_PACKET_TYPE_PROMISCUOUS
	{	//printf("Warning: unable to set promiscuous mode!\n");
	}

	/* Set hardware filter to directed mode */
	//if(PacketSetHwFilter(adptr,NDIS_PACKET_TYPE_DIRECTED)==FALSE)
	//{	//msgStatus ="Warning: unable to set directed mode..";SHOWSTAT(msgStatus);
	//}

	// set a 512K buffer in the driver
	if(PacketSetBuff(adptr,512000)==FALSE)
	{	//printf("Unable to set the kernel buffer!\n");
	}

	// set a 1 second read timeout
	if(!PacketSetReadTimeout(adptr,1500))
	{	//printf("Warning: unable to set the read tiemout!\n");
	}

	recvThrdPar[2] = &bCancelRecvThrd;
	recvThrdPar[3] = adptr;
	recvThrdPar[4] = &pcktRecv[0];
	recvThrdPar[5] = (LPVOID)NUM_RECV_PCKTS;
	recvThrdPar[6] = &iRecvdPkts;
	//recvThrdPar[7] = plg;
	for(n=0; n<NUM_RECV_PCKTS; ++n)
	{	pcktRecv[n] = PacketAllocatePacket();
		PacketInitPacket(pcktRecv[n],recvBuf[n],recvBufLen);
	}

	pcktUdp = PacketAllocatePacket();
	PacketInitPacket(pcktUdp,udpMsg,totUDPBufLen);

	pcktArp=PacketAllocatePacket();
	PacketInitPacket(pcktArp,arpMsg,ARPReqLen);

	plg->SendBitTable = HeapAlloc(GetProcessHeap(), HEAP_ZERO_MEMORY, plg->totSearchNodes);

	plg->RecvThrd = recvThrdPar[0] = (LPVOID)CreateThread(NULL,0,recvThrdRoutine,&recvThrdPar[0],0,(LPDWORD)&recvThrdPar[1]);
	if(!recvThrdPar[0])
	{	
		goto End;
	}

	plg->SendBitTable = HeapAlloc(GetProcessHeap(), HEAP_ZERO_MEMORY, plg->totSearchNodes);

	plg->RecvThrd = recvThrdPar[0] = (LPVOID)CreateThread(NULL,0,recvThrdRoutine,&recvThrdPar[0],0,(LPDWORD)&recvThrdPar[1]);
	if(!recvThrdPar[0])
	{	
		goto End;
	}SetThreadPriority(recvThrdPar[0],THREAD_PRIORITY_HIGHEST);
	Sleep(50);

	//addItemToPanelList(plg->host,L"..",NULL,&fd,0xffffffff,TRUE); SetVirtualda bor
	tmBgn = tmSnd = GetTickCount();

	//1.Tez topish kerak bo'lgan IPlarni qidirsun:
	for(N=conf.bUsePredefinedIPList?1:0; N<2; ++N)
	for(n=0; n<(N?plg->totSearchNodes:conf.iIPListCnt); ++n)
	{	if(N)
		{	nip = plg->dwIPFrom + n;
			if(plg->SendBitTable[n] > 0)
				continue;
		}
		else//tez spiska:
		{	Ip4Shufl(&nip,&conf.IPList[n].b[0]);
			if(nip<plg->dwIPFrom)continue;
			if(nip>plg->dwIPFrom+plg->totSearchNodes)continue;
		}

		if(plg->TermScanThrd>0)//1-Exit,2-Stop
			goto End1;
		if(nip==plg->dwMyIP)//1-Exit,2-Stop
			continue;

		//Agar 1ta shlyuzda bo'lsa,MAC-ffffffffffff b-shi kerak, aks holda shlyuz MAC b-shi kerak:
		if(GetTickCount()-tmSnd<(DWORD)conf.iSpeed)
			Sleep(conf.iSpeed);

		*((DWORD*)&arpMsg[38]) = Ip4AsDWORD((*((IP4BYTE*)&nip)));
		PacketSendPacket(adptr,pcktArp,TRUE);
		tmSnd = GetTickCount();

		plg->SendBitTable[n] = 1;

		while(iPcktProced<iRecvdPkts)
		{	long NN;long totalPackets,i = iPcktProced % NUM_RECV_PCKTS;
			int r=ProcessRecvPacketGW(&recvBuf[i][20],pcktRecv[i]->ulBytesReceived-20,
								      &totalPackets,plg,sName,sDomain,&nip,&dstMAC[0]);
			NN = nip-plg->dwIPFrom;
			if(NN>-1)
			if(NN<plg->totSearchNodes)
			switch(r)
			{	case 1://ARP echo 
				case 3://ICMPReply
					if(0==plg->iScanMethod[0])//WINS
					{	*((DWORD*)&udpMsg[30]) = Ip4AsDWORD((*((IP4BYTE*)&nip)));
						memcpy(udpMsg,dstMAC,6);
						ip_checksum(&udpMsg[EHTHdrLen],20);
						*((WORD*)(&udpMsg[40])) = 0x0000;
						udp_checksum(&udpMsg[EHTHdrLen],UDPBufLen);//+50);//crc ne bylo raschitano
						if(GetTickCount()-tmSnd<(DWORD)conf.iSpeed)
							Sleep(conf.iSpeed);
						PacketSendPacket(adptr,pcktUdp,TRUE);
						tmSnd = GetTickCount();
						plg->SendBitTable[NN] = 2;
					}
					else plg->SendBitTable[NN] = 3;
					addNodeToPlgList(plg,NULL,NULL,&fd,nip);
					break;
				case 4://UDP-137 dan kelgan:
					addNodeToPlgList(plg,sName,sDomain,&fd,nip);
					plg->SendBitTable[NN] = 4;
					break;
			}
			++iPcktProced;
		}
		//4 ta oldingisidan xabar kelmagan bo'lsa:
		/*if(n>4)
		{	if(2==plg->SendBitTable[n-4])//WINS zapros yuborilgan, lekin kelmagan;
			{	nip = plg->dwIPFrom + n-4;
				wsprintf(s,L"%d.%d.%d.%d",nip >> 24, (nip >> 16) & 0xff, (nip >> 8) & 0xff, nip  & 0xff);
				addItemToPanelList(plg->host,s,NULL,&fd,0xffffffff,TRUE);
		}	}*/
		//if(0==n%2)Sleep(2);else
		if(1==n%100)
		{	wsprintf((wchar_t*)s,strngs[91],(GetTickCount()-tmBgn)/1000);//L"Scanning... %d sec. posted."
			SetWindowTextW(plg->tlbrEditState,(wchar_t*)s);
			SendMessage(plg->tlbrPrgrs,PBM_SETPOS,100*n/plg->totSearchNodes,0);
	}	}

End1:
	bCancelRecvThrd = TRUE;
	if(WAIT_OBJECT_0!=WaitForSingleObject((HANDLE)recvThrdPar[0],5000))
		TerminateThread((HANDLE)recvThrdPar[0],0);
End:
	PacketFreePacket(pcktUdp);
	PacketFreePacket(pcktArp);
	for(n=0; n<NUM_RECV_PCKTS; ++n)
		PacketFreePacket(pcktRecv[n]);
	PacketCloseAdapter(adptr);
	HeapFree(GetProcessHeap(),0,plg->SendBitTable);
	plg->SendBitTable = NULL;
	plg->ScanThrd = NULL;
	plg->state = end_scan;
	SendMessage(plg->tlbrEditState,WM_SETTEXT,0,(LPARAM)L"");//SetWindowText(plg->tlbrEditState,L"");tormozit !!!!!!!
	SendMessage(plg->tlbrPrgrs, PBM_SETPOS, 0, 0);//tormozit !!!!!!!
	SendMessage(plg->tlbrBtnStop,WM_SETTEXT,0,(LPARAM)strngs[11]);//SetWindowText(plg->tlbrBtnStop,L"Start"); tormozit !!!!!!!
	return 0;
}

/*BYTE ARPPckt[50] = { 0xff,0xff,0xff,0xff,0xff,0xff,//Ethernet-kadr,shirokoveshatelniy;
					 0,0,0,0,0,0,					// Ethernet-kadr,Nash fizicheskiy address,pust 0 budet;
					 8,6,							// Ethernet-kadr,Tip sredy,po RFC Ethernet tip;
					 0,1,							// ARP-kadr,tip kanala svyazi;
					 8,0,							// ARP-kadr,tip protokola;
					 6,								// ARP-kadr,dlina fizicheskogo adresa,dlya ethe-6;
					 4,								// ARP-kadr,dlina IP-adresa,maks 4;
					 0,1,							// ARP-kadr,tip ARP paketa,po RFC;
					 0,0,0,0,0,0,					// ARP-kadr,nash fizich address;
					 0,0,0,0,						// 28,29,30,31-ARP-kadr,nash IP-address;
					 0xff,0xff,0xff,0xff,0xff,0xff, // ARP-kadr,fiz addr poluchatelya;
					 0,0,0,0};						// 38,39,40,41-ARP-kadr,IP-address poluchatelya;

int BuildARPPacket(	PArpPacket ArpPacket, unsigned char *dst_etheraddr,
					unsigned char *src_etheraddr, int ar_op, unsigned char *ar_sha, 
					unsigned char *ar_sip, unsigned char *ar_tha,
					unsigned char *ar_tip,unsigned short int ar_hw)
{
	memcpy(&(ArpPacket->eth.eth_dst), dst_etheraddr, ETH_ADD_LEN);
	memcpy(&(ArpPacket->eth.eth_src), src_etheraddr, ETH_ADD_LEN);
	ArpPacket->eth.eth_type = htons(ETH_TYPE_ARP);
	ArpPacket->arp.arp_hdr = htons(ar_hw);
	ArpPacket->arp.arp_pro = htons(ARP_PRO_IP);
	ArpPacket->arp.arp_hln = ARP_ETH_ADD_SPACE;
	ArpPacket->arp.arp_pln = ARP_IP_ADD_SPACE;
	ArpPacket->arp.arp_opt = htons(ar_op);
	memcpy(&(ArpPacket->arp.arp_sha), ar_sha, ARP_ETH_ADD_SPACE);
	memcpy(&(ArpPacket->arp.arp_spa), ar_sip, ARP_IP_ADD_SPACE);
	memcpy(&(ArpPacket->arp.arp_tha), ar_tha, ARP_ETH_ADD_SPACE);
	memcpy(&(ArpPacket->arp.arp_tpa), ar_tip, ARP_IP_ADD_SPACE);
	memset(ArpPacket->eth_pad, 32, ETH_PADDING_ARP);
	return(EXIT_SUCCESS);
}

void GetLocalMAC(LPADAPTER lpAdapter, unsigned char *ether_addr)
{ 
	ULONG IoCtlBufferLength = (sizeof(PACKET_OID_DATA) + sizeof(ULONG) - 1);
	PPACKET_OID_DATA OidData;
	OidData = (struct _PACKET_OID_DATA *)malloc(IoCtlBufferLength);
	OidData->Oid = OID_802_3_CURRENT_ADDRESS;
	OidData->Length = 6;
	if(PacketRequest(lpAdapter, FALSE, OidData) == FALSE)
		memcpy(ether_addr, 0, 6);
	else
		memcpy(ether_addr, OidData->Data, 6);
	free(OidData);
}

int GetARPReply(LPPACKET lpPacket, unsigned char *iptarget, unsigned char *result)
{
unsigned short int ether_type;
unsigned char ipsender[4]; 
unsigned int off=0;
unsigned int tlen;
struct bpf_hdr *hdr; 
char *pChar;
char *buf;
	buf = (char *)lpPacket->Buffer; 
	hdr = (struct bpf_hdr *)(buf + off);
	tlen = hdr->bh_caplen;
	off += hdr->bh_hdrlen; 
	pChar = (char*)(buf + off); 
	off = Packet_WORDALIGN(off + tlen);
	memcpy(&ether_type, pChar + 12, 2);
	ether_type = ntohs(ether_type); 
	if(ether_type == ETH_TYPE_ARP)
	{	memcpy(ipsender, pChar + 28, 4);
		if(	(iptarget[0] == ipsender[0])&&(iptarget[1] == ipsender[1])&&
			(iptarget[2] == ipsender[2])&&(iptarget[3] == ipsender[3]))
			memcpy(result, pChar + 22, 6);
		else
			return(EXIT_FAILURE);
	}
	else
		return(EXIT_FAILURE);
	return(EXIT_SUCCESS);
}

int CheckPROMode(LPADAPTER lpAdapter, unsigned char *iptarget, 
				 unsigned char *remotemac,unsigned char *srcMAC,
				 unsigned char *srcIPAdd)
{
LPPACKET lpPacketRequest;
LPPACKET lpPacketReply;
char buffer[256000];
TArpPacket ArpPacket;
unsigned char magicpack[ETH_ADD_LEN]= {0xFF,0xFF,0xFF,0xFF,0xFF,0xFE};
unsigned char mactarget[ARP_ETH_ADD_SPACE];
DWORD timestamp = 0;
int numPacks = 0;
// Init fields
	memset(mactarget, 0, 6);
	// Allocate PACKET structure for ARP Request packet
	if((lpPacketRequest = PacketAllocatePacket()) == NULL)
	{	//msgStatus = "Error : failed to allocate the LPPACKET structure..";
		//SHOWSTAT(msgStatus);
		return(EXIT_FAILURE);
	}
	// Init packet structure
	memset(&ArpPacket, 0, sizeof(TArpPacket));
	// Build ARP Request packet
	BuildARPPacket(&ArpPacket, magicpack, srcMAC, ARP_OP_REQUEST,
					srcMAC, srcIPAdd, mactarget, iptarget, ARP_HARDWARE);
	// Init ARP Request packet
	PacketInitPacket(lpPacketRequest, &ArpPacket, sizeof(ArpPacket));

	// Set number of ARP Request packets to send
	if(PacketSetNumWrites(lpAdapter, 1) == FALSE)
	{	//msgStatus = "Warning : unable to send more than one packet in a single write..";
		//SHOWSTAT(msgStatus);
	}
	// Set hardware filter to directed mode
	if(PacketSetHwFilter(lpAdapter, NDIS_PACKET_TYPE_DIRECTED) == FALSE)
	{	//msgStatus ="Warning: unable to set directed mode..";
		//SHOWSTAT(msgStatus);
	}
	// Set a 512K buffer in the driver
	if(PacketSetBuff(lpAdapter, 512000) == FALSE)
	{	//msgStatus = "Error: unable to set the kernel buffer..";
		//SHOWSTAT(msgStatus);
		PacketFreePacket(lpPacketRequest);
		return(EXIT_FAILURE);
	}
	// Set a 1 second read timeout
	if(PacketSetReadTimeout(lpAdapter, -1) == FALSE)
	{	//msgStatus = "Warning: unable to set the read tiemout..";
		//SHOWSTAT(msgStatus);
	}
	// Allocate PACKET structure for ARP Reply packet
	if((lpPacketReply = PacketAllocatePacket()) == NULL)
	{	//msgStatus = "Error: failed to allocate the LPPACKET structure..";
		//SHOWSTAT(msgStatus);
		PacketFreePacket(lpPacketRequest);
		return(EXIT_FAILURE);
	}
	// Init ARP Reply packet
	PacketInitPacket(lpPacketReply, (char*)buffer, 256000);
	// Allocate memory for remote MAC address
	timestamp = GetTickCount();
	// Main capture loop
	for(;;)
	{	if(numPacks < numPacks)//wParams.
		{	// Send packet
			if(PacketSendPacket(lpAdapter, lpPacketRequest, TRUE) == FALSE)
			{	//msgStatus ="Error : unable to send the packets..";
				//SHOWSTAT(msgStatus);
				PacketFreePacket(lpPacketRequest);
				PacketFreePacket(lpPacketReply);
				return(EXIT_FAILURE);
			}
			// Free packet
			PacketFreePacket(lpPacketRequest);
			numPacks += 1;
		}
		// Capture the packets
		if(PacketReceivePacket(lpAdapter, lpPacketReply, TRUE) == FALSE)
		{	//msgStatus = "Error: PacketReceivePacket failed..";
			//SHOWSTAT(msgStatus);
			PacketFreePacket(lpPacketReply);
			return(EXIT_FAILURE);
		}
		//if(lpPacketReply->ulBytesReceived > 0)
		//	if(GetARPReply(lpPacketReply, iptarget, remotemac) == EXIT_SUCCESS)
		//		break;
		if((GetTickCount() - timestamp) > 2000)//delay)//wParams.
		{	PacketFreePacket(lpPacketReply);
			return(EXIT_FAILURE);
		}
	}
	// Free packet
	PacketFreePacket(lpPacketReply);
	return(EXIT_SUCCESS);
}
	
BOOL SendARPFromConfIPList(PluginObj *plg)
{
BOOL rt=FALSE;int i;
DWORD n;//cnt = totSearchNodes;

	for(i=0; conf.iIPListCnt; ++i)
	{	n = Ip4AsDWORD(conf.IPList[i]);		
		if(n<plg->dwIPFrom)continue;//vne diapazona
		if(n>plg->dwIPTo)continue;//vne diapazona
		n -= plg->dwIPFrom;
		if(plg->SendBitTable[n] & 0x80)//eng katta biti, zapros yuborilganligini bildiradi;
			continue;	  //undan keyingi biti otvet olinganligini bildiradi;
						  //6 ta bit esa(0-63) sekundlarni bildiradi;
	}
	return rt;
}*/