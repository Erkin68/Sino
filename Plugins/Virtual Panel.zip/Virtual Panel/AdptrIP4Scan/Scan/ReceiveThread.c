#pragma warning(disable:4005)
#pragma warning(disable:4995)
#pragma warning(disable:4996)

#include "..\Packet\Packet32.h"
#include "..\Plugins_C.h"
#include <ntddndis.h>
#include <commctrl.h>



DWORD WINAPI recvThrdRoutine(LPVOID lpParameter)
{
LPVOID *pars = (LPVOID*)lpParameter;//0-recvThrd,1-recvThrdId,2-bCancelThread,3-adapter,4-&pckts,5-numPckts;
BOOL *bCancelThread = pars[2];
LPADAPTER adptr = pars[3];
LPPACKET  *recvPckts = (LPPACKET*)pars[4];
int iRecvPckts = (int)pars[5];
long *iRecvPcktsHere = pars[6];
//PluginObj *plg = pars[7];
	
	*iRecvPcktsHere = 0;

	for(;;)
	{	//if(!plg->ScanThrd)
		//	return 0;
		if(TRUE==(*bCancelThread))
			return 0;
		PacketReceivePacket(adptr,recvPckts[(*iRecvPcktsHere) % iRecvPckts],TRUE);
		//PacketReceivePacketImmediate(adptr,recvPckts[(*iRecvPcktsHere) % iRecvPckts]);
		if(recvPckts[(*iRecvPcktsHere) % iRecvPckts]->ulBytesReceived>20)
		{	
			++(*iRecvPcktsHere);
	}	}
	return 1;
}