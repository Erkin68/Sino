//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by AdptrIP4Scan.rc
//
#define IDD_DIALOG_OPTIONS              101
#define IDD_DIALOG_ADAPTERS_FAILES      102
#define IDC_COMBO_SCAN_METHOD           1002
#define IDC_EDIT_METHOD_DESC            1003
#define IDC_IPADDRESS_FROM              1004
#define IDC_IPADDRESS_TO                1005
#define IDC_EDIT_timeout                1006
#define IDC_COMBO_IP_SELECT_METHOD      1007
#define IDC_EDIT_IP_SELECT_METHOD_DESC  1008
#define IDC_CHECK_IPV6                  1009
#define IDC_EDIT_IPV6_FROM              1010
#define IDC_EDIT_IPV6_TO                1011
#define IDC_COMBO_ADAPTERS              1012
#define IDC_STATIC0                     1013
#define IDC_STATIC1                     1014
#define IDC_STATIC2                     1015
#define IDC_STATIC3                     1016
#define IDC_STATIC4                     1017
#define IDC_STATIC5                     1018
#define IDC_CHECK_USE_LIST              1019
#define IDC_STATIC7                     1020
#define IDC_STATIC6                     1021
#define IDC_CHECK_OUT_IP_ADDR           1022
#define IDC_CHECK_OUT_GROUP             1023
#define IDC_CHECK_OUT_NAME              1024
#define IDC_COMBO_ADAPTERS_ADDRESSES    1025
#define IDC_STATIC8                     1026
#define IDC_COMBO_ADAPTERS_SUBNET_MASKS 1027
#define IDC_STATIC9                     1028
#define IDC_COMBO_ADAPTERS_SUBNET_MASKS2 1029
#define IDC_COMBO_ADAPTERS_BROADCAST_ADDRESSES 1029
#define IDC_BUTTON1                     1030
#define IDC_BUTTON_CLR_REGISTRY         1030
#define IDC_BUTTON_RESET                1030
#define IDC_STATIC10                    1031
#define IDC_COMBO_ADAPTERS_BROADCAST_ADDRESSES2 1032
#define IDC_COMBO_ADAPTERS_GATEWAY_ADDRESSES 1032
#define IDC_SLIDER_SPEED                1033
#define IDC_STATIC11                    1034
#define IDC_CHECK1                      1035
#define IDC_CHECK_FAST_ICON             1035

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        103
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1036
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
