#include "Winsock2.h"
#include "Plugins_C.h"
//#include "Lm.h"

int RetriveHostNameAndDomainName(PluginObj* plg,int itemId,wchar_t *itemIP4str)
{
LPBYTE bufptr=NULL;
DWORD dwIP; int n;
wchar_t s[64]=L"\\\\";
char itemIP4strA[32];
struct hostent *Host;
	WideCharToMultiByte(CP_ACP,0,itemIP4str,-1,itemIP4strA,wcslen(itemIP4str)+2,NULL,NULL);
	dwIP = inet_addr(itemIP4strA);
	Host = gethostbyaddr((char*)&dwIP, 4, AF_INET);
	if(Host)
	{	for(n=0; n<plg->IPNodesCnt; ++n)
		{	if(plg->IPNodes[n].IP == dwIP)
			{	if(0==plg->IPNodes[n].NETBIOSNAME[0])
				{	MultiByteToWideChar(CP_ACP,0,Host->h_name,-1,plg->IPNodes[n].NETBIOSNAME,(DWORD)(strlen(Host->h_name)+2));
					//wcscpy(&s[2],plg->IPNodes[n].NETBIOSNAME);
					//if(/*NERR_Success*/0==NetGroupGetInfo(s,0,NULL,&bufptr))
					{	//wcscpy(plg->IPNodes[n].NETBIOSGROUPNAME,((PGROUP_INFO_0)bufptr)->grpi0_name);
						//NetApiBufferFree(bufptr);
					}
					return 0;
				}
				else return -1;
	}	}	}
	return 0;
}