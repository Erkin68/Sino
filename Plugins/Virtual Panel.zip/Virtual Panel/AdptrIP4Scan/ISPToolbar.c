#pragma warning(disable:4005)

#include "Packet\Packet32.h"
#include "windows.h"
#include "strsafe.h"
#include "shlobj.h"
#include "Plugins_C.h"
#include "resource.h"
#include "..\..\..\Operations\MyShell\MyShellC.h"
//#include "..\..\..\Operations\MyShell\MyButtonC.h"

//BUTTONS IDS:
#define tlbrBtnOptnID		2
//#define tlbrBtnResetListID3
#define tlbrBtnExitID		3
#define tlbrBtnStopID		4

VOID GetChldPos(HWND prnt,RECT *rc)
{
	GetWindowRect(prnt,rc);
	rc->bottom = rc->top;
	rc->top -= 42;
}

LRESULT CALLBACK VPtoolbarWndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
PluginObj *plg = (PluginObj*)((LPCREATESTRUCT)GetWindowLongPtr(hWnd,GWLP_USERDATA));//->lpCreateParams);
	switch(message)
	{	case WM_CREATE:
			SetWindowLongPtr(hWnd,GWLP_USERDATA,(LONG)((LPCREATESTRUCT)lParam)->lpCreateParams);
			//SetWindowLongPtr(hWnd,GWL_ID,(LONG)((LPCREATESTRUCT)lParam)->hwndParent);
			return 0;
		case WM_COMMAND:
			switch(LOWORD(wParam))
			{	case tlbrBtnStopID:
					if(scan==plg->state)
					{	plg->state = wait_for_stopandexiting;
						plg->TermScanThrd = 2;
						SetFocus(plg->prnt);//SetFocus((HWND)GetWindowLongPtr(hWnd,GWL_ID));//GetParent(hWnd));ishlamaydur;
					}
					else
					{	WaitForScan(plg,15000,1);
						//freePanel(plg->host,TRUE);
						/*if(plg->IPNodes)free(plg->IPNodes);
						plg->IPNodes = NULL;
						plg->IPNodesCnt = plg->IPNodesMaxCnt = 0;
						if(plg->DomainNodes)free(plg->DomainNodes);
						plg->DomainNodesCnt = plg->DomainNodesMaxCnt = 0;
						plg->DomainNodes = NULL;*/
						SendMessage(plg->tlbrBtnStop,WM_SETTEXT,0,(LPARAM)strngs[45]);//L"Stop");
						if(0==wcscmp(plg->path,L"\\\\?\\UNC\\*"))
							plg->ScanThrd = CreateThread(NULL,0,plg->trd,plg,0,&plg->ScanThrdId);
						else MessageBox(hWnd,strngs[81],strngs[82],MB_OK);//L"You can't reset in not root folder.",L"Please,go to root folder",MB_OK);
						SetFocus(plg->prnt);//(HWND)GetWindowLongPtr(hWnd,GWL_ID));//GetParent(hWnd));ishlamaydur;
					}
					return 0;
				case tlbrBtnExitID:
					if(lParam==(LPARAM)plg->tlbrBtnExit)
					{	//if(!plg->bEntrScan)goto E;
						//else
						{	if(plg->ScanThrd)
								WaitForScan(plg,15000,1);
							if(!plg->ScanThrd)
							{	
							//E:  
								closeEvent(plgId,plg->host);
								//DetachPanel$8((LPVOID)plg,plg->host);
					}	}	}
					return 0;
				case tlbrBtnOptnID:
					//if(lParam==(LPARAM)plg->tlbrBtnOptn)
						DialogBoxParam(plgnDllInst,(LPCWSTR)IDD_DIALOG_OPTIONS,hWnd,OptnDlgProc,(LPARAM)plg);
					//Sleep(20);
					//SetFocus(GetParent(hWnd));
				return 0;
			}
		break;
	}
	return DefWindowProc(hWnd, message, wParam, lParam);
}

__declspec (dllexport) LPVOID AttachPanel$12(HWND prnt,LPVOID host,wchar_t *path)
{
WNDCLASSEX wcex;RECT rc;INITCOMMONCONTROLSEX iccInit;PluginObj *plg;
npf_if_addr crntAddr, **pAdAddr;char ipstrA[32];

	if(!GetAdaptersNumsAndNames())
	{	//MessageBox(prnt,L"Network adapters not founded!!!",L"Error...",MB_OK);
		//OutputDebugStringA("\nFailed GetAdaptersNumsAndNames");
	Fail:	return FALSE;
	}
	if(conf.pAdatersIPNums)
		conf.pAdatersIPNums = (char*)realloc(conf.pAdatersIPNums,conf.iNumAdapters);
	else
		conf.pAdatersIPNums = (char*)malloc(conf.iNumAdapters);
	if(conf.pAdaptersIf_addrs)
		conf.pAdaptersIf_addrs = (LPVOID**)realloc(conf.pAdaptersIf_addrs,conf.iNumAdapters * sizeof(npf_if_addr*));
	else
		conf.pAdaptersIf_addrs = (LPVOID**)malloc(conf.iNumAdapters * sizeof(npf_if_addr*));
	if(!GetAdaptersAdresses())
		goto Fail;

	//OutputDebugStringA("\nSuccessed GetAdaptersNumsAndNames");
	plg = (PluginObj*)malloc(sizeof(PluginObj));
	if(!plg)
	{	MessageBox(prnt,strngs[3],path,MB_OK);
		return NULL;
	}
	
	if(!plgList)
	{	plgList = (LPVOID*)malloc(sizeof(LPVOID));
		plgList[0] = plg;
		iPlgList = 1;
	}
	else
	{	plgList = (LPVOID*)realloc(plgList,(iPlgList+1) * sizeof(LPVOID));
		plgList[iPlgList++] = plg;
	}

	plg->pathLn=MyStringCpy(plg->path,MAX_PATH-1,path);
	wcex.cbSize = sizeof(WNDCLASSEX);
	wcex.style			= CS_HREDRAW | CS_VREDRAW;
	wcex.lpfnWndProc	= VPtoolbarWndProc;
	wcex.cbClsExtra		= 0;
	wcex.cbWndExtra		= 0;
	wcex.hInstance		= plgnDllInst;
	wcex.hIcon			= NULL;
	wcex.hCursor		= LoadCursor(NULL, IDC_ARROW);
	wcex.hbrBackground	= (HBRUSH)(COLOR_WINDOW+1);
	wcex.lpszMenuName	= NULL;
	wcex.lpszClassName	= L"VirtNETtoolbarClass";
	wcex.hIconSm		= NULL;
	RegisterClassEx(&wcex);
	GetChldPos(prnt,&rc);
	plg->tlbrWnd = CreateWindowEx(0, 
                        L"VirtNETtoolbarClass", 
                        (LPCTSTR)NULL, 
                        WS_POPUP|WS_BORDER, 
                        rc.left,rc.top,rc.right-rc.left,rc.bottom-rc.top,
                        prnt,
                        0,
                        plgnDllInst, 
                        plg);//shuni o'zi; SetWindowLongPtrW(plg->tlbrWnd,GWLP_USERDATA,(LONG)plg);
	iccInit.dwSize = sizeof(iccInit);
	iccInit.dwICC = ICC_PROGRESS_CLASS;
	InitCommonControlsEx(&iccInit);
	plg->tlbrPrgrs = CreateWindowEx(0,
                        PROGRESS_CLASS,
                        TEXT("Progess Bar"), 
                        WS_CHILD|WS_VISIBLE|PBS_SMOOTH|PBS_MARQUEE,
                        2, 
						rc.bottom-rc.top-16,
                        436,//rc.right - rc.left-4,
                        15, 
                        plg->tlbrWnd,
                        NULL,
                        plgnDllInst,
                        NULL);
	plg->tlbrLabelState = CreateWindowEx(0,
                        WC_STATIC,
						TEXT("State:"),
                        WS_CHILD|WS_VISIBLE,
                        2, 
						rc.bottom-rc.top-36,
                        45,
                        20, 
                        plg->tlbrWnd,
                        NULL,
                        plgnDllInst,
                        NULL);
	plg->tlbrEditState = CreateWindowEx(WS_EX_CLIENTEDGE,
                        L"EDIT",
						NULL,
                        WS_CHILD|WS_VISIBLE|ES_LEFT|ES_AUTOVSCROLL,//WS_DISABLED
                        46, 
						rc.bottom-rc.top-36,
                        238,
                        20, 
                        plg->tlbrWnd,
                        (HMENU)1,
                        plgnDllInst,
                        NULL);
	plg->tlbrBtnStop = CreateWindowEx(WS_EX_CLIENTEDGE,
                        L"BUTTON",
						L"Stop",
                        WS_CHILD|WS_VISIBLE,
                        288, 
						rc.bottom-rc.top-40,
                        50,
                        24, 
                        plg->tlbrWnd,
                        (HMENU)tlbrBtnStopID,
                        plgnDllInst,
                        NULL);
	//plg->tlbrBtnStop=MyButtonGetHWND(MyButtonInit(plg->tlbrWnd,strngs[45]/*L"Stop"*/,tlbrBtnStopID,0,288,rc.bottom-rc.top-36,50,20));
	plg->tlbrBtnOptn = CreateWindowEx(WS_EX_CLIENTEDGE,
                        L"BUTTON",
						L"Options",
                        WS_CHILD|WS_VISIBLE,
                        340, 
						rc.bottom-rc.top-40,
                        70,
                        24, 
                        plg->tlbrWnd,
                        (HMENU)tlbrBtnOptnID,
                        plgnDllInst,
                        NULL);
	/*plg->tlbrBtnOptn=MyButtonGetHWND(MyButtonInit(plg->tlbrWnd,strngs[104],tlbrBtnOptnID,0,340,rc.bottom-rc.top-36,70,20));
	  plg->tlbrBtnResetList = CreateWindowEx(WS_EX_CLIENTEDGE,
                        L"BUTTON",
						L"Rst",//exit
                        WS_CHILD|WS_VISIBLE,
                        374, 
						rc.bottom-rc.top-40,
                        38,
                        24, 
                        plg->tlbrWnd,
                        (HMENU)tlbrBtnResetListID,
                        plgnDllInst,
                        NULL);*/
	//plg->tlbrBtnResetList=MyButtonGetHWND(MyButtonInit(plg->tlbrWnd,L"Rst",tlbrBtnResetListID,0,374,rc.bottom-rc.top-36,38,20));
	plg->tlbrBtnExit = CreateWindowEx(WS_EX_CLIENTEDGE,
                        L"BUTTON",
						L"x",//exit
                        WS_CHILD|WS_VISIBLE,
                        414, 
						rc.bottom-rc.top-40,
                        22,
                        24, 
                        plg->tlbrWnd,
                        (HMENU)tlbrBtnExitID,
                        plgnDllInst,
                        NULL);
	//plg->tlbrBtnExit=MyButtonGetHWND(MyButtonInit(plg->tlbrWnd,L"x",tlbrBtnExitID,0,414,rc.bottom-rc.top-36,22,20));
	SendMessage(plg->tlbrEditState, WM_SETTEXT, 0, (LPARAM)strngs[101]);//L"Scanning..."); 
	ShowWindow(plg->tlbrWnd,SW_SHOW);
	UpdateWindow(plg->tlbrWnd);
	SendMessage(plg->tlbrPrgrs, PBM_SETRANGE, 0, MAKELPARAM(0,100)); 
	SendMessage(plg->tlbrPrgrs, PBM_SETSTEP, MAKEWPARAM(1, 0), 0);
	SendMessage(plg->tlbrPrgrs, PBM_SETPOS, 0, 0);


	//1.Avval configni plg ga ko'chirib olamiz,chunki conf o'zgarib ketishi mumkin;
	CopyIp4(&plg->ipFrom,&conf.ipFrom);		 CopyIp4(&plg->ipTo,&conf.ipTo);
	plg->dwIPFrom = Ip4AsDWORD(plg->ipFrom); plg->dwIPTo = Ip4AsDWORD(plg->ipTo);
	plg->totSearchNodes = plg->dwIPTo - plg->dwIPFrom + 1;
	
	pAdAddr = (npf_if_addr**)conf.pAdaptersIf_addrs;
	crntAddr = pAdAddr[conf.iCrntAdapter][conf.iCrntAdapterIPAddress];
	CopyIp4(&plg->myIP,&crntAddr.IPAddress.__ss_pad1[2]);
	plg->dwMyIP = Ip4AsDWORD(plg->myIP);
	if(plg->myIP.b[0]<128)plg->crntAdptrIPGroupe = 0;//A
	else if(plg->myIP.b[0]<192)plg->crntAdptrIPGroupe = 1;//B
	else if(plg->myIP.b[0]<224)plg->crntAdptrIPGroupe = 2;//C
	else if(plg->myIP.b[0]<240)plg->crntAdptrIPGroupe = 3;//D
	else /*if(plg->myIP.b[0]<256)*/plg->crntAdptrIPGroupe = 4;//D

	plg->iScanMethod[0] = conf.iScanMethod[0];plg->iScanMethod[1] = conf.iScanMethod[1];
	MyStringCpyA(plg->crntAdptrDesc,MAX_PATH-1,conf.crntAdptrDesc);
	MyStringCpyA(plg->crntAdptrName,MAX_PATH-1,conf.crntAdptrName);
	MyStringCpyA(plg->crntAdptrNameInFile,MAX_PATH-1,conf.crntAdptrNameInFile);
	plg->iCrntAdapter = conf.iCrntAdapter;plg->iCrntAdapterIPAddress = conf.iCrntAdapterIPAddress;
	CopyIp4(&plg->crntAdptrMask,&crntAddr.SubnetMask.__ss_pad1[2]);
	plg->dwCrntAdptrMask = Ip4AsDWORD(plg->crntAdptrMask);

	plg->IPNodes = NULL;	
	plg->IPNodesCnt=plg->IPNodesMaxCnt=0;
	plg->DomainNodes = NULL;	
	plg->DomainNodesCnt=plg->DomainNodesMaxCnt=0;
	plg->crntDomainGroup[0]=0;
	plg->state=scan;
	plg->host = host;
	plg->prnt = prnt;
	//plg->bEntrScan = TRUE;
	plg->srchResltBuf=NULL;
	plg->srchResltBufLn=0;
	plg->trd = ScanWithoutGateThrdProc;
	plg->state = attachForScan;
	plg->schDlgOkBtn = NULL;

	if(1>GetAdapterMacAndGatewayIP4((char*)&plg->crntAdptrMAC.b[0],(char*)&plg->crntAdptrGatewayIP4.b[0],plg->crntAdptrName))
	{	ZeroIp4(&plg->crntAdptrGatewayIP4);		
	}
	else
	{	ULONG szMac,Mac[2]={0,0},dwRetVal;
		szMac=plg->dwCrntAdptrGatewayIP4 = Ip4AsDWORD(plg->crntAdptrGatewayIP4);
		//if(plg->dwCrntAdptrGatewayIP4<plg->dwIPFrom && plg->dwCrntAdptrGatewayIP4<plg->dwIPFrom)
		FlushIpNetTable(conf.iCrntAdapter);
		dwRetVal=SendARP(*((IPAddr*)&plg->crntAdptrGatewayIP4),*((IPAddr*)&plg->myIP),Mac,&szMac);
		if((NO_ERROR==dwRetVal) && (Mac[0] | Mac[1]))
		{	CopyIp6(&plg->crntAdptrGWMAC.b[0],&Mac[0]);
			plg->trd = ScanViaGateThrdProc;
		}
		else
		{	/*printf("Error: SendArp failed with error: %d", dwRetVal);
			switch (dwRetVal)
			{	case ERROR_GEN_FAILURE:
					printf(" (ERROR_GEN_FAILURE)\n");		break;
				case ERROR_INVALID_PARAMETER:
					printf(" (ERROR_INVALID_PARAMETER)\n");	break;
				case ERROR_INVALID_USER_BUFFER:
					printf(" (ERROR_INVALID_USER_BUFFER)\n");break;
				case ERROR_BAD_NET_NAME:
					printf(" (ERROR_GEN_FAILURE)\n");		break;
				case ERROR_BUFFER_OVERFLOW:
					printf(" (ERROR_BUFFER_OVERFLOW)\n");	break;
				case ERROR_NOT_FOUND:
					printf(" (ERROR_NOT_FOUND)\n");			break;
				default: 
					printf("\n");							break;
			}*/
			DWORD i,dwSize=0;PMIB_IPNETTABLE pIpNetTable=NULL;
			if(ERROR_INSUFFICIENT_BUFFER==GetIpNetTable(pIpNetTable,&dwSize,FALSE))
			{	pIpNetTable = (PMIB_IPNETTABLE)malloc(dwSize);
				if(NO_ERROR==GetIpNetTable(pIpNetTable,&dwSize,FALSE))
				{	for(i=0; i<pIpNetTable->dwNumEntries; ++i)
					{	if(pIpNetTable->table[i].dwAddr==(*((DWORD*)&plg->crntAdptrGatewayIP4)))
						{	CopyIp6(&plg->crntAdptrGWMAC.b[0],pIpNetTable->table[i].bPhysAddr);
							plg->trd = ScanViaGateThrdProc;
							break;
				}	}	}
				free(pIpNetTable);
			}
	}	}
	if(MyInet4StrToDword(path,ipstrA,&plg->dwIPWEnum))
	{	//plg->bEntrScan = FALSE;
		plg->state = attachWithoutScan;
		plg->trd = NULL;//WEnumNodeThrdProc;
		Ip4Shufl((DWORD*)&plg->ipWEnum.b[0],(BYTE*)&plg->dwIPWEnum);
	}
	SetFocus(prnt);
	return plg;
}