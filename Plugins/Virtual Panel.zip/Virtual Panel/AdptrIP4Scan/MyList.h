#ifndef _MY_LIST_H__
#define _MY_LIST_H__

#include "ntndk.h"


typedef struct _my_list
{	struct _my_list *next;	/* pointer to the next region */
    struct _my_list *prev;	/* pointer to the previous region */
	unsigned long objAccesFlag;
	char	attribute;
	UNICODE_STRING symbolicLinkName;
	UNICODE_STRING name;
	UNICODE_STRING path;
} my_list;

typedef struct _list_entry
{	struct _list_entry *next; /* pointer to next entry */
    struct _list_entry *prev; /* pointer to previous entry */
} list_entry;


extern list_entry* winx_list_insert(list_entry**,list_entry*,long);
extern void winx_list_remove(list_entry**,list_entry*);
extern void winx_list_destroy(list_entry**);
extern my_list *my_winx_list_get_entry(my_list**,int);


#endif