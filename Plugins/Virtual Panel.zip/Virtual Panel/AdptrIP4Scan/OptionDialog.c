#pragma warning(disable:4005)
#pragma warning(disable:4996)

#include "Packet\Packet32.h"
#include "windows.h"
#include "resource.h"
#include "Plugins_C.h"
#include "commctrl.h"
#include "..\..\..\Operations\MyShell\MyShellC.h"
//#include "..\..\..\Operations\MyShell\MyButtonC.h"


BOOL ReadOptions();
BOOL SaveOptions();
BOOL SetOptionsToDlg(HWND);
extern __declspec (dllexport) int GetAdapterMacAndGatewayIP4(char*,char*,char*);

Conf conf = {0,0,0,0,0,0,0,0,//IP4BYTE ipFrom,ipTo;
			NULL,//IP4BYTE *IPList;
			0,//long iIPListCnt;
			0,//int  iNumAdapters;
			0,0,//int  iScanMethod[2];
			10,//iSpeed
			1000,//iTimeout
			"",//char selectedAdapterDesc[MAX_PATH];
			"",//char crntAdptrNameInFile[MAX_PATH];
			"",//char crntAdptrNameInFile[MAX_PATH];
			NULL,NULL,//char *AdaptersName,*pAdatersIPNums;//har 1 adapterda nechtadan IP address borligi;
			NULL,//LPVOID **pAdaptersIf_addrs;//IP_ADAPTER_INFO *pAdaptersInfo;
			0,0};//int iCrntAdapter,iCrntAdapterIPAddress;
char sA[MAX_PATH] = "";

INT_PTR CALLBACK OptnDlgProc(HWND hDlg,UINT message,WPARAM wParam,LPARAM lParam)
{
PluginObj *plg; wchar_t RetCar[3] = {0x0d, 0x0a, 0x00};int p;npf_if_addr **pAdAddr;char gateWayIP[4],MAC[6];
wchar_t *ps,s[MAX_PATH];PROCESS_INFORMATION pi;STARTUPINFO si;
	switch(message)
	{
	case WM_INITDIALOG:
		SetWindowLongPtr(hDlg,GWLP_USERDATA,lParam);
		plg = (PluginObj*)lParam;

		SetOptionsToDlg(hDlg);

		SendMessageW(GetDlgItem(hDlg,IDC_COMBO_SCAN_METHOD),CB_INSERTSTRING,-1,(LPARAM)strngs[86]);//L"1. SEND NAME RECOGNIZE REQUEST IN PACKETS");
		SendMessageW(GetDlgItem(hDlg,IDC_COMBO_SCAN_METHOD),CB_INSERTSTRING,-1,(LPARAM)strngs[87]);//L"2. NOT SEND NAME RECOGNIZE REQUEST IN PACKETS");
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_SCAN_METHOD),CB_SETCURSEL,conf.iScanMethod[0],0);

		SendMessageW(GetDlgItem(hDlg,IDC_COMBO_IP_SELECT_METHOD),CB_INSERTSTRING,-1,(LPARAM)strngs[88]);//L"1. DIRECT");
		SendMessageW(GetDlgItem(hDlg,IDC_COMBO_IP_SELECT_METHOD),CB_INSERTSTRING,-1,(LPARAM)strngs[89]);//L"2. RANDOM");
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_IP_SELECT_METHOD),CB_SETCURSEL,conf.iScanMethod[1],0);

		SendMessage(GetDlgItem(hDlg,IDC_SLIDER_SPEED),TBM_SETRANGE,FALSE,MAKELONG(0,250));
		SendMessage(GetDlgItem(hDlg,IDC_SLIDER_SPEED),TBM_SETPOS,TRUE,conf.iSpeed);
		wsprintf(s,L"Speed/Accuracy: %d ms.",conf.iSpeed);
		SetDlgItemText(hDlg,IDC_STATIC11,s);

		wsprintf(s,L"%d",conf.iTimeout);
		SetDlgItemText(hDlg,IDC_EDIT_timeout,s);

		SetWindowText(hDlg,strngs[59]);
		SetDlgItemText(hDlg,IDC_STATIC0,strngs[60]);
		SetDlgItemText(hDlg,IDC_STATIC7,strngs[61]);
		SetDlgItemText(hDlg,IDC_STATIC8,strngs[62]);
		SetDlgItemText(hDlg,IDC_STATIC9,strngs[63]);
		SetDlgItemText(hDlg,IDC_STATIC10,strngs[64]);
		SetDlgItemText(hDlg,IDC_STATIC1,strngs[65]);
		SetDlgItemText(hDlg,IDC_STATIC2,strngs[66]);
		SetDlgItemText(hDlg,IDC_STATIC3,strngs[67]);
		SetDlgItemText(hDlg,IDC_STATIC4,strngs[68]);
		SetDlgItemText(hDlg,IDC_STATIC5,strngs[69]);
		SetDlgItemText(hDlg,IDC_CHECK_USE_LIST,strngs[70]);
		SetDlgItemText(hDlg,IDC_CHECK_FAST_ICON,strngs[71]);
		SetDlgItemText(hDlg,IDC_STATIC6,strngs[72]);
		SetDlgItemText(hDlg,IDC_STATIC11,strngs[73]);
		SetDlgItemText(hDlg,IDC_BUTTON_CLR_REGISTRY,strngs[74]);
		SetDlgItemText(hDlg,IDOK,strngs[12]);

		//MyButtonFrRCBtn(hDlg,IDC_BUTTON_CLR_REGISTRY,0);
		//MyButtonFrRCBtn(hDlg,IDOK,0);

		return TRUE;
	case WM_COMMAND:
		switch(LOWORD(wParam))
		{	case IDCANCEL:
				return 0;
			//case IDOK:
			case 1://tlbrBtnExit OK
				EndDialog(hDlg,0);
				return (INT_PTR)TRUE;
			case IDC_COMBO_SCAN_METHOD:
				if(CBN_SELCHANGE==HIWORD(wParam))
				{	int sel = (int)SendMessage(GetDlgItem(hDlg,IDC_COMBO_SCAN_METHOD),CB_GETCURSEL,0,0);
					switch(sel)//CB_ERR!=
					{	case 0:
							//SetDlgItemText(hDlg,IDC_EDIT_METHOD_DESC,L"1.Find node with WINS-protocol via port 137-NETBIOS;\n2.Enum directory resources in founded node via SMB protocol;");
							SetWindowText(GetDlgItem(hDlg,IDC_EDIT_METHOD_DESC),(LPCTSTR)0);
							SendMessageW(GetDlgItem(hDlg,IDC_EDIT_METHOD_DESC),EM_REPLACESEL,0,(LPARAM)strngs[85]);//L"1.Use for name recognizing WINS-protocol(via port 137-NETBIOS;)");
							SendMessageW(GetDlgItem(hDlg,IDC_EDIT_METHOD_DESC),EM_REPLACESEL, (WPARAM)FALSE, (LPARAM)(LPCSTR)RetCar);
							SendMessage(GetDlgItem(hDlg,IDC_EDIT_METHOD_DESC),EM_SCROLLCARET, (WPARAM)0, (LPARAM)0);
							SendMessageW(GetDlgItem(hDlg,IDC_EDIT_METHOD_DESC),EM_REPLACESEL,0,(LPARAM)strngs[84]);//L"2.Enum directory resources in founded node;");
							break;
						case 1:
							SetWindowTextW(GetDlgItem(hDlg,IDC_EDIT_METHOD_DESC),(LPCTSTR)0);
							SetDlgItemTextW(hDlg,IDC_EDIT_METHOD_DESC,strngs[83]);//L"1.Find node with PING echo signal via port-...");
							break;
					}
					return (INT_PTR)TRUE;
				}
				return 0;
			case IDC_COMBO_ADAPTERS:
				if(CBN_SELCHANGE==HIWORD(wParam))
				{	SendMessage(GetDlgItem(hDlg,IDC_COMBO_ADAPTERS_ADDRESSES),CB_RESETCONTENT,0,0);
					plg = (PluginObj*)GetWindowLongPtr(hDlg,GWLP_USERDATA);
					pAdAddr = (npf_if_addr**)conf.pAdaptersIf_addrs;
					for(p=0; p<conf.pAdatersIPNums[conf.iCrntAdapter]; ++p)
					{	npf_if_addr crntAddr = pAdAddr[conf.iCrntAdapter][p];
						IN_ADDR *pAddr = (IN_ADDR*)&crntAddr.IPAddress.__ss_pad1[2];
						SendMessageA(GetDlgItem(hDlg,IDC_COMBO_ADAPTERS_ADDRESSES),
												CB_INSERTSTRING,-1,
										  (LPARAM)inet_ntoa(*pAddr));
					}
					SendMessage(GetDlgItem(hDlg,IDC_COMBO_ADAPTERS_ADDRESSES),CB_SETCURSEL,conf.iCrntAdapterIPAddress,0);
					//Gateway address:
					if(0<GetAdapterMacAndGatewayIP4(MAC,gateWayIP,&conf.AdaptersName[conf.iCrntAdapter]))
						SendMessageA(GetDlgItem(hDlg,IDC_COMBO_ADAPTERS_GATEWAY_ADDRESSES),
												CB_SELECTSTRING,0,
												(LPARAM)inet_ntoa(*((IN_ADDR*)&gateWayIP)));

				}
				return 0;
			case IDC_BUTTON_CLR_REGISTRY:
				if(GetModuleFileName(NULL,s,MAX_PATH))
				{	ps = wcsrchr(s,'\\');
					if(ps)
					{	ZeroMemory(&si,sizeof(si));si.cb=sizeof(si);
						wsprintf(ps+1,L"UninstallAux.exe");
						CreateProcess(s,L" emtyCmndLine",NULL,NULL,FALSE,0,NULL,NULL,&si,&pi);
				}	}
				return 0;
			case IDC_EDIT_timeout:
				GetDlgItemText(hDlg,IDC_EDIT_timeout,s,MAX_PATH);
				conf.iTimeout = _wtoi(s);
				return 0;
			case IDC_CHECK_FAST_ICON:
				conf.bFasterIcon=(BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_FAST_ICON),BM_GETSTATE,0,0)?true:false);
				return 0;
			case IDC_CHECK_USE_LIST:
				conf.bUsePredefinedIPList=(BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_USE_LIST),BM_GETSTATE,0,0)?true:false);
				return 0;
		}
		break;
		case WM_HSCROLL:
			switch(LOWORD(wParam))
			{	case TB_THUMBPOSITION:
				case TB_THUMBTRACK:
					conf.iSpeed = HIWORD(wParam);
					wsprintf(s,strngs[102]/*L"Speed/Accuracy: %d ms."*/,conf.iSpeed);
					SetDlgItemText(hDlg,IDC_STATIC11,s);
					return 0;
				case TB_PAGEUP:
				case TB_PAGEDOWN:
				case TB_LINEUP:
				case TB_LINEDOWN:
					conf.iSpeed = (int)SendDlgItemMessage(hDlg,IDC_SLIDER_SPEED, TBM_GETPOS, 0, 0);
					wsprintf(s,strngs[102]/*L"Speed/Accuracy: %d ms."*/,conf.iSpeed);
					SetDlgItemText(hDlg,IDC_STATIC11,s);
					return 0;
			}	
			break;
	//case WM_DESTROY:
		//HWND prnt;prnt = GetParent(hDlg);
		//if(!prnt)prnt=GetDesktopWindow();
		//SetFocus(prnt));//ishlamaydur;
		//plg = (PluginObj*)GetWindowLong(hDlg,GWL_USERDATA);
		//((Panel*)plg->host)->SetFocus();
		//return 0;
	}
	return (INT_PTR)FALSE;
}

BOOL ReadOptions()
{
char *p,*pp;FILE *f;int k,l,m,crntAdptrLn;

	conf.crntAdptrNameInFile[0] = 0;

	GetModuleFileNameA(plgnDllInst,sA,MAX_PATH);
	p=strrchr(sA,'\\');
	if(p) ++p;
	else return FALSE;
	strcpy(p,"config.txt");
	f = fopen(sA,"r");
	if(!f)return FALSE;

	fscanf(f,"%s", sA);
	if(strcmp(sA,"Adapters:")) goto End;
	fscanf(f,"%d", &k);
	//if(conf.iNumAdapters < k)
	//{	
	//}

	//Current adapterni aniqlab olish:	
	fscanf(f,"%s", sA);
	if(strcmp(sA,"Selected_adapter:")) goto End;
	fscanf(f,"%s", conf.crntAdptrNameInFile);
	crntAdptrLn = (int)strlen(conf.crntAdptrNameInFile);
	if(1==crntAdptrLn)conf.crntAdptrNameInFile[0]=0;
	for(;;)
	{	if(!fscanf(f,"%s", sA))break;
		if(strcmp(sA,"IP_Scan_range:"))
		{	MyStringCatA(conf.crntAdptrNameInFile,MAX_PATH," ");
			MyStringCatA(conf.crntAdptrNameInFile,MAX_PATH,sA);
		}
		else break;
	}//if(!strcmp(s,"IP_Scan_range:"))
	fscanf(f,"%s", sA);
	if(!strcmp(sA,"from:"))
	{	fscanf(f,"%s", sA);p = strchr(sA,'.');*p=0;
		conf.ipFrom.b[0] = (BYTE)atoi(sA);
		pp = strchr(p+1,'.');*pp=0;conf.ipFrom.b[1] = (BYTE)atoi(p+1);
		p = strchr(pp+1,'.');*p=0;conf.ipFrom.b[2] = (BYTE)atoi(pp+1);
		conf.ipFrom.b[3] = (BYTE)atoi(p+1);
	}
	fscanf(f,"%s", sA);
	if(!strcmp(sA,"to:"))
	{	fscanf(f,"%s", sA);p = strchr(sA,'.');*p=0;
		conf.ipTo.b[0] = (BYTE)atoi(sA);
		pp = strchr(p+1,'.');*pp=0;conf.ipTo.b[1] = (BYTE)atoi(p+1);
		p = strchr(pp+1,'.');*p=0;conf.ipTo.b[2] = (BYTE)atoi(pp+1);
		conf.ipTo.b[3] = (BYTE)atoi(p+1);
	}
	fscanf(f,"%s", sA);
	if(!strcmp(sA,"Scan_method:"))
	{	fscanf(f,"%d", &conf.iScanMethod[0]);
		fscanf(f,"%d", &conf.iScanMethod[1]);
	}
	fscanf(f,"%s", sA);
	if(!strcmp(sA,"Speed/Accuracy:"))
		fscanf(f,"%d", &conf.iSpeed);
	fscanf(f,"%s", sA);
	if(!strcmp(sA,"Use_faster_icon:"))
		fscanf(f,"%d", &conf.bFasterIcon);
	fscanf(f,"%s", sA);
	if(!strcmp(sA,"Predefined_IP_list_cnt:"))
	{	fscanf(f,"%d", &conf.iIPListCnt);
		if(conf.iIPListCnt>0)
		{	conf.IPList = (IP4BYTE*)malloc(conf.iIPListCnt*sizeof(IP4BYTE));
			for(k=0; k<conf.iIPListCnt; ++k)
			{	fscanf(f,"%d", &m);
				if(m!=k)
				{	MessageBox(NULL,strngs[94],strngs[95],MB_OK);//L"Invalid IP list in config file...",L"Quiting...",MB_OK);
					goto End;
				}
				for(l=0; l<4; ++l)
				{	fscanf(f,"%d", &m);
					conf.IPList[k].b[l] = (BYTE)m;//Bo'lmasa bayt chegarasidan o'tib int chefarasini bosib oladi;
	}	}	}	}
End:
	fclose(f);
	return TRUE;
}

BOOL SetDefaultOptions()
{
	conf.iCrntAdapter = 0;
	conf.iSpeed = 10;
	conf.iTimeout = 1000;
	conf.bFasterIcon = true;
	conf.bUsePredefinedIPList = true;
	return TRUE;
}

BOOL SaveOptions()
{
char *p;FILE *f;int i;
	if(!conf.iNumAdapters)return FALSE;
	GetModuleFileNameA(plgnDllInst,sA,MAX_PATH);
	p=strrchr(sA,'\\');
	if(p) ++p;
	else return FALSE;

	strcpy(p,"config.txt");
	f = fopen(sA,"w");
	if(!f)return FALSE;

	fprintf(f,"Adapters: %d",conf.iNumAdapters);
	//MultiByteToWideChar(AreFileApisANSI()?CP_ACP:CP_OEMCP,MB_PRECOMPOSED,
	//				plg->AdaptersName,MAX_PATH-1,s,MAX_PATH);
	//SendMessageW(GetDlgItem(hDlg,IDC_COMBO_ADAPTERS),CB_GETLBTEXT,
	//SendMessage(GetDlgItem(hDlg,IDC_COMBO_ADAPTERS),CB_GETCURSEL,0,0),(LPARAM)s);
	fprintf(f,"\nSelected_adapter: %s",conf.crntAdptrDesc[0]?conf.crntAdptrDesc:"0");
	fprintf(f,"\nIP_Scan_range: ");
	fprintf(f,"from: %d.%d.%d.%d",conf.ipFrom.b[0],conf.ipFrom.b[1],conf.ipFrom.b[2],conf.ipFrom.b[3]);
	fprintf(f," to: %d.%d.%d.%d",conf.ipTo.b[0],conf.ipTo.b[1],conf.ipTo.b[2],conf.ipTo.b[3]);
	fprintf(f,"\nScan_method: %d %d",conf.iScanMethod[0],conf.iScanMethod[1]);
	fprintf(f,"\nSpeed/Accuracy: %d",conf.iSpeed);
	fprintf(f,"\nUse_faster_icon: %d",conf.bFasterIcon);
	fprintf(f,"\nPredefined_IP_list_cnt: %d",conf.iIPListCnt);
	for(i=0; i<conf.iIPListCnt; ++i)
	{	fwprintf(f,L"\n%d %d %d %d %d",i,conf.IPList[i].b[0],conf.IPList[i].b[1],conf.IPList[i].b[2],conf.IPList[i].b[3]);
	}
		
	fclose(f);
	return TRUE;
}

VOID FreeConfig()
{
int p;
	if(conf.AdaptersName)//if(((PluginObj*)plgObj)->pAdaptersInfo)
	{	//free(((PluginObj*)plgObj)->pAdaptersInfo);
		for(p=0; p<conf.iNumAdapters; ++p)
			free(conf.pAdaptersIf_addrs[p]);
		free(conf.pAdaptersIf_addrs);
		free(conf.pAdatersIPNums);
		free(conf.AdaptersName);
}	}

BOOL SetOptionsToDlg(HWND hDlg)
{	int i;char *name,*desc;npf_if_addr **pAdAddr;//BYTE addr[4];
	char gateWayIP[4],MAC[6];

	desc = &conf.AdaptersName[0];
	while(*desc != '\0' || *(desc + 1) != '\0')
		desc++;
	desc += 2;	
	name = &conf.AdaptersName[0];
	for(i=0; i<conf.iNumAdapters; ++i)
	{	if(*name == '\0')break;
		SendMessageA(GetDlgItem(hDlg,IDC_COMBO_ADAPTERS),CB_INSERTSTRING,-1,(LPARAM)desc);
		if(GetAdapterMacAndGatewayIP4(MAC,gateWayIP,name))
			SendMessageA(GetDlgItem(hDlg,IDC_COMBO_ADAPTERS_GATEWAY_ADDRESSES),
									CB_INSERTSTRING,-1,
									(LPARAM)inet_ntoa(*((IN_ADDR*)&gateWayIP)));
		name += strlen(name) + 1;
		desc += strlen(desc) + 1;
	}
	SendMessage(GetDlgItem(hDlg,IDC_COMBO_ADAPTERS),CB_SETCURSEL,conf.iCrntAdapter,0);
	SendMessage(GetDlgItem(hDlg,IDC_COMBO_ADAPTERS_GATEWAY_ADDRESSES),CB_SETCURSEL,conf.iCrntAdapter,0);

	pAdAddr = (npf_if_addr**)conf.pAdaptersIf_addrs;			
	for(i=0; i<conf.pAdatersIPNums[conf.iCrntAdapter]; ++i)
	{	npf_if_addr crntAddr = pAdAddr[conf.iCrntAdapter][i];
		IN_ADDR *pAddr = (IN_ADDR*)&crntAddr.IPAddress.__ss_pad1[2];
		SendMessageA(GetDlgItem(hDlg,IDC_COMBO_ADAPTERS_ADDRESSES),
								CB_INSERTSTRING,-1,
								(LPARAM)inet_ntoa(*pAddr));
		pAddr = (IN_ADDR*)&crntAddr.SubnetMask.__ss_pad1[2];
		SendMessageA(GetDlgItem(hDlg,IDC_COMBO_ADAPTERS_SUBNET_MASKS),
								CB_INSERTSTRING,-1,
								(LPARAM)inet_ntoa(*pAddr));
		pAddr = (IN_ADDR*)&crntAddr.Broadcast.__ss_pad1[2];
		SendMessageA(GetDlgItem(hDlg,IDC_COMBO_ADAPTERS_BROADCAST_ADDRESSES),
								CB_INSERTSTRING,-1,
								(LPARAM)inet_ntoa(*pAddr));
	}
	SendMessage(GetDlgItem(hDlg,IDC_COMBO_ADAPTERS_ADDRESSES),CB_SETCURSEL,conf.iCrntAdapterIPAddress,0);
	SendMessage(GetDlgItem(hDlg,IDC_COMBO_ADAPTERS_SUBNET_MASKS),CB_SETCURSEL,conf.iCrntAdapterIPAddress,0);
	SendMessage(GetDlgItem(hDlg,IDC_COMBO_ADAPTERS_BROADCAST_ADDRESSES),CB_SETCURSEL,conf.iCrntAdapterIPAddress,0);
	
	if(conf.iNumAdapters<1)return FALSE;
	SendMessageW(GetDlgItem(hDlg,IDC_COMBO_ADAPTERS_ADDRESSES),CB_GETLBTEXT,
	SendMessage(GetDlgItem(hDlg,IDC_COMBO_ADAPTERS_ADDRESSES),CB_GETCURSEL,0,0),(LPARAM)sA);
	/*p = wcschr(s,'.');
	if(!p)return FALSE;
	*p = 0;
	addr[0] = _wtoi(s);
	pp = p+1;
	p = wcschr(pp,'.');
	if(!p)return FALSE;
	*p = 0;
	addr[1] = _wtoi(s);
	addr[2] = 0;
	addr[3] = 1;*/
	SendMessage(GetDlgItem(hDlg,IDC_IPADDRESS_FROM),IPM_SETADDRESS,0,
		MAKEIPADDRESS(conf.ipFrom.b[0],conf.ipFrom.b[1],conf.ipFrom.b[2],conf.ipFrom.b[3]));//MAKEIPADDRESS(addr[0],addr[1],addr[2],addr[3]));

	//addr[2] = 255;
	//addr[3] = 255;
	SendMessage(GetDlgItem(hDlg,IDC_IPADDRESS_TO),IPM_SETADDRESS,0,
		MAKEIPADDRESS(conf.ipTo.b[0],conf.ipTo.b[1],conf.ipTo.b[2],conf.ipTo.b[3]));//MAKEIPADDRESS(addr[0],addr[1],addr[2],addr[3]));

	SendMessage(GetDlgItem(hDlg,IDC_CHECK_USE_LIST),BM_SETCHECK,conf.bUsePredefinedIPList?BST_CHECKED:BST_UNCHECKED,0);
	SendMessage(GetDlgItem(hDlg,IDC_CHECK_OUT_IP_ADDR),BM_SETCHECK,BST_CHECKED,0);
	SendMessage(GetDlgItem(hDlg,IDC_CHECK_OUT_NAME),BM_SETCHECK,BST_UNCHECKED,0);
	SendMessage(GetDlgItem(hDlg,IDC_CHECK_OUT_GROUP),BM_SETCHECK,BST_UNCHECKED,0);

	SendMessage(GetDlgItem(hDlg,IDC_CHECK_FAST_ICON),BM_SETCHECK,conf.bFasterIcon?BST_CHECKED:BST_UNCHECKED,0);
	return TRUE;
}