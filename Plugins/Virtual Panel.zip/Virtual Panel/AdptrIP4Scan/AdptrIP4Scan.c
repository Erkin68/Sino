#pragma warning(disable:4005)
#pragma warning(disable:4133)
#pragma warning(disable:4995)
#pragma warning(disable:4996)

#include "windows.h"
#include "strsafe.h"
#include "shlobj.h"
#include "Plugins_C.h"
#include "..\..\..\Operations\MyShell\MyShellC.h"



extern wchar_t **strngs;
extern HMODULE plgnDllInst;

saveOptions_t saveOptions=0;
readOptions_t readOptions=0;
addItemToPanelList_t addItemToPanelList=0;
changeItemInPanelList_t changeItemInPanelList=0;
closeEvent_t closeEvent=0;
setPanelPath_t setPanelPath = 0;
//render_t render = 0;
//freePanel_t freePanel = 0;
//selectItem_t selectItem = 0;

int plgId = 0;
BOOL bStop=FALSE;

VOID GetChldPos(HWND,RECT*);

VOID WaitForScan(PluginObj* plg,DWORD waitTime,int stopState)
{
	plg->TermScanThrd = stopState;
	plg->state = (stopState==1?wait_for_stopping:wait_for_stopandexiting);
	if(WAIT_OBJECT_0!=WaitForSingleObject(plg->ScanThrd,waitTime))
	{	TerminateThread(plg->RecvThrd,0);TerminateThread(plg->ScanThrd,0);
		Sleep(25);plg->SendBitTable = NULL;plg->ScanThrd = NULL;
		plg->state = end_scan;
}	}


__declspec (dllexport) VOID SetCallbacks$4xxx(LPVOID frstCallback,...)
{
va_list args;
	va_start(args, frstCallback);//1
	saveOptions = (saveOptions_t)frstCallback;//1
	readOptions = (readOptions_t)va_arg(args, LPVOID);//2
	addItemToPanelList = (addItemToPanelList_t)va_arg(args, LPVOID);//3
	changeItemInPanelList = (changeItemInPanelList_t)va_arg(args, LPVOID);//4
	closeEvent = (closeEvent_t)va_arg(args, LPVOID);//5
	setPanelPath = (setPanelPath_t)va_arg(args, LPVOID);//6
	//render = (render_t)va_arg(args, int);//7
	//freePanel = (freePanel_t)va_arg(args, int);//8
	//selectItem = (selectItem_t)va_arg(args, int);//9	
va_end (args);
}

__declspec (dllexport) int GetPluginType()
{
	return 402;
}

__declspec (dllexport) const wchar_t* GetPluginName()
{
	return strngs[1];
}

__declspec (dllexport) const wchar_t* GetPluginDescription()
{
	return strngs[0];
}

__declspec (dllexport) VOID ShowOptionDialog(HWND prnt)
{
}

__declspec (dllexport) VOID DetachPanel$8(LPVOID plgObj,LPVOID host)
{
int n;BOOL bFind=FALSE;
	
	if(scan==((PluginObj*)plgObj)->state)
	{	//if(IDYES==MessageBox(NULL,strngs[92],strngs[93]/*L"WARN:...",L"Are you want stop scanning..."*/,MB_YESNO))
			WaitForScan((PluginObj*)plgObj,1500,2);//stop and exiting;
		//else return;
	}

	if(iPlgList>0)
	{	for(n=0; n<iPlgList; ++n)
		{	if(plgList[n]==plgObj)
			{	bFind = TRUE;
				break;
		}	}
		if(!bFind)
		{	
		G:	MessageBox(NULL,strngs[98]/*L"Attach/Detach panel count mismatching."*/,strngs[53]/*L"Err..."*/,MB_OK);
			return;
		}
		DestroyWindow(((PluginObj*)plgObj)->tlbrWnd);
		if(((PluginObj*)plgObj)->IPNodes)
		{	//Hammasini confga ko'chiramiz:
			if(conf.IPList) free(conf.IPList);
			conf.iIPListCnt = ((PluginObj*)plgObj)->IPNodesCnt;
			conf.IPList = (IP4BYTE*)malloc(conf.iIPListCnt*sizeof(IP4BYTE));
			for(n=0; n<conf.iIPListCnt; ++n)
				Ip4Shufl(&conf.IPList[n],&((PluginObj*)plgObj)->IPNodes[n]);
			free(((PluginObj*)plgObj)->IPNodes);
			((PluginObj*)plgObj)->IPNodes = NULL;
		}
		if(((PluginObj*)plgObj)->DomainNodes)
		{	free(((PluginObj*)plgObj)->DomainNodes);
			((PluginObj*)plgObj)->DomainNodes = NULL;
		}
		if(((PluginObj*)plgObj)->srchResltBuf)
			free(((PluginObj*)plgObj)->srchResltBuf);//srchResltBufLn=0;
		free(plgObj);//umid qilamizki, Detachni 1 marta chaqiradi;Keyin attach qilishi kerak;
		//plgObj = NULL; befoyda
		if(0==(--iPlgList))
		{	SaveOptions();
			free(plgList);
			plgList=NULL;
			iPlgList=0;
	}	}
	else goto G;
}

__declspec (dllexport) BOOL EventPanelResizing$8(HWND prnt,LPVOID plgObj)
{
RECT rc;
	if(!plgObj)
		return FALSE;
	GetChldPos(prnt,&rc);
	MoveWindow(((PluginObj*)plgObj)->tlbrWnd,rc.left,rc.top,rc.right-rc.left,rc.bottom-rc.top,TRUE);
	return TRUE;
}

__declspec (dllexport) BOOL GetItemPathAndName$16(LPVOID plgObj,wchar_t *buf,int bufln,DWORD itemId)
{
	/*PluginObj *pp = (PluginObj*)plgObj;
	State s = pp->state;
	tDomainNodes* dn = pp->DomainNodes;
	wchar_t *wp = &pp->DomainNodes[itemId].NAME[0];*/

	if(0xffffffff==itemId)//notop item;
		return FALSE;
	//else

	if(itemId>=(DWORD)((PluginObj*)plgObj)->IPNodesCnt)return FALSE;
	/*ln = MyStringCpy(buf,bufln,((PluginObj*)plgObj)->path);
	if('\\'!=buf[ln-1] && '*'!=buf[ln-1])
		buf[ln++] = '\\';
	else if('\\'==buf[ln-1] && '*'==buf[ln-1])
		--ln;*/
	if(in_top==((PluginObj*)plgObj)->state && 
			   ((PluginObj*)plgObj)->DomainNodes &&
		       ((PluginObj*)plgObj)->DomainNodes[itemId].NAME[0])
		return FALSE;//wsprintf(buf,L"\\\\?\\UNC\\%s",((PluginObj*)plgObj)->DomainNodes[itemId].NAME);//return FALSE;
	else
	{	BYTE b[4];
		Ip4Shufl(b,&((PluginObj*)plgObj)->IPNodes[itemId].IP);
		wsprintf(buf,L"\\\\?\\UNC\\%d.%d.%d.%d",b[0],b[1],b[2],b[3]);
	}
	return TRUE;
}

__declspec (dllexport) BOOL GetStrForTooltip$20(LPVOID plgObj,wchar_t *buf,int bufln,DWORD itemId,int *ln)
{
/*	if(((PluginObj*)plgObj)->listcnt > 0)
	{	my_list *lst = (my_list*)itemId;//my_list *lst = my_winx_list_get_entry(((PluginObj*)plgObj)->list,itemId);
		if(!lst)return FALSE;
		if(lst->symbolicLinkName.Buffer[0])
		{	StringCchPrintf(buf,
							bufln,
							L"%s %c%cSymbolicLink: %c%c%s",
							&lst->path.Buffer[0],
							0x0d,0x0a,
							0x0d,0x0a,
							&lst->symbolicLinkName.Buffer[0]);
		}
		else
		{	StringCchPrintf(buf,bufln,L"%s",&lst->path.Buffer[0]);
		}
	}*/
	buf[0] = 0;
	return TRUE;
}

//************************ Yangi protsedurlar: ***************************
//************************ Yangi protsedurlar: ***************************
//************************ Yangi protsedurlar: ***************************
//************************ Yangi protsedurlar: ***************************
//************************ Yangi protsedurlar: ***************************
//************************ Yangi protsedurlar: ***************************
//************************ Yangi protsedurlar: ***************************
//************************ Yangi protsedurlar: ***************************
/*__declspec (dllexport) BOOL EventPanelItemClick$16(HWND prnt,LPVOID plgObj,int itemId,wchar_t *itemName)
{
PluginObj* plg = (PluginObj*)plgObj;
	if(!plg)return FALSE;

	//if(0==wcscmp(itemName,L"192.168.101.2"))//0xc0a86502==ip)
	//	Beep(0,0);


	if(scan==plg->state)
	{	if(1==plg->TermScanThrd)
		{	MessageBox(prnt,L"Please,wait while stopping?",L"Warn...",MB_OK);
			return TRUE;
		}
		if(IDNO==MessageBox(prnt,L"Are you want stop scanning?",L"Warn...",MB_YESNO))
			return TRUE;
		//Stop scanning .....
		WaitForScan(plg,1500,1);
	}
	if(0==itemId || NULL==itemName)
		return FolderUp(plg);
	//else
	return FolderIn(plg,itemId,itemName);
}*/

/*__declspec (dllexport) VOID EventPanelReady$8(HWND prnt,LPVOID plgObj)
{
	if(!plgObj)return;
	if(((PluginObj*)plgObj)->ScanThrd)
		ResumeThread(((PluginObj*)plgObj)->ScanThrd);	 
}*/

void OnTop(PluginObj* plg,wchar_t *oldItemName)
{
int n;WIN32_FIND_DATA fd={FILE_ATTRIBUTE_DIRECTORY};
	//freePanel(plg->host,FALSE);
	for(n=0; n<plg->DomainNodesCnt; ++n)
		addItemToPanelList(plg->host,plg->DomainNodes[n].NAME,NULL,&fd,n,FALSE);//Render oxiriga
	//fd.dwFileAttributes=0;
	for(n=0; n<plg->IPNodesCnt; ++n)
	{	if(!plg->IPNodes[n].NETBIOSGROUPNAME[0])
		{	wchar_t s[32];BYTE bIP[4];Ip4Shufl(&bIP[0],&plg->IPNodes[n].IP);
			wsprintf(s,L"%d.%d.%d.%d",bIP[0],bIP[1],bIP[2],bIP[3]);
			addItemToPanelList(plg->host,s,hIconUnknown,&fd,n,FALSE);//Render oxiriga
	}	}
	plg->state = in_top;
	//render(plg->host);
	if(oldItemName)
	if(oldItemName[0])
	{	//selectItem(plg->host,0,oldItemName);
		SetWindowText(plg->tlbrEditState,oldItemName);
	}
	else SetWindowText(plg->tlbrEditState,L"");
}

void OnDomainGroup(PluginObj *plg,wchar_t *domainGroupPName,wchar_t *oldItemName)
{
int n;BYTE c[32];wchar_t Domain[MAX_PATH],IPStr[32];
WIN32_FIND_DATA fd={FILE_ATTRIBUTE_DIRECTORY};

	//freePanel(plg->host,FALSE);
	for(n=0; n<plg->IPNodesCnt; ++n)
	{	if(plg->IPNodes[n].NETBIOSGROUPNAME[0])
		{	if(0==wcscmp(plg->IPNodes[n].NETBIOSGROUPNAME,domainGroupPName))
			{	Ip4Shufl(&c[0],&plg->IPNodes[n].IP);
				if(plg->IPNodes[n].NETBIOSNAME[0])
					wsprintf(Domain,L"%d.%d.%d.%d - %s",c[0],c[1],c[2],c[3],plg->IPNodes[n].NETBIOSNAME);
				else
					wsprintf(Domain,L"%d.%d.%d.%d",c[0],c[1],c[2],c[3]);
				wsprintf(IPStr,L"%d.%d.%d.%d",c[0],c[1],c[2],c[3]);
				addItemToPanelList(	plg->host,
									Domain,
									IsFolderAccessibleWI(IPStr)?NULL:hIconUnknown,//hIconNotAccess,//NULL,
									&fd,
									n,
									FALSE);
	}	}	}
	plg->state = in_domain_group_folder;
	MyStringCpy(plg->crntDomainGroup,MAX_PATH,domainGroupPName);
	//render(plg->host);
	if(oldItemName)
	if(oldItemName[0])
	{	//selectItem(plg->host,0,oldItemName);
		wsprintf(Domain,L"%s\\%s",domainGroupPName,oldItemName);
		SetWindowText(plg->tlbrEditState,Domain);
	}
	else SetWindowText(plg->tlbrEditState,domainGroupPName);	
}

wchar_t* GetPanelItemName(PluginObj *plg,int nodeNum,int type,wchar_t *path)
{
static wchar_t s[MAX_PATH];BYTE b[4];
	Ip4Shufl(&b[0],&plg->IPNodes[nodeNum].IP);
	switch(type)
	{	case 0:
			wsprintf(s,L"%d.%d.%d.%d\\",b[0],b[1],b[2],b[3]);
			break;
		case 1://in domain group:
			if(plg->IPNodes[nodeNum].NETBIOSNAME[0])
				wsprintf(s,L"%d.%d.%d.%d - %s",b[0],b[1],b[2],b[3],plg->IPNodes[nodeNum].NETBIOSNAME);
			else
				wsprintf(s,L"%d.%d.%d.%d",b[0],b[1],b[2],b[3]);
			break;
	}
	return &s[0];
}

/*BOOL FolderUp(PluginObj* plg)
{
wchar_t *p,*pp,oldItem[MAX_PATH]=L"";
int n;char ipstrA[32];
DWORD dwPanelPathIP;

	if(!plg->bEntrScan)
	{	n = FolderUpNode(plg,0);
		return n==0 ? TRUE:FALSE;
	}

	//Agar 1- marta bu yerga kelayotgan bo'lsa:
	switch(plg->state)
	{	case end_scan:
		case in_domain_group_folder:
			OnTop(plg,plg->crntDomainGroup);
			return TRUE;
		case in_top:
			closeEvent(plgId,plg->host);
			//DetachPanel$8((LPVOID)plg,plg->host);
			return TRUE;
		case in_foldersEnum:
			p = wcsrchr(plg->path,'\\');
			if(p)
			{	*p = 0;
				pp = wcsrchr(plg->path,'\\');
				if(pp)MyStringCpy(oldItem,MAX_PATH,pp+1);
				*p = '\\';
			}					
			n = FolderUpNode((LPVOID)plg,0);
			if(-1==n)
			{	plg->state = in_WNetEnumResource;
				if(MyInet4StrToDword(&plg->path[2],&ipstrA[0],&dwPanelPathIP))
				{	FirstEntranceNode(plg,-1,dwPanelPathIP);
					if(oldItem[0])
						selectItem(plg->host,0,oldItem);
				}
				return TRUE;
			}
			else
			{	//if(oldItem[0])
				//	selectItem(plg->host,0,oldItem);
				if(!n) return TRUE;
			}
			return FALSE;
		case in_WNetEnumResource:
			MyInet4StrToDword(&plg->path[2],&ipstrA[0],&dwPanelPathIP);
			if(!GetNodeGroupName(plg,dwPanelPathIP,&n))
				OnTop(plg,plg->crntDomainGroup);
			else
			{	if(plg->IPNodes[n].NETBIOSGROUPNAME)
					OnDomainGroup(plg,plg->IPNodes[n].NETBIOSGROUPNAME,GetPanelItemName(plg,n,1,NULL));
				else
					OnTop(plg,plg->IPNodes[n].NETBIOSGROUPNAME);
			}
			return FALSE;
	}
	return FALSE;
}*/

//IP4 va nomi,domaini ajratish:
BOOL DistrItemName(wchar_t* itemName,DWORD *dwIP,wchar_t* Name,wchar_t* Domain)
{
/*int ipn=0,ln=0;wchar_t s[32],*p = itemName,*pOld=p;BYTE ip[4];
	for(ln=0; (*p) && ln<80; ++ln)
	{	if((*p)<'0' || (*p)>'9')
		{	if(ipn<4 && '.'!=(*p)) return FALSE;
			wcsncpy(s,pOld,p-pOld);
			s[p-pOld]=0;
			ip[ipn]=_wtoi(s);
			pOld = p+1;
			if(++ipn > 3)
				break;
			if((*pOld)<'0' || (*pOld)>'9')return FALSE;
		}
		++p;
	}
	if(ipn<4)
	{	wcsncpy(s,pOld,p-pOld);
		s[p-pOld]=0;
		ip[ipn]=_wtoi(s);
		pOld = p+1;
	}*/
	unsigned long l;char c[64];
	wchar_t s[32],*p = wcschr(itemName,'-');
	if(!p)
	{	WideCharToMultiByte(CP_ACP,0,itemName,-1,c,64,NULL,NULL);
		l = inet_addr(c);
		if(INADDR_NONE==l) return FALSE;
		*dwIP = l;
		Name[0] = 0;
		Domain[0] = 0;
		return TRUE;
	}
	//else:
	wcsncpy(s,itemName,p-itemName-1);
	s[p-itemName-1] = 0;
	WideCharToMultiByte(CP_ACP,0,s,-1,c,64,NULL,NULL);
	l = inet_addr(c);
	if(INADDR_NONE==l) return FALSE;
	*dwIP = l;

	wcscpy(Name,p+1);

	//Oxirini topamiz:
	p = wcsrchr(Name,'{');
	if(!p)//Not domain name defined:
	{	*Domain = 0;
		return TRUE;
	}
	*(p-1) = 0;
	//else:

	wcscpy(Domain,p+1);
	p = wcsrchr(Domain,'}');
	if(p)
		*p = 0;
	return TRUE;
}

/*BOOL FolderIn(PluginObj* plg,int itemId,wchar_t *itemName)
{
//IP4BYTE Ip;
int n;wchar_t Name[32],Domain[128];
DWORD dwIP;BOOL bDomainName=FALSE;
	int s=plg->state;

	//if(!plg->bEntrScan)
	{	n = FolderInNode(plg,itemId,itemName);
		return n==0 ? TRUE:FALSE;
	}

	switch(plg->state)
	{	case end_scan:
			if(0==itemId) return FALSE;
			if(NULL==itemName) return FALSE;
			if(!DistrItemName(itemName,&dwIP,&Name[0],&Domain[0])) return FALSE;
			if((!Name[0]) || (!Domain[0]))
			{	//dwIP = 0xc0a80e10;//0xc0a865be;
				//Ip4Shufl(&Ip.b[0],&dwIP);
				//GetIndividuallyHostAndDomainNameViaGate(plg,Ip);
				//RetriveHostNameAndDomainName(plg,itemId,L"192.168.14.10");//101.190");//itemIPName);
			}
			FirstEntranceNode(plg,itemId,dwIP);
			return TRUE;
		case in_top:
			for(n=0; n<plg->DomainNodesCnt; ++n)
			{	if(0==wcscmp(plg->DomainNodes[n].NAME,itemName))
					{bDomainName=TRUE;break;}//yes,domain;
			}
			if(bDomainName)
			{	OnDomainGroup(plg,itemName,NULL);
				return TRUE;
			}
			return TRUE;//NodeSambaViaGate(plg,itemId,itemName);
		case in_WNetEnumResource:
			if(0==FolderInNode(plg,itemId,itemName))
			{	plg->state = in_foldersEnum;
				return FALSE;
			}
			return FALSE;
		case in_foldersEnum:
			if(0==FolderInNode(plg,itemId,itemName))
				return TRUE;
			return FALSE;
		case in_domain_group_folder:
			if(0==itemId) return FALSE;
			if(NULL==itemName) return FALSE;
			if(!DistrItemName(itemName,&dwIP,&Name[0],&Domain[0])) return FALSE;
			FirstEntranceNode(plg,itemId,dwIP);
			return TRUE;
	}
	return FALSE;
}*/

#define plg ((PluginObj*)plgObj)
__declspec (dllexport) BOOL GetReadyForEnumDir$12(HWND prnt,LPVOID plgObj,wchar_t *path)
{
int l;char inetStrA[32];DWORD dwIp;HANDLE hf;WIN32_FIND_DATA fd;//wchar_t *p;
wchar_t pth[MAX_PATH];
	if(scan==plg->state)
	{	if(IDYES!=MessageBox(prnt,strngs[103]/*L"Scanning is progress..."*/,
							 strngs[93]/*L"Are you want to stop scanning."*/,MB_YESNO))
			return FALSE;
		WaitForScan(plg,15000,1);//onlystopping
		//path ni analyze qilamiz:
		if(wcsstr(path,L"\\\\?\\UNC\\"))
			return MyInet4StrToDword(&path[8],inetStrA,&dwIp);
	}
	if(path)
	if(path[0]==0)
		return TRUE;//Bgn scan;

	if(wcsstr(path,L"\\\\?\\UNC\\"))
	{	BOOL b = MyInet4StrToDword(&path[8],inetStrA,&dwIp);
		l = MyStringLengthA(inetStrA,32);
		if(path[8+l]==0)//Korennoy:
			return IsFolderAccessibleWI(&path[8]);//TRUE
		else if('\\'==path[8+l] && '*'==path[9+l] && 0==path[10+l])//Komanda qatoridan kiritgan:
			return TRUE;
		//p = wcsrchr(&path[8+l],'\\');
		//if(!p)return FALSE;
		l=MyStringCpy(pth,MAX_PATH,path);
		if('\\'!=pth[l-1] && '*'!=pth[l-1])
			{pth[l++] = '\\';pth[l++] = '*';pth[l] = 0;}
		else if('\\'==pth[l-1])
			{pth[l++] = '*';pth[l] = 0;}
		hf = FindFirstFile(pth,&fd);
		if(INVALID_HANDLE_VALUE==hf)
		{	if(path[8]<'0' || path[8] > '9')
			if(plg->state=in_top)
				return TRUE;
			return b;//FALSE; Korennoy
		}
		FindClose(hf);
		return TRUE;
	}
	if(plg->IPNodes && wcsstr(path,L"\\\\?\\UNC"))//Global setga:
		return TRUE;
	if('\\'==path[0] && '\\'==path[1] && '?'==path[2] && 0==path[3])
		return TRUE;
	return FALSE;
}
__declspec (dllexport) BOOL EnumDir$12(HWND prnt,LPVOID plgObj,wchar_t *path)
{
int l;char inetStrA[32];DWORD dwIp;HANDLE hf;WIN32_FIND_DATA fd;//wchar_t *p;
wchar_t *p,pth[MAX_PATH];
	if(attachForScan==plg->state)//(((!path) || 0==path[0]) && plg->trd)
	{	if(plg->trd)
		{	plg->ScanThrd = CreateThread(NULL,0,plg->trd,plg,0,&plg->ScanThrdId);
			if(!plg->ScanThrd)
			{	DestroyWindow(plg->tlbrWnd);
				free(plg);
				MessageBoxW(NULL,strngs[99]/*L"Err. creating thread..."*/,strngs[100]/*L"Scanning for IP4..."*/,MB_OK);
				return FALSE;
			}
			setPanelPath(plg->host,L"\\\\?\\UNC\\*",10);
			plg->pathLn=MyStringCpy(plg->path,10,L"\\\\?\\UNC\\*");
			return TRUE;
		}
		else return FALSE;
	}

	if(wcsstr(path,L"\\\\?\\UNC\\"))
	{	BOOL b = MyInet4StrToDword(&path[8],inetStrA,&dwIp);
		l = MyStringLengthA(inetStrA,32);
		if(path[8+l]==0 ||//Korennoy:
		  ('\\'==path[8+l] && '*'==path[9+l] && 0==path[10+l]))//Komanda qatoridan kiritgan:
		{	//if(plg->IPNodes)
				return 0==FirstEntranceNode(plg,0,dwIp);
			//else 0==FirstEntranceNode(plg,0,dwIp); hozircha shu;
		}
		//p = wcsrchr(&path[8+l],'\\');
		//if(!p)return FALSE;
		l=MyStringCpy(pth,MAX_PATH,path);
		if('\\'==pth[l-1])
			{pth[l++] = '*';pth[l] = 0;}
		else if('\\'!=pth[l-1] && '*'!=pth[l-1])
			{pth[l++] = '\\';pth[l++] = '*';pth[l] = 0;}
		hf = FindFirstFile(pth,&fd);
		if(INVALID_HANDLE_VALUE==hf)
		{	if(path[8]<'0' || path[8] > '9')
			if(plg->state==in_top)
			{	p = wcsrchr(&pth[8],'\\');
				if(p) *p = 0;
				OnDomainGroup(plg,&pth[8],NULL);
				if(p) *p = '\\';
				plg->pathLn=MyStringCpy(plg->path,MAX_PATH,pth);
				setPanelPath(plg->host,pth,plg->pathLn);
				return TRUE;
			}
			if(b) return 0==FirstEntranceNode(plg,0,dwIp);
			return FALSE;
		}
		FindClose(hf);
		plg->pathLn=MyStringCpy(plg->path,MAX_PATH,pth);
		setPanelPath(plg->host,pth,plg->pathLn);
		return 0==FolderList(plg,pth);
	}
	if(wcsstr(path,L"\\\\?\\UNC"))//Global setga:
	{	//eski pathidan elementini topamiz:
		BOOL b = MyInet4StrToDword(plg->path,inetStrA,&dwIp);
		if(b)
		{	DWORD ip;Ip4Shufl(&ip,(BYTE*)&dwIp);
			l=GetNodeFromPlgList(plg,ip);
		}
		if(b && l>-1)
		{	if(plg->IPNodes[l].NETBIOSGROUPNAME[0])
				OnTop(plgObj,plg->IPNodes[l].NETBIOSGROUPNAME);
			else if(plg->IPNodes[l].NETBIOSNAME[0])
				OnTop(plgObj,plg->IPNodes[l].NETBIOSNAME);
			else
				OnTop(plgObj,L"");
		}
		else OnTop(plgObj,L"");
		plg->pathLn=MyStringCpy(plg->path,10,L"\\\\?\\UNC\\*");
		setPanelPath(plg->host,L"\\\\?\\UNC\\*",9);
		return TRUE;
	}
	if('\\'==path[0] && '\\'==path[1] && '?'==path[2] && 0==path[3])
	{	OnTop(plgObj,L"");
		plg->pathLn=MyStringCpy(plg->path,10,L"\\\\?\\UNC\\*");
		setPanelPath(plg->host,L"\\\\?\\UNC\\*",9);
	}
	return FALSE;
}
#undef plg