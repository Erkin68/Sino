#include "windows.h"
#include "..\..\..\..\..\Include\d3dx9.h"


extern "C"
{
extern HWND hWndPnl;
extern wchar_t path[MAX_PATH];
extern int pathLn;

typedef unsigned __int64 u64;
#define HALFPI 1.5707963267948966192313216916398f
#define TWOHALFPI 7.8539816339744830961566084581988f
#define DrawDirTimerId 88888

typedef struct TDIR_REC
{	WIN32_FIND_DATA ff;
	float kSc;
	float y,z;
	float r,g,b;
	int iFiles;
	u64 sz64;
}DIR_REC,*PDIR_REC;
extern PDIR_REC pDirs;

extern int iRootDirs,iRootFiles,iTotDirs,iTotFiles;
extern u64 szRootFiles64,totsz64;
extern BOOL bThreadRun,bStop,bStopThread,bSorted,bTimerInstalled;
extern float dt;
extern int iMove;

extern VOID CreateCylinder();
extern VOID CalcDirScales();
extern VOID PlaceDirCyls();
extern int  cmpDirFunc(const void*,const void*);
extern VOID CalcRGBs();
extern VOID OnLostDevice();
extern VOID InitDeviceObjects();
extern VOID InvalidateDeviceObjects();
extern VOID RestoreDeviceObjects();


extern int iDirs;

typedef struct TCUSTOMVERTEX
{	D3DXVECTOR3 position; // The position.
	D3DXVECTOR3 normal;
	//D3DCOLOR  color;    // The color.
    FLOAT     tu, tv;   // The texture coordinates.
}CUSTOMVERTEX;
//CUSTOMVERTEX CylVerts[100];
#define D3DFVF_CUSTOMVERTEX (D3DFVF_XYZ|D3DFVF_NORMAL|D3DFVF_TEX1)//D3DFVF_DIFFUSE
}