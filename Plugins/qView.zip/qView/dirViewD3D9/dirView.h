#include "windows.h"

typedef unsigned __int64 u64;
#define HALFPI 1.5707963267948966192313216916398f
#define TWOHALFPI 7.8539816339744830961566084581988f
#define DrawDirTimerId 88888

typedef struct TDIR_REC
{	WIN32_FIND_DATA ff;
	float kSc;
	float y,z;
	float r,g,b;
	int iFiles;
	u64 sz64;
}DIR_REC,*PDIR_REC;
//extern float worldRadius;

extern wchar_t path[MAX_PATH];
extern int pathLn;

extern HWND hWndPnl;
extern RECT rcClient;

extern wchar_t **strngs;
extern HMODULE plgnDllInst;

extern int iRootDirs,iRootFiles,iTotDirs,iTotFiles;
extern u64 szRootFiles64,totsz64;

extern BOOL bThreadRun,bStop,bStopThread,bSorted,bTimerInstalled;
extern float dt;
extern int iMove;

extern VOID DirThrd();
extern VOID WaitForThrd();

extern BOOL InitD3D9();
extern VOID CleanupD3D9();
extern VOID Cleanup3DDevice9();
extern BOOL Init3DDevice9(HWND);
extern BOOL RenderDirs(BOOL);
extern VOID OnLostDevice();
extern VOID InitDeviceObjects();
extern VOID InvalidateDeviceObjects();
extern VOID RestoreDeviceObjects();

//FFiles:
extern BOOL ListFiles(wchar_t*);
extern BOOL FreeFilesList();
extern BOOL AddToFileList(wchar_t*,PWIN32_FIND_DATA,int);
extern VOID CalcDirScales();
extern int  cmpDirFunc(const void*,const void*);
extern VOID PlaceDirCyls();
extern VOID CalcRGBs();