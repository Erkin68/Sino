#include "dirView.h"
#include "strsafe.h"
#include "shlobj.h"


wchar_t path[MAX_PATH]=L"";
int pathLn=0;
typedef BOOL (CALLBACK *saveOptions_t)(int,VOID*,int);
typedef BOOL (CALLBACK *readOptions_t)(int,VOID*,int);

saveOptions_t saveOptions=0;
readOptions_t readOptions=0;

int plgId = 0;
BOOL bStop=FALSE;
WIN32_FIND_DATAW pFindFileData;

__declspec (dllexport) VOID SetCallbacks$4xxx(LPVOID frstCallback,...)
{
va_list args;
	va_start(args, frstCallback);//1
	saveOptions = (saveOptions_t)frstCallback;//1
	readOptions = (readOptions_t)va_arg(args, LPVOID);//2
va_end (args);
}

__declspec (dllexport) int GetPluginType()
{
	return 502;
}

__declspec (dllexport) const wchar_t* GetPluginName()
{
	return strngs[1];
}

__declspec (dllexport) const wchar_t* GetExtensions()
{
	return L"..";
}

__declspec (dllexport) VOID SetId$4(int id)
{
	plgId = id;
}

__declspec (dllexport) const wchar_t* GetPluginDescription()
{
	return strngs[1];
}

__declspec (dllexport) VOID ShowOptionDialog(HWND prnt)
{
}