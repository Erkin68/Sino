#include <math.h>
#include "dirView.h"
#include "..\..\..\Operations\MyShell\MyShellC.h"


PDIR_REC pDirs=NULL;
int iDirs=0;
int iRootDirs,iRootFiles,iTotDirs,iTotFiles;
u64 szRootFiles64,totsz64;

BOOL ExpandDirRec(PWIN32_FIND_DATA pf,int iDirRec)
{	//u64 sz = ((u64)pDirs[iDirRec].ff.nFileSizeHigh << 32) | pDirs[iDirRec].ff.nFileSizeLow;
	u64 szA = ((u64)pf->nFileSizeHigh << 32) | pf->nFileSizeLow;
	//sz += szA;
	if(!pDirs)return FALSE;
	pDirs[iDirRec].sz64 += szA;
	++pDirs[iDirRec].iFiles;
	totsz64 += szA;
	//pDirs[iDirRec].ff.nFileSizeHigh = pDirs[iDirRec].sz64 >> 32;
	//pDirs[iDirRec].ff.nFileSizeLow = pDirs[iDirRec].sz64 & 0xffffffff;
	RenderDirs(TRUE);
	return TRUE;
}

BOOL ListDir(wchar_t* pth,int iDirsInList)
{
	wchar_t s[MAX_PATH];
	WIN32_FIND_DATA ff;
	HANDLE hf = INVALID_HANDLE_VALUE;
	int l=MyStringCpy(s,MAX_PATH-1,pth);
	if('*'!=s[l-1])
	{	if('\\'!=s[l-1])
		{	s[l++]='\\';
			s[l++]='*';
			s[l]=0;
		}
		else
		{	s[l++]='*';
			s[l]=0;
	}	}
	else --l;

	hf = MyFindFirstFileEx(pth,FindExInfoStandard,&ff,FindExSearchLimitToDirectories,NULL,0);
	do
	{	if(INVALID_HANDLE_VALUE==hf) return FALSE;
		if(FILE_ATTRIBUTE_DIRECTORY & ff.dwFileAttributes)//if(IsDirectory(path, &ff, FALSE))
		{	if(IsCrntOrPrntDirAttrbW(ff.cFileName))
			{	int n=MyStringCpy(&s[l],MAX_PATH-1,ff.cFileName);
				MyStringCpy(&s[l+n],MAX_PATH-1-l,L"\\*");
				ListDir(s,iDirsInList);
				++iTotDirs;
		}	}
		else
		{	ExpandDirRec(&ff,iDirsInList);			
			++iTotFiles;
	}	}
	while(FindNextFile(hf, &ff));
	FindClose(hf);
	return TRUE;
}

BOOL ListFiles(wchar_t* pth)
{
	wchar_t s[MAX_PATH]=L"";
	WIN32_FIND_DATA ff;
	HANDLE hf = INVALID_HANDLE_VALUE;
	int l=MyStringCpy(s,MAX_PATH-1,pth);
	if('*'!=s[l-1])
	{	if('\\'!=s[l-1])
		{	s[l++]='\\';
			s[l]='*';
			s[l+1]=0;
		}
		else
		{	s[l]='*';
			s[l+1]=0;
	}	}
	else --l;

	/*if(IsDirExist(s))
	{	ff.dwFileAttributes=16;ff.nFileSizeHigh=ff.nFileSizeLow=0;
		AddToFileList(s,&ff,l);
		ListDir(s,iDirs-1);//iDirs 1ta oldinda oshirilgan edi;
		return TRUE;
	}*/

	iRootDirs=iRootFiles=iTotDirs=iTotFiles=0;
	szRootFiles64=totsz64=0;
	ff.cFileName[0]=0;
	hf = MyFindFirstFileEx(s,FindExInfoStandard,&ff,FindExSearchLimitToDirectories,NULL,0);
	do
	{	if(INVALID_HANDLE_VALUE==hf) return FALSE;
		if(FILE_ATTRIBUTE_DIRECTORY & ff.dwFileAttributes)//if(IsDirectory(path, &ff, FALSE))
		{	if(IsCrntOrPrntDirAttrbW(ff.cFileName))
			{	int n;AddToFileList(s,&ff,l);
				n=MyStringCpy(&s[l],MAX_PATH-1,ff.cFileName);
				s[l+n]='\\';s[l+n+1]='*';s[l+n+2]=0;//MyStringCpy(&s[l+n],MAX_PATH-1-l,L"\\*");
				ListDir(s,iDirs-1);//iDirs 1ta oldinda oshirilgan edi;
				++iRootDirs;
				++iTotDirs;
		}	}
		else
		{	u64 sz = ((u64)ff.nFileSizeHigh << 32) | ff.nFileSizeLow;
			AddToFileList(s,&ff,l);
			++iRootFiles;
			++iTotFiles;
			szRootFiles64 += sz;
			totsz64 += sz;
		}ff.cFileName[0]=0;
	}
	while(FindNextFile(hf, &ff));
	FindClose(hf);
	return TRUE;
}

BOOL AddToFileList(wchar_t *pth,PWIN32_FIND_DATA pf,int l)
{	int L;
	if(pDirs)
		pDirs=(PDIR_REC)realloc(pDirs,sizeof(DIR_REC)*(iDirs+1));
	else
		pDirs=(PDIR_REC)malloc(sizeof(DIR_REC)*(iDirs+1));
	if(!pDirs)
	{	int e=GetLastError();
		return FALSE;
	}
	L=MyStringCpy(pDirs[iDirs].ff.cFileName,l,pth);
	if('*'==pDirs[iDirs].ff.cFileName[L-1] && '\\'==pDirs[iDirs].ff.cFileName[L-2])
		--L;
	else if('\\'!=pDirs[iDirs].ff.cFileName[L-1])
		pDirs[iDirs].ff.cFileName[L++]='\\';
	MyStringCpy(&pDirs[iDirs].ff.cFileName[L],l,pf->cFileName);
	MyStringCpy(pDirs[iDirs].ff.cAlternateFileName,l,pf->cAlternateFileName);
	pDirs[iDirs].ff.dwFileAttributes = pf->dwFileAttributes;
	pDirs[iDirs].ff.ftCreationTime = pf->ftCreationTime;
	pDirs[iDirs].ff.ftLastAccessTime = pf->ftLastAccessTime;
	pDirs[iDirs].ff.ftLastWriteTime = pf->ftLastWriteTime;
	//pDirs[iDirs].ff.nFileSizeHigh = pf->nFileSizeHigh;
	//pDirs[iDirs].ff.nFileSizeLow = pf->nFileSizeLow;
	pDirs[iDirs].sz64 = ((u64)pf->nFileSizeHigh << 32) | pf->nFileSizeLow;
	pDirs[iDirs].ff.dwReserved0 = pf->dwReserved0;
	pDirs[iDirs].ff.dwReserved1 = pf->dwReserved1;
	pDirs[iDirs].iFiles = 0;
	++iDirs;
	RenderDirs(TRUE);
	return TRUE;
}

BOOL FreeFilesList()
{	if(pDirs)free(pDirs);
	pDirs=0;
	iDirs=0;
	return TRUE;
}

VOID CalcDirScales()//sortirovka va kSc ni hisoblash:
{	int i;u64 maxSz;if(0==iDirs)return;
	//u64 minSz=pDirs[0].sz64;
	maxSz = pDirs[0].sz64;
	for(i=1; i<iDirs; ++i)
	{	//if(pDirs[i].sz64 < minSz)minSz = pDirs[i].sz64;
		if(pDirs[i].sz64 > maxSz)maxSz = pDirs[i].sz64;
	}
	for(i=0; i<iDirs; ++i)
	{	if(0==maxSz)
			pDirs[i].kSc = 1.75f;
		else
			pDirs[i].kSc = 0.05f+1.7f*(float)(double)pDirs[i].sz64/maxSz;
}	}

int cmpDirFunc(const void* dir1, const void*dir2)
{	if(((PDIR_REC)dir1)->sz64>((PDIR_REC)dir2)->sz64)
		return -1;
	if(((PDIR_REC)dir1)->sz64<((PDIR_REC)dir2)->sz64)
		return 1;
	return 0;
}

VOID PlaceDirCyls()
{	//int i;float deltaAngle = 6.283185307f / iDirs;
	//if(iDirs<1)worldRadius=0.0f;
	//else worldRadius = 0.45f * iDirs / 3.14159265f;
	int i;float height = 2.0f;
	for(i=0; i<iDirs; ++i)
	{	pDirs[i].z = i*0.12f;
		pDirs[i].y = 1.5f + height * cosf(1.57f + i*0.15f) - i * 0.05f;//deltaAngle);
		height -= 0.05f;
		//pDirs[i].x = 0.0f;//worldRadius * cosf(i * deltaAngle);
}	}

VOID CalcRGBs()
{	int i,iRgb=0;float r=0.0f,g=1.0f,b=0.0f;
	for(i=0; i<iDirs; ++i)
	{	if(0==iRgb%3){r+=0.25f;if(r>1.0f)r=0.0f;}
		else if(1==iRgb%3){g+=0.25f;if(g>1.0f)g=0.0f;}
		else {b+=0.25f;if(b>1.0f)b=0.0f;}
		pDirs[i].r = r;
		pDirs[i].g = g;
		pDirs[i].b = b;
		if(++iRgb>12)iRgb=0;
}	}