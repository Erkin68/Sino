#pragma comment(lib, "..\\..\\..\\Bin\\MyShell64.lib")

#include "d3d9.h"
#include "dirViewC++.h"
#include "..\..\..\DX8\Common\Include\d3dfont.h"
#include "..\..\..\Operations\MyShell\MyShell.h"
#include "strsafe.h"

inline DWORD FtoDW( FLOAT f ) { return *((DWORD*)&f); }

extern "C"
{


LPDIRECT3D9 pD3D = NULL;
LPDIRECT3DDEVICE9 pd3dDevice = NULL;
D3DXMATRIX matWorld,matView,matProj;
D3DXVECTOR3 vUpVec = D3DXVECTOR3(0.0f,1.0f,0.0f);
//LPDIRECT3DTEXTURE8 pTexture = NULL;
LPDIRECT3DVERTEXBUFFER9 pVB = NULL;
//ID3DXFont* pFont = NULL;
CD3DFont* pFont;
//float worldRadius=0.0f;

BOOL bTimerInstalled=FALSE;
BOOL bSorted = FALSE;
float dt=1.57079632679f;int iMove=0;

BOOL RenderDirs(BOOL);

VOID __cdecl m_VectorF_sub_VectorF_C(float *result, float *vA, float *vB)
{
	result[0] = vA[0] - vB[0];
	result[1] = vA[1] - vB[1];
	result[2] = vA[2] - vB[2];
	return;
}

VOID __cdecl m_VectorF_x_VectorF_C(float *result, float *vA, float *vB)
{
	result[0] = vA[0] * vB[0];
	result[1] = vA[1] * vB[1];
	result[2] = vA[2] * vB[2];
	return;
}

VOID __cdecl m_VectorF_x_F32_C( float *result, float *vA, float B)
{
	result[0] = vA[0] * B;
	result[1] = vA[1] * B;
	result[2] = vA[2] * B;
	return;
}

float m_Dot(float *p1, float *p2)
{
	return (p1[0]*p2[0] + p1[1]*p2[1] + p1[2]*p2[2]);
}

VOID __cdecl m_Cross(float *res, float *a, float *b)
{
	res[0] = a[1] * b[2] - a[2] * b[1];
	res[1] = a[2] * b[0] - a[0] * b[2];
	res[2] = a[0] * b[1] - a[1] * b[0];
	return;
}

FLOAT Dot(FLOAT *p1, FLOAT *p2)
{
	return (p1[0]*p2[0] + p1[1]*p2[1] + p1[2]*p2[2]);
}
VOID Cross(FLOAT *res, FLOAT *a, FLOAT *b)
{
	res[0] = a[1] * b[2] - a[2] * b[1];
	res[1] = a[2] * b[0] - a[0] * b[2];
	res[2] = a[0] * b[1] - a[1] * b[0];
	return;
} 

VOID lookAtLH(FLOAT *m, FLOAT *peye, FLOAT *pcenter, FLOAT *pup)
{
	FLOAT x[3], y[3], z[3];
	FLOAT mag;

	z[0] = pcenter[0] - peye[0];//vView
	z[1] = pcenter[1] - peye[1];//vView
	z[2] = pcenter[2] - peye[2];//vView

	mag = sqrtf(Dot(&z[0],&z[0]));
	if(0.001f<mag)//0.0f ham 0x000000000 b-di;
	{	mag = 1.0f / mag;
		z[0] *= mag;
		z[1] *= mag;
		z[2] *= mag;
	}

	y[0] = pup[0];//vUp
	y[1] = pup[1];
	y[2] = pup[2];

	Cross(&x[0], &y[0], &z[0]);//vRight
	Cross(&y[0], &z[0], &x[0]);//recalc vUp 

	mag = sqrtf(Dot(&x[0], &x[0]));
	if(0.001f<mag)
	{	mag = 1.0f / mag;
		x[0] *= mag;
		x[1] *= mag;
		x[2] *= mag;
	}

	mag = sqrtf(Dot(&y[0], &y[0]));
	if(mag) 
	{	mag = 1.0f / mag;
		y[0] *= mag;
		y[1] *= mag;
		y[2] *= mag;
	}

	m[0] = x[0];
	m[1] = y[0];
	m[2] = z[0];
	m[3] = 0.0f;

	m[4] = x[1];
	m[5] = y[1];
	m[6] = z[1];
	m[7] = 0.0f;

	m[8] = x[2];
	m[9] = y[2];
	m[10]= z[2];
	m[11]= 0.0f;

	FLOAT row1[3], row2[3], row3[3];

	row1[0] = peye[0] * x[0];
	row1[1] = peye[1] * x[1];
	row1[2] = peye[2] * x[2];

	row2[0] = peye[0] * y[0];
	row2[1] = peye[1] * y[1];
	row2[2] = peye[2] * y[2];

	row3[0] = peye[0] * z[0];
	row3[1] = peye[1] * z[1];
	row3[2] = peye[2] * z[2];

	m[12]= - row1[0] - row1[1] - row1[2];
	m[13]= - row2[0] - row2[1] - row2[2];
	m[14]= - row3[0] - row3[1] - row3[2];;
	m[15]= 1.0f;

	return;
}

VOID PerspectiveFovLH(FLOAT *m,FLOAT fovY,FLOAT Aspect,FLOAT zn,FLOAT zf)
{
	FLOAT yScale = 1.0f / tan(0.5f * fovY);
	FLOAT xScale = yScale / Aspect;

	m[0] = xScale;
	m[4] = 0.0f;
	m[8] = 0.0f;
	m[12]= 0.0f;

	m[1] = 0.0f;
	m[5] = yScale;
	m[9] = 0.0f;
	m[13]= 0.0f;

	m[2] = 0.0f;
	m[6] = 0.0f;
	m[10]= zf/(zf-zn);
	m[14]= -zn*zf/(zf-zn);

	m[3] = 0.0f;
	m[7] = 0.0f;
	m[11]= 1;
	m[15]= 0.0f;
}

VOID m_matF_x_matF(FLOAT *mresult, FLOAT *a, FLOAT *b)
{
FLOAT m[16];
	m[0] = a[0]*b[0] + a[1]*b[4] + a[2]*b[8 ] + a[3]*b[12];
	m[1] = a[0]*b[1] + a[1]*b[5] + a[2]*b[9 ] + a[3]*b[13];
	m[2] = a[0]*b[2] + a[1]*b[6] + a[2]*b[10] + a[3]*b[14];
	m[3] = a[0]*b[3] + a[1]*b[7] + a[2]*b[11] + a[3]*b[15];

	m[4] = a[4]*b[0] + a[5]*b[4] + a[6]*b[8 ] + a[7]*b[12];
	m[5] = a[4]*b[1] + a[5]*b[5] + a[6]*b[9 ] + a[7]*b[13];
	m[6] = a[4]*b[2] + a[5]*b[6] + a[6]*b[10] + a[7]*b[14];
	m[7] = a[4]*b[3] + a[5]*b[7] + a[6]*b[11] + a[7]*b[15];

	m[8] = a[8]*b[0] + a[9]*b[4] + a[10]*b[8 ] + a[11]*b[12];
    m[9] = a[8]*b[1] + a[9]*b[5] + a[10]*b[9 ] + a[11]*b[13];
	m[10]= a[8]*b[2] + a[9]*b[6] + a[10]*b[10] + a[11]*b[14];
	m[11]= a[8]*b[3] + a[9]*b[7] + a[10]*b[11] + a[11]*b[15];

	m[12] = a[12]*b[0] + a[13]*b[4] + a[14]*b[8 ] + a[15]*b[12];
	m[13] = a[12]*b[1] + a[13]*b[5] + a[14]*b[9 ] + a[15]*b[13];
	m[14]= a[12]*b[2] + a[13]*b[6] + a[14]*b[10] + a[15]*b[14];
	m[15]= a[12]*b[3] + a[13]*b[7] + a[14]*b[11] + a[15]*b[15];

	for(int i=0; i<16; i++)
		mresult[i] = m[i];
	return;
}

VOID MatrixScaling(FLOAT *m, FLOAT scx, FLOAT scy, FLOAT scz)
{
	m[0] = scx;
	m[1] = 0.0f;
	m[2] = 0.0f;
	m[3] = 0.0f;

	m[4] = 0.0f;
	m[5] = scy;
	m[6] = 0.0f;
	m[7] = 0.0f;

	m[8] = 0.0f;
	m[9] = 0.0f;
	m[10]= scz;
	m[11]= 0.0f;

	m[12]= 0.0f;
	m[13]= 0.0f;
	m[14]= 0.0f;
	m[15]= 1.0f;
}

//extern "C" {
//VOID m_sincos_ASM(FLOAT*,FLOAT*,FLOAT);

VOID m_sincos_ASM(FLOAT *s, FLOAT *c, FLOAT angle)
{
	*s = sinf(angle);
	*c = cosf(angle);
/*__asm	{
			mov     eax, c
			fld     angle
			fsincos
			fstp    dword ptr [eax]
			mov     eax, s
			fstp    dword ptr [eax]
}*/		}
 
VOID MatrixRotationY(FLOAT *m, FLOAT ry)
{
FLOAT cy,sy;

	m_sincos_ASM(&sy, &cy, ry);

    m[0] = cy;
	m[1] = 0.f;
    m[2] = -sy;
	m[3] = 0.f;

	m[4] = 0.f;
	m[5] = 1.f;
	m[6] = 0.f;
	m[7] = 0.f;

    m[8] = sy;
	m[9] = 0.f;
    m[10]= cy;
	m[11]= 0.f;

	m[12]= 0.f;
	m[13]= 0.f;
	m[14]= 0.f;
	m[15]= 1.f;
}

VOID m_tmatF_x_point4F(FLOAT *presult, FLOAT *m, FLOAT *p)
{
FLOAT r[4];
	r[0] = m[0 ]*p[0] + m[4 ]*p[1] + m[8 ]*p[2] + m[12]*p[3];   
	r[1] = m[1 ]*p[0] + m[5 ]*p[1] + m[9 ]*p[2] + m[13]*p[3];   
	r[2] = m[2 ]*p[0] + m[6 ]*p[1] + m[10]*p[2] + m[14]*p[3];   
	r[3] = m[3 ]*p[0] + m[7 ]*p[1] + m[11]*p[2] + m[15]*p[3];   
	presult[0] = r[0];
	presult[1] = r[1];
	presult[2] = r[2];
	presult[3] = r[3];
}

VOID D3DUtil_InitMaterial(D3DMATERIAL9& mtrl,FLOAT r,FLOAT g,FLOAT b,FLOAT a)
{
    ZeroMemory( &mtrl, sizeof(D3DMATERIAL9) );
    mtrl.Diffuse.r = mtrl.Ambient.r = r;
    mtrl.Diffuse.g = mtrl.Ambient.g = g;
    mtrl.Diffuse.b = mtrl.Ambient.b = b;
    mtrl.Diffuse.a = mtrl.Ambient.a = a;
	mtrl.Emissive.a = mtrl.Specular.a = 0.08f;
	mtrl.Emissive.r = mtrl.Specular.r = 0.02f;
	mtrl.Emissive.g = mtrl.Specular.g = 0.12f;
	mtrl.Emissive.b = mtrl.Specular.b = 0.02f;
	mtrl.Power = 0.0f;
}

typedef IDirect3D9* (WINAPI *Direct3DCreate9_t)(UINT);
BOOL InitD3D9()
{
HMODULE hm=LoadLibrary(L"d3d9.dll");
	if(!hm)return FALSE;
	Direct3DCreate9_t Direct3DCreate9;
	Direct3DCreate9 = (Direct3DCreate9_t)GetProcAddress(hm,"Direct3DCreate9");
	if(!Direct3DCreate9)return FALSE;
	pD3D = Direct3DCreate9(D3D_SDK_VERSION);
	if(!pD3D)return FALSE;
	return TRUE;
}

VOID CleanupD3D9()
{	if( pD3D != NULL ) 
		pD3D->Release();
	pD3D = NULL;
}

VOID CALLBACK drawDirTimerProc(HWND hwnd,UINT uMsg,UINT_PTR idEvent,DWORD dwTime)
{
static BOOL bInTimer=FALSE;
	if(bInTimer)
	{	//OutputDebugString(L"\nOver timer func...");
		return;
	}
	bInTimer=TRUE;
	RenderDirs(FALSE);
	bInTimer=FALSE;
}

BOOL Init3DDevice9(HWND hWnd)
{	if(pd3dDevice) return FALSE;
    D3DDISPLAYMODE d3ddm;
    if(FAILED(pD3D->GetAdapterDisplayMode(D3DADAPTER_DEFAULT,&d3ddm)))
        return FALSE;

    // Set up the structure used to create the D3DDevice
    D3DPRESENT_PARAMETERS d3dpp;
    ZeroMemory( &d3dpp, sizeof(d3dpp) );
    d3dpp.Windowed = TRUE;
    d3dpp.SwapEffect = D3DSWAPEFFECT_DISCARD;
    d3dpp.BackBufferFormat = d3ddm.Format;
    d3dpp.EnableAutoDepthStencil = TRUE;
    d3dpp.AutoDepthStencilFormat = D3DFMT_D16;

    if(FAILED(pD3D->CreateDevice(	D3DADAPTER_DEFAULT, D3DDEVTYPE_HAL, hWnd,
									D3DCREATE_MULTITHREADED|D3DCREATE_HARDWARE_VERTEXPROCESSING,
                                    &d3dpp, &pd3dDevice)))
	{if(FAILED(pD3D->CreateDevice(	D3DADAPTER_DEFAULT, D3DDEVTYPE_HAL, hWnd,
									D3DCREATE_MULTITHREADED|D3DCREATE_SOFTWARE_VERTEXPROCESSING,
                                    &d3dpp, &pd3dDevice)))
	{if(FAILED(pD3D->CreateDevice(	D3DADAPTER_DEFAULT, D3DDEVTYPE_REF, hWnd,
									D3DCREATE_MULTITHREADED|D3DCREATE_SOFTWARE_VERTEXPROCESSING,
                                    &d3dpp, &pd3dDevice)))
		return FALSE;
	}}
	PerspectiveFovLH((float*)&matProj,D3DX_PI/4,1.25f,1.0f,100.0f);

	/*wchar_t *p,s[MAX_PATH];GetModuleFileName(NULL,s,MAX_PATH);
	p=wcsrchr(s,'\\');
	if(p)
	{	MyStringCpy(p+1,MAX_PATH,L"Plugins\\qView\\Bump.jpg");
		D3DXCreateTextureFromFile(pd3dDevice,s,&pTexture);
	}*/

	/*LOGFONT logFont={0};
	logFont.lfHeight = -18;
	logFont.lfWeight = FW_NORMAL;
	logFont.lfCharSet = DEFAULT_CHARSET;
	wcscpy(logFont.lfFaceName,L"Arial");
	D3DXCreateFontIndirect(pd3dDevice,&logFont,&pFont);*/
	InitDeviceObjects();
	RestoreDeviceObjects();
    return TRUE;
}

VOID Cleanup3DDevice9()
{	//if(pTexture != NULL )
	//	pTexture->Release();
	//if(pFont != NULL)
	//	pFont->Release();
	//pFont = NULL;
	if(pFont){delete pFont;pFont=NULL;}
	if(pVB != NULL )
        pVB->Release();
	if(pd3dDevice != NULL ) 
        pd3dDevice->Release();
	pd3dDevice = NULL;
	KillTimer(hWndPnl,DrawDirTimerId);
}

BOOL RenderDirs(BOOL bProcessContinues)
{	if(!bProcessContinues)dt += 0.1f;
	if(dt>=TWOHALFPI)
	{	dt = HALFPI;
		if(!bProcessContinues)
		{	if(++iMove>iDirs-1)iMove=0;
	}	}
	//D3DXMATRIX matRot;D3DXMatrixRotationY(&matRot,dt);

	if(bProcessContinues)
	{	CalcDirScales();
		CalcRGBs();
	}

	if((!bProcessContinues) && (!bSorted))
	{	qsort(pDirs,iDirs,sizeof(DIR_REC),cmpDirFunc);
		bSorted = TRUE;
	}

	PlaceDirCyls();

	D3DXVECTOR3 vEyePt(1.0f+3.0f*cosf(dt), 2.0f, -3.0f*sinf(dt));
    D3DXVECTOR3 vLookatPt(1.0f, 1.0f, 0.0f);
	lookAtLH((float*)&matView, (float*)&vEyePt, (float*)&vLookatPt, (float*)&vUpVec);
/*  D3DXMatrixLookAtLH(&matView, &D3DXVECTOR3(0.0f, 0.5f, -2.0f*worldRadius),
                                 &D3DXVECTOR3(0.0f, 0.0f, 0.0f),
                                 &D3DXVECTOR3(0.0f, 1.0f, 0.0f));*/
	D3DXMatrixIdentity(&matWorld);

	HRESULT res=pd3dDevice->TestCooperativeLevel();
	if(D3DERR_DEVICELOST==res)OnLostDevice();
	if(D3D_OK!=res)return FALSE;

    pd3dDevice->Clear(0,NULL,D3DCLEAR_TARGET|D3DCLEAR_ZBUFFER,0x001793c1,1.0f,0L);
    if(SUCCEEDED(pd3dDevice->BeginScene()))
    {	pd3dDevice->SetTexture(0, 0);

		//pd3dDevice->SetVertexShader(D3DFVF_CUSTOMVERTEX);
		//pd3dDevice->DrawPrimitiveUP(D3DPT_TRIANGLESTRIP,2*50-2,&CylVerts[0],sizeof(D3DFVF_CUSTOMVERTEX));

		pd3dDevice->SetStreamSource(0,pVB,0,sizeof(CUSTOMVERTEX));
		pd3dDevice->SetFVF(D3DFVF_CUSTOMVERTEX);//SetVertexShader

		pd3dDevice->SetTransform(D3DTS_VIEW, &matView);
		pd3dDevice->SetTransform(D3DTS_PROJECTION, &matProj);

		D3DMATERIAL9 mtrl;D3DUtil_InitMaterial(mtrl,0.0f,0.0f,1.0f,1.0f);
		pd3dDevice->SetMaterial(&mtrl);

		/*FLOAT fFogStart =  5.0f;
		FLOAT fFogEnd   =  200.0f;
		pd3dDevice->SetRenderState( D3DRS_FOGENABLE,      TRUE );
		pd3dDevice->SetRenderState( D3DRS_FOGCOLOR,       0x009317c1 );
		pd3dDevice->SetRenderState( D3DRS_FOGTABLEMODE,   D3DFOG_EXP );
		pd3dDevice->SetRenderState( D3DRS_FOGVERTEXMODE,  D3DFOG_LINEAR );
		pd3dDevice->SetRenderState( D3DRS_RANGEFOGENABLE, FALSE );
		pd3dDevice->SetRenderState( D3DRS_FOGSTART,       FtoDW(fFogStart) );
		pd3dDevice->SetRenderState( D3DRS_FOGEND,         FtoDW(fFogEnd) );*/

		//float cx = matWorld._41;
		float cy = matWorld._42;float cz = matWorld._43;
		float fUp = 0.04f*(dt-HALFPI);
		for(int f=0; f<iDirs; ++f)
		{	int fMove=f;
			if(!bProcessContinues)
			{	fMove += iMove;
				if(fMove>iDirs-1)fMove-=iDirs;

				//static int ist=0;wchar_t ch[MAX_PATH];
				//wsprintf(ch,L"\n%d: path: %s iDirs: %d, fMove: %d, bSorted: %d, bStop: %d, bStopThread: %d, bThreadRun: %d, bTimerInstalled: %d",
				//		 ist++,path,iDirs,fMove,bSorted,bStop,bStopThread,bThreadRun,bTimerInstalled);
				//OutputDebugString(ch);


			}
			float kUp = (0==f?1.0f:1.54f/f);
			//matWorld._41 = cx + pDirs[f].x;
			matWorld._42 = cy + pDirs[f].y + fUp*kUp;
			matWorld._43 = cz + pDirs[f].z - fUp*kUp;

			if(0==f)mtrl.Ambient.a=mtrl.Diffuse.a=(TWOHALFPI-dt)/TWOHALFPI;
			else mtrl.Ambient.a=mtrl.Diffuse.a=1.0f;
			pd3dDevice->SetMaterial(&mtrl);

			D3DXMATRIX m,matSc;MatrixScaling((float*)&matSc,pDirs[fMove].kSc,1.0f,1.0f);//pDirs[f] edi
			m_matF_x_matF(m, matWorld, matSc);//m = matWorld * matSc;
			pd3dDevice->SetTransform(D3DTS_WORLD, &m);
			//m = matView * matRot;
			pd3dDevice->DrawPrimitive(D3DPT_TRIANGLESTRIP,0,2*50-2);
		}

		//OutputDebugString(L" DBG1 ");

		unsigned char s[2*MAX_PATH];//wchar_t ws[2*MAX_PATH];
		matWorld._41 = 0.0f;
		D3DXMATRIX matSc;MatrixScaling((float*)&matSc,0.06f,0.06f,0.06f);
		
		for(int f=0; f<iDirs; ++f)
		{	int fMove=f;
			if(!bProcessContinues)
			{	fMove += iMove;
				if(fMove>iDirs-1)fMove-=iDirs;
			}
			float kUp = (0==f?1.0f:1.54f/f);

			matWorld._42 = cy + pDirs[f].y + fUp*kUp;
			matWorld._43 = cz + pDirs[f].z - fUp*kUp;
			D3DXMATRIX m;m_matF_x_matF(m, matSc, matWorld);//m = matSc * matWorld;

			pd3dDevice->SetTransform(D3DTS_WORLD, &m);
			
			mtrl.Ambient.r=mtrl.Diffuse.r=pDirs[fMove].r;
			mtrl.Ambient.g=mtrl.Diffuse.g=pDirs[fMove].g;
			mtrl.Ambient.b=mtrl.Diffuse.b=pDirs[fMove].b;
			if(0==f)mtrl.Ambient.a=mtrl.Diffuse.a=2.0f*(TWOHALFPI-dt)/TWOHALFPI;
			else mtrl.Ambient.a=mtrl.Diffuse.a=1.0f;
			pd3dDevice->SetMaterial(&mtrl);

			//int ln = MyStringCpy(s,2*MAX_PATH,pDirs[fMove].ff.cFileName);//pDirs[f].ff.cFileName); edi
			//int ln=WideCharToMultiByte(CP_ACP,0,pDirs[fMove].ff.cFileName,-1,(char*)s,2*MAX_PATH,0,0);
			int ln=WideCharToMultiByte(	CP_ACP,0,
										&pDirs[fMove].ff.cFileName[pathLn],
										-1,(char*)s,2*MAX_PATH,0,0);
			if(ln>0)--ln;
			if(pDirs[f].iFiles>0)
			{	if(pDirs[fMove].sz64>1048575)
				 StringCchPrintfA((char*)&s[ln],2*MAX_PATH-ln,": %.2f mBytes in files: %d",pDirs[fMove].sz64/1048576.0f,pDirs[fMove].iFiles);
				else if(pDirs[fMove].sz64>1023)
				 StringCchPrintfA((char*)&s[ln],2*MAX_PATH-ln,": %d kBytes in files: %d",pDirs[fMove].sz64/1024,pDirs[fMove].iFiles);
				else
				 StringCchPrintfA((char*)&s[ln],2*MAX_PATH-ln,": %d Bytes in files: %d",pDirs[fMove].sz64,pDirs[fMove].iFiles);
			}
			else
			{	if(pDirs[fMove].sz64>1048575)
				 StringCchPrintfA((char*)&s[ln],2*MAX_PATH-ln,": %.2f mB;",pDirs[fMove].sz64/1048576.0f);
				else if(pDirs[fMove].sz64>1023)
				 StringCchPrintfA((char*)&s[ln],2*MAX_PATH-ln,": %d kB;",pDirs[fMove].sz64/1024);
				else
				 StringCchPrintfA((char*)&s[ln],2*MAX_PATH-ln,": %d B;",pDirs[fMove].sz64);
			}
			//OutputDebugString(L"\n");
			//OutputDebugStringA((char*)s);

			//MultiByteToWideChar(CP_ACP,0,s,-1,ws,2*MAX_PATH);
			pFont->Render3DText(s,D3DFONT_TWOSIDED|D3DFONT_FILTERED);
			//OutputDebugString(L" DBG2 ");
		}

		//RECT rc;GetClientRect(hWndPnl,&rc);//rc.bottom = 30;
		static int iPnt=0;
		//int ln=MyStringCpy(s,MAX_PATH,path);
		int ln=WideCharToMultiByte(CP_ACP,0,path,-1,(char*)s,2*MAX_PATH,0,0);
		if(ln>0)--ln;
		if(bProcessContinues)
		{	if(++iPnt>8)iPnt=0;
			for(int i=0; i<iPnt; ++i)s[ln++]='.';
			s[ln]=0;
		}
		else
		{	if('*'==s[ln-1] && '\\'==s[ln-2])s[ln-2]=0;
			else if('\\'==s[ln-1])s[ln-1]=0;
		}

		//OutputDebugString(L"\nDBG3");OutputDebugStringA((char*)s);

		//MultiByteToWideChar(CP_ACP,0,s,-1,ws,2*MAX_PATH);
		pFont->DrawText(0,0,0xc000ff00,s,D3DFONT_TWOSIDED|D3DFONT_FILTERED);
		//StringCchPrintf(s,MAX_PATH,L"Root folders: %d, root files: %d",iRootDirs,iRootFiles);
		if(iRootDirs>0 && iRootFiles)
			StringCchPrintfA((char*)&s[0],2*MAX_PATH,"Root folders: %d, root files: %d",iRootDirs,iRootFiles);
		else if(iRootDirs>0)
			StringCchPrintfA((char*)&s[0],2*MAX_PATH,"Root folders: %d",iRootDirs);
		else
			StringCchPrintfA((char*)&s[0],2*MAX_PATH,"Root files: %d",iRootFiles);

		//OutputDebugString(L"\nDBG4");OutputDebugStringA((char*)s);

		pFont->DrawText(0,25,0xc0ff0000,s,D3DFONT_TWOSIDED|D3DFONT_FILTERED);
		//StringCchPrintf(s,MAX_PATH,L"Total folders: %d, total files: %d",iTotDirs,iTotFiles);
		if(iTotDirs>0 && iTotFiles)
			StringCchPrintfA((char*)&s[0],2*MAX_PATH,"Total folders: %d, total files: %d",iTotDirs,iTotFiles);
		else if(iTotDirs>0)
			StringCchPrintfA((char*)&s[0],2*MAX_PATH,"Total folders: %d",iTotDirs);
		else
			StringCchPrintfA((char*)&s[0],2*MAX_PATH,"Total files: %d",iTotFiles);

		//OutputDebugString(L"\nDBG5");OutputDebugStringA((char*)s);

		pFont->DrawText(0,50,0xc00000ff,s,D3DFONT_TWOSIDED|D3DFONT_FILTERED);
		if(szRootFiles64>1048575)
		 StringCchPrintfA((char*)&s[0],2*MAX_PATH,"%.2f mBytes in root files",szRootFiles64/1048576.0f);
		else if(szRootFiles64>1023)
		 StringCchPrintfA((char*)&s[0],2*MAX_PATH,"%d kBytes in root files",szRootFiles64/1024);
		else
		 StringCchPrintfA((char*)&s[0],2*MAX_PATH,"%d Bytes in root files",szRootFiles64);

		//OutputDebugString(L"\nDBG6");OutputDebugStringA((char*)s);

		pFont->DrawText(0,75,0xc0ffff00,s,D3DFONT_TWOSIDED|D3DFONT_FILTERED);
		if(totsz64>1048575)
		 StringCchPrintfA((char*)&s[0],2*MAX_PATH,"Total size: %.2f mBytes",totsz64/1048576.0f);
		else if(totsz64>1024)
		 StringCchPrintfA((char*)&s[0],2*MAX_PATH,"Total size: %d kBytes",totsz64/1024);
		else
		 StringCchPrintfA((char*)&s[0],2*MAX_PATH,"Total size: %d Bytes",totsz64);

		//OutputDebugString(L"\nDBG7");OutputDebugStringA((char*)s);

		pFont->DrawText(0,100,0xc000ffff,s,D3DFONT_TWOSIDED|D3DFONT_FILTERED);
		pd3dDevice->EndScene();
    }

	//OutputDebugString(L" DBG9 ");

	pd3dDevice->Present(NULL,NULL,NULL,NULL);

	if((!bProcessContinues) && (!bTimerInstalled) )
	{	SetTimer(hWndPnl,DrawDirTimerId,250,drawDirTimerProc);
		bTimerInstalled = TRUE;
	}

	//Draw progress:
	return TRUE;
}

VOID CreateCylinder()
{ 
  if(FAILED(pd3dDevice->CreateVertexBuffer(50*2*sizeof(CUSTOMVERTEX),
                                           0, D3DFVF_CUSTOMVERTEX,
                                           D3DPOOL_DEFAULT, &pVB, NULL)))
    return;

  CUSTOMVERTEX* CylVerts;
  if(FAILED(pVB->Lock(0,0,(void**)&CylVerts,0)))
	return;
	
	
  for(DWORD i=0; i<50; i++)
  { FLOAT theta = (2*D3DX_PI*i)/(50-1);
    CylVerts[2*i  ].position = D3DXVECTOR3(0.0f, 0.06f*sinf(theta), 0.06f*cosf(theta));
	CylVerts[2*i  ].normal   = D3DXVECTOR3(0.0f, sinf(theta), cosf(theta));
    //CylVerts[2*i  ].color    = 0xff1010ff;
    CylVerts[2*i  ].tv       = ((FLOAT)i)/(50-1);
    CylVerts[2*i  ].tu       = 1.0f;

    CylVerts[2*i+1].position = D3DXVECTOR3(2.0f, 0.06f*sinf(theta), 0.06f*cosf(theta));
	CylVerts[2*i+1].normal   = D3DXVECTOR3(0.0f, sinf(theta), cosf(theta));
    //CylVerts[2*i+1].color    = 0xffbb10c9;
    CylVerts[2*i+1].tv       = ((FLOAT)i)/(50-1);
    CylVerts[2*i+1].tu       = 0.0f;
  }
  pVB->Unlock();
}

/*BOOL CALLBACK EnumFamCallBack(LPLOGFONT lplf, LPNEWTEXTMETRIC lpntm, DWORD FontType, LPVOID aFontCount) 
{ 
    int far * aiFontCount = (int far *) aFontCount; 
 
    // Record the number of raster, TrueType, and vector 
    // fonts in the font-count array. 
 
    if (FontType & RASTER_FONTTYPE) 
        aiFontCount[0]++; 
    else if (FontType & TRUETYPE_FONTTYPE) 
        aiFontCount[2]++; 
    else 
        aiFontCount[1]++; 
 
    if (aiFontCount[0] || aiFontCount[1] || aiFontCount[2]) 
        return TRUE; 
    else 
        return FALSE; 
 
    UNREFERENCED_PARAMETER( lplf ); 
    UNREFERENCED_PARAMETER( lpntm ); 
}*/

VOID InitDeviceObjects()
{	//int aFontCount[] = { 0, 0, 0 }; 
	//EnumFonts(GetDC(GetDesktopWindow()),(LPCTSTR)NULL,(FONTENUMPROC)EnumFamCallBack,(LPARAM)aFontCount);
	pFont = new CD3DFont((UCHAR*)"Arial", 18, D3DFONT_BOLD);
	pFont->InitDeviceObjects(pd3dDevice);
	CreateCylinder();
}

VOID InvalidateDeviceObjects()
{
	pFont->InvalidateDeviceObjects();
}

VOID RestoreDeviceObjects()
{   pd3dDevice->SetRenderState(D3DRS_CULLMODE, D3DCULL_NONE);
    pd3dDevice->SetRenderState(D3DRS_ZENABLE, TRUE);
	pd3dDevice->SetTextureStageState(0, D3DTSS_COLORARG1, D3DTA_TEXTURE);
    pd3dDevice->SetTextureStageState(0, D3DTSS_COLORARG2, D3DTA_DIFFUSE);
    pd3dDevice->SetTextureStageState(0, D3DTSS_COLOROP,   D3DTOP_MODULATE);
    //pd3dDevice->SetTextureStageState(0, D3DTSS_MINFILTER, D3DTEXF_LINEAR);
    //pd3dDevice->SetTextureStageState(0, D3DTSS_MAGFILTER, D3DTEXF_LINEAR);
    pd3dDevice->SetRenderState(D3DRS_DITHERENABLE, TRUE);
    pd3dDevice->SetRenderState(D3DRS_SPECULARENABLE, TRUE);
    pd3dDevice->SetRenderState(D3DRS_AMBIENT, 0xFFE0E0E0);

    pd3dDevice->SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE);
    pd3dDevice->SetRenderState(D3DRS_SRCBLEND,   D3DBLEND_SRCALPHA);
    pd3dDevice->SetRenderState(D3DRS_DESTBLEND,  D3DBLEND_INVSRCALPHA);
    pd3dDevice->SetTextureStageState(0, D3DTSS_ALPHAOP,   D3DTOP_MODULATE);
    pd3dDevice->SetTextureStageState(0, D3DTSS_ALPHAARG1, D3DTA_TEXTURE);
    pd3dDevice->SetTextureStageState(0, D3DTSS_ALPHAARG2, D3DTA_DIFFUSE);
    pd3dDevice->SetTextureStageState(1, D3DTSS_COLOROP,   D3DTOP_DISABLE);
    pd3dDevice->SetTextureStageState(1, D3DTSS_ALPHAOP,   D3DTOP_DISABLE);

	pFont->RestoreDeviceObjects();
}

VOID OnLostDevice()
{	//OutputDebugString(L"\nOnLostDevice");
	InvalidateDeviceObjects();
	RestoreDeviceObjects();
}

}//end of namespace "C"