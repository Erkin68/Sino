#include "windows.h"

typedef unsigned char u8;
typedef unsigned __int16 u16;
typedef unsigned __int32 u32;
typedef unsigned __int64 u64;
typedef __int16 s16;
typedef __int64 s64;

extern wchar_t FilePathForSearch[MAX_PATH];
extern int FilePathForSearchLn;
extern BOOL bFileLoaded;
extern LPVOID pNextPageTopAddress;
extern int language;

extern HWND hWndPnl;
//extern RECT rcPnl;

extern HANDLE hFile,hFileMap;
extern LPVOID pFileBase;
extern DWORD nFileSizeHigh,nFileSizeLow;
extern u64 szFile;
extern u64 pageSz,szToEndRow;
extern BOOL OpenTextFile();
extern BOOL CloseFileMap();

extern wchar_t **strngs;
extern HMODULE plgnDllInst;

extern BOOL InitViewer(HWND,wchar_t*);
extern BOOL ChangeViewFile(wchar_t*);
extern VOID CloseViewer();
extern VOID OnDraw(HDC,int);
extern VOID OnResizeWindow(WORD,WORD);
extern VOID OnVScroll(WPARAM);
extern VOID LineUp(BOOL);
extern VOID LineDown(BOOL);
extern VOID PageUp();
extern VOID PageDown();
extern VOID End();
extern VOID Home();

extern int nRows,nColumns,nViewRows,nViewColumns,
		   xSpaceText,ySpaceText,
		   nViewFromChar,
		   perCentOfAddr,perCentOfBin,perCentOfText;
extern BOOL bMouseCapture;
extern BOOL bLastRowDrawed;
extern __int16 capturePosX,capturePosY,capturePosToX,capturePosToY;
extern int xScroll;
extern float deltaLineHScroll;
extern COLORREF textColorText,backColorText;
extern HBRUSH selctnBrsh;
extern BOOL addrFillZero;
extern UINT addrFmt,addrFmtDesc;


//DrawText.cpp:
extern u8 retLineChars[3];
extern COLORREF textColorText,backColorText;
extern HFONT fntText;
extern LOGFONT textLogFont;
extern HBRUSH bluBrsh;
extern UINT textFmt,textFmtDesc;
extern u64 iAddressText;
extern VOID DrawTexts(HDC,RECT*,int*,LPVOID*);
extern u64  CalcPosInDrawTexts(HDC,RECT*,int*,int*);
extern VOID DrawTexts16(HDC,RECT*,int*,LPVOID*);
extern u64  CalcPosInDrawTexts16(HDC,RECT*,int*,int*);
extern BOOL CheckRetLineA(u8*);
extern BOOL CheckRetLineW(wchar_t*);

//Selection.cpp
typedef struct TSelection
{	int x;
	int y;
	u64 iAddress;
} Selection;
extern Selection selctBgn,selct;
extern BOOL bBgnSelSuccess;
extern BOOL bTimerScrollSelection;
extern BOOL BeginSelection();
extern BOOL SelectedItemsChanged();
extern VOID DrawSelectionBack(HDC);
extern VOID EndSelection();
extern BOOL OnScrollSelectionTimer();
extern VOID CopyBinaryToClipboard();
extern VOID CopyTextToClipboard();
extern INT_PTR CALLBACK ClpbrdDlgProc(HWND,UINT,WPARAM,LPARAM);

extern u8* MyStrCmpNNAPrgrs(u8*,u8*,int,int,HWND);
extern u8* MyStrCmpNNADirUpPrgrs(u8*,u8*,int,int,HWND);


extern INT_PTR CALLBACK About(HWND,UINT,WPARAM,LPARAM);
extern BOOL OpenTextFile();
extern BOOL CloseFileMap();
extern VOID OnVScroll(WPARAM);
extern VOID OnHScroll(WPARAM);
extern VOID PageDown();
extern VOID PageDown16();
extern VOID PageUp();
extern VOID PageUp16();
extern VOID LineUp(BOOL);
extern VOID LineUp16();
extern VOID LineDown(BOOL);
extern VOID LineDown16();
extern VOID LineLeft();
extern VOID LineRight();
extern VOID End();
extern VOID End16();
extern VOID Home();
extern VOID FAR PASCAL InitLogFont(LOGFONT*);
extern LRESULT CALLBACK TextWndProc(HWND,UINT,WPARAM,LPARAM);
extern VOID MessageProcess();
extern VOID OnDraw(HDC,int);
extern VOID CheckAddressParity16(u64*,BOOL);

//CrctScrlMethod.cpp
extern BOOL bOrderToCrctCalcing,bOrderToStopCrctCalcing;
extern u8 **linesStarts;
typedef enum TCorrectScrollState
{	fast,
	calcThread,
	finished
} CorrectScrollState;
extern CorrectScrollState crctScrlSt;
extern s64 iCrtScrlLines,iCrtScrlCrntLines,iCrctScrlMaxHorChars,iCrctScrlMaxHorCharsWidth;
extern u16 **linesStartsW;
extern u16 *pInMaxHorCharsW;
extern BOOL bOrderToCrctCalcing,bOrderToStopCrctCalcing;

extern VOID CalcCorrectScrollingA();
extern VOID PageDownCrct();
extern VOID PageUpCrct();
extern VOID LineUpCrct(BOOL);
extern VOID LineDownCrct(BOOL);
extern VOID EndCrct();
extern VOID HomeCrct();
extern VOID OnVScrollCrct(WPARAM);
extern VOID OnHScrollCrct(WPARAM);
extern VOID OnDrawCrct(HDC,int);
extern VOID DrawTextsCrct(HDC,RECT*,int*,LPVOID*);
extern VOID SetScrollInResizeCrct();
extern u64  CalcPosInDrawTextsCrct(HDC,RECT*,int*,int*);

extern VOID OnHScroll(WPARAM);

//CrctScrlMethodWEven.c
extern VOID CalcCorrectScrollingWEven();
extern u64  CalcPosInDrawTextsCrctW(HDC,RECT*,int*,int*);

//CrctScrlMethodWOdd.c
extern u16  **linesStartsW;
extern VOID CalcCorrectScrollingWOdd();
extern VOID DrawTextsCrctW(HDC,RECT*,int*,LPVOID*);

//// AutoDef.c
extern BOOL bAutoDef;
extern char iAutoSz,iAutoFileSz;
extern VOID AutoCalcDepthOfChars();
extern INT_PTR CALLBACK AutoAnalSizeDlgProc(HWND,UINT,WPARAM,LPARAM);
extern INT_PTR CALLBACK AutoCrctFileSizeDlgProc(HWND,UINT,WPARAM,LPARAM);

//Search.c:
extern wchar_t srchText[MAX_PATH];
extern INT_PTR CALLBACK SearchDlg(HWND,UINT,WPARAM,LPARAM);
