#include "txtView.h"
#include "stdio.h"



VOID CalcCorrectScrollingWOdd()
{	int imx=0,pr=0,linesStartsSize = 1000;//1000 tadan oshirib boramiz;
	u16 *p,*pp;u64 i;
	HDC dc;SIZE sz;u16 *pBgn,*pEnd;

	//SendMessage(hPrgs,PBM_SETRANGE32,0,1000);
	//SendMessage(hPrgs,PBM_SETPOS,0,0);
	//SetWindowText(hStat,L"Calculating lines,scrolling info,odd...");
	crctScrlSt=calcThread;
	bOrderToStopCrctCalcing=FALSE;
	iCrtScrlLines=iCrctScrlMaxHorChars=iCrctScrlMaxHorCharsWidth=0;
	if(linesStartsW)linesStartsW=(u16**)realloc(linesStartsW,linesStartsSize*sizeof(u16*));
	else linesStartsW=(u16**)malloc(linesStartsSize*sizeof(u16*));

	//linesStartsW[iCrtScrlLines++]=(u16*)((u8*)pFileBase+1);
	pInMaxHorCharsW = (u16*)((u8*)pFileBase+1);

	p = pInMaxHorCharsW;pp=p;
	for(i=0; i<szFile/2-1; ++i)
	{	if(++imx>0xff || CheckRetLineW(p))
		{	s64 ss;
			if(iCrtScrlLines>linesStartsSize-2)
			{	linesStartsSize+=1000;
				linesStartsW=(u16**)realloc(linesStartsW,linesStartsSize*sizeof(u16*));
			}
			linesStartsW[iCrtScrlLines++]=pp;
			ss=(s64)(p-pp);
			if(ss>iCrctScrlMaxHorChars)
			{	iCrctScrlMaxHorChars=ss;
				pInMaxHorCharsW=pp;
			}
			pp=p+retLineChars[2];
			imx=0;
		}
		++p;
		if(0==i%1000)
		{	MessageProcess();
			//if(szFile>0)
			//	SendMessage(hPrgs,PBM_SETPOS,(WPARAM)(1000*i/szFile),0);
		}
		if(bOrderToStopCrctCalcing)
		{	crctScrlSt=fast;
			//SendMessage(hPrgs,PBM_SETPOS,1000,0);
			//SetWindowText(hStat,L"Calculating lines,scrolling info emergency shutdowning.");
			return;
	}	}
	if(szFile>0 && 0==iCrtScrlLines)
		linesStartsW[iCrtScrlLines++]=(u16*)pFileBase;
	dc=GetDC(hWndPnl);
	pBgn=pInMaxHorCharsW;pEnd= pBgn+iCrctScrlMaxHorChars;
	if(pBgn==pEnd)pEnd=p;
	//iCrctScrlMaxHorCharsWidth=0 qiluvdik;
	//SetWindowText(hStat,L"Calculating horizontal spacing...");
	while(pBgn<pEnd)
	{	int isz=(int)(pBgn+0xff<pEnd?0xff:pEnd-pBgn);//bayt ANSI uchun;
		GetTextExtentPoint32W(dc,(LPCWSTR)pBgn,isz,&sz);
		pBgn+=isz;iCrctScrlMaxHorCharsWidth+=sz.cx;
		//SendMessage(hPrgs,PBM_SETPOS,(WPARAM)pr,0);
		if(++pr>1000)pr=0;
	}
	ReleaseDC(hWndPnl,dc);
	SetScrollInResizeCrct();
	//SendMessage(hPrgs,PBM_SETPOS,1000,0);
	//SetWindowText(hStat,L"Calculating lines,scrolling info finished.");
	iCrtScrlCrntLines=0;iAddressText=0;
	crctScrlSt=finished;
	//SetCursor(hArrCursor);
}