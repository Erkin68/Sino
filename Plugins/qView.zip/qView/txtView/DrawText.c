#include "txtView.h"
#include "strsafe.h"



COLORREF textColorText=RGB(255,255,255),backColorText=RGB(0,0,255);
HFONT fntText;
LOGFONT textLogFont;
UINT textFmt=DT_CENTER|DT_VCENTER,textFmtDesc=8;

int xSpaceText=8,ySpaceText=24;

u8 retLineChars[3]={0x0d,0x0a,2};//[2]-si nechta simvol tekshirish kerakligi;
BOOL bLastRowDrawed=FALSE;

BOOL CheckRetLineA(u8 *p)
{	if(2==retLineChars[2])
	{	if(retLineChars[0] == *p)
		if(retLineChars[1]==*(p+1))//0x0d==*p && 0x0a==*(p+1))
			return TRUE;
		return FALSE;
	}
	//else : 1ta
	if(retLineChars[0] == *p)
		return TRUE;
	return FALSE;
}

BOOL CheckRetLineW(wchar_t *p)
{	if(2==retLineChars[2])
	{	if(retLineChars[0] == *p)
		if(retLineChars[1]==*(p+1))//0x0d==*p && 0x0a==*(p+1))
			return TRUE;
		return FALSE;
	}
	//else : 1ta
	if(retLineChars[0] == *p)
		return TRUE;
	return FALSE;
}

VOID DrawTexts(HDC hDC,RECT *rDC,int *maxWidth,LPVOID* pNextPageTopAddress)
{HFONT oldFnt;u8 *p;u64 iiAddress;int row;
 RECT rc = *rDC;
 FillRect(hDC,&rc,bluBrsh);
 
 rc.left += 2-xScroll;
 rc.right -= 1;
 rc.top = 0;
 rc.bottom = ySpaceText-1;

 SetBkColor(hDC,backColorText);
 SetTextColor(hDC,textColorText);
 oldFnt=(HFONT)SelectObject(hDC,fntText);

 p = (u8*)pFileBase+iAddressText;
 iiAddress=iAddressText;

 *maxWidth=0;

 for(row=0; row<nViewRows; ++row)
 {	u8 *pp=p;SIZE sz;int strLn,strLn1,strLn2,limit=0;BOOL r;
	while(iiAddress<szFile)
	{	++iiAddress;
		++p;
		if(CheckRetLineA(p))
			break;
		if(++limit>0xff)break;
	}
	strLn=(int)(p-pp);
	strLn1=(strLn>0xff?0xff:strLn);
	strLn2=strLn;

	if(strLn2>0xff)strLn2=0xff;
	r=ExtTextOutA(hDC,rc.left,rc.top,0,&rc,(LPCSTR)pp,strLn1,NULL);
	rc.top += ySpaceText;
	rc.bottom = rc.top+ySpaceText-1;

	if(strLn==strLn1)
	{	GetTextExtentPoint32A(hDC,(LPCSTR)pp,strLn1,&sz);
		if(sz.cx>(*maxWidth))*maxWidth=sz.cx;
	}
	else
	{	//Taxminan uramiz:
		GetTextExtentPoint32A(hDC,(LPCSTR)pp,strLn1,&sz);
		sz.cx *= strLn/strLn1;
		if(sz.cx>(*maxWidth))*maxWidth=sz.cx;
    }
	if(iiAddress>szFile-1)
		break;
 }
 SelectObject(hDC,oldFnt);
 *pNextPageTopAddress=p;
 bLastRowDrawed=((u64)(p-(u8*)pFileBase)>szFile-2)?TRUE:FALSE;
}

u64 CalcPosInDrawTexts(HDC hDC,RECT *rDC,int *xOut,int *yOut)
{RECT rc = *rDC;
 HFONT oldFnt=(HFONT)SelectObject(hDC,fntText);
 u8 *p;
 u64 iiAddress;
 int dx,row,cptX = *xOut,cptY = *yOut;

 rc.left += 2-xScroll;
 rc.right -= 1;
 rc.top = 0;
 rc.bottom = ySpaceText-1;

 p = (u8*)pFileBase+iAddressText;
 iiAddress=iAddressText;
 for(row=0; row<nViewRows; ++row)
 {	int limit=dx=0;
	while(iiAddress<szFile)
	{	if(rc.top<=cptY && rc.top+ySpaceText>=cptY)
		{	SIZE sz;GetTextExtentPoint32A(hDC,(LPCSTR)p,1,&sz);
			dx += sz.cx;
			if(dx-sz.cx-xScroll<=cptX && dx-xScroll>=cptX)
				break;
		}
		++p;
		++iiAddress;
		if(CheckRetLineA(p))
			break;
		if(++limit>0xff)break;
	}
	if(rc.top>=cptY && rc.top+ySpaceText<=cptY)//if(dx>0)
		break;
	rc.top += ySpaceText;
	rc.bottom = rc.top+ySpaceText-1;
 }
 SelectObject(hDC,oldFnt);
 if(dx+xScroll>=cptX)
	*xOut = dx;
 else *xOut = cptX;
 *yOut = rc.top;
 return iiAddress;
}

VOID DrawTexts16(HDC hDC,RECT *rDC,int *maxWidth,LPVOID* pNextPageTopAddress)
{RECT rc = *rDC;
 HFONT oldFnt=(HFONT)SelectObject(hDC,fntText);
 wchar_t *p;int row;
 u64 iiAddress;

 FillRect(hDC,&rc,bluBrsh);
 
 rc.left += 2;
 rc.right -= 1;
 rc.top = 0;
 rc.bottom = ySpaceText-1;

 SetBkColor(hDC,backColorText);
 SetTextColor(hDC,textColorText);

 CheckAddressParity16(&iAddressText,TRUE);
 p = (wchar_t*)((u8*)pFileBase+iAddressText);
 iiAddress=iAddressText;

 *maxWidth=0;

 for(row=0; row<nViewRows; ++row)
 {	wchar_t *pp=p;int limit=0;
	SIZE sz;
	int strLn,strLn1,strLn2;

	while(iiAddress<szFile)
	{	iiAddress+=2;
		++p;
		if(CheckRetLineW(p))
			break;
		if(++limit>0xff)break;
	}
	strLn=(int)(p-pp);
	strLn1=(strLn>0xff?0xff:strLn);
	strLn2=strLn;

	if(strLn2>0xff)strLn2=0xff;
	ExtTextOutW(hDC,rc.left-xScroll,rc.top,ETO_CLIPPED,&rc,(LPCWSTR)pp,strLn1,NULL);
	rc.top += ySpaceText;
	rc.bottom = rc.top+ySpaceText-1;

	if(strLn==strLn1)
	{	GetTextExtentPoint32W(hDC,(LPCWSTR)pp,strLn1,&sz);
		if(sz.cx>(*maxWidth))*maxWidth=sz.cx;
	}
	else
	{	//Taxminan uramiz:
		GetTextExtentPoint32W(hDC,(LPCWSTR)pp,strLn1,&sz);
		sz.cx *= strLn/strLn1;
		if(sz.cx>(*maxWidth))*maxWidth=sz.cx;
    }
	if(iiAddress>szFile-1)
		break;
 }
 SelectObject(hDC,oldFnt);
 *pNextPageTopAddress=p;
 bLastRowDrawed=((u64)(((u8*)p)-(u8*)pFileBase)>szFile-2)?TRUE:FALSE;
}

u64 CalcPosInDrawTexts16(HDC hDC,RECT *rDC,int *xOut,int *yOut)
{RECT rc = *rDC;
 int cptX = *xOut,cptY = *yOut,row;
 wchar_t *p;
 u64 iiAddress;
 int dx;	
 HFONT oldFnt=(HFONT)SelectObject(hDC,fntText);

 rc.left += 2;
 rc.right -= 1;
 rc.top = 0;
 rc.bottom = ySpaceText-1;

 CheckAddressParity16(&iAddressText,TRUE);
 p = (wchar_t*)((u8*)pFileBase+iAddressText);
 iiAddress=iAddressText;
 for(row=0; row<nViewRows; ++row)
 {	int limit=dx=0;
	while(iiAddress<szFile)
	{	if(rc.top<=cptY && rc.top+ySpaceText>=cptY)
		{	SIZE sz;GetTextExtentPoint32W(hDC,(LPCWSTR)p,1,&sz);
			dx += sz.cx;
			if(dx-sz.cx-xScroll<=cptX && dx-xScroll>=cptX)
				break;
		}
		++p;
		iiAddress+=2;
		if(CheckRetLineW(p))
			break;
		if(++limit>0xff)break;
	}
	if(rc.top<=cptY && rc.top+ySpaceText>=cptY)//if(dx>0)
		break;
	rc.top += ySpaceText;
	rc.bottom = rc.top+ySpaceText-1;
 }
 SelectObject(hDC,oldFnt);
 if(dx+xScroll>=cptX)
	*xOut = dx;
 else *xOut = cptX;
 *yOut = rc.top;
 return iiAddress;
}