#include "txtView.h"
#include "..\..\..\Operations\Myshell\MyShellC.h"



HANDLE hFile=0,hFileMap=0;
LPVOID pFileBase=0;
LPVOID pNextPageTopAddress;
DWORD nFileSizeHigh,nFileSizeLow;
u64 szFile=0;

BOOL OpenTextFile()
{
BY_HANDLE_FILE_INFORMATION fibh;

	if(0==FilePathForSearch[0])return FALSE;
    hFile = CreateFile(FilePathForSearch, GENERIC_READ, FILE_SHARE_READ, NULL,
                       OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, (HANDLE)0);                    
    if(hFile == INVALID_HANDLE_VALUE)
        return FALSE;

	if(!GetFileInformationByHandle(hFile,&fibh))
	{	CloseHandle(hFile);
		hFile = 0;
		return FALSE;
	}
	nFileSizeHigh = fibh.nFileSizeHigh;
	nFileSizeLow = fibh.nFileSizeLow;
	szFile = (((u64)nFileSizeHigh) << 32) | nFileSizeLow;

    hFileMap = CreateFileMapping(hFile, NULL, PAGE_READONLY, 0, 0,NULL);
    if(hFileMap == 0)
	{	CloseHandle(hFile);
		hFile=0;
		return FALSE;
	}

    pFileBase = (PCHAR)MapViewOfFile(hFileMap,FILE_MAP_READ,0,0,0);
    if(pFileBase==0)
	{	if(hFileMap)CloseHandle(hFileMap);
		CloseHandle(hFile);
		hFile=0;hFileMap=0;
		return FALSE;
	}

    //if(IsBadReadPtr(pNTHdr, sizeof(IMAGE_NT_HEADERS)))return;

	return TRUE;
}

BOOL CloseFileMap()
{	if(pFileBase)
		UnmapViewOfFile(pFileBase);
	pFileBase = 0;
	if(hFileMap)
		CloseHandle(hFileMap);
	hFileMap = 0;
	if(hFile)
		CloseHandle(hFile);
	hFile = 0;
	return TRUE;
}