#include "txtView.h"
#include "resource.h"
#include "..\..\..\Operations\MyShell\MyShellC.h"

HWND hWndPnl=0;
BOOL bFileLoaded=FALSE;
u64 iAddressText=0;
int xScroll=0;

VOID MessageProcess()
{MSG msg;
	if(PeekMessage(&msg, hWndPnl,  0, 0, PM_REMOVE))
	{	TranslateMessage(&msg);
		DispatchMessage(&msg);
}	}

LRESULT newPnlWndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{wchar_t *p,modPth[MAX_PATH],pth[MAX_PATH],tmp[MAX_PATH]=L" ";
PROCESS_INFORMATION pi;STARTUPINFO si;
PAINTSTRUCT ps;HDC dc;RECT rc;
	switch(msg)
	{	case WM_CHAR:
			return 0;
		case WM_PAINT:
			dc = BeginPaint(hWnd, &ps);
			OnDraw(dc,0);
            EndPaint(hWnd, &ps);
			return 0;
		case WM_SIZE:
			OnResizeWindow(LOWORD(lParam),HIWORD(lParam));
		return 0;
		case WM_VSCROLL:
			if(finished==crctScrlSt)OnVScrollCrct(wParam);
			else OnVScroll(wParam);
			return 0;
		case WM_HSCROLL:
			if(finished==crctScrlSt)OnHScrollCrct(wParam);
			else OnHScroll(wParam);
			return 0;
		case WM_KEYDOWN:
			switch(wParam)
			{	case VK_ESCAPE:
					DestroyWindow(hWnd);
					return 0;
				case VK_NEXT:
					PageDown();
				return 0;
				case VK_PRIOR:
					PageUp();
					return 0;
				case VK_DOWN:
					LineDown(TRUE);
				return 0;
				case VK_UP:
					LineUp(TRUE);
				return 0;
				case VK_HOME:
					Home();
				return 0;
				case VK_END:
					End();
				return 0;
				case 0x46://VK_F:
					if(0x8000 & GetKeyState(VK_CONTROL))
						DialogBoxParam(plgnDllInst, MAKEINTRESOURCE(IDD_DIALOG_SEARCH), hWnd, SearchDlg, 0);
					return 0;
				case VK_F3:
					DialogBoxParam(plgnDllInst, MAKEINTRESOURCE(IDD_DIALOG_SEARCH), hWnd, SearchDlg, 1);
					return 0;
				case 0x32/*VK_1*/:
					GetModuleFileName(NULL,modPth,MAX_PATH);
					p = wcsrchr(modPth,'\\');
					if(p)
					{	*p=0;MyStringCpy(pth,MAX_PATH,modPth);
						MyStringCpy(p,32,L"\\TextViewerRel.exe");
						p=wcsrchr(pth,'\\');
						if(p)*p=0;
						p=wcsrchr(pth,'\\');
						if(p)*p=0;
					}pi.hThread=0;ZeroMemory(&si,sizeof(si));si.cb=sizeof(si);
					tmp[0]=' ';MyStringCpy(&tmp[1],MAX_PATH-1,FilePathForSearch);
					if(CreateProcess(modPth,tmp,NULL,NULL,FALSE,0,NULL,pth,&si,&pi))
					{	if(pi.hThread)
							PostQuitMessage(0);
					}
				return 0;
			}
			return 0;
		case WM_MOUSEWHEEL:
			if(0>GET_WHEEL_DELTA_WPARAM(wParam))PageDown();
			else PageUp();
			return 0;
		case WM_DESTROY:
			GetWindowRect(hWnd,&rc);
			DeleteObject(fntText);
			CloseFileMap();
		break;
		case WM_CTLCOLORSTATIC:
			return (LRESULT)GetStockObject(DC_BRUSH);
		case WM_LBUTTONDOWN:
			if(bFileLoaded)
			{	if(bBgnSelSuccess)
				{	EndSelection();
					OnDraw(0,0);
				}
				capturePosX = (__int16)(LOWORD(lParam));
				capturePosY = (__int16)(HIWORD(lParam));
				if(BeginSelection())
				{	SetCapture(hWnd);
					bMouseCapture = TRUE;
			}	}
			return 0;
		case WM_LBUTTONUP:
			if(bFileLoaded && bMouseCapture)
			{	bMouseCapture = FALSE;
				ReleaseCapture();
				if(bTimerScrollSelection)
					KillTimer(hWnd,0);
				//EndSelection();
				//OnDraw(0);
			}
			return 0;
		case WM_MOUSEMOVE:
			if(bFileLoaded && bMouseCapture)
			{	capturePosToX = (int)(LOWORD(lParam));
				capturePosToY = (int)(HIWORD(lParam));
				if(SelectedItemsChanged())
					OnDraw(0,0);
			}
			return 0;
		case WM_RBUTTONDOWN:
			/*if(bBgnSelSuccess)
			{	HMENU hm = GetSubMenu(GetMenu(hWnd),2);
				if(hm)
				{	POINT p={LOWORD(lParam),HIWORD(lParam)};
					ClientToScreen(hWnd,&p);
					r=TrackPopupMenu(hm,TPM_RETURNCMD,p.x,p.y,0,hWnd,NULL);
					if(ID_EDIT_COPY1==r)
						CopyBinaryToClipboard();
					else if(ID_CLIPBOARD_COPYTEXT==r)
						CopyTextToClipboard();
			}	}*/
			return 0;
		case WM_TIMER:
			if(bFileLoaded)
				OnScrollSelectionTimer();
			return 0;


	}
	return DefWindowProc(hWnd,msg,wParam,lParam);
}

BOOL ChangeViewFile(wchar_t *filePthAndName)
{	RECT rcPnl;
	FilePathForSearchLn=MyStringCpy(FilePathForSearch,MAX_PATH,filePthAndName);
	if(hFile)CloseFileMap();
	bFileLoaded = OpenTextFile();
	if(!bFileLoaded)return FALSE;

	bBgnSelSuccess = FALSE;

	if(bFileLoaded && bAutoDef)AutoCalcDepthOfChars();
	if(bFileLoaded && bOrderToCrctCalcing)
	{if(8==textFmtDesc)
		CalcCorrectScrollingA();
	else if(16==textFmtDesc)
		CalcCorrectScrollingWEven();
	else if(161==textFmtDesc)
		CalcCorrectScrollingWOdd();
	}
	GetClientRect(hWndPnl,&rcPnl);
	OnResizeWindow((WORD)rcPnl.right,(WORD)rcPnl.bottom);
	selctBgn.iAddress=selct.iAddress=0;
	OnDraw(0,0);
	return bFileLoaded;
}

HBRUSH bluBrsh;
BOOL InitViewer(HWND prnt, wchar_t *filePthAndName)
{WNDCLASSEX wc;RECT rc;ATOM a;
	FilePathForSearchLn=MyStringCpy(FilePathForSearch,MAX_PATH,filePthAndName);
	wc.cbSize=sizeof(wc);
	wc.hInstance=plgnDllInst;
	wc.hCursor=LoadCursor(NULL,IDC_ARROW);
	wc.hIcon=wc.hIconSm=NULL;
	wc.lpfnWndProc=(WNDPROC)newPnlWndProc;
	wc.lpszClassName=L"qvtext_class";
	wc.lpszMenuName=NULL;
	wc.cbClsExtra=0;
	wc.cbWndExtra=0;
	wc.style=CS_HREDRAW|CS_VREDRAW;
	bluBrsh = CreateSolidBrush(RGB(0,0,255));
	wc.hbrBackground=bluBrsh; 
	a=RegisterClassEx(&wc);
	//if(!a)return FALSE;
	GetWindowRect(prnt,&rc);
	hWndPnl = CreateWindowEx(WS_EX_LEFT|WS_EX_CLIENTEDGE,
							 L"qvtext_class",
							 L"qvtext_window",
							 WS_VISIBLE|WS_CHILDWINDOW,
							 0,
							 0,
							 (int)(rc.right-rc.left),
							 (int)(rc.bottom-rc.top),
							 prnt,
							 0,
							 plgnDllInst,
							 0);
	if(!hWndPnl)return FALSE;
	return ChangeViewFile(filePthAndName);
}

VOID CloseViewer()
{	CloseFileMap();
	if(hWndPnl)DestroyWindow(hWndPnl);
	hWndPnl=0;
	UnregisterClass(L"qvtext_class",plgnDllInst);
	DeleteObject(bluBrsh);
}

__declspec (dllexport) BOOL Draw$8(HWND prnt, wchar_t* filePthAndName)
{	if(!prnt)return FALSE;
	if(!filePthAndName)return FALSE;
	if(0==filePthAndName[0])return FALSE;
	if(hWndPnl)
	{	if(0==wcscmp(FilePathForSearch,filePthAndName))
			return TRUE;
		else ChangeViewFile(filePthAndName);
	}
	else//if(hWndPnl!=prnt)
		InitViewer(prnt,filePthAndName);
	return TRUE;
}

int nRows=0,nColumns=0,nViewRows=25,nViewColumns=33,
	nViewFromChar=0,
	perCentOfAddr=10,perCentOfBin=65,perCentOfText=25;
u64 pageSz,szToEndRow;
SCROLLINFO si;
VOID OnResizeWindow(WORD w,WORD h)
{	//if(hWndPnl)MoveWindow(hWndPnl,0,0,w,h-20,TRUE);
	//if(hStat)MoveWindow(hStat,0,h-19,w/2,19,TRUE);
	//if(hPrgs)MoveWindow(hPrgs,w/2,h-19,w/2,19,TRUE);
	h-=20;
	if(0==w && 0==h)return;
	if(0==ySpaceText)ySpaceText=24;
	//SCROLLINFO si;
	//ZeroMemory(&si,sizeof(si));
	//si.cbSize=sizeof(si);

	nViewColumns = w / xSpaceText;
	if(nViewColumns<1)nViewColumns=1;
	nViewRows = (h+ySpaceText-1) / ySpaceText;
	if(nViewRows<1)nViewRows=1;
	pageSz = nViewColumns * nViewRows;
	if(finished==crctScrlSt)
		SetScrollInResizeCrct();
}

VOID PageDown()
{u64 iiAddress;u8 *p;int r;SCROLLINFO si;
 if(!bLastRowDrawed)
 {if(16==textFmtDesc || 161==textFmtDesc)
  {PageDown16();
   return;
  }
  iiAddress=iAddressText;
  p = (u8*)pFileBase+iAddressText;
  for(r=0; r<nViewRows; ++r)
  {	while(iiAddress<szFile)
	{	if(CheckRetLineA(p))
		{	++p;
			break;
		}
		++iiAddress;
		++p;
  }	}
  iAddressText = (u64)((char*)p-(char*)pFileBase)+retLineChars[2]-1;//0d0a uchun;
  si.nPos = (int)iAddressText;
  si.fMask = SIF_POS;
  SetScrollInfo(hWndPnl,SB_VERT,&si,TRUE);
  OnDraw(0,1);
}}

VOID PageDown16()
{BOOL bFind;u64 iiAddress;wchar_t *p;int r;SCROLLINFO si;
 if(!bLastRowDrawed)
 {CheckAddressParity16(&iAddressText,TRUE);
  iiAddress=iAddressText;
  p = (wchar_t*)((u8*)pFileBase+iAddressText);
  for(r=0; r<nViewRows; ++r)
  {	int limit=0;bFind=FALSE;
	while(iiAddress<szFile)
	{	if(CheckRetLineW(p))
		{	++p;
			bFind=TRUE;
			break;
		}
		iiAddress+=2;
		++p;
		if(++limit>0xff)break;
  }	}
  if(bFind)
	iAddressText = (u64)((char*)p-(char*)pFileBase)+retLineChars[2]-2;//0d0a uchun;
  else
	iAddressText = (u64)((char*)p-(char*)pFileBase);//0d0a uchun;
  si.nPos = (int)iAddressText;
  si.fMask = SIF_POS;
  SetScrollInfo(hWndPnl,SB_VERT,&si,TRUE);
  OnDraw(0,1);
}}

VOID PageUp()
{u64 iiAddress;u8 *p;int r;SCROLLINFO si;
 //if(0!=iAddressText)
 {if(16==textFmtDesc || 161==textFmtDesc)
  {PageUp16();
   return;
  }
  iiAddress=iAddressText;
  p = (u8*)pFileBase+iAddressText;
  if(p>(u8*)pFileBase)
  {for(r=0; r<nViewRows; ++r)
   {u64 iBAddress=iiAddress;
	while(iiAddress>0 && p>(u8*)pFileBase)
	{	if(iBAddress-iiAddress>2 && CheckRetLineA(p-1))//0x0a==*p && 0x0d==*(p-1))
		{	--p;
			break;
		}
		--iiAddress;
		--p;
   }}
   iAddressText = (u64)((char*)p-(char*)pFileBase)+retLineChars[2];//0d0a uchun;
   if(iAddressText<3)iAddressText=0;
   si.nPos = (int)iAddressText;
   si.fMask = SIF_POS;
   SetScrollInfo(hWndPnl,SB_VERT,&si,TRUE);
   OnDraw(0,1);
}}}

VOID PageUp16()
{BOOL bFind;u64 iiAddress;wchar_t *p;int r;SCROLLINFO si;
 //if(0!=iAddressText)
 {CheckAddressParity16(&iAddressText,TRUE);  
  iiAddress=iAddressText;
  p = (wchar_t*)((u8*)pFileBase+iAddressText);
  if(p>(wchar_t*)pFileBase)
  {for(r=0; r<nViewRows; ++r)
   {u64 iBAddress=iiAddress;
    int limit=0;bFind=FALSE;
	while(iiAddress>=(16==textFmtDesc?2:3) && p>(wchar_t*)pFileBase)
	{	if(iBAddress-iiAddress>2 && CheckRetLineW(p-1))//0x0a==*p && 0x0d==*(p-1))
		{	--p;
			bFind=TRUE;
			break;
		}
		iiAddress-=2;
		--p;
		if(++limit>0xff)break;
   }}
   if(bFind)
	iAddressText = (u64)((char*)p-(char*)pFileBase)+retLineChars[2];//0d0a uchun;
   else
	iAddressText = (u64)((char*)p-(char*)pFileBase);//0d0a uchun;
   if(iAddressText<3)iAddressText=0;
   si.nPos = (int)iAddressText;
   si.fMask = SIF_POS;
   SetScrollInfo(hWndPnl,SB_VERT,&si,TRUE);
   OnDraw(0,1);
}}}

VOID LineUp(BOOL bInScrollSelect)
{SCROLLINFO si;
 //if(0!=iAddressText)
 {if(16==textFmtDesc || 161==textFmtDesc)
   LineUp16();
  else
  {  BOOL bFind=FALSE;u64 iiAddress=iAddressText;
	 u8 *p = (u8*)pFileBase+iAddressText;
	 while(iiAddress>0)
	 {	if(iAddressText-iiAddress>2 && CheckRetLineA(p-1))//0x0a==*p && 0x0d==*(p-1))
 		{	--p;
			bFind=TRUE;
			break;
		}
		--iiAddress;
		--p;
	 }
	 if(bFind)
	 {iAddressText = (u64)((char*)p-(char*)pFileBase)+retLineChars[2];//0d uchun;
	  if(iAddressText<3)iAddressText=0;
	 }else iAddressText=0;
	 si.nPos = (int)iAddressText;
	 si.fMask = SIF_POS;
	 SetScrollInfo(hWndPnl,SB_VERT,&si,TRUE);
	 OnDraw(0,1);
  }
  if(!bInScrollSelect && bBgnSelSuccess)
  {	selctBgn.y += ySpaceText;
	selct.y += ySpaceText;
}}}

VOID LineUp16()
{u64 iiAddress;wchar_t *p;int limit=0;BOOL bFind=FALSE;SCROLLINFO si;
 //if(0!=iAddressText)
 {CheckAddressParity16(&iAddressText,TRUE);  
  iiAddress=iAddressText;
  p = (wchar_t*)((u8*)pFileBase+iAddressText);
  while(iiAddress>=(16==textFmtDesc?2:3))
  {	if(iAddressText-iiAddress>2 && CheckRetLineW(p-1))//0x0a==*p && 0x0d==*(p-1))
	{	--p;
		bFind=TRUE;
		break;
	}
	iiAddress-=2;
	--p;
	if(++limit>0xff)break;
  }
  if(bFind)
  {iAddressText = (u64)((char*)p-(char*)pFileBase)+retLineChars[2];//0d uchun;
   if(iAddressText<3)iAddressText=0;
  }else iAddressText=(u64)((char*)p-(char*)pFileBase);//0d uchun;
  si.nPos = (int)iAddressText;
  si.fMask = SIF_POS;
  SetScrollInfo(hWndPnl,SB_VERT,&si,TRUE);
  OnDraw(0,1);
}}

VOID LineDown(BOOL bInScrollSelect)
{SCROLLINFO si;
 if(!bLastRowDrawed)
 {if(16==textFmtDesc || 161==textFmtDesc)
   LineDown16();
  else
  {  BOOL bFind=FALSE;u64 iiAddress=iAddressText;
	 u8 *p = (u8*)pFileBase+iAddressText;
	 while(iiAddress<szFile)
	 {	if(CheckRetLineA(p))//0x0d==*p && 0x0a==*(p+1))
 		{	++p;
			bFind=TRUE;
			break;
		}
		++iiAddress;
		++p;
	 }
	 if(bFind)
	 {iAddressText = (u64)((char*)p-(char*)pFileBase)+retLineChars[2]-1;//0d0a uchun;
	  si.nPos = (int)iAddressText;
	  si.fMask = SIF_POS;
	  SetScrollInfo(hWndPnl,SB_VERT,&si,TRUE);
	  OnDraw(0,1);
  }	 }
  if((!bInScrollSelect) && bBgnSelSuccess)
  {	selctBgn.y -= ySpaceText;
	selct.y -= ySpaceText;
}}}

VOID CheckAddressParity16(u64 *addr,BOOL bFrontDir)
{	if(16==textFmtDesc)
	{	if(*addr%2)
		{	if(bFrontDir)
			{	if(*addr<szFile)
					(*addr)+=1;	
			}
			else
			{	if(*addr>1)
				(*addr)-=1;
	}	}	}
	else if(161==textFmtDesc)
	{	if(0==*addr%2)
		{	if(bFrontDir)
			{	if(*addr<szFile)
					(*addr)+=1;	
			}
			else
			{	if(*addr>1)
					(*addr)-=1;
}	}	}	}
  
VOID LineDown16()
{u64 iiAddress;wchar_t *p;int limit=0;BOOL bFind=FALSE;SCROLLINFO si;
 if(!bLastRowDrawed)
 {CheckAddressParity16(&iAddressText,TRUE);
  iiAddress=iAddressText;
  p = (wchar_t*)((u8*)pFileBase+iAddressText);
  while(iiAddress<szFile)
  {	if(CheckRetLineW(p))//0x0d==*p && 0x0a==*(p+1))
 	{	++p;
        bFind=TRUE;
		break;
	}
	iiAddress+=2;
	++p;
	if(++limit>0xff)break;
  }
  if(bFind)
	iAddressText = (u64)((char*)p-(char*)pFileBase)+retLineChars[2]-2;//0d0a uchun;
  else
	iAddressText = (u64)((char*)p-(char*)pFileBase);//0d0a uchun;
  si.nPos = (int)iAddressText;
  si.fMask = SIF_POS;
  SetScrollInfo(hWndPnl,SB_VERT,&si,TRUE);
  OnDraw(0,1);
}}

float deltaLineHScroll=0.5f;
VOID LineRight()
{	SCROLLINFO siWM;RECT r;GetClientRect(hWndPnl,&r);
	siWM.cbSize=sizeof(siWM);siWM.fMask=SIF_POS|SIF_RANGE;
	GetScrollInfo(hWndPnl,SB_HORZ,&siWM);
	if(xScroll<siWM.nMax-r.right)
	{	int pos = siWM.nPos+(int)deltaLineHScroll;
		if(pos>siWM.nMax-r.right)pos=siWM.nMax-r.right;
		xScroll = siWM.nPos = pos;
		OnDraw(0,2);
		siWM.fMask = SIF_POS;
		SetScrollInfo(hWndPnl,SB_HORZ,&siWM,TRUE);
		if(deltaLineHScroll<50.0f)deltaLineHScroll+=0.5f;
}	}

VOID LineLeft()
{	int pos;
	if(xScroll>0)
	{	SCROLLINFO siWM;siWM.cbSize=sizeof(siWM);siWM.fMask=SIF_POS|SIF_RANGE;
		GetScrollInfo(hWndPnl,SB_HORZ,&siWM);
		pos = siWM.nPos-(int)deltaLineHScroll;
		if(pos<0)pos=0;
		xScroll = siWM.nPos = pos;
		OnDraw(0,2);
		siWM.fMask = SIF_POS;
		SetScrollInfo(hWndPnl,SB_HORZ,&siWM,TRUE);
		if(deltaLineHScroll<50.0f)deltaLineHScroll+=0.5f;
}	}

VOID End()
{u64 iiAddress;u8 *p;int r;SCROLLINFO si;
 if(16==textFmtDesc || 161==textFmtDesc)
 {End16();
  return;
 }
 iiAddress=szFile;
 p = (u8*)pFileBase+szFile;
 if(p>(u8*)pFileBase)
 { for(r=0; r<nViewRows; ++r)
   {while(p>(u8*)pFileBase)
	{	if(CheckRetLineA(p-1))
		{	--p;
			break;
		}
		--p;
   }}
   iAddressText = (u64)((char*)p-(char*)pFileBase)+retLineChars[2];//0d0a uchun;
   if(iAddressText<3)iAddressText=0;
   si.nPos = (int)iAddressText;
   si.fMask = SIF_POS;
   SetScrollInfo(hWndPnl,SB_VERT,&si,TRUE);
   OnDraw(0,1);
}}

VOID End16()
{wchar_t *p;int r,iFind=0;u64 iiAddress=szFile;SCROLLINFO si;
 CheckAddressParity16(&iiAddress,FALSE);
 p = (wchar_t*)((u8*)pFileBase+iiAddress);
 if(p>(wchar_t*)pFileBase)
 { for(r=0; r<nViewRows; ++r)
   {int limit=0;
	while(p>(wchar_t*)pFileBase)
	{	if(CheckRetLineW(p-1))
		{	--p;
			++iFind;
			break;
		}
		--p;
		if(++limit>0xff)
			break;
   }}
   if(iFind)
	iAddressText = (u64)((char*)p-(char*)pFileBase)+retLineChars[2];
   else
	iAddressText = (u64)((char*)p-(char*)pFileBase);
   if(iAddressText<3)iAddressText=0;
   si.nPos = (int)iAddressText;
   si.fMask = SIF_POS;
   SetScrollInfo(hWndPnl,SB_VERT,&si,TRUE);
   OnDraw(0,1);
}}

VOID Home()
{   SCROLLINFO si;
	if(0==iAddressText)return;
	iAddressText = 0;
	si.nPos = 0;
	si.fMask = SIF_POS;
	SetScrollInfo(hWndPnl,SB_VERT,&si,TRUE);
	OnDraw(0,1);
}

VOID OnVScroll(WPARAM wParam)
{int pos;SCROLLINFO siWM;

	EndSelection();

	switch(LOWORD(wParam))
	{	case SB_THUMBPOSITION:
			//pos = (int)(HIWORD(wParam));
			siWM.cbSize=sizeof(siWM);siWM.fMask=SIF_TRACKPOS|SIF_RANGE;
			GetScrollInfo(hWndPnl,SB_VERT,&siWM);
			pos = siWM.nTrackPos;
			if(pos>=0 && pos<siWM.nMax)
			{	iAddressText = pos;
				LineDown(FALSE);
			}
			return;
		case SB_THUMBTRACK:
			//pos = (int)(HIWORD(wParam));
			siWM.cbSize=sizeof(siWM);siWM.fMask=SIF_TRACKPOS|SIF_RANGE;
			GetScrollInfo(hWndPnl,SB_VERT,&siWM);
			pos = siWM.nTrackPos;
			if(pos>=0 && pos<siWM.nMax)
			{	iAddressText = pos;
				LineDown(FALSE);
			}
			return;
		case SB_BOTTOM:
			End();
			return;
		case SB_ENDSCROLL:
			return;
		case SB_LINEDOWN:
			LineDown(FALSE);
			return;
		case SB_LINEUP:
			if(0!=iAddressText)
				LineUp(FALSE);
			return;
		case SB_PAGEDOWN:
			PageDown();
			return;
		case SB_PAGEUP:
			if(0!=iAddressText)
				PageUp();
			return;
		case SB_TOP:
			Home();
			return;
}	}

float delta=1.0f;
VOID OnHScroll(WPARAM wParam)
{int pos;SCROLLINFO siWM;RECT r;
	switch(LOWORD(wParam))
	{	case SB_THUMBPOSITION:
			siWM.cbSize=sizeof(siWM);siWM.fMask=SIF_TRACKPOS|SIF_RANGE;//|SIF_PAGE;
			GetScrollInfo(hWndPnl,SB_HORZ,&siWM);
			pos = siWM.nTrackPos;
			if(pos>=0 && pos<=siWM.nMax)
			{	xScroll = siWM.nPos = pos;
				OnDraw(0,2);
				siWM.fMask = SIF_POS;
				SetScrollInfo(hWndPnl,SB_HORZ,&siWM,TRUE);
			}
			return;
		case SB_THUMBTRACK:
			siWM.cbSize=sizeof(siWM);siWM.fMask=SIF_TRACKPOS|SIF_RANGE;
			GetScrollInfo(hWndPnl,SB_HORZ,&siWM);
			pos = siWM.nTrackPos;
			if(pos>=0 && pos<siWM.nMax)
			{	xScroll = siWM.nPos = pos;
				OnDraw(0,2);
				siWM.fMask = SIF_POS;
				SetScrollInfo(hWndPnl,SB_HORZ,&siWM,TRUE);
			}
			return;
		case SB_BOTTOM:
			siWM.cbSize=sizeof(siWM);siWM.fMask=SIF_TRACKPOS|SIF_RANGE;
			GetScrollInfo(hWndPnl,SB_HORZ,&siWM);
			xScroll = siWM.nMax;
			OnDraw(0,2);
			siWM.nPos = siWM.nMax;siWM.fMask = SIF_POS;
			SetScrollInfo(hWndPnl,SB_HORZ,&siWM,TRUE);
			return;
		case SB_ENDSCROLL:
			deltaLineHScroll=1;
			return;
		case SB_LINEDOWN:
			LineRight();
			return;
		case SB_LINEUP:
			LineLeft();
			return;
		case SB_PAGEDOWN:
			GetClientRect(hWndPnl,&r);
			siWM.cbSize=sizeof(siWM);siWM.fMask=SIF_POS|SIF_RANGE|SIF_PAGE;
			GetScrollInfo(hWndPnl,SB_HORZ,&siWM);
			if(xScroll<siWM.nMax-r.right)
			{	pos = siWM.nPos+siWM.nPage;
				if(pos>siWM.nMax-r.right)pos=siWM.nMax-r.right;
				xScroll = siWM.nPos = pos;
				OnDraw(0,2);
				siWM.fMask = SIF_POS;
				SetScrollInfo(hWndPnl,SB_HORZ,&siWM,TRUE);
			}
			return;
		case SB_PAGEUP:
			if(xScroll>0)
			{	siWM.cbSize=sizeof(siWM);siWM.fMask=SIF_POS|SIF_RANGE|SIF_PAGE;
				GetScrollInfo(hWndPnl,SB_HORZ,&siWM);
				pos = siWM.nPos-siWM.nPage;
				if(pos<0)pos=0;
				xScroll = siWM.nPos = pos;
				OnDraw(0,2);
				siWM.fMask = SIF_POS;
				SetScrollInfo(hWndPnl,SB_HORZ,&siWM,TRUE);
			}
			return;
		case SB_TOP:
			if(xScroll>0)
			{	siWM.cbSize=sizeof(siWM);
				xScroll = 0;
				OnDraw(0,2);
				siWM.nPos = 0;siWM.fMask = SIF_POS;
				SetScrollInfo(hWndPnl,SB_HORZ,&siWM,TRUE);
			}
			return;
}	}

VOID OnDraw(HDC dc,int inScroll)
{RECT r;int maxWidth=0;
 HDC hDC=dc?dc:GetDC(hWndPnl);
 if(!bFileLoaded)return;
 if(finished==crctScrlSt)
 {	OnDrawCrct(dc,inScroll);
	return;
 }
 GetClientRect(hWndPnl,&r);

 if(8==textFmtDesc)
 	DrawTexts(hDC,&r,&maxWidth,&pNextPageTopAddress);
 else if(16==textFmtDesc || 161==textFmtDesc)
	DrawTexts16(hDC,&r,&maxWidth,&pNextPageTopAddress);

 //PatBlt(hDC,0,0,600,600,PATINVERT);
 if(bBgnSelSuccess)
	 DrawSelectionBack(hDC);
 else OutputDebugString(L"\nelse");

 if(!dc)ReleaseDC(hWndPnl,hDC);
 if(inScroll!=2 && maxWidth>r.right)
 {	SCROLLINFO si;si.cbSize=sizeof(si);
	si.fMask=SIF_RANGE|SIF_PAGE;si.nMin=0;si.nMax=maxWidth;si.nPage=r.right;
	SetScrollInfo(hWndPnl,SB_HORZ,&si,TRUE);
 }
 if(0==inScroll)
 {	u64 szToNextPage=(u64)((char*)pNextPageTopAddress-(char*)pFileBase);
	SCROLLINFO si;si.cbSize=sizeof(si);
	si.fMask=SIF_RANGE|SIF_PAGE|SIF_POS;si.nMin=0;si.nMax=(int)szFile;si.nPage=(int)(szToNextPage-iAddressText);
	si.nPos=(int)szToNextPage;
	if(8!=textFmtDesc)
	{	si.nPos/=2;si.nMax/=2;si.nPage/=2;
	}
	SetScrollInfo(hWndPnl,SB_VERT,&si,TRUE);		
}}