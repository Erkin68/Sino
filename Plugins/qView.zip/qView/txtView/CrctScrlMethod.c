#include "txtView.h"
#include "stdio.h"


CorrectScrollState crctScrlSt=fast;//in starting;
s64 iCrtScrlLines,iCrtScrlCrntLines,iCrctScrlMaxHorChars,iCrctScrlMaxHorCharsWidth;
u8 **linesStarts=0;
u8 *pInMaxHorChars;
BOOL bOrderToCrctCalcing=FALSE,bOrderToStopCrctCalcing;

VOID SetScrollInResizeCrct()
{	RECT rc;SCROLLINFO si;

	GetClientRect(hWndPnl,&rc);
	si.cbSize=sizeof(si);si.fMask=SIF_POS;
	GetScrollInfo(hWndPnl,SB_HORZ,&si);
	si.fMask=SIF_RANGE|SIF_POS|SIF_PAGE;si.nMin=0;
	si.nMax=(int)iCrctScrlMaxHorCharsWidth;si.nPage=rc.right;
	SetScrollInfo(hWndPnl,SB_HORZ,&si,TRUE);
	si.nMax=(int)iCrtScrlLines;si.nPage=nViewRows;
	SetScrollInfo(hWndPnl,SB_VERT,&si,TRUE);
}

VOID CalcCorrectScrollingA()
{	int pr=0,imx=0,linesStartsSize = 1000;//1000 tadan oshirib boramiz;
	u8 *p,*pp,*pBgn,*pEnd;
	u64 i=0;
	HDC dc;SIZE sz;

	//SendMessage(hPrgs,PBM_SETRANGE32,0,1000);
	//SendMessage(hPrgs,PBM_SETPOS,0,0);
	//SetWindowText(hStat,L"Calculating lines,scrolling info...");
	crctScrlSt=calcThread;
	bOrderToStopCrctCalcing=FALSE;
	iCrtScrlLines=iCrctScrlMaxHorChars=iCrctScrlMaxHorCharsWidth=0;
	if(linesStarts)linesStarts=(u8**)realloc(linesStarts,linesStartsSize*sizeof(u8*));
	else linesStarts=(u8**)malloc(linesStartsSize*sizeof(u8*));

	//linesStarts[iCrtScrlLines++]=(u8*)pFileBase;
	pInMaxHorChars = (u8*)pFileBase;

	p = (u8*)pFileBase;pp=p;
	for(i=0; i<szFile-1; ++i)
	{	if(++imx>0xff || CheckRetLineA(p))
		{	s64 ss;
			if(iCrtScrlLines>linesStartsSize-2)
			{	linesStartsSize+=1000;
				linesStarts=(u8**)realloc(linesStarts,linesStartsSize*sizeof(u8*));
			}
			linesStarts[iCrtScrlLines++]=pp;
			ss=(s64)(p-pp);
			if(ss>iCrctScrlMaxHorChars)
			{	iCrctScrlMaxHorChars=ss;
				pInMaxHorChars=pp;
			}
			pp=p+retLineChars[2];
			imx=0;
		}
		++p;
		if(0==i%1000)
		{	MessageProcess();
			//if(szFile>0)
			//	SendMessage(hPrgs,PBM_SETPOS,(WPARAM)(1000*i/szFile),0);
		}
		if(bOrderToStopCrctCalcing)
		{	crctScrlSt=fast;
			//SendMessage(hPrgs,PBM_SETPOS,1000,0);
			//SetWindowText(hStat,L"Calculating lines,scrolling info emergency shutdowning.");
			return;
	}	}
	if(szFile>0 && 0==iCrtScrlLines)
		linesStarts[iCrtScrlLines++]=(u8*)pFileBase;
	dc=GetDC(hWndPnl);
	pBgn=pInMaxHorChars;pEnd= pBgn+iCrctScrlMaxHorChars;
	if(pBgn==pEnd)pEnd=p;
	//iCrctScrlMaxHorCharsWidth=0 qiluvdik;
	//SetWindowText(hStat,L"Calculating horizontal spacing...");
	while(pBgn<pEnd)
	{	int isz=(int)(pBgn+0xff<pEnd?0xff:pEnd-pBgn);//bayt ANSI uchun;
		GetTextExtentPoint32A(dc,(LPCSTR)pBgn,isz,&sz);
		pBgn+=isz;iCrctScrlMaxHorCharsWidth+=sz.cx;
		//SendMessage(hPrgs,PBM_SETPOS,(WPARAM)pr,0);
		if(++pr>1000)pr=0;
	}
	ReleaseDC(hWndPnl,dc);
	SetScrollInResizeCrct();
	//SendMessage(hPrgs,PBM_SETPOS,1000,0);
	//SetWindowText(hStat,L"Calculating lines,scrolling info finished.");
	iCrtScrlCrntLines=0;iAddressText=0;
	crctScrlSt=finished;
	//SetCursor(hArrCursor);
}

VOID PageDownCrct()
{ SCROLLINFO si;
  if(iCrtScrlCrntLines<iCrtScrlLines-nViewRows+1)
  {	iCrtScrlCrntLines += nViewRows-1;
	if(iCrtScrlCrntLines>iCrtScrlLines-nViewRows+1)
		iCrtScrlCrntLines=iCrtScrlLines-nViewRows+1;
	if(8==textFmtDesc)
		iAddressText = (u64)(linesStarts[iCrtScrlCrntLines]-(u8*)pFileBase);
	else
		iAddressText = (u64)((u8*)linesStartsW[iCrtScrlCrntLines]-(u8*)pFileBase);
    si.nPos = (int)iCrtScrlCrntLines;
    si.fMask = SIF_POS;
    SetScrollInfo(hWndPnl,SB_VERT,&si,TRUE);
	if(bBgnSelSuccess)
	{	int slcDY = nViewRows-1;
		if(0!=slcDY)
		{	selctBgn.y -= slcDY*ySpaceText;
			selct.y -= slcDY*ySpaceText;
	}	}
    OnDraw(0,1);
} }

VOID PageUpCrct()
{ SCROLLINFO si;
  if(iCrtScrlCrntLines>0)
  {	iCrtScrlCrntLines -= nViewRows-1;
	if(iCrtScrlCrntLines<0)
		iCrtScrlCrntLines=0;
	if(8==textFmtDesc)
		iAddressText = (u64)(linesStarts[iCrtScrlCrntLines]-(u8*)pFileBase);
	else
		iAddressText = (u64)((u8*)linesStartsW[iCrtScrlCrntLines]-(u8*)pFileBase);
    si.nPos = (int)iCrtScrlCrntLines;
    si.fMask = SIF_POS;
    SetScrollInfo(hWndPnl,SB_VERT,&si,TRUE);
	if(bBgnSelSuccess)
	{	int slcDY = nViewRows-1;
		if(0!=slcDY)
		{	selctBgn.y += slcDY*ySpaceText;
			selct.y += slcDY*ySpaceText;
	}	}
    OnDraw(0,1);
} }

VOID LineUpCrct(BOOL bInScrollSelect)
{ SCROLLINFO si;
  if(iCrtScrlCrntLines>0)
  {	if(8==textFmtDesc)
		iAddressText = (u64)(linesStarts[--iCrtScrlCrntLines]-(u8*)pFileBase);
	else
		iAddressText = (u64)((u8*)linesStartsW[--iCrtScrlCrntLines]-(u8*)pFileBase);
    si.nPos = (int)iCrtScrlCrntLines;
    si.fMask = SIF_POS;
    SetScrollInfo(hWndPnl,SB_VERT,&si,TRUE);
	if(!bInScrollSelect && bBgnSelSuccess)
	{	selctBgn.y += ySpaceText;
		selct.y += ySpaceText;
	}
    OnDraw(0,1);
} }

VOID LineDownCrct(BOOL bInScrollSelect)
{ SCROLLINFO si;
  if(iCrtScrlCrntLines<iCrtScrlLines-nViewRows+1)
  {	if(8==textFmtDesc)
		iAddressText = (u64)(linesStarts[++iCrtScrlCrntLines]-(u8*)pFileBase);
	else
		iAddressText = (u64)((u8*)linesStartsW[++iCrtScrlCrntLines]-(u8*)pFileBase);
    si.nPos = (int)iCrtScrlCrntLines;
    si.fMask = SIF_POS;
    SetScrollInfo(hWndPnl,SB_VERT,&si,TRUE);
	if(!bInScrollSelect && bBgnSelSuccess)
	{	selctBgn.y -= ySpaceText;
		selct.y -= ySpaceText;
	}
    OnDraw(0,1);
} }

VOID HomeCrct()
{   SCROLLINFO si;
	int slcDY = (int)iCrtScrlCrntLines;
	BOOL b = (0==iAddressText);
	iAddressText = iCrtScrlCrntLines = 0;
	si.nPos = 0;
	si.fMask = SIF_POS;
	SetScrollInfo(hWndPnl,SB_VERT,&si,TRUE);
	if(b)return;
	if(bBgnSelSuccess)
	{	if(0!=slcDY)
		{	selctBgn.y -= slcDY*ySpaceText;
			selct.y -= slcDY*ySpaceText;
	}	}
	OnDraw(0,1);
}

VOID EndCrct()
{ SCROLLINFO si;
  if(iCrtScrlCrntLines<iCrtScrlLines-nViewRows+1)
  {	int slcDY = (int)(iCrtScrlCrntLines-iCrtScrlLines+nViewRows-1);
	iCrtScrlCrntLines = iCrtScrlLines-nViewRows+1;
	if(8==textFmtDesc)
		iAddressText = (u64)(linesStarts[iCrtScrlCrntLines]-(u8*)pFileBase);
	else//if(16==textFmtDesc || 161)
		iAddressText = (u64)((u8*)linesStartsW[iCrtScrlCrntLines]-(u8*)pFileBase);
    si.nPos = (int)iCrtScrlLines;
    si.fMask = SIF_POS;
    SetScrollInfo(hWndPnl,SB_VERT,&si,TRUE);
	if(bBgnSelSuccess)
	{	if(0!=slcDY)
		{	selctBgn.y -= slcDY*ySpaceText;
			selct.y -= slcDY*ySpaceText;
	}	}
    OnDraw(0,1);
} }

VOID OnVScrollCrct(WPARAM wParam)
{int pos;SCROLLINFO siWM;

	switch(LOWORD(wParam))
	{	case SB_THUMBPOSITION:
			//pos = (int)(HIWORD(wParam));
			siWM.cbSize=sizeof(siWM);siWM.fMask=SIF_TRACKPOS|SIF_RANGE;
			GetScrollInfo(hWndPnl,SB_VERT,&siWM);
			pos = siWM.nTrackPos;
			if(pos>=0 && pos<siWM.nMax)
			{	if(bBgnSelSuccess)
				{	int slcDY = (int)(iCrtScrlCrntLines-pos);
					if(0!=slcDY)
					{	selctBgn.y += slcDY*ySpaceText;
						selct.y += slcDY*ySpaceText;
				}	}
				iCrtScrlCrntLines = pos;
			  	if(8==textFmtDesc)
					iAddressText = (u64)(linesStarts[iCrtScrlCrntLines]-(u8*)pFileBase);
				else
					iAddressText = (u64)((u8*)linesStartsW[iCrtScrlCrntLines]-(u8*)pFileBase);
			    OnDraw(0,1);
			    siWM.fMask = SIF_POS;
				siWM.nPos = pos;
				SetScrollInfo(hWndPnl,SB_VERT,&siWM,TRUE);
			}
			return;
		case SB_THUMBTRACK:
			//pos = (int)(HIWORD(wParam));
			siWM.cbSize=sizeof(siWM);siWM.fMask=SIF_TRACKPOS|SIF_RANGE;
			GetScrollInfo(hWndPnl,SB_VERT,&siWM);
			pos = siWM.nTrackPos;
			if(pos>=0 && pos<siWM.nMax)
			if(pos>=0 && pos<siWM.nMax)
			{	if(bBgnSelSuccess)
				{	int slcDY = (int)(iCrtScrlCrntLines-pos);
					if(0!=slcDY)
					{	selctBgn.y += slcDY*ySpaceText;
						selct.y += slcDY*ySpaceText;
				}	}
				iCrtScrlCrntLines = pos;
			  	if(8==textFmtDesc)
					iAddressText = (u64)(linesStarts[iCrtScrlCrntLines]-(u8*)pFileBase);
				else
					iAddressText = (u64)((u8*)linesStartsW[iCrtScrlCrntLines]-(u8*)pFileBase);
			    OnDraw(0,1);
			}
			return;
		case SB_BOTTOM:
			EndCrct();
			return;
		case SB_ENDSCROLL:
			return;
		case SB_LINEDOWN:
			LineDownCrct(FALSE);
			return;
		case SB_LINEUP:
			if(0!=iAddressText)
				LineUpCrct(FALSE);
			return;
		case SB_PAGEDOWN:
			PageDownCrct();
			return;
		case SB_PAGEUP:
			if(0!=iAddressText)
				PageUpCrct();
			return;
		case SB_TOP:
			HomeCrct();
			return;
}	}

extern float delta;
VOID OnHScrollCrct(WPARAM wParam)
{int pos;SCROLLINFO siWM;RECT r;
	switch(LOWORD(wParam))
	{	case SB_THUMBPOSITION:
			siWM.cbSize=sizeof(siWM);siWM.fMask=SIF_TRACKPOS|SIF_RANGE;//|SIF_PAGE;
			GetScrollInfo(hWndPnl,SB_HORZ,&siWM);
			pos = siWM.nTrackPos;
			if(pos>=0 && pos<=siWM.nMax)
			{	xScroll = siWM.nPos = pos;
				OnDraw(0,2);
				siWM.fMask = SIF_POS;
				SetScrollInfo(hWndPnl,SB_HORZ,&siWM,TRUE);
			}
			return;
		case SB_THUMBTRACK:
			siWM.cbSize=sizeof(siWM);siWM.fMask=SIF_TRACKPOS|SIF_RANGE;
			GetScrollInfo(hWndPnl,SB_HORZ,&siWM);
			pos = siWM.nTrackPos;
			if(pos>=0 && pos<siWM.nMax)
			{	xScroll = siWM.nPos = pos;
				OnDraw(0,2);
				siWM.fMask = SIF_POS;
				SetScrollInfo(hWndPnl,SB_HORZ,&siWM,TRUE);
			}
			return;
		case SB_BOTTOM:
			siWM.cbSize=sizeof(siWM);siWM.fMask=SIF_TRACKPOS|SIF_RANGE;
			GetScrollInfo(hWndPnl,SB_HORZ,&siWM);
			xScroll = siWM.nMax;
			OnDraw(0,2);
			siWM.nPos = siWM.nMax;siWM.fMask = SIF_POS;
			SetScrollInfo(hWndPnl,SB_HORZ,&siWM,TRUE);
			return;
		case SB_ENDSCROLL:
			deltaLineHScroll=1;
			return;
		case SB_LINEDOWN:
			LineRight();
			return;
		case SB_LINEUP:
			LineLeft();
			return;
		case SB_PAGEDOWN:
			GetClientRect(hWndPnl,&r);
			siWM.cbSize=sizeof(siWM);siWM.fMask=SIF_POS|SIF_RANGE|SIF_PAGE;
			GetScrollInfo(hWndPnl,SB_HORZ,&siWM);
			if(xScroll<siWM.nMax-r.right)
			{	pos = siWM.nPos+siWM.nPage;
				if(pos>siWM.nMax-r.right)pos=siWM.nMax-r.right;
				xScroll = siWM.nPos = pos;
				OnDraw(0,2);
				siWM.fMask = SIF_POS;
				SetScrollInfo(hWndPnl,SB_HORZ,&siWM,TRUE);
			}
			return;
		case SB_PAGEUP:
			if(xScroll>0)
			{	siWM.cbSize=sizeof(siWM);siWM.fMask=SIF_POS|SIF_RANGE|SIF_PAGE;
				GetScrollInfo(hWndPnl,SB_HORZ,&siWM);
				pos = siWM.nPos-siWM.nPage;
				if(pos<0)pos=0;
				xScroll = siWM.nPos = pos;
				OnDraw(0,2);
				siWM.fMask = SIF_POS;
				SetScrollInfo(hWndPnl,SB_HORZ,&siWM,TRUE);
			}
			return;
		case SB_TOP:
			if(xScroll>0)
			{	siWM.cbSize=sizeof(siWM);
				xScroll = 0;
				OnDraw(0,2);
				siWM.nPos = 0;siWM.fMask = SIF_POS;
				SetScrollInfo(hWndPnl,SB_HORZ,&siWM,TRUE);
			}
			return;
}	}

VOID OnDrawCrct(HDC dc,int inScroll)
{RECT r;int maxWidth=0;
 HDC hDC=dc?dc:GetDC(hWndPnl);
 GetClientRect(hWndPnl,&r);

 if(8==textFmtDesc)
 	DrawTextsCrct(hDC,&r,&maxWidth,&pNextPageTopAddress);
 else if(16==textFmtDesc || 161==textFmtDesc)
 	DrawTextsCrctW(hDC,&r,&maxWidth,&pNextPageTopAddress);

 if(bBgnSelSuccess)
	 DrawSelectionBack(hDC);

 if(!dc)ReleaseDC(hWndPnl,hDC);
}

VOID DrawTextsCrct(HDC hDC,RECT *rDC,int *maxWidth,LPVOID* pNextPageTopAddress)
{RECT rc = *rDC;HFONT oldFnt;int row;
 u8 *pBgn,*pEnd;

 FillRect(hDC,&rc,bluBrsh);
 
 rc.left += 2;
 rc.right -= 1;
 rc.top = 0;
 rc.bottom = ySpaceText-1;

 SetBkColor(hDC,backColorText);
 SetTextColor(hDC,textColorText);
 oldFnt=(HFONT)SelectObject(hDC,fntText);

 for(row=0; row<nViewRows; ++row)
 {	s64 i = iCrtScrlCrntLines+row;
	s64 SLN=0,rowLen;int sln,rcBgn=0,iBgnPos=-1,iEndPos=-1;SIZE sz={0,0};	
	if(i>iCrtScrlLines-1)break;
	pBgn = linesStarts[i];
	pEnd = (i<iCrtScrlLines-1) ? linesStarts[i+1] :	((u8*)pFileBase+szFile);
	rowLen = (u64)(pEnd - pBgn);
	for(sln=0; sln<rowLen; sln++)
	{	if(SLN==xScroll && -1==iBgnPos)
		{	iBgnPos = sln;
			rcBgn = 0;
		}
		else if(SLN>xScroll && -1==iBgnPos)
		{	iBgnPos = sln-1;
			rcBgn = (int)(SLN-sz.cx-xScroll);
		}
		else if(SLN>xScroll+rc.right && -1==iEndPos)
		{	iEndPos = sln;
			break;
		}
		GetTextExtentPoint32A(hDC,(LPCSTR)&pBgn[sln],1,&sz);
		SLN += sz.cx;
	}
	if(iBgnPos>-1)
	{	if(-1==iEndPos)
			iEndPos = (int)rowLen;
		ExtTextOutA(hDC,rc.left+rcBgn,rc.top,0,&rc,(LPCSTR)&pBgn[iBgnPos],iEndPos-iBgnPos,NULL);
		//TextOutA(hDC,rc.left+rcBgn,rc.top,(LPCSTR)&pBgn[iBgnPos],iEndPos-iBgnPos);
		//if(0==row)
		//{	char ss[32];sprintf(ss,"\nrcLeft: %d, chPos: %d",rc.left+rcBgn,iBgnPos);
		//	OutputDebugStringA(ss);
	}	//}
	rc.top += ySpaceText;
	rc.bottom = rc.top+ySpaceText-1;
 }
 SelectObject(hDC,oldFnt);
}

u64 CalcPosInDrawTextsCrct(HDC hDC,RECT *rDC,int *xOut,int *yOut)
{RECT rc = *rDC;HFONT oldFnt;s64 rowLen;
 int row,SLN,oldSLN=0,sln=0;u8 *pBgn;
 int cptX = *xOut;
 int cptY = *yOut;

 rc.left += 2;
 rc.right -= 1;
 rc.top = 0;
 rc.bottom = ySpaceText-1;

 oldFnt=(HFONT)SelectObject(hDC,fntText);
 for(row=0; row<nViewRows; ++row)
 {	u8 *pEnd;int rcBgn=0,iBgnPos=-1,iEndPos=-1;SIZE sz={0,0};
	s64 i = iCrtScrlCrntLines+row;
	if(i>iCrtScrlLines-1)break;
	pBgn = linesStarts[i];
	pEnd = (i<iCrtScrlLines-1) ? linesStarts[i+1] :	((u8*)pFileBase+szFile);
	SLN=0;rowLen = (u64)(pEnd - pBgn);

	for(sln=0; sln<rowLen; sln++)
	{	if(SLN==xScroll && -1==iBgnPos)
		{	iBgnPos = sln;
			rcBgn = 0;
		}
		else if(SLN>xScroll && -1==iBgnPos)
		{	iBgnPos = sln-1;
			rcBgn = (int)(SLN-sz.cx-xScroll);
		}
		else if(SLN>xScroll+rc.right && -1==iEndPos)
		{	iEndPos = sln;
			break;
		}
		if(GetTextExtentPoint32A(hDC,(LPCSTR)pBgn,sln+1,&sz))//if(GetTextExtentPoint32A(hDC,(LPCSTR)&pBgn[sln],1,&sz))
		{	SLN = sz.cx;//SLN += sz.cx;
			if(rc.top<=cptY && rc.top+ySpaceText>=cptY)
			{	if(SLN>=cptX)//if(SLN-sz.cx-xScroll<=cptX && SLN-xScroll>=cptX)
					break;
		}	}
		oldSLN = SLN;
	}
	if(rc.top<=cptY && rc.top+ySpaceText>=cptY)
		break;
	rc.top += ySpaceText;
	rc.bottom = rc.top+ySpaceText-1;
 }
 SelectObject(hDC,oldFnt);
 if(rc.top<=cptY && rc.top+ySpaceText>=cptY)
	*xOut = oldSLN;//SLN-sz.cx;
 else *xOut = cptX;
 *yOut = rc.top;
 return (u64)(&pBgn[sln]-(u8*)pFileBase+1);
}