//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by FileAppend.rc
//
#define IDD_DIALOG_SEARCH               112
#define IDC_EDIT_SEARCH_TEXT			113
#define IDC_EDIT_FIND_ADDRESS			114
#define IDC_EDIT_FIND_LENGTH			115
#define IDC_EDIT_FIND_CMNT				116
#define IDC_STATIC1						21570
#define IDC_STATIC2						21571
#define IDC_CHECK_2						119
#define IDC_CHECK_8						120
#define IDC_CHECK_10					121
#define IDC_CHECK_16					122
#define IDC_CHECK_DOWN					123
#define IDC_CHECK_UP					124
#define IDC_CHECK_FROM_START			125
#define IDC_PROGRESS1					126


// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        127
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1014
#define _APS_NEXT_SYMED_VALUE           128
#endif
#endif
