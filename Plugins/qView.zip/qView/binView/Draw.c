#include "binView.h"
#include "resource.h"
#include "..\..\..\Operations\MyShell\MyShellC.h"

HWND hWndPnl=0;
BOOL bFileLoaded=FALSE;

LRESULT newPnlWndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{wchar_t *p,modPth[MAX_PATH],pth[MAX_PATH],tmp[MAX_PATH]=L" ";
PROCESS_INFORMATION pi;STARTUPINFO si;
PAINTSTRUCT ps;HDC dc;RECT rc;
	switch(msg)
	{	case WM_CREATE:
			return 0;
		case WM_PAINT:
			dc = BeginPaint(hWnd, &ps);
			OnDraw(dc);
            EndPaint(hWnd, &ps);
			return 0;
		case WM_SIZE:
			OnResizeWindow(LOWORD(lParam),HIWORD(lParam));
		return 0;
		case WM_VSCROLL:
			OnVScroll(wParam);
			return 0;
		case WM_KEYDOWN:
			switch(wParam)
			{	case VK_ESCAPE:
					DestroyWindow(hWnd);
					return 0;
				case VK_NEXT:
					PageDown();
				return 0;
				case VK_PRIOR:
					PageUp();
					return 0;
				case VK_DOWN:
					LineDown(TRUE);
				return 0;
				case VK_UP:
					LineUp(TRUE);
				return 0;
				case VK_HOME:
					Home();
				return 0;
				case VK_END:
					End();
				return 0;
				case 0x46://VK_F:
					if(0x8000 & GetKeyState(VK_CONTROL))
						DialogBoxParam(plgnDllInst, MAKEINTRESOURCE(IDD_DIALOG_SEARCH), hWnd, SearchDlg, 0);
					return 0;
				case VK_F3:
					DialogBoxParam(plgnDllInst, MAKEINTRESOURCE(IDD_DIALOG_SEARCH), hWnd, SearchDlg, 1);
					return 0;
				case 0x32/*VK_1*/:
					GetModuleFileName(NULL,modPth,MAX_PATH);
					p = wcsrchr(modPth,'\\');
					if(p)
					{	*p=0;MyStringCpy(pth,MAX_PATH,modPth);
						MyStringCpy(p,32,L"\\TextViewerRel.exe");
						p=wcsrchr(pth,'\\');
						if(p)*p=0;
						p=wcsrchr(pth,'\\');
						if(p)*p=0;
					}pi.hThread=0;ZeroMemory(&si,sizeof(si));si.cb=sizeof(si);
					tmp[0]=' ';MyStringCpy(&tmp[1],MAX_PATH-1,FilePathForSearch);
					if(CreateProcess(modPth,tmp,NULL,NULL,FALSE,0,NULL,pth,&si,&pi))
					{	if(pi.hThread)
							PostQuitMessage(0);
					}
				return 0;
			}
			return 0;
		case WM_MOUSEWHEEL:
			if(0>GET_WHEEL_DELTA_WPARAM(wParam))PageDown();
			else PageUp();
			return 0;
		case WM_DESTROY:
			GetWindowRect(hWnd,&rc);
			DeleteObject(fntAddr);
			DeleteObject(fntBin);
			DeleteObject(fntText);
			DeleteObject(adrrBackBrsh);
			DeleteObject(binBackBrsh);
			DeleteObject(textBackBrsh);
			CloseFileMap();
			break;
		case WM_CTLCOLORSTATIC:
			return (LRESULT)GetStockObject(DC_BRUSH);
		case WM_LBUTTONDOWN:
			if(bFileLoaded)
			{	if(bBgnSelSuccess)
				{	EndSelection();
					OnDraw(0);
				}
				capturePosX = (__int16)(LOWORD(lParam));
				capturePosY = (__int16)(HIWORD(lParam));
				if(BeginSelection())
				{	SetCapture(hWnd);
					bMouseCapture = TRUE;
			}	}
			return 0;
		case WM_LBUTTONUP:
			if(bFileLoaded && bMouseCapture)
			{	bMouseCapture = FALSE;
				ReleaseCapture();
				if(bTimerScrollSelection)
					KillTimer(hWnd,0);
			}
			return 0;
		case WM_MOUSEMOVE:
			if(bFileLoaded && bMouseCapture)
			{	capturePosToX = (int)(LOWORD(lParam));
				capturePosToY = (int)(HIWORD(lParam));
				if(SelectedItemsChanged())
					OnDraw(0);
			}
			return 0;
		case WM_TIMER:
			if(bFileLoaded)
				OnScrollSelectionTimer();
			return 0;
	}
	return DefWindowProc(hWnd,msg,wParam,lParam);
}

BOOL ChangeViewFile(wchar_t *filePthAndName)
{	FilePathForSearchLn=MyStringCpy(FilePathForSearch,MAX_PATH,filePthAndName);
	if(hFile)CloseFileMap();
	bFileLoaded = OpenBinaryFile();
	if(!bFileLoaded)return FALSE;
	GetClientRect(hWndPnl,&rcPnl);
	OnResizeWindow((WORD)rcPnl.right,(WORD)rcPnl.bottom);
	selctBgn.iAddress=selct.iAddress=0;
	OnDraw(0);
	return bFileLoaded;
}

BOOL InitViewer(HWND prnt, wchar_t *filePthAndName)
{WNDCLASSEX wc;RECT rc;ATOM a;
	FilePathForSearchLn=MyStringCpy(FilePathForSearch,MAX_PATH,filePthAndName);
	wc.cbSize=sizeof(wc);
	wc.hInstance=plgnDllInst;
	wc.hCursor=LoadCursor(NULL,IDC_ARROW);
	wc.hIcon=wc.hIconSm=NULL;
	wc.lpfnWndProc=(WNDPROC)newPnlWndProc;
	wc.lpszClassName=L"qvbin_class";
	wc.lpszMenuName=NULL;
	wc.cbClsExtra=0;
	wc.cbWndExtra=0;
	wc.style=CS_HREDRAW|CS_VREDRAW;  
	wc.hbrBackground=GetStockObject(WHITE_BRUSH); 
	a=RegisterClassEx(&wc);
	//if(!a)return FALSE;
	GetWindowRect(prnt,&rc);
	hWndPnl = CreateWindowEx(WS_EX_LEFT|WS_EX_CLIENTEDGE,
							 L"qvbin_class",
							 L"qvbin_window",
							 WS_VISIBLE|WS_CHILDWINDOW,
							 0,
							 0,
							 (int)(rc.right-rc.left),
							 (int)(rc.bottom-rc.top),
							 prnt,
							 0,
							 plgnDllInst,
							 0);
	if(!hWndPnl)return FALSE;
	return ChangeViewFile(filePthAndName);
}

VOID CloseViewer()
{	CloseFileMap();
	if(hWndPnl)DestroyWindow(hWndPnl);
	hWndPnl=0;
	UnregisterClass(L"qvbin_class",plgnDllInst);
}

__declspec (dllexport) BOOL Draw$8(HWND prnt, wchar_t* filePthAndName)
{	if(!prnt)return FALSE;
	if(!filePthAndName)return FALSE;
	if(0==filePthAndName[0])return FALSE;
	if(hWndPnl)
	{	if(0==wcscmp(FilePathForSearch,filePthAndName))
			return TRUE;
		else return ChangeViewFile(filePthAndName);
	}
	else//if(hWndPnl!=prnt)
		return InitViewer(prnt,filePthAndName);
	return TRUE;
}

int nRows=0,nColumns=0,nViewRows=25,nViewColumns=33,
	nViewFromChar=0,
	perCentOfAddr=10,perCentOfBin=65,perCentOfText=25;
u64 pageSz,szToEndRow;
SCROLLINFO si;
VOID OnResizeWindow(WORD w,WORD h)
{	int p;
	
	if(0==w && 0==h)return;
	if(0==xSpaceAddr)xSpaceAddr=18;
	if(0==xSpaceBin)xSpaceBin=18;
	if(0==ySpaceBin)ySpaceBin=18;
	if(0==xSpaceText)xSpaceText=18;

	ZeroMemory(&si,sizeof(si));
	si.cbSize=sizeof(si);

	nViewColumns = perCentOfBin * w / xSpaceBin / 100;
	if(nViewColumns<1)nViewColumns=1;
	nViewRows = (h+ySpaceBin-1) / ySpaceBin;
	if(nViewRows<1)nViewRows=1;
	pageSz = nViewColumns * nViewRows;

	p = iAddressView%nViewColumns;
	iAddressView -= p;

	p=szFile%nViewColumns;
	if(p)
		szToEndRow = szFile + nViewColumns - p;
	else
		szToEndRow = szFile;

	if(iAddressView>=szToEndRow-(nViewRows-1)*nViewColumns)//+nViewColumns*nViewRows>szToEndRow)
		iAddressView=szToEndRow-(nViewRows-1)*nViewColumns;

	if(pageSz>=szFile)
	{	si.nMin=si.nMax=si.nPage=si.nPos=si.nTrackPos=0;		
	}
	else
	{	si.nMin=0;
		si.nMax=(int)(szToEndRow/nViewColumns);
		si.nPage=nViewRows;//(int)(si.nMax*pageSz/sz);
		if(iAddressView<=pageSz)
			si.nPos=0;
		else
			si.nPos=(int)(iAddressView/nViewColumns);
	}

	si.fMask = SIF_PAGE|SIF_POS|SIF_RANGE;
	SetScrollInfo(hWndPnl,SB_VERT,&si,TRUE);
}

VOID PageDown()
{	if(iAddressView == szToEndRow - nViewColumns*(nViewRows-1))return;
	if(iAddressView+nViewColumns*(nViewRows-1)>szToEndRow)
		iAddressView = szToEndRow - nViewColumns*(nViewRows-1);
	else
		iAddressView += nViewColumns*(nViewRows-1);
	si.nPos = (int)(iAddressView / nViewColumns);
	si.fMask = SIF_POS;
	SetScrollInfo(hWndPnl,SB_VERT,&si,TRUE);
	OnDraw(0);
}

VOID PageUp()
{	if(0==iAddressView)return;
	if(iAddressView<nViewColumns*(nViewRows-1))
		iAddressView=0;
	else
		iAddressView -= nViewColumns*(nViewRows-1);
	si.nPos = (int)(iAddressView / nViewColumns);
	si.fMask = SIF_POS;
	SetScrollInfo(hWndPnl,SB_VERT,&si,TRUE);
	OnDraw(0);
}

VOID LineUp(BOOL bDraw)
{	if(0==iAddressView)
		return;
	if(iAddressView >= nViewColumns)
		iAddressView -= nViewColumns;
	else
		iAddressView = 0;
	si.nPos = (int)(iAddressView / nViewColumns);
	si.fMask = SIF_POS;
	SetScrollInfo(hWndPnl,SB_VERT,&si,TRUE);
	if(bDraw)
		OnDraw(0);
}

VOID LineDown(BOOL bDraw)
{	if(iAddressView+nViewRows*nViewColumns>szToEndRow)
		return;
	iAddressView += nViewColumns;
	si.nPos = (int)(iAddressView / nViewColumns);
	si.fMask = SIF_POS;
	SetScrollInfo(hWndPnl,SB_VERT,&si,TRUE);
	if(bDraw)
		OnDraw(0);
}

VOID End()
{	if(iAddressView==szToEndRow-(nViewRows-1)*nViewColumns)return;
	iAddressView=szToEndRow-(nViewRows-1)*nViewColumns;
	si.nPos = (int)(iAddressView / nViewColumns);
	si.fMask = SIF_POS;
	SetScrollInfo(hWndPnl,SB_VERT,&si,TRUE);
	OnDraw(0);
}

VOID Home()
{	if(0==iAddressView)return;
	iAddressView = 0;
	si.nPos = 0;
	si.fMask = SIF_POS;
	SetScrollInfo(hWndPnl,SB_VERT,&si,TRUE);
	OnDraw(0);
}

VOID OnVScroll(WPARAM wParam)
{int pos;SCROLLINFO siWM;

	switch(LOWORD(wParam))
	{	case SB_THUMBPOSITION:
			//pos = (int)(HIWORD(wParam));
			siWM.cbSize=sizeof(siWM);siWM.fMask=SIF_TRACKPOS;
			GetScrollInfo(hWndPnl,SB_VERT,&siWM);
			pos = siWM.nTrackPos;
			if(pos>=0 && pos<si.nMax)
			{	iAddressView = pos*nViewColumns;
				if(iAddressView+nViewRows*nViewColumns>szToEndRow)
					iAddressView=szToEndRow-(nViewRows-1)*nViewColumns;
				si.nPos=(int)((iAddressView+nViewColumns-1)/nViewColumns);
				si.fMask = SIF_POS;
				SetScrollInfo(hWndPnl,SB_VERT,&si,TRUE);
				OnDraw(0);
			}
			return;
		case SB_THUMBTRACK:
			//pos = (int)(HIWORD(wParam));
			siWM.cbSize=sizeof(siWM);siWM.fMask=SIF_TRACKPOS;
			GetScrollInfo(hWndPnl,SB_VERT,&siWM);
			pos = siWM.nTrackPos;
			if(pos>=0 && pos<si.nMax)
			{	iAddressView = pos*nViewColumns;
				if(iAddressView+nViewRows*nViewColumns>szToEndRow)
					iAddressView=szToEndRow-(nViewRows-1)*nViewColumns;
				si.nPos=(int)((iAddressView+nViewColumns-1)/nViewColumns);
				si.fMask = SIF_POS;
				SetScrollInfo(hWndPnl,SB_VERT,&si,TRUE);
				OnDraw(0);
			}
			return;
		case SB_BOTTOM:
			End();
			return;
		case SB_ENDSCROLL:
			return;
		case SB_LINEDOWN:
			LineDown(TRUE);
			return;
		case SB_LINEUP:
			LineUp(TRUE);
			return;
		case SB_PAGEDOWN:
			PageDown();
			return;
		case SB_PAGEUP:
			PageUp();
			return;
		case SB_TOP:
			Home();
			return;
}	}

VOID OnDraw(HDC dc)
{RECT r;HDC hDC;
 GetClientRect(hWndPnl,&r);
 hDC=dc?dc:GetDC(hWndPnl);

 MoveToEx(hDC,perCentOfAddr*r.right/100,0,NULL);
 LineTo(hDC,perCentOfAddr*r.right/100,r.bottom);
 MoveToEx(hDC,(perCentOfAddr+perCentOfBin)*r.right/100,0,NULL);
 LineTo(hDC,(perCentOfAddr+perCentOfBin)*r.right/100,r.bottom);
 
if(bFileLoaded)
{
 DrawAddress(hDC,&r);
 DrawBin(hDC,&r);

 if(8==textFmtDesc)
	DrawTexts(hDC,&r);
 else if(16==textFmtDesc)
	DrawTexts16Even(hDC,&r);
 else //if(161==textFmtDesc)
	DrawTexts16Odd(hDC,&r);

 if(0==nViewColumns%2)
 {	MoveToEx(hDC,perCentOfAddr*r.right/100+perCentOfBin*r.right/200-xSpaceBin/2,0,NULL);
	LineTo(hDC,perCentOfAddr*r.right/100+perCentOfBin*r.right/200-xSpaceBin/2,r.bottom);
 }
 if(0==nViewColumns%4)
 {	MoveToEx(hDC,perCentOfAddr*r.right/100+perCentOfBin*r.right/400-xSpaceBin/2,0,NULL);
	LineTo(hDC,perCentOfAddr*r.right/100+perCentOfBin*r.right/400-xSpaceBin/2,r.bottom);
 	MoveToEx(hDC,perCentOfAddr*r.right/100+3*perCentOfBin*r.right/400-xSpaceBin/2,0,NULL);
	LineTo(hDC,perCentOfAddr*r.right/100+3*perCentOfBin*r.right/400-xSpaceBin/2,r.bottom);
 }

 if(bBgnSelSuccess)
	 DrawSelectionBack(hDC);
}
 if(!dc)ReleaseDC(hWndPnl,hDC);
}