#include "windows.h"

typedef unsigned char u8;
typedef unsigned __int32 u32;
typedef unsigned __int64 u64;

extern wchar_t FilePathForSearch[MAX_PATH];
extern int FilePathForSearchLn;
extern BOOL bFileLoaded;
extern int language;

extern HWND hWndPnl;
extern RECT rcPnl;

extern HANDLE hFile,hFileMap;
extern LPVOID pFileBase;
extern DWORD nFileSizeHigh,nFileSizeLow;
extern u64 szFile;
extern u64 pageSz,szToEndRow;
extern BOOL OpenBinaryFile();
extern BOOL CloseFileMap();

extern wchar_t **strngs;
extern HMODULE plgnDllInst;

extern BOOL InitViewer(HWND,wchar_t*);
extern BOOL ChangeViewFile(wchar_t*);
extern VOID CloseViewer();
extern VOID OnDraw(HDC);
extern VOID OnResizeWindow(WORD,WORD);
extern VOID OnVScroll(WPARAM);
extern VOID LineUp(BOOL);
extern VOID LineDown(BOOL);
extern VOID PageUp();
extern VOID PageDown();
extern VOID End();
extern VOID Home();

extern int nRows,nColumns,nViewRows,nViewColumns,
		   xSpaceAddr,xSpaceBin,ySpaceBin,xSpaceText,
		   nViewFromChar,
		   perCentOfAddr,perCentOfBin,perCentOfText;
extern BOOL bMouseCapture;
extern __int16 capturePosX,capturePosY,capturePosToX,capturePosToY;
extern COLORREF textColorText,backColorText;
extern BOOL addrFillZero;
extern UINT addrFmt,addrFmtDesc;

//DrawAddress.cpp:
extern int  addrMaxWidth8,addrMaxWidth10,addrMaxWidth16;
extern COLORREF textColorAddr,backColorAddr;
extern HFONT fntAddr;
extern LOGFONT addrLogFont;
extern HBRUSH adrrBackBrsh;
extern BOOL bAddrShowRowNum;
extern u64 iAddressView;
extern VOID DrawAddress(HDC,RECT*);

//DrawBinary.cpp:
extern SIZE widthOfHexChar;
extern COLORREF textColorBin,backColorBin;
extern HFONT fntBin;
extern LOGFONT binLogFont;
extern HBRUSH binBackBrsh;
extern UINT binFmt,binFmtDesc;
extern VOID DrawBin(HDC,RECT*);

//DrawText.cpp:
extern COLORREF textColorText,backColorText;
extern HFONT fntText;
extern LOGFONT textLogFont;
extern HBRUSH textBackBrsh;
extern UINT textFmt,textFmtDesc;
extern VOID DrawTexts(HDC,RECT*);
extern VOID DrawTexts16Even(HDC,RECT*);
extern VOID DrawTexts16Odd(HDC,RECT*);

//Selection.cpp
typedef struct TSelection
{	int nColumn;
	int nRow;
	u64 iAddress;
} Selection;
extern Selection selctBgn,selct;
extern COLORREF selctnColorBack;
extern HBRUSH selctnBrsh;
extern BOOL bBgnSelSuccess;
extern BOOL bTimerScrollSelection;
extern BOOL BeginSelection();
extern BOOL SelectedItemsChanged();
extern VOID DrawSelectionBack(HDC);
extern VOID EndSelection();
extern BOOL OnScrollSelectionTimer();
extern VOID CopyBinaryToClipboard();
extern VOID CopyTextToClipboard();

extern u8* MyStrCmpNNAPrgrs(u8*,u8*,int,int,HWND);
extern u8* MyStrCmpNNADirUpPrgrs(u8*,u8*,int,int,HWND);

//Search.c:
extern char srchText[MAX_PATH];
extern INT_PTR CALLBACK SearchDlg(HWND,UINT,WPARAM,LPARAM);
