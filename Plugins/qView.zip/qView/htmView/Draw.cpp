#pragma comment(lib, "amstrmid.lib")
#include <dshow.h>
#include "strsafe.h"
#include "windows.h"
#include <comdef.h>
#include <comdefsp.h>
#include <exdisp.h>
#include "ax.h"

#define WM_GRAPHNOTIFY  WM_APP + 1


extern "C"
{
#include "htmView.h"
#include "..\..\..\Operations\MyShell\MyShellC.h"

BOOL CALLBACK D_DP(HWND,UINT,WPARAM,LPARAM);

HWND hWndPnl=0,htmlWnd=0;

//OUR_GUID_ENTRY(CLSID_FilterGraph,0xe436ebb3,0x524f,0x11ce,0x9f,0x53,0x00,0x20,0xaf,0x0b,0xa7,0x70)
//DEFINE_GUID(IID_IFilterGraph,0xe436ebb3,0x524f,0x11ce,0x9f,0x53,0x00,0x20,0xaf,0x0b,0xa7,0x70);


BOOL ChangeViewFile(wchar_t *filePthAndName)
{	RECT rcPnl;
	imgFilePathAndNameLn=MyStringCpy(imgFilePathAndName,MAX_PATH,filePthAndName);
	GetClientRect(hWndPnl,&rcPnl);

	if(htmlWnd)DestroyWindow(htmlWnd);
	htmlWnd = CreateDialog(plgnDllInst,L"DIALOG_1",hWndPnl,(DLGPROC)D_DP);
	if(!htmlWnd)return FALSE;
	SetWindowPos(htmlWnd,0,0,0,rcPnl.right,rcPnl.bottom,SWP_SHOWWINDOW);
	//ShowWindow(htmlWnd,SW_SHOW);
	return TRUE;
}

//static WNDPROC savePnlWndProc;
//LRESULT newPnlWndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
//{	return CallWindowProc(savePnlWndProc,hWnd,msg,wParam,lParam);
//}

BOOL InitViewer(HWND prnt, wchar_t *filePthAndName)
{	imgFilePathAndNameLn=MyStringCpy(imgFilePathAndName,MAX_PATH,filePthAndName);
	hWndPnl = prnt;
	//savePnlWndProc = (WNDPROC)GetWindowLongPtr(prnt,GWLP_WNDPROC);
	//if(!savePnlWndProc) return FALSE;
	//if(!SetWindowLongPtr(prnt,GWLP_WNDPROC,(LONG)newPnlWndProc)) return FALSE;

	OleInitialize(0);
	AXRegister();

	return ChangeViewFile(filePthAndName);
}

VOID CloseViewer()
{	if(htmlWnd)DestroyWindow(htmlWnd);htmlWnd=0;
	UnregisterClassA("AX",GetModuleHandle(0));
	//SetWindowLongPtr(hWndPnl,GWLP_WNDPROC,(LONG)savePnlWndProc);
}

__declspec (dllexport) BOOL Draw$8(HWND prnt, wchar_t* filePthAndName)
{	if(!prnt)return FALSE;
	if(!filePthAndName)return FALSE;
	if(0==filePthAndName[0])return FALSE;
	if(IsDirExist(filePthAndName))return FALSE;
	if(hWndPnl==prnt)
	{	if(0==wcscmp(imgFilePathAndName,filePthAndName))
			return TRUE;
		else ChangeViewFile(filePthAndName);
	}
	else//if(hWndPnl!=prnt)
		InitViewer(prnt,filePthAndName);
	return TRUE;
}

BOOL CALLBACK D_DP(HWND hh,UINT mm,WPARAM ww,LPARAM ll)
{
	switch(mm)
	{	case WM_INITDIALOG:
  		{	HWND hX = GetDlgItem(hh,801);
			SendMessage(hX,AX_INPLACE,1,0);
			IWebBrowser2 *wb=0;
			SendMessage(hX,AX_QUERYINTERFACE,(WPARAM)&IID_IWebBrowser2,(LPARAM)&wb);
			if(wb)
			{	wb->put_Silent(VARIANT_TRUE);
				wb->Navigate(imgFilePathAndName,0,0,0,0);
				wb->Release();
			}
			return true;
	}	}
	return 0;
}
}