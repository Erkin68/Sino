#pragma comment(lib, "amstrmid.lib")
#include <dshow.h>
#include "resource.h"
#include "strsafe.h"

#define WM_GRAPHNOTIFY  WM_APP + 1

extern "C"
{
#include "mpView.h"
#include "..\..\..\Operations\MyShell\MyShellC.h"

HWND hWndPnl=0;
IGraphBuilder   *pGraph = NULL;
IMediaControl   *pMediaControl = NULL;
IMediaEventEx   *pEvent = NULL;
IVideoWindow    *pVidWin = NULL;

//OUR_GUID_ENTRY(CLSID_FilterGraph,0xe436ebb3,0x524f,0x11ce,0x9f,0x53,0x00,0x20,0xaf,0x0b,0xa7,0x70)
//DEFINE_GUID(IID_IFilterGraph,0xe436ebb3,0x524f,0x11ce,0x9f,0x53,0x00,0x20,0xaf,0x0b,0xa7,0x70);


BOOL ChangeViewFile(wchar_t *filePthAndName)
{	RECT rcPnl;
	imgFilePathAndNameLn=MyStringCpy(imgFilePathAndName,MAX_PATH,filePthAndName);
	GetClientRect(hWndPnl,&rcPnl);
	if(pGraph)
	{IVideoWindow *pVidWin = NULL;
	 IMediaControl *pMdaCntl = NULL;
	 pGraph->QueryInterface(IID_IMediaControl, (void **)&pMdaCntl);
	 pMdaCntl->Pause();
	 pGraph->QueryInterface(IID_IVideoWindow, (void **)&pVidWin);
	 pVidWin->put_Visible(OAFALSE);
	 pVidWin->put_Owner(NULL);
	 pMdaCntl->Release();
	 pEvent->Release();
	 pVidWin->Release();
	 pGraph->Release();
	 pGraph = NULL;
	 pVidWin = NULL;
	 pMediaControl = NULL;
	 pEvent = NULL;
	}
	//else
	{CoCreateInstance(CLSID_FilterGraph,NULL,CLSCTX_INPROC,IID_IGraphBuilder,(void**)&pGraph);
	 if(!pGraph)
	 {	CoUninitialize();
		return FALSE;
	 }
     pGraph->QueryInterface(IID_IMediaControl,(void**)&pMediaControl);
	 if(!pMediaControl)
	 {	pGraph->Release();
		CoUninitialize();
		return FALSE;
	 }
	 pGraph->QueryInterface(IID_IVideoWindow,(void**)&pVidWin);
	 if(!pVidWin)
	 {	pMediaControl->Release();
	 	pGraph->Release();
		CoUninitialize();
		return FALSE;
	 }
	 if(S_OK!=pGraph->RenderFile(filePthAndName, NULL))
	 {	pVidWin->Release();
		pMediaControl->Release();
	 	pGraph->Release();
		CoUninitialize();
		return FALSE;
	 }
     pVidWin->put_Owner((OAHWND)hWndPnl);
     //pVidWin->put_WindowStyle(WS_CHILD | WS_CLIPSIBLINGS);
	 pGraph->QueryInterface(IID_IMediaEventEx, (void **)&pEvent);
     pEvent->SetNotifyWindow((OAHWND)hWndPnl, WM_GRAPHNOTIFY, 0);
     pVidWin->SetWindowPosition(0,0,rcPnl.right,rcPnl.bottom);
     pMediaControl->Run();
	}
	return TRUE;
}

LRESULT newPnlWndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{	return DefWindowProc(hWnd,msg,wParam,lParam);
}

BOOL InitViewer(HWND prnt, wchar_t *filePthAndName)
{	HRESULT hRes = CoInitializeEx(NULL, COINIT_MULTITHREADED);//CoInitialize(NULL);
	if(!(S_OK==hRes || S_FALSE==hRes || RPC_E_CHANGED_MODE==hRes))return FALSE;
	imgFilePathAndNameLn=MyStringCpy(imgFilePathAndName,MAX_PATH,filePthAndName);

WNDCLASSEX wc;RECT rc;ATOM a;
	wc.cbSize=sizeof(wc);
	wc.hInstance=plgnDllInst;
	wc.hCursor=LoadCursor(NULL,IDC_ARROW);
	wc.hIcon=wc.hIconSm=NULL;
	wc.lpfnWndProc=(WNDPROC)newPnlWndProc;
	wc.lpszClassName=L"qvmpds_class";
	wc.lpszMenuName=NULL;
	wc.cbClsExtra=0;
	wc.cbWndExtra=0;
	wc.style=CS_HREDRAW|CS_VREDRAW;  
	wc.hbrBackground=(HBRUSH)GetStockObject(WHITE_BRUSH); 
	a=RegisterClassEx(&wc);
	//if(!a)return FALSE;
	GetWindowRect(prnt,&rc);
	hWndPnl = CreateWindowEx(WS_EX_LEFT|WS_EX_CLIENTEDGE,
							 L"qvmpds_class",
							 L"qvmpds_window",
							 WS_VISIBLE|WS_CHILDWINDOW,
							 0,
							 0,
							 (int)(rc.right-rc.left),
							 (int)(rc.bottom-rc.top),
							 prnt,
							 0,
							 plgnDllInst,
							 0);
	if(!hWndPnl)return FALSE;
	HDC dc=GetDC(hWndPnl);GetClientRect(prnt,&rc);
	FillRect(dc,&rc,(HBRUSH)(COLOR_WINDOW+1));
	ReleaseDC(hWndPnl,dc);
	return ChangeViewFile(filePthAndName);
}

VOID CloseViewer()
{	IVideoWindow *pVidWin = NULL;
	IMediaControl *pMdaCntl = NULL;
	if(!pGraph)return;
	

    //long evCode;
    //pEvent->WaitForCompletion(INFINITE, &evCode);

	// Stop the graph.
    pGraph->QueryInterface(IID_IMediaControl, (void **)&pMdaCntl);
    pMdaCntl->Pause();//Stop();
	//pGraph->Abort();

    pGraph->QueryInterface(IID_IVideoWindow, (void **)&pVidWin);
    pVidWin->put_Visible(OAFALSE);
    pVidWin->put_Owner(NULL);

    pMdaCntl->Release();
    pEvent->Release();
	pVidWin->Release();
	pGraph->Release();

    pGraph = NULL;
    pVidWin = NULL;
    pMediaControl = NULL;
    pEvent = NULL;

	CoUninitialize();
	if(hWndPnl)DestroyWindow(hWndPnl);
	hWndPnl=0;
	UnregisterClass(L"qvbin_class",plgnDllInst);
}

__declspec (dllexport) BOOL Draw$8(HWND prnt, wchar_t* filePthAndName)
{	if(!prnt)return FALSE;
	if(!filePthAndName)return FALSE;
	if(0==filePthAndName[0])return FALSE;
	if(IsDirExist(filePthAndName))return FALSE;
	if(hWndPnl)
	{	if(0==wcscmp(imgFilePathAndName,filePthAndName))
			return TRUE;
		else return ChangeViewFile(filePthAndName);
	}
	else//if(hWndPnl!=prnt)
		return InitViewer(prnt,filePthAndName);
}
}