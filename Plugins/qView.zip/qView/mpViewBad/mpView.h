#include "windows.h"

extern HMODULE hm;//image opener module(jpgdbg,dll, as sample)
extern HINSTANCE hInst;
extern HWND hWnd;

extern wchar_t imgFilePathAndName[MAX_PATH];
extern int imgFilePathAndNameLn;
extern int language;

extern HWND hWndPnl;
//extern RECT rcPnl;

extern wchar_t **strngs;
extern HMODULE plgnDllInst;

extern BOOL InitViewer(HWND,wchar_t*);
extern BOOL ChangeViewFile(wchar_t*);
extern __declspec (dllexport) VOID CloseViewer();