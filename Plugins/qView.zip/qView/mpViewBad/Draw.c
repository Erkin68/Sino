#pragma comment(lib,"Msimg32.lib")

#include "mpView.h"
#include "resource.h"
#include "strsafe.h"
#include "Vfw.h"
#include "Digitalv.h"
#include "..\..\..\Operations\MyShell\MyShellC.h"

HWND hWndPnl=0;
HWND hMCI=NULL;

BOOL ChangeViewFile(wchar_t *filePthAndName)
{	RECT rcPnl;//long r;
	imgFilePathAndNameLn=MyStringCpy(imgFilePathAndName,MAX_PATH,filePthAndName);
	GetClientRect(hWndPnl,&rcPnl);
	if(hMCI)
	{	//MCI_OPEN_PARMS mciOpenParms;
		MCIWndStop(hMCI);		
		//mciOpenParms.lpstrElementName = imgFilePathAndName;
		//mciSendCommand(0,MCI_OPEN,MCI_OPEN_ELEMENT,(DWORD)(LPVOID)&mciOpenParms);
		MCIWndOpen(hMCI,imgFilePathAndName,0);
	}
	else
	{	hMCI = MCIWndCreate(hWndPnl,plgnDllInst,MCIWNDF_SHOWALL,NULL);
		if(!hMCI)return FALSE;
		MCIWndRealize(hWndPnl, TRUE);
		MCIWndPutSource(hMCI,&rcPnl);
		MCIWndOpen(hMCI,imgFilePathAndName,0);
	}
	MCIWndPlay(hMCI);
	return TRUE;
}

static WNDPROC savePnlWndProc;
LRESULT newPnlWndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{ switch(msg)
  {case WM_COMMAND: 
     switch (wParam) 
     {	
     } 
   break;
   case MCIWNDM_NOTIFYMODE: 
 	 if (lParam == MCI_MODE_STOP)  // device stopped
	 {
	 }
	 Beep(0,0);
   break; 
  }
  return CallWindowProc(savePnlWndProc,hWnd,msg,wParam,lParam);
}

BOOL InitViewer(HWND prnt, wchar_t *filePthAndName)
{	RECT rc;HDC dc=GetDC(prnt);GetClientRect(prnt,&rc);
	imgFilePathAndNameLn=MyStringCpy(imgFilePathAndName,MAX_PATH,filePthAndName);
	hWndPnl = prnt;
	FillRect(dc,&rc,(HBRUSH)(COLOR_WINDOW+1));
	ReleaseDC(prnt,dc);
	savePnlWndProc = (WNDPROC)GetWindowLongPtr(prnt,GWLP_WNDPROC);
	if(!savePnlWndProc) return FALSE;
	if(!SetWindowLongPtr(prnt,GWLP_WNDPROC,(LONG)newPnlWndProc)) return FALSE;
	return ChangeViewFile(filePthAndName);
}

__declspec (dllexport) VOID CloseViewer()
{	if(hMCI)
	{	//mciSendCommand(MCI_ALL_DEVICE_ID, MCI_CLOSE, MCI_WAIT, NULL);
		//MCI_GENERIC_PARMS mciCloseParms;mciCloseParms.dwCallback=0;
		//MCIWndClose(hMCI);
		//hMCI=NULL;
		//MCIWndStop(hMCI);		
		//mciSendCommand(0,MCI_CLOSE,0,(DWORD)(LPVOID)&mciCloseParms);
		//SendMessage(hMCI,WM_CLOSE,0,0);
		//MCIWndDestroy(hMCI);
		
		//MCI_GENERIC_PARMS  mciClose;
		//DWORD mciID = mciGetDeviceID("avivideo");
		//mciSendCommand(mciID, MCI_CLOSE, 0L, (DWORD)(LPMCI_GENERIC_PARMS)&mciClose);
		MCIWndStop(hMCI);
		//MCIWndClose(hMCI);
		MCIWndDestroy(hMCI);

		//mciSendCommand( 0,MCI_CLOSE,MCI_WAIT,//MCI_ALL_DEVICE_ID
		//				(DWORD)(LPMCI_GENERIC_PARMS)&mciClose);
		
		hMCI=NULL;
	}
	SetWindowLongPtr(hWndPnl,GWLP_WNDPROC,(LONG)savePnlWndProc);
}

__declspec (dllexport) BOOL Draw$8(HWND prnt, wchar_t* filePthAndName)
{	if(!prnt)return FALSE;
	if(!filePthAndName)return FALSE;
	if(0==filePthAndName[0])return FALSE;
	if(IsDirExist(filePthAndName))return FALSE;
	if(hWndPnl==prnt)
	{	if(0==wcscmp(imgFilePathAndName,filePthAndName))
			return TRUE;
		else ChangeViewFile(filePthAndName);
	}
	else//if(hWndPnl!=prnt)
		InitViewer(prnt,filePthAndName);
	return TRUE;
}