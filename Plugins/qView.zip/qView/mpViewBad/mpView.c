#include "mpView.h"
#include "resource.h"
#include "strsafe.h"
#include "shlobj.h"
#include "..\..\..\Operations\Myshell\MyShellC.h"


wchar_t imgFilePathAndName[MAX_PATH]=L"";
int imgFilePathAndNameLn=0;
typedef BOOL (CALLBACK *saveOptions_t)(int,VOID*,int);
typedef BOOL (CALLBACK *readOptions_t)(int,VOID*,int);

saveOptions_t saveOptions=0;
readOptions_t readOptions=0;

int plgId = 0;

__declspec (dllexport) VOID SetCallbacks$4xxx(LPVOID frstCallback,...)
{
va_list args;
	va_start(args, frstCallback);//1
	saveOptions = (saveOptions_t)frstCallback;//1
	readOptions = (readOptions_t)va_arg(args, LPVOID);//2
va_end (args);
}

__declspec (dllexport) int GetPluginType()
{
	return 502;
}

__declspec (dllexport) const wchar_t* GetPluginName()
{
	return strngs[1];
}

__declspec (dllexport) const wchar_t* GetExtensions()
{
	return L"mpg;mp4;mp4v;3gp;3gpp;3g2;3gp2;mp4a;mp3;mid;rmi;midi;asf;wm;wma;wmv;wmd;wav;snd;au;mp2;avi;mov";
}

__declspec (dllexport) VOID SetId$4(int id)
{
	plgId = id;
}

__declspec (dllexport) const wchar_t* GetPluginDescription()
{
	return strngs[1];
}

__declspec (dllexport) VOID ShowOptionDialog(HWND prnt)
{
}