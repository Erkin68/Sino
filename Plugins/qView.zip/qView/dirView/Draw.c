#include "dirView.h"
#include "..\..\..\Operations\MyShell\MyShellC.h"

RECT rcClient;
HWND hWndPnl=0;
HDC  dcPnl;
BOOL bThreadRun=FALSE,bStopThread=FALSE;

__declspec (dllexport) BOOL Draw$8(HWND prnt, wchar_t* filePthAndName)
{	wchar_t *p;
	if(!prnt)
	{	return FALSE;
	}
	if(hWndPnl==prnt && 0==wcscmp(path,filePthAndName))//Init3D
	{	RenderDirs(TRUE);//FALSE;
		return TRUE;
	}else if(hWndPnl!=prnt)
	{	if(hWndPnl)Cleanup3DDevice8();
		Init3DDevice8(prnt);
	}
	if(bThreadRun)
	{	bStopThread=TRUE;
		WaitForThrd();
	}
	MyStringCpy(path,MAX_PATH,filePthAndName);
	p=wcsrchr(path,'\\');
	if(!p)pathLn=0;
	else pathLn = (int)(p-&path[0])+1;
	hWndPnl=prnt;
	CreateThread(NULL,0,(LPTHREAD_START_ROUTINE)DirThrd,0,0,0);
	return TRUE;
}

VOID DirThrd()
{	bThreadRun=TRUE;

	FreeFilesList();
	iMove=0;
	dt=1.57079632679f;
	KillTimer(hWndPnl,DrawDirTimerId);
	bTimerInstalled=FALSE;	
	bSorted = FALSE;

	ListFiles(path);
	RenderDirs(FALSE);
	bThreadRun=FALSE;
}

VOID WaitForThrd()
{	while(bThreadRun)Sleep(25);
}