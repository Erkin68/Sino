//#pragma comment(lib, "D:\\ProgsArchives\\2-3D\\DirectX\\DirectX8_SDK\\Libs\\prerelease\\d3d8.lib")
//#pragma comment(lib, "D:\\ProgsArchives\\2-3D\\DirectX\\DirectX8_SDK\\Libs\\prerelease\\d3dx8.lib")
#pragma comment(lib, "..\\..\\..\\DX8\\Libs\\prerelease\\d3d8.lib")
#pragma comment(lib, "..\\..\\..\\DX8\\Libs\\prerelease\\d3dx8.lib")
#pragma comment(lib, "..\\..\\..\\Bin\\MyShell.lib")
//#include "dirView.h"
//#include "..\..\..\..\..\Include\d3d9.h"

//D:\ProgsArchives\2-3D\DirectX\DirectX8_SDK\Include\prerelease

#include "dirViewC++.h"
//#include "D:\ProgsArchives\2-3D\DirectX\DirectX8_SDK\common\include\d3dfont.h"
#include "..\..\..\DX8\Common\Include\d3dfont.h"
#include "..\..\..\Operations\MyShell\MyShell.h"
#include "strsafe.h"
//#include "D:\ProgsArchives\2-3D\DirectX\DirectX8_SDK\common\include\d3dutil.h"

inline DWORD FtoDW( FLOAT f ) { return *((DWORD*)&f); }

extern "C"
{

LPDIRECT3D8 pD3D = NULL;
LPDIRECT3DDEVICE8 pd3dDevice = NULL;
D3DXMATRIX matWorld,matView,matProj;
D3DXVECTOR3 vUpVec = D3DXVECTOR3(0.0f,1.0f,0.0f);
//LPDIRECT3DTEXTURE8 pTexture = NULL;
LPDIRECT3DVERTEXBUFFER8 pVB = NULL;
//ID3DXFont* pFont = NULL;
CD3DFont* pFont;
//float worldRadius=0.0f;

BOOL bTimerInstalled=FALSE;
BOOL bSorted = FALSE;
float dt=1.57079632679f;int iMove=0;

BOOL RenderDirs(BOOL);


VOID D3DUtil_InitMaterial(D3DMATERIAL8& mtrl,FLOAT r,FLOAT g,FLOAT b,FLOAT a)
{
    ZeroMemory( &mtrl, sizeof(D3DMATERIAL8) );
    mtrl.Diffuse.r = mtrl.Ambient.r = r;
    mtrl.Diffuse.g = mtrl.Ambient.g = g;
    mtrl.Diffuse.b = mtrl.Ambient.b = b;
    mtrl.Diffuse.a = mtrl.Ambient.a = a;
	mtrl.Emissive.a = mtrl.Specular.a = 0.08f;
	mtrl.Emissive.r = mtrl.Specular.r = 0.02f;
	mtrl.Emissive.g = mtrl.Specular.g = 0.12f;
	mtrl.Emissive.b = mtrl.Specular.b = 0.02f;
	mtrl.Power = 0.0f;
}

BOOL InitD3D8()
{
	pD3D = Direct3DCreate8(D3D_SDK_VERSION);
	if(!pD3D)return FALSE;
	return TRUE;
}

VOID CleanupD3D8()
{	if( pD3D != NULL ) 
		pD3D->Release();
	pD3D = NULL;
}

VOID CALLBACK drawDirTimerProc(HWND hwnd,UINT uMsg,UINT_PTR idEvent,DWORD dwTime)
{
static BOOL bInTimer=FALSE;
	if(bInTimer)
	{	//OutputDebugString(L"\nOver timer func...");
		return;
	}
	bInTimer=TRUE;
	RenderDirs(FALSE);
	bInTimer=FALSE;
}

BOOL Init3DDevice8(HWND hWnd)
{	if(pd3dDevice) return FALSE;
    D3DDISPLAYMODE d3ddm;
    if(FAILED(pD3D->GetAdapterDisplayMode(D3DADAPTER_DEFAULT,&d3ddm)))
        return FALSE;

    // Set up the structure used to create the D3DDevice
    D3DPRESENT_PARAMETERS d3dpp;
    ZeroMemory( &d3dpp, sizeof(d3dpp) );
    d3dpp.Windowed = TRUE;
    d3dpp.SwapEffect = D3DSWAPEFFECT_DISCARD;
    d3dpp.BackBufferFormat = d3ddm.Format;
    d3dpp.EnableAutoDepthStencil = TRUE;
    d3dpp.AutoDepthStencilFormat = D3DFMT_D16;

    if(FAILED(pD3D->CreateDevice(	D3DADAPTER_DEFAULT, D3DDEVTYPE_HAL, hWnd,
									D3DCREATE_MULTITHREADED|D3DCREATE_HARDWARE_VERTEXPROCESSING,
                                    &d3dpp, &pd3dDevice)))
	{if(FAILED(pD3D->CreateDevice(	D3DADAPTER_DEFAULT, D3DDEVTYPE_HAL, hWnd,
									D3DCREATE_MULTITHREADED|D3DCREATE_SOFTWARE_VERTEXPROCESSING,
                                    &d3dpp, &pd3dDevice)))
	{if(FAILED(pD3D->CreateDevice(	D3DADAPTER_DEFAULT, D3DDEVTYPE_REF, hWnd,
									D3DCREATE_MULTITHREADED|D3DCREATE_SOFTWARE_VERTEXPROCESSING,
                                    &d3dpp, &pd3dDevice)))
		return FALSE;
	}}
	D3DXMatrixPerspectiveFovLH(&matProj,D3DX_PI/4,1.25f,1.0f,100.0f);

	/*wchar_t *p,s[MAX_PATH];GetModuleFileName(NULL,s,MAX_PATH);
	p=wcsrchr(s,'\\');
	if(p)
	{	MyStringCpy(p+1,MAX_PATH,L"Plugins\\qView\\Bump.jpg");
		D3DXCreateTextureFromFile(pd3dDevice,s,&pTexture);
	}*/

	/*LOGFONT logFont={0};
	logFont.lfHeight = -18;
	logFont.lfWeight = FW_NORMAL;
	logFont.lfCharSet = DEFAULT_CHARSET;
	wcscpy(logFont.lfFaceName,L"Arial");
	D3DXCreateFontIndirect(pd3dDevice,&logFont,&pFont);*/
	InitDeviceObjects();
	RestoreDeviceObjects();
    return TRUE;
}

VOID Cleanup3DDevice8()
{	//if(pTexture != NULL )
	//	pTexture->Release();
	//if(pFont != NULL)
	//	pFont->Release();
	//pFont = NULL;
	if(pFont){delete pFont;pFont=NULL;}
	if(pVB != NULL )
        pVB->Release();
	if(pd3dDevice != NULL ) 
        pd3dDevice->Release();
	pd3dDevice = NULL;
	KillTimer(hWndPnl,DrawDirTimerId);
}

BOOL RenderDirs(BOOL bProcessContinues)
{	if(!bProcessContinues)dt += 0.1f;
	if(dt>=TWOHALFPI)
	{	dt = HALFPI;
		if(!bProcessContinues)
		{	if(++iMove>iDirs-1)iMove=0;
	}	}
	//D3DXMATRIX matRot;D3DXMatrixRotationY(&matRot,dt);

	if(bProcessContinues)
	{	CalcDirScales();
		CalcRGBs();
	}

	if((!bProcessContinues) && (!bSorted))
	{	qsort(pDirs,iDirs,sizeof(DIR_REC),cmpDirFunc);
		bSorted = TRUE;
	}

	PlaceDirCyls();

	D3DXVECTOR3 vEyePt(1.0f+3.0f*cosf(dt), 2.0f, -3.0f*sinf(dt));
    D3DXVECTOR3 vLookatPt(1.0f, 1.0f, 0.0f);
	D3DXMatrixLookAtLH(&matView, &vEyePt, &vLookatPt, &vUpVec);
/*  D3DXMatrixLookAtLH(&matView, &D3DXVECTOR3(0.0f, 0.5f, -2.0f*worldRadius),
                                 &D3DXVECTOR3(0.0f, 0.0f, 0.0f),
                                 &D3DXVECTOR3(0.0f, 1.0f, 0.0f));*/
	D3DXMatrixIdentity(&matWorld);

	HRESULT res=pd3dDevice->TestCooperativeLevel();
	if(D3DERR_DEVICELOST==res)OnLostDevice();
	if(D3D_OK!=res)return FALSE;

    pd3dDevice->Clear(0,NULL,D3DCLEAR_TARGET|D3DCLEAR_ZBUFFER,0x001793c1,1.0f,0L);
    if(SUCCEEDED(pd3dDevice->BeginScene()))
    {	//pd3dDevice->SetTexture(0, pTexture);

		//pd3dDevice->SetVertexShader(D3DFVF_CUSTOMVERTEX);
		//pd3dDevice->DrawPrimitiveUP(D3DPT_TRIANGLESTRIP,2*50-2,&CylVerts[0],sizeof(D3DFVF_CUSTOMVERTEX));

		pd3dDevice->SetStreamSource(0,pVB,sizeof(CUSTOMVERTEX));
		pd3dDevice->SetVertexShader(D3DFVF_CUSTOMVERTEX);

		pd3dDevice->SetTransform(D3DTS_VIEW, &matView);
		pd3dDevice->SetTransform(D3DTS_PROJECTION, &matProj);

		D3DMATERIAL8 mtrl;D3DUtil_InitMaterial(mtrl,0.0f,0.0f,1.0f,1.0f);
		pd3dDevice->SetMaterial(&mtrl);

		/*FLOAT fFogStart =  5.0f;
		FLOAT fFogEnd   =  200.0f;
		pd3dDevice->SetRenderState( D3DRS_FOGENABLE,      TRUE );
		pd3dDevice->SetRenderState( D3DRS_FOGCOLOR,       0x009317c1 );
		pd3dDevice->SetRenderState( D3DRS_FOGTABLEMODE,   D3DFOG_EXP );
		pd3dDevice->SetRenderState( D3DRS_FOGVERTEXMODE,  D3DFOG_LINEAR );
		pd3dDevice->SetRenderState( D3DRS_RANGEFOGENABLE, FALSE );
		pd3dDevice->SetRenderState( D3DRS_FOGSTART,       FtoDW(fFogStart) );
		pd3dDevice->SetRenderState( D3DRS_FOGEND,         FtoDW(fFogEnd) );*/

		//float cx = matWorld._41;
		float cy = matWorld._42;float cz = matWorld._43;
		float fUp = 0.04f*(dt-HALFPI);
		for(int f=0; f<iDirs; ++f)
		{	int fMove=f;
			if(!bProcessContinues)
			{	fMove += iMove;
				if(fMove>iDirs-1)fMove-=iDirs;

				//static int ist=0;wchar_t ch[MAX_PATH];
				//wsprintf(ch,L"\n%d: path: %s iDirs: %d, fMove: %d, bSorted: %d, bStop: %d, bStopThread: %d, bThreadRun: %d, bTimerInstalled: %d",
				//		 ist++,path,iDirs,fMove,bSorted,bStop,bStopThread,bThreadRun,bTimerInstalled);
				//OutputDebugString(ch);


			}
			float kUp = (0==f?1.0f:1.54f/f);
			//matWorld._41 = cx + pDirs[f].x;
			matWorld._42 = cy + pDirs[f].y + fUp*kUp;
			matWorld._43 = cz + pDirs[f].z - fUp*kUp;

			if(0==f)mtrl.Ambient.a=mtrl.Diffuse.a=(TWOHALFPI-dt)/TWOHALFPI;
			else mtrl.Ambient.a=mtrl.Diffuse.a=1.0f;
			pd3dDevice->SetMaterial(&mtrl);

			D3DXMATRIX m,matSc;D3DXMatrixScaling(&matSc,pDirs[fMove].kSc,1.0f,1.0f);//pDirs[f] edi
			m = matWorld * matSc;
			pd3dDevice->SetTransform(D3DTS_WORLD, &m);
			//m = matView * matRot;
			pd3dDevice->DrawPrimitive(D3DPT_TRIANGLESTRIP,0,2*50-2);
		}

		//OutputDebugString(L" DBG1 ");

		unsigned char s[2*MAX_PATH];//wchar_t ws[2*MAX_PATH];
		matWorld._41 = 0.0f;
		D3DXMATRIX matSc;D3DXMatrixScaling(&matSc,0.06f,0.06f,0.06f);
		
		for(int f=0; f<iDirs; ++f)
		{	int fMove=f;
			if(!bProcessContinues)
			{	fMove += iMove;
				if(fMove>iDirs-1)fMove-=iDirs;
			}
			float kUp = (0==f?1.0f:1.54f/f);

			matWorld._42 = cy + pDirs[f].y + fUp*kUp;
			matWorld._43 = cz + pDirs[f].z - fUp*kUp;
			D3DXMATRIX m = matSc * matWorld;
			pd3dDevice->SetTransform(D3DTS_WORLD, &m);
			
			mtrl.Ambient.r=mtrl.Diffuse.r=pDirs[fMove].r;
			mtrl.Ambient.g=mtrl.Diffuse.g=pDirs[fMove].g;
			mtrl.Ambient.b=mtrl.Diffuse.b=pDirs[fMove].b;
			if(0==f)mtrl.Ambient.a=mtrl.Diffuse.a=2.0f*(TWOHALFPI-dt)/TWOHALFPI;
			else mtrl.Ambient.a=mtrl.Diffuse.a=1.0f;
			pd3dDevice->SetMaterial(&mtrl);

			//int ln = MyStringCpy(s,2*MAX_PATH,pDirs[fMove].ff.cFileName);//pDirs[f].ff.cFileName); edi
			//int ln=WideCharToMultiByte(CP_ACP,0,pDirs[fMove].ff.cFileName,-1,(char*)s,2*MAX_PATH,0,0);
			int ln=WideCharToMultiByte(	CP_ACP,0,
										&pDirs[fMove].ff.cFileName[pathLn],
										-1,(char*)s,2*MAX_PATH,0,0);
			if(ln>0)--ln;
			if(pDirs[f].iFiles>0)
			{	if(pDirs[fMove].sz64>1048575)
				 sprintf((char*)&s[ln],": %.2f mBytes in files: %d",pDirs[fMove].sz64/1048576.0f,pDirs[fMove].iFiles);
				else if(pDirs[fMove].sz64>1023)
				 sprintf((char*)&s[ln],": %d kBytes in files: %d",pDirs[fMove].sz64/1024,pDirs[fMove].iFiles);
				else
				 sprintf((char*)&s[ln],": %d Bytes in files: %d",pDirs[fMove].sz64,pDirs[fMove].iFiles);
			}
			else
			{	if(pDirs[fMove].sz64>1048575)
				 sprintf((char*)&s[ln],": %.2f mB;",pDirs[fMove].sz64/1048576.0f);
				else if(pDirs[fMove].sz64>1023)
				 sprintf((char*)&s[ln],": %d kB;",pDirs[fMove].sz64/1024);
				else
				 sprintf((char*)&s[ln],": %d B;",pDirs[fMove].sz64);
			}
			//OutputDebugString(L"\n");
			//OutputDebugStringA((char*)s);

			//MultiByteToWideChar(CP_ACP,0,s,-1,ws,2*MAX_PATH);
			pFont->Render3DText(s,D3DFONT_TWOSIDED|D3DFONT_FILTERED);
			//OutputDebugString(L" DBG2 ");
		}

		//RECT rc;GetClientRect(hWndPnl,&rc);//rc.bottom = 30;
		static int iPnt=0;
		//int ln=MyStringCpy(s,MAX_PATH,path);
		int ln=WideCharToMultiByte(CP_ACP,0,path,-1,(char*)s,2*MAX_PATH,0,0);
		if(ln>0)--ln;
		if(bProcessContinues)
		{	if(++iPnt>8)iPnt=0;
			for(int i=0; i<iPnt; ++i)s[ln++]='.';
			s[ln]=0;
		}
		else
		{	if('*'==s[ln-1] && '\\'==s[ln-2])s[ln-2]=0;
			else if('\\'==s[ln-1])s[ln-1]=0;
		}

		//OutputDebugString(L"\nDBG3");OutputDebugStringA((char*)s);

		//MultiByteToWideChar(CP_ACP,0,s,-1,ws,2*MAX_PATH);
		pFont->DrawText(0,0,0xc000ff00,s,D3DFONT_TWOSIDED|D3DFONT_FILTERED);
		//StringCchPrintf(s,MAX_PATH,L"Root folders: %d, root files: %d",iRootDirs,iRootFiles);
		if(iRootDirs>0 && iRootFiles)
			sprintf((char*)&s[0],"Root folders: %d, root files: %d",iRootDirs,iRootFiles);
		else if(iRootDirs>0)
			sprintf((char*)&s[0],"Root folders: %d",iRootDirs);
		else
			sprintf((char*)&s[0],"Root files: %d",iRootFiles);

		//OutputDebugString(L"\nDBG4");OutputDebugStringA((char*)s);

		pFont->DrawText(0,25,0xc0ff0000,s,D3DFONT_TWOSIDED|D3DFONT_FILTERED);
		//StringCchPrintf(s,MAX_PATH,L"Total folders: %d, total files: %d",iTotDirs,iTotFiles);
		if(iTotDirs>0 && iTotFiles)
			sprintf((char*)&s[0],"Total folders: %d, total files: %d",iTotDirs,iTotFiles);
		else if(iTotDirs>0)
			sprintf((char*)&s[0],"Total folders: %d",iTotDirs);
		else
			sprintf((char*)&s[0],"Total files: %d",iTotFiles);

		//OutputDebugString(L"\nDBG5");OutputDebugStringA((char*)s);

		pFont->DrawText(0,50,0xc00000ff,s,D3DFONT_TWOSIDED|D3DFONT_FILTERED);
		if(szRootFiles64>1048575)
		 sprintf((char*)&s[0],"%.2f mBytes in root files",szRootFiles64/1048576.0f);
		else if(szRootFiles64>1023)
		 sprintf((char*)&s[0],"%d kBytes in root files",szRootFiles64/1024);
		else
		 sprintf((char*)&s[0],"%d Bytes in root files",szRootFiles64);

		//OutputDebugString(L"\nDBG6");OutputDebugStringA((char*)s);

		pFont->DrawText(0,75,0xc0ffff00,s,D3DFONT_TWOSIDED|D3DFONT_FILTERED);
		if(totsz64>1048575)
		 sprintf((char*)&s[0],"Total size: %.2f mBytes",totsz64/1048576.0f);
		else if(totsz64>1024)
		 sprintf((char*)&s[0],"Total size: %d kBytes",totsz64/1024);
		else
		 sprintf((char*)&s[0],"Total size: %d Bytes",totsz64);

		//OutputDebugString(L"\nDBG7");OutputDebugStringA((char*)s);

		pFont->DrawText(0,100,0xc000ffff,s,D3DFONT_TWOSIDED|D3DFONT_FILTERED);
		pd3dDevice->EndScene();
    }

	//OutputDebugString(L" DBG9 ");

	pd3dDevice->Present(NULL,NULL,NULL,NULL);

	if((!bProcessContinues) && (!bTimerInstalled) )
	{	SetTimer(hWndPnl,DrawDirTimerId,250,drawDirTimerProc);
		bTimerInstalled = TRUE;
	}

	//Draw progress:
	return TRUE;
}

VOID CreateCylinder()
{ 
  if(FAILED(pd3dDevice->CreateVertexBuffer(50*2*sizeof(CUSTOMVERTEX),
                                           0, D3DFVF_CUSTOMVERTEX,
                                           D3DPOOL_DEFAULT, &pVB)))
    return;

  CUSTOMVERTEX* CylVerts;
  if(FAILED(pVB->Lock(0,0,(BYTE**)&CylVerts,0)))
	return;
	
	
  for(DWORD i=0; i<50; i++)
  { FLOAT theta = (2*D3DX_PI*i)/(50-1);
    CylVerts[2*i  ].position = D3DXVECTOR3(0.0f, 0.06f*sinf(theta), 0.06f*cosf(theta));
	CylVerts[2*i  ].normal   = D3DXVECTOR3(0.0f, sinf(theta), cosf(theta));
    //CylVerts[2*i  ].color    = 0xff1010ff;
    CylVerts[2*i  ].tv       = ((FLOAT)i)/(50-1);
    CylVerts[2*i  ].tu       = 1.0f;

    CylVerts[2*i+1].position = D3DXVECTOR3(2.0f, 0.06f*sinf(theta), 0.06f*cosf(theta));
	CylVerts[2*i+1].normal   = D3DXVECTOR3(0.0f, sinf(theta), cosf(theta));
    //CylVerts[2*i+1].color    = 0xffbb10c9;
    CylVerts[2*i+1].tv       = ((FLOAT)i)/(50-1);
    CylVerts[2*i+1].tu       = 0.0f;
  }
  pVB->Unlock();
}

/*BOOL CALLBACK EnumFamCallBack(LPLOGFONT lplf, LPNEWTEXTMETRIC lpntm, DWORD FontType, LPVOID aFontCount) 
{ 
    int far * aiFontCount = (int far *) aFontCount; 
 
    // Record the number of raster, TrueType, and vector 
    // fonts in the font-count array. 
 
    if (FontType & RASTER_FONTTYPE) 
        aiFontCount[0]++; 
    else if (FontType & TRUETYPE_FONTTYPE) 
        aiFontCount[2]++; 
    else 
        aiFontCount[1]++; 
 
    if (aiFontCount[0] || aiFontCount[1] || aiFontCount[2]) 
        return TRUE; 
    else 
        return FALSE; 
 
    UNREFERENCED_PARAMETER( lplf ); 
    UNREFERENCED_PARAMETER( lpntm ); 
}*/

VOID InitDeviceObjects()
{	//int aFontCount[] = { 0, 0, 0 }; 
	//EnumFonts(GetDC(GetDesktopWindow()),(LPCTSTR)NULL,(FONTENUMPROC)EnumFamCallBack,(LPARAM)aFontCount);
	pFont = new CD3DFont((UCHAR*)"Arial", 18, D3DFONT_BOLD);
	pFont->InitDeviceObjects(pd3dDevice);
	CreateCylinder();
}

VOID InvalidateDeviceObjects()
{
	pFont->InvalidateDeviceObjects();
}

VOID RestoreDeviceObjects()
{   pd3dDevice->SetRenderState(D3DRS_CULLMODE, D3DCULL_NONE);
    pd3dDevice->SetRenderState(D3DRS_ZENABLE, TRUE);
	pd3dDevice->SetTextureStageState(0, D3DTSS_COLORARG1, D3DTA_TEXTURE);
    pd3dDevice->SetTextureStageState(0, D3DTSS_COLORARG2, D3DTA_DIFFUSE);
    pd3dDevice->SetTextureStageState(0, D3DTSS_COLOROP,   D3DTOP_MODULATE);
    pd3dDevice->SetTextureStageState(0, D3DTSS_MINFILTER, D3DTEXF_LINEAR);
    pd3dDevice->SetTextureStageState(0, D3DTSS_MAGFILTER, D3DTEXF_LINEAR);
    pd3dDevice->SetRenderState(D3DRS_DITHERENABLE, TRUE);
    pd3dDevice->SetRenderState(D3DRS_SPECULARENABLE, TRUE);
    pd3dDevice->SetRenderState(D3DRS_AMBIENT, 0xFFE0E0E0);

    pd3dDevice->SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE);
    pd3dDevice->SetRenderState(D3DRS_SRCBLEND,   D3DBLEND_SRCALPHA);
    pd3dDevice->SetRenderState(D3DRS_DESTBLEND,  D3DBLEND_INVSRCALPHA);
    pd3dDevice->SetTextureStageState(0, D3DTSS_ALPHAOP,   D3DTOP_MODULATE);
    pd3dDevice->SetTextureStageState(0, D3DTSS_ALPHAARG1, D3DTA_TEXTURE);
    pd3dDevice->SetTextureStageState(0, D3DTSS_ALPHAARG2, D3DTA_DIFFUSE);
    pd3dDevice->SetTextureStageState(1, D3DTSS_COLOROP,   D3DTOP_DISABLE);
    pd3dDevice->SetTextureStageState(1, D3DTSS_ALPHAOP,   D3DTOP_DISABLE);

	pFont->RestoreDeviceObjects();
}

VOID OnLostDevice()
{	//OutputDebugString(L"\nOnLostDevice");
	InvalidateDeviceObjects();
	RestoreDeviceObjects();
}

}//end of namespace "C"