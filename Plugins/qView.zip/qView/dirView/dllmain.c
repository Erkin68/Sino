#pragma warning(disable:4995)

#define _CRT_SECURE_NO_WARNINGS

#include "dirView.h"
//#include "resource.h"
#include "stdio.h"
#include "strsafe.h"
#include "..\..\..\Operations\MyShell\MyShellC.h"



#define MAX_STRINGS 3



wchar_t **strngs=NULL;
HMODULE plgnDllInst;

BOOL APIENTRY DllMain(HMODULE hModule,DWORD ul_reason_for_call,LPVOID lpReserved)
{
//FILE *f;
int i;//,l;
wchar_t *pend;
wchar_t dllname[260];//,mnuStr[64];
	switch(ul_reason_for_call)
	{	case DLL_PROCESS_ATTACH:
			plgnDllInst=hModule;
			path[0]=0;
			InitD3D8();
			if(strngs)break;
			//GetModuleFileNameW(NULL,dllname,260);
			//pend = wcsrchr(dllname,'\\');
			//if(pend)
			//{	*pend=0;
			//	SetCurrentDirectory(dllname);
			//}

			strngs = (wchar_t **)malloc(MAX_STRINGS*sizeof(wchar_t*));
			for(i=0; i<MAX_STRINGS; ++i)strngs[i]=0;
			GetModuleFileNameW(hModule,dllname,260);
			//LoadNTFuncs();

			pend = wcsrchr(dllname,'\\');
			if(pend){*pend++='\\';*pend=0;}

			/*if(GetEnvironmentVariable(L"languge",mnuStr,64))//Language instartup qo'yadur;
			{	if(!wcscmp(mnuStr,L"russian"))
					wcscat(dllname,L"PlugApndStrsRus.txt");
				else if(!wcscmp(mnuStr,L"uzbekl"))
					wcscat(dllname,L"PlugApndStrsUZBL.txt");
				else if(!wcscmp(mnuStr,L"uzbekk"))
					wcscat(dllname,L"PlugApndStrsUZBK.txt");
				else//if(wcscmp(mnuStr,L"Exit")
					wcscat(dllname,L"PlugApndStrsEng.txt");
			}	
			else wcscat(dllname,L"PlugApndStrsEng.txt");

			f=_wfopen(dllname,L"r,ccs=UNICODE");
			if(f)
			{	wchar_t s[260];fwscanf(f,L"%s", s);
				if(wcscmp(s,L"Plugin")) goto NillStr;
				fwscanf(f,L"%s", s);
				if(wcscmp(s,L"fileappend.dll")) goto NillStr;
				fwscanf(f,L"%s", s);
				if(wcscmp(s,L"Strings:")) goto NillStr;
				for(i=0; i<MAX_STRINGS; i++)
				{	int t;fwscanf_s(f,L"%d", &t);
					if(t-1!=i) goto NillStr;
					l=fscanLineString(f,256,s);
					strngs[i]=(wchar_t*)malloc(sizeof(wchar_t)*(l+1));
					memcpy(strngs[i],s,sizeof(wchar_t)*(l+1));
				}
				fclose(f);
			}
			else*/
			{int l;
//NillStr:
				l=wcslen(L"Directory quick view")+1;
					strngs[0]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[0],l,L"Directory quick view");
				l=wcslen(L"Directory quick view plugin for 'Sino'")+1;
					strngs[1]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[1],l,L"Directory quick view plugin for 'Sino'");
			}
			break;
		case DLL_THREAD_ATTACH:
			break;
		case DLL_THREAD_DETACH:
			break;
		case DLL_PROCESS_DETACH:
			if(strngs)
			{	for(i=0; i<MAX_STRINGS; i++)
					{if(strngs[i])free(strngs[i]);}
				free(strngs);
				//saveOptCpp();
				strngs=NULL;
			}
			if(bThreadRun)
			{	bStopThread=TRUE;
				WaitForThrd();
			}
			Cleanup3DDevice8();
			CleanupD3D8();
			FreeFilesList();
			break;
	}
	return TRUE;
}