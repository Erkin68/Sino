#pragma once
#include "webbrowser2.h"


// CPlayerDlg dialog

class CPlayerDlg : public CDialog
{
	DECLARE_DYNAMIC(CPlayerDlg)

public:
	CPlayerDlg(CWnd* pParent = NULL);   // standard constructor
	virtual ~CPlayerDlg();

// Dialog Data
	enum { IDD = IDD_DIALOG_PLAYER };
	CWebBrowser2 m_webBrowser;

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
};
