#include "stdafx.h"
#include "mpView.h"
#include "resource.h"
#include "strsafe.h"
#include "PlayerDlg.h"

extern "C"
{
#pragma comment(lib,"..\\..\\..\\Bin\\MyShell.lib")
#include "..\..\..\Operations\MyShell\MyShell.h"
HWND hWndPnl=0;

BOOL ChangeViewFile(wchar_t *filePthAndName)
{	RECT rcPnl;
	imgFilePathAndNameLn=MyStringCpy(imgFilePathAndName,MAX_PATH,filePthAndName);
	GetClientRect(hWndPnl,&rcPnl);
	return TRUE;
}

LRESULT newPnlWndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{	return DefWindowProc(hWnd,msg,wParam,lParam);
}

BOOL InitViewer(HWND prnt, wchar_t *filePthAndName)
{	RECT rc;GetClientRect(prnt,&rc);
	imgFilePathAndNameLn=MyStringCpy(imgFilePathAndName,MAX_PATH,filePthAndName);


WNDCLASSEX wc;ATOM a;
	wc.cbSize=sizeof(wc);
	wc.hInstance=plgnDllInst;
	wc.hCursor=LoadCursor(NULL,IDC_ARROW);
	wc.hIcon=wc.hIconSm=NULL;
	wc.lpfnWndProc=(WNDPROC)newPnlWndProc;
	wc.lpszClassName=L"qvmp_class";
	wc.lpszMenuName=NULL;
	wc.cbClsExtra=0;
	wc.cbWndExtra=0;
	wc.style=CS_HREDRAW|CS_VREDRAW;  
	wc.hbrBackground=(HBRUSH)GetStockObject(WHITE_BRUSH); 
	a=RegisterClassEx(&wc);
	//if(!a)return FALSE;
	GetWindowRect(prnt,&rc);
	hWndPnl = CreateWindowEx(WS_EX_LEFT|WS_EX_CLIENTEDGE,
							 L"qvmp_class",
							 L"qvmp_window",
							 WS_VISIBLE|WS_CHILDWINDOW,
							 0,
							 0,
							 (int)(rc.right-rc.left),
							 (int)(rc.bottom-rc.top),
							 prnt,
							 0,
							 plgnDllInst,
							 0);
	if(!hWndPnl)return FALSE;

	HDC dc=GetDC(hWndPnl);
	FillRect(dc,&rc,(HBRUSH)(COLOR_WINDOW+1));
	ReleaseDC(hWndPnl,dc);
	CPlayerDlg dlg;
	dlg.DoModal();
	return ChangeViewFile(filePthAndName);
}

VOID CloseViewer()
{	if(hWndPnl)DestroyWindow(hWndPnl);
	hWndPnl=0;
	UnregisterClass(L"qvmp_class",plgnDllInst);
}

__declspec (dllexport) BOOL Draw$8(HWND prnt, wchar_t* filePthAndName)
{	if(!prnt)return FALSE;
	if(!filePthAndName)return FALSE;
	if(0==filePthAndName[0])return FALSE;
	if(IsDirExist(filePthAndName))return FALSE;
	if(hWndPnl)
	{	if(0==wcscmp(imgFilePathAndName,filePthAndName))
			return TRUE;
		else ChangeViewFile(filePthAndName);
	}
	else//if(hWndPnl!=prnt)
		InitViewer(prnt,filePthAndName);
	return TRUE;
}
}