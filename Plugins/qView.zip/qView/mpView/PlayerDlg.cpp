// Player.cpp : implementation file
//

#include "stdafx.h"
#include "mpView.h"
#include "PlayerDlg.h"


// CPlayerDlg dialog

IMPLEMENT_DYNAMIC(CPlayerDlg, CDialog)

CPlayerDlg::CPlayerDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CPlayerDlg::IDD, pParent)
{

}

CPlayerDlg::~CPlayerDlg()
{
}

void CPlayerDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDD_DIALOG_PLAYER, m_webBrowser);
}


BEGIN_MESSAGE_MAP(CPlayerDlg, CDialog)
END_MESSAGE_MAP()


// CPlayerDlg message handlers
