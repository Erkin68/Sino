#include "stdafx.h"
#include "mpView.h"
#include "PlayerDlg.h"
extern "C"
{
#pragma comment(lib,"..\\..\\..\\Bin\\MyShell.lib")
#include "..\..\..\Operations\MyShell\MyShellC.h"
}
#ifdef _DEBUG
#define new DEBUG_NEW
#endif


#define MAX_STRINGS 3

extern "C"
{
wchar_t **strngs=NULL;
HMODULE plgnDllInst;
int language=0;
}


//
//TODO: If this DLL is dynamically linked against the MFC DLLs,
//		any functions exported from this DLL which call into
//		MFC must have the AFX_MANAGE_STATE macro added at the
//		very beginning of the function.
//
//		For example:
//
//		extern "C" BOOL PASCAL EXPORT ExportedFunction()
//		{
//			AFX_MANAGE_STATE(AfxGetStaticModuleState());
//			// normal function body here
//		}
//
//		It is very important that this macro appear in each
//		function, prior to any calls into MFC.  This means that
//		it must appear as the first statement within the 
//		function, even before any object variable declarations
//		as their constructors may generate calls into the MFC
//		DLL.
//
//		Please see MFC Technical Notes 33 and 58 for additional
//		details.
//

// CmpViewApp

BEGIN_MESSAGE_MAP(CmpViewApp, CWinApp)
END_MESSAGE_MAP()


// CmpViewApp construction

CmpViewApp::CmpViewApp()
{
	// TODO: add construction code here,
	// Place all significant initialization in InitInstance
}

CmpViewApp::~CmpViewApp()
{
}


// The one and only CmpViewApp object

CmpViewApp theApp;


// CmpViewApp initialization

BOOL CmpViewApp::InitInstance()
{	//DWORD id=GetCurrentThreadId();

	AfxEnableControlContainer();

#ifdef _AFXDLL
	Enable3dControls();			// Call this when using MFC in a shared DLL
#else
	Enable3dControlsStatic();	// Call this when linking to MFC statically
#endif

	CWinApp::InitInstance();
	plgnDllInst = this->m_hInstance;
	imgFilePathAndName[0]=0;
	if(strngs)return TRUE;

	strngs = (wchar_t **)malloc(MAX_STRINGS*sizeof(wchar_t*));
	for(int i=0; i<MAX_STRINGS; ++i)strngs[i]=0;
	//GetModuleFileNameW(plgnDllInst,dllname,260);
	//LoadNTFuncs();

	//pend = wcsrchr(dllname,'\\');
	//if(pend){*pend++='\\';*pend=0;}
	wchar_t mnuStr[64];
	if(GetEnvironmentVariable(L"languge",mnuStr,64))//Language instartup qo'yadur;
	{	if(!wcscmp(mnuStr,L"russian"))
			language=1;//wcscat(dllname,L"PlugApndStrsRus.txt");
		else if(!wcscmp(mnuStr,L"uzbekl"))
			language=2;//wcscat(dllname,L"PlugApndStrsUZBL.txt");
		else if(!wcscmp(mnuStr,L"uzbekk"))
			language=3;//wcscat(dllname,L"PlugApndStrsUZBK.txt");
		else//if(wcscmp(mnuStr,L"Exit")
			language=0;//wcscat(dllname,L"PlugApndStrsEng.txt");
	}
	/*else wcscat(dllname,L"PlugApndStrsEng.txt");

	f=_wfopen(dllname,L"r,ccs=UNICODE");
	if(f)
	{	wchar_t s[260];fwscanf(f,L"%s", s);
		if(wcscmp(s,L"Plugin")) goto NillStr;
		fwscanf(f,L"%s", s);
		if(wcscmp(s,L"fileappend.dll")) goto NillStr;
		fwscanf(f,L"%s", s);
		if(wcscmp(s,L"Strings:")) goto NillStr;
		for(i=0; i<MAX_STRINGS; i++)
		{	int t;fwscanf_s(f,L"%d", &t);
			if(t-1!=i) goto NillStr;
			l=fscanLineString(f,256,s);
			strngs[i]=(wchar_t*)malloc(sizeof(wchar_t)*(l+1));
			memcpy(strngs[i],s,sizeof(wchar_t)*(l+1));
		}
		fclose(f);
	}
	else*/
	{int l;
//NillStr:
		l=(int)wcslen(L"Binary quick view")+1;
			strngs[0]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[0],l,L"Binary quick view");
		l=(int)wcslen(L"Binary quick view plugin for 'Sino'")+1;
			strngs[1]=(wchar_t*)malloc(2*l);MyStringCpy(strngs[1],l,L"Binary quick view plugin for 'Sino'");
	}

	//CPlayerDlg dlg;
	//dlg.DoModal();

	return TRUE;
}
