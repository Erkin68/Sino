// mpView.h : main header file for the mpView DLL
//

#pragma once

#ifndef __AFXWIN_H__
	#error "include 'stdafx.h' before including this file for PCH"
#endif

#include "resource.h"		// main symbols


// CmpViewApp
// See mpView.cpp for the implementation of this class
//

class CmpViewApp : public CWinApp
{
public:
	CmpViewApp();
   ~CmpViewApp();

// Overrides
public:
	virtual BOOL InitInstance();

	DECLARE_MESSAGE_MAP()
};

extern "C"
{
extern wchar_t imgFilePathAndName[MAX_PATH];
extern int imgFilePathAndNameLn;
extern wchar_t **strngs;
extern HMODULE plgnDllInst;
extern int language;

}