#include "windows.h"
#include "stdio.h"

#define ALIGN_DOWN(x, align)  (x & ~(align-1))//������������ ����
#define ALIGN_UP(x, align)    ((x & (align-1))?ALIGN_DOWN(x,align)+align:x)//������������ �����

LPVOID lpFileBase;
PIMAGE_DOS_HEADER pDosHdr;
PIMAGE_NT_HEADERS pNTHdr;

void PrintExportTable(long);
void PrintExportTable(LPVOID);

int main()
{
HANDLE hFile = CreateFile(L"D:\\Savar\\Auxilary\\Sino\\Bin\\mfc90.dll",
						  GENERIC_READ,FILE_SHARE_READ,NULL,
						  OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,0);
	if(hFile == INVALID_HANDLE_VALUE)
        return 0;
HANDLE hFileMapping = CreateFileMapping(hFile,NULL,PAGE_READONLY,0,0,NULL);
    if(hFileMapping == 0)
    {	CloseHandle(hFile);
        return 0;
    }
	lpFileBase = MapViewOfFile(hFileMapping, FILE_MAP_READ, 0, 0, 0);
    if(lpFileBase == 0)
    {	CloseHandle(hFileMapping);
        CloseHandle(hFile);
        return 0;
    }
	pDosHdr = (PIMAGE_DOS_HEADER)lpFileBase;
    pNTHdr = (PIMAGE_NT_HEADERS)((DWORD)lpFileBase + pDosHdr->e_lfanew);

	PrintExportTable(lpFileBase);

	UnmapViewOfFile(lpFileBase);
    CloseHandle(hFileMapping);
    CloseHandle(hFile);
	hFileMapping=NULL;
	hFile=NULL;
	getchar();
	return 1;
}

DWORD RVAtoOffset(DWORD Base,DWORD RVA)
{	PIMAGE_NT_HEADERS pPE=(PIMAGE_NT_HEADERS)((long)Base+((PIMAGE_DOS_HEADER)Base)->e_lfanew);
	short NumberOfSection=pPE->FileHeader.NumberOfSections;
	long SectionAlign=pPE->OptionalHeader.SectionAlignment;
	PIMAGE_SECTION_HEADER Section=(PIMAGE_SECTION_HEADER)
	   (pPE->FileHeader.SizeOfOptionalHeader+(long)&
	   (pPE->FileHeader)+sizeof(IMAGE_FILE_HEADER));
	long VirtualAddress,PointerToRawData;
	bool flag=false;
	for (int i=0;i<NumberOfSection;i++)
	{	if ((RVA>=(Section->VirtualAddress))&&
		    (RVA<Section->VirtualAddress+
		     ALIGN_UP((Section->Misc.VirtualSize),SectionAlign) ))
		{	VirtualAddress=Section->VirtualAddress;
			PointerToRawData=Section->PointerToRawData;
			flag=true;
			break;
		}
		Section++;
	}
	if (flag) return RVA-VirtualAddress+PointerToRawData;
	else return RVA;
}

void PrintExportTable(LPVOID pBase)
{	short NumberOfSection=pNTHdr->FileHeader.NumberOfSections;
	DWORD ExportRVA=pNTHdr->OptionalHeader.DataDirectory[0].VirtualAddress;

	PIMAGE_EXPORT_DIRECTORY Export=(PIMAGE_EXPORT_DIRECTORY)
	                      RVAtoOffset((long)pBase,ExportRVA);
	Export=(PIMAGE_EXPORT_DIRECTORY)((long)Export+(long)pBase);

	WORD* AddressOfNameOrdinals=(unsigned short *)
	      RVAtoOffset((long)pBase,Export->AddressOfNameOrdinals);
	AddressOfNameOrdinals=(WORD*)((long)AddressOfNameOrdinals+(long)pBase);

	DWORD* AddressOfNames=(unsigned long *)
	       RVAtoOffset((long)pBase,Export->AddressOfNames);
	AddressOfNames=(DWORD*)((long)AddressOfNames+(long)pBase);

	DWORD* AddressOfFunctions=(unsigned long *)
	       RVAtoOffset((long)pBase,Export->AddressOfFunctions);
	AddressOfFunctions=(DWORD*)((long)AddressOfFunctions+(long)pBase);

	WORD index;
	printf("%4s      %-40s       %s\n-------------------------------------",
	       "----------------------------------\n","Ordinal","NameOfFunctions",
		   "EntryPoint");
	int c=0;
	for (unsigned int i=0;i<Export->NumberOfFunctions-1;i++)
	{	index=0xFFFF;
		for (unsigned int j=0;j<Export->NumberOfNames;j++)
		{	if (AddressOfNameOrdinals[j]==(i+Export->Base))
			{	index=j;continue;
		}	}
		if ((AddressOfFunctions[i]>=
		     pNTHdr->OptionalHeader.DataDirectory[0].VirtualAddress)&&
			 (AddressOfFunctions[i]<=
			 pNTHdr->OptionalHeader.DataDirectory[0].VirtualAddress+pNTHdr -> 
			 OptionalHeader.DataDirectory[0].Size))
		{
			if (index!=0xFFFF) printf("%4d         |%-35s       |Forw->%s\n",
			   i+Export->Base,(long)pBase+RVAtoOffset((long)pBase,
			   AddressOfNames[index]),(long)pBase+RVAtoOffset((long)pBase,
			   AddressOfFunctions[i]));
			else printf("%4d         |OrdinalOnly       |Forw->%s\n",
			   i+Export->Base,(long)pBase+RVAtoOffset((long)pBase,
			   AddressOfNames[index]),(long)pBase+RVAtoOffset((long)pBase,
			   AddressOfFunctions[i]));
		}
		if (index!=0xFFFF) printf("%4d         |%-35s       |%X\n",
		    i+Export->Base,(long)pBase+RVAtoOffset((long)pBase,
			AddressOfNames[index]),AddressOfFunctions[i]);
		else printf("%4d         |OrdinalOnly       |%X\n",
		     i+Export->Base,AddressOfFunctions[i]);
		if(0==(++c)%25)
			getchar();
	}
}