#pragma warning (disable:4996)

#include "Config.h"
#include "stdio.h"
//#include "..\..\..\..\Operations\MyShell\MyShellC.h"


//namespace Config
//{

int conf_width=-1;
int conf_height=-1;
int conf_xPos=-1;
int conf_yPos=-1;
int conf_treeWidth=250;

__int8 conf_iCmnFileDlgSel;


BOOL conf_Save()
{
wchar_t *p,s[MAX_PATH];FILE *f;int l=GetModuleFileName(NULL,s,MAX_PATH);
	p=wcsrchr(s,'\\');if(!p)p=&s[l];else++p;
	wcscpy(p,L"PEVw.cnf");
	f=_wfopen(s,L"wb");
	if(!f)//default settings:
	 return FALSE;

	fwrite(&conf_treeWidth,sizeof(int),1,f);
	fwrite(&conf_iCmnFileDlgSel,sizeof(conf_iCmnFileDlgSel),1,f);
	fwrite(&conf_width,sizeof(conf_width),1,f);
	fwrite(&conf_height,sizeof(conf_height),1,f);
	fclose(f);
	return TRUE;
}

BOOL conf_Read()
{
//scrnSX=GetSystemMetrics(SM_CXSCREEN);
//scrnSY=GetSystemMetrics(SM_CYSCREEN);

wchar_t *p,s[MAX_PATH];FILE *f;int l=GetModuleFileName(NULL,s,MAX_PATH);
	p=wcsrchr(s,'\\');if(!p)p=&s[l];else++p;
	wcscpy(p,L"PEVw.cnf");
	f=_wfopen(s,L"rb");
	if(!f)//default settings:
	 return conf_DefaultSettings();

	fread(&conf_treeWidth,sizeof(int),1,f);
	fread(&conf_iCmnFileDlgSel,sizeof(conf_iCmnFileDlgSel),1,f);
	if(conf_iCmnFileDlgSel<0 || conf_iCmnFileDlgSel>2)conf_iCmnFileDlgSel=0;
	fclose(f);
	return TRUE;
}

BOOL conf_DefaultSettings()
{conf_iCmnFileDlgSel=0;
 return TRUE;
}

//}