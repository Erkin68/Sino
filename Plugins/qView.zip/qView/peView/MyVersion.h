#include "windows.h"

extern HWND hWndGetInfoFull;


typedef struct tVar
{ WORD  wLength; 
  WORD  wValueLength; 
  WORD  wType; 
  //WCHAR *szKey;//[]; 
  //WORD  Padding[]; 
  //DWORD *Value;//[]; 
}Var; 

typedef struct tVarFileInfo
{ WORD  wLength; 
  WORD  wValueLength; 
  WORD  wType; 
  //WCHAR *szKey;//[]; 
  //WORD  Padding[]; 
  //Var   *Children;//[]; 
}VarFileInfo; 

/*typedef struct tVS_FIXEDFILEINFO
{ DWORD dwSignature; 
  DWORD dwStrucVersion; 
  DWORD dwFileVersionMS; 
  DWORD dwFileVersionLS; 
  DWORD dwProductVersionMS; 
  DWORD dwProductVersionLS; 
  DWORD dwFileFlagsMask; 
  DWORD dwFileFlags; 
  DWORD dwFileOS; 
  DWORD dwFileType; 
  DWORD dwFileSubtype; 
  DWORD dwFileDateMS; 
  DWORD dwFileDateLS; 
}VS_FIXEDFILEINFO;*/
typedef struct tString
{ WORD   wLength; 
  WORD   wValueLength; 
  WORD   wType; 
  //WCHAR  *szKey;//[]
  //WORD Padding[]; 
  //WCHAR  *Value;//WORD   *Value[]; 
}String; 

typedef struct tStringTable
{ WORD   wLength; 
  WORD   wValueLength; 
  WORD   wType; 
  //WCHAR  *szKey;//[];
  //WORD   Padding[];
  //String *Children;//[]; 
} StringTable;

typedef struct tStringFileInfo
{ WORD        wLength; 
  WORD        wValueLength; 
  WORD        wType; 
  WCHAR       szKey[15];//"StringFileInfo"
  //WORD        Padding[]; 
  //StringTable *Children;//[]; 
}StringFileInfo; 

typedef struct tVS_VERSIONINFO
{ WORD  wLength; 
  WORD  wValueLength; 
  WORD  wType; 
  WCHAR szKey[16];//"VS_VERSION_INFO"
  //WORD  Padding1[]; 
  //VS_FIXEDFILEINFO *Value; 
  //WORD  Padding2[]; 
  //StringFileInfo *Children;//WORD  Children[]; 
}VS_VERSIONINFO; 

extern wchar_t RetCar[3];
extern VOID AddStrToMultilineEdit(HWND,wchar_t*);
extern VOID AddStrToMultilineEdit1(HWND,wchar_t*,wchar_t*);
extern VOID AddStrToMultilineEdit2(HWND,wchar_t*,wchar_t*,wchar_t*);
extern VOID AddStrToMultilineEdit3(HWND,wchar_t*,wchar_t*,wchar_t*,wchar_t*);
extern VOID AddStrToMultilineEditInt(HWND,wchar_t*,int,wchar_t* );
extern VOID AddStrToMultilineEditStr2Int(HWND,wchar_t*,wchar_t*,int,wchar_t*);
extern VOID AddStrToMultilineEditStr2Int1(HWND,wchar_t*,wchar_t*,int);
extern VOID AddStrToMultilineEditHex(HWND,wchar_t*,unsigned int );
extern VOID AddStrToMultilineEditHex2Str(HWND,wchar_t*,unsigned int,wchar_t*,unsigned int);
extern VOID AddStrToMultilineEditHex2Str4x2(HWND,wchar_t*,unsigned int,wchar_t*,unsigned int);
extern VOID AddStrToMultilineEditHex3Str2(HWND,wchar_t*,unsigned int,wchar_t*,unsigned int,wchar_t*,unsigned int);

extern VOID* CorrectPadding(VOID*,VOID*,int);
