#include "windows.h"


//namespace Config
//{
extern int conf_width;
extern int conf_height;
extern int conf_xPos;
extern int conf_yPos;
extern int conf_scrnSX;
extern int conf_scrnSY;
extern int conf_treeWidth;

extern BOOL conf_Read();
extern BOOL conf_Save();
extern BOOL conf_DefaultSettings();


//};
