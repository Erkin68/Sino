#pragma warning(disable: 4995)
#pragma warning(disable: 4996)

extern wchar_t PEFilePathAndName[260];

extern "C"
{
#include "MyVersion.h"
#include "strsafe.h"
#include "commctrl.h"
#include "WinNT.h"
#include "WinNT.h"
#include "MSJPERsrc.h"

int iResOffset = 0,iResSize = 0;

extern LPVOID lpFileBase;
typedef unsigned __int64 QWORD;
extern HWND hWndPnl,
	 hWndTree,
	 hWndFindFirst,
     hWndGetInfoShort,
     hWndGetInfoFull,
     hWndGetInfoBin,
     hWndImgDosHeader,
  	 hWndPESign,
 	 hWndCOOFFFileHeader,
	 hWndOptionalHeader,
	 hWndDataDirectory,
	 hWndSectionTable,
	 hWndExpDir,
	 hWndImpDir,
	 hWndResDir,
	 hWndExceptDir,
	 hWndSecurDir,
	 hWndBaseRelTable,
	 hWndDbgDir,
	 hWndArchSpecData,
	 hWndRVAtoGP,
	 hWndTLSDir,
	 hWndLoadConfDir,
	 hWndBoundImpDir,
	 hWndIAT,
	 hWndDelayLoadImpDesc,
	 hWndCOMRTDesc;

extern VOID AddStrToMultilineEditA(HWND,char*);
extern DWORD RVAToFileOffset(PIMAGE_SECTION_HEADER,DWORD,DWORD);
extern HTREEITEM AddItemToTree(HWND,wchar_t*,int,int,int,int);


BOOL GetImgResDir()
{
 // initial hook up to the resources
 PERsrcTbl rsrcTbl( lpFileBase );
    
 PPERsrcType pFirstResType=0;

 DWORD id=0;
 	
 while(pFirstResType = rsrcTbl.GetNextResourceType(pFirstResType))
 {	id = pFirstResType->Id();

	char s[MAX_PATH];wchar_t ws[MAX_PATH*2]=L"Res.type: ";
	if(pFirstResType->IsNamed())
	{	pFirstResType->Name(s,MAX_PATH);
		MultiByteToWideChar(CP_ACP,0,s,-1,&ws[10],MAX_PATH);
	}
	else
	{	switch(id)
		{	case RT_ACCELERATOR :wcscpy(&ws[10],L"RT_ACCELERATOR" );break;
			case RT_ANICURSOR   :wcscpy(&ws[10],L"RT_ANICURSOR"   );break;
			case RT_ANIICON     :wcscpy(&ws[10],L"RT_ANIICON"	  );break;
			case RT_BITMAP      :wcscpy(&ws[10],L"RT_BITMAP"	  );break;
			case RT_CURSOR      :wcscpy(&ws[10],L"RT_CURSOR"	  );break;
			case RT_DIALOG      :wcscpy(&ws[10],L"RT_DIALOG"	  );break;
			case RT_DLGINCLUDE  :wcscpy(&ws[10],L"RT_DLGINCLUDE"  );break;
			case RT_FONT        :wcscpy(&ws[10],L"RT_FONT"		  );break;
			case RT_FONTDIR     :wcscpy(&ws[10],L"RT_FONTDIR"	  );break;
			case RT_GROUP_CURSOR:wcscpy(&ws[10],L"RT_GROUP_CURSOR");break;
			case RT_GROUP_ICON  :wcscpy(&ws[10],L"RT_GROUP_ICON"  );break;
			case RT_HTML        :wcscpy(&ws[10],L"RT_HTML"		  );break;
			case RT_ICON        :wcscpy(&ws[10],L"RT_ICON"		  );break;
			case RT_MANIFEST    :wcscpy(&ws[10],L"RT_MANIFEST"	  );break;
			case RT_MENU        :wcscpy(&ws[10],L"RT_MENU"		  );break;
			case RT_MESSAGETABLE:wcscpy(&ws[10],L"RT_MESSAGETABLE");break;
			case RT_PLUGPLAY    :wcscpy(&ws[10],L"RT_PLUGPLAY"	  );break;
			case RT_RCDATA      :wcscpy(&ws[10],L"RT_RCDATA"	  );break;
			case RT_STRING      :wcscpy(&ws[10],L"RT_STRING"	  );break;
			case RT_VERSION     :wcscpy(&ws[10],L"RT_VERSION"	  );break;
			case RT_VXD         :wcscpy(&ws[10],L"RT_VXD"		  );break;
			default:StringCchPrintf(&ws[10],MAX_PATH-12,L"Unknown res type: 0x%04x",id);break;
	}	}AddStrToMultilineEdit(hWndResDir,ws);
    AddItemToTree(hWndTree,ws,1,3,3,-1);

    PPERsrcInst pResInst = 0;   // Begin enumeration by passing 0
    while ( pResInst = pFirstResType->GetNextResourceInst( pResInst ) )
    {   PVOID pResData = pResInst->GetData();
        if ( pResInst )
        {   StringCchPrintfA(s,MAX_PATH-12,"Res.offset: %08d (0x%08x) , size: %08d (0x%08x) , ",
							 (int)(((char*)pResData)-((char*)lpFileBase)),
							 (int)(((char*)pResData)-((char*)lpFileBase)),
							 pResInst->Size(),
							 pResInst->Size());
            if ( pResInst->IsNamed() )  // Does the dialog have a name? Get it!
                 pResInst->Name( &s[66], MAX_PATH );
            else StringCchPrintfA(&s[66],MAX_PATH-51,"no str.name, id: %08d (0x%04x)", pResInst->Id(), pResInst->Id() );
    		MultiByteToWideChar(CP_ACP,0,s,-1,ws,MAX_PATH);
			int rowNumInEdit = (int)SendMessage(hWndResDir,EM_GETLINECOUNT,0,0);
			AddStrToMultilineEdit(hWndResDir,ws);
		    AddItemToTree(hWndTree,&ws[66],2,3,3,-99-rowNumInEdit);
 }   }	}
 delete pFirstResType;
 return TRUE;
}

BOOL DrawResItem(int rowNumInEdit)//>>ZOrder
{BOOL ret=FALSE;
 RECT rc;GetWindowRect(hWndFindFirst,&rc);
 POINT pt={rc.left,rc.top};ScreenToClient(hWndPnl,&pt);
 rc.right=rc.right-rc.left;rc.bottom=rc.bottom-rc.top;
 rc.left=pt.x;rc.top=pt.y;
 rc.right+=rc.left;rc.bottom+=rc.top;
 HDC dc=GetDC(hWndPnl);
 FillRect(dc,&rc,(HBRUSH)GetStockObject(WHITE_BRUSH));
	
 wchar_t s[MAX_PATH];TVITEM tvi;ZeroMemory(&tvi,sizeof(tvi));
 HTREEITEM hti = TreeView_GetSelection(hWndTree);
 if(NULL==hti)goto End;
 tvi.hItem = TreeView_GetParent(hWndTree, hti);
 if(NULL==hti)goto End; 
 tvi.mask = TVIF_TEXT;tvi.pszText=&s[0];tvi.cchTextMax=MAX_PATH;
 if(!TreeView_GetItem(hWndTree,&tvi))goto End;
 if(!wcsstr(s,L"Res.type: RT_"))goto End;
 /*int resType;
 if(wcsstr(&s[13],L"GROUP_CURSOR"))resType = 1;//RT_GROUP_CURSOR;
 else if(wcsstr(&s[13],L"GROUP_ICON"))resType=3;//RT_GROUP_ICON;
 else if(wcsstr(&s[13],L"BITMAP"))resType=2;//RT_BITMAP;
 else if(wcsstr(&s[13],L"STRING"))resType=6;//RT_STRING;
 else if(wcsstr(&s[13],L"MENU"))resType=4;//RT_MENU;
 else if(wcsstr(&s[13],L"DIALOG"))resType=5;//RT_DIALOG;
 else goto End;*/

 *((WORD*)&s[0])=(WORD)MAX_PATH;
 int ln=(int)SendMessage(hWndResDir,EM_GETLINE,rowNumInEdit,(LPARAM)s);
 if(0==ln)goto End;
 s[ln]=0;
 iResOffset = _wtoi(&s[12]);
 iResSize = _wtoi(&s[42]);
 //int iResId = _wtoi(&s[ln-17]);
 if(iResSize<1)goto End;

/*HMODULE hm = LoadLibrary(PEFilePathAndName);//,0,LOAD_LIBRARY_AS_DATAFILE);
 if(!hm)goto End;
 PBYTE pb = (PBYTE)(((char*)lpFileBase) + iResOffset);
 HICON hIcon=CreateIconFromResource(pb,iResSize,FALSE,0x00030000);
 if(!hIcon)
 {	int err = GetLastError();
	 goto End;
 }
 switch(resType)
 {case 1://RT_GROUP_CURSOR
   HICON hCursor=(HICON)LoadImage(hm,MAKEINTRESOURCE(iResId),IMAGE_CURSOR,0,0,LR_LOADTRANSPARENT|LR_LOADFROMFILE);
   if(hCursor)
   {DrawIcon(dc,rc.left,rc.top,hCursor);
    DestroyIcon(hCursor);
   }
  break;
 }FreeLibrary(hm);*/
 char* pch=((char*)lpFileBase)+iResOffset;
 char* pchEnd=pch+iResSize;
 //SIZE sz;if(!GetTextExtentPoint32(dc,L"ff",1,&sz)){w=12;h=18;}else {w=3*sz.cx+2;h=2+sz.cy;}
 RECT r;r.left=rc.left;r.top=0;r.right=rc.left+25;r.bottom=25;
 DrawText(dc,L"FF",2,&r,DT_LEFT|DT_CALCRECT);
 int w=4+r.right-r.left;
 int h=1+r.bottom-r.top;
 for(int n=0; n<iResSize; ++n)
 {wchar_t txt[16];StringCchPrintf(txt,16,L"%02X",*pch);
  txt[2]=0;
  DrawText(dc,txt,2,&r,DT_LEFT|DT_INTERNAL);
  if(++pch>pchEnd)break;
  r.left += w;r.right += w;
  if(r.right>rc.right)
  {r.left=rc.left;r.right=r.left+w;
   r.top += h;r.bottom+= h;
   if(r.bottom>rc.bottom)
   {r.top-=h;r.bottom-=h;
    r.left=rc.right-2*w;
	r.right=rc.right;
    DrawText(dc,L"...     ",8,&r,DT_LEFT);
	break;
 }}}

 ret = TRUE;
End:
 ReleaseDC(hWndPnl,dc);
 return ret;
}
}//end of extern "C"
