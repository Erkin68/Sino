#include "windows.h"
#include "strsafe.h"


extern BOOL IsExeInPEHeader64(char*,unsigned long);
extern BOOL IsDLLInPEHeader64(char*,unsigned long);



// Check whether contents in buffer is a valid PE header
BOOL IsDLLInPEHeader(char* buffer, unsigned long size)
{
IMAGE_DOS_HEADER* dos_header;
IMAGE_NT_HEADERS32* header;
char pe_magic[] = "\x50\x45\x00\x00\x4c\x01";
const WORD magic_value = 0x010b;

	// Check whether buffer contains enough bytes to contain a dos header
	if ((long)size < sizeof(IMAGE_DOS_HEADER))
		return FALSE;
	dos_header = (IMAGE_DOS_HEADER*) buffer;
	// Check whether buffer is large enough to contain a PE header
	if ((long)size < dos_header->e_lfanew || (long)size - dos_header->e_lfanew < sizeof(IMAGE_NT_HEADERS32))
		return FALSE;
	header = (IMAGE_NT_HEADERS32*) (buffer + dos_header->e_lfanew);

	// A PE header should start with this sequence (PE00)
	if (memcmp(header, pe_magic, 6*sizeof(char)))
		return FALSE;
	// Check magic value
	if (header->OptionalHeader.Magic != magic_value)
		return FALSE;

	// Win32 VersionValue should be zero
	if (header->OptionalHeader.Win32VersionValue != 0)
		return FALSE;

	// Check whether subsystem is sane one
	if (header->OptionalHeader.Subsystem != IMAGE_SUBSYSTEM_NATIVE &&
		header->OptionalHeader.Subsystem != IMAGE_SUBSYSTEM_UNKNOWN &&
		header->OptionalHeader.Subsystem != IMAGE_SUBSYSTEM_WINDOWS_GUI &&
		header->OptionalHeader.Subsystem != IMAGE_SUBSYSTEM_WINDOWS_CUI)
		return FALSE;

	if(!(IMAGE_FILE_DLL & header->FileHeader.Characteristics))
		return FALSE;
	// Changes are that this is actually a valid PE header
	return TRUE;
}

BOOL IsThisValidDllFile(LPVOID lpFileBase)
{
BOOL bFndDll=FALSE;
PIMAGE_DOS_HEADER dosHeader;
    //printf("Dump of file %s\n\n", filename);
	dosHeader = (PIMAGE_DOS_HEADER)lpFileBase;
    if(dosHeader->e_magic == IMAGE_DOS_SIGNATURE)
	{	bFndDll=IsDLLInPEHeader((char*)dosHeader, sizeof(IMAGE_DOS_HEADER)+2*sizeof(IMAGE_NT_HEADERS32));
	    if(!bFndDll)
			return IsDLLInPEHeader64((char*)dosHeader, sizeof(IMAGE_DOS_HEADER)+2*sizeof(IMAGE_NT_HEADERS64));
	}
	return bFndDll; 
}

BOOL IsExeInPEHeader(char* buffer, unsigned long size)
{
IMAGE_DOS_HEADER* dos_header;
IMAGE_NT_HEADERS32* header;
	char pe_magic[] = "\x50\x45\x00\x00\x4c\x01";
	const WORD magic_value = 0x010b;
	// Check whether buffer contains enough bytes to contain a dos header
	if ((long)size < sizeof(IMAGE_DOS_HEADER))
		return FALSE;
	dos_header = (IMAGE_DOS_HEADER*)buffer;
	// Check whether buffer is large enough to contain a PE header
	// Check whether buffer is large enough to contain a PE header
	if ((long)size < dos_header->e_lfanew || (long)size - dos_header->e_lfanew < sizeof(IMAGE_NT_HEADERS32))
		return FALSE;
	header = (IMAGE_NT_HEADERS32*) (buffer + dos_header->e_lfanew);

	// A PE header should start with this sequence (PE00)
	if (memcmp(header, pe_magic, 6))
		return FALSE;
	// Check magic value
	if (header->OptionalHeader.Magic != magic_value)
		return FALSE;

	// Win32 VersionValue should be zero
	if (header->OptionalHeader.Win32VersionValue != 0)
		return FALSE;

	// Check whether subsystem is sane one
	if (header->OptionalHeader.Subsystem != IMAGE_SUBSYSTEM_NATIVE &&
		header->OptionalHeader.Subsystem != IMAGE_SUBSYSTEM_UNKNOWN &&
		header->OptionalHeader.Subsystem != IMAGE_SUBSYSTEM_WINDOWS_GUI &&
		header->OptionalHeader.Subsystem != IMAGE_SUBSYSTEM_WINDOWS_CUI)
		return FALSE;

	if(!(IMAGE_FILE_EXECUTABLE_IMAGE & header->FileHeader.Characteristics))
		return FALSE;
	// Changes are that this is actually a valid PE header
	return TRUE;
}

BOOL IsThisValidExeFile(LPVOID lpFileBase)
{
BOOL bFndExe=FALSE;
PIMAGE_DOS_HEADER dosHeader;

    //printf("Dump of file %s\n\n", filename);
	dosHeader = (PIMAGE_DOS_HEADER)lpFileBase;
    if ( dosHeader->e_magic == IMAGE_DOS_SIGNATURE )
	{   bFndExe=IsExeInPEHeader((char*)dosHeader, sizeof(IMAGE_DOS_HEADER)+2*sizeof(IMAGE_NT_HEADERS32) );
		if(!bFndExe)
           return IsExeInPEHeader64((char*)dosHeader, sizeof(IMAGE_DOS_HEADER)+2*sizeof(IMAGE_NT_HEADERS64) );
	}
	return bFndExe; 
}