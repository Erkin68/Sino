//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by FileAppend.rc
//
#define IDD_DIALOG_SEARCH               112
#define IDC_EDIT_SEARCH_TEXT			113
#define IDC_EDIT_FIND_ADDRESS			114
#define IDC_EDIT_FIND_LENGTH			115
#define IDC_EDIT_FIND_CMNT				116
#define IDC_STATIC1						21570
#define IDC_STATIC2						21571
#define IDC_STATIC_TEXT                 117
#define IDC_STATIC_BIN                  118
#define IDC_STATICTXT1					119
#define IDC_STATICTXT2					120
#define IDC_CHECK_2						121
#define IDC_CHECK_8						122
#define IDC_CHECK_10					123
#define IDC_CHECK_16					124
#define IDC_CHECK_DOWN					125
#define IDC_CHECK_UP					126
#define IDC_CHECK_FROM_START			127
#define IDC_CHECK_CHAR                  128
#define IDC_PROGRESS1					129
#define IDC_COMBO1                      130
#define IDC_BUTTON_SAVE_CLPBRD_TO_FILE  131
#define IDC_CHECK_UNICODE               132
#define IDC_CHECK_ANSI                  133
#define IDC_CHECK_BIN                   134
#define IDC_EDIT_BIN                    135
#define IDC_EDIT_TEXT                   136
#define IDC_EDIT_CHANGE_DBLE_ZERO       137
#define IDC_EDIT_CHANGE_DBLE_ZERO1      138
#define IDC_CHECK_WIDE_CHAR_FR_EVEN_ADDRS 139
#define IDC_CHECK_WIDE_CHAR_FR_ODD_ADDRS 140





// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        127
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1014
#define _APS_NEXT_SYMED_VALUE           128
#endif
#endif
