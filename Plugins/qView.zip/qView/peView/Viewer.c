#include "peView.h"
#include "resource.h"
#include "..\..\..\Operations\MyShell\MyShellC.h"

BOOL bFileLoaded=FALSE;
u64 iAddressText=0;
HWND hWndPnl=0;

BOOL ChangePEFile(wchar_t *filePthAndName)
{wchar_t *p,tmp[MAX_PATH];int l;
	bFileLoaded = FALSE;
    if(!PEFilePathAndName[0])return FALSE;
	MyStringCpy(PEFilePath,MAX_PATH-1,PEFilePathAndName);
	p = wcsrchr(PEFilePath,'\\');
	if(p)*p=0;
	else
	{	l=GetModuleFileName(NULL,tmp,MAX_PATH);
		p = wcsrchr(tmp,'\\');
		*p = '\\';
		MyStringCpy(p+1,MAX_PATH-l-1,PEFilePath);
		MyStringCpy(PEFilePath,MAX_PATH,tmp);
	}
	if(!IsDirExist(PEFilePath)) return FALSE;
	p = wcsrchr(PEFilePathAndName,'.');
	if(!p)return FALSE;

	if(0==_wcsnicmp(p+1,L"exe",3))
		PEType=exe;
	else if(0==_wcsnicmp(p+1,L"dll",3))
		PEType=dll;

	if(!(p && (!TryLoadPE(PEFilePathAndName))))
		return FALSE;
	/*l=GetWindowText(hWnd,tmp,MAX_PATH);
	p = wcschr(tmp,':');
	if(p) ++p;
	else p= &tmp[l];
	*p++=':';*p++=' ';*p++=' ';*p++=' ';*p++=' ';
	MyStringCpy(p,MAX_PATH-l-1,PEFilePathAndName);
	SetWindowText(hWnd,tmp);*/
	bFileLoaded = TRUE;
	return bFileLoaded;
}

BOOL InitViewer(HWND prnt, wchar_t *filePthAndName)
{WNDCLASSEX wc;RECT rc;ATOM a;
	PEFilePathAndNameLn=MyStringCpy(PEFilePathAndName,MAX_PATH,filePthAndName);
	wc.cbSize=sizeof(wc);
	wc.hInstance=plgnDllInst;
	wc.hCursor=LoadCursor(NULL,IDC_ARROW);
	wc.hIcon=wc.hIconSm=NULL;
	wc.lpfnWndProc=newPnlWndProc;
	wc.lpszClassName=L"qvpe_class";
	wc.lpszMenuName=NULL;
	wc.cbClsExtra=0;
	wc.cbWndExtra=0;
	wc.style=CS_HREDRAW|CS_VREDRAW;  
	wc.hbrBackground=GetStockObject(WHITE_BRUSH); 
	a=RegisterClassEx(&wc);
	//if(!a)return FALSE;
	GetWindowRect(prnt,&rc);
	hWndPnl = CreateWindowEx(WS_EX_LEFT|WS_EX_CLIENTEDGE,
							 L"qvpe_class",
							 L"qvpe_window",
							 WS_VISIBLE|WS_CHILDWINDOW,
							 0,
							 0,
							 (int)(rc.right-rc.left),
							 (int)(rc.bottom-rc.top),
							 prnt,
							 0,
							 plgnDllInst,
							 0);
	if(!hWndPnl)return FALSE;
	CreateControls(hWndPnl);
	return ChangePEFile(filePthAndName);
}

VOID CloseViewer()
{	//DeleteObject(fnt);
	if(hFileMapping)
	{UnmapViewOfFile(lpFileBase);
	 CloseHandle(hFileMapping);
	 CloseHandle(hFile);
	 hFileMapping=NULL;
	}
    if(hWndFindFirst)DestroyWindow(hWndFindFirst);
    if(hWndGetInfoShort)DestroyWindow(hWndGetInfoShort);
    if(hWndGetInfoFull)DestroyWindow(hWndGetInfoFull);
    if(hWndGetInfoBin)DestroyWindow(hWndGetInfoBin);
    if(hWndImgDosHeader)DestroyWindow(hWndImgDosHeader);
	if(hWndPESign)DestroyWindow(hWndPESign);
	if(hWndCOOFFFileHeader)DestroyWindow(hWndCOOFFFileHeader);
	if(hWndOptionalHeader)DestroyWindow(hWndOptionalHeader);
	if(hWndDataDirectory)DestroyWindow(hWndDataDirectory);
	if(hWndSectionTable)DestroyWindow(hWndSectionTable);
	if(hWndExpDir)DestroyWindow(hWndExpDir);
	if(hWndImpDir)DestroyWindow(hWndImpDir);
	if(hWndResDir)DestroyWindow(hWndResDir);
	if(hWndExceptDir)DestroyWindow(hWndExceptDir);
	if(hWndSecurDir)DestroyWindow(hWndSecurDir);
	if(hWndBaseRelTable)DestroyWindow(hWndBaseRelTable);
	if(hWndDbgDir)DestroyWindow(hWndDbgDir);
	if(hWndArchSpecData)DestroyWindow(hWndArchSpecData);
	if(hWndRVAtoGP)DestroyWindow(hWndRVAtoGP);
	if(hWndTLSDir)DestroyWindow(hWndTLSDir);
	if(hWndLoadConfDir)DestroyWindow(hWndLoadConfDir);
	if(hWndBoundImpDir)DestroyWindow(hWndBoundImpDir);
	if(hWndIAT)DestroyWindow(hWndIAT);
	if(hWndDelayLoadImpDesc)DestroyWindow(hWndDelayLoadImpDesc);
	if(hWndCOMRTDesc)DestroyWindow(hWndCOMRTDesc);
	if(hWndResize)DestroyWindow(hWndResize);
	ImageList_Destroy(himl);
	if(hWndPnl)DestroyWindow(hWndPnl);
	hWndPnl=0;
	UnregisterClass(L"qvpe_class",plgnDllInst);
}

__declspec (dllexport) BOOL Draw$8(HWND prnt, wchar_t* filePthAndName)
{	if(!prnt)return FALSE;
	if(!filePthAndName)return FALSE;
	if(0==filePthAndName[0])return FALSE;
	if(hWndPnl)
	{	if(0==wcscmp(PEFilePathAndName,filePthAndName))
			return TRUE;
		else
		{	ClearControls(prnt);
			if(hFileMapping)
			{UnmapViewOfFile(lpFileBase);
			 CloseHandle(hFileMapping);
			 CloseHandle(hFile);
			 hFileMapping=NULL;
		    }
			PEFilePathAndNameLn=MyStringCpy(PEFilePathAndName,MAX_PATH,filePthAndName);
			ChangePEFile(filePthAndName);
	}	}
	else//if(hWndPnl!=prnt)
		InitViewer(prnt,filePthAndName);
	return TRUE;
}

int nRows=0,nColumns=0,nViewRows=25,nViewColumns=33,
	nViewFromChar=0,
	perCentOfAddr=10,perCentOfBin=65,perCentOfText=25;
u64 pageSz,szToEndRow;
SCROLLINFO si;
VOID OnResizeWindow(WORD w,WORD h)
{	
}