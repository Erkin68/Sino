#pragma comment(lib, "Version.lib")

#include "MyVersion.h"
#include "strsafe.h"
#include "WinNT.h"
#include "commctrl.h"
#include "resource.h"
#include "peView.h"

enum
{exeType_Invalid,
 exeType_DOS,
 exeType_NE,
 exeType_VXD,
 exeType_LX,
 exeType_PE
}m_exeType;

extern WIN32_FIND_DATA ff;
extern BOOL GetImgOptionalHeader64(PIMAGE_OPTIONAL_HEADER64);
extern BOOL OutputImportLookupTable64(HWND,char*,PIMAGE_SECTION_HEADER,DWORD,DWORD,DWORD);
extern HTREEITEM AddItemToTree(HWND,wchar_t*,int,int,int,int);


VOID AddStrToMultilineEditNoRetCar(HWND hWndEdt,wchar_t *str)
{	SendMessage(hWndEdt,EM_REPLACESEL, (WPARAM)FALSE, (LPARAM)str);
}
VOID AddStrToMultilineEditA(HWND hWndEdt,char *str)
{	SendMessageA(hWndEdt,EM_REPLACESEL, (WPARAM)FALSE,(LPARAM)str);
	SendMessage(hWndEdt,EM_REPLACESEL, (WPARAM)FALSE, (LPARAM)RetCar);
	SendMessage(hWndEdt,EM_SCROLLCARET,(WPARAM)0, (LPARAM)0);
}

DWORD RVAToFileOffset(PIMAGE_SECTION_HEADER pSectHdr0,DWORD numOfSections,DWORD rva)
{unsigned i;
 for(i=0; i<numOfSections; i++, pSectHdr0++)
 {	DWORD cbMaxOnDisk = min(pSectHdr0->Misc.VirtualSize,pSectHdr0->SizeOfRawData);
	DWORD startSectRVA = pSectHdr0->VirtualAddress;
    DWORD endSectRVA = startSectRVA + cbMaxOnDisk;
    if((rva>=startSectRVA) && (rva<endSectRVA))
	 return pSectHdr0->PointerToRawData + (rva - startSectRVA);
 }
 return (DWORD)-1;// RVA not found in the section table... Ooops!
}

BOOL OutputImportLookupTable32(HWND hWnd,char* lpFileBase,PIMAGE_SECTION_HEADER pimgSectTable,
							   DWORD NumberOfSections,DWORD RVAordnl,DWORD RVAfsrt)
{char s[MAX_PATH];wchar_t ws[MAX_PATH];
 PIMAGE_IMPORT_BY_NAME pImpByName1,pImpByName2;
 DWORD t1,t2;
 DWORD *pRVAToFileOffset1,*pRVAToFileOffset2;
 DWORD RVAToBaseAddr1 = RVAToFileOffset(pimgSectTable,NumberOfSections,RVAordnl),
       RVAToBaseAddr2 = RVAToFileOffset(pimgSectTable,NumberOfSections,RVAfsrt);
 if((DWORD)(-1)==RVAToBaseAddr1 || (DWORD)(-1)==RVAToBaseAddr2)
 {AddStrToMultilineEdit(hWnd,L"      Zero RVA of the ordinal pointer...");
  return FALSE;
 }

 pRVAToFileOffset1 = (DWORD*)(lpFileBase + RVAToBaseAddr1);
 pRVAToFileOffset2 = (DWORD*)(lpFileBase + RVAToBaseAddr2);
 while(*pRVAToFileOffset1)
 {if((*pRVAToFileOffset1)!=(*pRVAToFileOffset2))
  {AddStrToMultilineEdit(hWnd,L"      RVA of the ordinal pointer mismatch to second copy(from first chunk pointer)...");
   return FALSE;
  }
  t1 = RVAToFileOffset(pimgSectTable,NumberOfSections,*pRVAToFileOffset1);
  t2 = RVAToFileOffset(pimgSectTable,NumberOfSections,*pRVAToFileOffset2);

  if((DWORD)-1==t1 && (DWORD)-1==t1)
  {StringCchPrintfA(s,MAX_PATH,"      %04d              ...",
					*((WORD*)pRVAToFileOffset1));
   AddStrToMultilineEditA(hWnd,s);
   StringCchPrintfA(s,MAX_PATH,"                                                                       %04d              ...",
					*((WORD*)pRVAToFileOffset2));
   AddStrToMultilineEditA(hWnd,s);
   s[0x4b]=0;
   MultiByteToWideChar(CP_ACP,0,&s[0x47],-1,ws,MAX_PATH);
   AddItemToTree(hWndTree,ws,3,3,3,-1);
  }
  else
  {pImpByName1 = (PIMAGE_IMPORT_BY_NAME)(lpFileBase + t1);
   pImpByName2 = (PIMAGE_IMPORT_BY_NAME)(lpFileBase + t2);
   StringCchPrintfA(s,MAX_PATH,"      %04d   %s",
					pImpByName1->Hint,pImpByName1->Name);
   AddStrToMultilineEditA(hWnd,s);
   StringCchPrintfA(s,MAX_PATH,"                                                                       %04d   %s",
					pImpByName2->Hint,pImpByName2->Name);
   AddStrToMultilineEditA(hWnd,s);
   MultiByteToWideChar(CP_ACP,0,pImpByName1->Name,-1,ws,MAX_PATH);
   AddItemToTree(hWndTree,ws,3,3,3,-1);
  }
  ++pRVAToFileOffset1;
  ++pRVAToFileOffset2;
 }
 return TRUE;
}

BOOL GetImgDosHeader()
{
wchar_t s[MAX_PATH];
PIMAGE_DOS_HEADER dosHeader;
DWORD m_secondaryHeaderOffset;
WORD *pSecondHdr;

	m_exeType = exeType_Invalid;

	dosHeader = (PIMAGE_DOS_HEADER)lpFileBase;
	if(dosHeader->e_lfarlc < 0x40 )// Theoretically, this field must be >=
     m_exeType = exeType_DOS;      // 0x40 for it to be a non-DOS executable
	m_secondaryHeaderOffset = dosHeader->e_lfanew;
	pSecondHdr = (WORD*)(((char*)lpFileBase) + m_secondaryHeaderOffset);
	switch(*pSecondHdr)
    {case IMAGE_OS2_SIGNATURE: m_exeType = exeType_NE; break;
     case IMAGE_VXD_SIGNATURE: m_exeType = exeType_VXD; break;
     case 0x4558: m_exeType = exeType_LX; break;     // OS/2 2.X
    }
    if(*(PDWORD)pSecondHdr == IMAGE_NT_SIGNATURE)
     m_exeType = exeType_PE;

	AddStrToMultilineEdit(hWndImgDosHeader,L"Exe type:");
	switch(m_exeType)
	{case exeType_Invalid:
		AddStrToMultilineEdit(hWndImgDosHeader,L"                                                            Invalid.");break;
	 case exeType_DOS:
		AddStrToMultilineEdit(hWndImgDosHeader,L"                                                            DOS.");break;
	 case exeType_NE:
		AddStrToMultilineEdit(hWndImgDosHeader,L"                                                            NE.");break;
	 case exeType_VXD:
		AddStrToMultilineEdit(hWndImgDosHeader,L"                                                            VXD.");break;
	 case exeType_LX:
		AddStrToMultilineEdit(hWndImgDosHeader,L"                                                            LX.");break;
	 case exeType_PE:
		AddStrToMultilineEdit(hWndImgDosHeader,L"                                                            PE.");break;
	}

	AddStrToMultilineEdit(hWndImgDosHeader,L"Magic number:");
	StringCchPrintf(s,MAX_PATH,L"                                                            0x%04x",dosHeader->e_magic);
	AddStrToMultilineEdit(hWndImgDosHeader,s);

	AddStrToMultilineEdit(hWndImgDosHeader,L"Bytes on last page of file:");
	StringCchPrintf(s,MAX_PATH,L"                                                            0x%04x",dosHeader->e_cblp);
	AddStrToMultilineEdit(hWndImgDosHeader,s);

	AddStrToMultilineEdit(hWndImgDosHeader,L"Pages in file:");
	StringCchPrintf(s,MAX_PATH,L"                                                            0x%04x",dosHeader->e_cp);
	AddStrToMultilineEdit(hWndImgDosHeader,s);

	AddStrToMultilineEdit(hWndImgDosHeader,L"Relocations:");
	StringCchPrintf(s,MAX_PATH,L"                                                            0x%04x",dosHeader->e_crlc);
	AddStrToMultilineEdit(hWndImgDosHeader,s);

	AddStrToMultilineEdit(hWndImgDosHeader,L"Size of header in paragraphs:");
	StringCchPrintf(s,MAX_PATH,L"                                                            0x%04x",dosHeader->e_cparhdr);
	AddStrToMultilineEdit(hWndImgDosHeader,s);

	AddStrToMultilineEdit(hWndImgDosHeader,L"Minimum extra paragraphs needed:");
	StringCchPrintf(s,MAX_PATH,L"                                                            0x%04x",dosHeader->e_minalloc);
	AddStrToMultilineEdit(hWndImgDosHeader,s);

	AddStrToMultilineEdit(hWndImgDosHeader,L"Maximum extra paragraphs needed:");
	StringCchPrintf(s,MAX_PATH,L"                                                            0x%04x",dosHeader->e_maxalloc);
	AddStrToMultilineEdit(hWndImgDosHeader,s);

	AddStrToMultilineEdit(hWndImgDosHeader,L"Initial (relative) SS value:");
	StringCchPrintf(s,MAX_PATH,L"                                                            0x%04x",dosHeader->e_ss);
	AddStrToMultilineEdit(hWndImgDosHeader,s);

	AddStrToMultilineEdit(hWndImgDosHeader,L"Initial SP value:");
	StringCchPrintf(s,MAX_PATH,L"                                                            0x%04x",dosHeader->e_sp);
	AddStrToMultilineEdit(hWndImgDosHeader,s);

	AddStrToMultilineEdit(hWndImgDosHeader,L"Checksum:");
	StringCchPrintf(s,MAX_PATH,L"                                                            0x%04x",dosHeader->e_csum);
	AddStrToMultilineEdit(hWndImgDosHeader,s);

	AddStrToMultilineEdit(hWndImgDosHeader,L"Initial IP value:");
	StringCchPrintf(s,MAX_PATH,L"                                                            0x%04x",dosHeader->e_ip);
	AddStrToMultilineEdit(hWndImgDosHeader,s);

	AddStrToMultilineEdit(hWndImgDosHeader,L"Initial (relative) CS value:");
	StringCchPrintf(s,MAX_PATH,L"                                                            0x%04x",dosHeader->e_cs);
	AddStrToMultilineEdit(hWndImgDosHeader,s);

	AddStrToMultilineEdit(hWndImgDosHeader,L"File address of relocation table:");
	StringCchPrintf(s,MAX_PATH,L"                                                            0x%04x",dosHeader->e_lfarlc);
	AddStrToMultilineEdit(hWndImgDosHeader,s);

	AddStrToMultilineEdit(hWndImgDosHeader,L"Overlay number:");
	StringCchPrintf(s,MAX_PATH,L"                                                            0x%04x",dosHeader->e_ovno);
	AddStrToMultilineEdit(hWndImgDosHeader,s);

	AddStrToMultilineEdit(hWndImgDosHeader,L"Reserved words:");
	StringCchPrintf(s,MAX_PATH,L"                                                            0x%04x 0x%04x 0x%04x 0x%04x",dosHeader->e_res[0],dosHeader->e_res[1],dosHeader->e_res[2],dosHeader->e_res[3]);
	AddStrToMultilineEdit(hWndImgDosHeader,s);

	AddStrToMultilineEdit(hWndImgDosHeader,L"OEM identifier (for e_oeminfo):");
	StringCchPrintf(s,MAX_PATH,L"                                                            0x%04x",dosHeader->e_oemid);
	AddStrToMultilineEdit(hWndImgDosHeader,s);

	AddStrToMultilineEdit(hWndImgDosHeader,L"OEM information; e_oemid specific:");
	StringCchPrintf(s,MAX_PATH,L"                                                            0x%04x",dosHeader->e_oeminfo);
	AddStrToMultilineEdit(hWndImgDosHeader,s);

	AddStrToMultilineEdit(hWndImgDosHeader,L"Reserved words:");
	StringCchPrintf(s,MAX_PATH,L"                                                            0x%04x 0x%04x 0x%04x 0x%04x 0x%04x 0x%04x 0x%04x 0x%04x 0x%04x 0x%04x",
					dosHeader->e_res2[0],
					dosHeader->e_res2[1],
					dosHeader->e_res2[2],
					dosHeader->e_res2[3],
					dosHeader->e_res2[4],
					dosHeader->e_res2[5],
					dosHeader->e_res2[6],
					dosHeader->e_res2[7],
					dosHeader->e_res2[8],
					dosHeader->e_res2[8]);
	AddStrToMultilineEdit(hWndImgDosHeader,s);

	AddStrToMultilineEdit(hWndImgDosHeader,L"File address of new exe header:");
	StringCchPrintf(s,MAX_PATH,L"                                                            0x%08x",dosHeader->e_lfanew);
	AddStrToMultilineEdit(hWndImgDosHeader,s);

	return TRUE;
} 

BOOL GetImgPESignature()
{
wchar_t s[MAX_PATH];
BYTE *pPESignature;
WORD PESignatureOffs;

//PESignature:
	PESignatureOffs = *((WORD*)(((char*)lpFileBase)+0x3c));
	pPESignature = ((char*)lpFileBase)+PESignatureOffs;
	AddStrToMultilineEdit(hWndPESign,L"PE Signature:");
	StringCchPrintf(s,MAX_PATH,L"                       %c%c %01x%01x",pPESignature[0],pPESignature[1],pPESignature[2],pPESignature[3]);
	AddStrToMultilineEdit(hWndPESign,s);
	return TRUE;
}

BOOL GetImgCOFFFileHeader()
{
wchar_t s[MAX_PATH];
BYTE *pPESignature;
PIMAGE_FILE_HEADER coffFileHeader;
WORD PESignatureOffs;
SYSTEMTIME st;
//int day,month,year,hour,minute,second;

	PESignatureOffs = *((WORD*)(((char*)lpFileBase)+0x3c));
	pPESignature = ((char*)lpFileBase)+PESignatureOffs;

//COFF File header:
	coffFileHeader = (PIMAGE_FILE_HEADER)(((char*)pPESignature)+4);
	AddStrToMultilineEdit(hWndCOOFFFileHeader,L"COFF File header:");
	StringCchPrintf(s,MAX_PATH,L"                              Machine:                         0x%04x",coffFileHeader->Machine);
	AddStrToMultilineEdit(hWndCOOFFFileHeader,s);

	if(IMAGE_FILE_MACHINE_UNKNOWN==coffFileHeader->Machine)
		AddStrToMultilineEdit(hWndCOOFFFileHeader,L"                                  IMAGE_FILE_MACHINE_UNKNOWN : Contents assumed to be applicable to any machine type.");
	else if(IMAGE_FILE_MACHINE_ALPHA==coffFileHeader->Machine)
		AddStrToMultilineEdit(hWndCOOFFFileHeader,L"                                  IMAGE_FILE_MACHINE_ALPHA : Alpha AXP�.");
	else if(IMAGE_FILE_MACHINE_ARM==coffFileHeader->Machine)
		AddStrToMultilineEdit(hWndCOOFFFileHeader,L"                                  IMAGE_FILE_MACHINE_ARM");
	else if(IMAGE_FILE_MACHINE_ALPHA64==coffFileHeader->Machine)
		AddStrToMultilineEdit(hWndCOOFFFileHeader,L"                                  IMAGE_FILE_MACHINE_ALPHA64 : Alpha AXP� 64-bit.");
	else if(IMAGE_FILE_MACHINE_I386==coffFileHeader->Machine)
		AddStrToMultilineEdit(hWndCOOFFFileHeader,L"                                  IMAGE_FILE_MACHINE_I386 : Intel 386 or later, and compatible processors.");
	else if(IMAGE_FILE_MACHINE_IA64==coffFileHeader->Machine)
		AddStrToMultilineEdit(hWndCOOFFFileHeader,L"                                  IMAGE_FILE_MACHINE_IA64 : Intel IA64�.");
	else if(0x268==coffFileHeader->Machine)//IMAGE_FILE_MACHINE_M68K
		AddStrToMultilineEdit(hWndCOOFFFileHeader,L"                                  IMAGE_FILE_MACHINE_M68K : Motorola 68000 series.");
	else if(IMAGE_FILE_MACHINE_MIPS16==coffFileHeader->Machine)
		AddStrToMultilineEdit(hWndCOOFFFileHeader,L"                                  IMAGE_FILE_MACHINE_MIPS16");
	else if(IMAGE_FILE_MACHINE_MIPSFPU==coffFileHeader->Machine)
		AddStrToMultilineEdit(hWndCOOFFFileHeader,L"                                  IMAGE_FILE_MACHINE_MIPSFPU : MIPS with FPU.");
	else if(IMAGE_FILE_MACHINE_MIPSFPU16==coffFileHeader->Machine)
		AddStrToMultilineEdit(hWndCOOFFFileHeader,L"                                  IMAGE_FILE_MACHINE_MIPSFPU16 : MIPS16 with FPU.");
	else if(IMAGE_FILE_MACHINE_POWERPC==coffFileHeader->Machine)
		AddStrToMultilineEdit(hWndCOOFFFileHeader,L"                                  IMAGE_FILE_MACHINE_POWERPC : Power PC, little endian.");
	else if(IMAGE_FILE_MACHINE_R3000==coffFileHeader->Machine)
		AddStrToMultilineEdit(hWndCOOFFFileHeader,L"                                  IMAGE_FILE_MACHINE_R3000");
	else if(IMAGE_FILE_MACHINE_R4000==coffFileHeader->Machine)
		AddStrToMultilineEdit(hWndCOOFFFileHeader,L"                                  IMAGE_FILE_MACHINE_R4000 : MIPS� little endian.");
	else if(IMAGE_FILE_MACHINE_R10000==coffFileHeader->Machine)
		AddStrToMultilineEdit(hWndCOOFFFileHeader,L"                                  IMAGE_FILE_MACHINE_R10000");
	else if(IMAGE_FILE_MACHINE_SH3==coffFileHeader->Machine)
		AddStrToMultilineEdit(hWndCOOFFFileHeader,L"                                  IMAGE_FILE_MACHINE_SH3 : Hitachi SH3.");
	else if(IMAGE_FILE_MACHINE_SH4==coffFileHeader->Machine)
		AddStrToMultilineEdit(hWndCOOFFFileHeader,L"                                  IMAGE_FILE_MACHINE_SH4 : Hitachi SH4.");
	else if(IMAGE_FILE_MACHINE_THUMB==coffFileHeader->Machine)
		AddStrToMultilineEdit(hWndCOOFFFileHeader,L"                                  IMAGE_FILE_MACHINE_THUMB");
	else if(IMAGE_FILE_MACHINE_WCEMIPSV2==coffFileHeader->Machine)
		AddStrToMultilineEdit(hWndCOOFFFileHeader,L"                                  IMAGE_FILE_MACHINE_WCEMIPSV2 : MIPS little-endian WCE v2.");
	else if(IMAGE_FILE_MACHINE_SH3DSP==coffFileHeader->Machine)
		AddStrToMultilineEdit(hWndCOOFFFileHeader,L"                                  IMAGE_FILE_MACHINE_SH3DSP");
	else if(IMAGE_FILE_MACHINE_SH3E==coffFileHeader->Machine)
		AddStrToMultilineEdit(hWndCOOFFFileHeader,L"                                  IMAGE_FILE_MACHINE_SH3E : SH3E little-endian.");
	else if(IMAGE_FILE_MACHINE_SH5==coffFileHeader->Machine)
		AddStrToMultilineEdit(hWndCOOFFFileHeader,L"                                  IMAGE_FILE_MACHINE_SH5 : SH5.");
	else if(IMAGE_FILE_MACHINE_AM33==coffFileHeader->Machine)
		AddStrToMultilineEdit(hWndCOOFFFileHeader,L"                                  IMAGE_FILE_MACHINE_AM33");
	else if(IMAGE_FILE_MACHINE_POWERPCFP==coffFileHeader->Machine)
		AddStrToMultilineEdit(hWndCOOFFFileHeader,L"                                  IMAGE_FILE_MACHINE_POWERPCFP");
	else if(IMAGE_FILE_MACHINE_AXP64==coffFileHeader->Machine)
		AddStrToMultilineEdit(hWndCOOFFFileHeader,L"                                  IMAGE_FILE_MACHINE_AXP64");
	else if(IMAGE_FILE_MACHINE_TRICORE==coffFileHeader->Machine)
		AddStrToMultilineEdit(hWndCOOFFFileHeader,L"                                  IMAGE_FILE_MACHINE_TRICORE : Infineon.");
	else if(IMAGE_FILE_MACHINE_CEF==coffFileHeader->Machine)
		AddStrToMultilineEdit(hWndCOOFFFileHeader,L"                                  IMAGE_FILE_MACHINE_CEF");
	else if(IMAGE_FILE_MACHINE_EBC==coffFileHeader->Machine)
		AddStrToMultilineEdit(hWndCOOFFFileHeader,L"                                  IMAGE_FILE_MACHINE_EBC : EFI Byte Code.");
	else if(IMAGE_FILE_MACHINE_AMD64==coffFileHeader->Machine)
		AddStrToMultilineEdit(hWndCOOFFFileHeader,L"                                  IMAGE_FILE_MACHINE_AMD64 : AMD64 (K8).");
	else if(IMAGE_FILE_MACHINE_M32R==coffFileHeader->Machine)
		AddStrToMultilineEdit(hWndCOOFFFileHeader,L"                                  IMAGE_FILE_MACHINE_M32R :M32R little-endian.");
	else if(IMAGE_FILE_MACHINE_CEE==coffFileHeader->Machine)
		AddStrToMultilineEdit(hWndCOOFFFileHeader,L"                                  IMAGE_FILE_MACHINE_CEE");	
	AddStrToMultilineEdit(hWndCOOFFFileHeader,L"");	

	StringCchPrintf(s,MAX_PATH,L"                              NumberOfSections:        %2d",coffFileHeader->NumberOfSections);
	AddStrToMultilineEdit(hWndCOOFFFileHeader,s);
	StringCchPrintf(s,MAX_PATH,L"                              TimeDateStamp:             0x%04x",coffFileHeader->TimeDateStamp);
	AddStrToMultilineEdit(hWndCOOFFFileHeader,s);
/*	day = (coffFileHeader->TimeDateStamp & 0xfc00) >> 10;
	month = coffFileHeader->TimeDateStamp & 0x0f;
	year = 1954 + (((coffFileHeader->TimeDateStamp & 0x0300) >> 4) | 
		           ((coffFileHeader->TimeDateStamp & 0xf0) >> 4));
	second = 2*((coffFileHeader->TimeDateStamp & 0xf8000000) >> 27);
	minute = (coffFileHeader->TimeDateStamp & 0x78000000) >> 27;
	hour = (coffFileHeader->TimeDateStamp & 0x7f0000) >> 16;
	StringCchPrintf(s,MAX_PATH,L"                                 %02d%s%02d%s%04d   %02d%s%02d%s%02d",
						day,L".",month,L".",year,
						hour,L":",minute,L":",second);
	AddStrToMultilineEdit(hWndCOOFFFileHeader,s);*/

	if(FileTimeToSystemTime(&ff.ftCreationTime,&st))
	{StringCchPrintf(s,MAX_PATH,L"                                  %02d%s%02d%s%04d   %02d%s%02d%s%02d",
						st.wDay,L".",st.wMonth,L".",st.wYear,
						st.wHour,L":",st.wMinute,L":",st.wSecond);
	 AddStrToMultilineEdit(hWndCOOFFFileHeader,s);
     AddStrToMultilineEdit(hWndCOOFFFileHeader,L"");	
    }

	StringCchPrintf(s,MAX_PATH,L"                              PointerToSymbolTable:  0x%08x",coffFileHeader->PointerToSymbolTable);
	AddStrToMultilineEdit(hWndCOOFFFileHeader,s);
	StringCchPrintf(s,MAX_PATH,L"                              NumberOfSymbols:        0x%08x",coffFileHeader->NumberOfSymbols);
	AddStrToMultilineEdit(hWndCOOFFFileHeader,s);
	StringCchPrintf(s,MAX_PATH,L"                              SizeOfOptionalHeader:   0x%04x",coffFileHeader->SizeOfOptionalHeader);
	AddStrToMultilineEdit(hWndCOOFFFileHeader,s);
	StringCchPrintf(s,MAX_PATH,L"                              Characteristics:               0x%04x",coffFileHeader->Characteristics);
	AddStrToMultilineEdit(hWndCOOFFFileHeader,s);

	if(IMAGE_FILE_RELOCS_STRIPPED & coffFileHeader->Characteristics)
		AddStrToMultilineEdit(hWndCOOFFFileHeader,L"                                  IMAGE_FILE_RELOCS_STRIPPED : Image only, Windows CE, Windows NT and above. Indicates that the file does not contain base relocations and must therefore be loaded at its preferred base address. If the base address is not available, the loader reports an error. Operating systems running on top of MS-DOS (Win32s�) are generally not able to use the preferred base address and so cannot run these images. However, beginning with version 4.0, Windows will use an application's preferred base address. The default behavior of the linker is to strip base relocations from EXEs.");
	if(IMAGE_FILE_EXECUTABLE_IMAGE & coffFileHeader->Characteristics)
		AddStrToMultilineEdit(hWndCOOFFFileHeader,L"                                  IMAGE_FILE_EXECUTABLE_IMAGE : Image only. Indicates that the image file is valid and can be run. If this flag is not set, it generally indicates a linker error.");
	if(IMAGE_FILE_LINE_NUMS_STRIPPED & coffFileHeader->Characteristics)
		AddStrToMultilineEdit(hWndCOOFFFileHeader,L"                                  IMAGE_FILE_LINE_NUMS_STRIPPED : COFF line numbers have been removed.");
	if(IMAGE_FILE_LOCAL_SYMS_STRIPPED & coffFileHeader->Characteristics)
		AddStrToMultilineEdit(hWndCOOFFFileHeader,L"                                  IMAGE_FILE_LOCAL_SYMS_STRIPPED : COFF symbol table entries for local symbols have been removed.");
	if(/*IMAGE_FILE_AGGRESSIVE_WS_TRIM*/0x0010 & coffFileHeader->Characteristics)
		AddStrToMultilineEdit(hWndCOOFFFileHeader,L"                                  IMAGE_FILE_AGGRESSIVE_WS_TRIM : Aggressively trim working set.");
	if(IMAGE_FILE_LARGE_ADDRESS_AWARE & coffFileHeader->Characteristics)
		AddStrToMultilineEdit(hWndCOOFFFileHeader,L"                                  IMAGE_FILE_LARGE_ADDRESS_AWARE : App can handle > 2gb addresses.");
	if(/*IMAGE_FILE_16BIT_MACHINE*/0x0040 & coffFileHeader->Characteristics)
		AddStrToMultilineEdit(hWndCOOFFFileHeader,L"                                  IMAGE_FILE_16BIT_MACHINE : Use of this flag is reserved for future use.");
	if(IMAGE_FILE_BYTES_REVERSED_LO & coffFileHeader->Characteristics)
		AddStrToMultilineEdit(hWndCOOFFFileHeader,L"                                  IMAGE_FILE_BYTES_REVERSED_LO : Little endian: LSB precedes MSB in memory.");
	if(IMAGE_FILE_32BIT_MACHINE & coffFileHeader->Characteristics)
		AddStrToMultilineEdit(hWndCOOFFFileHeader,L"                                  IMAGE_FILE_32BIT_MACHINE : Machine based on 32-bit-word architecture.");
	if(IMAGE_FILE_DEBUG_STRIPPED & coffFileHeader->Characteristics)
		AddStrToMultilineEdit(hWndCOOFFFileHeader,L"                                  IMAGE_FILE_DEBUG_STRIPPED : Debugging information removed from image file.");
	if(IMAGE_FILE_REMOVABLE_RUN_FROM_SWAP & coffFileHeader->Characteristics)
		AddStrToMultilineEdit(hWndCOOFFFileHeader,L"                                  IMAGE_FILE_REMOVABLE_RUN_FROM_SWAP : If image is on removable media, copy and run from swap file.");
	if(IMAGE_FILE_SYSTEM & coffFileHeader->Characteristics)
		AddStrToMultilineEdit(hWndCOOFFFileHeader,L"                                  IMAGE_FILE_SYSTEM : The image file is a system file, not a user program.");
	if(IMAGE_FILE_DLL & coffFileHeader->Characteristics)
		AddStrToMultilineEdit(hWndCOOFFFileHeader,L"                                  IMAGE_FILE_DLL : The image file is a dynamic-link library (DLL). Such files are considered executable files for almost all purposes, although they cannot be directly run.");
	if(IMAGE_FILE_UP_SYSTEM_ONLY & coffFileHeader->Characteristics)
		AddStrToMultilineEdit(hWndCOOFFFileHeader,L"                                  IMAGE_FILE_UP_SYSTEM_ONLY : File should be run only on a UP machine.");
	if(IMAGE_FILE_BYTES_REVERSED_HI & coffFileHeader->Characteristics)
		AddStrToMultilineEdit(hWndCOOFFFileHeader,L"                                  IMAGE_FILE_BYTES_REVERSED_HI : Bytes of machine word are reversed.");
	if(IMAGE_FILE_AGGRESIVE_WS_TRIM & coffFileHeader->Characteristics)
		AddStrToMultilineEdit(hWndCOOFFFileHeader,L"                                  IMAGE_FILE_AGGRESIVE_WS_TRIM : Agressively trim working set.");
	if(IMAGE_FILE_NET_RUN_FROM_SWAP & coffFileHeader->Characteristics)
		AddStrToMultilineEdit(hWndCOOFFFileHeader,L"                                  IMAGE_FILE_NET_RUN_FROM_SWAP : If Image is on Net, copy and run from the swap file.");
	return TRUE;
}

BOOL GetImgOptionalHeader()
{
wchar_t s[MAX_PATH];
BYTE *pPESignature;
PIMAGE_FILE_HEADER coffFileHeader;
WORD PESignatureOffs;
PIMAGE_OPTIONAL_HEADER32 pOptlHdr;
PIMAGE_OPTIONAL_HEADER64 pOptlHdr64 = NULL;

	PESignatureOffs = *((WORD*)(((char*)lpFileBase)+0x3c));
	pPESignature = ((char*)lpFileBase)+PESignatureOffs;
	coffFileHeader = (PIMAGE_FILE_HEADER)(((char*)pPESignature)+4);
	pOptlHdr = (PIMAGE_OPTIONAL_HEADER32)(((char*)coffFileHeader) + sizeof(IMAGE_FILE_HEADER));
	
	if(0==coffFileHeader->SizeOfOptionalHeader)
	{	AddStrToMultilineEdit(hWndOptionalHeader,L"coffFileHeader -> SizeOfOptionalHeader is zero.");
		return FALSE;
	}
	if(0x20b==pOptlHdr->Magic)
	{	StringCchPrintf(s,MAX_PATH,L"Magic (PE32+):                     0x%04x, identifies a ROM.",pOptlHdr->Magic);
	    return GetImgOptionalHeader64((PIMAGE_OPTIONAL_HEADER64)pOptlHdr);
	}
	else if(0x10B==pOptlHdr->Magic)
		StringCchPrintf(s,MAX_PATH,L"Magic (PE32):                      0x%04x, normal executable file.",pOptlHdr->Magic);
	else if(0x107==pOptlHdr->Magic)
		StringCchPrintf(s,MAX_PATH,L"Magic :                                 0x%04x, identifies a ROM.",pOptlHdr->Magic);
	else StringCchPrintf(s,MAX_PATH,L"Magic :                                 0x%04x",pOptlHdr->Magic);
	AddStrToMultilineEdit(hWndOptionalHeader,s);

	StringCchPrintf(s,MAX_PATH,L"MajorLinkerVersion :           0x%02x",pOptlHdr->MajorLinkerVersion);
	AddStrToMultilineEdit(hWndOptionalHeader,s);
	
	StringCchPrintf(s,MAX_PATH,L"MinorLinkerVersion :           0x%02x",pOptlHdr->MinorLinkerVersion);
	AddStrToMultilineEdit(hWndOptionalHeader,s);

	StringCchPrintf(s,MAX_PATH,L"SizeOfCode :                        0x%08x. Size of the code (text) section, or the sum of all code sections if there are multiple sections.",pOptlHdr->SizeOfCode);
	AddStrToMultilineEdit(hWndOptionalHeader,s);

	StringCchPrintf(s,MAX_PATH,L"SizeOfInitializedData :         0x%08x. Size of the initialized data section, or the sum of all such sections if there are multiple data sections.",pOptlHdr->SizeOfInitializedData);
	AddStrToMultilineEdit(hWndOptionalHeader,s);

	StringCchPrintf(s,MAX_PATH,L"SizeOfUninitializedData :     0x%08x. Size of the uninitialized data section (BSS), or the sum of all such sections if there are multiple BSS sections.",pOptlHdr->SizeOfUninitializedData);
	AddStrToMultilineEdit(hWndOptionalHeader,s);

	StringCchPrintf(s,MAX_PATH,L"AddressOfEntryPoint :          0x%08x. Address of entry point, relative to image base, when executable file is loaded into memory. For program images, this is the starting address.",pOptlHdr->AddressOfEntryPoint);
	AddStrToMultilineEdit(hWndOptionalHeader,s);

	StringCchPrintf(s,MAX_PATH,L"BaseOfCode :                       0x%08x. Address, relative to image base, of beginning of code section, when loaded into memory.",pOptlHdr->BaseOfCode);
	AddStrToMultilineEdit(hWndOptionalHeader,s);

	StringCchPrintf(s,MAX_PATH,L"BaseOfData :                        0x%08x.",pOptlHdr->BaseOfData);
	AddStrToMultilineEdit(hWndOptionalHeader,s);

	StringCchPrintf(s,MAX_PATH,L"ImageBase :                         0x%08x.",pOptlHdr->ImageBase);
	AddStrToMultilineEdit(hWndOptionalHeader,s);
	
	StringCchPrintf(s,MAX_PATH,L"SectionAlignment :                0x%08x.",pOptlHdr->SectionAlignment);
	AddStrToMultilineEdit(hWndOptionalHeader,s);

	StringCchPrintf(s,MAX_PATH,L"FileAlignment :                      0x%08x.",pOptlHdr->FileAlignment);
	AddStrToMultilineEdit(hWndOptionalHeader,s);

	StringCchPrintf(s,MAX_PATH,L"MajorOperatingSystemVersion : 0x%04x.",pOptlHdr->MajorOperatingSystemVersion);
	AddStrToMultilineEdit(hWndOptionalHeader,s);

	StringCchPrintf(s,MAX_PATH,L"MinorOperatingSystemVersion : 0x%04x.",pOptlHdr->MinorOperatingSystemVersion);
	AddStrToMultilineEdit(hWndOptionalHeader,s);

	StringCchPrintf(s,MAX_PATH,L"MajorImageVersion :             0x%04x.",pOptlHdr->MajorImageVersion);
	AddStrToMultilineEdit(hWndOptionalHeader,s);

	StringCchPrintf(s,MAX_PATH,L"MinorImageVersion :             0x%04x.",pOptlHdr->MinorImageVersion);
	AddStrToMultilineEdit(hWndOptionalHeader,s);

	StringCchPrintf(s,MAX_PATH,L"MajorSubsystemVersion :     0x%04x.",pOptlHdr->MajorSubsystemVersion);
	AddStrToMultilineEdit(hWndOptionalHeader,s);

	StringCchPrintf(s,MAX_PATH,L"MinorSubsystemVersion :     0x%04x.",pOptlHdr->MinorSubsystemVersion);
	AddStrToMultilineEdit(hWndOptionalHeader,s);

	StringCchPrintf(s,MAX_PATH,L"Win32VersionValue :             0x%08x.",pOptlHdr->Win32VersionValue);
	AddStrToMultilineEdit(hWndOptionalHeader,s);

	StringCchPrintf(s,MAX_PATH,L"SizeOfImage :                        0x%08x.",pOptlHdr->SizeOfImage);
	AddStrToMultilineEdit(hWndOptionalHeader,s);

	StringCchPrintf(s,MAX_PATH,L"SizeOfHeaders :                     0x%08x.",pOptlHdr->SizeOfHeaders);
	AddStrToMultilineEdit(hWndOptionalHeader,s);

	StringCchPrintf(s,MAX_PATH,L"CheckSum :                            0x%08x.",pOptlHdr->CheckSum);
	AddStrToMultilineEdit(hWndOptionalHeader,s);

	StringCchPrintf(s,MAX_PATH,L"Subsystem :                           0x%04x.",pOptlHdr->Subsystem);
	AddStrToMultilineEdit(hWndOptionalHeader,s);

//Subsystem P32 da ham, P32+ da ham bir xil:
	switch(pOptlHdr->Subsystem)
	{case IMAGE_SUBSYSTEM_UNKNOWN:
	  AddStrToMultilineEdit(hWndOptionalHeader,L"                                IMAGE_SUBSYSTEM_UNKNOWN");
	 break;
	 case IMAGE_SUBSYSTEM_NATIVE:
		 AddStrToMultilineEdit(hWndOptionalHeader,L"                                IMAGE_SUBSYSTEM_NATIVE : Used for device drivers and native Windows NT processes.");
	 break;
	 case IMAGE_SUBSYSTEM_WINDOWS_GUI:
		 AddStrToMultilineEdit(hWndOptionalHeader,L"                                IMAGE_SUBSYSTEM_WINDOWS_GUI : Image runs in the Windows� graphical user interface (GUI) subsystem.");
	 break;
	 case IMAGE_SUBSYSTEM_WINDOWS_CUI:
		 AddStrToMultilineEdit(hWndOptionalHeader,L"                                IMAGE_SUBSYSTEM_WINDOWS_CUI : Image runs in the Windows character subsystem.");
	 break;
	 case IMAGE_SUBSYSTEM_OS2_CUI: 
		 AddStrToMultilineEdit(hWndOptionalHeader,L"                                IMAGE_SUBSYSTEM_OS2_CUI : Image runs in the OS/2 character subsystem.");
	 break;
	 case IMAGE_SUBSYSTEM_POSIX_CUI: 
		 AddStrToMultilineEdit(hWndOptionalHeader,L"                                IMAGE_SUBSYSTEM_POSIX_CUI : Image runs in the Posix character subsystem.");
	 break;
	 case IMAGE_SUBSYSTEM_NATIVE_WINDOWS:
		 AddStrToMultilineEdit(hWndOptionalHeader,L"                                IMAGE_SUBSYSTEM_NATIVE_WINDOWS : Image is a native Win9x driver.");
	 break;
	 case IMAGE_SUBSYSTEM_WINDOWS_CE_GUI:
		 AddStrToMultilineEdit(hWndOptionalHeader,L"                                IMAGE_SUBSYSTEM_WINDOWS_CE_GUI : Image runs in on Windows CE.");
	 break;
	 case IMAGE_SUBSYSTEM_EFI_APPLICATION:
		 AddStrToMultilineEdit(hWndOptionalHeader,L"                                IMAGE_SUBSYSTEM_EFI_APPLICATION : Image is an EFI application.");
	 break;
	 case IMAGE_SUBSYSTEM_EFI_BOOT_SERVICE_DRIVER:
		 AddStrToMultilineEdit(hWndOptionalHeader,L"                                IMAGE_SUBSYSTEM_EFI_BOOT_SERVICE_DRIVER : Image is an EFI driver that provides boot services.");
	 break;
	 case IMAGE_SUBSYSTEM_EFI_RUNTIME_DRIVER:
		 AddStrToMultilineEdit(hWndOptionalHeader,L"                                IMAGE_SUBSYSTEM_EFI_RUNTIME_DRIVER : Image is an EFI driver that provides runtime services.");
	 break;
	 case IMAGE_SUBSYSTEM_EFI_ROM:
		 AddStrToMultilineEdit(hWndOptionalHeader,L"                                IMAGE_SUBSYSTEM_EFI_ROM");
	 break;
	 case IMAGE_SUBSYSTEM_XBOX:
		 AddStrToMultilineEdit(hWndOptionalHeader,L"                                IMAGE_SUBSYSTEM_XBOX");
	 break;
	}

	StringCchPrintf(s,MAX_PATH,L"DLL Characteristics :              0x%04x.",pOptlHdr->DllCharacteristics);
	AddStrToMultilineEdit(hWndOptionalHeader,s);

	if(pOptlHdr->DllCharacteristics & 0x0001)
	  AddStrToMultilineEdit(hWndOptionalHeader,L"                                IMAGE_LIBRARY_PROCESS_INIT : Reserved");
	if(pOptlHdr->DllCharacteristics & 0x0002)
	  AddStrToMultilineEdit(hWndOptionalHeader,L"                                IMAGE_LIBRARY_PROCESS_TERM : Reserved");
	if(pOptlHdr->DllCharacteristics & 0x0004)
	  AddStrToMultilineEdit(hWndOptionalHeader,L"                                IMAGE_LIBRARY_THREAD_INIT : Reserved");
	if(pOptlHdr->DllCharacteristics & 0x0008)
	  AddStrToMultilineEdit(hWndOptionalHeader,L"                                IMAGE_LIBRARY_THREAD_TERM : Reserved");
	if(pOptlHdr->DllCharacteristics & IMAGE_DLLCHARACTERISTICS_NO_ISOLATION)
	  AddStrToMultilineEdit(hWndOptionalHeader,L"                                IMAGE_DLLCHARACTERISTICS_NO_ISOLATION : Image understands isolation and doesn't want it.");
	if(pOptlHdr->DllCharacteristics & IMAGE_DLLCHARACTERISTICS_NO_SEH)
	  AddStrToMultilineEdit(hWndOptionalHeader,L"                                IMAGE_DLLCHARACTERISTICS_NO_SEH : Image does not use SEH.  No SE handler may reside in this image.");
	if(pOptlHdr->DllCharacteristics & IMAGE_DLLCHARACTERISTICS_NO_BIND)
	 AddStrToMultilineEdit(hWndOptionalHeader,L"                                IMAGE_DLLCHARACTERISTICS_NO_BIND : Do not bind image.");
	if(pOptlHdr->DllCharacteristics & IMAGE_DLLCHARACTERISTICS_WDM_DRIVER)
	 AddStrToMultilineEdit(hWndOptionalHeader,L"                                IMAGE_DLLCHARACTERISTICS_WDM_DRIVER : Driver is a WDM Driver.");
	if(pOptlHdr->DllCharacteristics & IMAGE_DLLCHARACTERISTICS_TERMINAL_SERVER_AWARE)
	 AddStrToMultilineEdit(hWndOptionalHeader,L"                                IMAGE_DLLCHARACTERISTICS_TERMINAL_SERVER_AWARE : Image is Terminal Server aware.");

	StringCchPrintf(s,MAX_PATH,L"SizeOfStackReserve :             0x%08x.",pOptlHdr->SizeOfStackReserve);
	AddStrToMultilineEdit(hWndOptionalHeader,s);

	StringCchPrintf(s,MAX_PATH,L"SizeOfStackCommit :              0x%08x.",pOptlHdr->SizeOfStackCommit);
	AddStrToMultilineEdit(hWndOptionalHeader,s);

	StringCchPrintf(s,MAX_PATH,L"SizeOfHeapReserve :             0x%08x.",pOptlHdr->SizeOfHeapReserve);
	AddStrToMultilineEdit(hWndOptionalHeader,s);

	StringCchPrintf(s,MAX_PATH,L"SizeOfHeapCommit :               0x%08x.",pOptlHdr->SizeOfHeapCommit);
	AddStrToMultilineEdit(hWndOptionalHeader,s);

	StringCchPrintf(s,MAX_PATH,L"SizeOfHeapReserve :              0x%08x.",pOptlHdr->SizeOfHeapReserve);
	AddStrToMultilineEdit(hWndOptionalHeader,s);

	StringCchPrintf(s,MAX_PATH,L"SizeOfHeapCommit :               0x%08x.",pOptlHdr->SizeOfHeapCommit);
	AddStrToMultilineEdit(hWndOptionalHeader,s);

	StringCchPrintf(s,MAX_PATH,L"LoaderFlags :                          0x%08x.",pOptlHdr->LoaderFlags);
	AddStrToMultilineEdit(hWndOptionalHeader,s);
	switch(pOptlHdr->LoaderFlags)
	{case 1:
	  AddStrToMultilineEdit(hWndOptionalHeader,L"                      1.Invoke a breakpoint instruction before starting the process.");
	 break;
	 case 2:
	  AddStrToMultilineEdit(hWndOptionalHeader,L"                      2.Invoke a debugger on the process after it's been loaded.");
	 break;
	}

	StringCchPrintf(s,MAX_PATH,L"NumberOfRvaAndSizes :        0x%08x.",pOptlHdr->NumberOfRvaAndSizes);
	AddStrToMultilineEdit(hWndOptionalHeader,s);
	return TRUE;
}

BOOL GetImgDataDirectory(BOOL *b64)
{
wchar_t s[MAX_PATH];
DWORD i,numDirectory;
BYTE *pPESignature;
PIMAGE_FILE_HEADER coffFileHeader;
WORD PESignatureOffs;
PIMAGE_OPTIONAL_HEADER32 pOptlHdr;
PIMAGE_OPTIONAL_HEADER64 pOptlHdr64=0;
PIMAGE_DATA_DIRECTORY pImgDir;

	PESignatureOffs = *((WORD*)(((char*)lpFileBase)+0x3c));
	pPESignature = ((char*)lpFileBase)+PESignatureOffs;
	coffFileHeader = (PIMAGE_FILE_HEADER)(((char*)pPESignature)+4);
	pOptlHdr = (PIMAGE_OPTIONAL_HEADER32)(((char*)coffFileHeader) + sizeof(IMAGE_FILE_HEADER));
	if(0x20b==pOptlHdr->Magic)
	{pOptlHdr64 = (PIMAGE_OPTIONAL_HEADER64)pOptlHdr;
	 pImgDir = &pOptlHdr64->DataDirectory[0];
	 numDirectory = pOptlHdr64->NumberOfRvaAndSizes;
	 *b64=TRUE;
	}
	else
	{pImgDir = &pOptlHdr->DataDirectory[0];
	 numDirectory = pOptlHdr->NumberOfRvaAndSizes;
	 *b64=FALSE;
	}

	StringCchPrintf(s,MAX_PATH,L"Data directory, %d entries (virtual address and size):",numDirectory);
	AddStrToMultilineEdit(hWndDataDirectory,s);
	AddStrToMultilineEdit(hWndDataDirectory,L"");

	for(i=0; i<numDirectory; ++i)
	{switch(i)
	 {case 0:StringCchPrintf(s,MAX_PATH,L"         1. Export Directory:                                0x%08x      0x%08x",pImgDir->VirtualAddress,pImgDir->Size);break;
	  case 1:StringCchPrintf(s,MAX_PATH,L"         2. Import Directory:                                0x%08x      0x%08x",pImgDir->VirtualAddress,pImgDir->Size);break;
	  case 2:StringCchPrintf(s,MAX_PATH,L"         3. Resource Directory:                           0x%08x      0x%08x",pImgDir->VirtualAddress,pImgDir->Size);break;
	  case 3:StringCchPrintf(s,MAX_PATH,L"         4. Exception Directory:                          0x%08x      0x%08x",pImgDir->VirtualAddress,pImgDir->Size);break;
	  case 4:StringCchPrintf(s,MAX_PATH,L"         5. Security Directory:                             0x%08x      0x%08x",pImgDir->VirtualAddress,pImgDir->Size);break;
	  case 5:StringCchPrintf(s,MAX_PATH,L"         6. Base Relocation Table:                     0x%08x      0x%08x",pImgDir->VirtualAddress,pImgDir->Size);break;
	  case 6:StringCchPrintf(s,MAX_PATH,L"         7. Debug Directory:                                0x%08x      0x%08x",pImgDir->VirtualAddress,pImgDir->Size);break;
	  case 7:StringCchPrintf(s,MAX_PATH,L"         8. Architecture Specific Data:                 0x%08x      0x%08x",pImgDir->VirtualAddress,pImgDir->Size);break;
	  case 8:StringCchPrintf(s,MAX_PATH,L"         9. RVA of GP:                                          0x%08x      0x%08x",pImgDir->VirtualAddress,pImgDir->Size);break;
	  case 9:StringCchPrintf(s,MAX_PATH,L"         10.TLS Directory:                                   0x%08x      0x%08x",pImgDir->VirtualAddress,pImgDir->Size);break;
	  case 10:StringCchPrintf(s,MAX_PATH,L"         11.Load Configuration Directory:           0x%08x      0x%08x",pImgDir->VirtualAddress,pImgDir->Size);break;
	  case 11:StringCchPrintf(s,MAX_PATH,L"         12.Bound Import Directory in headers:  0x%08x     0x%08x",pImgDir->VirtualAddress,pImgDir->Size);break;
	  case 12:StringCchPrintf(s,MAX_PATH,L"         13.Import Address Table:                       0x%08x      0x%08x",pImgDir->VirtualAddress,pImgDir->Size);break;
	  case 13:StringCchPrintf(s,MAX_PATH,L"         14.Delay Load Import Descriptors:        0x%08x      0x%08x",pImgDir->VirtualAddress,pImgDir->Size);break;
	  case 14:StringCchPrintf(s,MAX_PATH,L"         15.COM Runtime descriptor:                  0x%08x      0x%08x",pImgDir->VirtualAddress,pImgDir->Size);break;
	  default:StringCchPrintf(s,MAX_PATH,L"         %d.                                                          0x%08x      0x%08x",i+1,pImgDir->VirtualAddress,pImgDir->Size);break;
	 }
	 AddStrToMultilineEdit(hWndDataDirectory,s);
	 ++pImgDir;
	}
	return TRUE;
}

BOOL GetImgSectionTable()
{
wchar_t s[MAX_PATH];
DWORD i,numDirectory,numSection;
BYTE *pPESignature;
PIMAGE_FILE_HEADER coffFileHeader;
WORD PESignatureOffs;
PIMAGE_OPTIONAL_HEADER32 pOptlHdr;
PIMAGE_OPTIONAL_HEADER64 pOptlHdr64=0;
PIMAGE_DATA_DIRECTORY pImgDir;
PIMAGE_SECTION_HEADER pimgSectTable;

	PESignatureOffs = *((WORD*)(((char*)lpFileBase)+0x3c));
	pPESignature = ((char*)lpFileBase)+PESignatureOffs;
	coffFileHeader = (PIMAGE_FILE_HEADER)(((char*)pPESignature)+4);
	numSection = coffFileHeader->NumberOfSections;
	pOptlHdr = (PIMAGE_OPTIONAL_HEADER32)(((char*)coffFileHeader) + sizeof(IMAGE_FILE_HEADER));
	if(0x20b==pOptlHdr->Magic)
	{pOptlHdr64 = (PIMAGE_OPTIONAL_HEADER64)pOptlHdr;
	 pImgDir = &pOptlHdr64->DataDirectory[0];
	 numDirectory = pOptlHdr64->NumberOfRvaAndSizes;
	 pimgSectTable = (PIMAGE_SECTION_HEADER)(((char*)pImgDir) +
					  numDirectory*sizeof(IMAGE_DATA_DIRECTORY));
	}
	else
	{pImgDir = &pOptlHdr->DataDirectory[0];
	 numDirectory = pOptlHdr->NumberOfRvaAndSizes;
	 pimgSectTable = (PIMAGE_SECTION_HEADER)(((char*)pImgDir) +
					  numDirectory*sizeof(IMAGE_DATA_DIRECTORY));
	}

	StringCchPrintf(s,MAX_PATH,L"Section table, %d tables.",numSection);
	AddStrToMultilineEdit(hWndSectionTable,s);
	StringCchPrintf(s,MAX_PATH,L"Name, virtual size, virtual address, size of raw data, ptr.to raw, ptr.to reloc. ptr.to line num. num of reloc. num of line num. characteristics.");
	AddStrToMultilineEdit(hWndSectionTable,s);
	AddStrToMultilineEdit(hWndSectionTable,L"");

	for(i=0; i<numSection; ++i)
	{int k;char c[16];for(k=0; k<8; ++k)c[k]=pimgSectTable->Name[k];if(0!=c[k-1])c[k]=0;
	 StringCchPrintf(s,MAX_PATH,L"%02d ",i+1);
	 k=2+MultiByteToWideChar(CP_ACP,0,c,-1,&s[3],9);
	 s[k++]=' ';
	 StringCchPrintf(&s[k],MAX_PATH-k-1,L"   0x%08x",pimgSectTable->Misc.VirtualSize);
	 k+=13;
	 StringCchPrintf(&s[k],MAX_PATH-k-1,L"   0x%08x",pimgSectTable->VirtualAddress);
	 k+=13;
	 StringCchPrintf(&s[k],MAX_PATH-k-1,L"   0x%08x",pimgSectTable->SizeOfRawData);
	 k+=13;
	 StringCchPrintf(&s[k],MAX_PATH-k-1,L"   0x%08x",pimgSectTable->PointerToRawData);
	 k+=13;
	 StringCchPrintf(&s[k],MAX_PATH-k-1,L"   0x%08x",pimgSectTable->PointerToRelocations);
	 k+=13;
	 StringCchPrintf(&s[k],MAX_PATH-k-1,L"   0x%08x",pimgSectTable->PointerToLinenumbers);
	 k+=13;
	 StringCchPrintf(&s[k],MAX_PATH-k-1,L"   0x%08x",pimgSectTable->NumberOfRelocations);
	 k+=13;
	 StringCchPrintf(&s[k],MAX_PATH-k-1,L"   0x%08x",pimgSectTable->NumberOfLinenumbers);
	 k+=13;
	 StringCchPrintf(&s[k],MAX_PATH-k-1,L"   0x%08x",pimgSectTable->Characteristics);
	 AddStrToMultilineEdit(hWndSectionTable,s);
	 ++pimgSectTable;
	}
	pimgSectTable -= numSection;

    AddStrToMultilineEdit(hWndSectionTable,L"");

	for(i=0; i<numSection; ++i)
	{int k;char c[16];for(k=0; k<8; ++k)c[k]=pimgSectTable->Name[k];if(0!=c[k-1])c[k]=0;
	 StringCchPrintf(s,MAX_PATH,L"%02d Name: ",i+1);
	 MultiByteToWideChar(CP_ACP,0,c,-1,&s[9],9);
	 AddStrToMultilineEdit(hWndSectionTable,s);
	 if(wcschr(s,'$'))
	  AddStrToMultilineEdit(hWndSectionTable,L"            PART GROUP OF SECTIONS.");

	 StringCchPrintf(s,MAX_PATH-k-1,L"     VirtualSize:                     0x%08x",pimgSectTable->Misc.VirtualSize);
	 AddStrToMultilineEdit(hWndSectionTable,s);

	 StringCchPrintf(s,MAX_PATH-k-1,L"     VirtualAddress:               0x%08x",pimgSectTable->VirtualAddress);
	 AddStrToMultilineEdit(hWndSectionTable,s);

	 StringCchPrintf(s,MAX_PATH-k-1,L"     SizeOfRawData:             0x%08x",pimgSectTable->SizeOfRawData);
	 AddStrToMultilineEdit(hWndSectionTable,s);

	 StringCchPrintf(s,MAX_PATH-k-1,L"     PointerToRawData:         0x%08x",pimgSectTable->PointerToRawData);
	 AddStrToMultilineEdit(hWndSectionTable,s);

	 StringCchPrintf(s,MAX_PATH-k-1,L"     PointerToRelocations:    0x%08x",pimgSectTable->PointerToRelocations);
	 AddStrToMultilineEdit(hWndSectionTable,s);

	 StringCchPrintf(s,MAX_PATH-k-1,L"     PointerToLinenumbers:  0x%08x",pimgSectTable->PointerToLinenumbers);
	 AddStrToMultilineEdit(hWndSectionTable,s);

	 StringCchPrintf(s,MAX_PATH-k-1,L"     NumberOfRelocations:   0x%08x",pimgSectTable->NumberOfRelocations);
	 AddStrToMultilineEdit(hWndSectionTable,s);

	 StringCchPrintf(s,MAX_PATH-k-1,L"     NumberOfLinenumbers: 0x%08x",pimgSectTable->NumberOfLinenumbers);
	 AddStrToMultilineEdit(hWndSectionTable,s);

	 StringCchPrintf(s,MAX_PATH-k-1,L"     Characteristics:              0x%08x",pimgSectTable->Characteristics);
	 AddStrToMultilineEdit(hWndSectionTable,s);

	 if(0==pimgSectTable->Characteristics)// & IMAGE_SCN_TYPE_REG)
	  AddStrToMultilineEdit(hWndSectionTable,L"          IMAGE_SCN_TYPE_REG : Reserved for future use.");
	 if(pimgSectTable->Characteristics & 0x00000001)//IMAGE_SCN_TYPE_DSECT)
	  AddStrToMultilineEdit(hWndSectionTable,L"          IMAGE_SCN_TYPE_DSECT : Reserved for future use.");
	 if(pimgSectTable->Characteristics & 0x00000002)//IMAGE_SCN_TYPE_NOLOAD)
	  AddStrToMultilineEdit(hWndSectionTable,L"          IMAGE_SCN_TYPE_DSECT : Reserved for future use.");
	 if(pimgSectTable->Characteristics & 0x00000004)//IMAGE_SCN_TYPE_GROUP)
	  AddStrToMultilineEdit(hWndSectionTable,L"          IMAGE_SCN_TYPE_GROUP : Reserved for future use.");
	 if(pimgSectTable->Characteristics & IMAGE_SCN_TYPE_NO_PAD)
	  AddStrToMultilineEdit(hWndSectionTable,L"          IMAGE_SCN_TYPE_NO_PAD : Section should not be padded to next boundary. This is obsolete and replaced by IMAGE_SCN_ALIGN_1BYTES. This is valid for object files only.");
	 if(pimgSectTable->Characteristics & 0x00000010)//IMAGE_SCN_TYPE_COPY)
	  AddStrToMultilineEdit(hWndSectionTable,L"          IMAGE_SCN_TYPE_COPY : Reserved for future use.");
	 if(pimgSectTable->Characteristics & IMAGE_SCN_CNT_CODE)
	  AddStrToMultilineEdit(hWndSectionTable,L"          IMAGE_SCN_CNT_CODE : Section contains executable code.");
	 if(pimgSectTable->Characteristics & IMAGE_SCN_CNT_INITIALIZED_DATA)
	  AddStrToMultilineEdit(hWndSectionTable,L"          IMAGE_SCN_CNT_INITIALIZED_DATA : Section contains initialized data.");
	 if(pimgSectTable->Characteristics & IMAGE_SCN_CNT_UNINITIALIZED_DATA)
	  AddStrToMultilineEdit(hWndSectionTable,L"          IMAGE_SCN_CNT_UNINITIALIZED_DATA : Section contains uninitialized data.");
	 if(pimgSectTable->Characteristics & IMAGE_SCN_LNK_OTHER)
	  AddStrToMultilineEdit(hWndSectionTable,L"          IMAGE_SCN_LNK_OTHER : Reserved for future use.");
	 if(pimgSectTable->Characteristics & IMAGE_SCN_LNK_INFO)
	  AddStrToMultilineEdit(hWndSectionTable,L"          IMAGE_SCN_LNK_INFO : Section contains comments or other information. The .drectve section has this type. This is valid for object files only.");
	 if(pimgSectTable->Characteristics & 0x00000400)//IMAGE_SCN_TYPE_OVER)
	  AddStrToMultilineEdit(hWndSectionTable,L"          IMAGE_SCN_TYPE_OVER : Reserved for future use.");
	 if(pimgSectTable->Characteristics & IMAGE_SCN_LNK_REMOVE)
	  AddStrToMultilineEdit(hWndSectionTable,L"          IMAGE_SCN_LNK_REMOVE : Section will not become part of the image. This is valid for object files only.");
	 if(pimgSectTable->Characteristics & IMAGE_SCN_LNK_COMDAT)
	  AddStrToMultilineEdit(hWndSectionTable,L"          IMAGE_SCN_LNK_COMDAT : Section contains COMDAT data. See Section 5.5.6, �COMDAT Sections,� for more information. This is valid for object files only.");
	 if(pimgSectTable->Characteristics & IMAGE_SCN_MEM_FARDATA)
	  AddStrToMultilineEdit(hWndSectionTable,L"          IMAGE_SCN_MEM_FARDATA : Reserved for future use.");
	 if(pimgSectTable->Characteristics & IMAGE_SCN_MEM_PURGEABLE)
	  AddStrToMultilineEdit(hWndSectionTable,L"          IMAGE_SCN_MEM_PURGEABLE : Reserved for future use.");
	 if(pimgSectTable->Characteristics & IMAGE_SCN_MEM_16BIT)
	  AddStrToMultilineEdit(hWndSectionTable,L"          IMAGE_SCN_MEM_16BIT : Reserved for future use.");
	 if(pimgSectTable->Characteristics & IMAGE_SCN_MEM_LOCKED)
	  AddStrToMultilineEdit(hWndSectionTable,L"          IMAGE_SCN_MEM_LOCKED : Reserved for future use.");
	 if(pimgSectTable->Characteristics & IMAGE_SCN_MEM_PRELOAD)
	  AddStrToMultilineEdit(hWndSectionTable,L"          IMAGE_SCN_MEM_PRELOAD : Reserved for future use.");

	 if(pimgSectTable->Characteristics & IMAGE_SCN_ALIGN_1BYTES)
	  AddStrToMultilineEdit(hWndSectionTable,L"          IMAGE_SCN_ALIGN_1BYTES : Align data on a 1-byte boundary. This is valid for object files only.");
	 else if(pimgSectTable->Characteristics & IMAGE_SCN_ALIGN_2BYTES)
	  AddStrToMultilineEdit(hWndSectionTable,L"          IMAGE_SCN_ALIGN_2BYTES : Align data on a 2-byte boundary. This is valid for object files only.");
	 else if(pimgSectTable->Characteristics & IMAGE_SCN_ALIGN_4BYTES)
	  AddStrToMultilineEdit(hWndSectionTable,L"          IMAGE_SCN_ALIGN_4BYTES : Align data on a 4-byte boundary. This is valid for object files only.");
	 else if(pimgSectTable->Characteristics & IMAGE_SCN_ALIGN_8BYTES)
	  AddStrToMultilineEdit(hWndSectionTable,L"          IMAGE_SCN_ALIGN_8BYTES : Align data on a 8-byte boundary. This is valid for object files only.");
	 else if(pimgSectTable->Characteristics & IMAGE_SCN_ALIGN_32BYTES)
	  AddStrToMultilineEdit(hWndSectionTable,L"          IMAGE_SCN_ALIGN_32BYTES : Align data on a 32-byte boundary. This is valid for object files only.");
	 else if(pimgSectTable->Characteristics & IMAGE_SCN_ALIGN_64BYTES)
	  AddStrToMultilineEdit(hWndSectionTable,L"          IMAGE_SCN_ALIGN_64BYTES : Align data on a 64-byte boundary. This is valid for object files only.");
	 else if(pimgSectTable->Characteristics & IMAGE_SCN_ALIGN_128BYTES)
	  AddStrToMultilineEdit(hWndSectionTable,L"          IMAGE_SCN_ALIGN_128BYTES : Align data on a 128-byte boundary. This is valid for object files only.");
	 else if(pimgSectTable->Characteristics & IMAGE_SCN_ALIGN_256BYTES)
	  AddStrToMultilineEdit(hWndSectionTable,L"          IMAGE_SCN_ALIGN_256BYTES : Align data on a 256-byte boundary. This is valid for object files only.");
	 else if(pimgSectTable->Characteristics & IMAGE_SCN_ALIGN_512BYTES)
	  AddStrToMultilineEdit(hWndSectionTable,L"          IMAGE_SCN_ALIGN_512BYTES : Align data on a 512-byte boundary. This is valid for object files only.");
	 else if(pimgSectTable->Characteristics & IMAGE_SCN_ALIGN_1024BYTES)
	  AddStrToMultilineEdit(hWndSectionTable,L"          IMAGE_SCN_ALIGN_1024BYTES : Align data on a 1024-byte boundary. This is valid for object files only.");
	 else if(pimgSectTable->Characteristics & IMAGE_SCN_ALIGN_2048BYTES)
	  AddStrToMultilineEdit(hWndSectionTable,L"          IMAGE_SCN_ALIGN_2048BYTES : Align data on a 2048-byte boundary. This is valid for object files only.");
	 else if(pimgSectTable->Characteristics & IMAGE_SCN_ALIGN_4096BYTES)
	  AddStrToMultilineEdit(hWndSectionTable,L"          IMAGE_SCN_ALIGN_4096BYTES : Align data on a 4096-byte boundary. This is valid for object files only.");
	 else if(pimgSectTable->Characteristics & IMAGE_SCN_ALIGN_8192BYTES)
	  AddStrToMultilineEdit(hWndSectionTable,L"          IMAGE_SCN_ALIGN_8192BYTES : Align data on a 8192-byte boundary. This is valid for object files only.");
	 else//defa: if(pimgSectTable->Characteristics & IMAGE_SCN_ALIGN_16BYTES)
	  AddStrToMultilineEdit(hWndSectionTable,L"          IMAGE_SCN_ALIGN_16BYTES : Align data on a 16-byte boundary. This is valid for object files only.");

	 if(pimgSectTable->Characteristics & IMAGE_SCN_LNK_NRELOC_OVFL)
	  AddStrToMultilineEdit(hWndSectionTable,L"          IMAGE_SCN_LNK_NRELOC_OVFL : Section contains extended relocations.");
	 if(pimgSectTable->Characteristics & IMAGE_SCN_MEM_DISCARDABLE)
	  AddStrToMultilineEdit(hWndSectionTable,L"          IMAGE_SCN_MEM_DISCARDABLE : Section can be discarded as needed.");
	 if(pimgSectTable->Characteristics & IMAGE_SCN_MEM_NOT_CACHED)
	  AddStrToMultilineEdit(hWndSectionTable,L"          IMAGE_SCN_MEM_NOT_CACHED : Section cannot be cached.");
	 if(pimgSectTable->Characteristics & IMAGE_SCN_MEM_NOT_PAGED)
	  AddStrToMultilineEdit(hWndSectionTable,L"          IMAGE_SCN_MEM_NOT_PAGED : Section is not pageable.");
	 if(pimgSectTable->Characteristics & IMAGE_SCN_MEM_SHARED)
	  AddStrToMultilineEdit(hWndSectionTable,L"          IMAGE_SCN_MEM_SHARED : Section can be shared in memory.");
	 if(pimgSectTable->Characteristics & IMAGE_SCN_MEM_EXECUTE)
	  AddStrToMultilineEdit(hWndSectionTable,L"          IMAGE_SCN_MEM_EXECUTE : Section can be executed as code.");
	 if(pimgSectTable->Characteristics & IMAGE_SCN_MEM_READ)
	  AddStrToMultilineEdit(hWndSectionTable,L"          IMAGE_SCN_MEM_READ : Section can be read.");
	 if(pimgSectTable->Characteristics & IMAGE_SCN_MEM_WRITE)
	  AddStrToMultilineEdit(hWndSectionTable,L"          IMAGE_SCN_MEM_WRITE : Section can be written to.");
	 if(pimgSectTable->Characteristics & 0x00004000)//IMAGE_SCN_MEM_PROTECTED)
	  AddStrToMultilineEdit(hWndSectionTable,L"          IMAGE_SCN_MEM_PROTECTED : Obsolete.");
	 if(pimgSectTable->Characteristics & IMAGE_SCN_NO_DEFER_SPEC_EXC)
	  AddStrToMultilineEdit(hWndSectionTable,L"          IMAGE_SCN_NO_DEFER_SPEC_EXC : Reset speculative exceptions handling bits in the TLB entries for this section.");
	 if(pimgSectTable->Characteristics & IMAGE_SCN_GPREL)
	  AddStrToMultilineEdit(hWndSectionTable,L"          IMAGE_SCN_GPREL : Section content can be accessed relative to GP.");
	 if(pimgSectTable->Characteristics & 0x00010000)//IMAGE_SCN_MEM_SYSHEAP)
	  AddStrToMultilineEdit(hWndSectionTable,L"          IMAGE_SCN_MEM_SYSHEAP");
	 if(pimgSectTable->Characteristics & IMAGE_SCN_ALIGN_MASK)
	  AddStrToMultilineEdit(hWndSectionTable,L"          IMAGE_SCN_ALIGN_MASK");
	 AddStrToMultilineEdit(hWndSectionTable,L"");
	 ++pimgSectTable;
	}
	return TRUE;
}

BOOL OutputExportTable(HWND hWnd,LPVOID lpFileBase,PIMAGE_SECTION_HEADER pimgSectTable,
						 DWORD NumberOfSections,PIMAGE_EXPORT_DIRECTORY pimgDesc)
{DWORD i,j,index/*,last=0*/;char s[MAX_PATH];
 DWORD rvaAddressOfNames=RVAToFileOffset(pimgSectTable,
									NumberOfSections,
									pimgDesc->AddressOfNames);
 DWORD rvaAddressOfNameOrdinals=RVAToFileOffset(pimgSectTable,
									NumberOfSections,
									pimgDesc->AddressOfNameOrdinals);
 DWORD rvaAddressFunctions=RVAToFileOffset(pimgSectTable,
									NumberOfSections,
									pimgDesc->AddressOfFunctions);
 DWORD* pAddressOfNames = (DWORD*)(((char*)lpFileBase) + rvaAddressOfNames);
 WORD* pAddressOfNameOrdinals = (WORD*)(((char*)lpFileBase) + rvaAddressOfNameOrdinals);
 DWORD* pAddressFunctions = (DWORD*)(((char*)lpFileBase) + rvaAddressFunctions);
 if(-1==(int)rvaAddressOfNames)
	 pAddressOfNames=(DWORD*)lpFileBase;
 if(-1==(int)rvaAddressOfNameOrdinals)
	 pAddressOfNameOrdinals=(WORD*)lpFileBase;
 if(-1==(int)rvaAddressFunctions)
	 pAddressFunctions=(DWORD*)lpFileBase;

 StringCchPrintfA(s,MAX_PATH,"   Entry:          Ordinal:     Name:");
 AddStrToMultilineEditA(hWndExpDir,s);
 AddStrToMultilineEdit(hWndExpDir,L"");
 for(i=0; i<pimgDesc->NumberOfFunctions; ++i)
 {index=0xffff;
  for (j=0;j<pimgDesc->NumberOfNames;j++)
  {	if (pAddressOfNameOrdinals[j]==(i+pimgDesc->Base))
		{index=j;continue;}
  }
  if(-1==(int)rvaAddressOfNames || -1==(int)rvaAddressOfNameOrdinals)
  {	StringCchPrintfA(s,MAX_PATH,"Ordinal: %04d",i+pimgDesc->Base);
	AddStrToMultilineEditA(hWndExpDir,s);
	//last=i+pimgDesc->Base;
	continue;
  }else
  {DWORD *pAddressOfNames1;
   rvaAddressOfNames = RVAToFileOffset(pimgSectTable,
								       NumberOfSections,
								      *pAddressOfNames);
   if(0xffffffff==rvaAddressOfNames && 0xffff==index)
   {	StringCchPrintfA(s,MAX_PATH,"Ordinal: %04d",i+pimgDesc->Base);
		AddStrToMultilineEditA(hWndExpDir,s);
		//last=i+pimgDesc->Base;
   		continue;
   }
   pAddressOfNames1 = (DWORD*)(((char*)lpFileBase) + rvaAddressOfNames);
   StringCchPrintfA(s,MAX_PATH,"0x%08x    %04d    %s",*pAddressFunctions, *pAddressOfNameOrdinals+1, pAddressOfNames1);
   AddStrToMultilineEditA(hWndExpDir,s);
  }
  ++pAddressFunctions;
  ++pAddressOfNames;
  ++pAddressOfNameOrdinals;
 }
 AddStrToMultilineEdit(hWndExpDir,L"");
 return TRUE;
}

BOOL GetImgExpDir()
{char *pName;
wchar_t s[MAX_PATH];
DWORD numDirectory;
BYTE *pPESignature;
PIMAGE_FILE_HEADER coffFileHeader;
WORD PESignatureOffs;
DWORD RVAToBaseAddr,sz;
PIMAGE_OPTIONAL_HEADER32 pOptlHdr;
PIMAGE_OPTIONAL_HEADER64 pOptlHdr64=0;
PIMAGE_DATA_DIRECTORY pImgDir;
PIMAGE_EXPORT_DIRECTORY pimgDesc;
PIMAGE_SECTION_HEADER pimgSectTable;

	PESignatureOffs = *((WORD*)(((char*)lpFileBase)+0x3c));
	pPESignature = ((char*)lpFileBase)+PESignatureOffs;
	coffFileHeader = (PIMAGE_FILE_HEADER)(((char*)pPESignature)+4);
	pOptlHdr = (PIMAGE_OPTIONAL_HEADER32)(((char*)coffFileHeader) + sizeof(IMAGE_FILE_HEADER));
	if(0x20b==pOptlHdr->Magic)
	{pOptlHdr64 = (PIMAGE_OPTIONAL_HEADER64)pOptlHdr;
	 pImgDir = &pOptlHdr64->DataDirectory[0];
	 numDirectory = pOptlHdr64->NumberOfRvaAndSizes;
	 pimgSectTable = (PIMAGE_SECTION_HEADER)(((char*)pImgDir) +
					  numDirectory*sizeof(IMAGE_DATA_DIRECTORY));
	}
	else
	{pImgDir = &pOptlHdr->DataDirectory[0];
	 numDirectory = pOptlHdr->NumberOfRvaAndSizes;
	 pimgSectTable = (PIMAGE_SECTION_HEADER)(((char*)pImgDir) +
					  numDirectory*sizeof(IMAGE_DATA_DIRECTORY));
	}

	if(numDirectory<2)
	{AddStrToMultilineEdit(hWndIAT,L"Export Directory not founded.");
	 return FALSE;
	}

	StringCchPrintf(s,MAX_PATH,L"Export Directory: Virtual address: %08x, size: %08x.",
					pImgDir[0].VirtualAddress,pImgDir[0].Size);
	AddStrToMultilineEdit(hWndExpDir,s);
	AddStrToMultilineEdit(hWndExpDir,L"");

	RVAToBaseAddr = RVAToFileOffset(pimgSectTable,
									coffFileHeader->NumberOfSections,
									pImgDir[0].VirtualAddress);
	pimgDesc = (PIMAGE_EXPORT_DIRECTORY)(((char*)lpFileBase) + RVAToBaseAddr);

	sz=0;
	while(sz<pImgDir[0].Size)
	{if(0==pimgDesc->Characteristics && 0==pimgDesc->TimeDateStamp && 0==pimgDesc->MajorVersion &&
		0 == pimgDesc->MinorVersion && 0==pimgDesc->Name && 0==pimgDesc->Base &&
		0==pimgDesc->NumberOfFunctions && 0==pimgDesc->NumberOfNames && 0==pimgDesc->AddressOfFunctions &&
		0==pimgDesc->AddressOfNames && 0==pimgDesc->AddressOfNameOrdinals)
	  break;

	 //Name:
	 RVAToBaseAddr = RVAToFileOffset(pimgSectTable,coffFileHeader->NumberOfSections,pimgDesc->Name);
	 pName = ((char*)lpFileBase) + RVAToBaseAddr;
	 StringCchPrintf(s,MAX_PATH,L"Name:                                ");
	 MultiByteToWideChar(CP_ACP,0,pName,-1,&s[37],64);
	 AddStrToMultilineEdit(hWndExpDir,s);

	 StringCchPrintf(s,MAX_PATH,L"Name RVA:                         0x%08x",pimgDesc->Name);
	 AddStrToMultilineEdit(hWndExpDir,s);

	 StringCchPrintf(s,MAX_PATH,L"Export flag:                        0x%08x     A reserved field, set to zero for now..",pimgDesc->Characteristics);
	 AddStrToMultilineEdit(hWndExpDir,s);

	 StringCchPrintf(s,MAX_PATH,L"TimeDateStamp:                0x%08x     The time/date stamp indicating when the file was built.",pimgDesc->TimeDateStamp);
	 AddStrToMultilineEdit(hWndExpDir,s);

	 StringCchPrintf(s,MAX_PATH,L"MajorVersion:                     0x%04x",pimgDesc->MajorVersion);
	 AddStrToMultilineEdit(hWndExpDir,s);

	 StringCchPrintf(s,MAX_PATH,L"MinorVersion:                     0x%04x",pimgDesc->MinorVersion);
	 AddStrToMultilineEdit(hWndExpDir,s);

	 StringCchPrintf(s,MAX_PATH,L"Base:                                  0x%08x    Starting ordinal number for exports in this image. This field specifies the starting ordinal number for the Export Address Table. Usually set to 1.",pimgDesc->Base);
	 AddStrToMultilineEdit(hWndExpDir,s);

	 StringCchPrintf(s,MAX_PATH,L"NumberOfFunctions:           0x%08x    Number of entries in the Export Address Table.",pimgDesc->NumberOfFunctions);
	 AddStrToMultilineEdit(hWndExpDir,s);

	 StringCchPrintf(s,MAX_PATH,L"NumberOfNames:               0x%08x    Number of entries in the Name Pointer Table (also the number of entries in the Ordinal Table).",pimgDesc->NumberOfNames);
	 AddStrToMultilineEdit(hWndExpDir,s);

	 StringCchPrintf(s,MAX_PATH,L"AddressOfFunctions:           0x%08x    Address of the Export Address Table, relative to the image base.",pimgDesc->AddressOfFunctions);
	 AddStrToMultilineEdit(hWndExpDir,s);

	 StringCchPrintf(s,MAX_PATH,L"AddressOfNames:               0x%08x    Address of the Export Name Pointer Table, relative to the image base. The table size is given by Number of Name Pointers.",pimgDesc->AddressOfNames);
	 AddStrToMultilineEdit(hWndExpDir,s);

	 StringCchPrintf(s,MAX_PATH,L"AddressOfNameOrdinals:   0x%08x    Address of the Ordinal Table, relative to the image base.",pimgDesc->AddressOfNameOrdinals);
	 AddStrToMultilineEdit(hWndExpDir,s);
	 AddStrToMultilineEdit(hWndExpDir,L"");

	 OutputExportTable(hWndExpDir,
				       lpFileBase,
					   pimgSectTable,
					   coffFileHeader->NumberOfSections,
					   pimgDesc);
	 AddStrToMultilineEdit(hWndExpDir,L"");
	 sz += sizeof(IMAGE_EXPORT_DIRECTORY);
	 break;//++pimgDesc;
	}//Faqat 1tagina bo'ladur ekan;
	return TRUE;
}

BOOL GetImgImpDir()
{char *pName;
wchar_t s[MAX_PATH];
DWORD numDirectory;
BYTE *pPESignature;
PIMAGE_FILE_HEADER coffFileHeader;
WORD PESignatureOffs;
DWORD RVAToBaseAddr,sz;
PIMAGE_OPTIONAL_HEADER32 pOptlHdr;
PIMAGE_OPTIONAL_HEADER64 pOptlHdr64=0;
PIMAGE_DATA_DIRECTORY pImgDir;
PIMAGE_IMPORT_DESCRIPTOR pimgDesc;
PIMAGE_SECTION_HEADER pimgSectTable;

	PESignatureOffs = *((WORD*)(((char*)lpFileBase)+0x3c));
	pPESignature = ((char*)lpFileBase)+PESignatureOffs;
	coffFileHeader = (PIMAGE_FILE_HEADER)(((char*)pPESignature)+4);
	pOptlHdr = (PIMAGE_OPTIONAL_HEADER32)(((char*)coffFileHeader) + sizeof(IMAGE_FILE_HEADER));
	if(0x20b==pOptlHdr->Magic)
	{pOptlHdr64 = (PIMAGE_OPTIONAL_HEADER64)pOptlHdr;
	 pImgDir = &pOptlHdr64->DataDirectory[0];
	 numDirectory = pOptlHdr64->NumberOfRvaAndSizes;
	 pimgSectTable = (PIMAGE_SECTION_HEADER)(((char*)pImgDir) +
					  numDirectory*sizeof(IMAGE_DATA_DIRECTORY));
	}
	else
	{pImgDir = &pOptlHdr->DataDirectory[0];
	 numDirectory = pOptlHdr->NumberOfRvaAndSizes;
	 pimgSectTable = (PIMAGE_SECTION_HEADER)(((char*)pImgDir) +
					  numDirectory*sizeof(IMAGE_DATA_DIRECTORY));
	}

	if(numDirectory<2)
	{AddStrToMultilineEdit(hWndIAT,L"Import Directory not founded.");
	 return FALSE;
	}

	StringCchPrintf(s,MAX_PATH,L"Import Directory: Virtual address: %08x, size: %08x.",
					pImgDir[1].VirtualAddress,pImgDir[1].Size);
	AddStrToMultilineEdit(hWndImpDir,s);
	AddStrToMultilineEdit(hWndImpDir,L"");

	RVAToBaseAddr = RVAToFileOffset(pimgSectTable,
									coffFileHeader->NumberOfSections,
									pImgDir[1].VirtualAddress);
	pimgDesc = (PIMAGE_IMPORT_DESCRIPTOR)(((char*)lpFileBase) + RVAToBaseAddr);

	sz=0;
	while(sz<pImgDir[1].Size)
	{if(0==pimgDesc->OriginalFirstThunk && 0==pimgDesc->TimeDateStamp && 
	    0==pimgDesc->ForwarderChain && 0==pimgDesc->Name && 0==pimgDesc->FirstThunk)
	  break;

	 //Name:
	 RVAToBaseAddr = RVAToFileOffset(pimgSectTable,coffFileHeader->NumberOfSections,pimgDesc->Name);
	 pName = ((char*)lpFileBase) + RVAToBaseAddr;

	 StringCchPrintf(s,MAX_PATH,L"Name:                                ");
	 MultiByteToWideChar(CP_ACP,0,pName,-1,&s[37],64);
	 AddStrToMultilineEdit(hWndImpDir,s);
	 AddItemToTree(hWndTree,&s[37],2,3,3,-1);

	 StringCchPrintf(s,MAX_PATH,L"Name RVA:                         0x%08x",pimgDesc->Name);
	 AddStrToMultilineEdit(hWndImpDir,s);

	 StringCchPrintf(s,MAX_PATH,L"Import Lookup Table RVA: 0x%08x     Relative virtual address of the Import Lookup Table.",pimgDesc->OriginalFirstThunk);//Characteristics
	 AddStrToMultilineEdit(hWndImpDir,s);

	 StringCchPrintf(s,MAX_PATH,L"TimeDateStamp:                0x%08x     The time/date stamp indicating when the file was built.",pimgDesc->TimeDateStamp);
	 AddStrToMultilineEdit(hWndImpDir,s);

	 StringCchPrintf(s,MAX_PATH,L"ForwarderChain:                0x%08x     (-1 if no forwarders)",pimgDesc->ForwarderChain);
	 AddStrToMultilineEdit(hWndImpDir,s);

	 StringCchPrintf(s,MAX_PATH,L"Import Address Table:       0x%08x     Relative virtual address of the Import Address Table.",pimgDesc->FirstThunk);
	 AddStrToMultilineEdit(hWndImpDir,s);
	 AddStrToMultilineEdit(hWndImpDir,L"");

	 AddStrToMultilineEdit(hWndImpDir,L"  Ordinal1:        Name1:                              Ordinal2:        Name2:");
	 if(pOptlHdr64)
		 OutputImportLookupTable64(hWndImpDir,
								   lpFileBase,
								   pimgSectTable,
								   coffFileHeader->NumberOfSections,
								   pimgDesc->OriginalFirstThunk,
								   pimgDesc->FirstThunk);
	 else
		 OutputImportLookupTable32(hWndImpDir,
								   lpFileBase,
								   pimgSectTable,
								   coffFileHeader->NumberOfSections,
								   pimgDesc->OriginalFirstThunk,
								   pimgDesc->FirstThunk);
	 AddStrToMultilineEdit(hWndImpDir,L"");
	 sz += sizeof(IMAGE_IMPORT_DESCRIPTOR);
	 ++pimgDesc;
	}
	return TRUE;
}

BOOL GetImgBaseRelTable(LPVOID lpFileBase)
{
wchar_t s[MAX_PATH];
DWORD numDirectory;
BYTE *pPESignature;
PIMAGE_FILE_HEADER coffFileHeader;
WORD PESignatureOffs;
PIMAGE_OPTIONAL_HEADER32 pOptlHdr;
PIMAGE_OPTIONAL_HEADER64 pOptlHdr64=0;
PIMAGE_DATA_DIRECTORY pImgDir;

	PESignatureOffs = *((WORD*)(((char*)lpFileBase)+0x3c));
	pPESignature = ((char*)lpFileBase)+PESignatureOffs;
	coffFileHeader = (PIMAGE_FILE_HEADER)(((char*)pPESignature)+4);
	pOptlHdr = (PIMAGE_OPTIONAL_HEADER32)(((char*)coffFileHeader) + sizeof(IMAGE_FILE_HEADER));
	if(0x20b==pOptlHdr->Magic)
	{pOptlHdr64 = (PIMAGE_OPTIONAL_HEADER64)pOptlHdr;
	 pImgDir = &pOptlHdr64->DataDirectory[0];
	 numDirectory = pOptlHdr64->NumberOfRvaAndSizes;
	}
	else
	{pImgDir = &pOptlHdr->DataDirectory[0];
	 numDirectory = pOptlHdr->NumberOfRvaAndSizes;
	}
	if(numDirectory<3)
	{AddStrToMultilineEdit(hWndIAT,L"Base Relocation Table not founded.");
	 return FALSE;
	}

	StringCchPrintf(s,MAX_PATH,L"Base Relocation Table: Virtual address: %08x, size: %08x.",
					pImgDir[5].VirtualAddress,pImgDir[5].Size);
	AddStrToMultilineEdit(hWndBaseRelTable,s);
	AddStrToMultilineEdit(hWndBaseRelTable,L"");

	return TRUE;
}

BOOL GetImgDbgDir(LPVOID lpFileBase)
{
wchar_t s[MAX_PATH];
DWORD numDirectory;
BYTE *pPESignature;
PIMAGE_FILE_HEADER coffFileHeader;
WORD PESignatureOffs;
PIMAGE_OPTIONAL_HEADER32 pOptlHdr;
PIMAGE_OPTIONAL_HEADER64 pOptlHdr64=0;
PIMAGE_DATA_DIRECTORY pImgDir;

	PESignatureOffs = *((WORD*)(((char*)lpFileBase)+0x3c));
	pPESignature = ((char*)lpFileBase)+PESignatureOffs;
	coffFileHeader = (PIMAGE_FILE_HEADER)(((char*)pPESignature)+4);
	pOptlHdr = (PIMAGE_OPTIONAL_HEADER32)(((char*)coffFileHeader) + sizeof(IMAGE_FILE_HEADER));
	if(0x20b==pOptlHdr->Magic)
	{pOptlHdr64 = (PIMAGE_OPTIONAL_HEADER64)pOptlHdr;
	 pImgDir = &pOptlHdr64->DataDirectory[0];
	 numDirectory = pOptlHdr64->NumberOfRvaAndSizes;
	}
	else
	{pImgDir = &pOptlHdr->DataDirectory[0];
	 numDirectory = pOptlHdr->NumberOfRvaAndSizes;
	}
	if(numDirectory<3)
	{AddStrToMultilineEdit(hWndIAT,L"Debug Directory not founded.");
	 return FALSE;
	}

	StringCchPrintf(s,MAX_PATH,L"Base Relocation Table: Virtual address: %08x, size: %08x.",
					pImgDir[6].VirtualAddress,pImgDir[6].Size);
	AddStrToMultilineEdit(hWndDbgDir,s);
	AddStrToMultilineEdit(hWndDbgDir,L"");

	return TRUE;
}

BOOL GetImgLoadConfDir(LPVOID lpFileBase)
{
wchar_t s[MAX_PATH];
DWORD numDirectory;
BYTE *pPESignature;
PIMAGE_FILE_HEADER coffFileHeader;
WORD PESignatureOffs;
PIMAGE_OPTIONAL_HEADER32 pOptlHdr;
PIMAGE_OPTIONAL_HEADER64 pOptlHdr64=0;
PIMAGE_DATA_DIRECTORY pImgDir;

	PESignatureOffs = *((WORD*)(((char*)lpFileBase)+0x3c));
	pPESignature = ((char*)lpFileBase)+PESignatureOffs;
	coffFileHeader = (PIMAGE_FILE_HEADER)(((char*)pPESignature)+4);
	pOptlHdr = (PIMAGE_OPTIONAL_HEADER32)(((char*)coffFileHeader) + sizeof(IMAGE_FILE_HEADER));
	if(0x20b==pOptlHdr->Magic)
	{pOptlHdr64 = (PIMAGE_OPTIONAL_HEADER64)pOptlHdr;
	 pImgDir = &pOptlHdr64->DataDirectory[0];
	 numDirectory = pOptlHdr64->NumberOfRvaAndSizes;
	}
	else
	{pImgDir = &pOptlHdr->DataDirectory[0];
	 numDirectory = pOptlHdr->NumberOfRvaAndSizes;
	}
	if(numDirectory<3)
	{AddStrToMultilineEdit(hWndIAT,L"Load Configuration Directory not founded.");
	 return FALSE;
	}

	StringCchPrintf(s,MAX_PATH,L"Load Configuration Directory: Virtual address: %08x, size: %08x.",
					pImgDir[10].VirtualAddress,pImgDir[10].Size);
	AddStrToMultilineEdit(hWndLoadConfDir,s);
	AddStrToMultilineEdit(hWndLoadConfDir,L"");

	return TRUE;
}

BOOL GetImgIAT(LPVOID lpFileBase)
{
wchar_t s[MAX_PATH];
DWORD numDirectory;
BYTE *pPESignature;
PIMAGE_FILE_HEADER coffFileHeader;
WORD PESignatureOffs;
PIMAGE_OPTIONAL_HEADER32 pOptlHdr;
PIMAGE_OPTIONAL_HEADER64 pOptlHdr64=0;
PIMAGE_DATA_DIRECTORY pImgDir;

	PESignatureOffs = *((WORD*)(((char*)lpFileBase)+0x3c));
	pPESignature = ((char*)lpFileBase)+PESignatureOffs;
	coffFileHeader = (PIMAGE_FILE_HEADER)(((char*)pPESignature)+4);
	pOptlHdr = (PIMAGE_OPTIONAL_HEADER32)(((char*)coffFileHeader) + sizeof(IMAGE_FILE_HEADER));
	if(0x20b==pOptlHdr->Magic)
	{pOptlHdr64 = (PIMAGE_OPTIONAL_HEADER64)pOptlHdr;
	 pImgDir = &pOptlHdr64->DataDirectory[0];
	 numDirectory = pOptlHdr64->NumberOfRvaAndSizes;
	}
	else
	{pImgDir = &pOptlHdr->DataDirectory[0];
	 numDirectory = pOptlHdr->NumberOfRvaAndSizes;
	}
	if(numDirectory<12)
	{AddStrToMultilineEdit(hWndIAT,L"Import Address Table not founded.");
	 return FALSE;
	}

	StringCchPrintf(s,MAX_PATH,L"Import Address Table: Virtual address: %08x, size: %08x.",
					pImgDir[12].VirtualAddress,pImgDir[12].Size);
	AddStrToMultilineEdit(hWndIAT,s);
	AddStrToMultilineEdit(hWndIAT,L"");
	return TRUE;
}

BOOL GetMSDOSStubAddrToDlg(HWND hDlg)
{/*wchar_t s[MAX_PATH];
 SetDlgItemText(hDlg,IDC_EDIT_RES_OFFSET,L"0x000");
 StringCchPrintf(s,MAX_PATH,L"0x%08x",sizeof(IMAGE_DOS_HEADER));
 SetDlgItemText(hDlg,IDC_EDIT_RES_SIZE,s);*/
 return TRUE;
}
BOOL GetCOFFHdrAddrToDlg(HWND hDlg)
{/*wchar_t s[MAX_PATH];
 WORD PESignatureOffs = *((WORD*)(((char*)lpFileBase)+0x3c));
 BYTE *pPESignature = ((char*)lpFileBase)+PESignatureOffs;
 PIMAGE_FILE_HEADER coffFileHeader = (PIMAGE_FILE_HEADER)(((char*)pPESignature)+4);
 StringCchPrintf(s,MAX_PATH,L"0x%08x", (int)(((char*)coffFileHeader)-(char*)lpFileBase));
 SetDlgItemText(hDlg,IDC_EDIT_RES_OFFSET,s);
 StringCchPrintf(s,MAX_PATH,L"0x%08x",sizeof(IMAGE_FILE_HEADER));
 SetDlgItemText(hDlg,IDC_EDIT_RES_SIZE,s);*/
 return TRUE;
}
BOOL GetOptHdrAddrToDlg(HWND hDlg)
{/*wchar_t s[MAX_PATH];
 WORD PESignatureOffs = *((WORD*)(((char*)lpFileBase)+0x3c));
 BYTE *pPESignature = ((char*)lpFileBase)+PESignatureOffs;
 PIMAGE_FILE_HEADER coffFileHeader = (PIMAGE_FILE_HEADER)(((char*)pPESignature)+4);
 PIMAGE_OPTIONAL_HEADER32 pOptlHdr = (PIMAGE_OPTIONAL_HEADER32)(((char*)coffFileHeader) + sizeof(IMAGE_FILE_HEADER));
 StringCchPrintf(s,MAX_PATH,L"0x%08x", (int)(((char*)pOptlHdr)-(char*)lpFileBase));
 SetDlgItemText(hDlg,IDC_EDIT_RES_OFFSET,s);
 StringCchPrintf(s,MAX_PATH,L"0x%08x",sizeof(IMAGE_OPTIONAL_HEADER32));
 SetDlgItemText(hDlg,IDC_EDIT_RES_SIZE,s);*/
 return TRUE;
}
BOOL GetDataDirAddrToDlg(HWND hDlg)
{/*wchar_t s[MAX_PATH];
 WORD PESignatureOffs = *((WORD*)(((char*)lpFileBase)+0x3c));
 BYTE *pPESignature = ((char*)lpFileBase)+PESignatureOffs;
 PIMAGE_FILE_HEADER coffFileHeader = (PIMAGE_FILE_HEADER)(((char*)pPESignature)+4);
 PIMAGE_OPTIONAL_HEADER32 pOptlHdr = (PIMAGE_OPTIONAL_HEADER32)(((char*)coffFileHeader) + sizeof(IMAGE_FILE_HEADER));
 PIMAGE_OPTIONAL_HEADER64 pOptlHdr64;
 PIMAGE_DATA_DIRECTORY pImgDir;
 if(0x20b==pOptlHdr->Magic)
 {pOptlHdr64 = (PIMAGE_OPTIONAL_HEADER64)pOptlHdr;
  pImgDir = &pOptlHdr64->DataDirectory[0];
 }
 else pImgDir = &pOptlHdr->DataDirectory[0];
 StringCchPrintf(s,MAX_PATH,L"0x%08x", (int)(((char*)pImgDir)-((char*)lpFileBase)));
 SetDlgItemText(hDlg,IDC_EDIT_RES_OFFSET,s);
 StringCchPrintf(s,MAX_PATH,L"0x%08x",16*sizeof(IMAGE_DATA_DIRECTORY));
 SetDlgItemText(hDlg,IDC_EDIT_RES_SIZE,s);*/
 return TRUE;
}
BOOL GetSectnTblAddrToDlg(HWND hDlg)
{/*wchar_t s[MAX_PATH];
 WORD PESignatureOffs = *((WORD*)(((char*)lpFileBase)+0x3c));
 BYTE *pPESignature = ((char*)lpFileBase)+PESignatureOffs;
 PIMAGE_FILE_HEADER coffFileHeader = (PIMAGE_FILE_HEADER)(((char*)pPESignature)+4);
 DWORD numSection = coffFileHeader->NumberOfSections;
 PIMAGE_OPTIONAL_HEADER32 pOptlHdr = (PIMAGE_OPTIONAL_HEADER32)(((char*)coffFileHeader) + sizeof(IMAGE_FILE_HEADER));
 PIMAGE_OPTIONAL_HEADER64 pOptlHdr64;
 PIMAGE_DATA_DIRECTORY pImgDir;
 PIMAGE_SECTION_HEADER pimgSectTable;
 DWORD numDirectory;
 if(0x20b==pOptlHdr->Magic)
 {pOptlHdr64 = (PIMAGE_OPTIONAL_HEADER64)pOptlHdr;
  pImgDir = &pOptlHdr64->DataDirectory[0];
  numDirectory = pOptlHdr64->NumberOfRvaAndSizes;
  pimgSectTable = (PIMAGE_SECTION_HEADER)(((char*)pImgDir) +
					  numDirectory*sizeof(IMAGE_DATA_DIRECTORY));
 }
 else
 {numDirectory = pOptlHdr->NumberOfRvaAndSizes;
  pImgDir = &pOptlHdr->DataDirectory[0];
  pimgSectTable = (PIMAGE_SECTION_HEADER)(((char*)pImgDir) +
					  numDirectory*sizeof(IMAGE_DATA_DIRECTORY));
  pImgDir = &pOptlHdr->DataDirectory[0];
 }
 StringCchPrintf(s,MAX_PATH,L"0x%08x", (int)(((char*)pimgSectTable)-((char*)lpFileBase)));
 SetDlgItemText(hDlg,IDC_EDIT_RES_OFFSET,s);
 StringCchPrintf(s,MAX_PATH,L"0x%08x",numSection*sizeof(IMAGE_SECTION_HEADER));
 SetDlgItemText(hDlg,IDC_EDIT_RES_SIZE,s);*/
 return TRUE;
}
BOOL GetExprtDirAddrToDlg(HWND hDlg)
{/*wchar_t s[MAX_PATH];
 WORD PESignatureOffs = *((WORD*)(((char*)lpFileBase)+0x3c));
 BYTE *pPESignature = ((char*)lpFileBase)+PESignatureOffs;
 PIMAGE_FILE_HEADER coffFileHeader = (PIMAGE_FILE_HEADER)(((char*)pPESignature)+4);
 DWORD numSection = coffFileHeader->NumberOfSections;
 PIMAGE_OPTIONAL_HEADER32 pOptlHdr = (PIMAGE_OPTIONAL_HEADER32)(((char*)coffFileHeader) + sizeof(IMAGE_FILE_HEADER));
 PIMAGE_OPTIONAL_HEADER64 pOptlHdr64;
 PIMAGE_DATA_DIRECTORY pImgDir;
 PIMAGE_SECTION_HEADER pimgSectTable;
 DWORD numDirectory,RVAToBaseAddr;
 if(0x20b==pOptlHdr->Magic)
 {pOptlHdr64 = (PIMAGE_OPTIONAL_HEADER64)pOptlHdr;
  pImgDir = &pOptlHdr64->DataDirectory[0];
  numDirectory = pOptlHdr64->NumberOfRvaAndSizes;
  pimgSectTable = (PIMAGE_SECTION_HEADER)(((char*)pImgDir) +
					  numDirectory*sizeof(IMAGE_DATA_DIRECTORY));
 }
 else
 {numDirectory = pOptlHdr->NumberOfRvaAndSizes;
  pImgDir = &pOptlHdr->DataDirectory[0];
  pimgSectTable = (PIMAGE_SECTION_HEADER)(((char*)pImgDir) +
					  numDirectory*sizeof(IMAGE_DATA_DIRECTORY));
  pImgDir = &pOptlHdr->DataDirectory[0];
 }
 RVAToBaseAddr = RVAToFileOffset(pimgSectTable,
								 coffFileHeader->NumberOfSections,
								 pImgDir[0].VirtualAddress);
 StringCchPrintf(s,MAX_PATH,L"0x%08x", RVAToBaseAddr);
 SetDlgItemText(hDlg,IDC_EDIT_RES_OFFSET,s);
 StringCchPrintf(s,MAX_PATH,L"0x%08x",sizeof(IMAGE_EXPORT_DIRECTORY));
 SetDlgItemText(hDlg,IDC_EDIT_RES_SIZE,s);*/
 return TRUE;
}
BOOL GetImprtDirAddrToDlg(HWND hDlg)
{/*wchar_t s[MAX_PATH];
 WORD PESignatureOffs = *((WORD*)(((char*)lpFileBase)+0x3c));
 BYTE *pPESignature = ((char*)lpFileBase)+PESignatureOffs;
 PIMAGE_FILE_HEADER coffFileHeader = (PIMAGE_FILE_HEADER)(((char*)pPESignature)+4);
 DWORD numSection = coffFileHeader->NumberOfSections;
 PIMAGE_OPTIONAL_HEADER32 pOptlHdr = (PIMAGE_OPTIONAL_HEADER32)(((char*)coffFileHeader) + sizeof(IMAGE_FILE_HEADER));
 PIMAGE_OPTIONAL_HEADER64 pOptlHdr64;
 PIMAGE_DATA_DIRECTORY pImgDir;
 PIMAGE_SECTION_HEADER pimgSectTable;
 DWORD numDirectory,RVAToBaseAddr;
 if(0x20b==pOptlHdr->Magic)
 {pOptlHdr64 = (PIMAGE_OPTIONAL_HEADER64)pOptlHdr;
  pImgDir = &pOptlHdr64->DataDirectory[0];
  numDirectory = pOptlHdr64->NumberOfRvaAndSizes;
  pimgSectTable = (PIMAGE_SECTION_HEADER)(((char*)pImgDir) +
					  numDirectory*sizeof(IMAGE_DATA_DIRECTORY));
 }
 else
 {numDirectory = pOptlHdr->NumberOfRvaAndSizes;
  pImgDir = &pOptlHdr->DataDirectory[0];
  pimgSectTable = (PIMAGE_SECTION_HEADER)(((char*)pImgDir) +
					  numDirectory*sizeof(IMAGE_DATA_DIRECTORY));
  pImgDir = &pOptlHdr->DataDirectory[0];
 }
 RVAToBaseAddr = RVAToFileOffset(pimgSectTable,
									coffFileHeader->NumberOfSections,
									pImgDir[1].VirtualAddress);
 StringCchPrintf(s,MAX_PATH,L"0x%08x", RVAToBaseAddr);
 SetDlgItemText(hDlg,IDC_EDIT_RES_OFFSET,s);
 StringCchPrintf(s,MAX_PATH,L"0x%08x",sizeof(IMAGE_EXPORT_DIRECTORY));
 SetDlgItemText(hDlg,IDC_EDIT_RES_SIZE,s);*/
 return TRUE;
}
BOOL GetResDirAddr(HWND hDlg)
{
	return TRUE;
}
BOOL GetExcptnDirAddr(HWND hDlg)
{
	return TRUE;
}
BOOL GetSecurDirAddr(HWND hDlg)
{
	return TRUE;
}
BOOL GetBaseRelTblAddr(HWND hDlg)
{
	return TRUE;
}
BOOL GetDbgDirAddr(HWND hDlg)
{
	return TRUE;
}
BOOL GetArchSpecDatAddr(HWND hDlg)
{
	return TRUE;
}
BOOL GetRVAToGPAddr(HWND hDlg)
{
	return TRUE;
}
BOOL GetTLSDirAddr(HWND hDlg)
{
	return TRUE;
}
BOOL GetLoadConfDirAddr(HWND hDlg)
{
	return TRUE;
}
BOOL GetBoundImpDirAddr(HWND hDlg)
{
	return TRUE;
}
BOOL GetIATDirAddr(HWND hDlg)
{
	return TRUE;
}
BOOL GetDelayLoadImpDescAddr(HWND hDlg)
{
	return TRUE;
}
BOOL GetRTDescAddr(HWND hDlg)
{
	return TRUE;
}