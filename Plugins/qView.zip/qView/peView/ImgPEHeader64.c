#include "MyVersion.h"
#include "strsafe.h"
#include "WinNT.h"
#include "commctrl.h"


typedef unsigned __int64 QWORD;

extern HWND hWndTree,
	 hWndFindFirst,
     hWndGetInfoShort,
     hWndGetInfoFull,
     hWndGetInfoBin,
     hWndImgDosHeader,
  	 hWndPESign,
 	 hWndCOOFFFileHeader,
	 hWndOptionalHeader,
	 hWndDataDirectory,
	 hWndSectionTable,
	 hWndExpDir,
	 hWndImpDir,
	 hWndResDir,
	 hWndExceptDir,
	 hWndSecurDir,
	 hWndBaseRelTable,
	 hWndDbgDir,
	 hWndArchSpecData,
	 hWndRVAtoGP,
	 hWndTLSDir,
	 hWndLoadConfDir,
	 hWndBoundImpDir,
	 hWndIAT,
	 hWndDelayLoadImpDesc,
	 hWndCOMRTDesc;

extern VOID AddStrToMultilineEditA(HWND,char*);
extern DWORD RVAToFileOffset(PIMAGE_SECTION_HEADER,DWORD,DWORD);
extern HTREEITEM AddItemToTree(HWND,wchar_t*,int,int,int,int);


QWORD RVAToFileOffset64(PIMAGE_SECTION_HEADER pSectHdr0,DWORD numOfSections,QWORD rva)
{unsigned i;
 for(i=0; i<numOfSections; i++, pSectHdr0++)
 {	DWORD cbMaxOnDisk = min(pSectHdr0->Misc.VirtualSize,pSectHdr0->SizeOfRawData);
	DWORD startSectRVA = pSectHdr0->VirtualAddress;
    DWORD endSectRVA = startSectRVA + cbMaxOnDisk;
    if((rva>=startSectRVA) && (rva<endSectRVA))
	 return pSectHdr0->PointerToRawData + (rva - startSectRVA);
 }
 return (QWORD)-1;// RVA not found in the section table... Ooops!
}

BOOL OutputImportLookupTable64(HWND hWnd,char* lpFileBase,PIMAGE_SECTION_HEADER pimgSectTable,
							   DWORD NumberOfSections,DWORD RVAordnl,DWORD RVAfsrt)
{char s[MAX_PATH];wchar_t ws[MAX_PATH];
 PIMAGE_IMPORT_BY_NAME pImpByName1,pImpByName2;
 QWORD t1,t2;
 QWORD *pRVAToFileOffset1,*pRVAToFileOffset2;
 DWORD RVAToBaseAddr1 = RVAToFileOffset(pimgSectTable,NumberOfSections,RVAordnl),
       RVAToBaseAddr2 = RVAToFileOffset(pimgSectTable,NumberOfSections,RVAfsrt);
 if((DWORD)(-1)==RVAToBaseAddr1 || (DWORD)(-1)==RVAToBaseAddr2)
 {AddStrToMultilineEdit(hWnd,L"      Zero RVA of the ordinal pointer...");
  return FALSE;
 }

 pRVAToFileOffset1 = (QWORD*)(lpFileBase + RVAToBaseAddr1);
 pRVAToFileOffset2 = (QWORD*)(lpFileBase + RVAToBaseAddr2);
 while(*pRVAToFileOffset1)
 {if((*pRVAToFileOffset1)!=(*pRVAToFileOffset2))
  {AddStrToMultilineEdit(hWnd,L"      RVA of the ordinal pointer mismatch to second copy(from first chunk pointer)...");
   return FALSE;
  }
  t1 = RVAToFileOffset64(pimgSectTable,NumberOfSections,*pRVAToFileOffset1);
  t2 = RVAToFileOffset64(pimgSectTable,NumberOfSections,*pRVAToFileOffset2);

  if((QWORD)-1==t1 && (QWORD)-1==t1)
  {StringCchPrintfA(s,MAX_PATH,"      %04d              ...",
					*((WORD*)pRVAToFileOffset1));
   AddStrToMultilineEditA(hWnd,s);
   StringCchPrintfA(s,MAX_PATH,"                                                                       %04d              ...",
					*((WORD*)pRVAToFileOffset2));
   AddStrToMultilineEditA(hWnd,s);
   s[0x4b]=0;
   MultiByteToWideChar(CP_ACP,0,&s[0x47],-1,ws,MAX_PATH);
   AddItemToTree(hWndTree,ws,3,3,3,-1);
  }
  else
  {pImpByName1 = (PIMAGE_IMPORT_BY_NAME)(lpFileBase + t1);
   pImpByName2 = (PIMAGE_IMPORT_BY_NAME)(lpFileBase + t2);
   StringCchPrintfA(s,MAX_PATH,"      %04d   %s",
					pImpByName1->Hint,pImpByName1->Name);
   AddStrToMultilineEditA(hWnd,s);
   StringCchPrintfA(s,MAX_PATH,"                                                                       %04d   %s",
					pImpByName2->Hint,pImpByName2->Name);
   AddStrToMultilineEditA(hWnd,s);
   MultiByteToWideChar(CP_ACP,0,pImpByName1->Name,-1,ws,MAX_PATH);
   AddItemToTree(hWndTree,ws,3,3,3,-1);
  }
  ++pRVAToFileOffset1;
  ++pRVAToFileOffset2;
 }
 return TRUE;
}

BOOL IsExeInPEHeader64(char* buffer, unsigned long size)
{
IMAGE_DOS_HEADER* dos_header;
IMAGE_NT_HEADERS64* header;
	char pe_magic[] = "\x50\x45\x00\x00\x64\x86";
	const WORD magic_value = 0x020b;
	// Check whether buffer contains enough bytes to contain a dos header
	if ((long)size < sizeof(IMAGE_DOS_HEADER))
		return FALSE;
	dos_header = (IMAGE_DOS_HEADER*)buffer;
	// Check whether buffer is large enough to contain a PE header
	if ((long)size < dos_header->e_lfanew || (long)size - dos_header->e_lfanew < sizeof(IMAGE_NT_HEADERS64))
		return FALSE;
	header = (IMAGE_NT_HEADERS64*) (buffer + dos_header->e_lfanew);

	// A PE header should start with this sequence (PE00)
	if (memcmp(header, pe_magic, 6))
		return FALSE;
	// Check magic value
	if (header->OptionalHeader.Magic != magic_value)
		return FALSE;

	// Win32 VersionValue should be zero
	if (header->OptionalHeader.Win32VersionValue != 0)
		return FALSE;

	// Check whether subsystem is sane one
	if (header->OptionalHeader.Subsystem != IMAGE_SUBSYSTEM_NATIVE &&
		header->OptionalHeader.Subsystem != IMAGE_SUBSYSTEM_UNKNOWN &&
		header->OptionalHeader.Subsystem != IMAGE_SUBSYSTEM_WINDOWS_GUI &&
		header->OptionalHeader.Subsystem != IMAGE_SUBSYSTEM_WINDOWS_CUI)
		return FALSE;

	if(!(IMAGE_FILE_EXECUTABLE_IMAGE & header->FileHeader.Characteristics))
		return FALSE;
	// Changes are that this is actually a valid PE header
	return TRUE;
}

BOOL IsDLLInPEHeader64(char* buffer, unsigned long size)
{
IMAGE_DOS_HEADER* dos_header;
IMAGE_NT_HEADERS64* header;
char pe_magic[] = "\x50\x45\x00\x00\x64\x86";
const WORD magic_value = 0x020b;

	// Check whether buffer contains enough bytes to contain a dos header
	if ((long)size < sizeof(IMAGE_DOS_HEADER))
		return FALSE;
	dos_header = (IMAGE_DOS_HEADER*) buffer;
	// Check whether buffer is large enough to contain a PE header
	if ((long)size < dos_header->e_lfanew || (long)size - dos_header->e_lfanew < sizeof(IMAGE_NT_HEADERS64))
		return FALSE;
	header = (IMAGE_NT_HEADERS64*) (buffer + dos_header->e_lfanew);

	// A PE header should start with this sequence (PE00)
	if (memcmp(header, pe_magic, 6*sizeof(char)))
		return FALSE;
	// Check magic value
	if (header->OptionalHeader.Magic != magic_value)
		return FALSE;

	// Win32 VersionValue should be zero
	if (header->OptionalHeader.Win32VersionValue != 0)
		return FALSE;

	// Check whether subsystem is sane one
	if (header->OptionalHeader.Subsystem != IMAGE_SUBSYSTEM_NATIVE &&
		header->OptionalHeader.Subsystem != IMAGE_SUBSYSTEM_UNKNOWN &&
		header->OptionalHeader.Subsystem != IMAGE_SUBSYSTEM_WINDOWS_GUI &&
		header->OptionalHeader.Subsystem != IMAGE_SUBSYSTEM_WINDOWS_CUI)
		return FALSE;

	if(!(IMAGE_FILE_DLL & header->FileHeader.Characteristics))
		return FALSE;
	// Changes are that this is actually a valid PE header
	return TRUE;
}

BOOL GetImgOptionalHeader64(PIMAGE_OPTIONAL_HEADER64 pOptlHdr64)
{
wchar_t s[MAX_PATH];

	StringCchPrintf(s,MAX_PATH,L"Magic :                                 0x%04x",pOptlHdr64->Magic);
	AddStrToMultilineEdit(hWndOptionalHeader,s);

	StringCchPrintf(s,MAX_PATH,L"MajorLinkerVersion :           0x%02x",pOptlHdr64->MajorLinkerVersion);
	AddStrToMultilineEdit(hWndOptionalHeader,s);
	
	StringCchPrintf(s,MAX_PATH,L"MinorLinkerVersion :           0x%02x",pOptlHdr64->MinorLinkerVersion);
	AddStrToMultilineEdit(hWndOptionalHeader,s);

	StringCchPrintf(s,MAX_PATH,L"SizeOfCode :                        0x%08x. Size of the code (text) section, or the sum of all code sections if there are multiple sections.",pOptlHdr64->SizeOfCode);
	AddStrToMultilineEdit(hWndOptionalHeader,s);

	StringCchPrintf(s,MAX_PATH,L"SizeOfInitializedData :         0x%08x. Size of the initialized data section, or the sum of all such sections if there are multiple data sections.",pOptlHdr64->SizeOfInitializedData);
	AddStrToMultilineEdit(hWndOptionalHeader,s);

	StringCchPrintf(s,MAX_PATH,L"SizeOfUninitializedData :     0x%08x. Size of the uninitialized data section (BSS), or the sum of all such sections if there are multiple BSS sections.",pOptlHdr64->SizeOfUninitializedData);
	AddStrToMultilineEdit(hWndOptionalHeader,s);

	StringCchPrintf(s,MAX_PATH,L"AddressOfEntryPoint :          0x%08x. Address of entry point, relative to image base, when executable file is loaded into memory. For program images, this is the starting address.",pOptlHdr64->AddressOfEntryPoint);
	AddStrToMultilineEdit(hWndOptionalHeader,s);

	StringCchPrintf(s,MAX_PATH,L"BaseOfCode :                       0x%08x. Address, relative to image base, of beginning of code section, when loaded into memory.",pOptlHdr64->BaseOfCode);
	AddStrToMultilineEdit(hWndOptionalHeader,s);

	StringCchPrintf(s,MAX_PATH,L"ImageBase :                         0x%08x%08x.",*(((DWORD*)&pOptlHdr64->ImageBase)+1),*((DWORD*)&pOptlHdr64->ImageBase));
	AddStrToMultilineEdit(hWndOptionalHeader,s);
	
	StringCchPrintf(s,MAX_PATH,L"SectionAlignment :                0x%08x.",pOptlHdr64->SectionAlignment);
	AddStrToMultilineEdit(hWndOptionalHeader,s);

	StringCchPrintf(s,MAX_PATH,L"FileAlignment :                      0x%08x.",pOptlHdr64->FileAlignment);
	AddStrToMultilineEdit(hWndOptionalHeader,s);

	StringCchPrintf(s,MAX_PATH,L"MajorOperatingSystemVersion : 0x%04x.",pOptlHdr64->MajorOperatingSystemVersion);
	AddStrToMultilineEdit(hWndOptionalHeader,s);

	StringCchPrintf(s,MAX_PATH,L"MinorOperatingSystemVersion : 0x%04x.",pOptlHdr64->MinorOperatingSystemVersion);
	AddStrToMultilineEdit(hWndOptionalHeader,s);

	StringCchPrintf(s,MAX_PATH,L"MajorImageVersion :             0x%04x.",pOptlHdr64->MajorImageVersion);
	AddStrToMultilineEdit(hWndOptionalHeader,s);

	StringCchPrintf(s,MAX_PATH,L"MinorImageVersion :             0x%04x.",pOptlHdr64->MinorImageVersion);
	AddStrToMultilineEdit(hWndOptionalHeader,s);

	StringCchPrintf(s,MAX_PATH,L"MajorSubsystemVersion :     0x%04x.",pOptlHdr64->MajorSubsystemVersion);
	AddStrToMultilineEdit(hWndOptionalHeader,s);

	StringCchPrintf(s,MAX_PATH,L"MinorSubsystemVersion :     0x%04x.",pOptlHdr64->MinorSubsystemVersion);
	AddStrToMultilineEdit(hWndOptionalHeader,s);

	StringCchPrintf(s,MAX_PATH,L"Win32VersionValue :             0x%08x.",pOptlHdr64->Win32VersionValue);
	AddStrToMultilineEdit(hWndOptionalHeader,s);

	StringCchPrintf(s,MAX_PATH,L"SizeOfImage :                        0x%08x.",pOptlHdr64->SizeOfImage);
	AddStrToMultilineEdit(hWndOptionalHeader,s);

	StringCchPrintf(s,MAX_PATH,L"SizeOfHeaders :                     0x%08x.",pOptlHdr64->SizeOfHeaders);
	AddStrToMultilineEdit(hWndOptionalHeader,s);

	StringCchPrintf(s,MAX_PATH,L"CheckSum :                            0x%08x.",pOptlHdr64->CheckSum);
	AddStrToMultilineEdit(hWndOptionalHeader,s);

	StringCchPrintf(s,MAX_PATH,L"Subsystem :                           0x%04x.",pOptlHdr64->Subsystem);
	AddStrToMultilineEdit(hWndOptionalHeader,s);

//Subsystem P32 da ham, P32+ da ham bir xil:
	switch(pOptlHdr64->Subsystem)
	{case IMAGE_SUBSYSTEM_UNKNOWN:
	  AddStrToMultilineEdit(hWndOptionalHeader,L"                                IMAGE_SUBSYSTEM_UNKNOWN");
	 break;
	 case IMAGE_SUBSYSTEM_NATIVE:
		 AddStrToMultilineEdit(hWndOptionalHeader,L"                                IMAGE_SUBSYSTEM_NATIVE : Used for device drivers and native Windows NT processes.");
	 break;
	 case IMAGE_SUBSYSTEM_WINDOWS_GUI:
		 AddStrToMultilineEdit(hWndOptionalHeader,L"                                IMAGE_SUBSYSTEM_WINDOWS_GUI : Image runs in the Windows� graphical user interface (GUI) subsystem.");
	 break;
	 case IMAGE_SUBSYSTEM_WINDOWS_CUI:
		 AddStrToMultilineEdit(hWndOptionalHeader,L"                                IMAGE_SUBSYSTEM_WINDOWS_CUI : Image runs in the Windows character subsystem.");
	 break;
	 case IMAGE_SUBSYSTEM_OS2_CUI: 
		 AddStrToMultilineEdit(hWndOptionalHeader,L"                                IMAGE_SUBSYSTEM_OS2_CUI : Image runs in the OS/2 character subsystem.");
	 break;
	 case IMAGE_SUBSYSTEM_POSIX_CUI: 
		 AddStrToMultilineEdit(hWndOptionalHeader,L"                                IMAGE_SUBSYSTEM_POSIX_CUI : Image runs in the Posix character subsystem.");
	 break;
	 case IMAGE_SUBSYSTEM_NATIVE_WINDOWS:
		 AddStrToMultilineEdit(hWndOptionalHeader,L"                                IMAGE_SUBSYSTEM_NATIVE_WINDOWS : Image is a native Win9x driver.");
	 break;
	 case IMAGE_SUBSYSTEM_WINDOWS_CE_GUI:
		 AddStrToMultilineEdit(hWndOptionalHeader,L"                                IMAGE_SUBSYSTEM_WINDOWS_CE_GUI : Image runs in on Windows CE.");
	 break;
	 case IMAGE_SUBSYSTEM_EFI_APPLICATION:
		 AddStrToMultilineEdit(hWndOptionalHeader,L"                                IMAGE_SUBSYSTEM_EFI_APPLICATION : Image is an EFI application.");
	 break;
	 case IMAGE_SUBSYSTEM_EFI_BOOT_SERVICE_DRIVER:
		 AddStrToMultilineEdit(hWndOptionalHeader,L"                                IMAGE_SUBSYSTEM_EFI_BOOT_SERVICE_DRIVER : Image is an EFI driver that provides boot services.");
	 break;
	 case IMAGE_SUBSYSTEM_EFI_RUNTIME_DRIVER:
		 AddStrToMultilineEdit(hWndOptionalHeader,L"                                IMAGE_SUBSYSTEM_EFI_RUNTIME_DRIVER : Image is an EFI driver that provides runtime services.");
	 break;
	 case IMAGE_SUBSYSTEM_EFI_ROM:
		 AddStrToMultilineEdit(hWndOptionalHeader,L"                                IMAGE_SUBSYSTEM_EFI_ROM");
	 break;
	 case IMAGE_SUBSYSTEM_XBOX:
		 AddStrToMultilineEdit(hWndOptionalHeader,L"                                IMAGE_SUBSYSTEM_XBOX");
	 break;
	}

	StringCchPrintf(s,MAX_PATH,L"DLL Characteristics :              0x%04x.",pOptlHdr64->DllCharacteristics);
	AddStrToMultilineEdit(hWndOptionalHeader,s);

	if(pOptlHdr64->DllCharacteristics & 0x0001)
	  AddStrToMultilineEdit(hWndOptionalHeader,L"                                IMAGE_LIBRARY_PROCESS_INIT : Reserved");
	if(pOptlHdr64->DllCharacteristics & 0x0002)
	  AddStrToMultilineEdit(hWndOptionalHeader,L"                                IMAGE_LIBRARY_PROCESS_TERM : Reserved");
	if(pOptlHdr64->DllCharacteristics & 0x0004)
	  AddStrToMultilineEdit(hWndOptionalHeader,L"                                IMAGE_LIBRARY_THREAD_INIT : Reserved");
	if(pOptlHdr64->DllCharacteristics & 0x0008)
	  AddStrToMultilineEdit(hWndOptionalHeader,L"                                IMAGE_LIBRARY_THREAD_TERM : Reserved");
	if(pOptlHdr64->DllCharacteristics & IMAGE_DLLCHARACTERISTICS_NO_ISOLATION)
	  AddStrToMultilineEdit(hWndOptionalHeader,L"                                IMAGE_DLLCHARACTERISTICS_NO_ISOLATION : Image understands isolation and doesn't want it.");
	if(pOptlHdr64->DllCharacteristics & IMAGE_DLLCHARACTERISTICS_NO_SEH)
	  AddStrToMultilineEdit(hWndOptionalHeader,L"                                IMAGE_DLLCHARACTERISTICS_NO_SEH : Image does not use SEH.  No SE handler may reside in this image.");
	if(pOptlHdr64->DllCharacteristics & IMAGE_DLLCHARACTERISTICS_NO_BIND)
	 AddStrToMultilineEdit(hWndOptionalHeader,L"                                IMAGE_DLLCHARACTERISTICS_NO_BIND : Do not bind image.");
	if(pOptlHdr64->DllCharacteristics & IMAGE_DLLCHARACTERISTICS_WDM_DRIVER)
	 AddStrToMultilineEdit(hWndOptionalHeader,L"                                IMAGE_DLLCHARACTERISTICS_WDM_DRIVER : Driver is a WDM Driver.");
	if(pOptlHdr64->DllCharacteristics & IMAGE_DLLCHARACTERISTICS_TERMINAL_SERVER_AWARE)
	 AddStrToMultilineEdit(hWndOptionalHeader,L"                                IMAGE_DLLCHARACTERISTICS_TERMINAL_SERVER_AWARE : Image is Terminal Server aware.");

	StringCchPrintf(s,MAX_PATH,L"SizeOfStackReserve :             0x%08x%08x.",*(((DWORD*)&pOptlHdr64->SizeOfStackReserve)+1),*((DWORD*)&pOptlHdr64->SizeOfStackReserve));
	AddStrToMultilineEdit(hWndOptionalHeader,s);

	StringCchPrintf(s,MAX_PATH,L"SizeOfStackCommit :              0x%08x%08x.",*(((DWORD*)&pOptlHdr64->SizeOfStackCommit)+1),*((DWORD*)&pOptlHdr64->SizeOfStackCommit));
	AddStrToMultilineEdit(hWndOptionalHeader,s);

	StringCchPrintf(s,MAX_PATH,L"SizeOfHeapReserve :             0x%08x%08x.",*(((DWORD*)&pOptlHdr64->SizeOfHeapReserve)+1),*((DWORD*)&pOptlHdr64->SizeOfHeapReserve));
	AddStrToMultilineEdit(hWndOptionalHeader,s);

	StringCchPrintf(s,MAX_PATH,L"SizeOfHeapCommit :               0x%08x%08x.",*(((DWORD*)&pOptlHdr64->SizeOfHeapCommit)+1),*((DWORD*)&pOptlHdr64->SizeOfHeapCommit));
	AddStrToMultilineEdit(hWndOptionalHeader,s);

	StringCchPrintf(s,MAX_PATH,L"SizeOfHeapReserve :              0x%08x%08x.",*(((DWORD*)&pOptlHdr64->SizeOfHeapReserve)+1),*((DWORD*)&pOptlHdr64->SizeOfHeapReserve));
	AddStrToMultilineEdit(hWndOptionalHeader,s);

	StringCchPrintf(s,MAX_PATH,L"SizeOfHeapCommit :               0x%08x%08x.",*(((DWORD*)&pOptlHdr64->SizeOfHeapCommit)+1),*((DWORD*)&pOptlHdr64->SizeOfHeapCommit));
	AddStrToMultilineEdit(hWndOptionalHeader,s);

	StringCchPrintf(s,MAX_PATH,L"LoaderFlags :                          0x%08x.",pOptlHdr64->LoaderFlags);
	AddStrToMultilineEdit(hWndOptionalHeader,s);
	switch(pOptlHdr64->LoaderFlags)
	{case 1:
	  AddStrToMultilineEdit(hWndOptionalHeader,L"                      1.Invoke a breakpoint instruction before starting the process.");
	 break;
	 case 2:
	  AddStrToMultilineEdit(hWndOptionalHeader,L"                      2.Invoke a debugger on the process after it's been loaded.");
	 break;
	}

	StringCchPrintf(s,MAX_PATH,L"NumberOfRvaAndSizes :        0x%08x.",pOptlHdr64->NumberOfRvaAndSizes);
	AddStrToMultilineEdit(hWndOptionalHeader,s);
	return TRUE;
}