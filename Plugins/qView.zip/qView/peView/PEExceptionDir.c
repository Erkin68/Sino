#include "MyVersion.h"
#include "strsafe.h"
#include "WinNT.h"
#include "commctrl.h"

extern HWND hWndExceptDir;

BOOL GetImgExceptDir()
{
	AddStrToMultilineEdit(hWndExceptDir,L"Exception Directory research in future use...");
	return TRUE;
}
