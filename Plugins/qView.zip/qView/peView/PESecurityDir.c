#include "MyVersion.h"
#include "strsafe.h"
#include "WinNT.h"
#include "commctrl.h"

extern HWND hWndSecurDir;

BOOL GetImgSecurityDir()
{
	AddStrToMultilineEdit(hWndSecurDir,L"Security Directory research in future use...");
	return TRUE;
}
