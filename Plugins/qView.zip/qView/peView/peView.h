#include "windows.h"
#include "commctrl.h"

typedef unsigned char u8;
typedef unsigned __int16 u16;
typedef unsigned __int32 u32;
typedef unsigned __int64 u64;
typedef __int16 s16;
typedef __int64 s64;

extern BOOL bFileLoaded;
extern LPVOID pNextPageTopAddress;
extern int language;
extern unsigned __int64 iFileSize;

extern wchar_t PEFilePathAndName[MAX_PATH];
extern wchar_t PEFilePath[MAX_PATH];
extern int PEFilePathAndNameLn;

extern wchar_t **strngs;
extern HMODULE plgnDllInst;

extern BOOL InitViewer(HWND,wchar_t*);
extern BOOL ChangePEFile(wchar_t*);
extern VOID CloseViewer();

extern LRESULT CALLBACK newPnlWndProc(HWND,UINT,WPARAM,LPARAM);

#pragma once

#include "resource.h"

extern HWND hWndPnl;
extern BOOL PELoadFail,bLoadedFin;

extern LPVOID lpFileBase;
extern HANDLE hFileMapping;
extern HANDLE hFile;

typedef enum TPEType
{	exe=0,
	dll=1
}tPEType;
extern tPEType PEType;

extern HIMAGELIST himl;
extern LPVOID lpFileBase;
typedef unsigned __int64 QWORD;
extern HWND hWndResize,
	 hWndTree,
	 hWndFindFirst,
     hWndGetInfoShort,
     hWndGetInfoFull,
     hWndGetInfoBin,
     hWndImgDosHeader,
  	 hWndPESign,
 	 hWndCOOFFFileHeader,
	 hWndOptionalHeader,
	 hWndDataDirectory,
	 hWndSectionTable,
	 hWndExpDir,
	 hWndImpDir,
	 hWndResDir,
	 hWndExceptDir,
	 hWndSecurDir,
	 hWndBaseRelTable,
	 hWndDbgDir,
	 hWndArchSpecData,
	 hWndRVAtoGP,
	 hWndTLSDir,
	 hWndLoadConfDir,
	 hWndBoundImpDir,
	 hWndIAT,
	 hWndDelayLoadImpDesc,
	 hWndCOMRTDesc;

extern BOOL OnLoadingPEFromMenu(HWND,wchar_t*,wchar_t*);
extern BOOL TryLoadPE(wchar_t*);

extern BOOL GetVersionInfo(wchar_t*);
extern BOOL GetVersionInfoShort(wchar_t*);
extern BOOL GetVersionInfoBin(wchar_t*);
extern BOOL GetFindFirst(wchar_t*);
extern BOOL IsThisValidExeFile(LPVOID);
extern BOOL IsThisValidDllFile(LPVOID);
extern BOOL GetImgDosHeader();
extern BOOL GetImgCOFFFileHeader();
extern BOOL GetImgPESignature();
extern BOOL GetImgOptionalHeader();
extern BOOL GetImgDataDirectory(BOOL*);
extern BOOL GetImgSectionTable();
extern BOOL GetImgExpDir();
extern BOOL GetImgImpDir();
extern BOOL GetImgResDir();
extern BOOL GetImgBaseRelTable();
extern BOOL GetImgDbgDir();
extern BOOL GetImgLoadConfDir();
extern BOOL GetImgIAT();
extern BOOL GetImgExceptDir();
extern BOOL GetImgSecurityDir();
extern BOOL GetMSDOSStubAddr(HWND);
extern BOOL GetCOFFHdrAddr(HWND);
extern BOOL GetOptHdrAddr(HWND);
extern BOOL GetDataDirAddr(HWND);
extern BOOL GetSectnTblAddr(HWND);
extern BOOL GetExprtDirAddr(HWND);
extern BOOL GetImprtDirAddr(HWND);
extern BOOL GetResDirAddr(HWND);
extern BOOL GetExcptnDirAddr(HWND);
extern BOOL GetSecurDirAddr(HWND);
extern BOOL GetBaseRelTblAddr(HWND);
extern BOOL GetDbgDirAddr(HWND);
extern BOOL GetArchSpecDatAddr(HWND);
extern BOOL GetRVAToGPAddr(HWND);
extern BOOL GetTLSDirAddr(HWND);
extern BOOL GetLoadConfDirAddr(HWND);
extern BOOL GetBoundImpDirAddr(HWND);
extern BOOL GetIATDirAddr(HWND);
extern BOOL GetDelayLoadImpDescAddr(HWND);
extern BOOL GetRTDescAddr(HWND);


extern BOOL DrawResItem(int);//>>ZOrder
extern BOOL CreateControls(HWND);
