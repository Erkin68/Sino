#pragma comment(lib, "Version.lib")

#include "MyVersion.h"
#include "strsafe.h"


extern HWND hWndFindFirst,hWndGetInfoShort,hWndGetInfoBin;
//ispytaniyedan o'tsa, Shellga tiqaman:

WIN32_FIND_DATA ff;


int OutputVarValueShort(void* pBgn,int ln,wchar_t* padSpaceLeft)
{void *p,*pe,*pbgn=pBgn,*pend=(void*)(((char*)pbgn)+ln);DWORD *pv,*pVarValue;int l=0,l1;WCHAR* pVarszKey;
	while(pbgn<pend && l<ln)
	{	Var* pvar=(Var*)pbgn;
		//AddStrToMultilineEditStr2Int(hWndGetInfoShort,padSpaceLeft,L"    wLength          : ",pvar->wLength,L" bytes;");
		//AddStrToMultilineEditStr2Int(hWndGetInfoShort,padSpaceLeft,L"    wValueLength          : ",pvar->wValueLength,L" bytes;");
		//AddStrToMultilineEditStr2Int1(hWndGetInfoShort,padSpaceLeft,L"    wType          : ",pvar->wType);
		pVarszKey = (WCHAR*)(((char*)pvar)+3*sizeof(WORD));
		//AddStrToMultilineEdit3(hWndGetInfoShort,padSpaceLeft,L"               ",pVarszKey,L"");
		if(0!=wcscmp(pVarszKey,L"Translation"))
		{	AddStrToMultilineEdit(hWndGetInfoShort,L"    Err. openng \"Var\" values: ");
			return 0;
		}
		p = (void*)(pVarszKey + wcslen(pVarszKey)+1);
		pVarValue=CorrectPadding(p,pvar,32);
		pv = pVarValue;
		pe=pVarValue+pvar->wLength-(int)(((char*)p)-((char*)pvar));
		while(pv<(DWORD*)pe)
		{	//AddStrToMultilineEditHex2Str4x2(hWndGetInfoShort,L"    Microsoft language identifier: ",LOWORD(pv),
			//						 L"; IBM� code page number: ",HIWORD(pv));
			pv++;
		}
		l1 = (int)(((char*)pv)-((char*)pbgn));
		pbgn = (void*)(((char*)pbgn) + l1);
		l += l1;
	}
	return l;//(int)(pbgn-pBgn);
}

int OutputStringShort(void* pStr,wchar_t* padSpaceLeft)
{int l=0;void* p;String *pstr=(String*)pStr;WCHAR* StringszKey;
	//AddStrToMultilineEditStr2Int(hWndGetInfoShort,padSpaceLeft,L"    wLength          : ",pstr->wLength,L" bytes;");
	//AddStrToMultilineEditStr2Int(hWndGetInfoShort,padSpaceLeft,L"    wValueLength          : ",pstr->wValueLength,L" bytes;");
	//AddStrToMultilineEditStr2Int1(hWndGetInfoShort,padSpaceLeft,L"    wType          : ",pstr->wType);
	StringszKey = (WCHAR*)(((char*)pstr)+3*sizeof(WORD));
	AddStrToMultilineEdit(hWndGetInfoShort,StringszKey);
	p = ((wchar_t*)StringszKey + wcslen(StringszKey)+1);
	p=CorrectPadding(p,pStr,32);
	AddStrToMultilineEdit1(hWndGetInfoShort,L"                             ",p);
	l = (int)wcslen(p)+1;
	p = (void*)(((wchar_t*)p)+l);
	l = (int)(((char*)p)-((char*)pStr));
	return l;
}

int OutputStringTableShort(void* pBgn,int ln,wchar_t* padSpaceLeft)
{void *p,*pe,*pbgn=pBgn,*pend=(void*)(((char*)pbgn)+ln);wchar_t *pv;int l=0,l1;
 WCHAR *StringTableszKey;String *StringChildren;
	while(pbgn<pend && l<ln)
	{	StringTable* pStringTable=(StringTable*)pbgn;
		//AddStrToMultilineEditStr2Int(hWndGetInfoShort,padSpaceLeft,L"    wLength          : ",pStringTable->wLength,L" bytes;");
		//AddStrToMultilineEditStr2Int(hWndGetInfoShort,padSpaceLeft,L"    wValueLength          : ",pStringTable->wValueLength,L" bytes;");
		//AddStrToMultilineEditStr2Int1(hWndGetInfoShort,padSpaceLeft,L"    wType          : ",pStringTable->wType);
		StringTableszKey = (WCHAR*)(((char*)pStringTable)+3*sizeof(WORD));
		//AddStrToMultilineEdit2(hWndGetInfoShort,padSpaceLeft,L"",StringTableszKey);
		//AddStrToMultilineEditHex2Str(hWndGetInfoShort,L"    Language identifier[1]: major: ",StringTableszKey[0]&0x3ff,L" minor: ",(StringTableszKey[0]&0xfc00)>>10);
		//AddStrToMultilineEditHex2Str(hWndGetInfoShort,L"    Language identifier[2]: major: ",StringTableszKey[1]&0x3ff,L" minor: ",(StringTableszKey[1]&0xfc00)>>10);
		//AddStrToMultilineEditHex2Str(hWndGetInfoShort,L"    Language identifier[3]: major: ",StringTableszKey[2]&0x3ff,L" minor: ",(StringTableszKey[2]&0xfc00)>>10);
		//AddStrToMultilineEditHex2Str(hWndGetInfoShort,L"    Language identifier[4]: major: ",StringTableszKey[3]&0x3ff,L" minor: ",(StringTableszKey[3]&0xfc00)>>10);
		//AddStrToMultilineEditHex(hWndGetInfoShort,L"    Code page[1]: ",StringTableszKey[4]);
		//AddStrToMultilineEditHex(hWndGetInfoShort,L"    Code page[2]: ",StringTableszKey[5]);
		//AddStrToMultilineEditHex(hWndGetInfoShort,L"    Code page[3]: ",StringTableszKey[6]);
		//AddStrToMultilineEditHex(hWndGetInfoShort,L"    Code page[4]: ",StringTableszKey[7]);
		p = (void*)(StringTableszKey + 8);//wcslen(&pStringTable->szKey[0])+1);
		StringChildren=CorrectPadding(p,pStringTable,32);
		pv = (wchar_t*)StringChildren;
		pe=((char*)StringChildren)+pStringTable->wLength-(int)(((char*)p)-((char*)pStringTable));
		while(pv<(wchar_t*)pe && pv<(wchar_t*)pend)
		{	wchar_t *pp = (wchar_t*)(((char*)pv)+OutputStringShort(pv,padSpaceLeft));
			pv = CorrectPadding(pp,pv,32);
		}
		l1 = (int)(((char*)pv)-((char*)pbgn));
		pbgn = (void*)(((char*)pbgn) + l1);
		l += l1;
	}
	return l;//(int)(pbgn-pBgn);
}

BOOL GetVersionInfoShort(wchar_t *fileName)
{
DWORD visz;
VS_VERSIONINFO *pvi;
int sz,v,pviLengthPtr;
VS_FIXEDFILEINFO *VS_VERSIONINFOValue;
StringFileInfo *VS_VERSIONINFOChildren;
StringTable *pstringFileInfoChildren;
VarFileInfo* pvarFileInfo;
wchar_t *vi=NULL;void *p;

	sz = GetFileVersionInfoSize(fileName, &visz);
	if(0==sz)
	{	//MessageBox(NULL,fileName,L"GetVersionInfoShort: GetFileVersionInfoSize failed.",MB_OK);
		if(vi)free(vi);
		return FALSE;
	}
	vi = (wchar_t*)malloc(2*sz); vi[0] = '\0';//Win7 uchun 2* qo'ydim;
	if(!vi)
	{	MessageBox(NULL,fileName,L"malloc for GetFileVersionInfo failed.",MB_OK);
		if(vi)free(vi);
		return FALSE;
	}
	pvi=(VS_VERSIONINFO*)vi;

	if(!GetFileVersionInfo(fileName, 0, sz, vi))
	{	MessageBox(NULL,fileName,L"GetFileVersionInfo failed.",MB_OK);
		if(vi)free(vi);
		return FALSE;
	}

	p = (void*)(&pvi->szKey[0] + wcslen(&pvi->szKey[0])+1);
	VS_VERSIONINFOValue=(VS_FIXEDFILEINFO*)CorrectPadding(p,pvi,32);
	p = (void*)((char*)VS_VERSIONINFOValue+sizeof(VS_FIXEDFILEINFO));
	VS_VERSIONINFOChildren=CorrectPadding(p,pvi,32);

	//AddStrToMultilineEdit(hWndGetInfoShort,L"VS_VERSIONINFO :");
	//AddStrToMultilineEdit(hWndGetInfoShort,L"");
	//AddStrToMultilineEditInt(hWndGetInfoShort,L"    wLength          : ",pvi->wLength,L" bytes;");
	//AddStrToMultilineEditInt(hWndGetInfoShort,L"    wValueLength : ",pvi->wValueLength,L" bytes;");
	//AddStrToMultilineEditInt(hWndGetInfoShort,L"    wType             : ",pvi->wType,L" ;");
	//AddStrToMultilineEdit2(hWndGetInfoShort,L"    szKey             : \"",pvi->szKey,L"\"");
	//AddStrToMultilineEdit(hWndGetInfoShort,L"");

	//AddStrToMultilineEdit(hWndGetInfoShort,L"    VS_FIXEDFILEINFO:");
	//AddStrToMultilineEdit(hWndGetInfoShort,L"");
	//AddStrToMultilineEditHex(hWndGetInfoShort,L"    dwSignature               : ",VS_VERSIONINFOValue->dwSignature);
	//AddStrToMultilineEditHex3Str2(hWndGetInfoShort,L"    dwStrucVersion          : ",VS_VERSIONINFOValue->dwStrucVersion,
	//							  L";    Major version: ",HIWORD(VS_VERSIONINFOValue->dwStrucVersion),
	//							  L"  Minor version: ",LOWORD(VS_VERSIONINFOValue->dwStrucVersion));
	//AddStrToMultilineEditHex(hWndGetInfoShort,L"    dwFileVersionMS       : ",VS_VERSIONINFOValue->dwFileVersionMS);
	//AddStrToMultilineEditHex(hWndGetInfoShort,L"    dwFileVersionLS        : ",VS_VERSIONINFOValue->dwFileVersionLS);
	//AddStrToMultilineEditHex(hWndGetInfoShort,L"    dwProductVersionMS : ",VS_VERSIONINFOValue->dwProductVersionMS);
	//AddStrToMultilineEditHex(hWndGetInfoShort,L"    dwProductVersionLS  : ",VS_VERSIONINFOValue->dwProductVersionLS);
	//AddStrToMultilineEditHex(hWndGetInfoShort,L"    dwFileFlagsMask       : ",VS_VERSIONINFOValue->dwFileFlagsMask);
	//AddStrToMultilineEditHex(hWndGetInfoShort,L"    dwFileFlags                : ",VS_VERSIONINFOValue->dwFileFlags);
	//if(VS_FF_DEBUG & VS_VERSIONINFOValue->dwFileFlags)
	//	AddStrToMultilineEdit(hWndGetInfoShort,L"            VS_FF_DEBUG");
	//if(VS_FF_INFOINFERRED & VS_VERSIONINFOValue->dwFileFlags)
	//	AddStrToMultilineEdit(hWndGetInfoShort,L"            VS_FF_INFOINFERRED");
	//if(VS_FF_PATCHED & VS_VERSIONINFOValue->dwFileFlags)
	//	AddStrToMultilineEdit(hWndGetInfoShort,L"            VS_FF_PATCHED");
	//if(VS_FF_PRERELEASE & VS_VERSIONINFOValue->dwFileFlags)
	//	AddStrToMultilineEdit(hWndGetInfoShort,L"            VS_FF_PRERELEASE");
	//if(VS_FF_PRIVATEBUILD & VS_VERSIONINFOValue->dwFileFlags)
	//	AddStrToMultilineEdit(hWndGetInfoShort,L"            VS_FF_PRIVATEBUILD");
	//if(VS_FF_SPECIALBUILD & VS_VERSIONINFOValue->dwFileFlags)
	//	AddStrToMultilineEdit(hWndGetInfoShort,L"            VS_FF_SPECIALBUILD");

	//AddStrToMultilineEditHex(hWndGetInfoShort,L"    dwFileOS                    : ",VS_VERSIONINFOValue->dwFileOS);
	//if(VOS_DOS==VS_VERSIONINFOValue->dwFileOS)
	//	AddStrToMultilineEdit(hWndGetInfoShort,L"            VOS_DOS");
	//else if(VOS_NT==VS_VERSIONINFOValue->dwFileOS)
	//	AddStrToMultilineEdit(hWndGetInfoShort,L"            VOS_NT");
	//else if(VOS__WINDOWS16==VS_VERSIONINFOValue->dwFileOS)
	//	AddStrToMultilineEdit(hWndGetInfoShort,L"            VOS__WINDOWS16");
	//else if(VOS__WINDOWS32==VS_VERSIONINFOValue->dwFileOS)
	//	AddStrToMultilineEdit(hWndGetInfoShort,L"            VOS__WINDOWS32");
	//else if(VOS_OS216==VS_VERSIONINFOValue->dwFileOS)
	//	AddStrToMultilineEdit(hWndGetInfoShort,L"            VOS_OS216");
	//else if(VOS_OS232==VS_VERSIONINFOValue->dwFileOS)
	//	AddStrToMultilineEdit(hWndGetInfoShort,L"            VOS_OS232");
	//else if(VOS__PM16==VS_VERSIONINFOValue->dwFileOS)
	//	AddStrToMultilineEdit(hWndGetInfoShort,L"            VOS__PM16");
	//else if(VOS__PM32==VS_VERSIONINFOValue->dwFileOS)
	//	AddStrToMultilineEdit(hWndGetInfoShort,L"            VOS__PM32");
	//else if(VOS_UNKNOWN==VS_VERSIONINFOValue->dwFileOS)
	//	AddStrToMultilineEdit(hWndGetInfoShort,L"            VOS_UNKNOWN");
	//else if(VOS_DOS_WINDOWS16==VS_VERSIONINFOValue->dwFileOS)
	//	AddStrToMultilineEdit(hWndGetInfoShort,L"            VOS_DOS_WINDOWS16");
	//else if(VOS_DOS_WINDOWS32==VS_VERSIONINFOValue->dwFileOS)
	//	AddStrToMultilineEdit(hWndGetInfoShort,L"            VOS_DOS_WINDOWS32");
	//else if(VOS_NT_WINDOWS32==VS_VERSIONINFOValue->dwFileOS)
	//	AddStrToMultilineEdit(hWndGetInfoShort,L"            VOS_NT_WINDOWS32");
	//else if(VOS_OS216_PM16==VS_VERSIONINFOValue->dwFileOS)
	//	AddStrToMultilineEdit(hWndGetInfoShort,L"            VOS_OS216_PM16");
	//else if(VOS_OS232_PM32==VS_VERSIONINFOValue->dwFileOS)
	//	AddStrToMultilineEdit(hWndGetInfoShort,L"            VOS_OS232_PM32");

	//AddStrToMultilineEditHex(hWndGetInfoShort,L"    dwFileType                 : ",VS_VERSIONINFOValue->dwFileType);
	//if(VFT_UNKNOWN==VS_VERSIONINFOValue->dwFileType)
	//	AddStrToMultilineEdit(hWndGetInfoShort,L"            VFT_UNKNOWN");
	//else if(VFT_APP==VS_VERSIONINFOValue->dwFileType)
	//	AddStrToMultilineEdit(hWndGetInfoShort,L"            VFT_APP");
	//else if(VFT_DLL==VS_VERSIONINFOValue->dwFileType)
	//	AddStrToMultilineEdit(hWndGetInfoShort,L"            VFT_DLL");
	//else if(VFT_DRV==VS_VERSIONINFOValue->dwFileType)
	//	AddStrToMultilineEdit(hWndGetInfoShort,L"            VFT_DRV");
	//else if(VFT_FONT==VS_VERSIONINFOValue->dwFileType)
	//	AddStrToMultilineEdit(hWndGetInfoShort,L"            VFT_FONT");
	//else if(VFT_VXD==VS_VERSIONINFOValue->dwFileType)
	//	AddStrToMultilineEdit(hWndGetInfoShort,L"            VFT_VXD");
	//else if(VFT_STATIC_LIB==VS_VERSIONINFOValue->dwFileType)
	//	AddStrToMultilineEdit(hWndGetInfoShort,L"            VFT_STATIC_LIB");

	//AddStrToMultilineEditHex(hWndGetInfoShort,L"    dwFileSubtype            : ",VS_VERSIONINFOValue->dwFileSubtype);
	/*if(VFT_DRV==VS_VERSIONINFOValue->dwFileType)
	{if(VFT2_UNKNOWN==VS_VERSIONINFOValue->dwFileSubtype)
		AddStrToMultilineEdit(hWndGetInfoShort,L"            VFT2_UNKNOWN");
	 else if(VFT2_DRV_COMM==VS_VERSIONINFOValue->dwFileSubtype)
		AddStrToMultilineEdit(hWndGetInfoShort,L"            VFT2_DRV_COMM");
	 else if(VFT2_DRV_PRINTER==VS_VERSIONINFOValue->dwFileSubtype)
		AddStrToMultilineEdit(hWndGetInfoShort,L"            VFT2_DRV_PRINTER");
	 else if(VFT2_DRV_KEYBOARD==VS_VERSIONINFOValue->dwFileSubtype)
		AddStrToMultilineEdit(hWndGetInfoShort,L"            VFT2_DRV_KEYBOARD");
	 else if(VFT2_DRV_LANGUAGE==VS_VERSIONINFOValue->dwFileSubtype)
		AddStrToMultilineEdit(hWndGetInfoShort,L"            VFT2_DRV_LANGUAGE");
	 else if(VFT2_DRV_DISPLAY==VS_VERSIONINFOValue->dwFileSubtype)
		AddStrToMultilineEdit(hWndGetInfoShort,L"            VFT2_DRV_DISPLAY");
	 else if(VFT2_DRV_MOUSE==VS_VERSIONINFOValue->dwFileSubtype)
		AddStrToMultilineEdit(hWndGetInfoShort,L"            VFT2_DRV_MOUSE");
	 else if(VFT2_DRV_NETWORK==VS_VERSIONINFOValue->dwFileSubtype)
		AddStrToMultilineEdit(hWndGetInfoShort,L"            VFT2_DRV_NETWORK");
	 else if(VFT2_DRV_SYSTEM==VS_VERSIONINFOValue->dwFileSubtype)
		AddStrToMultilineEdit(hWndGetInfoShort,L"            VFT2_DRV_SYSTEM");
	 else if(VFT2_DRV_INSTALLABLE==VS_VERSIONINFOValue->dwFileSubtype)
		AddStrToMultilineEdit(hWndGetInfoShort,L"            VFT2_DRV_INSTALLABLE");
	 else if(VFT2_DRV_SOUND==VS_VERSIONINFOValue->dwFileSubtype)
		AddStrToMultilineEdit(hWndGetInfoShort,L"            VFT2_DRV_SOUND");
	}else if(VFT_FONT==VS_VERSIONINFOValue->dwFileType)
	{	if(VFT2_UNKNOWN==VS_VERSIONINFOValue->dwFileSubtype)
			AddStrToMultilineEdit(hWndGetInfoShort,L"            VFT2_UNKNOWN");
		else if(VFT2_UNKNOWN==VS_VERSIONINFOValue->dwFileSubtype)
			AddStrToMultilineEdit(hWndGetInfoShort,L"            VFT2_FONT_RASTER");
		else if(VFT2_FONT_VECTOR==VS_VERSIONINFOValue->dwFileSubtype)
			AddStrToMultilineEdit(hWndGetInfoShort,L"            VFT2_FONT_VECTOR");
		else if(VFT2_FONT_TRUETYPE==VS_VERSIONINFOValue->dwFileSubtype)
			AddStrToMultilineEdit(hWndGetInfoShort,L"            VFT2_FONT_TRUETYPE");
	}*/

	//AddStrToMultilineEditHex(hWndGetInfoShort,L"    dwFileDateMS            : ",VS_VERSIONINFOValue->dwFileDateMS);
	//AddStrToMultilineEditHex(hWndGetInfoShort,L"    dwFileDateLS             : ",VS_VERSIONINFOValue->dwFileDateLS);
	
	//AddStrToMultilineEdit(hWndGetInfoShort,L"");
	pviLengthPtr=(int)(((char*)VS_VERSIONINFOChildren) - ((char*)pvi));
	for(v=0; v<2; ++v)//Specifies the length, in bytes, of the VS_VERSIONINFO structure. This length does not include any padding that aligns any subsequent version resource data on a 32-bit boundary.
	{int ln;
	 if(0==_wcsnicmp(VS_VERSIONINFOChildren->szKey,L"StringFileInfo",14))
	 {	//AddStrToMultilineEdit(hWndGetInfoShort,L"    Consist from \"StringFileInfo\" structure:");
		//AddStrToMultilineEditInt(hWndGetInfoShort,L"    wLength          : ",VS_VERSIONINFOChildren->wLength,L" bytes;");
		//AddStrToMultilineEditInt(hWndGetInfoShort,L"    wValueLength           : ",VS_VERSIONINFOChildren->wValueLength,L" bytes;");
		//AddStrToMultilineEditInt(hWndGetInfoShort,L"    wType           : ",VS_VERSIONINFOChildren->wType,L" ;");
		//AddStrToMultilineEdit2(hWndGetInfoShort,L"    szKey             : \"",VS_VERSIONINFOChildren->szKey,L"\"");
		if(0!=wcscmp(VS_VERSIONINFOChildren->szKey,L"StringFileInfo"))
		{ AddStrToMultilineEdit(hWndGetInfoShort,L"    Error \"StringFileInfo\" structure decompressing...");
		  return FALSE;
		}
		p = (void*)(&VS_VERSIONINFOChildren->szKey[0] + wcslen(&VS_VERSIONINFOChildren->szKey[0])+1);
		pstringFileInfoChildren=CorrectPadding(p,VS_VERSIONINFOChildren,32);
		ln = (int)(((char*)pstringFileInfoChildren)-((char*)VS_VERSIONINFOChildren));
		if(ln<VS_VERSIONINFOChildren->wLength)
		{	ln+=OutputStringTableShort(pstringFileInfoChildren,VS_VERSIONINFOChildren->wLength-ln,L"      ");
	 }	}
	 else
	 {	WCHAR *pvarFileInfoszKey = (WCHAR*)(((char*)VS_VERSIONINFOChildren)+3*sizeof(WORD));
		Var *pvarFileInfoChildren;
		//AddStrToMultilineEdit(hWndGetInfoShort,L"    Consist from \"VarFileInfo\" structure:");
		pvarFileInfo = (VarFileInfo*)VS_VERSIONINFOChildren;
		//AddStrToMultilineEditInt(hWndGetInfoShort,L"    wLength          : ",pvarFileInfo->wLength,L" bytes;");
		//AddStrToMultilineEditInt(hWndGetInfoShort,L"    wValueLength : ",pvarFileInfo->wValueLength,L" bytes;");
		//AddStrToMultilineEditInt(hWndGetInfoShort,L"    wType             : ",pvarFileInfo->wType,L" ;");
		//AddStrToMultilineEdit2(hWndGetInfoShort,L"    szKey             : \"",pvarFileInfoszKey,L"\"");
		p = (void*)(pvarFileInfoszKey + wcslen(pvarFileInfoszKey)+1);
		pvarFileInfoChildren=CorrectPadding(p,pvarFileInfo,32);
		ln = (int)(((char*)pvarFileInfoChildren)-((char*)pvarFileInfo));
		if(ln<pvarFileInfo->wLength)
		{	ln+=OutputVarValueShort(pvarFileInfoChildren,pvarFileInfo->wLength-ln,L"      ");
	 }	}
	 pviLengthPtr+=ln;
	 if(pviLengthPtr>pvi->wLength-1)break;//if(ln>VS_VERSIONINFOChildren->wLength-1)break;
	 VS_VERSIONINFOChildren = (StringFileInfo*)((char*)VS_VERSIONINFOChildren+ln);
	}
	AddStrToMultilineEdit(hWndGetInfoShort,L"");

	free(vi);
	return TRUE;
}

BOOL GetVersionInfoBin(wchar_t *fileName)
{
DWORD sz,visz;
wchar_t *vi=NULL;char *pvi,*pviend;

	sz = GetFileVersionInfoSize(fileName, &visz);
	if(0==sz)
	{	//MessageBox(NULL,fileName,L"GetVersionInfoBin: GetFileVersionInfoSize failed.",MB_OK);
		if(vi)free(vi);
		return FALSE;
	}
	vi = (wchar_t*)malloc(2*sz); vi[0] = '\0';//Win7 uchun 2* qo'ydim;
	if(!vi)
	{	MessageBox(NULL,fileName,L"malloc for GetFileVersionInfo failed.",MB_OK);
		if(vi)free(vi);
		return FALSE;
	}
	ZeroMemory(vi,sz);

	if(!GetFileVersionInfo(fileName, 0, sz, vi))
	{	MessageBox(NULL,fileName,L"GetFileVersionInfo failed.",MB_OK);
		if(vi)free(vi);
		return FALSE;
	}

	pvi=(char*)vi;pviend=pvi+sz;
	while(pvi<pviend)
	{int k;wchar_t s[MAX_PATH],*ps=&s[0];
     //StringCchPrintf(s,16,L"%08d ",(int)(pvi-((char*)vi)));
	 for(k=0; k<32; ++k)
	 {if(pvi>pviend)break;
	  StringCchPrintf(ps,16,0==k?L"%02x":L" %02x",*pvi);
	  ++pvi;
	  ps += (0==k?2:3);
	 }
	 *ps=0;
	 AddStrToMultilineEdit(hWndGetInfoBin,s);
	}
	free(vi);
	return TRUE;
}

BOOL GetFindFirst(wchar_t* name)
{
wchar_t s[MAX_PATH];SYSTEMTIME st;HANDLE h;
 ZeroMemory(&ff,sizeof(ff));
 h=FindFirstFile(name,&ff);
 if(INVALID_HANDLE_VALUE==h)
 {AddStrToMultilineEdit(hWndFindFirst,L"FindFirstFile returned \"INVALID_HANDLE_VALUE\".");
  return FALSE;
 }
 AddStrToMultilineEdit(hWndFindFirst,L"dwFileAttributes:");
 StringCchPrintf(s,MAX_PATH,L"                               %x",ff.dwFileAttributes);
 AddStrToMultilineEdit(hWndFindFirst,s);
 if(FILE_ATTRIBUTE_ARCHIVE & ff.dwFileAttributes)
	AddStrToMultilineEdit(hWndFindFirst,L"                                      FILE_ATTRIBUTE_ARCHIVE");
 if(FILE_ATTRIBUTE_COMPRESSED & ff.dwFileAttributes)
	AddStrToMultilineEdit(hWndFindFirst,L"                                      FILE_ATTRIBUTE_COMPRESSED");
 if(FILE_ATTRIBUTE_DIRECTORY & ff.dwFileAttributes)
	AddStrToMultilineEdit(hWndFindFirst,L"                                      FILE_ATTRIBUTE_DIRECTORY");
 if(FILE_ATTRIBUTE_ENCRYPTED & ff.dwFileAttributes)
	AddStrToMultilineEdit(hWndFindFirst,L"                                      FILE_ATTRIBUTE_ENCRYPTED");
 if(FILE_ATTRIBUTE_HIDDEN & ff.dwFileAttributes)
	AddStrToMultilineEdit(hWndFindFirst,L"                                      FILE_ATTRIBUTE_HIDDEN");
 if(FILE_ATTRIBUTE_NORMAL & ff.dwFileAttributes)
	AddStrToMultilineEdit(hWndFindFirst,L"                                      FILE_ATTRIBUTE_NORMAL");
 if(FILE_ATTRIBUTE_OFFLINE & ff.dwFileAttributes)
	AddStrToMultilineEdit(hWndFindFirst,L"                                      FILE_ATTRIBUTE_OFFLINE");
 if(FILE_ATTRIBUTE_READONLY & ff.dwFileAttributes)
	AddStrToMultilineEdit(hWndFindFirst,L"                                      FILE_ATTRIBUTE_READONLY");
 if(FILE_ATTRIBUTE_REPARSE_POINT & ff.dwFileAttributes)
	AddStrToMultilineEdit(hWndFindFirst,L"                                      FILE_ATTRIBUTE_REPARSE_POINT");
 if(FILE_ATTRIBUTE_SPARSE_FILE & ff.dwFileAttributes)
	AddStrToMultilineEdit(hWndFindFirst,L"                                      FILE_ATTRIBUTE_SPARSE_FILE");
 if(FILE_ATTRIBUTE_SYSTEM & ff.dwFileAttributes)
	AddStrToMultilineEdit(hWndFindFirst,L"                                      FILE_ATTRIBUTE_SYSTEM");
 if(FILE_ATTRIBUTE_TEMPORARY & ff.dwFileAttributes)
	AddStrToMultilineEdit(hWndFindFirst,L"                                      FILE_ATTRIBUTE_TEMPORARY");


 if(FileTimeToSystemTime(&ff.ftCreationTime,&st))
 {AddStrToMultilineEdit(hWndFindFirst,L"ftCreationTime:");
  StringCchPrintf(s,MAX_PATH,L"                               %02d%s%02d%s%04d   %02d%s%02d%s%02d%s%03d",
						st.wDay,L".",st.wMonth,L".",st.wYear,
						st.wHour,L":",st.wMinute,L":",st.wSecond,L":",st.wMilliseconds);
  AddStrToMultilineEdit(hWndFindFirst,s);
 }

 if(FileTimeToSystemTime(&ff.ftLastAccessTime,&st))
 {AddStrToMultilineEdit(hWndFindFirst,L"ftLastAccessTime:");
  StringCchPrintf(s,MAX_PATH,L"                               %02d%s%02d%s%04d   %02d%s%02d%s%02d%s%03d",
						st.wDay,L".",st.wMonth,L".",st.wYear,
						st.wHour,L":",st.wMinute,L":",st.wSecond,L":",st.wMilliseconds);
  AddStrToMultilineEdit(hWndFindFirst,s);
 }

 if(FileTimeToSystemTime(&ff.ftLastWriteTime,&st))
 {AddStrToMultilineEdit(hWndFindFirst,L"ftLastWriteTime:");
  StringCchPrintf(s,MAX_PATH,L"                               %02d%s%02d%s%04d   %02d%s%02d%s%02d%s%03d",
						st.wDay,L".",st.wMonth,L".",st.wYear,
						st.wHour,L":",st.wMinute,L":",st.wSecond,L":",st.wMilliseconds);
  AddStrToMultilineEdit(hWndFindFirst,s);
 }

 AddStrToMultilineEdit(hWndFindFirst,L"nFileSizeHigh:");
 StringCchPrintf(s,MAX_PATH,L"                               %d",ff.nFileSizeHigh);
 AddStrToMultilineEdit(hWndFindFirst,s);
 AddStrToMultilineEdit(hWndFindFirst,L"nFileSizeLow:");
 StringCchPrintf(s,MAX_PATH,L"                               %d",ff.nFileSizeLow);
 AddStrToMultilineEdit(hWndFindFirst,s);

 AddStrToMultilineEdit(hWndFindFirst,L"dwReserved0:");
 StringCchPrintf(s,MAX_PATH,L"                               %s%08x",L"0x",ff.dwReserved0);
 AddStrToMultilineEdit(hWndFindFirst,s);

 AddStrToMultilineEdit(hWndFindFirst,L"dwReserved1:");
 StringCchPrintf(s,MAX_PATH,L"                               %s%08x",L"0x",ff.dwReserved1);
 AddStrToMultilineEdit(hWndFindFirst,s);

 AddStrToMultilineEdit(hWndFindFirst,L"cFileName:");
 AddStrToMultilineEdit1(hWndFindFirst,L"                              ",ff.cFileName);

 AddStrToMultilineEdit(hWndFindFirst,L"cAlternateFileName:");
 AddStrToMultilineEdit1(hWndFindFirst,L"                              ",ff.cAlternateFileName);

 FindClose(h);
 return TRUE;
}
