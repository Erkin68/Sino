#pragma comment(lib, "Version.lib")

#include "MyVersion.h"
#include "strsafe.h"

//ispytaniyedan o'tsa, Shellga tiqaman:

wchar_t RetCar[3]={0x0d,0x0a,0x00};
VOID AddStrToMultilineEdit(HWND hWndEdt,wchar_t *str)
{	SendMessage(hWndEdt,EM_REPLACESEL, (WPARAM)FALSE, (LPARAM)str);
	SendMessage(hWndEdt,EM_REPLACESEL, (WPARAM)FALSE, (LPARAM)RetCar);
	SendMessage(hWndEdt,EM_SCROLLCARET,(WPARAM)0, (LPARAM)0);
}VOID AddStrToMultilineEdit1(HWND hWndEdt,wchar_t *str,wchar_t *str1)
{	SendMessage(hWndEdt,EM_REPLACESEL, (WPARAM)FALSE, (LPARAM)str);
	SendMessage(hWndEdt,EM_REPLACESEL, (WPARAM)FALSE, (LPARAM)L" ");
	SendMessage(hWndEdt,EM_REPLACESEL, (WPARAM)FALSE, (LPARAM)str1);
	SendMessage(hWndEdt,EM_REPLACESEL, (WPARAM)FALSE, (LPARAM)RetCar);
	SendMessage(hWndEdt,EM_SCROLLCARET,(WPARAM)0, (LPARAM)0);
}VOID AddStrToMultilineEdit2(HWND hWndEdt,wchar_t *str,wchar_t *str1,wchar_t *str2)
{	SendMessage(hWndEdt,EM_REPLACESEL, (WPARAM)FALSE, (LPARAM)str);
	SendMessage(hWndEdt,EM_REPLACESEL, (WPARAM)FALSE, (LPARAM)str1);
	SendMessage(hWndEdt,EM_REPLACESEL, (WPARAM)FALSE, (LPARAM)str2);
	SendMessage(hWndEdt,EM_REPLACESEL, (WPARAM)FALSE, (LPARAM)RetCar);
	SendMessage(hWndEdt,EM_SCROLLCARET,(WPARAM)0, (LPARAM)0);
}VOID AddStrToMultilineEdit3(HWND hWndEdt,wchar_t *str,wchar_t *str1,wchar_t *str2,wchar_t *str3)
{	SendMessage(hWndEdt,EM_REPLACESEL, (WPARAM)FALSE, (LPARAM)str);
	SendMessage(hWndEdt,EM_REPLACESEL, (WPARAM)FALSE, (LPARAM)str1);
	SendMessage(hWndEdt,EM_REPLACESEL, (WPARAM)FALSE, (LPARAM)str2);
	SendMessage(hWndEdt,EM_REPLACESEL, (WPARAM)FALSE, (LPARAM)str3);
	SendMessage(hWndEdt,EM_REPLACESEL, (WPARAM)FALSE, (LPARAM)RetCar);
	SendMessage(hWndEdt,EM_SCROLLCARET,(WPARAM)0, (LPARAM)0);
}VOID AddStrToMultilineEditInt(HWND hWndEdt,wchar_t* pre,int i,wchar_t* post)
{wchar_t s[MAX_PATH];StringCchPrintf(s,MAX_PATH,L"%s%d%s",pre,i,post);
	SendMessage(hWndEdt,EM_REPLACESEL, (WPARAM)FALSE, (LPARAM)s);
	SendMessage(hWndEdt,EM_REPLACESEL, (WPARAM)FALSE, (LPARAM)RetCar);
	SendMessage(hWndEdt,EM_SCROLLCARET,(WPARAM)0, (LPARAM)0);
}VOID AddStrToMultilineEditStr2Int(HWND hWndEdt,wchar_t* pre,wchar_t* pre1,int i,wchar_t* post)
{wchar_t s[MAX_PATH];StringCchPrintf(s,MAX_PATH,L"%s%s%d%s",pre,pre1,i,post);
	SendMessage(hWndEdt,EM_REPLACESEL, (WPARAM)FALSE, (LPARAM)s);
	SendMessage(hWndEdt,EM_REPLACESEL, (WPARAM)FALSE, (LPARAM)RetCar);
	SendMessage(hWndEdt,EM_SCROLLCARET,(WPARAM)0, (LPARAM)0);
}VOID AddStrToMultilineEditStr2Int1(HWND hWndEdt,wchar_t* pre,wchar_t* pre1,int i)
{wchar_t s[MAX_PATH];StringCchPrintf(s,MAX_PATH,L"%s%s%d",pre,pre1,i);
	SendMessage(hWndEdt,EM_REPLACESEL, (WPARAM)FALSE, (LPARAM)s);
	SendMessage(hWndEdt,EM_REPLACESEL, (WPARAM)FALSE, (LPARAM)RetCar);
	SendMessage(hWndEdt,EM_SCROLLCARET,(WPARAM)0, (LPARAM)0);
}VOID AddStrToMultilineEditHex(HWND hWndEdt,wchar_t* pre,unsigned int i)
{wchar_t s[MAX_PATH];StringCchPrintf(s,MAX_PATH,L"%s%s%08X",pre,L"0X",i);
	SendMessage(hWndEdt,EM_REPLACESEL, (WPARAM)FALSE, (LPARAM)s);
	SendMessage(hWndEdt,EM_REPLACESEL, (WPARAM)FALSE, (LPARAM)RetCar);
	SendMessage(hWndEdt,EM_SCROLLCARET,(WPARAM)0, (LPARAM)0);
}VOID AddStrToMultilineEditHex2Str(HWND hWndEdt,wchar_t* pre,unsigned int i,wchar_t* str1,unsigned int i1)
{wchar_t s[MAX_PATH];StringCchPrintf(s,MAX_PATH,L"%s%s%08X%s%s%04X",pre,L"0X",i,str1,L"0X",i1);
	SendMessage(hWndEdt,EM_REPLACESEL, (WPARAM)FALSE, (LPARAM)s);
	SendMessage(hWndEdt,EM_REPLACESEL, (WPARAM)FALSE, (LPARAM)RetCar);
	SendMessage(hWndEdt,EM_SCROLLCARET,(WPARAM)0, (LPARAM)0);
}VOID AddStrToMultilineEditHex2Str4x2(HWND hWndEdt,wchar_t* pre,unsigned int i,wchar_t* str1,unsigned int i1)
{wchar_t s[MAX_PATH];StringCchPrintf(s,MAX_PATH,L"%s%s%04X%s%04d",pre,L"0X",i,str1,i1);
	SendMessage(hWndEdt,EM_REPLACESEL, (WPARAM)FALSE, (LPARAM)s);
	SendMessage(hWndEdt,EM_REPLACESEL, (WPARAM)FALSE, (LPARAM)RetCar);
	SendMessage(hWndEdt,EM_SCROLLCARET,(WPARAM)0, (LPARAM)0);
}VOID AddStrToMultilineEditHex3Str2(HWND hWndEdt,wchar_t* pre,unsigned int i,wchar_t* str1,unsigned int i1,wchar_t* str2,unsigned int i2)
{wchar_t s[MAX_PATH];StringCchPrintf(s,MAX_PATH,L"%s%s%08X%s%s%04X%s%s%04X",pre,L"0X",i,str1,L"0X",i1,str2,L"0X",i2);
	SendMessage(hWndEdt,EM_REPLACESEL, (WPARAM)FALSE, (LPARAM)s);
	SendMessage(hWndEdt,EM_REPLACESEL, (WPARAM)FALSE, (LPARAM)RetCar);
	SendMessage(hWndEdt,EM_SCROLLCARET,(WPARAM)0, (LPARAM)0);
}

VOID* CorrectPadding(VOID *pFrom,VOID *pBgn,int bitCnt)
{
int bitcnt = bitCnt/8-1;
int cnt = (int)(((char*)pFrom)-((char*)pBgn));
	cnt = (cnt+bitcnt) & (~3);
	return ((char*)pBgn)+cnt;
}

int OutputVarValue(void* pBgn,int ln,wchar_t* padSpaceLeft)
{void *p,*pe,*pbgn=pBgn,*pend=(void*)(((char*)pbgn)+ln);DWORD *pv,*pVarValue;int l=0,l1;WCHAR* pVarszKey;
	while(pbgn<pend && l<ln)
	{	Var* pvar=(Var*)pbgn;
		AddStrToMultilineEditStr2Int(hWndGetInfoFull,padSpaceLeft,L"    wLength          : ",pvar->wLength,L" bytes;");
		AddStrToMultilineEditStr2Int(hWndGetInfoFull,padSpaceLeft,L"    wValueLength          : ",pvar->wValueLength,L" bytes;");
		AddStrToMultilineEditStr2Int1(hWndGetInfoFull,padSpaceLeft,L"    wType          : ",pvar->wType);
		pVarszKey = (WCHAR*)(((char*)pvar)+3*sizeof(WORD));
		AddStrToMultilineEdit3(hWndGetInfoFull,padSpaceLeft,L"    szKey          : \"",pVarszKey,L"\"");
		if(0!=wcscmp(pVarszKey,L"Translation"))
		{	AddStrToMultilineEdit(hWndGetInfoFull,L"    Err. openng \"Var\" values: ");
			return 0;
		}
		p = (void*)(pVarszKey + wcslen(pVarszKey)+1);
		pVarValue=CorrectPadding(p,pvar,32);
		pv = pVarValue;
		pe=pVarValue+pvar->wLength-(int)(((char*)p)-((char*)pvar));
		while(pv<(DWORD*)pe)
		{	AddStrToMultilineEditHex2Str4x2(hWndGetInfoFull,L"    Microsoft language identifier: ",LOWORD(pv),
									 L"; IBM� code page number: ",HIWORD(pv));
			pv++;
		}
		l1 = (int)(((char*)pv)-((char*)pbgn));
		pbgn = (void*)(((char*)pbgn) + l1);
		l += l1;
	}
	return l;//(int)(pbgn-pBgn);
}

int OutputString(void* pStr,wchar_t* padSpaceLeft)
{int l=0;void* p;String *pstr=(String*)pStr;WCHAR* StringszKey;
	AddStrToMultilineEditStr2Int(hWndGetInfoFull,padSpaceLeft,L"    wLength          : ",pstr->wLength,L" bytes;");
	AddStrToMultilineEditStr2Int(hWndGetInfoFull,padSpaceLeft,L"    wValueLength          : ",pstr->wValueLength,L" bytes;");
	AddStrToMultilineEditStr2Int1(hWndGetInfoFull,padSpaceLeft,L"    wType          : ",pstr->wType);
	StringszKey = (WCHAR*)(((char*)pstr)+3*sizeof(WORD));
	AddStrToMultilineEdit3(hWndGetInfoFull,padSpaceLeft,L"    szKey          : \"",StringszKey,L"\"");
	p = ((wchar_t*)StringszKey + wcslen(StringszKey)+1);
	p=CorrectPadding(p,pStr,32);
	AddStrToMultilineEdit2(hWndGetInfoFull,padSpaceLeft,L"    Value          : ",p);
	l = (int)wcslen(p)+1;
	p = (void*)(((wchar_t*)p)+l);
	l = (int)(((char*)p)-((char*)pStr));
	return l;
}

int OutputStringTable(void* pBgn,int ln,wchar_t* padSpaceLeft)
{void *p,*pe,*pbgn=pBgn,*pend=(void*)(((char*)pbgn)+ln);wchar_t *pv;int l=0,l1;
 WCHAR *StringTableszKey;String *StringChildren;
	while(pbgn<pend && l<ln)
	{	StringTable* pStringTable=(StringTable*)pbgn;
		AddStrToMultilineEditStr2Int(hWndGetInfoFull,padSpaceLeft,L"    wLength          : ",pStringTable->wLength,L" bytes;");
		AddStrToMultilineEditStr2Int(hWndGetInfoFull,padSpaceLeft,L"    wValueLength          : ",pStringTable->wValueLength,L" bytes;");
		AddStrToMultilineEditStr2Int1(hWndGetInfoFull,padSpaceLeft,L"    wType          : ",pStringTable->wType);
		StringTableszKey = (WCHAR*)(((char*)pStringTable)+3*sizeof(WORD));
		AddStrToMultilineEdit2(hWndGetInfoFull,padSpaceLeft,L"    szKey          : ",StringTableszKey);
		AddStrToMultilineEditHex2Str(hWndGetInfoFull,L"    Language identifier[1]: major: ",StringTableszKey[0]&0x3ff,L" minor: ",(StringTableszKey[0]&0xfc00)>>10);
		AddStrToMultilineEditHex2Str(hWndGetInfoFull,L"    Language identifier[2]: major: ",StringTableszKey[1]&0x3ff,L" minor: ",(StringTableszKey[1]&0xfc00)>>10);
		AddStrToMultilineEditHex2Str(hWndGetInfoFull,L"    Language identifier[3]: major: ",StringTableszKey[2]&0x3ff,L" minor: ",(StringTableszKey[2]&0xfc00)>>10);
		AddStrToMultilineEditHex2Str(hWndGetInfoFull,L"    Language identifier[4]: major: ",StringTableszKey[3]&0x3ff,L" minor: ",(StringTableszKey[3]&0xfc00)>>10);
		AddStrToMultilineEditHex(hWndGetInfoFull,L"    Code page[1]: ",StringTableszKey[4]);
		AddStrToMultilineEditHex(hWndGetInfoFull,L"    Code page[2]: ",StringTableszKey[5]);
		AddStrToMultilineEditHex(hWndGetInfoFull,L"    Code page[3]: ",StringTableszKey[6]);
		AddStrToMultilineEditHex(hWndGetInfoFull,L"    Code page[4]: ",StringTableszKey[7]);
		p = (void*)(StringTableszKey + 8);//wcslen(&pStringTable->szKey[0])+1);
		StringChildren=CorrectPadding(p,pStringTable,32);
		pv = (wchar_t*)StringChildren;
		pe=((char*)StringChildren)+pStringTable->wLength-(int)(((char*)p)-((char*)pStringTable));
		while(pv<(wchar_t*)pe && pv<(wchar_t*)pend)
		{	wchar_t *pp = (wchar_t*)(((char*)pv)+OutputString(pv,padSpaceLeft));
			pv = CorrectPadding(pp,pv,32);
		}
		l1 = (int)(((char*)pv)-((char*)pbgn));
		pbgn = (void*)(((char*)pbgn) + l1);
		l += l1;
	}
	return l;//(int)(pbgn-pBgn);
}

BOOL GetVersionInfo(wchar_t *fileName)
{
DWORD visz;
VS_VERSIONINFO *pvi;
int sz,v,pviLengthPtr;
VS_FIXEDFILEINFO *VS_VERSIONINFOValue;
StringFileInfo *VS_VERSIONINFOChildren;
StringTable *pstringFileInfoChildren;
VarFileInfo* pvarFileInfo;
wchar_t *vi=NULL;void *p;

	sz = GetFileVersionInfoSize(fileName, &visz);
	if(0==sz)
	{	//wchar_t c[MAX_PATH];sz=GetLastError();
		//wsprintf(c,L"%s Err.code: %d",fileName,sz);
		//MessageBox(NULL,c,L"GetVersionInfo: GetFileVersionInfoSize failed.",MB_OK);
		if(vi)free(vi);
		return FALSE;
	}
	vi = (wchar_t*)malloc(2*sz); vi[0] = '\0';//Win7 uchun 2* qo'ydim;
	if(!vi)
	{	MessageBox(NULL,L"malloc for GetFileVersionInfo failed.",fileName,MB_OK);
		if(vi)free(vi);
		return FALSE;
	}
	pvi=(VS_VERSIONINFO*)vi;

	if(!GetFileVersionInfo(fileName, 0, sz, vi))
	{	MessageBox(NULL,L"GetFileVersionInfo failed.",fileName,MB_OK);
		if(vi)free(vi);
		return FALSE;
	}

	p = (void*)(&pvi->szKey[0] + wcslen(&pvi->szKey[0])+1);
	VS_VERSIONINFOValue=(VS_FIXEDFILEINFO*)CorrectPadding(p,pvi,32);
	p = (void*)((char*)VS_VERSIONINFOValue+sizeof(VS_FIXEDFILEINFO));
	VS_VERSIONINFOChildren=CorrectPadding(p,pvi,32);

	AddStrToMultilineEdit(hWndGetInfoFull,L"VS_VERSIONINFO :");
	AddStrToMultilineEdit(hWndGetInfoFull,L"");
	AddStrToMultilineEditInt(hWndGetInfoFull,L"    wLength          : ",pvi->wLength,L" bytes;");
	AddStrToMultilineEditInt(hWndGetInfoFull,L"    wValueLength : ",pvi->wValueLength,L" bytes;");
	AddStrToMultilineEditInt(hWndGetInfoFull,L"    wType             : ",pvi->wType,L" ;");
	AddStrToMultilineEdit2(hWndGetInfoFull,L"    szKey             : \"",pvi->szKey,L"\"");
	AddStrToMultilineEdit(hWndGetInfoFull,L"");

	AddStrToMultilineEdit(hWndGetInfoFull,L"    VS_FIXEDFILEINFO:");
	AddStrToMultilineEdit(hWndGetInfoFull,L"");
	AddStrToMultilineEditHex(hWndGetInfoFull,L"    dwSignature               : ",VS_VERSIONINFOValue->dwSignature);
	AddStrToMultilineEditHex3Str2(hWndGetInfoFull,L"    dwStrucVersion          : ",VS_VERSIONINFOValue->dwStrucVersion,
								  L";    Major version: ",HIWORD(VS_VERSIONINFOValue->dwStrucVersion),
								  L"  Minor version: ",LOWORD(VS_VERSIONINFOValue->dwStrucVersion));
	AddStrToMultilineEditHex(hWndGetInfoFull,L"    dwFileVersionMS       : ",VS_VERSIONINFOValue->dwFileVersionMS);
	AddStrToMultilineEditHex(hWndGetInfoFull,L"    dwFileVersionLS        : ",VS_VERSIONINFOValue->dwFileVersionLS);
	AddStrToMultilineEditHex(hWndGetInfoFull,L"    dwProductVersionMS : ",VS_VERSIONINFOValue->dwProductVersionMS);
	AddStrToMultilineEditHex(hWndGetInfoFull,L"    dwProductVersionLS  : ",VS_VERSIONINFOValue->dwProductVersionLS);
	AddStrToMultilineEditHex(hWndGetInfoFull,L"    dwFileFlagsMask       : ",VS_VERSIONINFOValue->dwFileFlagsMask);
	AddStrToMultilineEditHex(hWndGetInfoFull,L"    dwFileFlags                : ",VS_VERSIONINFOValue->dwFileFlags);
	if(VS_FF_DEBUG & VS_VERSIONINFOValue->dwFileFlags)
		AddStrToMultilineEdit(hWndGetInfoFull,L"            VS_FF_DEBUG");
	if(VS_FF_INFOINFERRED & VS_VERSIONINFOValue->dwFileFlags)
		AddStrToMultilineEdit(hWndGetInfoFull,L"            VS_FF_INFOINFERRED");
	if(VS_FF_PATCHED & VS_VERSIONINFOValue->dwFileFlags)
		AddStrToMultilineEdit(hWndGetInfoFull,L"            VS_FF_PATCHED");
	if(VS_FF_PRERELEASE & VS_VERSIONINFOValue->dwFileFlags)
		AddStrToMultilineEdit(hWndGetInfoFull,L"            VS_FF_PRERELEASE");
	if(VS_FF_PRIVATEBUILD & VS_VERSIONINFOValue->dwFileFlags)
		AddStrToMultilineEdit(hWndGetInfoFull,L"            VS_FF_PRIVATEBUILD");
	if(VS_FF_SPECIALBUILD & VS_VERSIONINFOValue->dwFileFlags)
		AddStrToMultilineEdit(hWndGetInfoFull,L"            VS_FF_SPECIALBUILD");

	AddStrToMultilineEditHex(hWndGetInfoFull,L"    dwFileOS                    : ",VS_VERSIONINFOValue->dwFileOS);
	if(VOS_DOS==VS_VERSIONINFOValue->dwFileOS)
		AddStrToMultilineEdit(hWndGetInfoFull,L"            VOS_DOS");
	else if(VOS_NT==VS_VERSIONINFOValue->dwFileOS)
		AddStrToMultilineEdit(hWndGetInfoFull,L"            VOS_NT");
	else if(VOS__WINDOWS16==VS_VERSIONINFOValue->dwFileOS)
		AddStrToMultilineEdit(hWndGetInfoFull,L"            VOS__WINDOWS16");
	else if(VOS__WINDOWS32==VS_VERSIONINFOValue->dwFileOS)
		AddStrToMultilineEdit(hWndGetInfoFull,L"            VOS__WINDOWS32");
	else if(VOS_OS216==VS_VERSIONINFOValue->dwFileOS)
		AddStrToMultilineEdit(hWndGetInfoFull,L"            VOS_OS216");
	else if(VOS_OS232==VS_VERSIONINFOValue->dwFileOS)
		AddStrToMultilineEdit(hWndGetInfoFull,L"            VOS_OS232");
	else if(VOS__PM16==VS_VERSIONINFOValue->dwFileOS)
		AddStrToMultilineEdit(hWndGetInfoFull,L"            VOS__PM16");
	else if(VOS__PM32==VS_VERSIONINFOValue->dwFileOS)
		AddStrToMultilineEdit(hWndGetInfoFull,L"            VOS__PM32");
	else if(VOS_UNKNOWN==VS_VERSIONINFOValue->dwFileOS)
		AddStrToMultilineEdit(hWndGetInfoFull,L"            VOS_UNKNOWN");
	else if(VOS_DOS_WINDOWS16==VS_VERSIONINFOValue->dwFileOS)
		AddStrToMultilineEdit(hWndGetInfoFull,L"            VOS_DOS_WINDOWS16");
	else if(VOS_DOS_WINDOWS32==VS_VERSIONINFOValue->dwFileOS)
		AddStrToMultilineEdit(hWndGetInfoFull,L"            VOS_DOS_WINDOWS32");
	else if(VOS_NT_WINDOWS32==VS_VERSIONINFOValue->dwFileOS)
		AddStrToMultilineEdit(hWndGetInfoFull,L"            VOS_NT_WINDOWS32");
	else if(VOS_OS216_PM16==VS_VERSIONINFOValue->dwFileOS)
		AddStrToMultilineEdit(hWndGetInfoFull,L"            VOS_OS216_PM16");
	else if(VOS_OS232_PM32==VS_VERSIONINFOValue->dwFileOS)
		AddStrToMultilineEdit(hWndGetInfoFull,L"            VOS_OS232_PM32");

	AddStrToMultilineEditHex(hWndGetInfoFull,L"    dwFileType                 : ",VS_VERSIONINFOValue->dwFileType);
	if(VFT_UNKNOWN==VS_VERSIONINFOValue->dwFileType)
		AddStrToMultilineEdit(hWndGetInfoFull,L"            VFT_UNKNOWN");
	else if(VFT_APP==VS_VERSIONINFOValue->dwFileType)
		AddStrToMultilineEdit(hWndGetInfoFull,L"            VFT_APP");
	else if(VFT_DLL==VS_VERSIONINFOValue->dwFileType)
		AddStrToMultilineEdit(hWndGetInfoFull,L"            VFT_DLL");
	else if(VFT_DRV==VS_VERSIONINFOValue->dwFileType)
		AddStrToMultilineEdit(hWndGetInfoFull,L"            VFT_DRV");
	else if(VFT_FONT==VS_VERSIONINFOValue->dwFileType)
		AddStrToMultilineEdit(hWndGetInfoFull,L"            VFT_FONT");
	else if(VFT_VXD==VS_VERSIONINFOValue->dwFileType)
		AddStrToMultilineEdit(hWndGetInfoFull,L"            VFT_VXD");
	else if(VFT_STATIC_LIB==VS_VERSIONINFOValue->dwFileType)
		AddStrToMultilineEdit(hWndGetInfoFull,L"            VFT_STATIC_LIB");

	AddStrToMultilineEditHex(hWndGetInfoFull,L"    dwFileSubtype            : ",VS_VERSIONINFOValue->dwFileSubtype);
	if(VFT_DRV==VS_VERSIONINFOValue->dwFileType)
	{if(VFT2_UNKNOWN==VS_VERSIONINFOValue->dwFileSubtype)
		AddStrToMultilineEdit(hWndGetInfoFull,L"            VFT2_UNKNOWN");
	 else if(VFT2_DRV_COMM==VS_VERSIONINFOValue->dwFileSubtype)
		AddStrToMultilineEdit(hWndGetInfoFull,L"            VFT2_DRV_COMM");
	 else if(VFT2_DRV_PRINTER==VS_VERSIONINFOValue->dwFileSubtype)
		AddStrToMultilineEdit(hWndGetInfoFull,L"            VFT2_DRV_PRINTER");
	 else if(VFT2_DRV_KEYBOARD==VS_VERSIONINFOValue->dwFileSubtype)
		AddStrToMultilineEdit(hWndGetInfoFull,L"            VFT2_DRV_KEYBOARD");
	 else if(VFT2_DRV_LANGUAGE==VS_VERSIONINFOValue->dwFileSubtype)
		AddStrToMultilineEdit(hWndGetInfoFull,L"            VFT2_DRV_LANGUAGE");
	 else if(VFT2_DRV_DISPLAY==VS_VERSIONINFOValue->dwFileSubtype)
		AddStrToMultilineEdit(hWndGetInfoFull,L"            VFT2_DRV_DISPLAY");
	 else if(VFT2_DRV_MOUSE==VS_VERSIONINFOValue->dwFileSubtype)
		AddStrToMultilineEdit(hWndGetInfoFull,L"            VFT2_DRV_MOUSE");
	 else if(VFT2_DRV_NETWORK==VS_VERSIONINFOValue->dwFileSubtype)
		AddStrToMultilineEdit(hWndGetInfoFull,L"            VFT2_DRV_NETWORK");
	 else if(VFT2_DRV_SYSTEM==VS_VERSIONINFOValue->dwFileSubtype)
		AddStrToMultilineEdit(hWndGetInfoFull,L"            VFT2_DRV_SYSTEM");
	 else if(VFT2_DRV_INSTALLABLE==VS_VERSIONINFOValue->dwFileSubtype)
		AddStrToMultilineEdit(hWndGetInfoFull,L"            VFT2_DRV_INSTALLABLE");
	 else if(VFT2_DRV_SOUND==VS_VERSIONINFOValue->dwFileSubtype)
		AddStrToMultilineEdit(hWndGetInfoFull,L"            VFT2_DRV_SOUND");
	}else if(VFT_FONT==VS_VERSIONINFOValue->dwFileType)
	{	if(VFT2_UNKNOWN==VS_VERSIONINFOValue->dwFileSubtype)
			AddStrToMultilineEdit(hWndGetInfoFull,L"            VFT2_UNKNOWN");
		else if(VFT2_UNKNOWN==VS_VERSIONINFOValue->dwFileSubtype)
			AddStrToMultilineEdit(hWndGetInfoFull,L"            VFT2_FONT_RASTER");
		else if(VFT2_FONT_VECTOR==VS_VERSIONINFOValue->dwFileSubtype)
			AddStrToMultilineEdit(hWndGetInfoFull,L"            VFT2_FONT_VECTOR");
		else if(VFT2_FONT_TRUETYPE==VS_VERSIONINFOValue->dwFileSubtype)
			AddStrToMultilineEdit(hWndGetInfoFull,L"            VFT2_FONT_TRUETYPE");
	}

	AddStrToMultilineEditHex(hWndGetInfoFull,L"    dwFileDateMS            : ",VS_VERSIONINFOValue->dwFileDateMS);
	AddStrToMultilineEditHex(hWndGetInfoFull,L"    dwFileDateLS             : ",VS_VERSIONINFOValue->dwFileDateLS);
	
	AddStrToMultilineEdit(hWndGetInfoFull,L"");
	pviLengthPtr=(int)(((char*)VS_VERSIONINFOChildren) - ((char*)pvi));
	for(v=0; v<2; ++v)//Specifies the length, in bytes, of the VS_VERSIONINFO structure. This length does not include any padding that aligns any subsequent version resource data on a 32-bit boundary.
	{int ln;
	 if(0==_wcsnicmp(VS_VERSIONINFOChildren->szKey,L"StringFileInfo",14))
	 {	AddStrToMultilineEdit(hWndGetInfoFull,L"    Consist from \"StringFileInfo\" structure:");
		AddStrToMultilineEditInt(hWndGetInfoFull,L"    wLength          : ",VS_VERSIONINFOChildren->wLength,L" bytes;");
		AddStrToMultilineEditInt(hWndGetInfoFull,L"    wValueLength           : ",VS_VERSIONINFOChildren->wValueLength,L" bytes;");
		AddStrToMultilineEditInt(hWndGetInfoFull,L"    wType           : ",VS_VERSIONINFOChildren->wType,L" ;");
		AddStrToMultilineEdit2(hWndGetInfoFull,L"    szKey             : \"",VS_VERSIONINFOChildren->szKey,L"\"");
		if(0!=wcscmp(VS_VERSIONINFOChildren->szKey,L"StringFileInfo"))
		{ AddStrToMultilineEdit(hWndGetInfoFull,L"    Error \"StringFileInfo\" structure decompressing...");
		  return FALSE;
		}
		p = (void*)(&VS_VERSIONINFOChildren->szKey[0] + wcslen(&VS_VERSIONINFOChildren->szKey[0])+1);
		pstringFileInfoChildren=CorrectPadding(p,VS_VERSIONINFOChildren,32);
		ln = (int)(((char*)pstringFileInfoChildren)-((char*)VS_VERSIONINFOChildren));
		if(ln<VS_VERSIONINFOChildren->wLength)
		{	ln+=OutputStringTable(pstringFileInfoChildren,VS_VERSIONINFOChildren->wLength-ln,L"      ");
	 }	}
	 else
	 {	WCHAR *pvarFileInfoszKey = (WCHAR*)(((char*)VS_VERSIONINFOChildren)+3*sizeof(WORD));
		Var *pvarFileInfoChildren;
		AddStrToMultilineEdit(hWndGetInfoFull,L"    Consist from \"VarFileInfo\" structure:");
		pvarFileInfo = (VarFileInfo*)VS_VERSIONINFOChildren;
		AddStrToMultilineEditInt(hWndGetInfoFull,L"    wLength          : ",pvarFileInfo->wLength,L" bytes;");
		AddStrToMultilineEditInt(hWndGetInfoFull,L"    wValueLength : ",pvarFileInfo->wValueLength,L" bytes;");
		AddStrToMultilineEditInt(hWndGetInfoFull,L"    wType             : ",pvarFileInfo->wType,L" ;");
		AddStrToMultilineEdit2(hWndGetInfoFull,L"    szKey             : \"",pvarFileInfoszKey,L"\"");
		p = (void*)(pvarFileInfoszKey + wcslen(pvarFileInfoszKey)+1);
		pvarFileInfoChildren=CorrectPadding(p,pvarFileInfo,32);
		ln = (int)(((char*)pvarFileInfoChildren)-((char*)pvarFileInfo));
		if(ln<pvarFileInfo->wLength)
		{	ln+=OutputVarValue(pvarFileInfoChildren,pvarFileInfo->wLength-ln,L"      ");
	 }	}
	 pviLengthPtr+=ln;
	 if(pviLengthPtr>pvi->wLength-1)break;//if(ln>VS_VERSIONINFOChildren->wLength-1)break;
	 VS_VERSIONINFOChildren = (StringFileInfo*)((char*)VS_VERSIONINFOChildren+ln);
	}
	AddStrToMultilineEdit(hWndGetInfoFull,L"");

	free(vi);
	//ReleaseDC(dc);
	return TRUE;
}