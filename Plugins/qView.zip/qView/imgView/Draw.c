#pragma comment(lib,"Msimg32.lib")

#include "imgView.h"
#include "resource.h"
#include "strsafe.h"
#include "Config.h"
#include "..\..\..\Operations\MyShell\MyShellC.h"

HWND hWndPnl=0;
BOOL bFileLoaded=FALSE;
u64 iAddressText=0;
int xScroll=0;

//static SCROLLINFO saveHScrlInfo,saveVScrlInfo;
//static WNDPROC savePnlWndProc;

VOID DrawImage(HDC DC,RECT* rc)
{
//BITMAPINFO bmi;
	int Width = rc->right - rc->left;
	int Height = rc->bottom - rc->top;
	//BitBlt(DC,0,0,Width,Height,dc,0,0,SRCCOPY);
	//SetStretchBltMode(dc,0);
	//StretchBlt(DC,0,0,Width,Height,dc,0,0,width,height,SRCCOPY);

/*	XFORM xForm;
	if(90==Conf_rotDegree)
	{SetGraphicsMode(DC, GM_ADVANCED);
     SetMapMode(DC, MM_TEXT);
	 xForm.eM11 = 0;
     xForm.eM12 = -1;
     xForm.eM21 = 1;
     xForm.eM22 = 0;//imgHeight/imgWidth;
     xForm.eDx  = 0; 
     xForm.eDy  = (FLOAT)imgHeight*heightChld/imgHeight;
     SetWorldTransform(DC, &xForm);
	}else if(-90==Conf_rotDegree)
	{SetGraphicsMode(DC, GM_ADVANCED);
     SetMapMode(DC, MM_TEXT);
	 xForm.eM11 = 0;
     xForm.eM12 = 1;
     xForm.eM21 = -1;
     xForm.eM22 = 0;
     xForm.eDx  = (FLOAT)imgHeight*heightChld/imgHeight;
     xForm.eDy  = 0; 
     SetWorldTransform(DC, &xForm);
	}else if(180==Conf_rotDegree)
	{SetGraphicsMode(DC, GM_ADVANCED);
     SetMapMode(DC, MM_TEXT);
	 xForm.eM11 = 1;
     xForm.eM12 = 0;
     xForm.eM21 = 0;
     xForm.eM22 = -1;
     xForm.eDx  = 0; 
     xForm.eDy  = (FLOAT)heightChld; 
     SetWorldTransform(DC, &xForm);
	}else
	{SetGraphicsMode(DC, GM_ADVANCED);
     SetMapMode(DC, MM_TEXT);
	 xForm.eM11 = 0;
     xForm.eM12 = 0;
     xForm.eM21 = 0;
     xForm.eM22 = 0;
     xForm.eDx  = 0; 
     xForm.eDy  = 0; 
     SetWorldTransform(DC, &xForm);
	}*/


	switch(Conf_horAlign)
	{case 0://left:
	  break;
	 case 1://center:
	  break;
     case 2://right:
	  break;
	}

	if(1==Conf_originalSize)
	{int dx,dy;drImgFrPosX=xScrnOffst;	
	 drImgFrPosY=yScrnOffst;
	 dx=widthChld;
	 if(drImgFrPosX+dx>imgWidth)dx=imgWidth-drImgFrPosX;
	 if(dx<0)
	 {	drImgFrPosX=0;
		dx=imgWidth;
	 }


	 dy=heightChld;	
	 if(drImgFrPosY+dy>imgHeight)dy=imgHeight-drImgFrPosY;
	 if(dy<0)
	 {	drImgFrPosY=0;
		dy=imgHeight;
	 }

	 if(1==Conf_drawMethod)
	 {SetStretchBltMode(dcImgBm,0);
	  StretchBlt(DC,rc->left,rc->top,dx,dy,dcImgBm,drImgFrPosX,drImgFrPosY,dx,dy,SRCCOPY);
	 }
	 else
	 {//if(imgType==dib)// && imgBpp==1)
	   BitBlt(DC,rc->left,rc->top,dx,dy,dcImgBm,drImgFrPosX,drImgFrPosY,SRCCOPY);
	  //else
	  // TransparentBlt(DC,rc.left,rc.top,dx,dy,dcImgBm,drImgFrPosX,drImgFrPosY,dx,dy,0xffffffff);
	 }
	 imgCntrPosX=drImgFrPosX+dx/2;
	 imgCntrPosY=drImgFrPosY+dy/2;
	 imgToPosX=rc->left;
	 imgToPosY=rc->top;
	}
	else
	{if(1==Conf_drawMethod)
	 {SetStretchBltMode(dcImgBm,0);
	  StretchBlt(DC,rc->left,rc->top,Width,Height,dcImgBm,0,0,imgWidth,imgHeight,SRCCOPY);
	 }
	 else
	 {if(Width>imgWidth && Height>imgHeight)
	   TransparentBlt(	DC,
						rc->left+(Width-imgWidth)/2,
						rc->top+(Height-imgHeight)/2,
						imgWidth,
						imgHeight,
						dcImgBm,
						0,
						0,
						imgWidth,
						imgHeight,
						0xffffffff);
	  else if(Width>imgWidth)
	   TransparentBlt(	DC,
						rc->left+(Width-imgWidth)/2,
						rc->top,
						imgWidth,
						Height,
						dcImgBm,
						0,
						0,
						imgWidth,
						imgHeight,
						0xffffffff);
	  else if(Height>imgHeight)
	   TransparentBlt(	DC,
						rc->left,
						rc->top+(Height-imgHeight)/2,
						Width,
						imgHeight,
						dcImgBm,
						0,
						0,
						imgWidth,
						imgHeight,
						0xffffffff);
	  else
	   TransparentBlt(DC,rc->left,rc->top,Width,Height,dcImgBm,0,0,imgWidth,imgHeight,0xffffffff);
	}}
/*
	memset(&bmi, 0, sizeof(bmi));
	bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biBitCount = bpp*8;
	bmi.bmiHeader.biClrUsed = 0;
    bmi.bmiHeader.biCompression = BI_RGB;


	if(Width > width || Height > height)
	{	bmi.bmiHeader.biWidth = width;
		bmi.bmiHeader.biHeight = -height;
		bmi.bmiHeader.biSizeImage = width*height*bpp;
		StretchDIBits(DC,0,0,Width,Height,0,0,width,height,pic,&bmi,DIB_RGB_COLORS,SRCCOPY);
		return;
	}


	const f32 sourceXStep = (f32) width / (f32) Width;
	const f32 sourceYStep = (f32) height / (f32) Height;

	s32 fx = ceil32(sourceXStep);
	s32 fy = ceil32(sourceYStep);
	f32 sx;
	f32 sy;

	BYTE *pdst = sclPic;
	sy = 0.f;
	for(u32 y=0; y!=Height; ++y )
	{	sx = 0.f;
		for(u32 x=0; x!=Width; ++x )
		{	*((DWORD*)pdst) = 
				getPixelBox(floor32(sx), floor32(sy), fx, fy);//, 0 );//bias=0; blend false
			sx += sourceXStep;
			pdst += bpp;
		}
		sy += sourceYStep;
	}
	bmi.bmiHeader.biWidth = Width;
	bmi.bmiHeader.biHeight = -Height;
	bmi.bmiHeader.biSizeImage = Width*Height*bpp;
	StretchDIBits(DC,0,0,Width,Height,0,0,Width,Height,sclPic,&bmi,DIB_RGB_COLORS,SRCCOPY);
	*/
	SetTextColor(DC,RGB(255,255,0));
	SetBkMode(DC,TRANSPARENT);
	DrawText(DC,&cmnt[imgFilePathAndNameLn+1],-1,rc,DT_SINGLELINE|DT_BOTTOM);//TextOut(DC,0,rc.bottom-25,&cmnt[imgFilePathAndNameLn+1],MyStringLength(&cmnt[imgFilePathAndNameLn+1],MAX_PATH));
}

VOID Render(HDC DC)
{HDC dc=DC;RECT rcPnl;
	if(!dc)dc=GetDC(hWndPnl);
	GetClientRect(hWndPnl,&rcPnl);
	FillRect(dc,&rcPnl,(HBRUSH)GetStockObject(BLACK_BRUSH));	  
	if(!imgLoadFail)
	{if(1==Conf_originalSize && imgWidth<widthChld && imgHeight<heightChld)
	 {if(1==Conf_horAlign)rcPnl.left=(widthChld-imgWidth)/2;
	  else if(2==Conf_horAlign)rcPnl.left=widthChld-imgWidth;
	  if(1==Conf_verAlign)rcPnl.top=(heightChld-imgHeight)/2;
	  else if(2==Conf_verAlign)rcPnl.top=heightChld-imgHeight;
	 }
	 DrawImage(dc,&rcPnl);
	}
	if(!DC)ReleaseDC(hWndPnl,dc);
}

VOID RenderFillBack(HDC DC)
{HDC dc=DC;RECT rcl;
	if(!dc)dc=GetDC(hWndPnl);
	GetClientRect(hWndPnl,&rcl);
	FillRect(dc,&rcl,(HBRUSH)GetStockObject(BLACK_BRUSH));
	if(!imgLoadFail)
	{if(1==Conf_originalSize && imgWidth<widthChld && imgHeight<heightChld)
	 {if(1==Conf_horAlign)rcl.left=(widthChld-imgWidth)/2;
	  else if(2==Conf_horAlign)rcl.left=widthChld-imgWidth;
	  if(1==Conf_verAlign)rcl.top=(heightChld-imgHeight)/2;
	  else if(2==Conf_verAlign)rcl.top=heightChld-imgHeight;
	 }
	 DrawImage(dc,&rcl);
	}
	if(!DC)ReleaseDC(hWndPnl,dc);
}

LRESULT newPnlWndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{static DWORD deltaScrlTime=0;PAINTSTRUCT ps;HDC hdc;SCROLLINFO si;int deltaScrl,x,y;
	switch (msg)
	{
	case WM_SIZE:
		Conf_width=LOWORD(lParam);
		Conf_height=HIWORD(lParam);
		//if(1==Conf_originalSize)
			CalcScrnOffst();
		return 0;
	case WM_PAINT:
		hdc = BeginPaint(hWnd, &ps);
		 Render(hdc);
		EndPaint(hWnd, &ps);
		return 0;
	case WM_HSCROLL:
	    if(!bLoadedFin)return 0;
		ZeroMemory(&si,sizeof(si));
		switch(LOWORD(wParam))
		{case SB_ENDSCROLL:
		  deltaScrlTime=0;
		  return 0;
		 case SB_LINELEFT:
		  si.fMask = SIF_POS;
		  GetScrollInfo(hWnd, SB_HORZ, &si);
  		  if(0==deltaScrlTime){deltaScrl=1;deltaScrlTime=GetTickCount();}
		  else
		  {DWORD dt=GetTickCount();
		   deltaScrl=1+(dt-deltaScrlTime)/50;
		   if(deltaScrl>50)
			   deltaScrl=50;
		  }
		  si.nPos -= deltaScrl;
		  if(si.nPos<0)si.nPage=0;
		  SetScrollInfo(hWnd, SB_HORZ, &si, TRUE);
		  xScrnOffst=si.nPos;
		  Render(0);
		  //wchar_t s[32];
		  //wsprintf(s,L"\n%d",deltaScrl);
		  //OutputDebugString(s);
		  return 0;
		 case SB_LINERIGHT:
		  si.fMask = SIF_POS|SIF_RANGE;
		  GetScrollInfo(hWnd, SB_HORZ, &si);
  		  if(0==deltaScrlTime){deltaScrl=1;deltaScrlTime=GetTickCount();}
		  else
		  {DWORD dt=GetTickCount();
		   deltaScrl=1+(dt-deltaScrlTime)/50;
		   if(deltaScrl>50)
			   deltaScrl=50;
		  }
		  si.nPos += deltaScrl;
		  if(si.nPos>si.nMax)si.nPos=si.nMax;
		  si.fMask = SIF_POS;
		  SetScrollInfo(hWnd, SB_HORZ, &si, TRUE);
		  xScrnOffst=si.nPos;
		  Render(0);
		  return 0;
		 case SB_PAGELEFT:
		  si.fMask = SIF_PAGE|SIF_POS|SIF_RANGE;
		  GetScrollInfo(hWnd, SB_HORZ, &si);
		  si.nPos -= si.nPage>0?((si.nMax-si.nMin)/si.nPage):1;
		  if(si.nPos<0)si.nPos=0;
		  si.fMask = SIF_POS;
		  SetScrollInfo(hWnd, SB_HORZ, &si, TRUE);
		  xScrnOffst=si.nPos;
		  Render(0);
		  return 0;
		 case SB_PAGERIGHT:
		  si.fMask = SIF_PAGE|SIF_POS|SIF_RANGE;
		  GetScrollInfo(hWnd, SB_HORZ, &si);
		  si.nPos += si.nPage>0?((si.nMax-si.nMin)/si.nPage):1;
		  if(si.nPos>si.nMax)si.nPos=si.nMax;
		  si.fMask = SIF_POS;
		  SetScrollInfo(hWnd, SB_HORZ, &si, TRUE);
		  xScrnOffst=si.nPos;
		  Render(0);
		  return 0;
		 case SB_THUMBPOSITION:
		  xScrnOffst=HIWORD(wParam);
		  si.fMask = SIF_POS;
		  si.nPos = xScrnOffst;
		  SetScrollInfo(hWnd, SB_HORZ, &si, TRUE);
		  Render(0);
		  return 0;
		 case SB_THUMBTRACK:
		  xScrnOffst=HIWORD(wParam);
		  Render(0);
		  return 0;
		}
		return 0;
	case WM_VSCROLL:
	    if(!bLoadedFin)return 0;
		ZeroMemory(&si,sizeof(si));
		switch(LOWORD(wParam))
		{case SB_ENDSCROLL:
		  deltaScrlTime=0;
		  return 0;
		 case SB_LINELEFT:
		  si.fMask = SIF_POS;
		  GetScrollInfo(hWnd, SB_VERT, &si);
  		  if(0==deltaScrlTime){deltaScrl=1;deltaScrlTime=GetTickCount();}
		  else
		  {DWORD dt=GetTickCount();
		   deltaScrl=1+(dt-deltaScrlTime)/50;
		   if(deltaScrl>50)
			   deltaScrl=50;
		  }
		  si.nPos -= deltaScrl;
		  if(si.nPos<0)si.nPage=0;
		  SetScrollInfo(hWnd, SB_VERT, &si, TRUE);
		  yScrnOffst=si.nPos;
		  Render(0);
		  //wchar_t s[32];
		  //wsprintf(s,L"\n%d",deltaScrl);
		  //OutputDebugString(s);
		  return 0;
		 case SB_LINERIGHT:
		  si.fMask = SIF_POS|SIF_RANGE;
		  GetScrollInfo(hWnd, SB_VERT, &si);
  		  if(0==deltaScrlTime){deltaScrl=1;deltaScrlTime=GetTickCount();}
		  else
		  {DWORD dt=GetTickCount();
		   deltaScrl=1+(dt-deltaScrlTime)/50;
		   if(deltaScrl>50)
			   deltaScrl=50;
		  }
		  si.nPos += deltaScrl;
		  if(si.nPos>si.nMax)si.nPos=si.nMax;
		  si.fMask = SIF_POS;
		  SetScrollInfo(hWnd, SB_VERT, &si, TRUE);
		  yScrnOffst=si.nPos;
		  Render(0);
		  return 0;
		 case SB_PAGELEFT:
		  si.fMask = SIF_PAGE|SIF_POS|SIF_RANGE;
		  GetScrollInfo(hWnd, SB_VERT, &si);
		  si.nPos -= si.nPage>0?((si.nMax-si.nMin)/si.nPage):1;
		  if(si.nPos<0)si.nPos=0;
		  si.fMask = SIF_POS;
		  SetScrollInfo(hWnd, SB_VERT, &si, TRUE);
		  yScrnOffst=si.nPos;
		  Render(0);
		  return 0;
		 case SB_PAGERIGHT:
		  si.fMask = SIF_PAGE|SIF_POS|SIF_RANGE;
		  GetScrollInfo(hWnd, SB_VERT, &si);
		  si.nPos += si.nPage>0?((si.nMax-si.nMin)/si.nPage):1;
		  if(si.nPos>si.nMax)si.nPos=si.nMax;
		  si.fMask = SIF_POS;
		  SetScrollInfo(hWnd, SB_VERT, &si, TRUE);
		  yScrnOffst=si.nPos;
		  Render(0);
		  return 0;
		 case SB_THUMBPOSITION:
		  yScrnOffst=HIWORD(wParam);
		  si.fMask = SIF_POS;
		  si.nPos = yScrnOffst;
		  SetScrollInfo(hWnd, SB_VERT, &si, TRUE);
		  Render(0);
		  return 0;
		 case SB_THUMBTRACK:
		  yScrnOffst=HIWORD(wParam);
		  Render(0);
		  return 0;
		}
		return 0;
	case WM_LBUTTONDOWN:
		SetCursor(hCursorHand);
		cursCaptFrX=LOWORD(lParam);
		cursCaptFrY=HIWORD(lParam);
		xScrnOffstInMouCapt=xScrnOffst;
		yScrnOffstInMouCapt=yScrnOffst;
		if(1==Conf_originalSize)
		{SetCapture(hWnd);
		 bMouseCapture=TRUE;
		}
		x=drImgFrPosX+cursCaptFrX;
		y=drImgFrPosY+cursCaptFrY;
		if(x>-1 && y>-1)
		{if(x>imgWidth)
		  x -= imgToPosX;
	     if(y>imgHeight)
		  y -= imgToPosY;
		 if(x>0 && x<imgWidth && y>0 && y<imgHeight)
		 {/*StringCchPrintf(s,MAX_PATH,L"%d",x);
		  SetWindowText(hWndStatCaptX,s);
		  StringCchPrintf(s,MAX_PATH,L"%d",y);
		  SetWindowText(hWndStatCaptY,s);*/
		}}
		return 0;
	case WM_LBUTTONUP:
		SetCursor(hCursorArr);
		ReleaseCapture();
		//SetWindowText(hWndStatCaptX,L"");
		//SetWindowText(hWndStatCaptY,L"");
		bMouseCapture=FALSE;
		return 0;
	case WM_MOUSEMOVE:
		if(bMouseCapture)
		if(LOWORD(lParam)<0xf000)
		if(HIWORD(lParam)<0xf000)
		{int xs,ys;xs=xScrnOffstInMouCapt-(LOWORD(lParam)-cursCaptFrX);
		 ys=yScrnOffstInMouCapt-(HIWORD(lParam)-cursCaptFrY);
		 xScrnOffst=xs;if(xScrnOffst<0)xScrnOffst=0;
		 yScrnOffst=ys;if(yScrnOffst<0)yScrnOffst=0;
		 si.fMask = SIF_POS;
		 si.nPos = xScrnOffst;
		 SetScrollInfo(hWnd, SB_HORZ, &si, TRUE);
		 si.nPos = yScrnOffst;
		 SetScrollInfo(hWnd, SB_VERT, &si, TRUE);
		 RenderFillBack(0);
		}
		return 0;
	}
	return DefWindowProc(hWnd,msg,wParam,lParam);
}

BOOL ChangeViewFile(wchar_t *filePthAndName)
{	imgFilePathAndNameLn=MyStringCpy(imgFilePathAndName,MAX_PATH,filePthAndName);
	bFileLoaded = OpenImgFile();
	Render(0);
	return bFileLoaded;
}

BOOL InitViewer(HWND prnt, wchar_t *filePthAndName)
{WNDCLASSEX wc;RECT rc;ATOM a;
	imgFilePathAndNameLn=MyStringCpy(imgFilePathAndName,MAX_PATH,filePthAndName);
	wc.cbSize=sizeof(wc);
	wc.hInstance=plgnDllInst;
	wc.hCursor=LoadCursor(NULL,IDC_ARROW);
	wc.hIcon=wc.hIconSm=NULL;
	wc.lpfnWndProc=(WNDPROC)newPnlWndProc;
	wc.lpszClassName=L"qvimg_class";
	wc.lpszMenuName=NULL;
	wc.cbClsExtra=0;
	wc.cbWndExtra=0;
	wc.style=CS_HREDRAW|CS_VREDRAW;  
	wc.hbrBackground=GetStockObject(WHITE_BRUSH); 
	a=RegisterClassEx(&wc);
	//if(!a)return FALSE;
	GetWindowRect(prnt,&rc);
	hWndPnl = CreateWindowEx(WS_EX_LEFT|WS_EX_CLIENTEDGE,
							 L"qvimg_class",
							 L"qvimg_window",
							 WS_VISIBLE|WS_CHILDWINDOW,
							 0,
							 0,
							 (int)(rc.right-rc.left),
							 (int)(rc.bottom-rc.top),
							 prnt,
							 0,
							 plgnDllInst,
							 0);
	if(!hWndPnl)return FALSE;
	SetWindowLongPtr(hWndPnl,GWLP_USERDATA,(LONG_PTR)prnt);
	return ChangeViewFile(filePthAndName);
}

VOID CloseViewer()
{	if(dcTmpImgBm)DeleteDC(dcTmpImgBm);dcTmpImgBm=0;
	if(dcTmpImgBm)DeleteObject(dcTmpImgBm);dcTmpImgBm=0;
	if(hWndPnl)DestroyWindow(hWndPnl);
	hWndPnl=0;
	UnregisterClass(L"qvimg_class",plgnDllInst);
}

__declspec (dllexport) BOOL Draw$8(HWND prnt, wchar_t* filePthAndName)
{	if(!prnt)return FALSE;
	if(!filePthAndName)return FALSE;
	if(0==filePthAndName[0])return FALSE;
	if(hWndPnl)
	{	if(0==wcscmp(imgFilePathAndName,filePthAndName))
			return TRUE;
		else ChangeViewFile(filePthAndName);
	}
	else//if(hWndPnl!=prnt)
		InitViewer(prnt,filePthAndName);
	return TRUE;
}