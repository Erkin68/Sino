#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <windows.h>
#include <strsafe.h>
#include "imgView.h"
#include "..\..\..\Operations\MyShell\MyShellC.h"




typedef BOOL (*LoadDDS_t)(wchar_t*,HDC*,HBITMAP*,int*,int*,int*);
LoadDDS_t LoadDDS=NULL;

BOOL TryLoadDds(wchar_t* imgFilePathAndName,HBITMAP* pbm,HDC *pdc,int *width,int *height,int *bpp)
{wchar_t s[MAX_PATH],*p,*pp;DWORD t1,t2;int ln;

//BITMAPINFO *pb;
	if(!hm)
	{	GetModuleFileName(NULL,s,MAX_PATH-1);
		p = wcsrchr(s,'\\');
		if(!p)return FALSE;
		*(p+1)=0;
		MyStringCpy(p+1,MAX_PATH-1-(int)(p-&s[0]),L"Plugins\\Image\\DdsRel.dll");
		if(!IsFileExist(s))
			MyStringCpy(p+1,MAX_PATH-1-(int)(p-&s[0]),L"Plugins\\Image\\DdsDbg.dll");
		hm = LoadLibrary(s);
		if(!hm)	return FALSE;

		LoadDDS = (LoadDDS_t)GetProcAddress(hm,"Load$24");
		if(!LoadDDS)
		{	FreeLibrary(hm);
			return FALSE;
	}	}
	pp = &cmnt[0];
	t1=GetTickCount();

	LoadDDS(imgFilePathAndName,pdc,pbm,width,height,bpp);
	//TransparentBlt(*pdc,0,0,*width,*height,DC,0,0,*width,*height,0x1);
	//t2=GetLastError();

	t2=GetTickCount();
	ln = MyStringLength(cmnt,2*MAX_PATH);
	cmnt[ln++] = ' ';
	StringCchPrintfW(&cmnt[ln],MAX_PATH-ln,L"open time: %d ms",t2-t1);


	//free(ppbImage);
	FreeLibrary(hm);
	hm=0;
	return TRUE;
}