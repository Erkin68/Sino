#include "imgView.h"
#include "..\..\..\Operations\Myshell\MyShellC.h"


ImgType imgType=jpg;


BOOL OpenImgFile()
{	wchar_t *p;
	if(!IsFileExist(imgFilePathAndName)) return FALSE;
	p = wcsrchr(imgFilePathAndName,'.');
	if(!p)return FALSE;

	if(0==_wcsnicmp(p+1,L"jpg",3))
		imgType=jpg;
	else if(0==_wcsnicmp(p+1,L"jpeg",4))
		imgType=jpg;
	else if(0==_wcsnicmp(p+1,L"png",3))
		imgType=png;
	else if(0==_wcsnicmp(p+1,L"bmp",3))
		imgType=dib;
	else if(0==_wcsnicmp(p+1,L"dib",3))
		imgType=dib;
	else if(0==_wcsnicmp(p+1,L"ico",3))
		imgType=dib;
	else if(0==_wcsnicmp(p+1,L"cur",3))
		imgType=dib;
	else if(0==_wcsnicmp(p+1,L"ani",3))
		imgType=dib;
	else if(0==_wcsnicmp(p+1,L"gif",3))
		imgType=gif;
	else if(0==_wcsnicmp(p+1,L"tga",3))
		imgType=tga;
	else if(0==_wcsnicmp(p+1,L"tif",3))
		imgType=tif;
	else if(0==_wcsnicmp(p+1,L"dds",3))
		imgType=dds;

	if(dcTmpImgBm)DeleteDC(dcTmpImgBm);dcTmpImgBm=0;
	if(dcTmpImgBm)DeleteObject(dcTmpImgBm);dcTmpImgBm=0;

	if(TryLoadImageWithExtension(imgFilePathAndName,p+1,&bmTmpImg,&dcTmpImgBm,&imgTmpWidth,&imgTmpHeight,&imgTmpBpp))
	{	ReplaceTemp();
		//SetFileNameForSearch(imgFilePath);
		//SetWindowText(hWndStat,imgFilePathAndName);
		CalcScrnOffst();
		imgLoadFail=FALSE;
		Render(0);
		//MyStringCpy(imgFilePathAndName,MAX_PATH,s);
	}
	return TRUE;
}

BOOL CloseImgFile()
{	return TRUE;
}