#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <windows.h>
#include <strsafe.h>
#include "imgView.h"
#include "..\..\..\Operations\MyShell\MyShellC.h"


extern int MyStringLength(wchar_t*,int);


typedef BOOL (*Load$24Tga_t)(wchar_t*,HDC*,HBITMAP*,int*,int*,int*);
Load$24Tga_t Load$24Tga=NULL;


typedef int (*GetLookupInDirCntTga_t)();
GetLookupInDirCntTga_t GetLookupInDirCntTga=NULL;
typedef BOOL (*LoadImageInDir$28Tga_t)(wchar_t*,int,HDC*,HBITMAP*,int*,int*,int*);
LoadImageInDir$28Tga_t LoadImageInDir$28Tga=NULL;


BOOL TryLoadTga(wchar_t* imgFilePathAndName,int numInLookUpDir,HBITMAP* pbm,HDC *pdc,int *width,int *height,int *bpp)
{DWORD t1,t2;BOOL rt;
 wchar_t s[MAX_PATH],*p,*pp;
	if(!hm)
	{	GetModuleFileName(NULL,s,MAX_PATH-1);
		p = wcsrchr(s,'\\');
		if(!p)return FALSE;
		*(p+1)=0;
		MyStringCpy(p+1,MAX_PATH-1-(int)(p-&s[0]),L"Plugins\\Image\\TargaRel.dll");
		if(!IsFileExist(s))
			MyStringCpy(p+1,MAX_PATH-1-(int)(p-&s[0]),L"Plugins\\Image\\TargaRel.dll");
		if(!IsFileExist(s))
			MyStringCpy(p+1,MAX_PATH-1-(int)(p-&s[0]),L"Plugins\\Image\\TargaDbg.dll");
		if(!IsFileExist(s))
			MyStringCpy(p+1,MAX_PATH-1-(int)(p-&s[0]),L"Plugins\\Image\\TargaDbg.dll");
		if(!IsFileExist(s)) return FALSE;
		hm = LoadLibrary(s);
		if(!hm)	return FALSE;

		Load$24Tga = (Load$24Tga_t)GetProcAddress(hm,"Load$24");
		GetLookupInDirCntTga = (GetLookupInDirCntTga_t)GetProcAddress(hm,"GetLookupInDirCnt");
		LoadImageInDir$28Tga = (LoadImageInDir$28Tga_t)GetProcAddress(hm,"LoadImageInDir$28");
		if((!Load$24Tga) || (!GetLookupInDirCntTga) || (!LoadImageInDir$28Tga))
		{	FreeLibrary(hm);
			return FALSE;
	}	}
	pp = &cmnt[0];
	t1=GetTickCount();

	if(numInLookUpDir<0)
	{ rt=Load$24Tga(imgFilePathAndName,pdc,pbm,width,height,bpp);
	  iInLookUpDirCnt[0]=GetLookupInDirCntTga();
	}
	//else rt=LoadImageInDir$28(imgFilePathAndName,numInLookUpDir,pdc,pbm,width,height,bpp);
	/*if(iIndirCnt>1)
	{StringCchPrintf(s,MAX_PATH,L"%d",iIndirCnt);
	 SetWindowText(hWndInDirCntEdit,s);
	} else SetWindowText(hWndInDirCntEdit,L"");*/

	//t2=GetLastError();

	t2=GetTickCount();
	//ln = MyStringLength(cmnt,2*MAX_PATH);
	//cmnt[ln++] = ' ';
	StringCchPrintfW(cmnt,MAX_PATH,L"%s: %d x %d x %d open time: %d ms",imgFilePathAndName,*width,*height,*bpp,t2-t1);

	FreeLibrary(hm);
	hm=0;
	return rt;
}