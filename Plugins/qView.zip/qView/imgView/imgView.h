#include "windows.h"

typedef unsigned char u8;
typedef unsigned __int16 u16;
typedef unsigned __int32 u32;
typedef unsigned __int64 u64;
typedef __int16 s16;
typedef __int32 s32;
typedef __int64 s64;
typedef float f32;

extern int xChldPos,yChldPos,widthChld,heightChld;
extern int xScrnOffst,yScrnOffst;
extern int imgCntrPosX,imgCntrPosY,drImgFrPosX,drImgFrPosY,imgToPosX,imgToPosY;

extern int imgWidth,imgHeight,imgBpp,imgTmpWidth,imgTmpHeight,imgTmpBpp;
extern wchar_t cmnt[2*MAX_PATH];
extern HDC dcImgBm,dcTmpImgBm;
extern HBITMAP bmImg,bmTmpImg;
extern HCURSOR	hCursorHand,hCursorArr;
extern int cursCaptFrX,cursCaptFrY,xScrnOffstInMouCapt,yScrnOffstInMouCapt;
extern HMODULE hm;//image opener module(jpgdbg,dll, as sample)
extern HINSTANCE hInst;
extern HWND hWnd;
extern int iInLookUpDirCnt[2];
extern BOOL bLoadedFin,imgLoadFail,bMouseCapture;
typedef enum TImgType
{	jpg=0,
	png=1,
	dib=2,
	gif=3,
	tga=4,
	tif=5,
	dds=6
}ImgType;
extern ImgType imgType;
extern BOOL ImageOnCreateWindow(HWND);
extern BOOL OnLoadingImgFromMenu(HWND,wchar_t*,wchar_t*);
extern BOOL TryLoadImg(wchar_t*,HBITMAP*,HDC*,int*,int*,int*);
extern VOID Render(HDC);
extern void FreeTemp();
extern void ReplaceTemp();
extern VOID CalcScrnOffst();

typedef BOOL (*LoadJPG_t)(const wchar_t*,byte**,int*,int*,int*);
extern LoadJPG_t LoadJPG;
typedef BOOL (*LoadJPGWithCmnt_t)(const wchar_t*,HBITMAP*,HDC*,int*,int*,int*,wchar_t**);
extern LoadJPGWithCmnt_t LoadJPGWithCmnt;

extern wchar_t imgFilePathAndName[MAX_PATH];
extern int imgFilePathAndNameLn;
extern BOOL bFileLoaded;
extern int language;

extern HWND hWndPnl;
//extern RECT rcPnl;

extern BOOL OpenImgFile();
extern BOOL CloseImgFile();

extern wchar_t **strngs;
extern HMODULE plgnDllInst;

extern BOOL InitViewer(HWND,wchar_t*);
extern BOOL ChangeViewFile(wchar_t*);
extern VOID CloseViewer();
extern VOID OnVScroll(WPARAM);
extern VOID LineUp(BOOL);
extern VOID LineDown(BOOL);
extern VOID PageUp();
extern VOID PageDown();
extern VOID End();
extern VOID Home();

extern int xScroll;
extern float deltaLineHScroll;

extern INT_PTR CALLBACK About(HWND,UINT,WPARAM,LPARAM);
extern BOOL OpenImgFile();
extern BOOL CloseImgFile();
extern VOID OnVScroll(WPARAM);
extern VOID OnHScroll(WPARAM);

extern BOOL TryLoadPng(wchar_t*,HBITMAP*,HDC*,int*,int*,int*);
extern BOOL TryLoadDib(wchar_t*,int,HBITMAP*,HDC*,int*,int*,int*);
extern BOOL TryLoadGif(wchar_t*,int,HBITMAP*,HDC*,int*,int*,int*);
extern BOOL TryLoadTif(wchar_t*,int,HBITMAP*,HDC*,int*,int*,int*);
extern BOOL TryLoadJpg(wchar_t*,HBITMAP*,HDC*,int*,int*,int*);
extern BOOL LoadPngImageFile(wchar_t*,BYTE**,int*,int*,int*);
extern BOOL TryLoadTga(wchar_t*,int,HBITMAP*,HDC*,int*,int*,int*);

extern DWORD getPixelBox(s32,s32,s32,s32);//,s32);
extern s32 ceil32(f32);
extern s32 floor32(f32);
extern s32 s32_max(s32,s32);
extern s32 s32_min(s32,s32);
extern s32 s32_clamp (s32,s32,s32);
extern s32 s32_log2_f32(f32);

extern int imgWidth,imgHeight,imgBpp,imgTmpWidth,imgTmpHeight,imgTmpBpp;
extern BOOL TryLoadImageWithExtension(wchar_t*,wchar_t*,HBITMAP*,HDC*,int*,int*,int*);
extern BOOL TryLoadImageExperAllExtensions(wchar_t*,HBITMAP*,HDC*,int*,int*,int*);
extern VOID DrawImage(HDC,RECT*);