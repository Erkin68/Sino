#include "windows.h"


extern int Conf_width;
extern int Conf_height;
extern int Conf_xPos;
extern int Conf_yPos;
extern int Conf_scrnSX;
extern int Conf_scrnSY;

extern __int8 Conf_originalSize;
extern __int8 Conf_horAlign;
extern __int8 Conf_verAlign;
extern __int8 Conf_drawMethod;
extern __int8 Conf_savePosition;
extern __int8 Conf_iCmnFileDlgSel;
extern int    Conf_rotDegree;


extern BOOL Conf_Read();
extern BOOL Conf_Save();
extern BOOL Conf_DefaultSettings();
