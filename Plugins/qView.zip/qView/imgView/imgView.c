#include "imgView.h"
#include "resource.h"
#include "strsafe.h"
#include "Config.h"
#include "shlobj.h"
#include "..\..\..\Operations\Myshell\MyShellC.h"


int xChldPos=150,yChldPos=0,widthChld=250,heightChld=250;
int xScrnOffst=0,yScrnOffst=0;
int imgCntrPosX=0,imgCntrPosY=0,drImgFrPosX=0,drImgFrPosY=0,imgToPosX=0,imgToPosY=0;
int iInLookUpDirCnt[2]={0,0};

wchar_t imgFilePathAndName[MAX_PATH]=L"";
int imgFilePathAndNameLn=0;
BOOL imgLoadFail=TRUE,bLoadedFin=TRUE;
BOOL bMouseCapture=FALSE;
HCURSOR	hCursorHand=NULL,hCursorArr=NULL;
int cursCaptFrX=0,cursCaptFrY=0,xScrnOffstInMouCapt=0,yScrnOffstInMouCapt=0;
__int16 capturePosX,capturePosY,capturePosToX,capturePosToY;
typedef BOOL (CALLBACK *saveOptions_t)(int,VOID*,int);
typedef BOOL (CALLBACK *readOptions_t)(int,VOID*,int);

saveOptions_t saveOptions=0;
readOptions_t readOptions=0;

int plgId = 0;

__declspec (dllexport) VOID SetCallbacks$4xxx(LPVOID frstCallback,...)
{
va_list args;
	va_start(args, frstCallback);//1
	saveOptions = (saveOptions_t)frstCallback;//1
	readOptions = (readOptions_t)va_arg(args, LPVOID);//2
va_end (args);
}

__declspec (dllexport) int GetPluginType()
{
	return 502;
}

__declspec (dllexport) const wchar_t* GetPluginName()
{
	return strngs[1];
}

__declspec (dllexport) const wchar_t* GetExtensions()
{
	return L"jpg;jpeg;bmp;png;dib;ani;cur;ico;gif;tga;tif;dds";
}

__declspec (dllexport) VOID SetId$4(int id)
{
	plgId = id;
}

__declspec (dllexport) const wchar_t* GetPluginDescription()
{
	return strngs[1];
}

__declspec (dllexport) VOID ShowOptionDialog(HWND prnt)
{
}

BOOL TryLoadImg(wchar_t* imgFilePathAndName,HBITMAP *pbm,HDC *pdc,int *w,int *h,int *bpp)
{
	switch(imgType)
	{case jpg:
		return TryLoadJpg(imgFilePathAndName,pbm,pdc,w,h,bpp);
	 case png:
		return TryLoadPng(imgFilePathAndName,pbm,pdc,w,h,bpp);
	 case dib:
		return TryLoadDib(imgFilePathAndName,-1,pbm,pdc,w,h,bpp);
	 case gif:
		return TryLoadGif(imgFilePathAndName,-1,pbm,pdc,w,h,bpp);
	 case tga:
		return TryLoadTga(imgFilePathAndName,-1,pbm,pdc,w,h,bpp);
	 case tif:
		return TryLoadTif(imgFilePathAndName,-1,pbm,pdc,w,h,bpp);
	}
	//SetParamsToControls();
	//wchar_t s[MAX_PATH];StringCchPrintf(s,MAX_PATH,L"Error opening the %s image occured...",imgFilePathAndName);
    //SetWindowText(hWndStat,s);
	return FALSE;
}

BOOL TryLoadImageWithExtension(wchar_t* imgFilePathAndName,wchar_t* ext,HBITMAP *pbm,HDC *pdc,int *w,int *h,int *bpp)
{
BOOL r=FALSE;ImgType newType=dib;
	bLoadedFin=FALSE;
	//switch(imgType)
	//{case jpg:
	if((!_wcsnicmp(ext,L"jpg",3)) || (!_wcsnicmp(ext,L"jpeg",4)))
	{	r = TryLoadJpg(imgFilePathAndName,pbm,pdc,w,h,bpp);
		newType = jpg;
	}
	else if(!_wcsnicmp(ext,L"png",3))
	{	r = TryLoadPng(imgFilePathAndName,pbm,pdc,w,h,bpp);
		newType = png;
	}
	else if((!_wcsnicmp(ext,L"bmp",3)) || (!_wcsnicmp(ext,L"dib",3)) || 
			(!_wcsnicmp(ext,L"ico",3)) || (!_wcsnicmp(ext,L"cur",3)) || (!_wcsnicmp(ext,L"ani",3)))
	{	r = TryLoadDib(imgFilePathAndName,-1,pbm,pdc,w,h,bpp);
		newType = dib;
	}
	else if(!_wcsnicmp(ext,L"gif",3))
	{	r = TryLoadGif(imgFilePathAndName,-1,pbm,pdc,w,h,bpp);
		newType = gif;
	}
	else if(!_wcsnicmp(ext,L"tga",3))
	{	r = TryLoadTga(imgFilePathAndName,-1,pbm,pdc,w,h,bpp);
		newType = tga;
	}
	else if(!_wcsnicmp(ext,L"tif",3))
	{	r = TryLoadTif(imgFilePathAndName,-1,pbm,pdc,w,h,bpp);
		newType = tif;
	}
	else if(!_wcsnicmp(ext,L"dds",3))
	{	r = TryLoadDds(imgFilePathAndName,pbm,pdc,w,h,bpp);
		newType = tif;
	}
	bLoadedFin=TRUE;
	//SetParamsToControls();
	if(!r)
	{//wchar_t s[MAX_PATH];StringCchPrintf(s,MAX_PATH,L"Error opening the %s %s image occured...",imgFilePathAndName,ext);
     //SetWindowText(hWndStat,s);
	 imgType=newType;
	}
	return r;
}

BOOL TryLoadImageExperAllExtensions(wchar_t* imgFilePathAndName,HBITMAP *pbm,HDC *pdc,int *w,int *h,int *bpp)
{
wchar_t *pext=wcsrchr(imgFilePathAndName,'.');
if(!pext)return FALSE;
return TryLoadImageWithExtension(imgFilePathAndName,pext,pbm,pdc,w,h,bpp);
}

VOID CalcScrnOffst()
{SCROLLINFO si;
 if(0==Conf_originalSize)
 {	xScrnOffst=yScrnOffst=0;ZeroMemory(&si,sizeof(si));
	si.fMask=SIF_RANGE;si.nMin=si.nMax=0;
	SetScrollInfo(hWndPnl,SB_HORZ,&si,TRUE);
	SetScrollInfo(hWndPnl,SB_VERT,&si,TRUE);
	return;
 }//else:
 ZeroMemory(&si,sizeof(si));
 si.fMask=SIF_RANGE|SIF_POS|SIF_PAGE;
 si.nMin=0;
 si.nMax=imgWidth-widthChld;
 if(si.nMax<0)si.nMax=0;
 si.nPage=imgWidth/(widthChld>0?widthChld:1);
 if(imgCntrPosX>0)
 {int dx=imgCntrPosX-widthChld/2;
  if(dx<0)dx=0;
  if(imgWidth>widthChld)
   si.nPos=xScrnOffst=si.nMin + (si.nMax-si.nMin) * (int)((float)dx/(float)(imgWidth-widthChld));
 }
 SetScrollInfo(hWndPnl,SB_HORZ,&si,TRUE);

 si.nMin=0;
 si.nMax=imgHeight-heightChld;
 if(si.nMax<0)si.nMax=0;
 si.nPage=heightChld/(imgHeight>0?imgHeight:1);
 {int dy=imgCntrPosY-heightChld/2;
  if(dy<0)dy=0;
  if(imgHeight>heightChld)
   si.nPos=yScrnOffst=si.nMin + (si.nMax-si.nMin) * (int)((float)dy/(float)(imgHeight-heightChld));
 }
 SetScrollInfo(hWndPnl,SB_VERT,&si,TRUE);
}

HFONT FAR PASCAL MyCreateFont(void)
{ 
LOGFONT lf; 
HFONT hfont; 
 
    // Initialize members of the CHOOSEFONT structure. 
	/*CHOOSEFONT cf; 
    cf.lStructSize = sizeof(CHOOSEFONT); 
    cf.hwndOwner = (HWND)NULL; 
    cf.hDC = (HDC)NULL; 
    cf.lpLogFont = &lf; 
    cf.iPointSize = 0; 
    cf.Flags = CF_SCREENFONTS; 
    cf.rgbColors = RGB(0,0,0); 
    cf.lCustData = 0L; 
    cf.lpfnHook = (LPCFHOOKPROC)NULL; 
    cf.lpTemplateName = (LPWSTR)NULL; 
    cf.hInstance = (HINSTANCE) NULL; 
    cf.lpszStyle = (LPWSTR)NULL; 
    cf.nFontType = SCREEN_FONTTYPE; 
    cf.nSizeMin = 0; 
    cf.nSizeMax = 0; 

    // Display the CHOOSEFONT common-dialog box. 
 
    ChooseFont(&cf); */
 
    // Create a logical font based on the user's 
    // selection and return a handle identifying 
    // that font. 

    lf.lfHeight = -11;
    lf.lfWidth = 0;
    lf.lfEscapement = 0;
    lf.lfOrientation = 0;
    lf.lfWeight = 400;
    lf.lfItalic = 255;
    lf.lfUnderline = 0;
    lf.lfStrikeOut = 0;
    lf.lfCharSet = 0;
	lf.lfOutPrecision = 3;
    lf.lfClipPrecision = 2;
    lf.lfQuality = 1;
    lf.lfPitchAndFamily = 34;
    MyStringCpy(lf.lfFaceName,32,L"Arial Narrow");
 
    hfont = CreateFontIndirect(&lf);//cf.lpLogFont); 
    return (hfont); 
}