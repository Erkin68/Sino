#pragma warning (disable:4996)

#include "Config.h"
#include "stdio.h"


int Conf_width=-1;
int Conf_height=-1;
int Conf_xPos=-1;
int Conf_yPos=-1;

__int8 Conf_originalSize=0;
__int8 Conf_horAlign=1;
__int8 Conf_verAlign=1;
__int8 Conf_drawMethod=0;
__int8 Conf_savePosition;
__int8 Conf_iCmnFileDlgSel;
int    Conf_rotDegree;

int Conf_scrnSX;
int Conf_scrnSY;



BOOL Conf_Save()
{
wchar_t *p,s[MAX_PATH];FILE *f;int l=GetModuleFileName(NULL,s,MAX_PATH);
	p=wcsrchr(s,'\\');if(!p)p=&s[l];else++p;
	wcscpy(p,L"ImgVw.cnf");
	f=_wfopen(s,L"wb");
	if(!f)//default settings:
	 return FALSE;
	fwrite(&Conf_originalSize,sizeof(Conf_originalSize),1,f);
	fwrite(&Conf_horAlign,sizeof(Conf_horAlign),1,f);
	fwrite(&Conf_verAlign,sizeof(Conf_verAlign),1,f);
	fwrite(&Conf_drawMethod,sizeof(Conf_drawMethod),1,f);
	fwrite(&Conf_savePosition,sizeof(Conf_savePosition),1,f);
	fwrite(&Conf_iCmnFileDlgSel,sizeof(Conf_iCmnFileDlgSel),1,f);

	fwrite(&Conf_width,sizeof(Conf_width),1,f);
	fwrite(&Conf_height,sizeof(Conf_height),1,f);
	fwrite(&Conf_xPos,sizeof(Conf_xPos),1,f);
	fwrite(&Conf_yPos,sizeof(Conf_yPos),1,f);
	fwrite(&Conf_rotDegree,sizeof(Conf_rotDegree),1,f);
	fclose(f);
	return TRUE;
}

BOOL Conf_Read()
{
wchar_t *p,s[MAX_PATH];FILE *f;int l=GetModuleFileName(NULL,s,MAX_PATH);
Conf_scrnSX=GetSystemMetrics(SM_CXSCREEN);
Conf_scrnSY=GetSystemMetrics(SM_CYSCREEN);

	p=wcsrchr(s,'\\');if(!p)p=&s[l];else++p;
	wcscpy(p,L"ImgVw.cnf");
	f=_wfopen(s,L"rb");
	if(!f)//default settings:
	 return Conf_DefaultSettings();

	fread(&Conf_originalSize,sizeof(Conf_originalSize),1,f);
	fread(&Conf_horAlign,sizeof(Conf_horAlign),1,f);
	fread(&Conf_verAlign,sizeof(Conf_verAlign),1,f);
	fread(&Conf_drawMethod,sizeof(Conf_drawMethod),1,f);
	fread(&Conf_savePosition,sizeof(Conf_savePosition),1,f);
	fread(&Conf_iCmnFileDlgSel,sizeof(Conf_iCmnFileDlgSel),1,f);
	if(Conf_iCmnFileDlgSel<0 || Conf_iCmnFileDlgSel>2)Conf_iCmnFileDlgSel=0;
	fread(&Conf_width,sizeof(Conf_width),1,f);
	fread(&Conf_height,sizeof(Conf_height),1,f);
	fread(&Conf_xPos,sizeof(Conf_xPos),1,f);
	fread(&Conf_yPos,sizeof(Conf_yPos),1,f);
	fread(&Conf_rotDegree,sizeof(Conf_rotDegree),1,f);
	fclose(f);
	return TRUE;
}

BOOL Conf_DefaultSettings()
{Conf_savePosition=1;
 Conf_horAlign=1;
 Conf_verAlign=1;
 Conf_drawMethod=0;
 Conf_originalSize=1;
 Conf_iCmnFileDlgSel=0;
 Conf_rotDegree=0;
 return TRUE;
}