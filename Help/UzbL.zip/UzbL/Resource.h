//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by SinoHlp32.rc
//
#define ID_FIND                         2
#define ID_CONTENTS                     3
#define ID_INDEX                        4
#define ID_SEARCH                       5
#define ID_PREV                         6
#define ID_NEXT                         7
#define ID_PREV_STEP                    8
#define ID_NEXT_STEP                    9
#define IDS_STRING_CONTENTS             10
#define IDS_STRING_INDEX                11
#define IDS_STRING_SEARCH               12
#define IDS_STRING_PREV                 13
#define IDS_STRING_NEXT                 14
#define IDS_STRING_PREV_STEP            15
#define IDS_STRING_NEXT_STEP            16
#define IDS_STRING_FIND                 17
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             101
#define IDR_MAINFRAME                   102
#define IDR_SinoSHlp32TYPE              106
#define IDR_HTML_MAIN                   135
#define IDR_HTML_SEL_SOZDANIYA          136
#define IDR_HTML_CHEM_OTLICHAYETCYA     137
#define IDR_HTML_LICENSE                138
#define IDR_HTML_LICENSE_ZLIB           139
#define IDR_HTML_LICENSE_UNRAR          140
#define IDR_HTML_LICENSE_PNG            141
#define IDR_HTML_LICENSE_MS             142
#define IDR_HTML_LICENSE_JPG            143
#define IDR_HTML_LICENSE_CHM            144
#define IDR_HTML_LICENSE_7ZIP           145
#define IDR_HTML_LICENSE_KRATKAYA_INFO  146
#define IDR_HTML_LICENSE_UDEFRAG        147
#define IDR_HTML_GNU_LICENSE            148
#define IDR_HTML_LICENSE_WINPCAP		149
#define IDR_HTML_LICENSE_SINO           150
#define IDR_HTML_LICENSE_GIF			151
#define IDR_HTML_LICENSE_NOTEPAD		152
#define IDR_HTML_HOT_KEYS				153
#define IDR_HTML_CHANGE_HOT_KEYS		154
#define IDR_HTML_FILE_ASSOCIATIONS		155
#define IDR_HTML_VIEW_FILES				156
#define IDR_HTML_QUICK_VIEW_FILES		157
#define IDR_HTML_GUID_FOLDERS			158
#define IDR_HTML_CONNECT_VIA_TCP_IP		159
#define IDR_HTML_IP4_ADAPTER_SCANER		160
#define IDB_SINO                        252
#define IDI_ICON_BOOK                   253
#define IDI_ICON_QUEST                  254
#define IDI_ICON_PAPER                  255
#define IDI_ICON_OPEN_BOOK              256
#define IDD_DIALOG_FIND_TEXT            257
#define IDD_DIALOG_PROGRESS             258
#define IDI_STATIC                      1001
#define IDC_EDIT_FIND_TEXT              1002
#define IDC_PROGRESS                    1003
#define IDC_EDIT_PROGRESS               1004
#define ID_EDIT_SELECTALL               32774
#define ID_FONTS_SMALL                  32777
#define ID_FONTS_MEDIUM                 32778
#define ID_FONTS_BIG                    32779
#define ID_EDIT_CLEARSELECTION          32780
#define ID_FONTS_LARGEST                32782
#define ID_FONTS_LARGE                  32783
#define IDM_EDIT_COPY                   32788

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        223
#define _APS_NEXT_COMMAND_VALUE         32798
#define _APS_NEXT_CONTROL_VALUE         1005
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
