#include <shlobj.h>
#include <shlwapi.h>
#include <strsafe.h>

int EnumInDesktop();
int EnumInMyComp();

int main()
{
	//EnumInDesktop();
	EnumInMyComp();
}

int EnumInDesktop()
{
    IShellFolder *psfDeskTop = NULL;
    LPITEMIDLIST pidlItems = NULL;
    IEnumIDList *ppenum = NULL;
    STRRET strDispName;
    TCHAR szParseName[MAX_PATH];
    TCHAR szSourceFiles[256];
    unsigned int i;
    int iBufPos = 0;
    ULONG celtFetched;
    size_t ParseNameSize = 0;
    HRESULT hr;
	

    szSourceFiles[0] = '\0';
    hr = SHGetDesktopFolder(&psfDeskTop);
    hr = psfDeskTop->EnumObjects(NULL,SHCONTF_FOLDERS|SHCONTF_NONFOLDERS,//|SHCONTF_INCLUDEHIDDEN|
									//SHCONTF_INIT_ON_FIRST_NEXT|SHCONTF_NETPRINTERSRCH|
									//SHCONTF_SHAREABLE|SHCONTF_STORAGE|SHCONTF_FASTITEMS|
									//SHCONTF_FLATLIST|SHCONTF_ENABLE_ASYNC,
									&ppenum);
    while( (hr = ppenum->Next(1,&pidlItems, &celtFetched)) == S_OK 
       && (celtFetched) == 1)
    {
        psfDeskTop->GetDisplayNameOf(pidlItems, SHGDN_FORPARSING, 
            &strDispName);
        StrRetToBuf(&strDispName, pidlItems, szParseName, MAX_PATH);
		
        hr = StringCchLength(szParseName, MAX_PATH, &ParseNameSize);
		
        if (SUCCEEDED(hr))
        {
            for(i=0; i<=ParseNameSize; i++)
            {
                szSourceFiles[iBufPos++] = szParseName[i];
            }
            CoTaskMemFree(pidlItems);
			iBufPos=0;
        }
    }
    ppenum->Release();
    psfDeskTop->Release();
    return 0;
}

int EnumInMyComp()
{
    IShellFolder *psfDeskTop = NULL;
    IShellFolder *psfMyComputer = NULL;
    LPITEMIDLIST pidlMyComputer = NULL;
    LPITEMIDLIST pidlItems = NULL;
    IEnumIDList *ppenum = NULL;
    STRRET strDispName;
    TCHAR szParseName[MAX_PATH];
    TCHAR szSourceFiles[256];
    unsigned int i;
    int iBufPos = 0;
    ULONG chEaten;
    ULONG celtFetched;
    size_t ParseNameSize = 0;
    HRESULT hr;
	

    szSourceFiles[0] = '\0';
    hr = SHGetDesktopFolder(&psfDeskTop);

    hr = psfDeskTop->ParseDisplayName(NULL, NULL, L"::{20D04FE0-3AEA-1069-A2D8-08002B30309D}",
         &chEaten, &pidlMyComputer, NULL);
    hr = psfDeskTop->BindToObject(pidlMyComputer, NULL, IID_IShellFolder, 
         (LPVOID *) &psfMyComputer);
    hr = psfDeskTop->Release();

    hr = psfMyComputer->EnumObjects(NULL,SHCONTF_FOLDERS|SHCONTF_NONFOLDERS,//|SHCONTF_INCLUDEHIDDEN|
									//SHCONTF_INIT_ON_FIRST_NEXT|SHCONTF_NETPRINTERSRCH|
									//SHCONTF_SHAREABLE|SHCONTF_STORAGE|SHCONTF_FASTITEMS|
									//SHCONTF_FLATLIST|SHCONTF_ENABLE_ASYNC,
									&ppenum);
    while( (hr = ppenum->Next(1,&pidlItems, &celtFetched)) == S_OK 
       && (celtFetched) == 1)
    {
        psfMyComputer->GetDisplayNameOf(pidlItems, SHGDN_FORPARSING, 
            &strDispName);
        StrRetToBuf(&strDispName, pidlItems, szParseName, MAX_PATH);
		
        hr = StringCchLength(szParseName, MAX_PATH, &ParseNameSize);
		
//"::{20D04FE0-3AEA-1069-A2D8-08002B30309D}\::{21EC2020-3AEA-1069-A2DD-08002B30309D}" MyComp ning o'zi;
//"C:\Documents and Settings\All Users\���������"

		//SHFOLDERCUSTOMSETTINGS fcs;WCHAR presMemPtr[MAX_PATH];
		//MultiByteToWideChar(CP_ACP,MB_PRECOMPOSED,szParseName,MAX_PATH,presMemPtr,MAX_PATH);
		//if(S_OK==SHGetSetFolderCustomSettings(&fcs,presMemPtr,FCS_READ))
		//	fcs=fcs;

        if (SUCCEEDED(hr))
        {
            for(i=0; i<=ParseNameSize; i++)
            {
                szSourceFiles[iBufPos++] = szParseName[i];
            }
            CoTaskMemFree(pidlItems);
			iBufPos=0;
        }
    }
    ppenum->Release();
	
    //hr = SHFileOperation(&sfo);
	//SHChangeNotify(SHCNE_UPDATEDIR, SHCNF_PATH, (LPCVOID) "c:\\My_Docs2", 0);
    CoTaskMemFree(pidlMyComputer);
    psfMyComputer->Release();
    return 0;
}
