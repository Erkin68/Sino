#define _CRT_SECURE_NO_WARNINGS
#define FOPEN_FUNC(filename, mode) fopen64(filename, mode)
#define FTELLO_FUNC(stream) ftello64(stream)
#define FSEEKO_FUNC(stream, offset, origin) fseeko64(stream, offset, origin)

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <errno.h>
#include <fcntl.h>

#include <direct.h>
#include <io.h>
#include "zip.h"

#define USEWIN32IOAPI
#include "iowin32.h"


uLong filetime(char *f, tm_zip *tmzip,uLong *dt)
             /* name of file to get info on */
             /* return value: access, modific. and creation times */
             /* dostime */
{
	int ret = 0;
	FILETIME ftLocal;
	HANDLE hFind;
	WIN32_FIND_DATAA ff32;

	hFind = FindFirstFileA((char*)f,&ff32);
	if (hFind != INVALID_HANDLE_VALUE)
	{	FileTimeToLocalFileTime(&(ff32.ftLastWriteTime),&ftLocal);
		FileTimeToDosDateTime(&ftLocal,((LPWORD)dt)+1,((LPWORD)dt)+0);
		FindClose(hFind);
		ret = 1;
	}
	return ret;
}

int check_exist_file(const char *filename)
{
	FILE* ftestexist;
    int ret = 1;
    ftestexist = FOPEN_FUNC(filename,"rb");
    if(ftestexist==NULL)
        ret = 0;
    else
        fclose(ftestexist);
    return ret;
}

/*void do_banner()
{
    printf("MiniZip 1.1, demo of zLib + MiniZip64 package, written by Gilles Vollant\n");
    printf("more info on MiniZip at http://www.winimage.com/zLibDll/minizip.html\n\n");
}

void do_help()
{
    printf("Usage : minizip [-o] [-a] [-0 to -9] [-p password] [-j] file.zip [files_to_add]\n\n" \
           "  -o  Overwrite existing file.zip\n" \
           "  -a  Append to existing file.zip\n" \
           "  -0  Store only\n" \
           "  -1  Compress faster\n" \
           "  -9  Compress better\n\n" \
           "  -j  exclude path. store only the file name.\n\n");
}*/

/* calculate the CRC32 of a file,
   because to encrypt a file, we need known the CRC32 of the file before */
int getFileCrc(const char* filenameinzip,void*buf,unsigned long size_buf,unsigned long* result_crc)
{
	unsigned long calculate_crc=0;
	int err=ZIP_OK;
	FILE * fin = FOPEN_FUNC((char*)filenameinzip,"rb");

	unsigned long size_read = 0;
	unsigned long total_read = 0;
	if(fin==NULL)
	{
		err = ZIP_ERRNO;
	}

	if(err == ZIP_OK)
	{	do
		{
			err = ZIP_OK;
			size_read = (int)fread(buf,1,size_buf,fin);
			if (size_read < size_buf)
				if (feof(fin)==0)
			{
				//printf("error in reading %s\n",filenameinzip);
				err = ZIP_ERRNO;
			}

			if (size_read>0)
				calculate_crc = crc32(calculate_crc,(const Bytef*)buf,size_read);
			total_read += size_read;

		} while ((err == ZIP_OK) && (size_read>0));
	}

	if (fin)
        fclose(fin);

    *result_crc=calculate_crc;
    //printf("file %s crc %lx\n", filenameinzip, calculate_crc);
    return err;
}

int isLargeFile(const char* filename)
{
	int largeFile = 0;
	ZPOS64_T pos = 0;
	FILE* pFile = FOPEN_FUNC((char*)filename, "rb");

	if(pFile != NULL)
	{	int n = FSEEKO_FUNC(pFile, 0, SEEK_END);
		pos = FTELLO_FUNC(pFile);
        //printf("File : %s is %lld bytes\n", filename, pos);

		if(pos >= 0xffffffff)
			largeFile = 1;

		fclose(pFile);
	}

	return largeFile;
}

int zipFiles(char *zipFileName,char* fileNames,int numFiles,int optn)
{
bool fileOverwrite=false;
	if(check_exist_file(zipFileName)==1)
	{	if(IDNO==MessageBox(NULL,"File already exist,overwrite existing?",
							zipFileName,MB_YESNO))
			return 0;
		fileOverwrite = true;		
	}
	//zipFile zf;
    //int errclose;
    //zlib_filefunc64_def ffunc;
    //fill_win32_filefunc64A(&ffunc);
    //zf = zipOpen2_64(zipFileName,(opt_overwrite==2) ? 2 : 0,NULL,&ffunc);
	return 1;
}
