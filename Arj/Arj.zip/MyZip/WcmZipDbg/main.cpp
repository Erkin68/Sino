#include "windows.h"


BOOL WINAPI DllMain(HANDLE hModule,DWORD  ul_reason_for_call,LPVOID lpReserved)
{
	switch(ul_reason_for_call)
	{
		case DLL_PROCESS_ATTACH:
			break;
		case DLL_THREAD_ATTACH:
		case DLL_THREAD_DETACH:
			break;
		case DLL_PROCESS_DETACH:
			break;
    }
  return( TRUE );
}

extern "C"
{

DWORD __stdcall _DecryptAESMemoryCBC_16(DWORD par1,DWORD par2,DWORD par3,DWORD par4)
{
	return 0;
}

DWORD __stdcall _DecryptZipAES_12(DWORD par1,DWORD par2,DWORD par3)
{
	return 0;
}

DWORD __stdcall _DeflateChunk_32(DWORD par1,DWORD par2,DWORD par3,DWORD par4,
								 DWORD par5,DWORD par6,DWORD par7,DWORD par8)
{
	return 0;
}

DWORD __stdcall _DoneDeflate_4(DWORD par1)
{
	return 0;
}

DWORD __stdcall _EncryptAESMemoryCBC_20(DWORD par1,DWORD par2,DWORD par3,DWORD par4,DWORD par5)
{
	return 0;
}

DWORD __stdcall _EncryptZipAES_12(DWORD par1,DWORD par2,DWORD par3)
{
	return 0;
}

DWORD __stdcall _EndZipAES_8(DWORD par1,DWORD par2)
{
	return 0;
}

DWORD __stdcall _file_compress_24(DWORD par1,DWORD par2,DWORD par3,
								  DWORD par4,DWORD par5,DWORD par6)
{
	return 0;
}

DWORD __stdcall _GetKeys_12(DWORD par1,DWORD par2,DWORD par3)
{
	return 0;
}

DWORD __stdcall _GetRandomData_8(DWORD par1,DWORD par2)
{
	return 0;
}

DWORD __stdcall _InitZipAES_24(DWORD par1,DWORD par2,DWORD par3,
							   DWORD par4,DWORD par5,DWORD par6)
{
	return 0;
}

DWORD __stdcall _StartDeflate_12(DWORD par1,DWORD par2,DWORD par3)
{
	return 0;
}

DWORD __stdcall _UpdateOnlyCrc_12(DWORD par1,DWORD par2,DWORD par3)
{
	return 0;
}

}