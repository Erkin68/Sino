#ifndef _MY_ZLIB_H__
#define _MY_ZLIB_H__

#include "windows.h"
#include "zip.h"
#include "unzip.h"



class CArcThrd;
class CZLib
{
public:
			CZLib();
	BOOL	Add(char*,CArcThrd*);
	BOOL	CreateDir(char*,CArcThrd*);
	BOOL	Open(CArcThrd*,int);
	BOOL	Close(CArcThrd*);
protected:
	zipFile zf;
	unzFile unzpf;
    zlib_filefunc64_def ffuncZip,ffuncUnzip;
	int		opt_compress_level,iAppend;
enum
{	disk,
	himem,
	pagefile
} pakcType;
};

#define WRITEBUFFERSIZE (16384)
#define MAXFILENAME (256)
	extern uLong filetime(char*,tm_zip*,uLong*);
	extern int check_exist_file(const char*);
	extern int getFileCrc(const char*,void*,unsigned long,unsigned long*);
	extern int isLargeFile(const char*);
	extern int zipFiles(char*,char*,int,int);


#endif