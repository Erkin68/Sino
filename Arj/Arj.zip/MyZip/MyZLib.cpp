#define _CRT_SECURE_NO_WARNINGS

#include "MyZLib.h"
#include "unzip.h"
#include "iowin32.h"
#include "..\Archive.h"
#include "..\..\Operations\MyErrors.h"



#define WRITEBUFFERSIZE (16384)
#define FOPEN_FUNC(filename, mode) fopen64(filename, mode)
#define FTELLO_FUNC(stream) ftello64(stream)
#define FSEEKO_FUNC(stream, offset, origin) fseeko64(stream, offset, origin) 


CZLib::CZLib():zf(0),unzpf(0),pakcType(disk)
{
}

BOOL CZLib::Add(char *name,CArcThrd *arc)
{
	if(!zf)return FALSE;
    FILE * fin;
    int size_read;
    const char *savefilenameinzip;
    zip_fileinfo zi;
    unsigned long crcFile=0;
    int zip64 = 0;
	int err=0;
	int size_buf=0;
	void* buf=NULL;

    zi.tmz_date.tm_sec = zi.tmz_date.tm_min = zi.tmz_date.tm_hour =
    zi.tmz_date.tm_mday = zi.tmz_date.tm_mon = zi.tmz_date.tm_year = 0;
    zi.dosDate = 0;
    zi.internal_fa = 0;
    zi.external_fa = 0;
    filetime(name,&zi.tmz_date,&zi.dosDate);
/*
    err = zipOpenNewFileInZip(zf,filenameinzip,&zi,
                              NULL,0,NULL,0,NULL / * comment * /,
                              (opt_compress_level != 0) ? Z_DEFLATED : 0,
                              opt_compress_level);
*/
	if ((arc->password != NULL) && (err==ZIP_OK))
    err = getFileCrc(name,buf,size_buf,&crcFile);

    zip64 = isLargeFile(name);

    /* The path name saved, should not include a leading slash. */
    /*if it did, windows/xp and dynazip couldn't read the zip file. */
    savefilenameinzip = name;
    while(savefilenameinzip[0] == '\\' || savefilenameinzip[0] == '/')
		savefilenameinzip++;

	/*should the zip file contain any path at all?*/
    if(arc->bExcldPath)
	{	const char *tmpptr;
        const char *lastslash = 0;
        for(tmpptr = savefilenameinzip; *tmpptr; tmpptr++)
        {	if(*tmpptr == '\\' || *tmpptr == '/')
				lastslash = tmpptr;
		}
        if(lastslash != NULL)
			savefilenameinzip = lastslash+1; // base filename follows last slash.
	}
	else
	{	char *srcPath = panel[arc->srcPanel].GetPath();
		for(const char *tmpptr = savefilenameinzip; *tmpptr; tmpptr++)
        {	if(*tmpptr != *srcPath++)
			{	savefilenameinzip = tmpptr;
				break;
	}	}	}

	wchar_t s[MAX_PATH];char c[MAX_PATH];
	MultiByteToWideChar(CP_ACP,MB_PRECOMPOSED,savefilenameinzip,MAX_PATH,s,MAX_PATH);
	WideCharToMultiByte(CP_OEMCP,0,s,-1,c,MAX_PATH,NULL,NULL);

	/**/
    err = zipOpenNewFileInZip3_64(zf,c/*savefilenameinzip*/,&zi,
                     NULL,0,NULL,0,NULL /* comment*/,
                     (opt_compress_level != 0) ? Z_DEFLATED : 0,
                     opt_compress_level,0,
                     /* -MAX_WBITS, DEF_MEM_LEVEL, Z_DEFAULT_STRATEGY, */
                     -MAX_WBITS, DEF_MEM_LEVEL, Z_DEFAULT_STRATEGY,
					 arc->password[0]?arc->password:NULL,
					 crcFile, zip64);

    if(err != ZIP_OK)
	{	Err::msg1(err,"error in opening in zipfile",name);
		return FALSE;
	}
    else
    {	fin = FOPEN_FUNC(name,"rb");
        if (fin==NULL)
        {   err=ZIP_ERRNO;
			Err::msg1(err,"error in opening for reading",name);
			return FALSE;
	}	}

	size_buf = WRITEBUFFERSIZE;
    buf = (void*)malloc(size_buf);
    if (buf==NULL)
	{   Err::msg1(err,"Error allocating memory in zip.Add.",name);
		return FALSE;
    }

	unsigned __int64 alrdyReaded=0;
    if(err == ZIP_OK)
    do
    {	err = ZIP_OK;
        size_read = (int)fread(buf,1,size_buf,fin);
        if(size_read < size_buf)if (feof(fin)==0)
        {	err = ZIP_ERRNO;
			Err::msg1(err,"error in reading",name);
			free(buf);
			return FALSE;
        }

        if(size_read>0)
        {	err = zipWriteInFileInZip(zf,buf,size_read);
            if(err<0)
            {	Err::msg1(err,"error in writing in the zipfile",name);
				free(buf);
				return FALSE;
        }	}
		alrdyReaded+=size_read;
		arc->arcPrgrssRout(&alrdyReaded);
	}
	while((err == ZIP_OK) && (size_read>0));

    if(fin)
        fclose(fin);

    if(err<0)
        err=ZIP_ERRNO;
    else
    {	err = zipCloseFileInZip(zf);
        if (err!=ZIP_OK)
		{	Err::msg1(err,"error in closing in the zipfile",name);
			free(buf);
			return FALSE;
	}	}
	free(buf);
	return TRUE;
}

BOOL CZLib::CreateDir(char *name,CArcThrd *arc)
{
	if(!zf)return FALSE;
    const char *savefilenameinzip;
    zip_fileinfo zi;
    int zip64 = 0;
	int err=0;

    if(unzLocateFile(unzpf,name,0/*CASESENSITIVITY*/)!=0/*UNZ_OK*/)
		return 2;

    zi.tmz_date.tm_sec = zi.tmz_date.tm_min = zi.tmz_date.tm_hour =
    zi.tmz_date.tm_mday = zi.tmz_date.tm_mon = zi.tmz_date.tm_year = 0;
    zi.dosDate = 0;
    zi.internal_fa = 0;
    zi.external_fa = 0x30;
    filetime(name,&zi.tmz_date,&zi.dosDate);
/*
    err = zipOpenNewFileInZip(zf,filenameinzip,&zi,
                              NULL,0,NULL,0,NULL / * comment * /,
                              (opt_compress_level != 0) ? Z_DEFLATED : 0,
                              opt_compress_level);
*/
	if ((arc->password != NULL) && (err==ZIP_OK))

    zip64 = isLargeFile(name);

    /* The path name saved, should not include a leading slash. */
    /*if it did, windows/xp and dynazip couldn't read the zip file. */
    savefilenameinzip = name;
    while(savefilenameinzip[0] == '\\' || savefilenameinzip[0] == '/')
		savefilenameinzip++;

	/*should the zip file contain any path at all?*/
    if(arc->bExcldPath)
	{	const char *tmpptr;
        const char *lastslash = 0;
        for(tmpptr = savefilenameinzip; *tmpptr; tmpptr++)
        {	if(*tmpptr == '\\' || *tmpptr == '/')
				lastslash = tmpptr;
		}
        if(lastslash != NULL)
			savefilenameinzip = lastslash+1; // base filename follows last slash.
	}
	else
	{	char *srcPath = panel[arc->srcPanel].GetPath();
		for(const char *tmpptr = savefilenameinzip; *tmpptr; tmpptr++)
        {	if(*tmpptr != *srcPath++)
			{	savefilenameinzip = tmpptr;
				break;
		}	}
		strcat((char*)savefilenameinzip,"\\");
	}

	wchar_t s[MAX_PATH];char c[MAX_PATH];
	MultiByteToWideChar(CP_ACP,MB_PRECOMPOSED,savefilenameinzip,MAX_PATH,s,MAX_PATH);
	WideCharToMultiByte(CP_OEMCP,0,s,-1,c,MAX_PATH,NULL,NULL);

	/**/
    err = zipOpenNewFileInZip4(zf,c/*savefilenameinzip*/,&zi,
                     NULL,0,NULL,0,NULL /* comment*/,
                     (opt_compress_level != 0) ? Z_DEFLATED : 0,
                     opt_compress_level,1,
                     /* -MAX_WBITS, DEF_MEM_LEVEL, Z_DEFAULT_STRATEGY, */
                     -MAX_WBITS, DEF_MEM_LEVEL, Z_DEFAULT_STRATEGY,
					 arc->password[0]?arc->password:NULL,0,14,2);

    if(err != ZIP_OK)
	{	Err::msg1(err,"error in opening in zipfile",name);
		return FALSE;
	}
    else
    {	err = zipCloseFileInZip(zf);
        if (err!=ZIP_OK)
		{	Err::msg1(err,"error in closing in the zipfile",name);
			return FALSE;
	}	}
	return TRUE;
}

BOOL CZLib::Open(CArcThrd* thrd,int iArcFileExist)
{
	iAppend = iArcFileExist;
	if(iAppend==2)
	{	//Found the packtype:
		if(packType==disk)
		{	fill_win32_filefunc64A(&ffuncUnzip);
			unzpf = unzOpen2_64(thrd->name,&ffuncUnzip);
			
			fill_win32_filefunc64A(&ffuncZip);
			thrd->name[thrd->nameLn-1]='#';
			zf = zipOpen2_64(thrd->name,0,NULL,&ffuncZip);
			thrd->name[thrd->nameLn-1]='p';
			if(!zf)
			{	Err::msg1(0,"Err.opening zip file.",thrd->name);
				return FALSE;
	}	}	}
	else
	{	fill_win32_filefunc64A(&ffuncZip);
		zf = zipOpen2_64(thrd->name,0,NULL,&ffuncZip);
		if(!zf)
		{	Err::msg1(0,"Err.opening zip file.",thrd->name);
			return FALSE;
	}	}
	opt_compress_level = (int)(thrd->cmqlev * 9.f);
	return TRUE;
}

BOOL CZLib::Close(CArcThrd* thrd)
{
	if(iAppend==2)
	{	zipClose(zf,NULL);
		zf=0;
		unzClose(unzpf);
		unzpf = 0;
		char apndFile[MAX_PATH];
		int ln=MyStringCpy(apndFile,MAX_PATH,thrd->name);
		apndFile[ln]='#';
		return MyMoveFile(apndFile,thrd->name);
	}
	else
	{	zipClose(zf,NULL);
		zf=0;
	}
	return TRUE;
}