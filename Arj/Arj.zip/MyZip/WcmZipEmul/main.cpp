#include "windows.h"

HMODULE hOrig,hDbg;


typedef DWORD (__stdcall* _DecryptAESMemoryCBC_16_t)(DWORD,DWORD,DWORD,DWORD);
typedef DWORD (__stdcall* _DecryptZipAES_12_t)(DWORD,DWORD,DWORD);
typedef DWORD (__stdcall* _DeflateChunk_32_t)(DWORD,DWORD,DWORD,DWORD,DWORD,DWORD,DWORD,DWORD);
typedef DWORD (__stdcall* _DoneDeflate_4_t)(DWORD);
typedef DWORD (__stdcall* _EncryptZipAES_12_t)(DWORD,DWORD,DWORD);
typedef DWORD (__stdcall* _EncryptAESMemoryCBC_20_t)(DWORD,DWORD,DWORD,DWORD,DWORD);
typedef DWORD (__stdcall* _EndZipAES_8_t)(DWORD,DWORD);
typedef DWORD (__stdcall* _file_compress_24_t)(DWORD,DWORD,DWORD,DWORD,DWORD,DWORD);
typedef DWORD (__stdcall* _GetKeys_12t)(DWORD,DWORD,DWORD);
typedef DWORD (__stdcall* _GetRandomData_8_t)(DWORD,DWORD);
typedef DWORD (__stdcall* _InitZipAES_24_t)(DWORD,DWORD,DWORD,DWORD,DWORD,DWORD);
typedef DWORD (__stdcall* _StartDeflate_12_t)(DWORD,DWORD,DWORD);
typedef DWORD (__stdcall* _UpdateOnlyCrc_12_t)(DWORD,DWORD,DWORD);

_DecryptAESMemoryCBC_16_t origDecryptAESMemoryCBC,dbgDecryptAESMemoryCBC;
_DecryptZipAES_12_t origDecryptZipAES,dbgDecryptZipAES;
_DeflateChunk_32_t origDeflateChunk,dbgDeflateChunk;
_DoneDeflate_4_t origDoneDeflate,dbgDoneDeflate;
_EncryptZipAES_12_t origEncryptZipAES,dbgEncryptZipAES;
_EncryptAESMemoryCBC_20_t origEncryptAESMemoryCBC,dbgEncryptAESMemoryCBC;
_EndZipAES_8_t origEndZipAES,dbgEndZipAES;
_file_compress_24_t origfile_compress,dbgfile_compress;
_GetKeys_12t origGetKeys,dbgGetKeys;
_GetRandomData_8_t origGetRandomData,dbgGetRandomData;
_InitZipAES_24_t origInitZipAES,dbgInitZipAES;
_StartDeflate_12_t origStartDeflate,dbgStartDeflate;
_UpdateOnlyCrc_12_t origUpdateOnlyCrc,dbgUpdateOnlyCrc;


BOOL WINAPI DllMain(HANDLE hModule,DWORD  ul_reason_for_call,LPVOID lpReserved)
{
	switch(ul_reason_for_call)
	{
		case DLL_PROCESS_ATTACH:
			hOrig = LoadLibrary("Wcmzip32pr.dll");
			hDbg = LoadLibrary("D:\\Savar\\Auxilary\\Sino\\Arj\\MyZip\\WcmZipDbg\\Debug\\WcmZipDbg.dll");

			origDecryptAESMemoryCBC = (_DecryptAESMemoryCBC_16_t)
									GetProcAddress(hOrig,"_DecryptAESMemoryCBC@16");
			origDecryptZipAES = (_DecryptZipAES_12_t)
									GetProcAddress(hOrig,"_DecryptZipAES@12");
			origDeflateChunk = (_DeflateChunk_32_t)
									GetProcAddress(hOrig,"_DeflateChunk@32");
			origDoneDeflate = (_DoneDeflate_4_t)
									GetProcAddress(hOrig,"_DoneDeflate@4");
			origEncryptZipAES = (_EncryptZipAES_12_t)
									GetProcAddress(hOrig,"_EncryptZipAES@12");
			origEncryptAESMemoryCBC = (_EncryptAESMemoryCBC_20_t)
									GetProcAddress(hOrig,"_EncryptAESMemoryCBC@20");
			origEndZipAES = (_EndZipAES_8_t)GetProcAddress(hOrig,"_EndZipAES@8");
			origfile_compress = (_file_compress_24_t)
									GetProcAddress(hOrig,"_file_compress@24");
			origGetKeys = (_GetKeys_12t)GetProcAddress(hOrig,"_GetKeys@12");
			origGetRandomData = (_GetRandomData_8_t)
									GetProcAddress(hOrig,"_GetRandomData@8");
			origInitZipAES = (_InitZipAES_24_t)
									GetProcAddress(hOrig,"_InitZipAES@24");
			origStartDeflate = (_StartDeflate_12_t)GetProcAddress(hOrig,"_StartDeflate@12");
			origUpdateOnlyCrc = (_UpdateOnlyCrc_12_t)
									GetProcAddress(hOrig,"_UpdateOnlyCrc@12");


			dbgDecryptAESMemoryCBC = (_DecryptAESMemoryCBC_16_t)
									GetProcAddress(hDbg,"_DecryptAESMemoryCBC_16");
			dbgDecryptZipAES = (_DecryptZipAES_12_t)
									GetProcAddress(hDbg,"_DecryptZipAES_12");
			dbgDeflateChunk = (_DeflateChunk_32_t)
									GetProcAddress(hDbg,"_DeflateChunk_32");
			dbgDoneDeflate = (_DoneDeflate_4_t)
									GetProcAddress(hDbg,"_DoneDeflate_4");
			dbgEncryptZipAES = (_EncryptZipAES_12_t)
									GetProcAddress(hDbg,"_EncryptZipAES_12");
			dbgEncryptAESMemoryCBC = (_EncryptAESMemoryCBC_20_t)
									GetProcAddress(hDbg,"_EncryptAESMemoryCBC_20");
			dbgEndZipAES = (_EndZipAES_8_t)GetProcAddress(hDbg,"_EndZipAES_8");
			dbgfile_compress = (_file_compress_24_t)
									GetProcAddress(hDbg,"_file_compress_24");
			dbgGetKeys = (_GetKeys_12t)GetProcAddress(hDbg,"_GetKeys_12");
			dbgGetRandomData = (_GetRandomData_8_t)
									GetProcAddress(hDbg,"_GetRandomData_8");
			dbgInitZipAES = (_InitZipAES_24_t)
									GetProcAddress(hDbg,"_InitZipAES_24");
			dbgStartDeflate = (_StartDeflate_12_t)GetProcAddress(hDbg,"_StartDeflate_12");
			dbgUpdateOnlyCrc = (_UpdateOnlyCrc_12_t)
									GetProcAddress(hDbg,"_UpdateOnlyCrc_12");
			break;
		case DLL_THREAD_ATTACH:
		case DLL_THREAD_DETACH:
			break;
		case DLL_PROCESS_DETACH:
			FreeLibrary(hOrig);
			FreeLibrary(hDbg);
			break;
    }
  return( TRUE );
}

extern "C"
{

DWORD __stdcall _DecryptAESMemoryCBC_16(DWORD par1,DWORD par2,DWORD par3,DWORD par4)
{
	dbgDecryptAESMemoryCBC(par1,par2,par3,par4);
	return origDecryptAESMemoryCBC(par1,par2,par3,par4);
}

DWORD __stdcall _DecryptZipAES_12(DWORD par1,DWORD par2,DWORD par3)
{
	dbgDecryptZipAES(par1,par2,par3);
	return origDecryptZipAES(par1,par2,par3);
}

DWORD __stdcall _DeflateChunk_32(DWORD par1,DWORD par2,DWORD par3,DWORD par4,
								 DWORD par5,DWORD par6,DWORD par7,DWORD par8)
{
	dbgDeflateChunk(par1,par2,par3,par4,par5,par6,par7,par8);
	return origDeflateChunk(par1,par2,par3,par4,par5,par6,par7,par8);
}

DWORD __stdcall _DoneDeflate_4(DWORD par1)
{
	dbgDoneDeflate(par1);
	return origDoneDeflate(par1);
}

DWORD __stdcall _EncryptAESMemoryCBC_20(DWORD par1,DWORD par2,DWORD par3,DWORD par4,DWORD par5)
{
	dbgEncryptAESMemoryCBC(par1,par2,par3,par4,par5);
	return origEncryptAESMemoryCBC(par1,par2,par3,par4,par5);
}

DWORD __stdcall _EncryptZipAES_12(DWORD par1,DWORD par2,DWORD par3)
{
	dbgEncryptZipAES(par1,par2,par3);
	return origEncryptZipAES(par1,par2,par3);
}

DWORD __stdcall _EndZipAES_8(DWORD par1,DWORD par2)
{
	dbgEndZipAES(par1,par2);
	return origEndZipAES(par1,par2);
}

DWORD __stdcall _file_compress_24(DWORD par1,DWORD par2,DWORD par3,
								  DWORD par4,DWORD par5,DWORD par6)
{
	dbgfile_compress(par1,par2,par3,par4,par5,par6);
	return origfile_compress(par1,par2,par3,par4,par5,par6);
}

DWORD __stdcall _GetKeys_12(DWORD par1,DWORD par2,DWORD par3)
{
	dbgGetKeys(par1,par2,par3);
	return origGetKeys(par1,par2,par3);
}

DWORD __stdcall _GetRandomData_8(DWORD par1,DWORD par2)
{
	dbgGetRandomData(par1,par2);
	return origGetRandomData(par1,par2);
}

DWORD __stdcall _InitZipAES_24(DWORD par1,DWORD par2,DWORD par3,
							   DWORD par4,DWORD par5,DWORD par6)
{
	dbgInitZipAES(par1,par2,par3,par4,par5,par6);
	return origInitZipAES(par1,par2,par3,par4,par5,par6);
}

DWORD __stdcall _StartDeflate_12(DWORD par1,DWORD par2,DWORD par3)
{
	dbgStartDeflate(par1,par2,par3);
	return origStartDeflate(par1,par2,par3);
}

DWORD __stdcall _UpdateOnlyCrc_12(DWORD par1,DWORD par2,DWORD par3)
{
	dbgUpdateOnlyCrc(par1,par2,par3);
	return origUpdateOnlyCrc(par1,par2,par3);
}

}