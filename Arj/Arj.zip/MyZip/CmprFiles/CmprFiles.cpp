#include <stdio.h>


void main()
{
FILE *fIn=fopen("D:\\Temp\\���.zip","rb");
	if(!fIn) return;
FILE *fIn1=fopen("D:\\Temp\\���2.zip","rb");
	if(!fIn1) return;

	int i=0;
	char cOld=0,c1Old=0,cOldOld=0,c1OldOld=0,cOldOldOld=0,c1OldOldOld=0;
	while(1)
	{	char c,c1;
		if(!fread(&c,1,1,fIn))
		{	printf("file 1 is reched to end;");
			break;
		}
		if(!fread(&c1,1,1,fIn1))
		{	printf("file 2 is reched to end;");
			break;
		}
		if(c!=c1)
		{	printf("File mismatch in pos: %d, char1: %02x %02x %02x %02x, char2: %02x %02x %02x %02x",
				i,cOldOldOld,cOldOld,cOld,c,c1OldOldOld,c1OldOld,c1Old,c1);
			break;
		}
		cOldOldOld=cOldOld;c1OldOldOld=c1OldOld;
		cOldOld=cOld;c1OldOld=c1Old;
		cOld=c;c1Old=c1;
		++i;
	}
	fcloseall();
	getchar();
}