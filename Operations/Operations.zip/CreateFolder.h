#ifndef _CREATE_FOLDER_H_
#define _CREATE_FOLDER_H_

#include "windows.h"
#include "..\panel.h"


namespace CreaFolder
{
	extern INT_PTR CALLBACK DlgProc(HWND,UINT,WPARAM,LPARAM);
	extern VOID ShowDlg(Panel*);

//	int      panelNum;
//	char*    path;
//	char     Name[MAX_PATH];
//	BOOL     bCanceled;
}

#endif