#include "MyErrors.h"
#include "strsafe.h"
#include "..\sino.h"
#include "..\config.h"
#include "MyShell\resource.h"


namespace Err
{

void fatalExit(LPWSTR msg, HWND h)
{
	MessageBox(h?h:NULL, msg, L"Err.", MB_OK|MB_SYSTEMMODAL|MB_ICONERROR);
	//ExitProcess(0);
}

void AssertFatal(BOOL b, wchar_t* msg)
{	if(!b)
	{	MessageBox(NULL, msg, L"Err.", MB_OK|MB_SYSTEMMODAL|MB_ICONERROR);
		//ExitProcess(0);
}	}

void msg(HWND prnt,DWORD e,wchar_t* lpszFunction) 
{ 
    // Retrieve the system error message for the last-error code

    LPVOID lpMsgBuf;
    LPVOID lpDisplayBuf;
	DWORD dw = (e==(DWORD)(-1))?GetLastError():e;

    FormatMessage(
        FORMAT_MESSAGE_ALLOCATE_BUFFER | 
        FORMAT_MESSAGE_FROM_SYSTEM |
        FORMAT_MESSAGE_IGNORE_INSERTS,
        NULL,
        dw,
        MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
        (LPWSTR)&lpMsgBuf,
        0, NULL );

    // Display the error message and exit the process

    lpDisplayBuf = (LPVOID)LocalAlloc(LMEM_ZEROINIT, 
        (lstrlen((LPCWSTR)lpMsgBuf)+lstrlen((LPCWSTR)lpszFunction)+40)*sizeof(wchar_t));
    StringCchPrintf((STRSAFE_LPWSTR)lpDisplayBuf, 
        LocalSize(lpDisplayBuf),
        L"Failed with error %d: %s",
        dw, lpMsgBuf); 
    MessageBox(prnt, (LPCWSTR)lpDisplayBuf, lpszFunction, MB_OK|MB_SYSTEMMODAL|MB_ICONERROR);

	LocalFree(lpMsgBuf);
    LocalFree(lpDisplayBuf);
    //ExitProcess(dw); 
}

void msg1(HWND prnt,DWORD e,wchar_t* lpszFunction,wchar_t* msg1)
{ 
    // Retrieve the system error message for the last-error code

    LPVOID lpMsgBuf;
    LPVOID lpDisplayBuf;
	DWORD dw = (e==(DWORD)(-1))?GetLastError():e;

    FormatMessage(
        FORMAT_MESSAGE_ALLOCATE_BUFFER | 
        FORMAT_MESSAGE_FROM_SYSTEM |
        FORMAT_MESSAGE_IGNORE_INSERTS,
        NULL,
        dw,
        MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
        (LPWSTR)&lpMsgBuf,
        0, NULL );

    // Display the error message and exit the process

    lpDisplayBuf = (LPVOID)LocalAlloc(LMEM_ZEROINIT, 
        (lstrlen((LPCWSTR)lpMsgBuf)+lstrlen((LPCWSTR)lpszFunction)+40)*sizeof(wchar_t)); 
    StringCchPrintf((STRSAFE_LPWSTR)lpDisplayBuf, 
        LocalSize(lpDisplayBuf),
        L"%s failed with error %d: %s",
        lpszFunction, dw, lpMsgBuf); 
    MessageBox(prnt, msg1, (LPCWSTR)lpDisplayBuf, MB_OK|MB_SYSTEMMODAL|MB_ICONERROR); 


    LocalFree(lpMsgBuf);
    LocalFree(lpDisplayBuf);
    //ExitProcess(dw); 
}

void msg2(HWND prnt,DWORD e,wchar_t* lpszFunction,wchar_t* msg1,wchar_t* msg2)
{ 
    // Retrieve the system error message for the last-error code

    LPVOID lpMsgBuf;
    LPVOID lpDisplayBuf;
	DWORD dw = (e==(DWORD)(-1))?GetLastError():e;

    FormatMessage(
        FORMAT_MESSAGE_ALLOCATE_BUFFER | 
        FORMAT_MESSAGE_FROM_SYSTEM |
        FORMAT_MESSAGE_IGNORE_INSERTS,
        NULL,
        dw,
        MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
        (LPWSTR)&lpMsgBuf,
        0, NULL );

    // Display the error message and exit the process

    lpDisplayBuf = (LPVOID)LocalAlloc(LMEM_ZEROINIT, 
        (lstrlen((LPCWSTR)lpMsgBuf)+lstrlen((LPCWSTR)lpszFunction)+40)*sizeof(wchar_t)); 
    StringCchPrintf((STRSAFE_LPWSTR)lpDisplayBuf, 
        LocalSize(lpDisplayBuf),
        L"%s failed with error %d: %s %s",
        lpszFunction, dw, lpMsgBuf, msg1); 
    MessageBox(prnt, msg2, (LPCWSTR)lpDisplayBuf, MB_OK|MB_SYSTEMMODAL|MB_ICONERROR); 

    LocalFree(lpMsgBuf);
    LocalFree(lpDisplayBuf);
    //ExitProcess(dw); 
}

void msg2A(HWND prnt,DWORD e,char* lpszFunction,char* msg1,char* msg2)
{ 
    // Retrieve the system error message for the last-error code

    LPVOID lpMsgBuf;
    LPVOID lpDisplayBuf;
	DWORD dw = (e==(DWORD)(-1))?GetLastError():e;

    FormatMessageA(
        FORMAT_MESSAGE_ALLOCATE_BUFFER | 
        FORMAT_MESSAGE_FROM_SYSTEM |
        FORMAT_MESSAGE_IGNORE_INSERTS,
        NULL,
        dw,
        MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
        (LPSTR)&lpMsgBuf,
        0, NULL );

    // Display the error message and exit the process

    lpDisplayBuf = (LPVOID)LocalAlloc(LMEM_ZEROINIT, 
        (lstrlenA((LPCSTR)lpMsgBuf)+lstrlenA((LPCSTR)lpszFunction)+40)*sizeof(char)); 
    StringCchPrintfA((STRSAFE_LPSTR)lpDisplayBuf, 
        LocalSize(lpDisplayBuf),
        "%s failed with error %d: %s %s",
        lpszFunction, dw, lpMsgBuf, msg1); 
    MessageBoxA(prnt, msg2, (LPCSTR)lpDisplayBuf, MB_OK|MB_SYSTEMMODAL|MB_ICONERROR); 

    LocalFree(lpMsgBuf);
    LocalFree(lpDisplayBuf);
    //ExitProcess(dw); 
}

void msgC2(HWND prnt,DWORD e,wchar_t* lpszFunction,wchar_t* msg1,wchar_t* msg2)
{ 
    // Retrieve the system error message for the last-error code

    LPVOID lpMsgBuf;
    LPVOID lpDisplayBuf;
	DWORD dw = (e==(DWORD)(-1))?GetLastError():e;

    FormatMessageA(
        FORMAT_MESSAGE_ALLOCATE_BUFFER | 
        FORMAT_MESSAGE_FROM_SYSTEM |
        FORMAT_MESSAGE_IGNORE_INSERTS,
        NULL,
        dw,
        MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
        (LPSTR) &lpMsgBuf,
        0, NULL );

    // Display the error message and exit the process

    lpDisplayBuf = (LPVOID)LocalAlloc(LMEM_ZEROINIT, 
        (lstrlen((LPCWSTR)lpMsgBuf)+lstrlen(lpszFunction)+40)*sizeof(wchar_t)); 
    StringCchPrintf((STRSAFE_LPWSTR)lpDisplayBuf, 
        LocalSize(lpDisplayBuf),
        L"%s failed with error %d: %s %s", 
        lpszFunction, dw, lpMsgBuf, msg1); 
    MessageBox(prnt, msg2, (LPCWSTR)lpDisplayBuf, MB_OK|MB_SYSTEMMODAL|MB_ICONERROR); 

    LocalFree(lpMsgBuf);
    LocalFree(lpDisplayBuf);
    //ExitProcess(dw); 
}

#define WSA_INVALID_HANDLE      (ERROR_INVALID_HANDLE)
#define WSA_INVALID_PARAMETER   (ERROR_INVALID_PARAMETER)
#define WSA_IO_INCOMPLETE       (ERROR_IO_INCOMPLETE)
#define WSA_IO_PENDING          (ERROR_IO_PENDING)
#define WSA_NOT_ENOUGH_MEMORY   (ERROR_NOT_ENOUGH_MEMORY)
#define WSA_OPERATION_ABORTED   (ERROR_OPERATION_ABORTED)
void SockMsg(wchar_t *ms)
{ 
    // Retrieve the system error message for the last-error code
    LPVOID lpDisplayBuf;
	DWORD dw = WSAGetLastError();
	if(!dw) return;

    // Display the error message and exit the process
    lpDisplayBuf = (LPVOID)LocalAlloc(LMEM_ZEROINIT, 64*sizeof(TCHAR)); 

	switch(dw)
	{	case WSAEACCES:
			StringCchPrintf((STRSAFE_LPWSTR)lpDisplayBuf, LocalSize(lpDisplayBuf),
				L"%s,WSAEACCES-%d",ms,dw);break;
		case WSAEADDRINUSE:
			StringCchPrintf((STRSAFE_LPWSTR)lpDisplayBuf, LocalSize(lpDisplayBuf),
				L"%s,WSAEADDRINUSE-%d",ms,dw);break;
		case WSAEADDRNOTAVAIL:
			StringCchPrintf((STRSAFE_LPWSTR)lpDisplayBuf, LocalSize(lpDisplayBuf),
				L"%s,WSAEADDRNOTAVAIL-%d",ms,dw);break;
		case WSAEAFNOSUPPORT:
			StringCchPrintf((STRSAFE_LPWSTR)lpDisplayBuf, LocalSize(lpDisplayBuf),
				L"%s,WSAEAFNOSUPPORT-%d",ms,dw);break;
		case WSAEALREADY:
			StringCchPrintf((STRSAFE_LPWSTR)lpDisplayBuf, LocalSize(lpDisplayBuf),
				L"%s,WSAEALREADY-%d",ms,dw);break;
		case WSAECONNABORTED:
			StringCchPrintf((STRSAFE_LPWSTR)lpDisplayBuf, LocalSize(lpDisplayBuf),
				L"%s,WSAECONNABORTED-%d",ms,dw);break;
		case WSAECONNREFUSED:
			StringCchPrintf((STRSAFE_LPWSTR)lpDisplayBuf, LocalSize(lpDisplayBuf),
				L"%s,WSAECONNREFUSED-%d",ms,dw);break;
		case WSAECONNRESET:
			StringCchPrintf((STRSAFE_LPWSTR)lpDisplayBuf, LocalSize(lpDisplayBuf),
				L"%s,WSAECONNRESET-%d",ms,dw);break;
		case WSAEDESTADDRREQ:
			StringCchPrintf((STRSAFE_LPWSTR)lpDisplayBuf, LocalSize(lpDisplayBuf),
				L"%s,WSAEDESTADDRREQ-%d",ms,dw);break;
		case WSAEFAULT:
			StringCchPrintf((STRSAFE_LPWSTR)lpDisplayBuf, LocalSize(lpDisplayBuf),
				L"%s,WSAEFAULT-%d",ms,dw);break;
		case WSAEHOSTDOWN:
			StringCchPrintf((STRSAFE_LPWSTR)lpDisplayBuf, LocalSize(lpDisplayBuf),
				L"%s,WSAEHOSTDOWN-%d",ms,dw);break;
		case WSAEHOSTUNREACH:
			StringCchPrintf((STRSAFE_LPWSTR)lpDisplayBuf, LocalSize(lpDisplayBuf),
				L"%s,WSAEHOSTUNREACH-%d",ms,dw);break;
		case WSAEINPROGRESS:
			StringCchPrintf((STRSAFE_LPWSTR)lpDisplayBuf, LocalSize(lpDisplayBuf),
				L"%s,WSAEINPROGRESS-%d",ms,dw);break;
		case WSAEINTR:
			StringCchPrintf((STRSAFE_LPWSTR)lpDisplayBuf, LocalSize(lpDisplayBuf),
				L"%s,WSAEINTR-%d",ms,dw);break;
		case WSAEINVAL:
			StringCchPrintf((STRSAFE_LPWSTR)lpDisplayBuf, LocalSize(lpDisplayBuf),
				L"%s,WSAEINVAL-%d",ms,dw);break;
		case WSAEISCONN:
			StringCchPrintf((STRSAFE_LPWSTR)lpDisplayBuf, LocalSize(lpDisplayBuf),
				L"%s,WSAEISCONN-%d",ms,dw);break;
		case WSAEMFILE:
			StringCchPrintf((STRSAFE_LPWSTR)lpDisplayBuf, LocalSize(lpDisplayBuf),
				L"%s,WSAEMFILE-%d",ms,dw);break;
		case WSAEMSGSIZE:
			StringCchPrintf((STRSAFE_LPWSTR)lpDisplayBuf, LocalSize(lpDisplayBuf),
				L"%s,WSAEMSGSIZE-%d",ms,dw);break;
		case WSAENETDOWN:
			StringCchPrintf((STRSAFE_LPWSTR)lpDisplayBuf, LocalSize(lpDisplayBuf),
				L"%s,WSAENETDOWN-%d",ms,dw);break;
		case WSAENETRESET:
			StringCchPrintf((STRSAFE_LPWSTR)lpDisplayBuf, LocalSize(lpDisplayBuf),
				L"%s,WSAENETRESET-%d",ms,dw);break;
		case WSAENETUNREACH:
			StringCchPrintf((STRSAFE_LPWSTR)lpDisplayBuf, LocalSize(lpDisplayBuf),
				L"%s,WSAENETUNREACH-%d",ms,dw);break;
		case WSAENOBUFS:
			StringCchPrintf((STRSAFE_LPWSTR)lpDisplayBuf, LocalSize(lpDisplayBuf),
				L"%s,WSAENOBUFS-%d",ms,dw);break;
		case WSAENOPROTOOPT:
			StringCchPrintf((STRSAFE_LPWSTR)lpDisplayBuf, LocalSize(lpDisplayBuf),
				L"%s,WSAENOPROTOOPT-%d",ms,dw);break;
		case WSAENOTCONN:
			StringCchPrintf((STRSAFE_LPWSTR)lpDisplayBuf, LocalSize(lpDisplayBuf),
				L"%s,WSAENOTCONN-%d",ms,dw);break;
		case WSAENOTSOCK:
			StringCchPrintf((STRSAFE_LPWSTR)lpDisplayBuf, LocalSize(lpDisplayBuf),
				L"%s,WSAENOTSOCK-%d",ms,dw);break;
		case WSAEOPNOTSUPP:
			StringCchPrintf((STRSAFE_LPWSTR)lpDisplayBuf, LocalSize(lpDisplayBuf),
				L"%s,WSAEOPNOTSUPP-%d",ms,dw);break;
		case WSAEPFNOSUPPORT:
			StringCchPrintf((STRSAFE_LPWSTR)lpDisplayBuf, LocalSize(lpDisplayBuf),
				L"%s,WSAEPFNOSUPPORT-%d",ms,dw);break;
		case WSAEPROCLIM:
			StringCchPrintf((STRSAFE_LPWSTR)lpDisplayBuf, LocalSize(lpDisplayBuf),
				L"%s,WSAEPROCLIM-%d",ms,dw);break;
		case WSAEPROTONOSUPPORT:
			StringCchPrintf((STRSAFE_LPWSTR)lpDisplayBuf, LocalSize(lpDisplayBuf),
				L"%s,WSAEPROTONOSUPPORT-%d",ms,dw);break;
		case WSAEPROTOTYPE:
			StringCchPrintf((STRSAFE_LPWSTR)lpDisplayBuf, LocalSize(lpDisplayBuf),
				L"%s,WSAEPROTOTYPE-%d",ms,dw);break;
		case WSAESHUTDOWN:
			StringCchPrintf((STRSAFE_LPWSTR)lpDisplayBuf, LocalSize(lpDisplayBuf),
				L"%s,WSAESHUTDOWN-%d",ms,dw);break;
		case WSAESOCKTNOSUPPORT:
			StringCchPrintf((STRSAFE_LPWSTR)lpDisplayBuf, LocalSize(lpDisplayBuf),
				L"%s,WSAESOCKTNOSUPPORT-%d",ms,dw);break;
		case WSAETIMEDOUT:
			StringCchPrintf((STRSAFE_LPWSTR)lpDisplayBuf, LocalSize(lpDisplayBuf),
				L"%s,WSAETIMEDOUT-%d",ms,dw);break;
		case WSATYPE_NOT_FOUND:
			StringCchPrintf((STRSAFE_LPWSTR)lpDisplayBuf, LocalSize(lpDisplayBuf),
				L"%s,WSATYPE_NOT_FOUND-%d",ms,dw);break;
		case WSAEWOULDBLOCK:
			StringCchPrintf((STRSAFE_LPWSTR)lpDisplayBuf, LocalSize(lpDisplayBuf),
				L"%s,WSAEWOULDBLOCK-%d",ms,dw);break;
		case WSAHOST_NOT_FOUND:
			StringCchPrintf((STRSAFE_LPWSTR)lpDisplayBuf, LocalSize(lpDisplayBuf),
				L"%s,WSAHOST_NOT_FOUND-%d",ms,dw);break;
		case WSA_INVALID_HANDLE:
			StringCchPrintf((STRSAFE_LPWSTR)lpDisplayBuf, LocalSize(lpDisplayBuf),
				L"%s,WSA_INVALID_HANDLE-%d",ms,dw);break;
		case WSA_INVALID_PARAMETER:
			StringCchPrintf((STRSAFE_LPWSTR)lpDisplayBuf, LocalSize(lpDisplayBuf),
				L"%s,WSA_INVALID_PARAMETER-%d",ms,dw);break;
		case WSAEINVALIDPROCTABLE:
			StringCchPrintf((STRSAFE_LPWSTR)lpDisplayBuf, LocalSize(lpDisplayBuf),
				L"%s,WSAINVALIDPROCTABLE-%d",ms,dw);break;
		case WSAEINVALIDPROVIDER:
			StringCchPrintf((STRSAFE_LPWSTR)lpDisplayBuf, LocalSize(lpDisplayBuf),
				L"%s,WSAINVALIDPROVIDER-%d",ms,dw);break;
		case WSA_IO_INCOMPLETE:
			StringCchPrintf((STRSAFE_LPWSTR)lpDisplayBuf, LocalSize(lpDisplayBuf),
				L"%s,WSA_IO_INCOMPLETE-%d",ms,dw);break;
		case WSA_IO_PENDING:
			StringCchPrintf((STRSAFE_LPWSTR)lpDisplayBuf, LocalSize(lpDisplayBuf),
				L"%s,WSA_IO_PENDING-%d",ms,dw);break;
		case WSA_NOT_ENOUGH_MEMORY:
			StringCchPrintf((STRSAFE_LPWSTR)lpDisplayBuf, LocalSize(lpDisplayBuf),
				L"%s,WSA_NOT_ENOUGH_MEMORY-%d",ms,dw);break;
		case WSANOTINITIALISED:
			StringCchPrintf((STRSAFE_LPWSTR)lpDisplayBuf, LocalSize(lpDisplayBuf),
				L"%s,WSANOTINITIALISED-%d",ms,dw);break;
		case WSANO_DATA:
			StringCchPrintf((STRSAFE_LPWSTR)lpDisplayBuf, LocalSize(lpDisplayBuf),
				L"%s,WSANO_DATA-%d",ms,dw);break;
		case WSANO_RECOVERY:
			StringCchPrintf((STRSAFE_LPWSTR)lpDisplayBuf, LocalSize(lpDisplayBuf),
				L"%s,WSANO_RECOVERY-%d",ms,dw);break;
		case WSAEPROVIDERFAILEDINIT:
			StringCchPrintf((STRSAFE_LPWSTR)lpDisplayBuf, LocalSize(lpDisplayBuf),
				L"%s,WSAPROVIDERFAILEDINIT-%d",ms,dw);break;
		case WSASYSCALLFAILURE:
			StringCchPrintf((STRSAFE_LPWSTR)lpDisplayBuf, LocalSize(lpDisplayBuf),
				L"%s,WSASYSCALLFAILURE-%d",ms,dw);break;
		case WSASYSNOTREADY:
			StringCchPrintf((STRSAFE_LPWSTR)lpDisplayBuf, LocalSize(lpDisplayBuf),
				L"%s,WSASYSNOTREADY-%d",ms,dw);break;
		case WSATRY_AGAIN:
			StringCchPrintf((STRSAFE_LPWSTR)lpDisplayBuf, LocalSize(lpDisplayBuf),
				L"%s,WSATRY_AGAIN-%d",ms,dw);break;
		case WSAVERNOTSUPPORTED:
			StringCchPrintf((STRSAFE_LPWSTR)lpDisplayBuf, LocalSize(lpDisplayBuf),
				L"%s,WSAVERNOTSUPPORTED-%d",ms,dw);break;
		case WSAEDISCON:
			StringCchPrintf((STRSAFE_LPWSTR)lpDisplayBuf, LocalSize(lpDisplayBuf),
				L"%s,WSAEDISCON-%d",ms,dw);break;
		case WSA_OPERATION_ABORTED:
			StringCchPrintf((STRSAFE_LPWSTR)lpDisplayBuf, LocalSize(lpDisplayBuf),
				L"%s,WSA_OPERATION_ABORTED-%d",ms,dw);break;
	}
	//MessageBox(NULL, lpDisplayBuf, L"Error"), MB_OK);
    FlipMsg((wchar_t*)lpDisplayBuf,2000);
    LocalFree(lpDisplayBuf);
    //ExitProcess(dw); 
}

BOOL SockChkMsg(int chkMsg,wchar_t *ms)
{ 
    // Retrieve the system error message for the last-error code
    LPVOID lpDisplayBuf;
	DWORD dw = WSAGetLastError();
	if(chkMsg==dw || dw==WSAEWOULDBLOCK)
		return TRUE;

    // Display the error message and exit the process
    lpDisplayBuf = (LPVOID)LocalAlloc(LMEM_ZEROINIT, 128*sizeof(TCHAR)); 

	switch(dw)
	{	case WSAEACCES:
			StringCchPrintf((STRSAFE_LPWSTR)lpDisplayBuf, LocalSize(lpDisplayBuf),
				L"%s,WSAEACCES-%d",ms,dw);break;
		case WSAEADDRINUSE:
			StringCchPrintf((STRSAFE_LPWSTR)lpDisplayBuf, LocalSize(lpDisplayBuf),
				L"%s,WSAEADDRINUSE-%d",ms,dw);break;
		case WSAEADDRNOTAVAIL:
			StringCchPrintf((STRSAFE_LPWSTR)lpDisplayBuf, LocalSize(lpDisplayBuf),
				L"%s,WSAEADDRNOTAVAIL-%d",ms,dw);break;
		case WSAEAFNOSUPPORT:
			StringCchPrintf((STRSAFE_LPWSTR)lpDisplayBuf, LocalSize(lpDisplayBuf),
				L"%s,WSAEAFNOSUPPORT-%d",ms,dw);break;
		case WSAEALREADY:
			StringCchPrintf((STRSAFE_LPWSTR)lpDisplayBuf, LocalSize(lpDisplayBuf),
				L"%s,WSAEALREADY-%d",ms,dw);break;
		case WSAECONNABORTED:
			StringCchPrintf((STRSAFE_LPWSTR)lpDisplayBuf, LocalSize(lpDisplayBuf),
				L"%s,WSAECONNABORTED-%d",ms,dw);break;
		case WSAECONNREFUSED:
			StringCchPrintf((STRSAFE_LPWSTR)lpDisplayBuf, LocalSize(lpDisplayBuf),
				L"%s,WSAECONNREFUSED-%d",ms,dw);break;
		case WSAECONNRESET:
			StringCchPrintf((STRSAFE_LPWSTR)lpDisplayBuf, LocalSize(lpDisplayBuf),
				L"%s,WSAECONNRESET-%d",ms,dw);break;
		case WSAEDESTADDRREQ:
			StringCchPrintf((STRSAFE_LPWSTR)lpDisplayBuf, LocalSize(lpDisplayBuf),
				L"%s,WSAEDESTADDRREQ-%d",ms,dw);break;
		case WSAEFAULT:
			StringCchPrintf((STRSAFE_LPWSTR)lpDisplayBuf, LocalSize(lpDisplayBuf),
				L"%s,WSAEFAULT-%d",ms,dw);break;
		case WSAEHOSTDOWN:
			StringCchPrintf((STRSAFE_LPWSTR)lpDisplayBuf, LocalSize(lpDisplayBuf),
				L"%s,WSAEHOSTDOWN-%d",ms,dw);break;
		case WSAEHOSTUNREACH:
			StringCchPrintf((STRSAFE_LPWSTR)lpDisplayBuf, LocalSize(lpDisplayBuf),
				L"%s,WSAEHOSTUNREACH-%d",ms,dw);break;
		case WSAEINPROGRESS:
			StringCchPrintf((STRSAFE_LPWSTR)lpDisplayBuf, LocalSize(lpDisplayBuf),
				L"%s,WSAEINPROGRESS-%d",ms,dw);break;
		case WSAEINTR:
			StringCchPrintf((STRSAFE_LPWSTR)lpDisplayBuf, LocalSize(lpDisplayBuf),
				L"%s,WSAEINTR-%d",ms,dw);break;
		case WSAEINVAL:
			StringCchPrintf((STRSAFE_LPWSTR)lpDisplayBuf, LocalSize(lpDisplayBuf),
				L"%s,WSAEINVAL-%d",ms,dw);break;
		case WSAEISCONN:
			StringCchPrintf((STRSAFE_LPWSTR)lpDisplayBuf, LocalSize(lpDisplayBuf),
				L"%s,WSAEISCONN-%d",ms,dw);break;
		case WSAEMFILE:
			StringCchPrintf((STRSAFE_LPWSTR)lpDisplayBuf, LocalSize(lpDisplayBuf),
				L"%s,WSAEMFILE-%d",ms,dw);break;
		case WSAEMSGSIZE:
			StringCchPrintf((STRSAFE_LPWSTR)lpDisplayBuf, LocalSize(lpDisplayBuf),
				L"%s,WSAEMSGSIZE-%d",ms,dw);break;
		case WSAENETDOWN:
			StringCchPrintf((STRSAFE_LPWSTR)lpDisplayBuf, LocalSize(lpDisplayBuf),
				L"%s,WSAENETDOWN-%d",ms,dw);break;
		case WSAENETRESET:
			StringCchPrintf((STRSAFE_LPWSTR)lpDisplayBuf, LocalSize(lpDisplayBuf),
				L"%s,WSAENETRESET-%d",ms,dw);break;
		case WSAENETUNREACH:
			StringCchPrintf((STRSAFE_LPWSTR)lpDisplayBuf, LocalSize(lpDisplayBuf),
				L"%s,WSAENETUNREACH-%d",ms,dw);break;
		case WSAENOBUFS:
			StringCchPrintf((STRSAFE_LPWSTR)lpDisplayBuf, LocalSize(lpDisplayBuf),
				L"%s,WSAENOBUFS-%d",ms,dw);break;
		case WSAENOPROTOOPT:
			StringCchPrintf((STRSAFE_LPWSTR)lpDisplayBuf, LocalSize(lpDisplayBuf),
				L"%s,WSAENOPROTOOPT-%d",ms,dw);break;
		case WSAENOTCONN:
			StringCchPrintf((STRSAFE_LPWSTR)lpDisplayBuf, LocalSize(lpDisplayBuf),
				L"%s,WSAENOTCONN-%d",ms,dw);break;
		case WSAENOTSOCK:
			StringCchPrintf((STRSAFE_LPWSTR)lpDisplayBuf, LocalSize(lpDisplayBuf),
				L"%s,WSAENOTSOCK-%d",ms,dw);break;
		case WSAEOPNOTSUPP:
			StringCchPrintf((STRSAFE_LPWSTR)lpDisplayBuf, LocalSize(lpDisplayBuf),
				L"%s,WSAEOPNOTSUPP-%d",ms,dw);break;
		case WSAEPFNOSUPPORT:
			StringCchPrintf((STRSAFE_LPWSTR)lpDisplayBuf, LocalSize(lpDisplayBuf),
				L"%s,WSAEPFNOSUPPORT-%d",ms,dw);break;
		case WSAEPROCLIM:
			StringCchPrintf((STRSAFE_LPWSTR)lpDisplayBuf, LocalSize(lpDisplayBuf),
				L"%s,WSAEPROCLIM-%d",ms,dw);break;
		case WSAEPROTONOSUPPORT:
			StringCchPrintf((STRSAFE_LPWSTR)lpDisplayBuf, LocalSize(lpDisplayBuf),
				L"%s,WSAEPROTONOSUPPORT-%d",ms,dw);break;
		case WSAEPROTOTYPE:
			StringCchPrintf((STRSAFE_LPWSTR)lpDisplayBuf, LocalSize(lpDisplayBuf),
				L"%s,WSAEPROTOTYPE-%d",ms,dw);break;
		case WSAESHUTDOWN:
			StringCchPrintf((STRSAFE_LPWSTR)lpDisplayBuf, LocalSize(lpDisplayBuf),
				L"%s,WSAESHUTDOWN-%d",ms,dw);break;
		case WSAESOCKTNOSUPPORT:
			StringCchPrintf((STRSAFE_LPWSTR)lpDisplayBuf, LocalSize(lpDisplayBuf),
				L"%s,WSAESOCKTNOSUPPORT-%d",ms,dw);break;
		case WSAETIMEDOUT:
			StringCchPrintf((STRSAFE_LPWSTR)lpDisplayBuf, LocalSize(lpDisplayBuf),
				L"%s,WSAETIMEDOUT-%d",ms,dw);break;
		case WSATYPE_NOT_FOUND:
			StringCchPrintf((STRSAFE_LPWSTR)lpDisplayBuf, LocalSize(lpDisplayBuf),
				L"%s,WSATYPE_NOT_FOUND-%d",ms,dw);break;
		case WSAEWOULDBLOCK:
			StringCchPrintf((STRSAFE_LPWSTR)lpDisplayBuf, LocalSize(lpDisplayBuf),
				L"%s,WSAEWOULDBLOCK-%d",ms,dw);break;
		case WSAHOST_NOT_FOUND:
			StringCchPrintf((STRSAFE_LPWSTR)lpDisplayBuf, LocalSize(lpDisplayBuf),
				L"%s,WSAHOST_NOT_FOUND-%d",ms,dw);break;
		case WSA_INVALID_HANDLE:
			StringCchPrintf((STRSAFE_LPWSTR)lpDisplayBuf, LocalSize(lpDisplayBuf),
				L"%s,WSA_INVALID_HANDLE-%d",ms,dw);break;
		case WSA_INVALID_PARAMETER:
			StringCchPrintf((STRSAFE_LPWSTR)lpDisplayBuf, LocalSize(lpDisplayBuf),
				L"%s,WSA_INVALID_PARAMETER-%d",ms,dw);break;
		case WSAEINVALIDPROCTABLE:
			StringCchPrintf((STRSAFE_LPWSTR)lpDisplayBuf, LocalSize(lpDisplayBuf),
				L"%s,WSAINVALIDPROCTABLE-%d",ms,dw);break;
		case WSAEINVALIDPROVIDER:
			StringCchPrintf((STRSAFE_LPWSTR)lpDisplayBuf, LocalSize(lpDisplayBuf),
				L"%s,WSAINVALIDPROVIDER-%d",ms,dw);break;
		case WSA_IO_INCOMPLETE:
			StringCchPrintf((STRSAFE_LPWSTR)lpDisplayBuf, LocalSize(lpDisplayBuf),
				L"%s,WSA_IO_INCOMPLETE-%d",ms,dw);break;
		case WSA_IO_PENDING:
			StringCchPrintf((STRSAFE_LPWSTR)lpDisplayBuf, LocalSize(lpDisplayBuf),
				L"%s,WSA_IO_PENDING-%d",ms,dw);break;
		case WSA_NOT_ENOUGH_MEMORY:
			StringCchPrintf((STRSAFE_LPWSTR)lpDisplayBuf, LocalSize(lpDisplayBuf),
				L"%s,WSA_NOT_ENOUGH_MEMORY-%d",ms,dw);break;
		case WSANOTINITIALISED:
			StringCchPrintf((STRSAFE_LPWSTR)lpDisplayBuf, LocalSize(lpDisplayBuf),
				L"%s,WSANOTINITIALISED-%d",ms,dw);break;
		case WSANO_DATA:
			StringCchPrintf((STRSAFE_LPWSTR)lpDisplayBuf, LocalSize(lpDisplayBuf),
				L"%s,WSANO_DATA-%d",ms,dw);break;
		case WSANO_RECOVERY:
			StringCchPrintf((STRSAFE_LPWSTR)lpDisplayBuf, LocalSize(lpDisplayBuf),
				L"%s,WSANO_RECOVERY-%d",ms,dw);break;
		case WSAEPROVIDERFAILEDINIT:
			StringCchPrintf((STRSAFE_LPWSTR)lpDisplayBuf, LocalSize(lpDisplayBuf),
				L"%s,WSAPROVIDERFAILEDINIT-%d",ms,dw);break;
		case WSASYSCALLFAILURE:
			StringCchPrintf((STRSAFE_LPWSTR)lpDisplayBuf, LocalSize(lpDisplayBuf),
				L"%s,WSASYSCALLFAILURE-%d",ms,dw);break;
		case WSASYSNOTREADY:
			StringCchPrintf((STRSAFE_LPWSTR)lpDisplayBuf, LocalSize(lpDisplayBuf),
				L"%s,WSASYSNOTREADY-%d",ms,dw);break;
		case WSATRY_AGAIN:
			StringCchPrintf((STRSAFE_LPWSTR)lpDisplayBuf, LocalSize(lpDisplayBuf),
				L"%s,WSATRY_AGAIN-%d",ms,dw);break;
		case WSAVERNOTSUPPORTED:
			StringCchPrintf((STRSAFE_LPWSTR)lpDisplayBuf, LocalSize(lpDisplayBuf),
				L"%s,WSAVERNOTSUPPORTED-%d",ms,dw);break;
		case WSAEDISCON:
			StringCchPrintf((STRSAFE_LPWSTR)lpDisplayBuf, LocalSize(lpDisplayBuf),
				L"%s,WSAEDISCON-%d",ms,dw);break;
		case WSA_OPERATION_ABORTED:
			StringCchPrintf((STRSAFE_LPWSTR)lpDisplayBuf, LocalSize(lpDisplayBuf),
				L"%s,WSA_OPERATION_ABORTED-%d",ms,dw);break;
	}
    //MessageBox(NULL, lpDisplayBuf, L"Error"), MB_OK); 
	FlipMsg((wchar_t*)lpDisplayBuf,1500);
    LocalFree(lpDisplayBuf);
    //ExitProcess(dw);
	return FALSE;
}

INT_PTR CALLBACK ErrFlipDlgProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	UNREFERENCED_PARAMETER(lParam);
	switch (message)
	{
	case WM_INITDIALOG:
		int* lpar;lpar = (int*)lParam;
		wchar_t* msg;msg = (wchar_t*)lpar[0];

		HDC dc;dc = GetDC(hWnd);
		SIZE sz;GetTextExtentPoint32A(dc,(LPCSTR)msg,MyStringLength(msg,1024),&sz);
		ReleaseDC(hWnd,dc);
		int left,top;
		left = conf::wndLeft + (conf::wndWidth - sz.cx - 20)/2;
		top = conf::wndTop + (conf::wndHeight - sz.cy - 35)/2;
		//MoveWindow(hDlg, left, top+20, sz.cx + 20, sz.cy + 35, TRUE);
		SetWindowPos(hDlg,HWND_TOP,left,top+20,sz.cx+20,sz.cy+35,SWP_SHOWWINDOW);

		SetDlgItemText(hDlg,IDC_STATIC,msg);
		SetTimer(hDlg,0xffff,lpar[1],NULL);
		return (INT_PTR)TRUE;
	case WM_TIMER:
		KillTimer(hDlg,0xffff);
		DestroyWindow(hDlg);
		break;
	case WM_CLOSE:
		KillTimer(hDlg,0xffff);
		DestroyWindow(hDlg);
		break;
	case WM_COMMAND:
		if(IDCANCEL==LOWORD(wParam))
		{	KillTimer(hDlg,0xffff);
			DestroyWindow(hDlg);
		}
		break;
	}
	return (INT_PTR)FALSE;
}

VOID FlipMsg(wchar_t* msg, int flipTime)
{
	int par[2]={(int)msg,flipTime};
	HWND dlg = CreateDialogParam(hInst,
				MAKEINTRESOURCE(IDD_ERR_FLIP_DIALOG),
		                        hWnd,
								(DLGPROC)ErrFlipDlgProc,
								(LPARAM)par);
	ShowWindow(dlg,SW_SHOW);
}

INT_PTR CALLBACK ErrPasswordCheckDlgProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
static int cnt;
	UNREFERENCED_PARAMETER(lParam);
	switch (message)
	{
	case WM_INITDIALOG:
		cnt = 0;
		RECT rc; GetWindowRect(hDlg, &rc);
		int width,left,height,top;
		width = rc.right - rc.left;
		left = conf::wndLeft + (conf::wndWidth - width)/2;
		height = rc.bottom - rc.top;
		top = conf::wndTop + (conf::wndHeight - height)/2;
		MoveWindow(hDlg, left, top+20, width, height, TRUE);
		SetWindowLong(hDlg,GWLP_USERDATA,(LONG)lParam);
		return (INT_PTR)TRUE;
	case WM_COMMAND:
		switch(LOWORD(wParam))
		{	case IDOK:wchar_t st[64];
				GetDlgItemText(hDlg,IDC_EDIT_PASSWORD,st,64);

				int* lpar;lpar = (int*)(GetWindowLong(hDlg,GWLP_USERDATA));
				wchar_t* msg;msg = (wchar_t*)lpar[0];

				if(!wcscmp(st,msg))
					EndDialog(hDlg,1);
				else 
				{	if(++cnt>lpar[1]-1)
						EndDialog(hDlg,0);
					else
						FlipMsg(L"Incorrect,try else one",1500);
				}	
				break;
			case IDCANCEL:
				EndDialog(hDlg,0);
				break;
		}
		break;		
	}
	return (INT_PTR)FALSE;
}

BOOL PasswordCheck(wchar_t* msg,HWND prnt,int cnt)
{
	int par[2]={(int)msg,cnt};
	int r = (int)DialogBoxParam(hInst,
				MAKEINTRESOURCE(IDD_ERR_PASSWORD_CHECK),
		                        prnt,
								(DLGPROC)ErrPasswordCheckDlgProc,
								(LPARAM)par);
	return (r==0?FALSE:TRUE);
}

}//end of namespace Err
