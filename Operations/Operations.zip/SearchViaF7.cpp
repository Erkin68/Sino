#include "..\sino.h"
#include "..\WindowsManagmentInstrumentation.h"
#include "SearchViaF7.h"
#include "strsafe.h"
#include "SelectViaPlus.h"
#include "MyErrors.h"
#include <malloc.h>
#include <Psapi.h>


namespace fSearchViaF7
{

VOID TryLoadPlugin(char *pth,char* name)
{//LoadLibrary da exception beradur;
	if(numPlugins>20)
	{	Err::msg(0,"There are any archiver plugins(above 20), ignore others...");
		return;
	}

	MyStringCat(pth,MAX_PATH-1,name);
HMODULE hm = LoadLibraryEx(pth,NULL,LOAD_LIBRARY_AS_IMAGE_RESOURCE);//LOAD_LIBRARY_AS_DATAFILE);
	if(!hm)return;
	FreeLibrary(hm);

//	char st[260]; char *p=strrchr(pth,'\\');if(p)*p=0;
//	if(32>(int)FindExecutable(name,pth,st)) return;

//	DWORD bt;
//	if(!GetBinaryType(pth,&bt))return;
	hm = LoadLibrary(pth);
	if(!hm)
	{	Err::msg(-1,pth);
		return;
	}

	Add$24_t Add$24 = (Add$24_t)GetProcAddress(hm,"Add$24");
	if(!Add$24)
	{
		//Err::msg(-1,"");
//Fall:	FreeLibrary(hm);             shart emas, unpack archive bo'lishi mumkin;
//		return;
	}	
	CreateDir$24_t CreateDir$24 = (CreateDir$24_t)GetProcAddress(hm,"CreateDir$24");
//	if(!CreateDir$24) goto Fall;
	GetArchExtnsn_t GetArchExtnsn = (GetArchExtnsn_t)GetProcAddress(hm,"GetArchExtnsn");
	if(!GetArchExtnsn)//goto Fall;
	{		
Fall:	FreeLibrary(hm);             //shart emas, unpack archive bo'lishi mumkin;
		return;
	}
	GetPluginType_t GetPluginType = (GetPluginType_t)GetProcAddress(hm,"GetPluginType");
	if(!GetPluginType) goto Fall;
	Open$12_t Open$12 = (Open$12_t)GetProcAddress(hm,"Open$12");
	if(!Open$12) goto Fall;
	Close$4_t Close$4 = (Close$4_t)GetProcAddress(hm,"Close$4");
	if(!Close$4) goto Fall;
	RebuildCheckExistings$8_t RebuildCheckExistings$8 = (RebuildCheckExistings$8_t)
										GetProcAddress(hm,"RebuildCheckExistings$8");
//	if(!RebuildCheckExistings$8) goto Fall;
	SetCallbacks$4xxx_t SetCallbacks$4xxx = (SetCallbacks$4xxx_t)GetProcAddress(hm,"SetCallbacks$4xxx");
	if(!SetCallbacks$4xxx) goto Fall;
	GetTotalCryptMethods_t GetTotalCryptMethods = (GetTotalCryptMethods_t)GetProcAddress(hm,"GetTotalCryptMethods");
	//if(!GetTotalCryptMethods) goto Fall;// nevajno;
	GetCryptDescription$4_t GetCryptDescription$4 = (GetCryptDescription$4_t)
												GetProcAddress(hm,"GetCryptDescription$4");
	//if(!GetCryptDescription) goto Fall; nevajno;
	SetCryptMethod$8_t SetCryptMethod$8 = (SetCryptMethod$8_t)GetProcAddress(hm,"SetCryptMethod$8");
	//if(!SetCryptMethod) goto Fall; nevajno;
	GetPluginDescription_t GetPluginDescription = (GetPluginDescription_t)GetProcAddress(hm,"GetPluginDescription");
	//if(!GetPluginDescription) goto Fall; nevajno;
	ShowOptionDialog_t ShowOptionDialog = (ShowOptionDialog_t)GetProcAddress(hm,"ShowOptionDialog");
	//if(!ShowOptionDialog) goto Fall; nevajno;


	//Unpacking:
	OpenForUnpacking$8_t OpenForUnpacking$8 = (OpenForUnpacking$8_t)GetProcAddress(hm,"OpenForUnpacking$8");
	//if(!OpenForUnpacking$8) goto Fall; nevajno;
	EnumDirectory$8_t EnumDirectory$8 = (EnumDirectory$8_t)GetProcAddress(hm,"EnumDirectory$8");
	//if(!EnumDirectory$4) goto Fall; nevajno;
	Unpack$12_t Unpack$12 = (Unpack$12_t)GetProcAddress(hm,"Unpack$12");
	//if(!Unpack$12$4) goto Fall; nevajno;


	int t=GetPluginType();
	if(t<1 || t>3) goto Fall;
	MODULEINFO mi;
	GetModuleInformation(GetCurrentProcess(),hm,&mi,sizeof(mi));

	/*for(int i=0; i<numPlugins; i++)
	{	//if(plgns[i].dllSize==mi.SizeOfImage)
		if(!strcmp(plgns[i].GetArchExtnsn(),GetArchExtnsn()))
			return;//goto Fall;
	}*/

	if(!plgns) plgns = (CArchPlgn*)malloc((numPlugins+1)*sizeof(CArchPlgn));
	else  plgns = (CArchPlgn*)realloc(plgns,(numPlugins+1)*sizeof(CArchPlgn));
	plgns[numPlugins].CArchPlgn::CArchPlgn();
	plgns[numPlugins].Add$24 = Add$24;
	plgns[numPlugins].CreateDir$24 = CreateDir$24;
	plgns[numPlugins].GetArchExtnsn = GetArchExtnsn;
	plgns[numPlugins].GetPluginType = GetPluginType;
	plgns[numPlugins].Open$12 = Open$12;
	plgns[numPlugins].Close$4 = Close$4;
	plgns[numPlugins].RebuildCheckExistings$8 = RebuildCheckExistings$8;
	plgns[numPlugins].SetCallbacks$4xxx = SetCallbacks$4xxx;
	plgns[numPlugins].GetTotalCryptMethods = GetTotalCryptMethods;
	plgns[numPlugins].GetCryptDescription$4 = GetCryptDescription$4;
	plgns[numPlugins].SetCryptMethod$8 = SetCryptMethod$8;
	plgns[numPlugins].GetPluginDescription = GetPluginDescription;
	plgns[numPlugins].ShowOptionDialog = ShowOptionDialog;

	//Unpacking:
	plgns[numPlugins].OpenForUnpacking$8 = OpenForUnpacking$8;
	plgns[numPlugins].EnumDirectory$8 = EnumDirectory$8;
	plgns[numPlugins].Unpack$12 = Unpack$12;

	plgns[numPlugins].type = t;
	SetCallbacks$4xxx(	CArchPlgn::checkFileInSelctn,
						CArchPlgn::excldFileFrSelctn,
						CArchPlgn::getFileInfoFromSelection,
						CArchPlgn::prgrssRout,
						CArchPlgn::showDlgOverwriteExistFile,
						CArchPlgn::saveOptions,
						CArchPlgn::readOptions,
						CArchPlgn::addItemToPanelList
						);
	//plgns[numPlugins].dllSize = mi.SizeOfImage;
	MyStringCpy(plgns[numPlugins].pathAndName,MAX_PATH-1,pth);
	++numPlugins;
}

VOID ListAuxDirLoadPlugins(char *path)
{
char s[MAX_PATH];
WIN32_FIND_DATA ff;
HANDLE hf = INVALID_HANDLE_VALUE;

	hf = FindFirstFileEx(path,FindExInfoStandard,&ff,FindExSearchLimitToDirectories,NULL,0);
	if(INVALID_HANDLE_VALUE==hf) return;

	if(FILE_ATTRIBUTE_DIRECTORY & ff.dwFileAttributes)//if(IsDirectory(path, &ff, TRUE))
	{	if(IsCrntOrPrntDirAttrb(ff.cFileName))
		{	MyStringCpy(s,MAX_PATH-1,path);
			MyStringRemoveLastCharCheckPre(s,MAX_PATH-1,'*','\\');
			MyStringCat(s,MAX_PATH-1,ff.cFileName);
			MyStringCat(s,MAX_PATH-1,"\\*");
			ListAuxDirLoadPlugins(s);
	}	}
	else
	{	MyStringCpy(s,MAX_PATH-1,path);
		MyStringRemoveLastCharCheckPre(s,MAX_PATH-1,'*','\\');
		//MyStringCat(s,MAX_PATH-1,ff.cFileName);
		TryLoadPlugin(s,ff.cFileName);
	}

	while(FindNextFile(hf, &ff))
	{	if(FILE_ATTRIBUTE_DIRECTORY & ff.dwFileAttributes)//if(IsDirectory(path, &ff, FALSE))
		{	if(IsCrntOrPrntDirAttrb(ff.cFileName))
			{	char s[MAX_PATH]; MyStringCpy(s,MAX_PATH-1,path);
				MyStringRemoveLastCharCheckPre(s,MAX_PATH-1,'*','\\');
				MyStringCat(s,MAX_PATH-1,ff.cFileName);
				MyStringCat(s,MAX_PATH-1,"\\*");
				ListAuxDirLoadPlugins(s);
		}	}
		else
		{	MyStringCpy(s,MAX_PATH-1,path);
			MyStringRemoveLastCharCheckPre(s,MAX_PATH-1,'*','\\');
			//MyStringCat(s,MAX_PATH-1,ff.cFileName);
			TryLoadPlugin(s,ff.cFileName);
	}	}
	FindClose(hf);
}

VOID FreePlugins()//CArch::~CArch ga qara, ochiq qolib ketgan arxivlar qoladur;
{
	//free(plgns);
	//plgns=NULL;
	//numPlugins=0;
}

VOID LoadPlugins()
{
	numPlugins=0;
	char *auxPlgPth = MyStringAddModulePath("Plugins\\Auxilary\\*");
	ListAuxDirLoadPlugins(auxPlgPth);
}

}//end of namespace