#ifndef _Backgrnd_thread_copy_operation_h
#define _Backgrnd_thread_copy_operation_h

#include "windows.h"

namespace fBckgrndCopyOper
{
	extern BOOL	AddToQueueFrCopyOperation();
	extern INT_PTR CALLBACK BckgrndCopyDlgProc(HWND,UINT,WPARAM,LPARAM);
	extern INT_PTR CALLBACK CopyFileExistDlgProc(HWND,UINT,WPARAM,LPARAM);
	extern BOOL	ShowCopyDlg();
	extern int  CheckCopyFilesToExisting(HWND,wchar_t*,wchar_t*);
}

#endif
