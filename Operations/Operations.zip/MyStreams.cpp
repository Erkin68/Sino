#include "windows.h"
#include "..\sino.h"
#include "..\config.h"
#include "strsafe.h"


namespace fileStream
{

HANDLE (__stdcall* pFindFirstStreamW)(LPCWSTR,STREAM_INFO_LEVELS,LPVOID,DWORD)=NULL;
BOOL (__stdcall* pFindNextStreamW)(HANDLE,LPVOID)=NULL;


typedef struct TStreamStru
{	int nStreams;
	wchar_t fileName[MAX_PATH];
WIN32_FIND_STREAM_DATA *pstreamdata;
} StreamStru;
StreamStru streamStru;

BOOL DetachStreamFromFile(int nStream)
{
	if(!pFindFirstStreamW)
	{	HMODULE hm = LoadLibrary(L"Kernel32.dll");
		if(hm)
		{	pFindFirstStreamW = (HANDLE(__stdcall*)(LPCWSTR,STREAM_INFO_LEVELS,LPVOID,DWORD))GetProcAddress(hm,"FindFirstStreamW");
			pFindNextStreamW = (BOOL(__stdcall*)(HANDLE,LPVOID))GetProcAddress(hm,"FindNextStreamW");
			if(!pFindFirstStreamW)
				return FALSE;
			if(!pFindNextStreamW)
				return FALSE;
	}	}


WIN32_FIND_STREAM_DATA d;
	//1-st enum streams:
int iStreams=0;
HANDLE h = pFindFirstStreamW(streamStru.fileName,FindStreamInfoStandard,&d,0);
	if(h==INVALID_HANDLE_VALUE)
		return FALSE;
	if(0==nStream)//Save stream 0 as file:
	{	FindClose(h);
	
		wchar_t s[MAX_PATH+36],ss[MAX_PATH+32];
		int lw=MyStringCpy(s,MAX_PATH,streamStru.fileName);
		s[lw++]=':';//MyStringCatW(s,MAX_PATH+36,L":");
		//s[lw]=0;
		MyStringCpy(&s[lw],MAX_PATH-lw,streamStru.pstreamdata[0].cStreamName+1);//MyStringCatW(s,MAX_PATH+36,streamStru.pstreamdata[0].cStreamName+1);
		HANDLE hh = CreateFileW(s,GENERIC_READ,FILE_SHARE_READ,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);
		if(INVALID_HANDLE_VALUE==hh)		
			return FALSE;
		
		lw=MyStringCpy(s,MAX_PATH,streamStru.fileName);
		s[lw++]='_';//MyStringCatW(s,MAX_PATH+36,L"_");
		//s[lw]=0;
		int l=MyStringCpy(ss,MAX_PATH+36,streamStru.pstreamdata[0].cStreamName);
		//int l;l = MyStringLengthW(ss,MAX_PATH+36);
		for(int i=0; i<l; i++)
		{	if(':'==ss[i])
				ss[i]='_';
		}
		MyStringCpy(&s[lw],MAX_PATH+32-lw,ss);//MyStringCatW(s,MAX_PATH+32,ss);
		HANDLE hhh = CreateFileW(s,GENERIC_WRITE,FILE_SHARE_WRITE,NULL,OPEN_ALWAYS,FILE_ATTRIBUTE_NORMAL,NULL);
		if(INVALID_HANDLE_VALUE==hhh)
		{	CloseHandle(hh);
			return FALSE;
		}
		char buf[32];DWORD nr=1;
		while(nr!=0)
		{	ReadFile(hh,buf,32,&nr,NULL);
			WriteFile(hhh,buf,nr,&nr,NULL);
		}

		CloseHandle(hhh);
		CloseHandle(hh);
		return TRUE;
	}

	iStreams++;
	while(pFindNextStreamW(h, &d))
	{	if(nStream==iStreams)
		{	FindClose(h);
			
			wchar_t s[MAX_PATH+36],ss[MAX_PATH+36];
			int lw=MyStringCpy(s,MAX_PATH,streamStru.fileName);
			s[lw++]=':';//MyStringCatW(s,MAX_PATH+36,L":");
			//s[lw]=0;
			MyStringCpy(&s[lw],MAX_PATH+36-lw,streamStru.pstreamdata[nStream].cStreamName+1);//MyStringCatW(s,MAX_PATH+36,streamStru.pstreamdata[nStream].cStreamName+1);
			HANDLE hh = CreateFileW(s,GENERIC_READ,FILE_SHARE_READ,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);
			if(INVALID_HANDLE_VALUE==hh)
				return FALSE;

			lw=MyStringCpy(s,MAX_PATH,streamStru.fileName);
			s[lw++]='_';//MyStringCatW(s,MAX_PATH+36,L"_");
			//s[lw]=0;
			int l=MyStringCpy(ss,MAX_PATH+36,streamStru.pstreamdata[nStream].cStreamName);
			//int l;l = MyStringLengthW(ss,MAX_PATH+36);
			for(int i=0; i<l; i++)
			{	if(':'==ss[i])
					ss[i]='_';
			}
			MyStringCpy(&s[lw],MAX_PATH+32-lw,ss);//MyStringCatW(s,MAX_PATH+32,ss);
			HANDLE hhh = CreateFileW(s,GENERIC_WRITE,FILE_SHARE_WRITE,NULL,OPEN_ALWAYS,FILE_ATTRIBUTE_NORMAL,NULL);
			if(INVALID_HANDLE_VALUE==hhh)
			{	CloseHandle(hh);
				return FALSE;
			}
			char buf[32];DWORD nr=1;
			while(nr!=0)
			{	ReadFile(hh,buf,32,&nr,NULL);
				WriteFile(hhh,buf,nr,&nr,NULL);
			}

			CloseHandle(hhh);
			CloseHandle(hh);
			return TRUE;
		}
		iStreams++;
	}
	FindClose(h);
	return FALSE;
}

INT_PTR CALLBACK FileStreamsDlgProc(HWND hDlg,UINT message,WPARAM wParam,LPARAM lParam)
{	//static int i=0;
	//char ss[32];sprintf(ss,"\n %d ",i++);
	//OutputDebugString(ss);
	//OutputDebugString(GetWinNotifyText(message));

	switch(message)
	{
	case WM_INITDIALOG:
		//Adjust:
		RECT rc; GetWindowRect(hDlg, &rc);
		int width,height,left,top;
		width = rc.right - rc.left;
		left = conf::wndLeft + (conf::wndWidth - width)/2;

		height = rc.bottom - rc.top;
		top = conf::wndTop + (conf::wndHeight - height)/2;
		MoveWindow(hDlg, left, top+20, width, height, TRUE);

		//Load language strings:
		wchar_t s[MAX_PATH];
		LoadString(hInst,IDS_STRINGSW_69,s,MAX_PATH);
		SetWindowText(hDlg,s);
		LoadString(hInst,IDS_STRINGSW_70,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_STATIC1,s);
		LoadString(hInst,IDS_STRINGSW_71,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_STATIC2,s);
		LoadString(hInst,IDS_STRINGSW_72,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_BUTTON_VIEW,s);
		LoadString(hInst,IDS_STRINGSW_73,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_BUTTON_DETACH_STREAM,s);
		LoadString(hInst,IDS_STRINGSW_41,s,MAX_PATH);
		SetDlgItemText(hDlg,IDOK,s);
		LoadString(hInst,IDS_STRINGSW_13,s,MAX_PATH);
		SetDlgItemText(hDlg,IDCANCEL,s);
		StreamStru *str;str = (StreamStru*)lParam;
		for(int i=str->nStreams-1; i>-1; i--)
		{	wchar_t s[32];
			SendMessageW(GetDlgItem(hDlg,IDC_LIST_STREAM_NAMES),CB_INSERTSTRING,0,(LPARAM)str->pstreamdata[i].cStreamName);
			StringCchPrintf(s,32,L"%d",str->pstreamdata[i].StreamSize);
			SendMessage(GetDlgItem(hDlg,IDC_LIST_STREAM_SIZES),CB_INSERTSTRING,0,(LPARAM)s);
			//if(0==i)
			//	SetWindowText(GetDlgItem(hDlg,IDC_LIST_STREAM_SIZES),s);
		}
		//SetWindowTextW(GetDlgItem(hDlg,IDC_LIST_STREAM_NAMES),str->pstreamdata[0].cStreamName);
		SendMessage(GetDlgItem(hDlg,IDC_LIST_STREAM_NAMES),CB_SETCURSEL,0,0);
		SendMessage(GetDlgItem(hDlg,IDC_LIST_STREAM_SIZES),CB_SETCURSEL,0,0);

		if(!pFindFirstStreamW)
		{	HMODULE hm = LoadLibrary(L"Kernel32.dll");
			if(hm)
			{	pFindFirstStreamW = (HANDLE(__stdcall*)(LPCWSTR,STREAM_INFO_LEVELS,LPVOID,DWORD))GetProcAddress(hm,"FindFirstStreamW");
				pFindNextStreamW = (BOOL(__stdcall*)(HANDLE,LPVOID))GetProcAddress(hm,"FindNextStreamW");
		}	}
		return TRUE;
	case WM_COMMAND:
		switch(LOWORD(wParam))
		{	case IDOK:
				EndDialog(hDlg,0);
				return FALSE;
			case IDCANCEL:
				EndDialog(hDlg,0);
				return FALSE;
			case IDC_BUTTON_VIEW:
				return (INT_PTR)TRUE;
			case IDC_BUTTON_DETACH_STREAM:
				int sel;sel = (int)SendMessage(GetDlgItem(hDlg,IDC_LIST_STREAM_NAMES),
								CB_GETCURSEL,0,0);
				DetachStreamFromFile(sel);
				return (INT_PTR)TRUE;
			case IDC_LIST_STREAM_NAMES:
				if(HIWORD(wParam)==CBN_SELCHANGE)
				{	int sel;sel = (int)SendMessage(GetDlgItem(hDlg,IDC_LIST_STREAM_NAMES),
								CB_GETCURSEL,0,0);
								SendMessage(GetDlgItem(hDlg,IDC_LIST_STREAM_SIZES),
								CB_SETCURSEL,sel,0);
				}
				return (INT_PTR)TRUE;
			case IDC_LIST_STREAM_SIZES:
				if(HIWORD(wParam)==CBN_SELCHANGE)
				{	int sel;sel = (int)SendMessage(GetDlgItem(hDlg,IDC_LIST_STREAM_SIZES),
								CB_GETCURSEL,0,0);
								SendMessage(GetDlgItem(hDlg,IDC_LIST_STREAM_NAMES),
								CB_SETCURSEL,sel,0);
				}
				return (INT_PTR)TRUE;
		}
		break;
	}
	return (INT_PTR)FALSE;
}

//Bu uchun Vista va undan yuqori bo'lishi shart:
VOID EnumFileStreams(HWND hPrnt,wchar_t *fullPathAndName)
{
	if(!pFindFirstStreamW)
	{	HMODULE hm = LoadLibrary(L"Kernel32.dll");
		if(hm)
		{	pFindFirstStreamW = (HANDLE(__stdcall*)(LPCWSTR,STREAM_INFO_LEVELS,LPVOID,DWORD))GetProcAddress(hm,"FindFirstStreamW");
			pFindNextStreamW = (BOOL(__stdcall*)(HANDLE,LPVOID))GetProcAddress(hm,"FindNextStreamW");
			if(!pFindFirstStreamW)return;
			if(!pFindNextStreamW)return;
	}	}

	/*char pch[512]; shu b-n tekshurdik;
	FILE_STREAM_INFO *pi = (FILE_STREAM_INFO*)pch;
	HANDLE hh = CreateFile(fullPathAndName,GENERIC_READ,FILE_SHARE_READ,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);
	int r = GetFileInformationByHandleEx(hh,FileStreamInfo,pi,512);*/

WIN32_FIND_STREAM_DATA d;

	//1-st enum streams:
int iStreams=0;
HANDLE h = pFindFirstStreamW(fullPathAndName,FindStreamInfoStandard,&d,0);
	if(h==INVALID_HANDLE_VALUE)
	{	MessageBox(hPrnt,L"This file do not contain any streams.",fullPathAndName,MB_OK);
		return;
	}
	iStreams++;
	while(pFindNextStreamW(h, &d))
		iStreams++;
	FindClose(h);

	if(1==iStreams)
	{	MessageBox(hPrnt,L"This file contain only one(main) stream.",fullPathAndName,MB_OK);
		return;
	}

	//2-nd: Alloc:
	WIN32_FIND_STREAM_DATA *pstreamdata=(WIN32_FIND_STREAM_DATA*)
			malloc(iStreams*sizeof(WIN32_FIND_STREAM_DATA));

	//3-d: Fill data:
	iStreams=0;
	h = pFindFirstStreamW(fullPathAndName,FindStreamInfoStandard,&pstreamdata[0],0);
	iStreams++;
	while(pFindNextStreamW(h, &pstreamdata[iStreams]))
	{	iStreams++;
	}
	FindClose(h);

	//4-th:Call dialog:
	streamStru.nStreams = iStreams;
	MyStringCpy(streamStru.fileName,MAX_PATH,fullPathAndName);
	if(streamStru.pstreamdata)free(streamStru.pstreamdata);
	streamStru.pstreamdata = pstreamdata;

	DialogBoxParam(hInst,MAKEINTRESOURCE(IDD_DIALOG_STREAMS),hPrnt,FileStreamsDlgProc,(LPARAM)&streamStru);
}

//Bu uchun Vista va undan yuqori bo'lishi shart:
BOOL IsFileConsistStream(wchar_t *fullPathAndName)
{
	if(!pFindFirstStreamW)
	{	HMODULE hm = LoadLibrary(L"Kernel32.dll");
		if(hm)
		{	pFindFirstStreamW = (HANDLE(__stdcall*)(LPCWSTR,STREAM_INFO_LEVELS,LPVOID,DWORD))GetProcAddress(hm,"FindFirstStreamW");
			pFindNextStreamW = (BOOL(__stdcall*)(HANDLE,LPVOID))GetProcAddress(hm,"FindNextStreamW");
			if(!pFindFirstStreamW)
				return FALSE;
			if(!pFindNextStreamW)
				return FALSE;
	}	}

	/*char pch[512]; shu b-n tekshurdik;
	FILE_STREAM_INFO *pi = (FILE_STREAM_INFO*)pch;
	HANDLE hh = CreateFile(fullPathAndName,GENERIC_READ,FILE_SHARE_READ,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);
	int r = GetFileInformationByHandleEx(hh,FileStreamInfo,pi,512);*/

WIN32_FIND_STREAM_DATA d;

	//1-st enum streams:
int iStreams=0;
HANDLE h = pFindFirstStreamW(fullPathAndName,FindStreamInfoStandard,&d,0);
	if(h==INVALID_HANDLE_VALUE)
		return FALSE;
	iStreams++;
	while(pFindNextStreamW(h, &d))
		iStreams++;
	FindClose(h);

	if(1==iStreams)
		return FALSE;
	return TRUE;
}
}//end of namespace fileStream