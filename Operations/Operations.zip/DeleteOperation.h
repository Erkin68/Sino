#ifndef __DELETE_OPERATION_H_

#include "windows.h"
#include "CopyOperation.h"


class Panel;
namespace fDelOper
{
	extern BOOL Delete(Panel*,BOOL);
	extern int  GetFilesInFolder(wchar_t*,CpyStack*);
	extern int  GetFilesCntInFolder(wchar_t *path);
	extern VOID deleteExThrdFnc(LPVOID*);
	extern INT_PTR CALLBACK actnDlgProc(HWND,UINT,WPARAM,LPARAM);
	extern INT_PTR CALLBACK actnDlgProc1(HWND,UINT,WPARAM,LPARAM);
}

#endif
