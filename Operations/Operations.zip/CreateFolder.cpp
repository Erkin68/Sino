#include "CreateFolder.h"
#include "strsafe.h"
#include "MyErrors.h"
#include "LinkSocket.h"
#include "..\sino.h"
#include "..\config.h"
//#include "MyShell\MyButtonC++.h"
#include "MyShell\resource.h"


namespace CreaFolder
{

int      panelNum;
wchar_t* path;
wchar_t  Name[MAX_PATH];
BOOL     bCanceled;


INT_PTR CALLBACK DlgProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
static HFONT hf=0;static int hfRef=0;//obshiy hf, dinamik uchun emas:
static HBRUSH br=0;
static HBRUSH brHtBk=0;
	UNREFERENCED_PARAMETER(lParam);
	//char s[128];sprintf(s,"\n%x %x %x",message,wParam,lParam);
	//OutputDebugString(s);

	switch (message)
	{
	case WM_INITDIALOG:
		//Adjust to center:
		RECT rc; GetWindowRect(hDlg, &rc);
		int width,left,height,top;

		width = rc.right - rc.left;
		left = conf::wndLeft + (conf::wndWidth - width)/2;

		height = rc.bottom - rc.top;
		top = conf::wndTop + (conf::wndHeight - height)/2;
		MoveWindow(hDlg, left, top+20, width, height, TRUE);

		//Load language strings:
		wchar_t s[MAX_PATH];
		LoadString(hInst,IDS_STRINGSW_141,s,MAX_PATH);
		SetWindowText(hDlg,s);
		LoadString(hInst,IDS_STRINGSW_11,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_STATIC,s);
		LoadString(hInst,IDS_STRINGSW_41,s,MAX_PATH);
		SetDlgItemText(hDlg,IDOK,s);
		LoadString(hInst,IDS_STRINGSW_13,s,MAX_PATH);
		SetDlgItemText(hDlg,IDCANCEL,s);

		SendMessage(hDlg,WM_USER+1,0,0);
		SetWindowLong(hDlg,GWLP_USERDATA,(LONG)lParam);

		//MyButtonFrRCBtn(hDlg,IDOK,conf::Dlg.iBtnsType);
		//MyButtonFrRCBtn(hDlg,IDCANCEL,conf::Dlg.iBtnsType);
	
		return TRUE;

	case WM_CTLCOLORSTATIC:
	case WM_CTLCOLORDLG:
		if(2==conf::Dlg.iBtnsType)//ownedraw
		{	HDC dc;dc = (HDC)wParam;
			SetTextColor(dc,conf::Dlg.dlgRGBs[3][1]);
			SetBkColor(dc,conf::Dlg.dlgRGBs[3][2]);
			return (INT_PTR)br;
		}return 0;
	case WM_CTLCOLOREDIT:
		if(2==conf::Dlg.iBtnsType)//ownedraw
		{	HDC dc = (HDC)wParam;
			SetTextColor(dc,conf::Dlg.dlgRGBs[3][1]);
			SetBkColor(dc,conf::Dlg.dlgRGBs[3][2]);
			return (INT_PTR)br;
		}return 0;
	case WM_CTLCOLORBTN:
		if(2==conf::Dlg.iBtnsType)//ownedraw
		{	HDC dc=(HDC)wParam;
			SetTextColor(dc,conf::Dlg.dlgRGBs[3][4]);
			SetBkColor(dc,conf::Dlg.dlgRGBs[3][5]);
			return (INT_PTR)brHtBk;
		}return 0;
	case WM_DRAWITEM://WM_CTLCOLORBTN dagi knopkalar:
		if(2==conf::Dlg.iBtnsType)//ownedraw
		{	LPDRAWITEMSTRUCT lpdis;lpdis = (LPDRAWITEMSTRUCT)lParam;
			GetWindowText(lpdis->hwndItem,s,64);
			UINT uStyle;uStyle = DFCS_BUTTONPUSH;
			rc = lpdis->rcItem;
			if(lpdis->itemState & ODS_SELECTED)
			{	uStyle |= DFCS_PUSHED;
				rc.left+=2;rc.top+=2;
			}
			DrawFrameControl(lpdis->hDC, &lpdis->rcItem, DFC_BUTTON, uStyle);
			if(lpdis->itemState & ODS_SELECTED)
				{rc.left+=1;rc.top+=1;rc.bottom-=2;rc.right-=3;}
			else
				{rc.left+=1;rc.top+=2;rc.bottom-=3;rc.right-=3;}
			FillRect(lpdis->hDC,&rc,brHtBk);//DrawText(lpdis->hDC,"                                                  ",50,&rc,DT_SINGLELINE|DT_VCENTER|DT_INTERNAL|DT_LEFT);
			if(lpdis->itemState & ODS_SELECTED)
				{rc.left-=1;rc.top-=1;rc.bottom+=3;rc.right+=3;}
			else
				{rc.left-=1;rc.top-=2;rc.bottom+=2;rc.right+=3;}
			DrawText(lpdis->hDC,s,MyStringLength(s,64),&rc,DT_SINGLELINE|DT_VCENTER|DT_CENTER);
			return TRUE;
		}return 0;
	case WM_USER+1://hf obshiy uchun, dinamik o'zgartirish uchun emas:
		if(0==hfRef)
		{	hf = CreateFontIndirect(&conf::Dlg.dlgFnts[3]);
			br = CreateSolidBrush(conf::Dlg.dlgRGBs[3][0]);
			brHtBk = CreateSolidBrush(conf::Dlg.dlgRGBs[3][5]);
		}
		SendMessage(GetDlgItem(hDlg,IDC_STATIC),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDOK),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDCANCEL),WM_SETFONT,(WPARAM)hf,TRUE);
		++hfRef;
		return 0;//GWLP_USERDATA
	case WM_DESTROY:
		if(--hfRef<1)
		{	DeleteObject(hf);
			DeleteObject(br);
			DeleteObject(brHtBk);
		}
		return 0;
	case WM_USER+2://Dinamik o'zgartirish uchun:
		DeleteObject(hf);hfRef=1;
		hf = CreateFontIndirect(&conf::Dlg.dlgFnts[3]);
		SendMessage(GetDlgItem(hDlg,IDC_STATIC),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDOK),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDCANCEL),WM_SETFONT,(WPARAM)hf,TRUE);
		return 0;//GWLP_USERDATA
	case WM_USER+3://Dinamik o'zgartirish uchun, colorni:
		DeleteObject(br);DeleteObject(brHtBk);hfRef=1;
		br = CreateSolidBrush(conf::Dlg.dlgRGBs[3][0]);
		brHtBk = CreateSolidBrush(conf::Dlg.dlgRGBs[3][5]);
		RedrawWindow(hDlg,NULL,NULL,RDW_INVALIDATE|RDW_ALLCHILDREN);
		return 0;//GWLP_USERDATA
	case WM_COMMAND:
		switch(LOWORD(wParam))
		{	case IDOK:
			if(!GetWindowLong(hDlg,GWLP_USERDATA))return TRUE;
			int ln;ln=GetDlgItemText(hDlg,IDC_EDIT_NEW_FOLDER_NAME,Name,MAX_PATH);

			wchar_t ch[4];ch[0]=' ';
			for(int i=0; i<ln; ++i)
			{	if('<'==Name[i])
					ch[0]='<';
				else if('>'==Name[i])
					ch[0]='>';
				else if(':'==Name[i])
					ch[0]=':';
				else if('"'==Name[i])
					ch[0]='"';
				else if('/'==Name[i])
					ch[0]='/';
				else if('|'==Name[i])
					ch[0]='|';
				else if('?'==Name[i])
					ch[0]='?';
				else if('*'==Name[i])
					ch[0]='*';
				if(ch[0]!=' ')
				{	MessageBox(hWnd,L"Directory name cannot contain character:",ch,MB_OK);
					return FALSE;
			}	}
			wchar_t *p;p=0;
			if(0==wcscmp(Name,L"CON"))
				p=&Name[0];
			else if(0==wcscmp(Name,L"PRN"))
				p=&Name[0];
			else if(0==wcscmp(Name,L"AUX"))
				p=&Name[0];
			else if(0==wcscmp(Name,L"NUL"))
				p=&Name[0];
			else if(0==wcscmp(Name,L"COM1"))
				p=&Name[0];
			else if(0==wcscmp(Name,L"COM2"))
				p=&Name[0];
			else if(0==wcscmp(Name,L"COM3"))
				p=&Name[0];
			else if(0==wcscmp(Name,L"COM4"))
				p=&Name[0];
			else if(0==wcscmp(Name,L"COM5"))
				p=&Name[0];
			else if(0==wcscmp(Name,L"COM6"))
				p=&Name[0];
			else if(0==wcscmp(Name,L"COM7"))
				p=&Name[0];
			else if(0==wcscmp(Name,L"COM8"))
				p=&Name[0];
			else if(0==wcscmp(Name,L"COM9"))
				p=&Name[0];
			else if(0==wcscmp(Name,L"LPT1"))
				p=&Name[0];
			else if(0==wcscmp(Name,L"LPT2"))
				p=&Name[0];
			else if(0==wcscmp(Name,L"LPT3"))
				p=&Name[0];
			else if(0==wcscmp(Name,L"LPT4"))
				p=&Name[0];
			else if(0==wcscmp(Name,L"LPT5"))
				p=&Name[0];
			else if(0==wcscmp(Name,L"LPT6"))
				p=&Name[0];
			else if(0==wcscmp(Name,L"LPT7"))
				p=&Name[0];
			else if(0==wcscmp(Name,L"LPT8"))
				p=&Name[0];
			else if(0==wcscmp(Name,L"LPT9"))
				p=&ch[0];
			if(p)
			{	MessageBox(hWnd,L"CON,PRN,AUX,NUL,COM1,COM2,COM3,COM4,COM5,COM6,COM7,COM8,COM9,LPT1,LPT2,LPT3,LPT4,LPT5,LPT6,LPT7,LPT8,LPT9",L"File name cannot contain words:",MB_OK);
				return FALSE;
			}


			if(ln>0)
				bCanceled = FALSE;
			else
				bCanceled = TRUE;
			EndDialog(hDlg, 1);
			return (INT_PTR)TRUE;
			case IDCANCEL://ESC
			if(!GetWindowLong(hDlg,GWLP_USERDATA))return TRUE;
				bCanceled = TRUE;
				EndDialog(hDlg, 0);
				return (INT_PTR)TRUE;
		}
		break;
	}
	return (INT_PTR)FALSE;
}

VOID ShowDlg(Panel *frPanel)
{
	if(rndPathList==frPanel->GetEntry()->GetCrntRecType())
	{	MessageBox(hWnd,L"Do not ccreate folder in results list of searching.",L"Warn!!!",MB_OK|MB_ICONWARNING|MB_SYSTEMMODAL);
		return;
	}

	panelNum = frPanel->iThis;
	Err::AssertFatal(panelNum>-1 && panelNum<4, L"CreateFolder panel number define error...");
	path = frPanel->GetPath();
	//r = DialogBoxParam(hInst,MAKEINTRESOURCE(IDD_DIALOG_CREA_FOLDER),hWnd,DlgProc,this);
	if(-1==DialogBoxParam(hInst,MAKEINTRESOURCE(IDD_DIALOG_CREA_FOLDER),hWnd,DlgProc,1))
	{	return;
	}//else:
	if(bCanceled) return;
	wchar_t p[MAX_PATH];
	int l=MyStringCpy(p,MAX_PATH-1,path);
	if('*'==p[l-1])//MyStringRemoveLastCharCheckPre(p,MAX_PATH-1,'*','\\');
	if('\\'==p[l-2])
		p[--l]=0;
	l+=MyStringCpy(&p[l],MAX_PATH-l,Name);//MyStringCat(p,MAX_PATH-1,Name);

	switch(frPanel->GetEntry()->GetCrntRecType())
	{	default:case unknown:
			break;
		case socketCl:
			linkSock::SendToServerMsg(panelNum,LNKSCKMSG_CREATE_FOLDER_NOT_WAIT,p);
			break;
		case directFolder:
			MyCreateDirectory(p,NULL);
			wchar_t *pp;pp = wcsrchr(p,'\\');
			if(pp)
				MyStringCpy(frPanel->findItemName,MAX_PATH,pp+1);
			break;
		case archElem:
			wchar_t s[MAX_PATH];l=MyStringCpy(s,MAX_PATH-1,frPanel->GetArcPath());
			if(l)
			{	if('\\' != s[l-1])
					s[l++]='\\';
			}
			l+=MyStringCpy(&s[l],MAX_PATH-l-1,Name);
			if('\\' != s[l-1])
				s[l++]='\\';
			s[l]=0;
			frPanel->GetArch()->Close$4();
			frPanel->GetArch()->Open$12(frPanel->GetArcFilePathAndName(),frPanel->GetArch()->GetPlgNum(),2);//opn exstng
         BEGIN_TRY
		    if(archive::plgns[frPanel->GetArch()->GetPlgNum()].AddEmptyDir$20)
				archive::plgns[frPanel->GetArch()->GetPlgNum()].AddEmptyDir$20(
						frPanel->GetArch()->GetPlgObj(),
						s,
						L"",//password,
						9,
						FALSE);
			else
			{	archive::plgns[frPanel->GetArch()->GetPlgNum()].RebuildCheckExistings$8(
						frPanel->GetArch()->GetPlgObj(),L"");
				archive::plgns[frPanel->GetArch()->GetPlgNum()].CreateDir$24(
						frPanel->GetArch()->GetPlgObj(),
						frPanel->GetArcFilePathAndName(),
						s,
						L"",//password,
						9,
						FALSE);
			}
			frPanel->GetArch()->Close$4();
			frPanel->GetArch()->OpenForUnpacking$8(frPanel->GetArcFilePathAndName(),frPanel->GetArch()->GetPlgNum());
		 END_TRY
		 {
		 }
			int id;id=frPanel->GetHot();
			if(id<0 || id>frPanel->GetTotItems()-1)
				id = frPanel->GetSelectedItemNum(0);
			if(id>0 && id<frPanel->GetTotItems())
				MyStringCpy(frPanel->findItemName,MAX_PATH-1,frPanel->GetItem(id)->Name);
			frPanel->FreeMem();//p->FreeSelection(); shartmas
			frPanel->FillArchItems(frPanel->GetArcPath());
			frPanel->ChangeSheetTabPath();
			frPanel->AdjustScrollity();
			if(id>0 && id<frPanel->GetTotItems())
				frPanel->FindItem(frPanel->findItemName);
			else
				frPanel->ScrollItemToView(0);
			frPanel->ClrScr();
			frPanel->Render(NULL);
			frPanel->SetFocus();
			break;
		case guidFolder:
			// void *ppv;
			//SHCreateItemInKnownFolder((wchar_t*)frPanel->path,KF_FLAG_CREATE,p,
			//	REFIID riid, &ppv);
			break;
}	}

}//namespace CreaFolder
