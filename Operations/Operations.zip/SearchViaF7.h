#ifndef __SEARCH_VIA_F7_H_
#define __SEARCH_VIA_F7_H_

//#include "..\Panel.h"
#include "windows.h"

class Panel;
//class PanelItem;

namespace fSearchViaF7
{

extern VOID FreePlugins();
extern VOID LoadPlugins();

};//end of namespace;

#endif
