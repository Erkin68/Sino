#include "windows.h"
#include "strsafe.h"
#include <malloc.h>
#include "..\sino.h"
#include "..\Asm\MyStrCmpNN_SSE.h"


#define _CRT_SECURE_NO_WARNINGS

extern "C"
{
extern int MyStringCpyA(char*,int,char*);

VOID ConvertToLittleA(char *txt, int ln)
{	register int LN = ln>0?ln:MAX_PATH;
	for(register int i=0; i<LN; i++)
	{	if(!ln)
		if(!txt[i])//('\0'==txt[i])
			return;
		if(txt[i]<91)
		{	if(txt[i]>64)
				txt[i]+=32;
		} else
		{	if(txt[i]<224)
			{	if(txt[i]>191)
				txt[i]+=32;
}	}	}	}

VOID ConvertToLittle(wchar_t *txt, int ln)
{	register int LN = ln>0?ln:MAX_PATH;
	for(register int i=0; i<LN; i++)
	{	if(!ln)
		if(!txt[i])//('\0'==txt[i])
			return;
		if(txt[i]<91)
		{	if(txt[i]>64)
				txt[i]+=32;
		} else
		{	if(txt[i]<224)
			{	if(txt[i]>191)
				txt[i]+=32;
}	}	}	}

char* ConvertToLittleRA(char *txt, int ln)
{	
static char R[MAX_PATH];
	register int LN = ln>0?ln:MAX_PATH;
	for(register int i=0; i<LN; i++)
	{	R[i]=txt[i];
		if(!ln)
		if(!R[i])//('\0'==txt[i])
			return R;
		if(R[i]<91)
		{	if(R[i]>64)
				R[i]+=32;
		} else
		{	if(R[i]<224)
			{	if(R[i]>191)
				R[i]+=32;
	}	}	}
	return R;
}

wchar_t* ConvertToLittleR(wchar_t *txt, int ln)
{	
static wchar_t R[MAX_PATH];
	register int LN = ln>0?ln:MAX_PATH;
	for(register int i=0; i<LN; i++)
	{	R[i]=txt[i];
		if(!ln)
		if(!R[i])//('\0'==txt[i])
			return R;
		if(R[i]<91)
		{	if(R[i]>64)
				R[i]+=32;
		} else
		{	if(R[i]<224)
			{	if(R[i]>191)
				R[i]+=32;
	}	}	}
	return R;
}

unsigned __int64 MyAtoU64A(char *s)
{
register unsigned __int64 rt=0;
char *ps = s;
	while(*ps!=0)
	{	if(*ps < '0')
			return 0;
		if(*ps > '9')
			return 0;
		rt = rt*10 + (*ps - '0');
		ps++;
	}
	return rt;
}

unsigned __int64 MyAtoU64(wchar_t *s)
{
register unsigned __int64 rt=0;
wchar_t *ps = s;
	while(*ps!=0)
	{	if(*ps < '0')
			return 0;
		if(*ps > '9')
			return 0;
		rt = rt*10 + (*ps - '0');
		ps++;
	}
	return rt;
}

BOOL MyU64ToA(char* st,int sLen,unsigned __int64 u)
{
register int l=0;
register unsigned __int64 delit = u;
static char s[32];
	if(!u)
	{	st[0] = '0';
		st[1] = 0;
		return true;
	}

	while(delit)
	{	s[l++] = delit % 10 + '0';
		delit /= 10;
	}
	for(int i=0; i<l; i++)
		st[i] = s[l-i-1];
	st[l] = 0;
	return true;
}

BOOL MyU64To(wchar_t* st,int sLen,unsigned __int64 u)
{
register int l=0;
register unsigned __int64 delit = u;
static wchar_t s[32];
	if(!u)
	{	st[0] = '0';
		st[1] = 0;
		return true;
	}

	while(delit)
	{	s[l++] = delit % 10 + '0';
		delit /= 10;
	}
	for(int i=0; i<l; i++)
		st[i] = s[l-i-1];
	st[l] = 0;
	return true;
}

char* MyStringAddModulePathA(char* name)
{
static char path[MAX_PATH]="";
static char* pend;int l=0;
	if(!path[0])//('\0'==path[0])
	{	l=GetModuleFileNameA(NULL,path,MAX_PATH);
		pend = strrchr(path,'\\')+1;
	}
	if(!pend)pend=&path[l];
	MyStringCpyA(pend,MAX_PATH-1,name);
	return path;
}

wchar_t* MyStringAddModulePath(wchar_t* name)
{
static wchar_t path[MAX_PATH]=L"";
static wchar_t* pend;int l=0;
	if(!path[0])//('\0'==path[0])
	{	l=GetModuleFileName(NULL,path,MAX_PATH);
		pend = wcsrchr(path,'\\')+1;
	}
	if(!pend)pend=&path[l];
	MyStringCpy(pend,MAX_PATH-1,name);
	return path;
}

int MyStringCatA(char* buf, int mx, char* src)
{	register int l=-1;
	while(++l<mx)
	{	if(!buf[l]) break;//('\0'==buf[l])
		if(l>=mx) break;
	}
	register int l1=-1;
	while(++l1<mx-1)
	{	buf[l+l1] = src[l1];
		if(!src[l1]) break;//('\0'==src[l1])
	}
	if(buf[l+l1])//0 bo'lmasa;
	if(l1>=mx)
		buf[l+(--l1)] = 0;
	return l1;
}

int MyStringCat(wchar_t* buf, int mx, wchar_t* src)
{	register int l=-1;
	while(++l<mx)
	{	if(!buf[l]) break;//('\0'==buf[l])
		if(l>=mx) break;
	}
	register int l1=-1;
	while(++l1<mx-1)
	{	buf[l+l1] = src[l1];
		if(!src[l1]) break;//('\0'==src[l1])
	}
	if(buf[l+l1])//0 bo'lmasa;
	if(l1>=mx)
		buf[l+(--l1)] = 0;
	return l1;
}

int MyStringCpyA(char* buf, int mx, char* src)
{	if(!src)
	{	buf[0]=0;
		return 0;
	}	
	register int l=-1;
	while(++l<mx)
	{	buf[l] = src[l];
		if(!src[l]) break;//('\0'==src[l])
	}
	if(buf[l])//0 bo'lmasa;
	if(l>=mx)
		buf[l] = 0;
	return l;
}

int MyStringCpy(wchar_t* buf, int mx, wchar_t* src)//mx null siz chalar soni deb faraz qilamiz;
{	if(!src)
	{	buf[0]=0;
		return 0;
	}	
	register int l=-1;
	while(++l<mx)
	{	buf[l] = src[l];
		if(!src[l]) break;//(0==src[l])
	}
	if(buf[l])//0 bo'lmasa;
	if(l>=mx)
		buf[l] = 0;
	return l;
}

int MyStringEraseEndAndCatA(char* buf, int mx, char* src)
{	register int l=-1;
	while(++l<mx)
	{	if(!buf[l]) break;//(0==buf[l])
		if(l>=mx) break;
	}
	int l1=-1;
	if(l>0) --l;
	while(++l1<mx-1)
	{	buf[l+l1] = src[l1];
		if(!src[l1]) break;//(0==src[l1]) 
	}
	if(buf[l+l1])
	if(l1>=mx)
		buf[l+(--l1)] = 0;
	return l1;
}

int MyStringEraseEndAndCat(wchar_t* buf, int mx, wchar_t* src)
{	register int l=-1;
	while(++l<mx)
	{	if(!buf[l]) break;//(0==buf[l])
		if(l>=mx) break;
	}
	int l1=-1;
	if(l>0) --l;
	while(++l1<mx-1)
	{	buf[l+l1] = src[l1];
		if(!src[l1]) break;//(0==src[l1]) 
	}
	if(buf[l+l1])
	if(l1>=mx)
		buf[l+(--l1)] = 0;
	return l1;
}

char *MyStringFindFirstUnmatchA(char *dst, char *src, int ln)
{
	for(register int i=0; i<ln; i++)
	{	if(dst[i] ^ src[i])//(dst[i] != src[i])
			return &dst[i];
	}
	return NULL;
}

wchar_t *MyStringFindFirstUnmatch(wchar_t *dst, wchar_t *src, int ln)
{
	for(register int i=0; i<ln; i++)
	{	if(dst[i] ^ src[i])//(dst[i] != src[i])
			return &dst[i];
	}
	return NULL;
}

int MyStringLengthA(char* buf, int mx)
{	if(!buf[0])return 0;
	register int l=-1;
	while(++l<mx)
	{	if(!buf[l])//(0==buf[l])
			return l;
		if(l>=mx)
			return l;
	};
	return l;
}

int MyStringLength(wchar_t* buf, int mx)
{	if(!buf[0])return 0;
	register int l=-1;
	while(++l<mx)
	{	if(!buf[l])//(0==buf[l])
			return l;
		if(l>=mx)
			return l;
	};
	return l;
}

BOOL MyStrCmpNA(char *str0, char *str1, int n)
{
	register int dn = n>>2;//n/4;
	register int d = n & 0x0003;//n%4;
	DWORD *p0 = (DWORD*)str0;
	DWORD *p1 = (DWORD*)str1;
	for(register int dw=0; dw<dn; dw++)
	{	if(p0[dw] ^ p1[dw])//(p0[dw] != p1[dw])
			return FALSE;
	}
	for(register int i=n-d; i<n; i++)
	{	if(str0[i] ^ str1[i])//(str0[i] != str1[i])
			return FALSE;
	}
	return TRUE;
}

BOOL MyStrCmpNW(wchar_t *str0, wchar_t *str1, int n)
{
	register int dn = n>>2;//n/4;
	register int d = n & 0x0003;//n%4;
	DWORD *p0 = (DWORD*)str0;
	DWORD *p1 = (DWORD*)str1;
	for(register int dw=0; dw<dn; dw++)
	{	if(p0[dw] ^ p1[dw])//(p0[dw] != p1[dw])
			return FALSE;
	}
	for(register int i=n-d; i<n; i++)
	{	if(str0[i] ^ str1[i])//(str0[i] != str1[i])
			return FALSE;
	}
	return TRUE;
}

BOOL IsBin(char ch)
{
	if(ch >= '0')
	if(ch <= '9')
		return TRUE;
	if(ch >= 'A')
	if(ch <= 'F')
		return TRUE;
	if(ch >= 'a')
	if(ch <= 'f')
		return TRUE;
	return FALSE;
}

/*BOOL IsBin(wchar_t ch)
{
	if(ch >= '0')
	if(ch <= '9')
		return TRUE;
	if(ch >= 'A')
	if(ch <= 'F')
		return TRUE;
	if(ch >= 'a')
	if(ch <= 'f')
		return TRUE;
	return FALSE;
}*/

char* MyStrCmpBinNA(char *str0, char *str1, int N, int n)//2-str is binary representation;
{	//n num of symbols in str0, for each pair in str1!!!
char *s = (char*)_malloca(n/2);
char *ps = s;
	for(register int i=0; i<n; i++)
	{	if(str1[2*i]>='0' && str1[2*i]<='9')
			*ps = str1[2*i] - '0';
		else if(str1[2*i]>='A' && str1[2*i]<='F')
			*ps = str1[2*i] - 'A' + 10;
		else if(str1[2*i]>='a' && str1[2*i]<='f')
			*ps = str1[2*i] - 'a' + 10;
		ps++;
	}
	ps = MyStrCmpNNA(str0, s, N, n);
	_freea(s);
	return ps;
}

wchar_t* MyStrCmpBinNW(wchar_t *str0, wchar_t *str1, int N, int n)//2-str is binary representation;
{	//n num of symbols in str0, for each pair in str1!!!
wchar_t *s = (wchar_t*)_malloca(n);
wchar_t *ps = s;
	for(register int i=0; i<n; i++)
	{	if(str1[2*i]>='0' && str1[2*i]<='9')
			*ps = str1[2*i] - '0';
		else if(str1[2*i]>='A' && str1[2*i]<='F')
			*ps = str1[2*i] - 'A' + 10;
		else if(str1[2*i]>='a' && str1[2*i]<='f')
			*ps = str1[2*i] - 'a' + 10;
		ps++;
	}
	ps = MyStrCmpNNW(str0, s, N, n);
	_freea(s);
	return ps;
}

BOOL MyStrCmpNotRelUpRegNA(char *str0, char *str1, int n)//Upper registr unreleated;
{
	for(register int i=0; i<n; i++)
	{	if(str0[i] >= 'A' && str0[i] <= 'Z')
		{	if(str0[i] ^ str1[i] && (str0[i]+32) ^ str1[i])//(str0[i] != str1[i] && str0[i]+32 != str1[i])
				return FALSE;
		}
		else if(str0[i] >= 'a' && str0[i] <= 'z')
		{	if(str0[i] ^ str1[i] && (str0[i]-32) ^ str1[i])//(str0[i] != str1[i] && str0[i]-32 != str1[i])
				return FALSE;
		}
		else if(str0[i] >= '�' && str0[i] <= '�')
		{	if(str0[i] ^ str1[i] && (str0[i]+32) ^ str1[i])//(str0[i] != str1[i] && str0[i]+32 != str1[i])
				return FALSE;
		}
		else if(str0[i] >= '�' && str0[i] <= '�')
		{	if(str0[i] ^ str1[i] && (str0[i]-32) ^ str1[i])//(str0[i] != str1[i] && str0[i]-32 != str1[i])
				return FALSE;
		}
		else if(str0[i] ^ str1[i])//(str0[i] != str1[i])
			return FALSE;
	}
	return TRUE;
}

BOOL MyStrCmpNotRelUpRegNW(wchar_t *str0, wchar_t *str1, int n)//Upper registr unreleated;
{
	for(register int i=0; i<n; i++)
	{	if(str0[i] >= 'A' && str0[i] <= 'Z')
		{	if(str0[i] ^ str1[i] && (str0[i]+32) ^ str1[i])//(str0[i] != str1[i] && str0[i]+32 != str1[i])
				return FALSE;
		}
		else if(str0[i] >= 'a' && str0[i] <= 'z')
		{	if(str0[i] ^ str1[i] && (str0[i]-32) ^ str1[i])//(str0[i] != str1[i] && str0[i]-32 != str1[i])
				return FALSE;
		}
		else if(str0[i] >= '�' && str0[i] <= '�')
		{	if(str0[i] ^ str1[i] && (str0[i]+32) ^ str1[i])//(str0[i] != str1[i] && str0[i]+32 != str1[i])
				return FALSE;
		}
		else if(str0[i] >= '�' && str0[i] <= '�')
		{	if(str0[i] ^ str1[i] && (str0[i]-32) ^ str1[i])//(str0[i] != str1[i] && str0[i]-32 != str1[i])
				return FALSE;
		}
		else if(str0[i] ^ str1[i])//(str0[i] != str1[i])
			return FALSE;
	}
	return TRUE;
}

/*char* MyStrRChrN(char* src, int ln, char c, int n)
{
	int Ln = MyStringLength(src,ln);
int k=0;
	for(register int i=Ln-1; i>=0; i--)
	{	if(!(c^src[i]))//(c==src[i])
		{	if(++k>=n)
				return &src[i];
	}	}
	return NULL;
}*/

wchar_t* MyStrRChrN(wchar_t* src, int ln, wchar_t c, int n)
{
	int Ln = MyStringLength(src,ln);
int k=0;
	for(register int i=Ln-1; i>=0; i--)
	{	if(!(c^src[i]))//(c==src[i])
		{	if(++k>=n)
				return &src[i];
	}	}
	return NULL;
}

VOID MyTimeToStringA(char *s, DWORD tick)
{
	register int hour = tick / 3600000;
	register int min = tick / 60000;
	register int sec = (tick / 1000) % 60;
	if(hour)
		StringCchPrintfA(s,MAX_PATH-1,"%.2d:%.2d:%.2d",hour,min,sec);
	else
	{	if(min)
			StringCchPrintfA(s,MAX_PATH-1,"%.2d:%.2d",min,sec);
		else
			StringCchPrintfA(s,MAX_PATH-1,"00:%.2d",sec);
}	}

VOID MyTimeToString(wchar_t *s, DWORD tick)
{
	register int hour = tick / 3600000;
	register int min = tick / 60000;
	register int sec = (tick / 1000) % 60;
	if(hour)
		StringCchPrintf(s,MAX_PATH-1,L"%.2d:%.2d:%.2d",hour,min,sec);
	else
	{	if(min)
			StringCchPrintf(s,MAX_PATH-1,L"%.2d:%.2d",min,sec);
		else
			StringCchPrintf(s,MAX_PATH-1,L"00:%.2d",sec);
}	}

int MyStringPrintDecSpaceA(char *str, __int64 d)
{
	if(d)
	{	register __int64 D = d; char s[32]; s[31]=0; char *ps = &s[30];
		while(D)
		{	int q = D % 1000;
			int q0 = q % 10;
			int q1 = (q / 10) % 10;
			int q2 = (q / 100) % 10;
			*ps-- = q0+48;
			*ps-- = q1+48;
			*ps = q2+48;
			D /= 1000;
			if(D){--ps; *ps-- = ' ';}
		}
		char *pstr = str;
		while(*ps=='0')
			ps++;
		while(ps<&s[31])
			*pstr++ = *ps++;
		*pstr++ = ' ';
		*pstr++ = 'b';
		*pstr = 0;
		return pstr - str;
	} else
	{	str[0] = '0';
		str[1] = ' ';
		str[2] = 'b';
		str[3] = 0;
		return 2;
}	}

int MyStringPrintDecSpace(wchar_t *str, __int64 d)
{
	if(d)
	{	register __int64 D = d; wchar_t s[32]; s[31]=0; wchar_t *ps = &s[30];
		while(D)
		{	int q = D % 1000;
			int q0 = q % 10;
			int q1 = (q / 10) % 10;
			int q2 = (q / 100) % 10;
			*ps-- = q0+48;
			*ps-- = q1+48;
			*ps = q2+48;
			D /= 1000;
			if(D){--ps; *ps-- = ' ';}
		}
		wchar_t *pstr = str;
		while(*ps=='0')
			ps++;
		while(ps<&s[31])
			*pstr++ = *ps++;
		*pstr++ = ' ';
		*pstr++ = 'b';
		*pstr = 0;
		return pstr - str;
	} else
	{	str[0] = '0';
		str[1] = ' ';
		str[2] = 'b';
		str[3] = 0;
		return 2;
}	}

BOOL MyStringRemoveLastCharA(char *str,int maxLen, char ch)
{
	for(register int i=0; i<maxLen; i++)
	{	if(!str[i])//(0==str[i])
		{	if(!(ch ^ str[i-1]))//(ch==str[i-1])
			{	str[i-1] = 0;
				return TRUE;
			}
			return FALSE;
	}	}
	return FALSE;
}

BOOL MyStringRemoveLastChar(wchar_t *str,int maxLen, wchar_t ch)
{
	for(register int i=0; i<maxLen; i++)
	{	if(!str[i])//(0==str[i])
		{	if(!(ch ^ str[i-1]))//(ch==str[i-1])
			{	str[i-1] = 0;
				return TRUE;
			}
			return FALSE;
	}	}
	return FALSE;
}

BOOL MyStringRemoveLastCharCheckPreA(char *str,int maxLen, char ch0, char ch1)
{
	for(register int i=0; i<maxLen; i++)
	{	if(!str[i])//(0==str[i])
		{	if(!(ch0 ^ str[i-1]))//(ch0==str[i-1])
			if(!(ch1 ^ str[i-2]))//(ch1==str[i-2])
			{	str[i-1] = 0;
				return TRUE;
			}
			return FALSE;
	}	}
	return FALSE;
}

BOOL MyStringRemoveLastCharCheckPre(wchar_t *str,int maxLen, wchar_t ch0, wchar_t ch1)
{
	for(register int i=0; i<maxLen; i++)
	{	if(!str[i])//(0==str[i])
		{	if(!(ch0 ^ str[i-1]))//(ch0==str[i-1])
			if(!(ch1 ^ str[i-2]))//(ch1==str[i-2])
			{	str[i-1] = 0;
				return TRUE;
			}
			return FALSE;
	}	}
	return FALSE;
}

BOOL MySubstrA(char *str,char *subStr,int from,int to)
{
register int i;
	for(i=from; i<to; i++)
		subStr[i-from] = str[i];
	subStr[i] = 0;
	return TRUE;
}

BOOL MySubstr(wchar_t *str,wchar_t *subStr,int from,int to)
{
register int i;
	for(i=from; i<to; i++)
		subStr[i-from] = str[i];
	subStr[i] = 0;
	return TRUE;
}

/*static const Byte kUtf8Limits[5] = { 0xC0, 0xE0, 0xF0, 0xF8, 0xFC };
Bool Utf8_To_Utf16(wchar_t *dest, size_t *destLen, const char *src, size_t srcLen)
{
  size_t destPos = 0, srcPos = 0;
  for (;;)
  {
    Byte c;
    int numAdds;
    if (srcPos == srcLen)
    {
      *destLen = destPos;
      return TRUE;
    }
    c = (Byte)src[srcPos++];

    if (c < 0x80)
    {
      if (dest)
        dest[destPos] = (wchar_t)c;
      destPos++;
      continue;
    }
    if (c < 0xC0)
      break;
    for (numAdds = 1; numAdds < 5; numAdds++)
      if (c < kUtf8Limits[numAdds])
        break;
    UInt32 value = (c - kUtf8Limits[numAdds - 1]);

    do
    {
      Byte c2;
      if (srcPos == srcLen)
        break;
      c2 = (Byte)src[srcPos++];
      if (c2 < 0x80 || c2 >= 0xC0)
        break;
      value <<= 6;
      value |= (c2 - 0x80);
    }
    while (--numAdds != 0);
    
    if (value < 0x10000)
    {
      if (dest)
        dest[destPos] = (wchar_t)value;
      destPos++;
    }
    else
    {
      value -= 0x10000;
      if (value >= 0x100000)
        break;
      if (dest)
      {
        dest[destPos + 0] = (wchar_t)(0xD800 + (value >> 10));
        dest[destPos + 1] = (wchar_t)(0xDC00 + (value & 0x3FF));
      }
      destPos += 2;
    }
  }
  *destLen = destPos;
  return False;
}

Bool Utf16_To_Utf8(char *dest, size_t *destLen, const wchar_t *src, size_t srcLen)
{
  size_t destPos = 0, srcPos = 0;
  for (;;)
  {
    unsigned numAdds;
    UInt32 value;
    if (srcPos == srcLen)
    {
      *destLen = destPos;
      return True;
    }
    value = src[srcPos++];
    if (value < 0x80)
    {
      if (dest)
        dest[destPos] = (char)value;
      destPos++;
      continue;
    }
    if (value >= 0xD800 && value < 0xE000)
    {
      UInt32 c2;
      if (value >= 0xDC00 || srcPos == srcLen)
        break;
      c2 = src[srcPos++];
      if (c2 < 0xDC00 || c2 >= 0xE000)
        break;
      value = (((value - 0xD800) << 10) | (c2 - 0xDC00)) + 0x10000;
    }
    for (numAdds = 1; numAdds < 5; numAdds++)
      if (value < (((UInt32)1) << (numAdds * 5 + 6)))
        break;
    if (dest)
      dest[destPos] = (char)(kUtf8Limits[numAdds - 1] + (value >> (6 * numAdds)));
    destPos++;
    do
    {
      numAdds--;
      if (dest)
        dest[destPos] = (char)(0x80 + ((value >> (6 * numAdds)) & 0x3F));
      destPos++;
    }
    while (numAdds != 0);
  }
  *destLen = destPos;
  return False;
}

wchar_t* ToUnicode(char *s)
{
static wchar_t ws[MAX_PATH];
wchar_t *pws=&ws[0];
char cw[2]={0,0};
		
	for(s; *s;)
	{	cw[1]=*s++;
		*pws++ = *((wchar_t*)(cw));
	}
	*pws = 0;
	return ws;
}*/

}//end of "C"