#include "..\Sino.h"
#include "..\Config.h"
#include "strsafe.h"
#include "RenMove.h"
#include "MyErrors.h"
#include "MyShell\MyShell.h"
//#include "MyShell\MyButtonC++.h"
#include "DeleteOperation.h"
#include "Backgrnd thread copy operation.h"
#include "Backgrnd thread move operation.h"


namespace fBckgrndMoveOper
{

#define MYWM_CANCEL	0x7f00
#define MYWM_STOP   0x7f01

CRITICAL_SECTION critSect;
HWND	dlg(NULL);
DWORD   cpyThrdId;
unsigned __int64 totSizes;
unsigned __int64 copyedSizes;


INT_PTR CALLBACK BckgrndMoveDlgProc(HWND hDlg,UINT message,WPARAM wParam,LPARAM lParam)
{
	switch(message)
	{
	case WM_INITDIALOG:

		InitializeCriticalSection(&critSect);

		//Adjust:
		RECT rc; GetWindowRect(hDlg, &rc);
		int width,height;
		width = rc.right - rc.left;
		height = rc.bottom - rc.top;
		MoveWindow(hDlg, conf::bckgrndCpyDlgPozX, conf::bckgrndCpyDlgPozY, width, height, TRUE);//MoveWindow(hDlg, left, top+20, width, height, TRUE);

		//Load language strings:
		wchar_t s[MAX_PATH];
		LoadString(hInst,IDS_STRINGSW_46,s,MAX_PATH);
		SetWindowText(hDlg,s);
		LoadString(hInst,IDS_STRINGSW_47,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_STATIC2,s);
		LoadString(hInst,IDS_STRINGSW_48,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_STATIC4,s);
		LoadString(hInst,IDS_STRINGSW_50,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_BUTTON_STOP,s);
		LoadString(hInst,IDS_STRINGSW_13,s,MAX_PATH);
		SetDlgItemText(hDlg,IDCANCEL,s);

		PostMessage(GetDlgItem(hDlg,IDC_PROGRESS_COPY_SINGLE),PBM_SETRANGE,0,MAKELPARAM(0,1000));
		PostMessage(GetDlgItem(hDlg,IDC_PROGRESS_COPY_TOTAL ),PBM_SETRANGE,0,MAKELPARAM(0,1000));
		PostMessage(GetDlgItem(hDlg,IDC_PROGRESS_COPY_SINGLE),PBM_SETSTEP,1,0);
		PostMessage(GetDlgItem(hDlg,IDC_PROGRESS_COPY_TOTAL ),PBM_SETSTEP,1,0);

		//MyButtonFrRCBtn(hDlg,IDC_BUTTON_STOP,conf::Dlg.iBtnsType);
		//MyButtonFrRCBtn(hDlg,IDCANCEL,conf::Dlg.iBtnsType);

		return TRUE;
	case WM_DESTROY:
		dlg = NULL;
		DeleteCriticalSection(&critSect);
		return TRUE;
	case WM_MOVE:
		conf::bckgrndCpyDlgPozX = (int)(short) LOWORD(lParam);
		conf::bckgrndCpyDlgPozY = (int)(short) HIWORD(lParam);   
		break;
	case WM_COMMAND:
		switch(LOWORD(wParam))
		{	//case IDCANCEL:
			//	dlg = NULL;
			//	return FALSE;
			case IDC_BUTTON_STOP:
				PostThreadMessage(cpyThrdId,MYWM_STOP,0,0);
				return (INT_PTR)TRUE;
			case IDCANCEL:
				//PostThreadMessage(cpyThrdId,MYWM_CANCEL,0,0);
				DestroyWindow(hDlg);
				dlg = NULL;
				return (INT_PTR)TRUE;
		}
		break;
	}
	return (INT_PTR)FALSE;
}

BOOL ShowCopyDlg()
{
	if(dlg) return FALSE;
	dlg = CreateDialog(hInst,MAKEINTRESOURCE(IDD_DIALOG_COPY_BACKGROUND_QUEUE),
                       NULL,(DLGPROC)BckgrndMoveDlgProc);
	if(!dlg)Err::fatalExit(L"CreateDialog failed!!!",dlg);
    ShowWindow(dlg,SW_SHOW);
	return TRUE;
}

DWORD CALLBACK bckgrndMovePrgrssRout(
							LARGE_INTEGER	TotalFileSize,
							LARGE_INTEGER	TotalBytesTransferred,
							LARGE_INTEGER	StreamSize,
							LARGE_INTEGER	StreamBytesTransferred,
							DWORD			dwStreamNumber,
							DWORD			dwCallbackReason,
							HANDLE			hSourceFile,
							HANDLE			hDestinationFile,
							LPVOID			lpData)
{
	cpyTrdDat *pdat = (cpyTrdDat*)lpData;
#define dlg pdat->hDlg
	__int64 tfs = ((__int64)TotalFileSize.HighPart << 32) | TotalFileSize.LowPart;
	__int64 tbt = ((__int64)TotalBytesTransferred.HighPart << 32) | TotalBytesTransferred.LowPart;
	double prgrsPos = tfs?(1000.0*tbt/tfs):1000.0;
	copyedSizes += tbt;
	PostMessage(GetDlgItem(dlg,IDC_PROGRESS_COPY_SINGLE),PBM_SETPOS,(int)prgrsPos,0);
	double prgrsPosTot = tfs?(1000.0*tbt/totSizes):1000.0;
	PostMessage(GetDlgItem(dlg,IDC_PROGRESS_COPY_TOTAL ),PBM_SETPOS,(int)prgrsPosTot,0);

	// ***************** % calculating: ***********************
	wchar_t s[MAX_PATH];StringCchPrintf(s,MAX_PATH,L"%.2f %s",0.1f*prgrsPos,L"%");
	SetDlgItemText(dlg,IDC_STATIC1,s);
	StringCchPrintf(s,MAX_PATH,L"%.2f %s",100.0-0.1*prgrsPos,L"%");
	SetDlgItemText(dlg,IDC_STATIC3,s);
	StringCchPrintf(s,MAX_PATH,L"%.2f %s",tfs?(100.0*tbt/totSizes):100.0,L"%");
	SetDlgItemText(dlg,IDC_STATIC6,s);
	StringCchPrintf(s,MAX_PATH,L"%.2f %s",tfs?(100.0-100.0*tbt/totSizes):100.0,L"%");
	SetDlgItemText(dlg,IDC_STATIC8,s);

	// ***************** tick calculating: ********************
	DWORD tick = GetTickCount() - pdat->beginTick - pdat->stopTick[0];
	MyTimeToString(s, tick);
	SetDlgItemText(pdat->hDlg,IDC_STATIC2,s);
	if(prgrsPos>0.0f)
	{	MyTimeToString(s, (int)(tick*(1000.0f-prgrsPos)/prgrsPos));
		SetDlgItemText(pdat->hDlg,IDC_STATIC4,s);
	}
	
	tick = GetTickCount() - pdat->beginTickTot - pdat->stopTickTot[0];
	MyTimeToString(s, tick);
	SetDlgItemText(pdat->hDlg,IDC_STATIC7,s);
	if(prgrsPosTot>0.0f)
	{	MyTimeToString(s, (int)(tick*(1.0f-0.001f*prgrsPosTot)/(0.001f*prgrsPosTot)));
		SetDlgItemText(pdat->hDlg,IDC_STATIC9,s);
	}



	//message from thread queue:
	MSG msg;
Loop:
	if(PeekMessage(&msg,(HWND)-1,0,0,PM_REMOVE))
	{	
		//static int i=0;
		//char ss[32];sprintf(ss,"\n %d ",i++);
		//OutputDebugString(ss);
		//OutputDebugString(GetWinNotifyText(msg.message));
		
		switch(msg.message)
		{	case MYWM_CANCEL:
				return PROGRESS_CANCEL;
			case MYWM_STOP:
				if(pdat->bStop)
				{	LoadString(hInst,IDS_STRINGSW_50,s,MAX_PATH);
					SetDlgItemText(dlg,IDC_BUTTON_STOP,s);
					pdat->stopTick[0] = GetTickCount() - pdat->stopTick[1];
					pdat->stopTickTot[0] = GetTickCount() - pdat->stopTickTot[1];
					pdat->bStop = FALSE;
				}
				else
				{	LoadString(hInst,IDS_STRINGSW_3,s,MAX_PATH);
					SetDlgItemText(dlg,IDC_BUTTON_STOP,s);
					pdat->stopTick[1] = pdat->stopTickTot[1] = GetTickCount();
					pdat->bStop = TRUE;
					Sleep(250);
					goto Loop;
				}
				break;
 	}	}
	else if(pdat->bStop)
	{	Sleep(250);
		goto Loop;
	}

	return PROGRESS_CONTINUE;
#undef dlg
}

VOID bckgrndMoveFileExThrdFnc(LPVOID lpar)
{
#define dlg dat.hDlg
cpyTrdDat dat; dat.hDlg = (HWND)lpar;
	dat.bStop = FALSE;
	dat.bCancel = FALSE;
	dat.bSwtchToBckgrnd = FALSE;
	dat.thrId = GetCurrentThreadId();
	dat.beginTick = dat.beginTickTot = GetTickCount();
	dat.stopTick[0] = dat.stopTickTot[0] = 0;
	enCheckCopyFilesToExisting = showEach;


HWND ed1 = GetDlgItem(dlg,IDC_EDIT_COPY_BCKGRND_QUEUE);
HWND ed2 = GetDlgItem(dlg,IDC_EDIT_COPY_BCKGRND_QUEUE2);
	Err::AssertFatal(edt1 && edt2,L"Err. gettting bck.cpy dialog edit control!");

 int cnt=0;BOOL bSkipAll=FALSE;
 for(;;)
 {EnterCriticalSection(&critSect);
  int totalItems = (int)SendMessage(ed1,EM_GETLINECOUNT,0,0);
  if(totalItems < SendMessage(ed2,EM_GETLINECOUNT,0,0))
	totalItems = (int)SendMessage(ed2,EM_GETLINECOUNT,0,0);
  LeaveCriticalSection(&critSect);

  wchar_t txt1[255];WORD *pw = (WORD*)txt1; *pw = 255;
  int l1 = (int)SendMessage(ed1,EM_GETLINE,0,(LPARAM)txt1);
  wchar_t txt2[255];pw = (WORD*)txt2; *pw = 255;
  int l2 = (int)SendMessage(ed2,EM_GETLINE,0,(LPARAM)txt2);
  //Selecting first line:**************************************************
  //SendMessage(ed1,EM_SETSEL,0,l1+2);SendMessage(ed2,EM_SETSEL,0,l2+2);

  if(!l1)if(!l2) break;//oxiri;
  txt1[l1] = 0; txt2[l2] = 0;
  if(!l1)
  { 
LoopCreate:
	if(!MyCreateDirectory(txt2,NULL))
    {	LPVOID* par[2]={(LPVOID*)GetLastError(),(LPVOID*)txt2};
		int r = (int)DialogBoxParam(hInst,MAKEINTRESOURCE(IDD_DIALOG_CHOISE_ACTION),dat.hDlg,fDelOper::actnDlgProc,(LPARAM)par);
		if(0==r) goto End;//Cancel action;
		if(1==r) goto LoopCreate;
		if(3==r)
			bSkipAll=TRUE;//2-skip,3-skipAll;
  } }
  else
  {	if(!wcscmp(txt1,txt2))
    {	LoadString(hInst,IDS_STRINGSW_51,txt1,MAX_PATH);
		MessageBox(NULL,txt1,L"Err.",MB_OK);
    }
    else
	{int r=fBckgrndCopyOper::CheckCopyFilesToExisting(dlg,txt1,txt2);
	 if(r==skipAll || r==skip)
     	goto skipOne;
	 else if(r==cancel)
     	goto End;
	 else if(r==overwrite || r==overwriteAll)
     {
LoopMove:
	  if(!MyMoveFileWithProgress(txt1,txt2,bckgrndMovePrgrssRout,&dat,FALSE) &&(!bSkipAll))
	  {	LPVOID* par[3]={(LPVOID*)GetLastError(),(LPVOID*)txt1,(LPVOID*)txt2};
		int r = (int)DialogBoxParam(hInst,MAKEINTRESOURCE(IDD_DIALOG_CHOISE_ACTION),dat.hDlg,fDelOper::actnDlgProc1,(LPARAM)par);
		if(0==r) goto End;//Cancel action;
		if(1==r) goto LoopMove;
		if(3==r)
			bSkipAll=TRUE;//2-skip,3-skipAll;
	 }}
	 else if(r==rename1 || r==renameAll)
     {
LoopRename:
	  if(!MyMoveRenameFileWithProgress(txt1,txt2,bckgrndMovePrgrssRout,&dat,FALSE) &&(!bSkipAll))
	  {	LPVOID* par[3]={(LPVOID*)GetLastError(),(LPVOID*)txt1,(LPVOID*)txt2};
		int r = (int)DialogBoxParam(hInst,MAKEINTRESOURCE(IDD_DIALOG_CHOISE_ACTION),dat.hDlg,fDelOper::actnDlgProc1,(LPARAM)par);
		if(0==r) goto End;//Cancel action;
		if(1==r) goto LoopRename;
		if(3==r)
			bSkipAll=TRUE;//2-skip,3-skipAll;
	 }}
     else if(r==overwriteOldest || r==overwriteOldestAll)
     {
LoopOverOldest:
	  if(!MyMoveOverwriteOldestFileWithProgress(txt1,txt2,bckgrndMovePrgrssRout,&dat,FALSE) &&(!bSkipAll))
	  {	LPVOID* par[3]={(LPVOID*)GetLastError(),(LPVOID*)txt1,(LPVOID*)txt2};
		int r = (int)DialogBoxParam(hInst,MAKEINTRESOURCE(IDD_DIALOG_CHOISE_ACTION),dat.hDlg,fDelOper::actnDlgProc1,(LPARAM)par);
		if(0==r) goto End;//Cancel action;
		if(1==r) goto LoopOverOldest;
		if(3==r)
			bSkipAll=TRUE;//2-skip,3-skipAll;
	 }}
     else if(r==overwriteLatest || r==overwriteLatestAll)
     {
LoopOverLatest:
	  if(!MyMoveOverwriteLatestFileWithProgress(txt1,txt2,bckgrndMovePrgrssRout,&dat,FALSE) &&(!bSkipAll))
	  {	LPVOID* par[3]={(LPVOID*)GetLastError(),(LPVOID*)txt1,(LPVOID*)txt2};
		int r = (int)DialogBoxParam(hInst,MAKEINTRESOURCE(IDD_DIALOG_CHOISE_ACTION),dat.hDlg,fDelOper::actnDlgProc1,(LPARAM)par);
		if(0==r) goto End;//Cancel action;
		if(1==r) goto LoopOverLatest;
		if(3==r)
			bSkipAll=TRUE;//2-skip,3-skipAll;
	 }}
     else if(r==overwriteBigest || r==overwriteBigestAll)
     {
LoopBigest:
	  if(!MyMoveOverwriteBigestFileWithProgress(txt1,txt2,bckgrndMovePrgrssRout,&dat,FALSE) &&(!bSkipAll))
	  {	LPVOID* par[3]={(LPVOID*)GetLastError(),(LPVOID*)txt1,(LPVOID*)txt2};
		int r = (int)DialogBoxParam(hInst,MAKEINTRESOURCE(IDD_DIALOG_CHOISE_ACTION),dat.hDlg,fDelOper::actnDlgProc1,(LPARAM)par);
		if(0==r) goto End;//Cancel action;
		if(1==r) goto LoopBigest;
		if(3==r)
			bSkipAll=TRUE;//2-skip,3-skipAll;
	 }}
     else if(r==overwriteLittlest || r==overwriteLittlestAll)
     {
LoopLittlest:
	  if(!MyMoveOverwriteLittlestFileWithProgress(txt1,txt2,bckgrndMovePrgrssRout,&dat,FALSE) &&(!bSkipAll))
	  {	LPVOID* par[3]={(LPVOID*)GetLastError(),(LPVOID*)txt1,(LPVOID*)txt2};
		int r = (int)DialogBoxParam(hInst,MAKEINTRESOURCE(IDD_DIALOG_CHOISE_ACTION),dat.hDlg,fDelOper::actnDlgProc1,(LPARAM)par);
		if(0==r) goto End;//Cancel action;
		if(1==r) goto LoopLittlest;
		if(3==r)
			bSkipAll=TRUE;//2-skip,3-skipAll;
	}}}
skipOne:
	PostMessage(GetDlgItem(dlg,IDC_PROGRESS_COPY_SINGLE),PBM_SETPOS,1000,0);
	PostMessage(GetDlgItem(dlg,IDC_PROGRESS_COPY_TOTAL ),PBM_SETPOS,
    (int)(1000.0f*(copyedSizes)/totSizes),0);
  }
  
  //Delete line from edits:
  EnterCriticalSection(&critSect);
  SendMessage(ed1,EM_SETSEL,0,l1+2);SendMessage(ed2,EM_SETSEL,0,l2+2);
  SendMessage(ed1,WM_CLEAR,0,0);SendMessage(ed2,WM_CLEAR,0,0);

  //Selecting first line:**************************************************
  //pw = (WORD*)txt1; *pw = 255;											//*
  //l1 = SendMessage(ed1,EM_GETLINE,0,(LPARAM)txt1);						//*
  //pw = (WORD*)txt2; *pw = 255;											//*
  //l2 = SendMessage(ed2,EM_GETLINE,0,(LPARAM)txt2);						//*
  //SendMessage(ed1,EM_SETSEL,0,l1+2);SendMessage(ed2,EM_SETSEL,0,l2+2);	//*

  LeaveCriticalSection(&critSect);

Loop:
	MSG msg;//Only thread message:
	if(PeekMessage(&msg,(HWND)-1,0,0,PM_REMOVE))
	{	
		
		//static int i=0;
		//char ss[32];sprintf(ss,"\n %d ",i++);
		//OutputDebugString(ss);
		//OutputDebugString(GetWinNotifyText(msg.message));
		
		switch(msg.message)
		{	//case MYWM_CANCEL:
				//dat.bCancel = TRUE;
			//	goto End;
			case MYWM_STOP:
				wchar_t s[MAX_PATH];
				if(dat.bStop)
				{	LoadString(hInst,IDS_STRINGSW_50,s,MAX_PATH);
					SetDlgItemText(dlg,IDC_BUTTON_STOP,s);
					dat.bStop = FALSE;
				}
				else
				{	LoadString(hInst,IDS_STRINGSW_3,s,MAX_PATH);
					SetDlgItemText(dlg,IDC_BUTTON_STOP,s);
					dat.bStop = TRUE;
					Sleep(250);
					goto Loop;
				}
				break;
 	}	}
	else if(dat.bStop)
	{	Sleep(250);
		goto Loop;
}	}
End:
 DestroyWindow(dlg);
 //if(dat.stack) free(dat.stack);
 ExitThread(0);
#undef dlg
}

BOOL AddToQueueFrMoveOperation()
{
	BOOL r = ShowCopyDlg();
	if(r)// CreateThread:
	{	totSizes = 0;
		copyedSizes = 0;
		CreateThread(NULL,1024,(LPTHREAD_START_ROUTINE)bckgrndMoveFileExThrdFnc,
					 dlg,0,&cpyThrdId);
	}
	EnterCriticalSection(&critSect);
	totSizes += fCopyOper::GetSelectedFilesToDlg(GetDlgItem(dlg,IDC_EDIT_COPY_BCKGRND_QUEUE),
									GetDlgItem(dlg,IDC_EDIT_COPY_BCKGRND_QUEUE2));
	LeaveCriticalSection(&critSect);
	return TRUE;
}

/*INT_PTR CALLBACK MoveFileExistDlgProc(HWND hDlg,UINT message,WPARAM wParam,LPARAM lParam)
{
WIN32_FIND_DATA *pff;
	switch(message)
	{
	case WM_INITDIALOG:
		//Adjust to center:
		RECT rc; GetWindowRect(hDlg, &rc);
		int width,left,height,top;

		width = rc.right - rc.left;
		left = conf::wndLeft + (conf::wndWidth - width)/2;

		height = rc.bottom - rc.top;
		top = conf::wndTop + (conf::wndHeight - height)/2;
		MoveWindow(hDlg, left, top+20, width, height, TRUE);

		char s[MAX_PATH];
		LoadString(hInst,IDS_STRINGSW_52,s,MAX_PATH);
		SetWindowText(hDlg,s);
		LoadString(hInst,IDS_STRINGSW_53,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_STATIC1,s);
		LoadString(hInst,IDS_STRINGSW_54,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_STATIC2,s);
		LoadString(hInst,IDS_STRINGSW_53,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_STATIC3,s);
		LoadString(hInst,IDS_STRINGSW_54,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_STATIC4,s);
		LoadString(hInst,IDS_STRINGSW_55,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_STATIC2,s);
		LoadString(hInst,IDS_STRINGSW_56,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_STATIC6,s);
		LoadString(hInst,IDS_STRINGSW_57,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_STATIC7,s);
		LoadString(hInst,IDS_STRINGSW_58,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_STATIC8,s);
		LoadString(hInst,IDS_STRINGSW_59,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_STATIC9,s);
		LoadString(hInst,IDS_STRINGSW_60,s,MAX_PATH);
		SetDlgItemText(hDlg,IDOK,s);
		LoadString(hInst,IDS_STRINGSW_13,s,MAX_PATH);
		SetDlgItemText(hDlg,IDCANCEL,s);

		pff = (WIN32_FIND_DATA*)(lParam);
		SetDlgItemText(hDlg,IDC_EDIT_SRC_PATH,pff[0].cFileName);
		SetDlgItemText(hDlg,IDC_EDIT_DEST_PATH,pff[1].cFileName);
		
		unsigned __int64 sz;sz = ((unsigned __int64)pff[0].nFileSizeHigh << 32) | pff[0].nFileSizeLow;
		StringCchPrintf(s,MAX_PATH,"%d",sz);
		SetDlgItemText(hDlg,IDC_EDIT_SRC_SIZE,s);
		sz = ((unsigned __int64)pff[1].nFileSizeHigh << 32) | pff[1].nFileSizeLow;
		StringCchPrintf(s,MAX_PATH,"%d",sz);
		SetDlgItemText(hDlg,IDC_EDIT_DEST_SIZE,s);
		
		FILETIME ft;SYSTEMTIME st;
		if(FileTimeToLocalFileTime(&pff[0].ftCreationTime,&ft) != 0)
        {	if(FileTimeToSystemTime(&ft, &st) != 0)
			{	StringCchPrintf(s,MAX_PATH,"%d.%d.%d  %d:%d:%d",
								st.wDay,st.wMonth,st.wYear,
								st.wHour,st.wMinute,st.wSecond);
				SetDlgItemText(hDlg,IDC_EDIT_SRC_CREATE_TIME,s);
		}	}
		if(FileTimeToLocalFileTime(&pff[1].ftCreationTime,&ft) != 0)
        {	if(FileTimeToSystemTime(&ft, &st) != 0)
			{	StringCchPrintf(s,MAX_PATH,"%d.%d.%d  %d:%d:%d",
								st.wDay,st.wMonth,st.wYear,
								st.wHour,st.wMinute,st.wSecond);
				SetDlgItemText(hDlg,IDC_EDIT_DEST_CREATE_TIME,s);
		}	}

		if(FileTimeToLocalFileTime(&pff[0].ftLastWriteTime,&ft) != 0)
        {	if(FileTimeToSystemTime(&ft, &st) != 0)
			{	StringCchPrintf(s,MAX_PATH,"%d.%d.%d  %d:%d:%d",
								st.wDay,st.wMonth,st.wYear,
								st.wHour,st.wMinute,st.wSecond);
				SetDlgItemText(hDlg,IDC_EDIT_SRC_LAST_WRITE_TIME,s);
		}	}
		if(FileTimeToLocalFileTime(&pff[1].ftLastWriteTime,&ft) != 0)
        {	if(FileTimeToSystemTime(&ft, &st) != 0)
			{	StringCchPrintf(s,MAX_PATH,"%d.%d.%d  %d:%d:%d",
								st.wDay,st.wMonth,st.wYear,
								st.wHour,st.wMinute,st.wSecond);
				SetDlgItemText(hDlg,IDC_EDIT_DEST_LAST_WRITE_TIME,s);
		}	}

		if(FileTimeToLocalFileTime(&pff[0].ftLastAccessTime,&ft) != 0)
        {	if(FileTimeToSystemTime(&ft, &st) != 0)
			{	StringCchPrintf(s,MAX_PATH,"%d.%d.%d  %d:%d:%d",
								st.wDay,st.wMonth,st.wYear,
								st.wHour,st.wMinute,st.wSecond);
				SetDlgItemText(hDlg,IDC_EDIT_SRC_LAST_ACCESS_TIME,s);
		}	}
		if(FileTimeToLocalFileTime(&pff[1].ftLastAccessTime,&ft) != 0)
        {	if(FileTimeToSystemTime(&ft, &st) != 0)
		{	StringCchPrintf(s,MAX_PATH,"%d.%d.%d  %d:%d:%d",
								st.wDay,st.wMonth,st.wYear,
								st.wHour,st.wMinute,st.wSecond);
				SetDlgItemText(hDlg,IDC_EDIT_DEST_LAST_ACCESS_TIME,s);
		}	}

		if(FILE_ATTRIBUTE_ARCHIVE==pff[0].dwFileAttributes)
			SetDlgItemText(hDlg,IDC_EDIT_SRC_ATTRIBUTE,"Archive");
		else if(FILE_ATTRIBUTE_COMPRESSED==pff[0].dwFileAttributes)
			SetDlgItemText(hDlg,IDC_EDIT_SRC_ATTRIBUTE,"Compressed");
		else if(FILE_ATTRIBUTE_DEVICE==pff[0].dwFileAttributes)
			SetDlgItemText(hDlg,FILE_ATTRIBUTE_DEVICE,"Device");
		else if(FILE_ATTRIBUTE_DIRECTORY==pff[0].dwFileAttributes)
			SetDlgItemText(hDlg,IDC_EDIT_SRC_ATTRIBUTE,"Directory");
		else if(FILE_ATTRIBUTE_ENCRYPTED==pff[0].dwFileAttributes)
			SetDlgItemText(hDlg,IDC_EDIT_SRC_ATTRIBUTE,"Encrypted");
		else if(FILE_ATTRIBUTE_HIDDEN==pff[0].dwFileAttributes)
			SetDlgItemText(hDlg,IDC_EDIT_SRC_ATTRIBUTE,"Hidden");
		else if(FILE_ATTRIBUTE_NORMAL==pff[0].dwFileAttributes)
			SetDlgItemText(hDlg,IDC_EDIT_SRC_ATTRIBUTE,"Normal");
		else if(FILE_ATTRIBUTE_NOT_CONTENT_INDEXED==pff[0].dwFileAttributes)
			SetDlgItemText(hDlg,IDC_EDIT_SRC_ATTRIBUTE,"Not content indexed");
		else if(FILE_ATTRIBUTE_OFFLINE==pff[0].dwFileAttributes)
			SetDlgItemText(hDlg,IDC_EDIT_SRC_ATTRIBUTE,"Offline");		
		else if(FILE_ATTRIBUTE_READONLY==pff[0].dwFileAttributes)
			SetDlgItemText(hDlg,IDC_EDIT_SRC_ATTRIBUTE,"Readonly");
		else if(FILE_ATTRIBUTE_REPARSE_POINT==pff[0].dwFileAttributes)
			SetDlgItemText(hDlg,IDC_EDIT_SRC_ATTRIBUTE,"Reparsepoint");
		else if(FILE_ATTRIBUTE_SPARSE_FILE==pff[0].dwFileAttributes)
			SetDlgItemText(hDlg,IDC_EDIT_SRC_ATTRIBUTE,"Sparsefile");
		else if(FILE_ATTRIBUTE_SYSTEM==pff[0].dwFileAttributes)
			SetDlgItemText(hDlg,IDC_EDIT_SRC_ATTRIBUTE,"System");
		else if(FILE_ATTRIBUTE_TEMPORARY==pff[0].dwFileAttributes)
			SetDlgItemText(hDlg,IDC_EDIT_SRC_ATTRIBUTE,"Temporary");
		else if(FILE_ATTRIBUTE_VIRTUAL==pff[0].dwFileAttributes)
			SetDlgItemText(hDlg,IDC_EDIT_SRC_ATTRIBUTE,"Virtual");

		if(FILE_ATTRIBUTE_ARCHIVE==pff[1].dwFileAttributes)
			SetDlgItemText(hDlg,IDC_EDIT_SRC_ATTRIBUTE,"Archive");
		else if(FILE_ATTRIBUTE_COMPRESSED==pff[1].dwFileAttributes)
			SetDlgItemText(hDlg,IDC_EDIT_SRC_ATTRIBUTE,"Compressed");
		else if(FILE_ATTRIBUTE_DEVICE==pff[1].dwFileAttributes)
			SetDlgItemText(hDlg,FILE_ATTRIBUTE_DEVICE,"Device");
		else if(FILE_ATTRIBUTE_DIRECTORY==pff[1].dwFileAttributes)
			SetDlgItemText(hDlg,IDC_EDIT_SRC_ATTRIBUTE,"Directory");
		else if(FILE_ATTRIBUTE_ENCRYPTED==pff[1].dwFileAttributes)
			SetDlgItemText(hDlg,IDC_EDIT_SRC_ATTRIBUTE,"Encrypted");
		else if(FILE_ATTRIBUTE_HIDDEN==pff[1].dwFileAttributes)
			SetDlgItemText(hDlg,IDC_EDIT_SRC_ATTRIBUTE,"Hidden");
		else if(FILE_ATTRIBUTE_NORMAL==pff[1].dwFileAttributes)
			SetDlgItemText(hDlg,IDC_EDIT_SRC_ATTRIBUTE,"Normal");
		else if(FILE_ATTRIBUTE_NOT_CONTENT_INDEXED==pff[1].dwFileAttributes)
			SetDlgItemText(hDlg,IDC_EDIT_SRC_ATTRIBUTE,"Not content indexed");
		else if(FILE_ATTRIBUTE_OFFLINE==pff[1].dwFileAttributes)
			SetDlgItemText(hDlg,IDC_EDIT_SRC_ATTRIBUTE,"Offline");		
		else if(FILE_ATTRIBUTE_READONLY==pff[1].dwFileAttributes)
			SetDlgItemText(hDlg,IDC_EDIT_SRC_ATTRIBUTE,"Readonly");
		else if(FILE_ATTRIBUTE_REPARSE_POINT==pff[1].dwFileAttributes)
			SetDlgItemText(hDlg,IDC_EDIT_SRC_ATTRIBUTE,"Reparsepoint");
		else if(FILE_ATTRIBUTE_SPARSE_FILE==pff[1].dwFileAttributes)
			SetDlgItemText(hDlg,IDC_EDIT_SRC_ATTRIBUTE,"Sparsefile");
		else if(FILE_ATTRIBUTE_SYSTEM==pff[1].dwFileAttributes)
			SetDlgItemText(hDlg,IDC_EDIT_SRC_ATTRIBUTE,"System");
		else if(FILE_ATTRIBUTE_TEMPORARY==pff[1].dwFileAttributes)
			SetDlgItemText(hDlg,IDC_EDIT_SRC_ATTRIBUTE,"Temporary");
		else if(FILE_ATTRIBUTE_VIRTUAL==pff[1].dwFileAttributes)
			SetDlgItemText(hDlg,IDC_EDIT_SRC_ATTRIBUTE,"Virtual");

		return TRUE;
	//case WM_DESTROY:
	//	return TRUE;
	case WM_COMMAND:
		switch(LOWORD(wParam))
		{	case IDOK:
				EndDialog(hDlg,FALSE);
				return (INT_PTR)TRUE;
			case IDCANCEL:
				EndDialog(hDlg,TRUE);
				return (INT_PTR)TRUE;
			case IDCANCEL:
				EndDialog(hDlg,TRUE);
				return (INT_PTR)TRUE;
		}
		break;
	}
	return (INT_PTR)FALSE;
}*/

}//end of namespace