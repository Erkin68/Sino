#include "MenuUtils.h"
#include "..\config.h"
#include "..\sino.h"
#include "MyErrors.h"
#include "Execution.h"
#include "strsafe.h"
#include "SelectViaPlus.h"
#include "MyShell\MyShell.h"
#include "..\WindowsManagmentInstrumentation.h"
#include <malloc.h>
#include <Psapi.h>



namespace menuUtils
{

int numPlugins;
CMnuUtPlgn *plgns=NULL;

BOOL Run$4(HWND prnt,int iplg)
{	BOOL r=FALSE;
	if(iplg<0) return FALSE;
	if(iplg>numPlugins-1) return FALSE;
BEGIN_TRY
	if(plgns[iplg].LoadPlugin())
	{	r=plgns[iplg].Run$4(prnt);
		//if(!r)
			plgns[iplg].FreePlugin();
	}
END_TRY
{
	r=FALSE;
}
	return r;
}

BOOL RunFromName(HWND wnd,wchar_t *name)
{
wchar_t *pname=wcsrchr(name,'\\');if(pname)++pname;else pname=name;
int ln=MyStringLength(pname,MAX_PATH);
	for(int i=0; i<numPlugins; i++)
	{wchar_t *p=wcsrchr(plgns[i].pathAndName,'\\');if(p)++p;else p=&plgns[i].pathAndName[0];
	 int l=MyStringLength(p,MAX_PATH);
	 if(l!=ln)continue;
	 if(0==_wcsnicmp(pname,p,l))
	 {	Run$4(wnd,i);
		return TRUE;
	}}
	return FALSE;
}

VOID TryLoadPlugin(wchar_t *pth,wchar_t* name)
{//LoadLibrary da exception beradur;
	if(numPlugins>20)
	{	Err::msg(hWnd,0,(LPTSTR)"There are any archiver plugins(above 20), ignore others...");
		return;
	}

	MyStringCat(pth,MAX_PATH-1,name);
	if(!Execution::IsThisValidDllFile(pth))
		return;

BEGIN_TRY

HMODULE hm = LoadLibraryEx(pth,NULL,DONT_RESOLVE_DLL_REFERENCES);
	if(!hm)
	{	Err::msg(hWnd,-1,pth);
		return;
	}

	menuUtils::GetPluginType_t GetPluginType = (GetPluginType_t)GetProcAddress(hm,"GetPluginType");
	if(!GetPluginType) goto Fail;
	menuUtils::SetCallbacks$4xxx_t SetCallbacks$4xxx = (SetCallbacks$4xxx_t)GetProcAddress(hm,"SetCallbacks$4xxx");
	if(!SetCallbacks$4xxx) goto Fail;
	menuUtils::SetId$4_t SetId$4 = (SetId$4_t)GetProcAddress(hm,"SetId$4");
	if(!SetId$4) goto Fail;
	menuUtils::GetPluginDescription_t GetPluginDescription = (GetPluginDescription_t)GetProcAddress(hm,"GetPluginDescription");
	if(!GetPluginDescription) goto Fail;
	menuUtils::ShowOptionDialog_t ShowOptionDialog = (ShowOptionDialog_t)GetProcAddress(hm,"ShowOptionDialog");
	if(!ShowOptionDialog) goto Fail;
	menuUtils::Run$4_t Run$4 = (Run$4_t)GetProcAddress(hm,"Run$4");
	if(!Run$4) goto Fail;
	menuUtils::GetPluginName_t GetPluginName = (GetPluginName_t)GetProcAddress(hm,"GetPluginName");
	if(!GetPluginName) goto Fail;
	menuUtils::GetMenuNum_t GetMenuNum = (GetMenuNum_t)GetProcAddress(hm,"GetMenuNum");
	if(!GetMenuNum) goto Fail;
	menuUtils::GetMenuPos_t GetMenuPos = (GetMenuPos_t)GetProcAddress(hm,"GetMenuPos");
	if(!GetMenuPos) goto Fail;
	menuUtils::GetMenuItemText_t GetMenuItemText = (GetMenuItemText_t)GetProcAddress(hm,"GetMenuItemText");
	if(!GetMenuItemText) goto Fail;
	menuUtils::GetMenuText_t GetMenuText = (GetMenuText_t)GetProcAddress(hm,"GetMenuText");
	if(!GetMenuText) goto Fail;

	FreeLibrary(hm);
	hm = LoadLibrary(pth);//DllMain ni yuklasin, endi;
	GetPluginType = (GetPluginType_t)GetProcAddress(hm,"GetPluginType");
	SetCallbacks$4xxx = (SetCallbacks$4xxx_t)GetProcAddress(hm,"SetCallbacks$4xxx");
	SetId$4 = (SetId$4_t)GetProcAddress(hm,"SetId$4");
	GetPluginDescription = (GetPluginDescription_t)GetProcAddress(hm,"GetPluginDescription");
	ShowOptionDialog = (ShowOptionDialog_t)GetProcAddress(hm,"ShowOptionDialog");
	Run$4 = (Run$4_t)GetProcAddress(hm,"Run$4");
	GetPluginName = (GetPluginName_t)GetProcAddress(hm,"GetPluginName");
	GetMenuNum = (GetMenuNum_t)GetProcAddress(hm,"GetMenuNum");
	GetMenuPos = (GetMenuPos_t)GetProcAddress(hm,"GetMenuPos");
	GetMenuItemText = (GetMenuItemText_t)GetProcAddress(hm,"GetMenuItemText");
	GetMenuText = (GetMenuText_t)GetProcAddress(hm,"GetMenuText");

	int t=GetPluginType();
	if(102!=t)//utility menu
	{		
Fail:	FreeLibrary(hm);
		return;
	}
	MODULEINFO mi;
	GetModuleInformation(GetCurrentProcess(),hm,&mi,sizeof(mi));

	if(!plgns) plgns = (CMnuUtPlgn*)malloc((numPlugins+1)*sizeof(CMnuUtPlgn));
	else  plgns = (CMnuUtPlgn*)realloc(plgns,(numPlugins+1)*sizeof(CMnuUtPlgn));
	plgns[numPlugins].CMnuUtPlgn::CMnuUtPlgn();
	plgns[numPlugins].GetPluginType = GetPluginType;
	plgns[numPlugins].SetCallbacks$4xxx = SetCallbacks$4xxx;
	plgns[numPlugins].SetId$4 = SetId$4;
	plgns[numPlugins].GetPluginDescription = GetPluginDescription;
	plgns[numPlugins].ShowOptionDialog = ShowOptionDialog;
	plgns[numPlugins].Run$4 = Run$4;
	plgns[numPlugins].GetPluginName = GetPluginName;
	plgns[numPlugins].GetMenuNum = GetMenuNum;
	plgns[numPlugins].GetMenuPos = GetMenuPos;
	plgns[numPlugins].GetMenuItemText = GetMenuItemText;
	plgns[numPlugins].GetMenuText = GetMenuText;
	SetCallbacks$4xxx(	CMnuUtPlgn::saveOptions,
						CMnuUtPlgn::readOptions,
						CMnuUtPlgn::getTotPanels,
						CMnuUtPlgn::getCrntPanelNum,
						CMnuUtPlgn::getPanelCrntItem,
						CMnuUtPlgn::getPanelSelectedItems,
						CMnuUtPlgn::getPanelPath,
						CMnuUtPlgn::GetLogicalDriveSpace
						);
	plgns[numPlugins].hm = hm;
	MyStringCpy(plgns[numPlugins].pathAndName,MAX_PATH-1,pth);
	plgns[numPlugins].SetId$4(numPlugins);
	plgns[numPlugins].idNum = numPlugins;
	plgns[numPlugins].mnuIdNum = -1;	
	plgns[numPlugins].mnuPos = GetMenuPos();
	MyStringCpy(plgns[numPlugins].descrpn,MAX_PATH,(wchar_t*)GetPluginDescription());
	MyStringCpy(plgns[numPlugins].mnuTxt,31,(wchar_t*)GetMenuItemText());
	//plgns[numPlugins].dllSize = mi.SizeOfImage;
	//plgns[numPlugins].FreePlugin(); menuni taxlab olgandan so'ng free qilamiz;
	++numPlugins;

END_TRY
{
	Err::msg1(NULL,0,pth,L"Err.loading menu utility plgn.");
}}

VOID ListAuxDirLoadPlugins(wchar_t *path)
{
wchar_t s[MAX_PATH];
WIN32_FIND_DATAW ff;
HANDLE hf = INVALID_HANDLE_VALUE;

	hf = MyFindFirstFileEx(path,FindExInfoStandard,&ff,FindExSearchLimitToDirectories,NULL,0);
	do
	{	if(INVALID_HANDLE_VALUE==hf) return;
		if(FILE_ATTRIBUTE_DIRECTORY & ff.dwFileAttributes)//if(IsDirectory(path, &ff, FALSE))
		{	if(IsCrntOrPrntDirAttrb(ff.cFileName))
			{	wchar_t s[MAX_PATH]; MyStringCpy(s,MAX_PATH-1,path);
				MyStringRemoveLastCharCheckPre(s,MAX_PATH-1,'*','\\');
				MyStringCat(s,MAX_PATH-1,ff.cFileName);
				MyStringCat(s,MAX_PATH-1,L"\\*");
				ListAuxDirLoadPlugins(s);
		}	}
		else
		{	MyStringCpy(s,MAX_PATH-1,path);
			MyStringRemoveLastCharCheckPre(s,MAX_PATH-1,'*','\\');
			//MyStringCat(s,MAX_PATH-1,ff.cFileName);
			TryLoadPlugin(s,ff.cFileName);
	}	}
	while(FindNextFile(hf, &ff));
	FindClose(hf);
}

VOID FreePlugins()//CArch::~CArch ga qara, ochiq qolib ketgan arxivlar qoladur;
{
	//free(plgns);
	//plgns=NULL;
	//numPlugins=0;
}

VOID LoadPlugins(HWND wnd)
{
	numPlugins=0;
	wchar_t *auxPlgPth = MyStringAddModulePath(L"Plugins\\Auxilary\\*");
	ListAuxDirLoadPlugins(auxPlgPth);
	SetMenusInStartup(wnd);
}

BOOL SetMenusInStartup(HWND hWnd)
{
	//Setup menu items:
	HMENU hm = GetMenu(hWnd);
	if(!hm) return FALSE;
	int cItems = GetMenuItemCount(hm);
	//if(cItems<1 || cItems>100) return FALSE;
	int iApndMnu=0;
	MENUITEMINFO mi;mi.cbSize=sizeof(mi);mi.fMask=MIIM_STRING|MIIM_ID; mi.fType=MFT_STRING;
	//MENUITEMINFO mk;mk.cbSize=sizeof(mi);mk.fMask=MIIM_ID; mk.fType=MFT_STRING;
	for(int p=0; p<numPlugins; p++)
	{	wchar_t st[MAX_PATH];
		int menuNum = plgns[p].GetMenuNum();
		if(menuNum > cItems-1)
		{	StringCchPrintf(st,MAX_PATH-1,L"%s...plugin",plgns[p].GetMenuText());
			AppendMenu(hm,MF_STRING,0xffff-(iApndMnu++),st);
			++cItems;
		}
		HMENU sbMnu = GetSubMenu(hm,menuNum);
		StringCchPrintf(st,MAX_PATH-1,L"%s...plugin",plgns[p].GetMenuText());
		mi.dwTypeData = st;
		mi.wID = 0xffff-(iApndMnu++);
		InsertMenuItem(sbMnu,plgns[p].GetMenuPos(),TRUE,&mi);//AppendMenu(sbMnu,MF_STRING,0xffffffff-iApndMnu,plgns[p].GetMenuItemText());
		//GetMenuItemInfo(sbMnu,plgns[p].GetMenuPos(),TRUE,&mk);
		plgns[p].mnuIdNum = mi.wID;//mk.wID;
		plgns[p].FreePlugin();//Free qilib qo'yamiz:
	}
	return TRUE;
}//GetMenuString(hm,0,szTemp,sizeof(szTemp)/sizeof(TCHAR), MF_BYPOSITION);

BOOL IsKeyExist(int k)
{
BOOL r=FALSE;
	for(int i=0; i<numPlugins; i++)
	{	if(i==k)continue;
		if(plgns[i].key.key==plgns[k].key.key)
		if(plgns[i].key.bCtrl==plgns[k].key.bCtrl)
		if(plgns[i].key.bAlt==plgns[k].key.bAlt)
		if(plgns[i].key.bShft==plgns[k].key.bShft)
			return TRUE;
	}
	return FALSE;
}

BOOL CheckKeys(HWND wnd,conf::STKey *key)
{
	for(int i=0; i<numPlugins; i++)
	{	if(plgns[i].key.key==key->key)
		if(plgns[i].key.bCtrl==key->bCtrl)
		if(plgns[i].key.bAlt==key->bAlt)
		if(plgns[i].key.bShft==key->bShft)
		{	Run$4(wnd,i);
			return TRUE;
	}	}
	return FALSE;
}

BOOL CheckFromMenuId(HWND wnd,WPARAM wParam)
{	
	wchar_t s[128];//MENUITEMINFO mi;mi.cbSize=sizeof(mi);mi.fMask=MIIM_STRING;
			   //   		  mi.fType=MFT_STRING;mi.dwTypeData=s;
HMENU hm = GetMenu(wnd);
	wParam &= 0xffff;//only loword
	for(int i=0; i<numPlugins; i++)
	{	if(plgns[i].mnuIdNum==wParam)
		{	//HMENU sm=GetSubMenu(hm,plgns[i].mnuPos);
			GetMenuString(hm,(UINT)wParam,s,127,MF_BYCOMMAND);//GetMenuItemInfo(sm,wParam,FALSE,&mi);
			wchar_t *p=wcsstr(s,L"...plugin");
			if(p)(*p)=0;
			if(0==wcscmp(s,plgns[i].mnuTxt))
			{	Run$4(wnd,i);
				return TRUE;
	}	}	}
	return FALSE;
}

}//end of namespace

//Class CMnuUtPlgn ****
//Class CMnuUtPlgn ****
//Class CMnuUtPlgn ****
//Class CMnuUtPlgn ****
//Class CMnuUtPlgn ****
//Class CMnuUtPlgn ****
//Class CMnuUtPlgn ****
CMnuUtPlgn::CMnuUtPlgn():idNum(0),hm(NULL)
{
}

CMnuUtPlgn::~CMnuUtPlgn()
{
}

BOOL CMnuUtPlgn::LoadPlugin()
{
	if(hm) return FALSE;//Faqat menu utilityda shunday bo'la qolsin.Faqat 1ta instance igina ishlasin.
	hm = LoadLibrary(pathAndName);
	if(!hm) return FALSE;

	GetPluginType = (menuUtils::GetPluginType_t)GetProcAddress(hm,"GetPluginType");
	SetCallbacks$4xxx = (menuUtils::SetCallbacks$4xxx_t)GetProcAddress(hm,"SetCallbacks$4xxx");
	SetId$4 = (menuUtils::SetId$4_t)GetProcAddress(hm,"SetId$4");
	GetPluginDescription = (menuUtils::GetPluginDescription_t)GetProcAddress(hm,"GetPluginDescription");
	ShowOptionDialog = (menuUtils::ShowOptionDialog_t)GetProcAddress(hm,"ShowOptionDialog");
	Run$4 = (menuUtils::Run$4_t)GetProcAddress(hm,"Run$4");
	GetPluginName = (menuUtils::GetPluginName_t)GetProcAddress(hm,"GetPluginName");
	GetMenuNum = (menuUtils::GetMenuNum_t)GetProcAddress(hm,"GetMenuNum");
	GetMenuPos = (menuUtils::GetMenuPos_t)GetProcAddress(hm,"GetMenuPos");
	GetMenuItemText = (menuUtils::GetMenuItemText_t)GetProcAddress(hm,"GetMenuItemText");
	GetMenuText = (menuUtils::GetMenuText_t)GetProcAddress(hm,"GetMenuText");
	SetCallbacks$4xxx(	CMnuUtPlgn::saveOptions,
						CMnuUtPlgn::readOptions,
						CMnuUtPlgn::getTotPanels,
						CMnuUtPlgn::getCrntPanelNum,
						CMnuUtPlgn::getPanelCrntItem,
						CMnuUtPlgn::getPanelSelectedItems,
						CMnuUtPlgn::getPanelPath,
						CMnuUtPlgn::GetLogicalDriveSpace//,
						//CMnuUtPlgn::MayFreePluginDll
						);
	SetId$4(idNum);
	return TRUE;
}

VOID CMnuUtPlgn::FreePlugin()
{
	if(hm)
		FreeLibrary(hm);
	hm = 0;
	GetPluginType = 0;
	SetCallbacks$4xxx = 0;
	SetId$4 = 0;
	GetPluginDescription = 0;
	ShowOptionDialog = 0;
	Run$4 = 0;
	GetPluginName = 0;
	GetMenuNum = 0;
	GetMenuPos = 0;
	GetMenuItemText = 0;
	GetMenuText = 0;
}

wchar_t* CALLBACK CMnuUtPlgn::getPanelPath(int iPnl)
{
	if(iPnl<0) return NULL;
	if(iPnl>conf::Dlg.iTotPanels) return NULL;
	return panel[iPnl].GetPath();
}

BOOL CALLBACK CMnuUtPlgn::readOptions(int plgId,VOID *buf,int bufLen)
{
	if(plgId<0) return FALSE;//|| plgId>fSearchViaF7::numPlugins-1) return FALSE; ni qo'ymaymiz, hali numPlugins 1ta oshmagan bo'lishi mumkin;
DWORD rb;
wchar_t s[MAX_PATH];MyStringCpy(s,MAX_PATH-1,menuUtils::plgns[plgId].pathAndName);
	wchar_t *p = wcsrchr(s,'.');
	if(p) *(p+1) = 0;
	MyStringCat(s,MAX_PATH-1,L"bin");
	HANDLE f = MyFopenViaCrF(s,L"r");
	if(!f) return FALSE;
	if(!ReadFile(f,buf,bufLen,&rb,NULL))
		rb=0;
	if(!ReadFile(f,&menuUtils::plgns[plgId].key,sizeof(menuUtils::plgns[plgId].key),&rb,NULL))
		rb=0;
	CloseHandle(f);
	return (rb!=bufLen)?FALSE:TRUE;
}

BOOL CALLBACK CMnuUtPlgn::saveOptions(int plgId,VOID *buf,int bufLen)
{
	if(plgId<0 || plgId>menuUtils::numPlugins-1) return FALSE;
DWORD rb;
wchar_t s[MAX_PATH];MyStringCpy(s,MAX_PATH-1,menuUtils::plgns[plgId].pathAndName);
	wchar_t *p = wcsrchr(s,'.');
	if(p) *(p+1) = 0;
	MyStringCat(s,MAX_PATH-1,L"bin");
	HANDLE f = MyFopenViaCrF(s,L"w");
	if(!f) return FALSE;
	if(!WriteFile(f,buf,bufLen,&rb,NULL))
		rb=0;
	if(!WriteFile(f,&menuUtils::plgns[plgId].key,sizeof(menuUtils::plgns[plgId].key),&rb,NULL))
		rb=0;
	CloseHandle(f);
	return (rb!=bufLen)?FALSE:TRUE;
}

unsigned __int64* CALLBACK CMnuUtPlgn::GetLogicalDriveSpace(int ld)
{
	return myWMI::GetLogicalDriveSpace(ld);
}

int CALLBACK CMnuUtPlgn::getTotPanels()
{
	return conf::Dlg.iTotPanels;
}

//VOID CALLBACK CMnuUtPlgn::MayFreePluginDll(int plgId)
//{
//	menuUtils::plgns[plgId].FreePlugin();
//}

int CALLBACK CMnuUtPlgn::getCrntPanelNum()
{
	return Panel::iActivePanel;
}

BOOL CALLBACK CMnuUtPlgn::getPanelCrntItem(int iPanel,WIN32_FIND_DATAW *ff)
{
	if(socketCl==panel[iPanel].GetEntry()->GetCrntRecType()) return FALSE;
	if(archElem==panel[iPanel].GetEntry()->GetCrntRecType()) return FALSE;
//static WIN32_FIND_DATA ff;
int id=-1;	
	if(panel[iPanel].GetTotSelects()==0) id=panel[iPanel].GetHot();
	else id = panel[iPanel].GetSelectedItemNum(0);
	if(id<1 || id>panel[iPanel].GetTotItems()-1) return FALSE;

	panel[iPanel].GetFullPathAndName(id,ff->cFileName,MAX_PATH-1);
	ff->dwFileAttributes = (panel[iPanel].GetItem(id)->attribute==folder)? FILE_ATTRIBUTE_DIRECTORY :
																		  FILE_ATTRIBUTE_NORMAL    ;
	ff->nFileSizeHigh = (panel[iPanel].GetItem(id)->size & 0xffffffff00000000) >> 32;
	ff->nFileSizeLow  =  panel[iPanel].GetItem(id)->size & 0xffffffff;
	ff->ftLastWriteTime = panel[iPanel].GetItem(id)->ftWrite;
	ff->ftCreationTime = panel[iPanel].GetItem(id)->ftWrite;
	return TRUE;
}

LPVOID CALLBACK CMnuUtPlgn::getPanelSelectedItems(int iPanel,int *outTot)
{
static WIN32_FIND_DATAW *ff=0;

	if(socketCl==panel[iPanel].GetEntry()->GetCrntRecType()) return FALSE;
	if(archElem==panel[iPanel].GetEntry()->GetCrntRecType()) return FALSE;

int tot=panel[iPanel].GetTotSelects();
	if(!tot)
	{	tot = panel[iPanel].GetHot();
		if(tot<0 || tot>panel[iPanel].GetTotItems()-1)
			return NULL;
		tot = 1;
	}
	if(!ff)ff=(WIN32_FIND_DATAW*)malloc(tot*sizeof(WIN32_FIND_DATAW));
	else ff=(WIN32_FIND_DATAW*)realloc(ff,tot*sizeof(WIN32_FIND_DATAW));

	if(1==tot && 0==panel[iPanel].GetTotSelects())
	{	int id=panel[iPanel].GetHot();
		if(id<1 || id>panel[iPanel].GetTotItems()-1) return NULL;

		panel[iPanel].GetFullPathAndName(id,&ff[0].cFileName[0],MAX_PATH-1);
		ff[0].dwFileAttributes = (panel[iPanel].GetItem(id)->attribute==folder)? FILE_ATTRIBUTE_DIRECTORY :
																				 FILE_ATTRIBUTE_NORMAL    ;
		ff[0].nFileSizeHigh = (panel[iPanel].GetItem(id)->size & 0xffffffff00000000) >> 32;
		ff[0].nFileSizeLow  =  panel[iPanel].GetItem(id)->size & 0xffffffff;
		ff[0].ftLastWriteTime = panel[iPanel].GetItem(id)->ftWrite;
		ff[0].ftCreationTime = panel[iPanel].GetItem(id)->ftWrite;
	}
	else
	{	int ireal=0;
		for(int i=0; i<tot; i++)
		{	int id = panel[iPanel].GetSelectedItemNum(i);
			if(id<1 || id>panel[iPanel].GetTotItems()-1) continue;
			panel[iPanel].GetFullPathAndName(id,ff[ireal].cFileName,MAX_PATH-1);
			ff[ireal].dwFileAttributes = (panel[iPanel].GetItem(id)->attribute==folder)? FILE_ATTRIBUTE_DIRECTORY :
																						   FILE_ATTRIBUTE_NORMAL    ;
			ff[ireal].nFileSizeHigh = (panel[iPanel].GetItem(id)->size & 0xffffffff00000000) >> 32;
			ff[ireal].nFileSizeLow  =  panel[iPanel].GetItem(id)->size & 0xffffffff;
			ff[ireal].ftLastWriteTime = panel[iPanel].GetItem(id)->ftWrite;
			ff[ireal].ftCreationTime = panel[iPanel].GetItem(id)->ftWrite;
			++ireal;
	}	}
	if(outTot)*outTot=tot;
	return &ff[0];
}