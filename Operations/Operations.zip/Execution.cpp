#include "..\Panel.h"
#include "..\Config.h"
#include "MyShell\MyShell.h"
#include "Execution.h"
#include "MyErrors.h"
#include "WinNT.H"//#include "WTYPES.H"
#include "HtmlHelp.H"



// ================= Windows structures/defines =================
#define IMAGE_SUBSYSTEM_UNKNOWN              0   // Unknown subsystem.
#define IMAGE_SUBSYSTEM_NATIVE               1   // Image doesn't require a subsystem.
#define IMAGE_SUBSYSTEM_WINDOWS_GUI          2   // Image runs in the Windows GUI subsystem.
#define IMAGE_SUBSYSTEM_WINDOWS_CUI			 3   // Image runs in the Windows character subsystem.
#define IMAGE_SUBSYSTEM_OS2_CUI              5   // image runs in the OS/2 character subsystem.
#define IMAGE_SUBSYSTEM_POSIX_CUI            7   // image runs in the Posix character subsystem.
#define IMAGE_SUBSYSTEM_NATIVE_WINDOWS       8   // image is a native Win9x driver.
#define IMAGE_SUBSYSTEM_WINDOWS_CE_GUI       9   // Image runs in the Windows CE subsystem.

/*typedef unsigned __int32 ULONG;
typedef			 __int32 LONG;
typedef unsigned __int16 WORD;
typedef unsigned __int8  UCHAR;

typedef struct _IMAGE_DOS_HEADER
{
     WORD e_magic;
     WORD e_cblp;
     WORD e_cp;
     WORD e_crlc;
     WORD e_cparhdr;
     WORD e_minalloc;
     WORD e_maxalloc;
     WORD e_ss;
     WORD e_sp;
     WORD e_csum;
     WORD e_ip;
     WORD e_cs;
     WORD e_lfarlc;
     WORD e_ovno;
     WORD e_res[4];
     WORD e_oemid;
     WORD e_oeminfo;
     WORD e_res2[10];
     LONG e_lfanew;
} IMAGE_DOS_HEADER, *PIMAGE_DOS_HEADER;

typedef struct _IMAGE_DATA_DIRECTORY
{
     ULONG VirtualAddress;
     ULONG Size;
} IMAGE_DATA_DIRECTORY, *PIMAGE_DATA_DIRECTORY;

typedef struct _IMAGE_OPTIONAL_HEADER
{
     WORD Magic;
     UCHAR MajorLinkerVersion;
     UCHAR MinorLinkerVersion;
     ULONG SizeOfCode;
     ULONG SizeOfInitializedData;
     ULONG SizeOfUninitializedData;
     ULONG AddressOfEntryPoint;
     ULONG BaseOfCode;
     ULONG BaseOfData;
     ULONG ImageBase;
     ULONG SectionAlignment;
     ULONG FileAlignment;
     WORD MajorOperatingSystemVersion;
     WORD MinorOperatingSystemVersion;
     WORD MajorImageVersion;
     WORD MinorImageVersion;
     WORD MajorSubsystemVersion;
     WORD MinorSubsystemVersion;
     ULONG Win32VersionValue;
     ULONG SizeOfImage;
     ULONG SizeOfHeaders;
     ULONG CheckSum;
     WORD Subsystem;
     WORD DllCharacteristics;
     ULONG SizeOfStackReserve;
     ULONG SizeOfStackCommit;
     ULONG SizeOfHeapReserve;
     ULONG SizeOfHeapCommit;
     ULONG LoaderFlags;
     ULONG NumberOfRvaAndSizes;
     IMAGE_DATA_DIRECTORY DataDirectory[16];
} IMAGE_OPTIONAL_HEADER, *PIMAGE_OPTIONAL_HEADER;
	
typedef struct _IMAGE_FILE_HEADER
{
     WORD Machine;
     WORD NumberOfSections;
     ULONG TimeDateStamp;
     ULONG PointerToSymbolTable;
     ULONG NumberOfSymbols;
     WORD SizeOfOptionalHeader;
     WORD Characteristics;
} IMAGE_FILE_HEADER, *PIMAGE_FILE_HEADER;
	
typedef struct _IMAGE_NT_HEADERS
{
     ULONG Signature;
     IMAGE_FILE_HEADER FileHeader;
     IMAGE_OPTIONAL_HEADER OptionalHeader;
} IMAGE_NT_HEADERS, *PIMAGE_NT_HEADERS;

typedef struct _IMAGE_SECTION_HEADER
{
     UCHAR Name[8];
     ULONG Misc;
     ULONG VirtualAddress;
     ULONG SizeOfRawData;
     ULONG PointerToRawData;
     ULONG PointerToRelocations;
     ULONG PointerToLinenumbers;
     WORD NumberOfRelocations;
     WORD NumberOfLinenumbers;
     ULONG Characteristics;
} IMAGE_SECTION_HEADER, *PIMAGE_SECTION_HEADER;*/


namespace Execution
{

BOOL exeBATCH(wchar_t *fullPathAndName)
{
STARTUPINFO si;ZeroMemory(&si,sizeof(si));si.cb=sizeof(si);
PROCESS_INFORMATION pi;
	BOOL r=CreateProcess(fullPathAndName,NULL,NULL,NULL,FALSE,0,NULL,NULL,&si,&pi);
	if(!r)
		Err::msg(hWnd,-1,L"exeBATCH");
	return r;
}

BOOL exePE(wchar_t *fullPathAndName, wchar_t *cmdLine)
{
STARTUPINFO si;ZeroMemory(&si,sizeof(si));si.cb=sizeof(si);
PROCESS_INFORMATION pi;
	BOOL r=CreateProcess(fullPathAndName,cmdLine,NULL,NULL,FALSE,0,NULL,NULL,&si,&pi);
	if(!r)
		Err::msg(hWnd,-1,L"ExePE");
	return r;
}

BOOL exePERoot(wchar_t *fullPathAndName, wchar_t *cmdLine, wchar_t *root)
{
STARTUPINFO si;ZeroMemory(&si,sizeof(si));si.cb=sizeof(si);
PROCESS_INFORMATION pi;
	BOOL r=CreateProcess(fullPathAndName,cmdLine,NULL,NULL,FALSE,0,NULL,root,&si,&pi);
	if(!r)
		Err::msg(hWnd,-1,L"ExePE");
	return r;
}

DWORD exePESplitCmndLine(wchar_t *fullPathAndName, wchar_t *cmdLine,wchar_t* root)
{wchar_t s[2*MAX_PATH];
STARTUPINFO si;PROCESS_INFORMATION pi;pi.dwThreadId=0;
ZeroMemory(&si,sizeof(si));si.cb=sizeof(si);
    wchar_t rooT[MAX_PATH];wchar_t *p=&rooT[0];
	MyStringCpy(rooT,MAX_PATH,root);
	if(!IsDirExist(rooT))
	{wchar_t *p=wcsrchr(rooT,'\\');
	 if(p)*p=0;
	 else p=NULL;
	}
	BOOL r=FALSE;
	int l=MyStringCpy(s,2*MAX_PATH,fullPathAndName);
	s[l++]=' ';MyStringCpy(&s[l],2*MAX_PATH-l,cmdLine);
	r=CreateProcess(s,NULL,NULL,NULL,FALSE,0,NULL,p,&si,&pi);
	if(!r)
	{s[0]=' ';MyStringCpy(&s[1],MAX_PATH,cmdLine);
	 r=CreateProcess(fullPathAndName,s,NULL,NULL,FALSE,0,NULL,p,&si,&pi);
	}
	if(!r)
	{HINSTANCE hi=ShellExecute(NULL,L"open",fullPathAndName,cmdLine,p,SW_SHOW);
	 if(32<(int)hi)
	  r=TRUE;
	 else 
	 {	hi=ShellExecute(NULL,L"open",cmdLine,NULL,NULL,SW_SHOW);
		if(32<(int)hi)
		  r=TRUE;
	}}
	if(r && pi.dwThreadId)return pi.dwThreadId;
	return 0;
}

BOOL exePEPutSpaceToCmndLine(wchar_t *fullPathAndName, wchar_t *cmdLine,wchar_t* root)
{wchar_t s[2*MAX_PATH];STARTUPINFO si;PROCESS_INFORMATION pi;
ZeroMemory(&si,sizeof(si));si.cb=sizeof(si);
s[0]=' ';MyStringCpy(&s[1],MAX_PATH-2,cmdLine);

    wchar_t rooT[MAX_PATH];wchar_t *p=&rooT[0];
	MyStringCpy(rooT,MAX_PATH,root);
	if(!IsDirExist(rooT))
	{wchar_t *p=wcsrchr(rooT,'\\');
	 if(p)*p=0;
	 else p=NULL;
	}
	
	BOOL r=CreateProcess(fullPathAndName,s,NULL,NULL,FALSE,0,NULL,p,&si,&pi);
	if(!r)
	{HINSTANCE hi=ShellExecute(NULL,L"open",s,NULL,p,SW_SHOW);
	 if(32<(int)hi)
	  r=TRUE;
	 else 
	 {	//Err::msg(hWnd,-1,L"ExePE");
	}}
	return r;
}

BOOL exePEA(char *fullPathAndName, char *cmdLine)
{
STARTUPINFOA si;ZeroMemory(&si,sizeof(si));si.cb=sizeof(si);
PROCESS_INFORMATION pi;
	BOOL r=CreateProcessA(fullPathAndName,cmdLine,NULL,NULL,FALSE,0,NULL,NULL,&si,&pi);
	if(!r)
		Err::msg(hWnd,-1,L"ExePEA");
	return r;
}

BOOL exeCHM(wchar_t *fullPathAndName, UINT cmd)
{
	HWND r=HtmlHelp(GetDesktopWindow(),fullPathAndName,cmd,NULL);
	if(!r)r=HtmlHelp(GetDesktopWindow(),fullPathAndName,HH_HELP_CONTEXT,NULL);
	if(!r)r=HtmlHelp(GetDesktopWindow(),fullPathAndName,HH_DISPLAY_TOPIC,NULL);
	if(!r)r=HtmlHelp(GetDesktopWindow(),fullPathAndName,HH_HELP_FINDER,NULL);
	if(!r)
		Err::msg(hWnd,-1,L"HtmlHelp");
	return (r==NULL?FALSE:TRUE);
}

//Sino pastidagi command CB editidan kiritilgan komandalarni bajarish:
BOOL exeFrCmndCB(wchar_t *cmdCBstr)
{
//STARTUPINFO si;si.cb=sizeof(si);PROCESS_INFORMATION pi;
//BOOL r;
int l;wchar_t pth[MAX_PATH],cmdLine[MAX_PATH],fstCmd[MAX_PATH],*p,*pp;
	__try
	{
     l=MyStringCpy(pth,MAX_PATH-1,panel[Panel::iActivePanel].GetFullPathAndName(0));
	 if(pth[l-1]=='*')pth[l-1]=0;
	 MyStringCpy(fstCmd,MAX_PATH-1,cmdCBstr);
	 p=wcschr(fstCmd,' ');
	 if(p)
	 {	MyStringCpy(cmdLine,MAX_PATH-1,p);
		*p=0;
	 }	 
	 if(32>=(int)ShellExecute(hWnd,L"open",fstCmd,p?cmdLine:NULL,pth,SW_SHOWNORMAL))//r=CreateProcess(NULL,cmdCBstr,0,0,0,0,0,pth,&si,&pi);
	 {	pp=wcsrchr(fstCmd,'.');
	    if(!pp)
		{	pp=&fstCmd[0]+MyStringLength(fstCmd,MAX_PATH);
			*pp='.';
		}
		MyStringCpy(pp+1,4,L"exe");
		if(32>=(int)ShellExecute(hWnd,L"open",fstCmd,p?cmdLine:NULL,pth,SW_SHOWNORMAL))
		{	pp=wcsrchr(fstCmd,'.');
			MyStringCpy(pp+1,4,L"msc");
			if(32>=(int)ShellExecute(hWnd,L"open",fstCmd,p?cmdLine:NULL,pth,SW_SHOWNORMAL))
			{	pp=wcsrchr(fstCmd,'.');
				MyStringCpy(pp+1,4,L"cpl");
				ShellExecute(hWnd,L"open",fstCmd,p?cmdLine:NULL,pth,SW_SHOWNORMAL);
	}}  }   }
	__finally
	{	//Err::msg(hWnd,0,L"Command execution error...");
	}
	//if(!r)
	//	Err::msg(hWnd,-1,L"Command execution error...");
	return TRUE;//r;
}

BOOL IsExeInPEHeader(char* buffer, unsigned long size)
{
IMAGE_DOS_HEADER* dos_header;
#ifdef _WIN64
IMAGE_NT_HEADERS64* header;
	char pe_magic[] = "\x50\x45\x00\x00\x64\x86";
	const WORD magic_value = 0x020b;
#else
IMAGE_NT_HEADERS32* header;
	char pe_magic[] = "\x50\x45\x00\x00\x4c\x01";
	const WORD magic_value = 0x010b;
#endif
	// Check whether buffer contains enough bytes to contain a dos header
	if ((long)size < sizeof(IMAGE_DOS_HEADER))
		return FALSE;
	dos_header = (IMAGE_DOS_HEADER*)buffer;
	// Check whether buffer is large enough to contain a PE header
#ifdef _WIN64
	if ((long)size < dos_header->e_lfanew || (long)size - dos_header->e_lfanew < sizeof(IMAGE_NT_HEADERS64))
		return FALSE;
	header = (IMAGE_NT_HEADERS64*) (buffer + dos_header->e_lfanew);
#else
	// Check whether buffer is large enough to contain a PE header
	if ((long)size < dos_header->e_lfanew || (long)size - dos_header->e_lfanew < sizeof(IMAGE_NT_HEADERS32))
		return FALSE;
	header = (IMAGE_NT_HEADERS32*) (buffer + dos_header->e_lfanew);
#endif

	// A PE header should start with this sequence (PE00)
	if (memcmp(header, pe_magic, 6))
		return FALSE;
	// Check magic value
	if (header->OptionalHeader.Magic != magic_value)
		return FALSE;

	// Win32 VersionValue should be zero
	if (header->OptionalHeader.Win32VersionValue != 0)
		return FALSE;

	// Check whether subsystem is sane one
	if (header->OptionalHeader.Subsystem != IMAGE_SUBSYSTEM_NATIVE &&
		header->OptionalHeader.Subsystem != IMAGE_SUBSYSTEM_UNKNOWN &&
		header->OptionalHeader.Subsystem != IMAGE_SUBSYSTEM_WINDOWS_GUI &&
		header->OptionalHeader.Subsystem != IMAGE_SUBSYSTEM_WINDOWS_CUI)
		return FALSE;

	if(!(IMAGE_FILE_EXECUTABLE_IMAGE & header->FileHeader.Characteristics))
		return FALSE;
	// Changes are that this is actually a valid PE header
	return TRUE;
}

int IsThisValidDllOrExeFile(wchar_t *filename)
{
LPVOID lpFileBase;BOOL bFndDll;PIMAGE_DOS_HEADER dosHeader;
HANDLE /*hFileMapping,*/hFile = CreateFile(	filename, GENERIC_READ, FILE_SHARE_READ, NULL,
							OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, 0);

    if ( hFile == INVALID_HANDLE_VALUE )
    {	//printf("Couldn't open file with CreateFile()\n");
        return FALSE;
    }

	//hFileMapping = CreateFileMapping(hFile, NULL, PAGE_READONLY, 0, 0, NULL);
    //if ( hFileMapping == 0 )
    //{	CloseHandle(hFile);
        //printf("Couldn't open file mapping with CreateFileMapping()\n");
    //    return 0;
    //}

	//lpFileBase = MapViewOfFile(hFileMapping, FILE_MAP_READ, 0, 0, 0);
    //if ( lpFileBase == 0 )
    //{	CloseHandle(hFileMapping);
    //  CloseHandle(hFile);
        //printf("Couldn't map view of file with MapViewOfFile()\n");
    //    return 0;
    //}

    //printf("Dump of file %s\n\n", filename);
#ifdef _WIN64
	lpFileBase = malloc(sizeof(IMAGE_DOS_HEADER)+2*sizeof(IMAGE_NT_HEADERS64));
	DWORD rd;ReadFile(hFile,lpFileBase,sizeof(IMAGE_DOS_HEADER)+2*sizeof(IMAGE_NT_HEADERS64),&rd,NULL);
	bFndDll=0;
	if(rd!=sizeof(IMAGE_DOS_HEADER)+2*sizeof(IMAGE_NT_HEADERS64))
		goto End;
	dosHeader = (PIMAGE_DOS_HEADER)lpFileBase;
    if ( dosHeader->e_magic == IMAGE_DOS_SIGNATURE )
    {   bFndDll = 1;
		if(IsExeInPEHeader( (char*)dosHeader, sizeof(IMAGE_DOS_HEADER)+2*sizeof(IMAGE_NT_HEADERS64) ))
			bFndDll = 2;
    }
#else
	lpFileBase = malloc(sizeof(IMAGE_DOS_HEADER)+2*sizeof(IMAGE_NT_HEADERS32));
	DWORD rd;ReadFile(hFile,lpFileBase,sizeof(IMAGE_DOS_HEADER)+2*sizeof(IMAGE_NT_HEADERS32),&rd,NULL);
	bFndDll=0;
	if(rd!=sizeof(IMAGE_DOS_HEADER)+2*sizeof(IMAGE_NT_HEADERS32))
		goto End;
	dosHeader = (PIMAGE_DOS_HEADER)lpFileBase;
    if ( dosHeader->e_magic == IMAGE_DOS_SIGNATURE )
    {   bFndDll = 1;
		if(IsExeInPEHeader( (char*)dosHeader, sizeof(IMAGE_DOS_HEADER)+2*sizeof(IMAGE_NT_HEADERS32) ))
			bFndDll = 2;
    }
#endif
    /*else if ( (dosHeader->e_magic == 0x014C)    // Does it look like a i386
              && (dosHeader->e_sp == 0) )        // COFF OBJ file???
    {
        // The two tests above aren't what they look like.  They're
        // really checking for IMAGE_FILE_HEADER.Machine == i386 (0x14C)
        // and IMAGE_FILE_HEADER.SizeOfOptionalHeader == 0;
        bFndDll=IsDllInObjFile( (PIMAGE_FILE_HEADER)lpFileBase );
    }*/
    //else
    //    printf("unrecognized file format\n");
    //UnmapViewOfFile(lpFileBase);
    //CloseHandle(hFileMapping);
End:
    CloseHandle(hFile);
	free(lpFileBase);
	return bFndDll>0?TRUE:FALSE;
}

BOOL IsThisValidChmFile(wchar_t *filename)
{
DWORD rd;
HANDLE hFile = CreateFile(	filename, GENERIC_READ, FILE_SHARE_READ, NULL,
							OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, 0);
	if ( hFile == INVALID_HANDLE_VALUE )
    	return FALSE;

	unsigned __int32 itsf;ReadFile(hFile,&itsf,sizeof(__int32),&rd,NULL);
	if(rd!=sizeof(__int32) || itsf!=0x46535449)
		{CloseHandle(hFile);return FALSE;}
	unsigned __int32 version;ReadFile(hFile,&version,sizeof(__int32),&rd,NULL);
	if(rd!=sizeof(__int32))
		{CloseHandle(hFile);return FALSE;}
	unsigned __int32 headerSize;ReadFile(hFile,&headerSize,sizeof(__int32),&rd,NULL);
	if(rd!=sizeof(__int32))
		{CloseHandle(hFile);return FALSE;}
	if(headerSize != 0x60)
		{CloseHandle(hFile);return FALSE;}
	unsigned __int32 unknown1; ReadFile(hFile,&unknown1,sizeof(__int32),&rd,NULL);
	if(rd!=sizeof(__int32))
		{CloseHandle(hFile);return FALSE;}
	if (unknown1 != 0 && unknown1 != 1) // it's 0 in one .sll file
		{CloseHandle(hFile);return FALSE;}
	ReadFile(hFile,&unknown1,sizeof(__int32),&rd,NULL);
	ReadFile(hFile,&unknown1,sizeof(__int32),&rd,NULL);
	DWORD Guid[8];ReadFile(hFile,Guid,8*sizeof(DWORD),&rd,NULL);
	CloseHandle(hFile);
	if(Guid[0]!=0x7C01FD10) return FALSE;
	if(Guid[1]!=0x11d07baa) return FALSE;
	if(Guid[2]!=0xa0000c9e) return FALSE;
	if(Guid[3]!=0xece622c9) return FALSE;
	if(Guid[4]!=0x7c01fd11) return FALSE;
	if(Guid[5]!=0x11d07baa) return FALSE;
	if(Guid[6]!=0xa0000c9e) return FALSE;
	if(Guid[7]!=0xece622c9) return FALSE;
	return TRUE;
}

BOOL tryToExec(Panel *p,int itemId)
{
wchar_t *fulPathAndName = p->GetFullPathAndName(itemId);
	/*DWORD binType;if(0!=GetBinaryType(fulPathAndName,&binType))
	{	if(SCS_32BIT_BINARY==binType || SCS_DOS_BINARY==binType || SCS_OS216_BINARY==binType || SCS_PIF_BINARY==binType || SCS_POSIX_BINARY==binType || SCS_WOW_BINARY==binType)
			return exePE(fulPathAndName,NULL);}*/
	if(IsThisValidDllOrExeFile(fulPathAndName))//2 emas(PE), DOS exe b-sayam;
		return exePE(fulPathAndName,NULL);
	if(IsThisValidChmFile(fulPathAndName))
		if(exeCHM(fulPathAndName,NULL)) return TRUE;

	//Else, others:
wchar_t *pExt = wcsrchr(fulPathAndName,'.');
	if(pExt)
	{	//1.bat file:
		++pExt;
		if(*pExt=='b' || *pExt=='B')
		if(*(pExt+1)=='a' || *(pExt+1)=='A')
		if(*(pExt+2)=='t' || *(pExt+2)=='T')
			return exeBATCH(fulPathAndName);
		//if(*pExt=='c' || *pExt=='C')
		//if(*(pExt+1)=='h' || *(pExt+1)=='H')
		//if(*(pExt+2)=='m' || *(pExt+2)=='M')
		//	if(exeCHM(fulPathAndName,NULL)) return TRUE;
	}

	//Archive plugins:
	if(conf::Dlg.crntArchvr>0)
	if(archive::numPlugins>0)
	if(conf::Dlg.crntArchvr<archive::numPlugins)
	{	int i=conf::Dlg.crntArchvr;
		if(1==archive::plgns[i].type || 3==archive::plgns[i].type)//unpacking;
		{	if(pExt && (0==_wcsicmp(pExt,archive::plgns[i].extnsn)))
			{	int id;
				if(p->GetTotSelects()<=1 || p->GetTotSelects()>p->GetTotItems()-1)
					id = p->GetHot();
				else//get from selection:
					id=p->GetSelectedItemNum(0);
				p->FolderInToArch(i,id);
				return TRUE;
	}	}	}
	//else:
	for(int i=0; i<archive::numPlugins; i++)
	{	if(1==archive::plgns[i].type || 3==archive::plgns[i].type)//unpacking;
		{	if(pExt)
			if(0==_wcsicmp(pExt,archive::plgns[i].extnsn))
			{	int id;
				if(p->GetTotSelects()<=1 || p->GetTotSelects()>p->GetTotItems()-1)
					id = p->GetHot();
				else//get from selection:
					id=p->GetSelectedItemNum(0);
				p->FolderInToArch(i,id);
				return TRUE;
	}	}	}

	ShellExecute(hWnd,L"open",fulPathAndName,L"",NULL,SW_SHOWDEFAULT);

	return TRUE;
}

// Check whether contents in buffer is a valid PE header
BOOL IsDLLInPEHeader(char* buffer, unsigned long size)
{
	// Check whether buffer contains enough bytes to contain a dos header
	if ((long)size < sizeof(IMAGE_DOS_HEADER))
		return FALSE;
	IMAGE_DOS_HEADER* dos_header = (IMAGE_DOS_HEADER*) buffer;
	// Check whether buffer is large enough to contain a PE header
#ifdef _WIN64
	char pe_magic[] = "\x50\x45\x00\x00\x64\x86";
	const WORD magic_value = 0x020b;
	if ((long)size < dos_header->e_lfanew || (long)size - dos_header->e_lfanew < sizeof(IMAGE_NT_HEADERS64))
		return FALSE;
	IMAGE_NT_HEADERS64* header = (IMAGE_NT_HEADERS64*) (buffer + dos_header->e_lfanew);
#else
	char pe_magic[] = "\x50\x45\x00\x00\x4c\x01";
	const WORD magic_value = 0x010b;
	if ((long)size < dos_header->e_lfanew || (long)size - dos_header->e_lfanew < sizeof(IMAGE_NT_HEADERS32))
		return FALSE;
	IMAGE_NT_HEADERS32* header = (IMAGE_NT_HEADERS32*) (buffer + dos_header->e_lfanew);
#endif

	// A PE header should start with this sequence (PE00)
	if (memcmp(header, pe_magic, 6*sizeof(char)))
		return FALSE;
	// Check magic value
	if (header->OptionalHeader.Magic != magic_value)
		return FALSE;

	// Win32 VersionValue should be zero
	if (header->OptionalHeader.Win32VersionValue != 0)
		return FALSE;

	// Check whether subsystem is sane one
	if (header->OptionalHeader.Subsystem != IMAGE_SUBSYSTEM_NATIVE &&
		header->OptionalHeader.Subsystem != IMAGE_SUBSYSTEM_UNKNOWN &&
		header->OptionalHeader.Subsystem != IMAGE_SUBSYSTEM_WINDOWS_GUI &&
		header->OptionalHeader.Subsystem != IMAGE_SUBSYSTEM_WINDOWS_CUI)
		return FALSE;

	if(!(IMAGE_FILE_DLL & header->FileHeader.Characteristics))
		return FALSE;
	// Changes are that this is actually a valid PE header
	return TRUE;
}

BOOL IsThisValidDllFile(wchar_t *filename)
{
HANDLE hFile = CreateFile(	filename, GENERIC_READ, FILE_SHARE_READ, NULL,
							OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, 0);

    if ( hFile == INVALID_HANDLE_VALUE )
    {	//printf("Couldn't open file with CreateFile()\n");
        return FALSE;
    }

HANDLE hFileMapping = CreateFileMapping(hFile, NULL, PAGE_READONLY, 0, 0, NULL);
    if ( hFileMapping == 0 )
    {	CloseHandle(hFile);
        //printf("Couldn't open file mapping with CreateFileMapping()\n");
        return FALSE;
    }

LPVOID lpFileBase = MapViewOfFile(hFileMapping, FILE_MAP_READ, 0, 0, 0);
    if ( lpFileBase == 0 )
    {	CloseHandle(hFileMapping);
        CloseHandle(hFile);
        //printf("Couldn't map view of file with MapViewOfFile()\n");
        return FALSE;
    }

    //printf("Dump of file %s\n\n", filename);
BOOL bFndDll=FALSE;
PIMAGE_DOS_HEADER dosHeader = (PIMAGE_DOS_HEADER)lpFileBase;
    if ( dosHeader->e_magic == IMAGE_DOS_SIGNATURE )
#ifdef _WIN64
        bFndDll=IsDLLInPEHeader((char*)dosHeader, sizeof(IMAGE_DOS_HEADER)+2*sizeof(IMAGE_NT_HEADERS64) );
#else
        bFndDll=IsDLLInPEHeader((char*)dosHeader, sizeof(IMAGE_DOS_HEADER)+2*sizeof(IMAGE_NT_HEADERS32) );
#endif
    /*else if ( (dosHeader->e_magic == 0x014C)    // Does it look like a i386
              && (dosHeader->e_sp == 0) )        // COFF OBJ file???
    {
        // The two tests above aren't what they look like.  They're
        // really checking for IMAGE_FILE_HEADER.Machine == i386 (0x14C)
        // and IMAGE_FILE_HEADER.SizeOfOptionalHeader == 0;
        bFndDll=IsDllInObjFile( (PIMAGE_FILE_HEADER)lpFileBase );
    }*/
    //else
    //    printf("unrecognized file format\n");
    UnmapViewOfFile(lpFileBase);
    CloseHandle(hFileMapping);
    CloseHandle(hFile);
	return bFndDll; 
}

BOOL IsThisValidExeFile(wchar_t *filename)
{
HANDLE hFile = CreateFile(	filename, GENERIC_READ, FILE_SHARE_READ, NULL,
							OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, 0);

    if ( hFile == INVALID_HANDLE_VALUE )
    {	//printf("Couldn't open file with CreateFile()\n");
        return FALSE;
    }

HANDLE hFileMapping = CreateFileMapping(hFile, NULL, PAGE_READONLY, 0, 0, NULL);
    if ( hFileMapping == 0 )
    {	CloseHandle(hFile);
        //printf("Couldn't open file mapping with CreateFileMapping()\n");
        return FALSE;
    }

LPVOID lpFileBase = MapViewOfFile(hFileMapping, FILE_MAP_READ, 0, 0, 0);
    if ( lpFileBase == 0 )
    {	CloseHandle(hFileMapping);
        CloseHandle(hFile);
        //printf("Couldn't map view of file with MapViewOfFile()\n");
        return FALSE;
    }

    //printf("Dump of file %s\n\n", filename);
BOOL bFndExe=FALSE;
PIMAGE_DOS_HEADER dosHeader = (PIMAGE_DOS_HEADER)lpFileBase;
    if ( dosHeader->e_magic == IMAGE_DOS_SIGNATURE )
#ifdef _WIN64
        bFndExe=IsExeInPEHeader((char*)dosHeader, sizeof(IMAGE_DOS_HEADER)+2*sizeof(IMAGE_NT_HEADERS64) );
#else
        bFndExe=IsExeInPEHeader((char*)dosHeader, sizeof(IMAGE_DOS_HEADER)+2*sizeof(IMAGE_NT_HEADERS32) );
#endif
    /*else if ( (dosHeader->e_magic == 0x014C)    // Does it look like a i386
              && (dosHeader->e_sp == 0) )        // COFF OBJ file???
    {
        // The two tests above aren't what they look like.  They're
        // really checking for IMAGE_FILE_HEADER.Machine == i386 (0x14C)
        // and IMAGE_FILE_HEADER.SizeOfOptionalHeader == 0;
        bFndDll=IsDllInObjFile( (PIMAGE_FILE_HEADER)lpFileBase );
    }*/
    //else
    //    printf("unrecognized file format\n");
    UnmapViewOfFile(lpFileBase);
    CloseHandle(hFileMapping);
    CloseHandle(hFile);
	return bFndExe; 
}

// Calculate PE filesize 
// returns filesize in bytes
/*uint32_t determine_file_size(char* buffer)
{
	uint32_t result = 0;

	// From the DOS header we know at which offset the PE header starts
	IMAGE_DOS_HEADER* dos_header = (IMAGE_DOS_HEADER*) buffer;

	// We need the PE header to access to underlying structures for the data directories and number of sections
#ifdef _WIN64
	IMAGE_NT_HEADERS64* header = (IMAGE_NT_HEADERS64*)(buffer + dos_header->e_lfanew);
#else
	IMAGE_NT_HEADERS32* header = (IMAGE_NT_HEADERS32*)(buffer + dos_header->e_lfanew);
#endif

	// Find start of sectionheaders; the start is calclulated by adding SizeOfOptionalHeader to the start of the 
	// optional header (which is 18h from the start of the PE header)
	char* sectionheaders_start = buffer + dos_header->e_lfanew + 0x18 + header->FileHeader.SizeOfOptionalHeader; 

	// Find the section which is located nearest to the end of the file by iterating over all sections
	uint32_t largest_pointer_to_raw_data = 0, largerst_size_of_raw_data = 0;
	uint16_t i = 0;
	for (i = 0; i < header->FileHeader.NumberOfSections; i++)
	{
		IMAGE_SECTION_HEADER* section_header = 
			(IMAGE_SECTION_HEADER*) (sectionheaders_start + i*sizeof(IMAGE_SECTION_HEADER));

		// Save the size and pointer of the section nearest to the end of file (i.e. the largests pointer)
		if (section_header->PointerToRawData > largest_pointer_to_raw_data)
		{
			largest_pointer_to_raw_data = section_header->PointerToRawData;
			largerst_size_of_raw_data = section_header->SizeOfRawData;
		}
	}

	// Pointer is releative to start of file so we now know the filesize
	result = largest_pointer_to_raw_data + largerst_size_of_raw_data;

	return result;
}*/

}//end of namespace