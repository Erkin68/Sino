#include "windows.h"

class Panel;

namespace Execution
{
	extern BOOL  exeBATCH(wchar_t*);
	extern BOOL  exePE(wchar_t*,wchar_t*);
	extern BOOL exePERoot(wchar_t*,wchar_t*,wchar_t*);
	extern BOOL  exePEPutSpaceToCmndLine(wchar_t*,wchar_t*,wchar_t*);
	extern DWORD exePESplitCmndLine(wchar_t*,wchar_t*,wchar_t*);
	extern BOOL  exePEA(char*,char*);
	extern BOOL  exeFrCmndCB(wchar_t*);
	extern BOOL  tryToExec(Panel*,int);
	extern BOOL  IsThisValidDllFile(wchar_t*);
	extern BOOL  IsThisValidExeFile(wchar_t*);
	extern int   IsThisValidDllOrExeFile(wchar_t*);
}