#ifndef _MY_STREAMS_H_
#define _MY_STREAMS_H_

#include "windows.h"

namespace fileStream
{
	extern VOID EnumFileStreams(HWND,wchar_t*);
	extern BOOL IsFileConsistStream(wchar_t*);
}
#endif