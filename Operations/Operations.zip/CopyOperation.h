#ifndef _CopyOperation_H_
#define _CopyOperation_H_

#include "windows.h"

class Panel;

struct CpyStack
{	wchar_t	 attribute;
	unsigned __int64	 size;//in bytes;
	wchar_t  Name		 [MAX_PATH];
	wchar_t  FullPathAndName[MAX_PATH];
};
/*struct CpyStackA
{	wchar_t	 attribute;
	unsigned __int64	 size;//in bytes;
	char  Name		 [MAX_PATH];
	char  FullPathAndName[MAX_PATH];
};*/
struct cpyTrdDat
{
	HWND	 hDlg;
	DWORD	 thrId;
	BOOL	 bStop;
	BOOL	 bCancel;
	int		 iRollDown;
	BOOL	 bSwtchToBckgrnd;
	int		 iCrntFileCopy;
	CpyStack *stack;
	DWORD	 beginTickTot,stopTickTot[2];
	DWORD	 beginTick,stopTick[2];
};
/*struct cpyTrdDatA
{
	HWND	 hDlg;
	DWORD	 thrId;
	BOOL	 bStop;
	BOOL	 bCancel;
	BOOL	 bSwtchToBckgrnd;
	int		 iCrntFileCopy;
	CpyStackA *stack;
	DWORD	 beginTickTot,stopTickTot[2];
	DWORD	 beginTick,stopTick[2];
};*/
typedef enum TEnCheckCopyFilesToExisting
{	cancel=0,
	showEach=1,
	overwrite=2,
	overwriteAll=3,
	skip=4,
	skipAll=5,//cancelAll-rezerver word(ili podobe etogo)
	rename1=6,
	renameAll=7,
	overwriteOldest=8,
	overwriteOldestAll=9,
	overwriteLatest=10,
	overwriteLatestAll=11,
	overwriteBigest=12,
	overwriteBigestAll=13,
	overwriteLittlest=14,
	overwriteLittlestAll=15
} EnCheckCopyFilesToExisting;
extern EnCheckCopyFilesToExisting enCheckCopyFilesToExisting;

namespace fCopyOper
{
	//extern VOID AddFolderSizeA(char*);
	extern VOID AddFolderSize(wchar_t*);
	extern VOID	CalcSrcAndAvailableDestSize();
	extern INT_PTR CALLBACK CopyDlgProc(HWND,UINT,WPARAM,LPARAM);
	extern INT_PTR CALLBACK CopyQueueDlgProc(HWND hDlg,UINT,WPARAM,LPARAM);
	extern VOID cpyFileExBckQueueThrdFnc(LPVOID);
	extern VOID cpyFileExThrdFnc(LPVOID);
	extern DWORD CALLBACK cpyPrgrssRout(LARGE_INTEGER,LARGE_INTEGER,LARGE_INTEGER,LARGE_INTEGER,DWORD,DWORD,HANDLE,HANDLE,LPVOID);
	//extern BOOL CutSelectedNamesA(CpyStackA*,char*,int);
	extern BOOL CutSelectedNames(CpyStack*,wchar_t*,int);
	extern BOOL	FillCopyFilesInfo(HWND,LPARAM,int);
	//extern int  GetFilesCntInFolderA(char*);
	extern int  GetFilesCntInFolder(wchar_t*);
	//extern int GetFilesInFolderA(char*,CpyStackA*);
	extern int  GetFilesInFolder(wchar_t*,CpyStack*);
	extern int  GetFilesInFolderToDlg(wchar_t*,int,HWND,HWND);
	//extern int GetSelectedFilesA(CpyStackA*);
	extern int	GetSelectedFiles(CpyStack*);
	extern int	GetSelectedFilesCnt();
	extern int  GetFilesInFolder(wchar_t*,CpyStack*);
	extern unsigned __int64 GetSelectedFilesToDlg(HWND,HWND);
	extern BOOL	IsFileExtIncludeCopyFilter(int);
	//extern BOOL IsFileExtIncludeCopyFilterIA(char*);
	extern BOOL IsFileExtIncludeCopyFilterI(wchar_t*);
	extern BOOL	ShowCopyDlg(Panel*);

	extern int srcPanel,destPanel,srcCnt;
	extern unsigned __int64 srcSz,copySrcSz,avDstSz;
	extern wchar_t 	destPath[MAX_PATH];

	typedef enum
	{	unchange,     //use asterics('\'+'*'+'0') symbol at the end;
		rename1File,  //1 ta fayl,  u ham bo'lsa nomini o'zgartirish kerak;
		rename1Folder,//1 ta folder,u ham bo'lsa nomini o'zgartirish kerak;
		allToRenFolder//hammasini 1 ta yangi folderga tiqish kerak;
	} SrcType;
	typedef enum
	{	single,
		addToBack
	} CopyType;
	typedef enum
	{	mCopyFileEx,
		mSHFileOperation
	} CopyMethod;
	extern SrcType srcType;
	extern CopyType copyType;
	extern CopyMethod copyMethod;

	extern HANDLE hAcknowlegeEvent;
};

#endif