#ifndef __TEMPORARY_H__
#define __TEMPORARY_H__

#include "windows.h"

extern "C"
{
extern int MyStringCpy(wchar_t*,int,wchar_t*);
}

class Panel;
class CTempDir
{
public:
	static int iCnt;
	static VOID AddToTempItemsLists(wchar_t*);
	static VOID FreeTempItems();


			CTempDir(wchar_t*);
			CTempDir(int);
			CTempDir();
		   ~CTempDir();
	HANDLE	AddFile(WIN32_FIND_DATA*,BOOL);
	VOID	AddSlashToPath();
	VOID	Close();
	BOOL	FindRandomDir();
	VOID	Free();
	wchar_t *GetPath();
	VOID	SetPath(wchar_t*);
	wchar_t *GetItemPathAndName();
	BOOL	UnpackSelected(Panel*);
	VOID	SetArchFilePath(wchar_t*);
	VOID	SetArchPath(wchar_t*);
	VOID	SetOldItem(int);
	wchar_t *GetItem(int);
	VOID	Restore(Panel*);
	BOOL	TryRestore();
	VOID    SetPlgNum(int);

typedef enum TType
{	arjCpyToArj=0,//arj paneldan arj panelga ko'chirish uchun;
	arjStack=1    //arj panel ichida arj item kelsa, ichma-ich arj tashkil etish uchun;
} Type;
Type type;

protected:
	int		iffd;
	int		oldId;
	int		maxFfdBufSz;
	int		pthLn;
	int     plgNum;
	wchar_t path[MAX_PATH];
	wchar_t fName[MAX_PATH];
	wchar_t archFilePath[MAX_PATH];
	wchar_t archPath[MAX_PATH];
	WIN32_FIND_DATAW* ffd;
};

inline wchar_t* CTempDir::GetPath(){return path;}
inline VOID CTempDir::SetPath(wchar_t *s){pthLn=MyStringCpy(path,MAX_PATH-1,s);}
inline VOID CTempDir::SetArchFilePath(wchar_t *s){MyStringCpy(archFilePath,MAX_PATH-1,s);}
inline VOID CTempDir::SetArchPath(wchar_t *s){MyStringCpy(archPath,MAX_PATH-1,s);}
inline VOID CTempDir::SetOldItem(int id){oldId=id;}
inline VOID CTempDir::SetPlgNum(int p){plgNum=p;}

#endif