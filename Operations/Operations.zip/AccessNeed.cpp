#include "windows.h"
#include "strsafe.h"
#include "MyShell\MyShell.h"
#include "MyErrors.h"
#include "CopyOperation.h"

extern HWND hWnd;

extern "C"
{

BOOL WINAPI MyCopyFileEx(
						__in  LPWSTR lpExistingFileName,
						__in  LPWSTR lpNewFileName,
						__in  LPPROGRESS_ROUTINE lpProgressRoutine,
						__in  LPVOID lpData,
						__in  LPBOOL pbCancel,
						__in  DWORD dwCopyFlags)
{
DWORD e;
	if(CopyFileEx(	lpExistingFileName,
					lpNewFileName,
					lpProgressRoutine,
					lpData,
					pbCancel,
					dwCopyFlags))
		return TRUE;
	e = GetLastError();
	if(ERROR_REQUEST_ABORTED==e)
		return FALSE;

	Err::msgC2(hWnd,e,L"CopyFileEx:",lpExistingFileName,lpNewFileName);
	return FALSE; 
	//Administartor levelini so'raymiz:
}

BOOL WINAPI MyCopyRenameFileEx( __in  LPWSTR lpExistingFileName,
								__in  LPWSTR lpNewFileName,
								__in  LPPROGRESS_ROUTINE lpProgressRoutine,
								__in  LPVOID lpData,
								__in  LPBOOL pbCancel,
								__in  DWORD dwCopyFlags)
{
wchar_t RenName[MAX_PATH],sAdd[32];
	int iMyCopyRenameFileEx=0;
	wchar_t* pExt = (wchar_t*)wcsrchr(lpNewFileName,'.');
	if(pExt) memcpy(RenName,lpNewFileName,sizeof(wchar_t)*(((wchar_t*)pExt) - ((wchar_t*)lpNewFileName)));
	else MyStringCpy(RenName,MAX_PATH-1,(wchar_t*)lpNewFileName);
	do
	{	++iMyCopyRenameFileEx;
		StringCchPrintf(sAdd,32,L"_%d",iMyCopyRenameFileEx);
		MyStringCat(RenName,MAX_PATH-1,sAdd);
		if(pExt)
			MyStringCat(RenName,MAX_PATH-1,pExt);
	} while(IsFileExist(RenName));	

	if(CopyFileEx(	lpExistingFileName,
					RenName,//lpNewFileName,
					lpProgressRoutine,
					lpData,
					pbCancel,
					dwCopyFlags|COPY_FILE_FAIL_IF_EXISTS))
		return TRUE;
	/*DWORD e = GetLastError();
	if(ERROR_REQUEST_ABORTED==e)
		return FALSE;

	Err::msgC2(e,"CopyFileEx:",lpExistingFileName,lpNewFileName);*/
	return FALSE; 
	//Administartor levelini so'raymiz:
}

BOOL WINAPI MyCopyOverwriteOldestFileEx(__in  LPWSTR lpExistingFileName,
										__in  LPWSTR lpNewFileName,
										__in  LPPROGRESS_ROUTINE lpProgressRoutine,
										__in  LPVOID lpData,
										__in  LPBOOL pbCancel,
										__in  DWORD dwCopyFlags)
{
WIN32_FIND_DATA ff[2];unsigned __int64 f0,f1;HANDLE hnew,
	hexst=FindFirstFile(lpExistingFileName,&ff[0]);
	if(INVALID_HANDLE_VALUE==hexst)
	{	/*DWORD e = GetLastError();
		if(ERROR_REQUEST_ABORTED==e)return FALSE;
		Err::msg1(e,L"File is not founded:",lpExistingFileName);*/
		return FALSE; 
	}
	FindClose(hexst);
	hnew=FindFirstFile(lpNewFileName,&ff[1]);
	if(INVALID_HANDLE_VALUE!=hnew)
	{	FindClose(hnew);
		f0=((unsigned __int64)ff[0].ftLastWriteTime.dwHighDateTime<<32) &
							 (unsigned __int64)ff[0].ftLastWriteTime.dwLowDateTime;
		f1=((unsigned __int64)ff[1].ftLastWriteTime.dwHighDateTime<<32) &
							 (unsigned __int64)ff[1].ftLastWriteTime.dwLowDateTime;
		if(f0<f1)return TRUE;
	}

	if(CopyFileEx(	lpExistingFileName,
					lpNewFileName,
					lpProgressRoutine,
					lpData,
					pbCancel,
					dwCopyFlags))
		return TRUE;
	/*DWORD e = GetLastError();
	if(ERROR_REQUEST_ABORTED==e)
		return FALSE;

	Err::msgC2(e,L"CopyFileEx:",lpExistingFileName,lpNewFileName);*/
	return FALSE; 
	//Administartor levelini so'raymiz:
}

BOOL WINAPI MyCopyOverwriteLatestFileEx(__in  LPWSTR lpExistingFileName,
										__in  LPWSTR lpNewFileName,
										__in  LPPROGRESS_ROUTINE lpProgressRoutine,
										__in  LPVOID lpData,
										__in  LPBOOL pbCancel,
										__in  DWORD dwCopyFlags)
{
WIN32_FIND_DATA ff[2];unsigned __int64 f0,f1;
	HANDLE hnew,hexst=FindFirstFile(lpExistingFileName,&ff[0]);
	if(INVALID_HANDLE_VALUE==hexst)
	{	/*DWORD e = GetLastError();
		if(ERROR_REQUEST_ABORTED==e)return FALSE;
		Err::msg1(e,"File is not founded:",lpExistingFileName);*/
		return FALSE; 
	}
	FindClose(hexst);
	hnew=FindFirstFile(lpNewFileName,&ff[1]);
	if(INVALID_HANDLE_VALUE!=hnew)
	{	FindClose(hnew);
		f0=((unsigned __int64)ff[0].ftLastWriteTime.dwHighDateTime<<32) &
							 (unsigned __int64)ff[0].ftLastWriteTime.dwLowDateTime;
		f1=((unsigned __int64)ff[1].ftLastWriteTime.dwHighDateTime<<32) &
							 (unsigned __int64)ff[1].ftLastWriteTime.dwLowDateTime;
		if(f0>f1)return TRUE;
	}

	if(CopyFileEx(	lpExistingFileName,
					lpNewFileName,
					lpProgressRoutine,
					lpData,
					pbCancel,
					dwCopyFlags))
		return TRUE;
	/*DWORD e = GetLastError();
	if(ERROR_REQUEST_ABORTED==e)
		return FALSE;

	Err::msgC2(e,L"CopyFileEx:",lpExistingFileName,lpNewFileName);*/
	return FALSE; 
	//Administartor levelini so'raymiz:
}

BOOL WINAPI MyCopyOverwriteBigestFileEx(__in  LPCWSTR lpExistingFileName,
										__in  LPCWSTR lpNewFileName,
										__in  LPPROGRESS_ROUTINE lpProgressRoutine,
										__in  LPVOID lpData,
										__in  LPBOOL pbCancel,
										__in  DWORD dwCopyFlags)
{
WIN32_FIND_DATA ff[2];unsigned __int64 f0,f1;
	HANDLE hnew,hexst=FindFirstFile(lpExistingFileName,&ff[0]);
	if(INVALID_HANDLE_VALUE==hexst)
	{	/*DWORD e = GetLastError();
		if(ERROR_REQUEST_ABORTED==e)return FALSE;
		Err::msg1(e,L"File is not founded:",lpExistingFileName);*/
		return FALSE; 
	}
	FindClose(hexst);
	hnew=FindFirstFile(lpNewFileName,&ff[1]);
	if(INVALID_HANDLE_VALUE!=hnew)
	{	FindClose(hnew);
		f0=((unsigned __int64)ff[0].nFileSizeHigh<<32) &
							 (unsigned __int64)ff[0].nFileSizeLow;
		f1=((unsigned __int64)ff[1].nFileSizeHigh<<32) &
							 (unsigned __int64)ff[1].nFileSizeLow;
		if(f0>f1)return TRUE;
	}

	if(CopyFileEx(	lpExistingFileName,
					lpNewFileName,
					lpProgressRoutine,
					lpData,
					pbCancel,
					dwCopyFlags))
		return TRUE;
	/*DWORD e = GetLastError();
	if(ERROR_REQUEST_ABORTED==e)
		return FALSE;

	Err::msgC2(e,L"CopyFileEx:",lpExistingFileName,lpNewFileName);*/
	return FALSE; 
	//Administartor levelini so'raymiz:
}

BOOL WINAPI MyCopyOverwriteLittlestFileEx(__in  LPWSTR lpExistingFileName,
										  __in  LPWSTR lpNewFileName,
										  __in  LPPROGRESS_ROUTINE lpProgressRoutine,
										  __in  LPVOID lpData,
										  __in  LPBOOL pbCancel,
										  __in  DWORD dwCopyFlags)
{
WIN32_FIND_DATA ff[2];unsigned __int64 f0,f1;
	HANDLE hnew,hexst=FindFirstFile(lpExistingFileName,&ff[0]);
	if(INVALID_HANDLE_VALUE==hexst)
	{	/*DWORD e = GetLastError();
		if(ERROR_REQUEST_ABORTED==e)return FALSE;
		Err::msg1(e,L"File is not founded:",lpExistingFileName);*/
		return FALSE; 
	}
	FindClose(hexst);
	hnew=FindFirstFile(lpNewFileName,&ff[1]);
	if(INVALID_HANDLE_VALUE!=hnew)
	{	FindClose(hnew);
		f0=((unsigned __int64)ff[0].nFileSizeHigh<<32) &
							 (unsigned __int64)ff[0].nFileSizeLow;
		f1=((unsigned __int64)ff[1].nFileSizeHigh<<32) &
							 (unsigned __int64)ff[1].nFileSizeLow;
		if(f0<f1)return TRUE;
	}

	if(CopyFileEx(	lpExistingFileName,
					lpNewFileName,
					lpProgressRoutine,
					lpData,
					pbCancel,
					dwCopyFlags))
		return TRUE;
	/*DWORD e = GetLastError();
	if(ERROR_REQUEST_ABORTED==e)
		return FALSE;

	Err::msgC2(e,L"CopyFileEx:",lpExistingFileName,lpNewFileName);*/
	return FALSE; 
	//Administartor levelini so'raymiz:
}

/*BOOL WINAPI MyCreateDirectoryA(__in LPCSTR lpPathName,
							   __in LPSECURITY_ATTRIBUTES lpSecurityAttributes)
{
	if(CreateDirectoryA(lpPathName, lpSecurityAttributes))
		return TRUE;
	DWORD e = GetLastError();
	if(ERROR_ALREADY_EXISTS==e)
		return TRUE;
	return FALSE;
}*/

BOOL WINAPI MyCreateDirectory(__in LPWSTR lpPathName,
							  __in LPSECURITY_ATTRIBUTES lpSecurityAttributes)
{
DWORD e;
	if(CreateDirectory(lpPathName, lpSecurityAttributes))
		return TRUE;
	e = GetLastError();
	if(ERROR_ALREADY_EXISTS==e)
		return TRUE;
	return FALSE;
}

/*BOOL WINAPI MyDeleteFileA(__in LPCSTR lpFileName)
{
	if(DeleteFileA(lpFileName))
		return TRUE;
	return FALSE;
}*/

BOOL WINAPI MyDeleteFile(__in LPCWSTR lpFileName)
{
	if(DeleteFile(lpFileName))
		return TRUE;
	return FALSE;
}

/*BOOL WINAPI MyMoveFileA(__in  LPCSTR lpExistingFileName,
						__in  LPCSTR lpNewFileName)
{
	if(MoveFileA(lpExistingFileName,lpNewFileName))
		return TRUE;
	return FALSE;
}*/

BOOL WINAPI MyMoveFile(__in  LPCWSTR lpExistingFileName,
					   __in  LPCWSTR lpNewFileName)
{
	if(MoveFile(lpExistingFileName,lpNewFileName))
		return TRUE;
	return FALSE;
}

/*BOOL WINAPI MyMoveFileWithProgressA(__in  LPCSTR lpExistingFileName,
									__in  LPCSTR lpNewFileName,
									__in  LPPROGRESS_ROUTINE lpProgressRoutine,
									__in  LPVOID lpData,
									__in  DWORD dwFlags)
{
	if(MoveFileWithProgressA(lpExistingFileName,
							 lpNewFileName,
							 lpProgressRoutine,
							 lpData,
							 dwFlags))
		return TRUE;
	return FALSE;
}*/

BOOL WINAPI MyMoveFileWithProgress(__in  LPCWSTR lpExistingFileName,
								   __in  LPCWSTR lpNewFileName,
								   __in  LPPROGRESS_ROUTINE lpProgressRoutine,
								   __in  LPVOID lpData,
								   __in  DWORD dwFlags)
{
	if(MoveFileWithProgress(lpExistingFileName,
							lpNewFileName,
							lpProgressRoutine,
							lpData,
							dwFlags))
		return TRUE;
	return FALSE;
}

/*BOOL WINAPI MyMoveRenameFileWithProgressA(__in  LPCSTR lpExistingFileName,
										  __in  LPCSTR lpNewFileName,
										  __in  LPPROGRESS_ROUTINE lpProgressRoutine,
										  __in  LPVOID lpData,
										  __in  DWORD dwFlags)
{
char RenName[MAX_PATH];
	char* pExt = (char*)strrchr(lpNewFileName,'.');
	if(pExt) memcpy(RenName,lpNewFileName,sizeof(char)*(((char*)pExt) - ((char*)lpNewFileName)));
	else MyStringCpyA(RenName,MAX_PATH-1,(char*)lpNewFileName);
char sAdd[32];
	int iMyCopyRenameFileEx=0;
	do
	{	++iMyCopyRenameFileEx;
		StringCchPrintfA(sAdd,32,"_%d",iMyCopyRenameFileEx);
		MyStringCatA(RenName,MAX_PATH-1,sAdd);
		if(pExt)
			MyStringCatA(RenName,MAX_PATH-1,pExt);
	} while(IsFileExistA(RenName));	

	if(MoveFileWithProgressA(lpExistingFileName,
							 RenName,//lpNewFileName,
							 lpProgressRoutine,
							 lpData,
							 dwFlags))
		return TRUE;
	return FALSE;
}*/

BOOL WINAPI MyMoveRenameFileWithProgress(__in  LPCWSTR lpExistingFileName,
										  __in  LPCWSTR lpNewFileName,
										  __in  LPPROGRESS_ROUTINE lpProgressRoutine,
										  __in  LPVOID lpData,
										  __in  DWORD dwFlags)
{
	int iMyCopyRenameFileEx=0;
wchar_t RenName[MAX_PATH],sAdd[32];
	wchar_t* pExt = (wchar_t*)wcsrchr(lpNewFileName,'.');
	if(pExt) memcpy(RenName,lpNewFileName,sizeof(wchar_t)*(((wchar_t*)pExt) - ((wchar_t*)lpNewFileName)));
	else MyStringCpy(RenName,MAX_PATH-1,(wchar_t*)lpNewFileName);
	do
	{	++iMyCopyRenameFileEx;
		StringCchPrintf(sAdd,32,L"_%d",iMyCopyRenameFileEx);
		MyStringCat(RenName,MAX_PATH-1,sAdd);
		if(pExt)
			MyStringCat(RenName,MAX_PATH-1,pExt);
	} while(IsFileExist(RenName));	

	if(MoveFileWithProgress(lpExistingFileName,
							 RenName,//lpNewFileName,
							 lpProgressRoutine,
							 lpData,
							 dwFlags))
		return TRUE;
	return FALSE;
}

/*BOOL WINAPI MyMoveOverwriteOldestFileWithProgressA(
									__in  LPCSTR lpExistingFileName,
									__in  LPCSTR lpNewFileName,
									__in  LPPROGRESS_ROUTINE lpProgressRoutine,
									__in  LPVOID lpData,
									__in  DWORD dwFlags)
{
WIN32_FIND_DATAA ff[2];
	HANDLE hexst=FindFirstFileA(lpExistingFileName,&ff[0]);
	if(INVALID_HANDLE_VALUE==hexst)
	{	return FALSE; 
	}
	FindClose(hexst);
	HANDLE hnew=FindFirstFileA(lpNewFileName,&ff[1]);
	if(INVALID_HANDLE_VALUE!=hnew)
	{	FindClose(hnew);
		unsigned __int64 f0=((unsigned __int64)ff[0].ftLastWriteTime.dwHighDateTime<<32) &
							 (unsigned __int64)ff[0].ftLastWriteTime.dwLowDateTime;
		unsigned __int64 f1=((unsigned __int64)ff[1].ftLastWriteTime.dwHighDateTime<<32) &
							 (unsigned __int64)ff[1].ftLastWriteTime.dwLowDateTime;
		if(f0<f1)return TRUE;
	}

	if(MoveFileWithProgressA(lpExistingFileName,
							 lpNewFileName,
							 lpProgressRoutine,
							 lpData,
							 dwFlags))
		return TRUE;
	return FALSE;
}*/

BOOL WINAPI MyMoveOverwriteOldestFileWithProgress(
									__in  LPCWSTR lpExistingFileName,
									__in  LPCWSTR lpNewFileName,
									__in  LPPROGRESS_ROUTINE lpProgressRoutine,
									__in  LPVOID lpData,
									__in  DWORD dwFlags)
{
WIN32_FIND_DATAW ff[2];unsigned __int64 f0,f1;
	HANDLE hnew,hexst=FindFirstFile(lpExistingFileName,&ff[0]);
	if(INVALID_HANDLE_VALUE==hexst)
	{	return FALSE; 
	}
	FindClose(hexst);
	hnew=FindFirstFile(lpNewFileName,&ff[1]);
	if(INVALID_HANDLE_VALUE!=hnew)
	{	FindClose(hnew);
		f0=((unsigned __int64)ff[0].ftLastWriteTime.dwHighDateTime<<32) &
							 (unsigned __int64)ff[0].ftLastWriteTime.dwLowDateTime;
		f1=((unsigned __int64)ff[1].ftLastWriteTime.dwHighDateTime<<32) &
							 (unsigned __int64)ff[1].ftLastWriteTime.dwLowDateTime;
		if(f0<f1)return TRUE;
	}

	if(MoveFileWithProgress(lpExistingFileName,
							 lpNewFileName,
							 lpProgressRoutine,
							 lpData,
							 dwFlags))
		return TRUE;
	return FALSE;
}

/*BOOL WINAPI MyMoveOverwriteLatestFileWithProgressA(
									__in  LPCSTR lpExistingFileName,
									__in  LPCSTR lpNewFileName,
									__in  LPPROGRESS_ROUTINE lpProgressRoutine,
									__in  LPVOID lpData,
									__in  DWORD dwFlags)
{
WIN32_FIND_DATAA ff[2];
	HANDLE hexst=FindFirstFileA(lpExistingFileName,&ff[0]);
	if(INVALID_HANDLE_VALUE==hexst)
	{	return FALSE; 
	}
	FindClose(hexst);
	HANDLE hnew=FindFirstFileA(lpNewFileName,&ff[1]);
	if(INVALID_HANDLE_VALUE!=hnew)
	{	FindClose(hnew);
		unsigned __int64 f0=((unsigned __int64)ff[0].ftLastWriteTime.dwHighDateTime<<32) &
							 (unsigned __int64)ff[0].ftLastWriteTime.dwLowDateTime;
		unsigned __int64 f1=((unsigned __int64)ff[1].ftLastWriteTime.dwHighDateTime<<32) &
							 (unsigned __int64)ff[1].ftLastWriteTime.dwLowDateTime;
		if(f0>f1)return TRUE;
	}

	if(MoveFileWithProgressA(lpExistingFileName,
							 lpNewFileName,
							 lpProgressRoutine,
							 lpData,
							 dwFlags))
		return TRUE;
	return FALSE;
}*/

BOOL WINAPI MyMoveOverwriteLatestFileWithProgress(
									__in  LPCWSTR lpExistingFileName,
									__in  LPCWSTR lpNewFileName,
									__in  LPPROGRESS_ROUTINE lpProgressRoutine,
									__in  LPVOID lpData,
									__in  DWORD dwFlags)
{
WIN32_FIND_DATAW ff[2];unsigned __int64 f0,f1;
	HANDLE hnew,hexst=FindFirstFile(lpExistingFileName,&ff[0]);
	if(INVALID_HANDLE_VALUE==hexst)
	{	return FALSE; 
	}
	FindClose(hexst);
	hnew=FindFirstFile(lpNewFileName,&ff[1]);
	if(INVALID_HANDLE_VALUE!=hnew)
	{	FindClose(hnew);
		f0=((unsigned __int64)ff[0].ftLastWriteTime.dwHighDateTime<<32) &
							 (unsigned __int64)ff[0].ftLastWriteTime.dwLowDateTime;
		f1=((unsigned __int64)ff[1].ftLastWriteTime.dwHighDateTime<<32) &
							 (unsigned __int64)ff[1].ftLastWriteTime.dwLowDateTime;
		if(f0>f1)return TRUE;
	}

	if(MoveFileWithProgress(lpExistingFileName,
							 lpNewFileName,
							 lpProgressRoutine,
							 lpData,
							 dwFlags))
		return TRUE;
	return FALSE;
}

/*BOOL WINAPI MyMoveOverwriteBigestFileWithProgressA(
									__in  LPCSTR lpExistingFileName,
									__in  LPCSTR lpNewFileName,
									__in  LPPROGRESS_ROUTINE lpProgressRoutine,
									__in  LPVOID lpData,
									__in  DWORD dwFlags)
{
WIN32_FIND_DATAA ff[2];
	HANDLE hexst=FindFirstFileA(lpExistingFileName,&ff[0]);
	if(INVALID_HANDLE_VALUE==hexst)
	{	return FALSE; 
	}
	FindClose(hexst);
	HANDLE hnew=FindFirstFileA(lpNewFileName,&ff[1]);
	if(INVALID_HANDLE_VALUE!=hnew)
	{	FindClose(hnew);
		unsigned __int64 f0=((unsigned __int64)ff[0].nFileSizeHigh<<32) &
							 (unsigned __int64)ff[0].nFileSizeLow;
		unsigned __int64 f1=((unsigned __int64)ff[1].nFileSizeHigh<<32) &
							 (unsigned __int64)ff[1].nFileSizeLow;
		if(f0>f1)return TRUE;
	}

	if(MoveFileWithProgressA(lpExistingFileName,
							 lpNewFileName,
							 lpProgressRoutine,
							 lpData,
							 dwFlags))
		return TRUE;
	return FALSE;
}*/

BOOL WINAPI MyMoveOverwriteBigestFileWithProgress(
									__in  LPCWSTR lpExistingFileName,
									__in  LPCWSTR lpNewFileName,
									__in  LPPROGRESS_ROUTINE lpProgressRoutine,
									__in  LPVOID lpData,
									__in  DWORD dwFlags)
{
WIN32_FIND_DATAW ff[2];unsigned __int64 f0,f1;
	HANDLE hnew,hexst=FindFirstFile(lpExistingFileName,&ff[0]);
	if(INVALID_HANDLE_VALUE==hexst)
	{	return FALSE; 
	}
	FindClose(hexst);
	hnew=FindFirstFile(lpNewFileName,&ff[1]);
	if(INVALID_HANDLE_VALUE!=hnew)
	{	FindClose(hnew);
		f0=((unsigned __int64)ff[0].nFileSizeHigh<<32) &
							 (unsigned __int64)ff[0].nFileSizeLow;
		f1=((unsigned __int64)ff[1].nFileSizeHigh<<32) &
							 (unsigned __int64)ff[1].nFileSizeLow;
		if(f0>f1)return TRUE;
	}

	if(MoveFileWithProgress(lpExistingFileName,
							 lpNewFileName,
							 lpProgressRoutine,
							 lpData,
							 dwFlags))
		return TRUE;
	return FALSE;
}

/*BOOL WINAPI MyMoveOverwriteLittlestFileWithProgressA(
									__in  LPCSTR lpExistingFileName,
									__in  LPCSTR lpNewFileName,
									__in  LPPROGRESS_ROUTINE lpProgressRoutine,
									__in  LPVOID lpData,
									__in  DWORD dwFlags)
{
WIN32_FIND_DATAA ff[2];
	HANDLE hexst=FindFirstFileA(lpExistingFileName,&ff[0]);
	if(INVALID_HANDLE_VALUE==hexst)
	{	return FALSE; 
	}
	FindClose(hexst);
	HANDLE hnew=FindFirstFileA(lpNewFileName,&ff[1]);
	if(INVALID_HANDLE_VALUE!=hnew)
	{	FindClose(hnew);
		unsigned __int64 f0=((unsigned __int64)ff[0].nFileSizeHigh<<32) &
							 (unsigned __int64)ff[0].nFileSizeLow;
		unsigned __int64 f1=((unsigned __int64)ff[1].nFileSizeHigh<<32) &
							 (unsigned __int64)ff[1].nFileSizeLow;
		if(f0<f1)return TRUE;
	}

	if(MoveFileWithProgressA(lpExistingFileName,
							 lpNewFileName,
							 lpProgressRoutine,
							 lpData,
							 dwFlags))
		return TRUE;
	return FALSE;
}*/

BOOL WINAPI MyMoveOverwriteLittlestFileWithProgress(
									__in  LPCWSTR lpExistingFileName,
									__in  LPCWSTR lpNewFileName,
									__in  LPPROGRESS_ROUTINE lpProgressRoutine,
									__in  LPVOID lpData,
									__in  DWORD dwFlags)
{
WIN32_FIND_DATAW ff[2];unsigned __int64 f0,f1;
	HANDLE hnew,hexst=FindFirstFile(lpExistingFileName,&ff[0]);
	if(INVALID_HANDLE_VALUE==hexst)
	{	return FALSE; 
	}
	FindClose(hexst);
	hnew=FindFirstFile(lpNewFileName,&ff[1]);
	if(INVALID_HANDLE_VALUE!=hnew)
	{	FindClose(hnew);
		f0=((unsigned __int64)ff[0].nFileSizeHigh<<32) &
							 (unsigned __int64)ff[0].nFileSizeLow;
		f1=((unsigned __int64)ff[1].nFileSizeHigh<<32) &
							 (unsigned __int64)ff[1].nFileSizeLow;
		if(f0<f1)return TRUE;
	}

	if(MoveFileWithProgress(lpExistingFileName,
							 lpNewFileName,
							 lpProgressRoutine,
							 lpData,
							 dwFlags))
		return TRUE;
	return FALSE;
}

BOOL MySHFileOperation(UINT Func,LPWSTR From,LPCWSTR To,FILEOP_FLAGS Flags, BOOL bApndEscape)
{
size_t l;
SHFILEOPSTRUCT fo; fo.hwnd = hWnd;
	fo.wFunc = Func;
	l = MyStringLength(From,MAX_PATH);//StringCchLength(From,MAX_PATH-1,&l);
	if(bApndEscape)
	{	From[l] = '\\';
		From[l+1] = 0;
		From[l+2] = 0;
	}
	else
	{	From[l] = 0;
		From[l+1] = 0;
	}
	fo.pFrom = From;
	fo.pTo = To;
	fo.fFlags = Flags;
	if(!SHFileOperation(&fo))
		return TRUE;
	//error o'ziniki bor;
/*	DWORD e = GetLastError();

	switch(e)
	{	case 0x71://DE_SAMEFILE:
		case 0x72://DE_MANYSRC1DEST:
		case 0x73://DE_DIFFDIR 0x73:
		case 0x74://DE_ROOTDIR 0x74:
		case 0x75://DE_OPCANCELLED:
		case 0x76://DE_DESTSUBTREE:
		case 0x78://DE_ACCESSDENIEDSRC:
		case 0x79://DE_PATHTOODEEP:
		case 0x7a://DE_MANYDEST:
		case 0x7c://DE_INVALIDFILES:
		case 0x7d://DE_DESTSAMETREE:
		case 0x7e://DE_FLDDESTISFILE:
		case 0x80://DE_FILEDESTISFLD:
		case 0x81://DE_FILENAMETOOLONG:
		case 0x82://DE_DEST_IS_CDROM:
		case 0x83://DE_DEST_IS_DVD:
		case 0x84://DE_DEST_IS_CDRECORD:
		case 0x85://DE_FILE_TOO_LARGE:
		case 0x86://DE_SRC_IS_CDROM:
		case 0x87://DE_SRC_IS_DVD:
		case 0x88://DE_SRC_IS_CDRECORD:
		case 0xb7://DE_ERROR_MAX:
		case 0x402://UNKNOWN
		case 0x10000://ERRORONDEST:
		case 0x10074://DE_ROOTDIR | ERRORONDEST:
			ErrMsgC2(e,"SHFileOperation:",From,To);
			break;
		default:
			ErrMsgC2(e,"SHFileOperation:",From,To);
			break;
	}*/
	return FALSE;
}

BOOL MyDeleteTryUnicode(HWND prnt,CpyStack* stck)
{
WIN32_FIND_DATAW ff;HANDLE h;wchar_t *p=wcsrchr(stck->FullPathAndName,'\\');
wchar_t s[MAX_PATH];int l=0;if(!p) return FALSE;
	l=MyStringCpy(s,MAX_PATH-1,stck->FullPathAndName);
	if(l)--l;
	s[l++]='\\';s[l++]='*';s[l]=0;
	h=MyFindFirstFileEx(s,FindExInfoStandard,&ff,FindExSearchLimitToDirectories,NULL,FIND_FIRST_EX_CASE_SENSITIVE);
	if(INVALID_HANDLE_VALUE==h) return FALSE;

	while(FindNextFile(h, &ff))
	{	if(!(FILE_ATTRIBUTE_DIRECTORY & ff.dwFileAttributes))
		{	if((stck->size & 0xffffffff) == ff.nFileSizeLow)
			{	if((stck->size & 0xffffffff00000000) >> 32 == ff.nFileSizeHigh)
				{	int l=MyStringLength(ff.cFileName,MAX_PATH);
					if(l==MyStringLength(p+1,MAX_PATH))
					{	MyStringCpy(&s[l+1],MAX_PATH-l,ff.cFileName);
						if(IDYES==MessageBox(prnt,s,L"Delete this file:",MB_YESNO))
						{	MySHFileOperation(FO_DELETE,s,NULL,
									FOF_SILENT|FOF_NOCONFIRMATION|FOF_NOCONFIRMMKDIR,FALSE);
							break;
	}	}	}	}	}	}
	FindClose(h);
	return TRUE;
}

/*BOOL MySetCurrentDirectoryA(char *st)
{
	if(st && st[0])
	{	char s[MAX_PATH];
		MyStringCpyA(s,MAX_PATH-1,st);
		int l = MyStringLengthA(s,MAX_PATH);
		if('\\'==s[l-2] && '*'==s[l-1])
			s[l-1]=0;
		else if('\\' != s[l-1])
		{	s[l-1] = '\\';
			s[l] = 0;
		}
		return SetCurrentDirectoryA(s);
	}
	return FALSE;
}*/

BOOL MySetCurrentDirectory(wchar_t* wst)
{
	if(wst && wst[0])
	{	wchar_t ws[MAX_PATH];
		MyStringCpy(ws,MAX_PATH-1,wst);
		int l = MyStringLength(ws,MAX_PATH);
		if('\\'==ws[l-2] && '*'==ws[l-1])
			ws[l-1]=0;
		else if('\\' != ws[l-1])
		{	ws[l-1] = '\\';
			ws[l] = 0;
		}
		return SetCurrentDirectory(ws);
	}
	return FALSE;
}



}