// SimpleStream.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "windows.h"
#include <locale.h>
//#include "strsafe.h"
//#include "Winsock2.h"

//void ErrorExit(LPTSTR);
BOOL WINAPI EnumerateFunc(HWND,HDC,LPNETRESOURCE,int type=RESOURCE_CONNECTED);
VOID NetErrorHandler(HWND,int,char*);
VOID DisplayStruct(HDC,NETRESOURCE*);

int _tmain(int argc, _TCHAR* argv[])
{
/*	HANDLE h = CreateFile("E:\\Temp\\����� 2012 �������.xlsx",GENERIC_READ,
							FILE_SHARE_READ,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_READONLY,NULL);
	if(INVALID_HANDLE_VALUE==h) ErrorExit("CreateFile");

	char str[1024];
	if(GetFileInformationByHandleEx(h,FileStreamInfo,&str,1024))
	{	FILE_STREAM_INFO *ps = (FILE_STREAM_INFO*)str;
		printf("\nNextEntryOffset: %d",ps->NextEntryOffset);
		printf("\nStreamNameLength : %d",ps->StreamNameLength);
		printf("\nStreamSize : %d",ps->StreamSize);
		printf("\nStreamAllocationSize : %d",ps->StreamAllocationSize);
		wprintf(L"\nStreamName : ");
		for(DWORD j=0; j<ps->StreamNameLength; j++)
			wprintf(L"%c",ps->StreamName[j]);
	}

	char buf[32];DWORD nr;int k=0;
	for(;;)
	{
		if(!ReadFile(h,buf,32,&nr,NULL))
			break;
		if(!nr)
			break;
		printf("\n%x",buf[0]);
		for(DWORD i=1; i<nr; i++)
			printf("%x",buf[i]);
		if(k++==25)
		{k=0;
		getchar();
	}	}
	getchar();
	CloseHandle(h);*/
/*
	int iResult;WSADATA wsaData;

	iResult = WSAStartup(MAKEWORD(2,2), &wsaData);
	if (iResult != 0)
	{	printf("WSAStartup failed: %d\n", iResult);
		return 1;
	}
*/

/*	DWORD di=sizeof(WSANAMESPACE_INFO);WSANAMESPACE_INFO np;
	iResult = WSAEnumNameSpaceProviders(&di,&np);
	if(-1==iResult)
	{	iResult = WSAGetLastError();
	}*/

/*	DWORD di=sizeof(WSAPROTOCOL_INFO);int k=1;
	WSAPROTOCOL_INFO *pi = (WSAPROTOCOL_INFO*)malloc(di);
L:
	iResult = WSAEnumProtocols(NULL,pi,&di);
	if(SOCKET_ERROR==iResult)
	{	iResult = WSAGetLastError();
		if(WSAENOBUFS==iResult)
		{	di = ++k*sizeof(WSAPROTOCOL_INFO);
			pi = (WSAPROTOCOL_INFO*)realloc(pi,di);
			goto L;
		}
		else
			return iResult;//in class
	}*/

	_wsetlocale( LC_ALL, L"Russian" );
	EnumerateFunc(NULL, NULL, NULL, RESOURCE_CONNECTED);
	EnumerateFunc(NULL, NULL, NULL, RESOURCE_REMEMBERED);
	EnumerateFunc(NULL, NULL, NULL, RESOURCE_GLOBALNET);


//	WSACleanup();
	getchar();
	return 0;
}

/*void ErrorExit(LPTSTR lpszFunction)
{ 
    // Retrieve the system error message for the last-error code

    LPVOID lpMsgBuf;
    LPVOID lpDisplayBuf;
    DWORD dw = GetLastError(); 

    FormatMessage(
        FORMAT_MESSAGE_ALLOCATE_BUFFER | 
        FORMAT_MESSAGE_FROM_SYSTEM |
        FORMAT_MESSAGE_IGNORE_INSERTS,
        NULL,
        dw,
        MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
        (LPTSTR) &lpMsgBuf,
        0, NULL );

    // Display the error message and exit the process

    lpDisplayBuf = (LPVOID)LocalAlloc(LMEM_ZEROINIT, 
        (lstrlen((LPCTSTR)lpMsgBuf)+lstrlen((LPCTSTR)lpszFunction)+40)*sizeof(TCHAR)); 
    StringCchPrintf((LPTSTR)lpDisplayBuf, 
        LocalSize(lpDisplayBuf),
        TEXT("%s failed with error %d: %s"), 
        lpszFunction, dw, lpMsgBuf); 
    MessageBox(NULL, (LPCTSTR)lpDisplayBuf, TEXT("Error"), MB_OK); 

    LocalFree(lpMsgBuf);
    LocalFree(lpDisplayBuf);
    ExitProcess(dw); 
}*/

BOOL WINAPI EnumerateFunc(HWND hwnd, HDC hdc, LPNETRESOURCE lpnr,int type)
{ 
DWORD dwResult, dwResultEnum;
HANDLE hEnum;
DWORD cbBuffer = 16384;      // 16K is a good size
DWORD cEntries = -1;         // enumerate all possible entries
LPNETRESOURCE lpnrLocal;     // pointer to enumerated structures
DWORD i;
  //
  // Call the WNetOpenEnum function to begin the enumeration.
  //
  dwResult = WNetOpenEnum(type,				// all network resources
                          RESOURCETYPE_ANY, // all resources
                          0,        // enumerate all resources
                          lpnr,     // NULL first time the function is called
                          &hEnum);  // handle to the resource

  if (dwResult != NO_ERROR)
  {  
    //
    // Process errors with an application-defined error handler.
    //
    NetErrorHandler(hwnd, dwResult, (LPSTR)"WNetOpenEnum");
    return FALSE;
  }
  //
  // Call the GlobalAlloc function to allocate resources.
  //
  lpnrLocal = (LPNETRESOURCE) GlobalAlloc(GPTR, cbBuffer);
  if (lpnrLocal == NULL) 
      return FALSE;
  
  do
  {  
    //
    // Initialize the buffer.
    //
    ZeroMemory(lpnrLocal, cbBuffer);
    //
    // Call the WNetEnumResource function to continue
    //  the enumeration.
    //
    dwResultEnum = WNetEnumResource(hEnum,      // resource handle
                                    &cEntries,  // defined locally as -1
                                    lpnrLocal,  // LPNETRESOURCE
                                    &cbBuffer); // buffer size
    //
    // If the call succeeds, loop through the structures.
    //
    if (dwResultEnum == NO_ERROR)
    {
      for(i = 0; i < cEntries; i++)
      {
        // Call an application-defined function to
        //  display the contents of the NETRESOURCE structures.
        //
        DisplayStruct(hdc, &lpnrLocal[i]);

        // If the NETRESOURCE structure represents a container resource, 
        //  call the EnumerateFunc function recursively.

        if(RESOURCEUSAGE_CONTAINER == (lpnrLocal[i].dwUsage
                                       & RESOURCEUSAGE_CONTAINER))
          if(!EnumerateFunc(hwnd, hdc, &lpnrLocal[i], type))
            TextOutA(hdc, 10, 10, "EnumerateFunc returned FALSE.", 29);


		char prntRes[1024]; DWORD di=1024;NETRESOURCE* p = (NETRESOURCE*)prntRes;
		char chldRes[1024]; memcpy(chldRes,&lpnrLocal[i],sizeof(NETRESOURCE));
Parent:
		dwResultEnum = WNetGetResourceParent((LPNETRESOURCEW)chldRes,p,&di);
		if(NO_ERROR==dwResultEnum)
		{	if(p->lpRemoteName)
			{	DisplayStruct(hdc, (NETRESOURCE*)prntRes);
				memcpy(chldRes,prntRes,1024);
				goto Parent;
		}	}
		else
			NetErrorHandler(hwnd, dwResultEnum, (LPSTR)"WNetGetResourceParent");
      }
    }
    // Process errors.
    //
    else if (dwResultEnum != ERROR_NO_MORE_ITEMS)
    {
      NetErrorHandler(hwnd, dwResultEnum, (LPSTR)"WNetEnumResource");
      break;
    }
  }
  //
  // End do.
  //
  while(dwResultEnum != ERROR_NO_MORE_ITEMS);
  //
  // Call the GlobalFree function to free the memory.
  //
  GlobalFree((HGLOBAL)lpnrLocal);
  //
  // Call WNetCloseEnum to end the enumeration.
  //
  dwResult = WNetCloseEnum(hEnum);
  
  if(dwResult != NO_ERROR)
  { 
    //
    // Process errors.
    //
    NetErrorHandler(hwnd, dwResult, (LPSTR)"WNetCloseEnum");
    return FALSE;
  }

  return TRUE;
}

VOID NetErrorHandler(HWND,int result,char *str)
{
	switch(result)
	{	case ERROR_NOT_CONTAINER:
			printf("\nERROR_NOT_CONTAINER"); break;
		case ERROR_INVALID_PARAMETER:
			printf("\nERROR_INVALID_PARAMETER"); break;
		case ERROR_NO_NETWORK:
			printf("\nERROR_NO_NETWORK"); break;
		case ERROR_EXTENDED_ERROR:
			printf("\nERROR_EXTENDED_ERROR"); break;
		case ERROR_INVALID_ADDRESS:
			printf("\nERROR_INVALID_ADDRESS"); break;
}	}

VOID DisplayStruct(HDC,NETRESOURCE*nr)
{
	switch(nr->dwDisplayType)
	{	case RESOURCEDISPLAYTYPE_DOMAIN:
			wprintf(L"\nRESOURCEDISPLAYTYPE_DOMAIN"); break;
		case RESOURCEDISPLAYTYPE_SERVER:
			wprintf(L"\nRESOURCEDISPLAYTYPE_SERVER");  break;
		case RESOURCEDISPLAYTYPE_SHARE:
			wprintf(L"\nRESOURCEDISPLAYTYPE_SHARE");   break;
		case RESOURCEDISPLAYTYPE_GENERIC:
			wprintf(L"\nRESOURCEDISPLAYTYPE_GENERIC"); break;
	}
	switch(nr->dwScope)
	{	case RESOURCE_CONNECTED:
			wprintf(L" RESOURCE_CONNECTED");  break;
		case RESOURCE_GLOBALNET:
			wprintf(L" RESOURCE_GLOBALNET");  break;
		case RESOURCE_REMEMBERED:
			wprintf(L" RESOURCE_REMEMBERED"); break;
	}
	switch(nr->dwType)
	{	case RESOURCETYPE_ANY:
			wprintf(L" RESOURCETYPE_ANY"); break;
		case RESOURCETYPE_DISK:
			wprintf(L" RESOURCETYPE_DISK");  break;
		case RESOURCETYPE_PRINT:
			wprintf(L" RESOURCETYPE_PRINT");   break;
	}
	switch(nr->dwUsage)
	{	case RESOURCEUSAGE_CONNECTABLE:
			wprintf(L" RESOURCEUSAGE_CONNECTABLE"); break;
		case RESOURCEUSAGE_CONTAINER:
			wprintf(L" RESOURCEUSAGE_CONTAINER");  break;
	}
	wprintf(L"\nLocal Name: %s Remote Name: %s \n Comment: %s Provider: %s",
		nr->lpLocalName, nr->lpRemoteName, nr->lpComment, nr->lpProvider);
}

