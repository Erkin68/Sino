#include "stdio.h" 
#include "shlobj.h"
#include "strsafe.h"
#include <mbstring.h>
#include "..\Sino.h"
#include "..\Config.h"
#include "RenMoveA.h"
#include "LinkSocket.h"
#include "MyShell\MyShell.h"
#include "Backgrnd thread copy operationA.h"
#include "..\WindowsManagmentInstrumentation.h"



namespace linkSock
{

DWORD CALLBACK RMcpyPrgrssRout(	LARGE_INTEGER	TotalFileSize,
								LARGE_INTEGER	TotalBytesTransferred,
								LARGE_INTEGER	StreamSize,
								LARGE_INTEGER	StreamBytesTransferred,
								DWORD			dwStreamNumber,
								DWORD			dwCallbackReason,
								HANDLE			hSourceFile,
								HANDLE			hDestinationFile,
								LPVOID			lpData)
{
	cpyTrdDat *pdat = (cpyTrdDat*)lpData;
	__int64 tfs = ((__int64)TotalFileSize.HighPart << 32) | TotalFileSize.LowPart;
	__int64 tbt = ((__int64)TotalBytesTransferred.HighPart << 32) | TotalBytesTransferred.LowPart;
	double prgrsPos = tfs?(1000.0*tbt/tfs):1000.0;
	PostMessage(GetDlgItem(pdat->hDlg,IDC_PROGRESS_COPY_SINGLE),PBM_SETPOS,(int)prgrsPos,0);

	tbt += fRenMove::copySrcSz;
	double prgrsPosTot = tfs?(1000.0*tbt/fRenMove::srcSz):1000.0;
	PostMessage(GetDlgItem(pdat->hDlg,IDC_PROGRESS_COPY_TOTAL),PBM_SETPOS,(int)prgrsPosTot,0);

	// ***************** % calculating: ***********************
	wchar_t s[MAX_PATH];StringCchPrintf(s,MAX_PATH,L"%.2f %s",0.1f*prgrsPos,L"%");
	SetDlgItemText(pdat->hDlg,IDC_STATIC1,s);
	StringCchPrintf(s,MAX_PATH,L"%.2f %s",100.0-0.1*prgrsPos,"%");
	SetDlgItemText(pdat->hDlg,IDC_STATIC3,s);
	StringCchPrintf(s,MAX_PATH,L"%.2f %s",tfs?(100.0*tbt/fRenMove::srcSz):100.0,L"%");
	SetDlgItemText(pdat->hDlg,IDC_STATIC6,s);
	StringCchPrintf(s,MAX_PATH,L"%.2f %s",tfs?(100.0-100.0*tbt/fRenMove::srcSz):100.0,L"%");
	SetDlgItemText(pdat->hDlg,IDC_STATIC8,s);

	// ***************** tick calculating: ********************
	DWORD tick = GetTickCount() - pdat->beginTick - pdat->stopTick[0];
	MyTimeToString(s, tick);
	SetDlgItemText(pdat->hDlg,IDC_STATIC2,s);
	if(prgrsPos>0.0f)
	{	MyTimeToString(s, (int)(tick*(1000.0f-prgrsPos)/prgrsPos));
		SetDlgItemText(pdat->hDlg,IDC_STATIC4,s);
	}
	
	tick = GetTickCount() - pdat->beginTickTot - pdat->stopTickTot[0];
	MyTimeToString(s, tick);
	SetDlgItemText(pdat->hDlg,IDC_STATIC7,s);
	if(prgrsPosTot>0.0f)
	{	MyTimeToString(s, (int)(tick*(1.0f-0.001f*prgrsPosTot)/(0.001f*prgrsPosTot)));
		SetDlgItemText(pdat->hDlg,IDC_STATIC9,s);
	}
	
	if(pdat->bCancel)
		return PROGRESS_CANCEL;

	//Agar 1tagina fayl b-sa:
	MSG msg;//Only thread message:

Loop:
	//message from thread queue:
	if(PeekMessage(&msg,(HWND)-1,MYWM_CANCEL-1,MYWM_CANCEL+10,PM_REMOVE))
	{	
		//static int i=0;
		//wchar_t ss[32];sprintf(ss,"\n %d ",i++);
		//OutputDebugString(ss);
		//OutputDebugString(GetWinNotifyText(msg.message));
		
		switch(msg.message)
		{	case MYWM_CANCEL:
				return PROGRESS_CANCEL;
			case MYWM_STOP:
				if(pdat->bStop)
				{	LoadString(hInst,IDS_STRINGSW_50,s,MAX_PATH);
					SetDlgItemText(pdat->hDlg,IDC_BUTTON_STOP,s);
					pdat->stopTick[0] = GetTickCount() - pdat->stopTick[1];
					pdat->stopTickTot[0] = GetTickCount() - pdat->stopTickTot[1];
					pdat->bStop = FALSE;
				}
				else
				{	LoadString(hInst,IDS_STRINGSW_3,s,MAX_PATH);
					SetDlgItemText(pdat->hDlg,IDC_BUTTON_STOP,s);
					pdat->bStop = TRUE;
					pdat->stopTick[1] = pdat->stopTickTot[1] = GetTickCount();
					Sleep(250);
					goto Loop;
				}
				break;
 	}	}
	else if(pdat->bStop)
	{	Sleep(250);
		goto Loop;
	}

	return PROGRESS_CONTINUE;
}

VOID RMcpyFileExThrdFnc(LPVOID lpar)
{
cpyTrdDat dat; dat.hDlg = (HWND)lpar;
	dat.bStop = FALSE;
	dat.bCancel = FALSE;
	dat.bSwtchToBckgrnd = FALSE;
	dat.thrId = GetCurrentThreadId();
	dat.beginTick = dat.beginTickTot = GetTickCount();
	dat.stopTick[0] = dat.stopTickTot[0] = 0;
	enCheckCopyFilesToExisting = showEach;

 wchar_t dst[MAX_PATH],buf[MAX_PATH];
 size_t dstPathLn;

 int totFiles = 0;
 if(socketCl!=panel[fCopyOper::srcPanel].GetEntry()->GetCrntRecType())
	totFiles = fCopyOper::GetSelectedFilesCnt();
 else
	totFiles = GetSelectedFilesCnt();
 dat.stack = (CpyStack*)malloc(totFiles*sizeof(CpyStack));
 fCopyOper::GetSelectedFiles(dat.stack);
 fCopyOper::CutSelectedNames(dat.stack,panel[fCopyOper::srcPanel].GetPath(),totFiles);

 
 dstPathLn=MyStringCpy(dst,MAX_PATH,fRenMove::destPath);
 if(fRenMove::allToRenFolder==fRenMove::srcType)
 {	dst[dstPathLn++]='\\';//MyStringCat(dst,MAX_PATH,"\\");//Yangi yo'l kiritsa;
 	dst[dstPathLn]=0;
	if(socketCl==panel[fCopyOper::destPanel].GetEntry()->GetCrntRecType())
	{	if(!MyLinkSockCreateDirectory(dst))//yangi yo'lini avval yaratib olsun;
			goto End;
	}
	else//socket-source;
	{	if(!MyCreateDirectory(dst,NULL))//yangi yo'lini avval yaratib olsun;
			goto End;
 }  }
 //dstPathLn = MyStringLength(dst,MAX_PATH);
  

 for(dat.iCrntFileCopy=0; dat.iCrntFileCopy<totFiles; dat.iCrntFileCopy++)
 {
 

 if(fRenMove::unchange==fRenMove::srcType)
	MyStringCpy(&dst[dstPathLn],MAX_PATH-(int)dstPathLn,dat.stack[dat.iCrntFileCopy].Name);//MyStringCat(dst,MAX_PATH,dat.stack[dat.iCrntFileCopy].Name);
 else
 {	if(fRenMove::allToRenFolder==fRenMove::srcType)
	{	//wchar_t *p=NULL;
		//if(dat.iCrntFileCopy>0)
		//if(folder==dat.stack[dat.iCrntFileCopy].attribute)//o'zgartirsa:
		//	p = strchr(dat.stack[dat.iCrntFileCopy].Name,'\\');
		MyStringCpy(&dst[dstPathLn],MAX_PATH-(int)dstPathLn,dat.stack[dat.iCrntFileCopy].Name);//MyStringCat(dst,MAX_PATH,dat.stack[dat.iCrntFileCopy].Name);
 	}
	else if(fRenMove::rename1Folder==fRenMove::srcType)
	{	if(dat.iCrntFileCopy>0)
		{	wchar_t *p=NULL;
			if(folder==dat.stack[0].attribute)//o'zgartirsa:
				p = wcschr(dat.stack[dat.iCrntFileCopy].Name,'\\');
			MyStringCpy(&dst[dstPathLn],MAX_PATH-(int)dstPathLn,p?p:dat.stack[dat.iCrntFileCopy].Name);//MyStringCat(dst,MAX_PATH,p?p:dat.stack[dat.iCrntFileCopy].Name);
 }	}	}


 //if(dst[0]!=dat.stack[dat.iCrntFileCopy].FullPathAndName[0])	
 //Agar diski 1 xil b-masa tez bo'lmaydur:
 if(file==dat.stack[dat.iCrntFileCopy].attribute)
 { if(!wcscmp(dat.stack[dat.iCrntFileCopy].FullPathAndName,dst))
    {	LoadString(hInst,IDS_STRINGSW_51,buf,MAX_PATH);
		MessageBox(NULL,buf,L"Err.",MB_OK);
    }
    else
	{int r=fBckgrndCopyOper::CheckCopyFilesToExisting(dat.hDlg,dat.stack[dat.iCrntFileCopy].FullPathAndName,dst);
	 if(r==skipAll || r==skip)
     	goto skipOne;
	 else if(r==cancel)
     	goto End;
	 else if(r==overwrite || r==overwriteAll)
     {if(!MyMoveFileWithProgress(dat.stack[dat.iCrntFileCopy].FullPathAndName,dst,RMcpyPrgrssRout,&dat,MOVEFILE_COPY_ALLOWED))
	  {	dat.bStop = FALSE;
		goto End;
	 }}
	 else if(r==rename1 || r==renameAll)
     {if(!MyMoveRenameFileWithProgress(dat.stack[dat.iCrntFileCopy].FullPathAndName,dst,RMcpyPrgrssRout,&dat,MOVEFILE_COPY_ALLOWED))
	  {	dat.bStop = FALSE;
		goto End;
	 }}
     else if(r==overwriteOldest || r==overwriteOldestAll)
     {if(!MyMoveOverwriteOldestFileWithProgress(dat.stack[dat.iCrntFileCopy].FullPathAndName,dst,RMcpyPrgrssRout,&dat,MOVEFILE_COPY_ALLOWED))
	  {	dat.bStop = FALSE;
		goto End;
	 }}
     else if(r==overwriteLatest || r==overwriteLatestAll)
     {if(!MyMoveOverwriteLatestFileWithProgress(dat.stack[dat.iCrntFileCopy].FullPathAndName,dst,RMcpyPrgrssRout,&dat,MOVEFILE_COPY_ALLOWED))
	  {	dat.bStop = FALSE;
		goto End;
	 }}
     else if(r==overwriteBigest || r==overwriteBigestAll)
     {if(!MyMoveOverwriteBigestFileWithProgress(dat.stack[dat.iCrntFileCopy].FullPathAndName,dst,RMcpyPrgrssRout,&dat,MOVEFILE_COPY_ALLOWED))
	  {	dat.bStop = FALSE;
		goto End;
	 }}
     else if(r==overwriteLittlest || r==overwriteLittlestAll)
     {if(!MyMoveOverwriteLittlestFileWithProgress(dat.stack[dat.iCrntFileCopy].FullPathAndName,dst,RMcpyPrgrssRout,&dat,MOVEFILE_COPY_ALLOWED))
	  {	dat.bStop = FALSE;
		goto End;
    }}}
skipOne:
	fRenMove::copySrcSz += dat.stack[dat.iCrntFileCopy].size;
	fRenMove::avDstSz -= dat.stack[dat.iCrntFileCopy].size;
	PostMessage(GetDlgItem(dat.hDlg,IDC_PROGRESS_COPY_SINGLE),PBM_SETPOS,1000,0);
	PostMessage(GetDlgItem(dat.hDlg,IDC_PROGRESS_COPY_TOTAL ),PBM_SETPOS,
    (int)(fRenMove::srcSz?(1000.0f*fRenMove::copySrcSz/fRenMove::srcSz):1000.0f),0);
	dat.stopTick[0] = 0;
	dat.beginTick = GetTickCount();
 }
 else
 {	if(!MyCreateDirectory(dst,NULL))
		goto End;
 }



 dst[dstPathLn]=0;
	
Loop:
	MSG msg;//Only thread message:
	if(PeekMessage(&msg,(HWND)-1,MYWM_CANCEL-1,MYWM_CANCEL+10,PM_REMOVE))
	{	
		//static int i=0;
		//wchar_t ss[32];sprintf(ss,"\n %d ",i++);
		//OutputDebugString(ss);
		//OutputDebugString(GetWinNotifyText(msg.message));
		
		switch(msg.message)
		{	case MYWM_CANCEL:
				dat.bCancel = TRUE;
				goto End;
			case MYWM_STOP:
				wchar_t s[MAX_PATH];
				if(dat.bStop)
				{	LoadString(hInst,IDS_STRINGSW_50,s,MAX_PATH);
					SetDlgItemText(dat.hDlg,IDC_BUTTON_STOP,s);
					dat.bStop = FALSE;
				}
				else
				{	LoadString(hInst,IDS_STRINGSW_3,s,MAX_PATH);
					SetDlgItemText(dat.hDlg,IDC_BUTTON_STOP,s);
					dat.bStop = TRUE;
					Sleep(250);
					goto Loop;
				}
				break;
			/*case MYWM_GOTOBCKGRND:
				EndDialog(dat.hDlg,0);
				dat.hDlg = CreateDialog(hInst,
								MAKEINTRESOURCE(IDD_DIALOG_COPY_QUEUE),
								NULL,RMCopyBckgrndDlgProc);
				ShowWindow(dat.hDlg,SW_SHOW);
				dat.bSwtchToBckgrnd = TRUE;
				return;*/
 	}	}
	else if(dat.bStop)
	{	Sleep(250);
		goto Loop;
}	}
End:
 EndDialog(dat.hDlg,0);

 //Agar MoveFileWithProgress ni ishlatsak, delete qilishimiz kerak:
 if(fRenMove::mMoveFileWithProgress == fRenMove::copyMethod)
 {	for(dat.iCrntFileCopy=0; dat.iCrntFileCopy<totFiles; dat.iCrntFileCopy++)
	{	MySHFileOperation(FO_DELETE,
					dat.stack[dat.iCrntFileCopy].FullPathAndName,NULL,0);
 }	}

 //1 marta optom Notify yuborsun:
 if(sockDlg[fCopyOper::destPanel])
 if(socketCl==panel[fCopyOper::destPanel].GetEntry()->GetCrntRecType())
	SendToServerMsg(fCopyOper::destPanel,LNKSCKMSG_ON_DIRECTORY_CHANGE_NOTIFY,panel[fCopyOper::destPanel].GetPath());

 if(dat.stack) free(dat.stack);
 ExitThread(0);
}

INT_PTR CALLBACK RMCopyQueueDlgProc(HWND hDlg,UINT message,WPARAM wParam,LPARAM lParam)
{
static HFONT hf=0;static int hfRef=0;//obshiy hf, dinamik uchun emas:
static HBRUSH br=0;
static HBRUSH brHtBk=0;
	switch(message)
	{
	case WM_INITDIALOG:
		//Adjust to center:
		RECT rc; GetWindowRect(hDlg, &rc);
		int width,left,height,top;

		width = rc.right - rc.left;
		left = conf::wndLeft + (conf::wndWidth - width)/2;

		height = rc.bottom - rc.top;
		top = conf::wndTop + (conf::wndHeight - height)/2;
		MoveWindow(hDlg, left, top+20, width, height, TRUE);

		//Load language strings:
		wchar_t s[MAX_PATH];
		LoadString(hInst,IDS_STRINGSW_46,s,MAX_PATH);
		SetWindowText(hDlg,s);
		LoadString(hInst,IDS_STRINGSW_47,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_STATIC,s);
		LoadString(hInst,IDS_STRINGSW_48,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_STATIC5,s);
		LoadString(hInst,IDS_STRINGSW_49,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_BUTTON_TO_BACKGROUND_COPY_QUEUE,s);
		LoadString(hInst,IDS_STRINGSW_50,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_BUTTON_STOP,s);
		LoadString(hInst,IDS_STRINGSW_13,s,MAX_PATH);
		SetDlgItemText(hDlg,IDCANCEL,s);

		PostMessage(GetDlgItem(hDlg,IDC_PROGRESS_COPY_SINGLE),PBM_SETRANGE,0,MAKELPARAM(0,1000));
		PostMessage(GetDlgItem(hDlg,IDC_PROGRESS_COPY_TOTAL ),PBM_SETRANGE,0,MAKELPARAM(0,1000));
		PostMessage(GetDlgItem(hDlg,IDC_PROGRESS_COPY_SINGLE),PBM_SETSTEP,1,0);
		PostMessage(GetDlgItem(hDlg,IDC_PROGRESS_COPY_TOTAL ),PBM_SETSTEP,1,0);

		SendMessage(hDlg,WM_USER+1,0,0);

		CalcSrcAndAvailableDestSize();
		if(fRenMove::avDstSz < fRenMove::srcSz)
		{	wchar_t txt[MAX_PATH];StringCchPrintf(txt,MAX_PATH,L"Available memory in %s is: %d, but needed %d. Start copy to available?",fRenMove::avDstSz,fRenMove::srcSz);
			if(IDCANCEL==MessageBox(NULL,txt,L"Warn:",MB_OKCANCEL))
			{	EndDialog(hDlg,0);
				return TRUE;
		}	}
		fRenMove::copySrcSz = 0;
		static DWORD cpyThrdId;
		CreateThread(NULL,1024,(LPTHREAD_START_ROUTINE)RMcpyFileExThrdFnc,
					 hDlg,0,&cpyThrdId);
		return TRUE;
	case WM_CTLCOLORSTATIC:
	case WM_CTLCOLORDLG:HDC dc;dc = (HDC)wParam;
		SetTextColor(dc,conf::Dlg.dlgRGBs[1][1]);
		SetBkColor(dc,conf::Dlg.dlgRGBs[1][2]);
		return (INT_PTR)br;
	case WM_CTLCOLOREDIT:dc = (HDC)wParam;
		SetTextColor(dc,conf::Dlg.dlgRGBs[1][1]);
		SetBkColor(dc,conf::Dlg.dlgRGBs[1][2]);
		return (INT_PTR)br;
	case WM_CTLCOLORBTN:dc=(HDC)wParam;
		SetTextColor(dc,conf::Dlg.dlgRGBs[1][4]);
		SetBkColor(dc,conf::Dlg.dlgRGBs[1][5]);
		return (INT_PTR)brHtBk;
	case WM_DRAWITEM://WM_CTLCOLORBTN dagi knopkalar:
		LPDRAWITEMSTRUCT lpdis;lpdis = (LPDRAWITEMSTRUCT)lParam;
		GetWindowText(lpdis->hwndItem,s,64);
		UINT uStyle;uStyle = DFCS_BUTTONPUSH;
		rc = lpdis->rcItem;
		if(lpdis->itemState & ODS_SELECTED)
		{	uStyle |= DFCS_PUSHED;
			rc.left+=2;rc.top+=2;
		}
		DrawFrameControl(lpdis->hDC, &lpdis->rcItem, DFC_BUTTON, uStyle);
		if(lpdis->itemState & ODS_SELECTED)
			{rc.left+=1;rc.top+=1;rc.bottom-=2;rc.right-=3;}
		else
			{rc.left+=1;rc.top+=2;rc.bottom-=3;rc.right-=3;}
		FillRect(lpdis->hDC,&rc,brHtBk);//DrawText(lpdis->hDC,"                                                  ",50,&rc,DT_SINGLELINE|DT_VCENTER|DT_INTERNAL|DT_LEFT);
		if(lpdis->itemState & ODS_SELECTED)
			{rc.left-=1;rc.top-=1;rc.bottom+=3;rc.right+=3;}
		else
			{rc.left-=1;rc.top-=2;rc.bottom+=2;rc.right+=3;}
		DrawText(lpdis->hDC,s,MyStringLength(s,64),&rc,DT_SINGLELINE|DT_VCENTER|DT_CENTER);
		return TRUE;
	case WM_USER+1://hf obshiy uchun, dinamik o'zgartirish uchun emas:
		if(0==hfRef)
		{	hf = CreateFontIndirectW(&conf::Dlg.dlgFnts[1]);
			br = CreateSolidBrush(conf::Dlg.dlgRGBs[1][0]);
			brHtBk = CreateSolidBrush(conf::Dlg.dlgRGBs[1][5]);
		}
		SendMessage(GetDlgItem(hDlg,IDC_STATIC),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_STATIC5),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_BUTTON_TO_BACKGROUND_COPY_QUEUE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_BUTTON_STOP),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDCANCEL),WM_SETFONT,(WPARAM)hf,TRUE);
		++hfRef;
		return 0;//GWLP_USERDATA
	case WM_DESTROY:
		if(--hfRef<1)
		{	DeleteObject(hf);
			DeleteObject(br);
			DeleteObject(brHtBk);
		}
		return 0;
	case WM_COMMAND:
		switch(LOWORD(wParam))
		{	case IDC_BUTTON_TO_BACKGROUND_COPY_QUEUE:
				PostThreadMessage(cpyThrdId,MYWM_GOTOBCKGRND,0,0);
				return (INT_PTR)TRUE;
			case IDC_BUTTON_STOP:
				PostThreadMessage(cpyThrdId,MYWM_STOP,0,0);
				return (INT_PTR)TRUE;
			case IDCANCEL:
				PostThreadMessage(cpyThrdId,MYWM_CANCEL,0,0);
				EndDialog(hDlg,0);
				return (INT_PTR)TRUE;
		}
		break;
	}
	return (INT_PTR)FALSE;
}

}//end of namespace fRenMove