#pragma warning(disable:4996)

#include "windows.h"
#include "..\Sino.h"
#include "Psapi.h"
#include "qView.h"
#include "..\Plugins\Executables\viewFileAssoc.h"
#include "..\resource.h"
#include "..\Config.h"
#include "MyErrors.h"
#include "Execution.h"
#include "MyShell\MyShell.h"
//#include "..\..\Operations\MyShell\MyButtonC++.h"

extern HINSTANCE hInst;

namespace QView
{wchar_t saveShowPathInfo[MAX_PATH];
int iMaxPlgns=0,numPlugins=0,iPanel=-1,iOpponentPanel=-1,iCrntPlgnNum=-1;
CQViewPlgn *plgns=NULL;

BOOL Open(int iiPanel,int iiOpponentPanel)
{	wchar_t s[MAX_PATH];
	if(iiPanel<0 || iiOpponentPanel<0 || iiPanel==iiOpponentPanel)
	{	MessageBox(panel[iiPanel].GetHWND(),L"QView panel instances mismatch.",L"Error...",MB_OK);
		return FALSE;
	}if(virtualPanel==panel[iiOpponentPanel].GetEntry()->GetCrntRecType())
	{	MessageBox(panel[iiPanel].GetHWND(),L"Can't set QView above virtual panel.",L"Error...",MB_OK);
		return FALSE;
	}
	int iHot = panel[iiPanel].GetHot();s[0]=0;
	if(0==iHot || folder==panel[iiPanel].GetItem(iHot)->attribute){s[0]='.';s[1]='.';s[2]=0;}
	else
	{	wchar_t *pext=panel[iiPanel].GetItem(iHot)->GetExt();
		if(pext) MyStringCpy(s,MAX_PATH,pext);
		else {s[0]='b';s[1]='i';s[2]='n';s[0]=0;}
	}
	if(0==s[0])
	{	MessageBox(panel[iiPanel].GetHWND(),L"Undefined filter string for QView.",L"Error...",MB_OK);
		return FALSE;
	}

	int iPlg = FindPlugin(s);
	if(iPlg<0)iPlg = FindPlugin(L"bin");
	if(iPlg<0)
	{	MessageBox(panel[iiPanel].GetHWND(),L"Corrected plugin for QView not founded.",L"Error...",MB_OK);
		return FALSE;
	}

	BOOL r=plgns[iPlg].LoadPlugin();
	if(!r)
	{	MessageBox(panel[iiPanel].GetHWND(),plgns[iPlg].descrpn,L"Can't load QView plugin.",MB_OK);
		return FALSE;
	}iCrntPlgnNum=iPlg;

	iPanel=iiPanel;iOpponentPanel=iiOpponentPanel;

	if(0==iHot)panel[iiPanel].GetPath(s);
	else panel[iiPanel].GetFullPathAndName(iHot,s,MAX_PATH);

	GetWindowText(panel[iiOpponentPanel].GetPathAndNameEdt(1),saveShowPathInfo,MAX_PATH);

	//for(int i=0; i<2; ++i)
	{	if(plgns[iPlg].Draw$8)
		{	if(archElem==panel[iiPanel].GetEntry()->GetCrntRecType())
			{	CTempDir tmp(conf::tmpPath);
				tmp.UnpackSelected(&panel[iiPanel]);
				wchar_t *pfName=tmp.GetItemPathAndName();
				r=plgns[iPlg].Draw$8(panel[iiOpponentPanel].GetHWND(),pfName);
				tmp.Free();
				MySHFileOperation(FO_DELETE,pfName,NULL,FOF_ALLOWUNDO|FOF_SILENT|FOF_NOCONFIRMATION|FOF_NOCONFIRMMKDIR,FALSE);//DeleteFile(pfName);//tmp.Close();
			}else r=plgns[iPlg].Draw$8(panel[iiOpponentPanel].GetHWND(),s);
			/*if(r)break;
			plgns[iPlg].FreePlugin();
			iPlg = FindPlugin(L"bin");
			r=plgns[iPlg].LoadPlugin();
			iCrntPlgnNum=iPlg;*/
	}	}
	SetWindowText(panel[iOpponentPanel].GetPathAndNameEdt(1),s);
	return TRUE;
}

BOOL Close()
{	if(plgns[iCrntPlgnNum].CloseViewer)
		plgns[iCrntPlgnNum].CloseViewer();
	plgns[iCrntPlgnNum].FreePlugin();
	panel[iOpponentPanel].Render();
	SetWindowText(panel[iOpponentPanel].GetPathAndNameEdt(1),saveShowPathInfo);
	iPanel=iOpponentPanel=iCrntPlgnNum=-1;
	return TRUE;
}

BOOL Draw(wchar_t *fullPathAndName)
{	if(!plgns)return FALSE;
	if(numPlugins<1)return FALSE;
	//if(iPanel<0)return FALSE;
	//if(iOpponentPanel<0)return FALSE;
	//if(iCrntPlgnNum<0)return FALSE;

	wchar_t s[MAX_PATH]=L"";int iPlg=-1;

	/*if((!fullPathAndName) || 0==fullPathAndName[0])
	{	iPlg=FindPlugin(L"..");
		panel[iPanel].GetPath(s);
	}else if(IsDirExist(fullPathAndName))
	{	iPlg=FindPlugin(L"..");
		MyStringCpy(s,MAX_PATH,fullPathAndName);
	}else if(IsFileExist(fullPathAndName))
	{	wchar_t *p=wcsrchr(fullPathAndName,'.');
		if(!p)iPlg=FindPlugin(L"bin");
		else iPlg=FindPlugin(p+1);
		if(iPlg<0)iPlg=FindPlugin(L"bin");
		MyStringCpy(s,MAX_PATH,fullPathAndName);
	}else
	{	iPlg=FindPlugin(L"..");
		MyStringCpy(s,MAX_PATH,fullPathAndName);
	}*/

	if(IsFileExist(fullPathAndName) || archElem==panel[iPanel].GetEntry()->GetCrntRecType())
	{	wchar_t *p=wcsrchr(fullPathAndName,'.');
		if(!p)iPlg=FindPlugin(L"bin");
		else iPlg=FindPlugin(p+1);
		if(iPlg<0)iPlg=FindPlugin(L"bin");
		MyStringCpy(s,MAX_PATH,fullPathAndName);
	}else
	{	iPlg=FindPlugin(L"..");
		MyStringCpy(s,MAX_PATH,fullPathAndName);
	}

	if(iPlg<0)
	{	MessageBox(panel[iPanel].GetHWND(),L"Corrected plugin for QView not founded.",L"Error...",MB_OK);
		return FALSE;
	}BOOL r;
	if(iPlg!=iCrntPlgnNum)
	{	if(plgns[iCrntPlgnNum].CloseViewer)
			plgns[iCrntPlgnNum].CloseViewer();
		plgns[iCrntPlgnNum].FreePlugin();
		r=plgns[iPlg].LoadPlugin();
		if(!r)
		{	MessageBox(panel[iPanel].GetHWND(),plgns[iPlg].descrpn,L"Can't load QView plugin.",MB_OK);
			return FALSE;
		}iCrntPlgnNum=iPlg;
	}

	//if(0!=IsBadStringPtr(s,MAX_PATH))
	//return FALSE;
	//for(int i=0; i<2; ++i)
	{	if(plgns[iPlg].Draw$8)
		{	if(archElem==panel[iPanel].GetEntry()->GetCrntRecType())
			{	CTempDir tmp(conf::tmpPath);
				tmp.UnpackSelected(&panel[iPanel]);
				wchar_t *pfName=tmp.GetItemPathAndName();
				r=plgns[iPlg].Draw$8(panel[iOpponentPanel].GetHWND(),pfName);
				tmp.Free();
				MySHFileOperation(FO_DELETE,pfName,NULL,FOF_ALLOWUNDO|FOF_SILENT|FOF_NOCONFIRMATION|FOF_NOCONFIRMMKDIR,FALSE);//DeleteFile(pfName);//tmp.Close();
			}else r=plgns[iPlg].Draw$8(panel[iOpponentPanel].GetHWND(),s);
			/*if(r)break;
			plgns[iPlg].FreePlugin();
			iPlg = FindPlugin(L"bin");
			r=plgns[iPlg].LoadPlugin();
			iCrntPlgnNum=iPlg;*/
	}	}
	SetWindowText(panel[iOpponentPanel].GetPathAndNameEdt(1),fullPathAndName);
	panel[iPanel].SetFocus();
	return TRUE;
}

VOID TryLoadPlugin(wchar_t *pth,wchar_t* name,int l)
{//LoadLibrary da exception beradur;
	if(numPlugins>conf::Dlg.totalAllovedArchvr)
	{	Err::msg(hWnd,0,L"There are any archiver plugins(above 20), ignore others...");
		return;
	}

	MyStringCpy(&pth[l],MAX_PATH-1,name);
//HMODULE hm = LoadLibraryEx(pth,NULL,LOAD_LIBRARY_AS_IMAGE_RESOURCE);//LOAD_LIBRARY_AS_DATAFILE);
//	if(!hm)return;
//	FreeLibrary(hm);
//	char st[260]; char *p=strrchr(pth,'\\');if(p)*p=0;
//	if(32>(int)FindExecutable(name,pth,st)) return;


//	DWORD bt;
//	if(!GetBinaryType(pth,&bt))return;

	if(!Execution::IsThisValidDllFile(pth))
		return;

BEGIN_TRY

HMODULE hm = LoadLibraryEx(pth,NULL,0);
	if(!hm)
	{	Err::msg(hWnd,-1,pth);
		return;
	}

	GetExtensions_t GetExtensions = (GetArchExtnsn_t)GetProcAddress(hm,"GetExtensions");
	if(!GetExtensions)//goto Fall;
	{		
Fall:	FreeLibrary(hm);             //shart emas, unpack archive bo'lishi mumkin;
		return;
	}
	GetPluginType_t GetPluginType = (GetPluginType_t)GetProcAddress(hm,"GetPluginType");
	if(!GetPluginType) goto Fall;
	SetCallbacks$4xxx_t SetCallbacks$4xxx = (SetCallbacks$4xxx_t)GetProcAddress(hm,"SetCallbacks$4xxx");
	if(!SetCallbacks$4xxx) goto Fall;
	Draw$8_t Draw$8 = (Draw$8_t)GetProcAddress(hm,"Draw$8");
	if(!Draw$8) goto Fall;	
	GetPluginDescription_t GetPluginDescription = (GetPluginDescription_t)GetProcAddress(hm,"GetPluginDescription");
	ShowOptionDialog_t ShowOptionDialog = (ShowOptionDialog_t)GetProcAddress(hm,"ShowOptionDialog");
	SetId$4_t SetId$4 = (SetId$4_t)GetProcAddress(hm,"SetId$4");

	int t=GetPluginType();
	if(502!=t) goto Fall;

	if(!plgns) plgns = (CQViewPlgn*)malloc((numPlugins+1)*sizeof(CQViewPlgn));
	else  plgns = (CQViewPlgn*)realloc(plgns,(numPlugins+1)*sizeof(CQViewPlgn));
	plgns[numPlugins].CQViewPlgn::CQViewPlgn();
	if(GetPluginDescription)MyStringCpy(plgns[numPlugins].descrpn,MAX_PATH,(wchar_t*)GetPluginDescription());
	else plgns[numPlugins].descrpn[0]=0;
	if(GetExtensions)MyStringCpy(plgns[numPlugins].extnsn,MAX_PATH,_wcslwr((wchar_t*)GetExtensions()));
	else plgns[numPlugins].extnsn[0]=0;	
	MyStringCpy(plgns[numPlugins].pathAndName,MAX_PATH-1,pth);
	plgns[numPlugins].idNum = numPlugins;

	FreeLibrary(hm);

	if(conf::Dlg.crntArchvr<0)conf::Dlg.crntArchvr=numPlugins;
	++numPlugins;
END_TRY
{
	Err::msg1(NULL,0,pth,L"Err.loading qView.plgn.");
}}

VOID ListArchDirLoadPlugins(wchar_t *path)
{
wchar_t s[MAX_PATH];
WIN32_FIND_DATA ff;
HANDLE hf = INVALID_HANDLE_VALUE;
	int l=MyStringCpy(s,MAX_PATH-1,path);
	if(MyStringRemoveLastCharCheckPre(s,MAX_PATH-1,'*','\\'))
		--l;

	hf = MyFindFirstFileEx(path,FindExInfoStandard,&ff,FindExSearchLimitToDirectories,NULL,0);
	do
	{	if(INVALID_HANDLE_VALUE==hf) return;
		if(FILE_ATTRIBUTE_DIRECTORY & ff.dwFileAttributes)//if(IsDirectory(path, &ff, FALSE))
		{	if(IsCrntOrPrntDirAttrb(ff.cFileName))
			{	int n=MyStringCpy(&s[l],MAX_PATH-1,ff.cFileName);
				MyStringCpy(&s[l+n],MAX_PATH-1-l,L"\\*");
				ListArchDirLoadPlugins(s);
		}	}
		else
			TryLoadPlugin(s,ff.cFileName,l);
	}
	while(FindNextFile(hf, &ff));
	FindClose(hf);
}

VOID FreePlugins()
{	free(plgns);
	plgns=NULL;
	numPlugins=0;
}

VOID LoadPlugins(HWND prnt)
{	numPlugins=0;
	wchar_t *qViewPlgPth = MyStringAddModulePath(L"Plugins\\qView\\*");
	ListArchDirLoadPlugins(qViewPlgPth);
}

int FindPlugin(wchar_t *extnsn)
{	wchar_t ext[MAX_PATH];int extLn=MyStringCpy(ext,MAX_PATH-1,extnsn);
	if(extLn<-1)return -1;
	wchar_t *pext=_wcslwr(ext);
	int plgnCnt=-1;
	for(int p=0; p<numPlugins; ++p)
	{	wchar_t *pp = viewFileAssoc::findExactExt(plgns[p].extnsn,pext,extLn);
		if(!pp)continue;
		if(*(pp+extLn)!=0 && *(pp+extLn)!=';')continue;
		return p;
	}
	return -1;
}

BOOL IsExistAny()
{	for(int i=0; i<conf::Dlg.iTotPanels; i++)
	{	if(1==panel[i].bQView)
			return TRUE;
	}
	return FALSE;
}
					
}//end of namespace QVIEW;

//*********** CQViewPlgn ****************
//*********** CQViewPlgn ****************
//*********** CQViewPlgn ****************
//*********** CQViewPlgn ****************
//*********** CQViewPlgn ****************
//*********** CQViewPlgn ****************
//*********** CQViewPlgn ****************
//*********** CQViewPlgn ****************
//*********** CQViewPlgn ****************
//*********** CQViewPlgn ****************
//*********** CQViewPlgn ****************
//*********** CQViewPlgn ****************
//*********** CQViewPlgn ****************
//*********** CQViewPlgn ****************
//*********** CQViewPlgn ****************

//*********** statics: ******************
//*********** statics: ******************
//*********** statics: ******************
//*********** statics: ******************
//*********** statics: ******************
//*********** statics: ******************
//*********** statics: ******************
//*********** statics: ******************
//*********** statics: ******************
//*********** statics: ******************
//*********** statics: ******************
//*********** statics: ******************
BOOL CALLBACK CQViewPlgn::readOptions(int plgId,VOID *buf,int bufLen)
{
	if(plgId<0) return FALSE;//|| plgId>fSearchViaF7::numPlugins-1) return FALSE; ni qo'ymaymiz, hali numPlugins 1ta oshmagan bo'lishi mumkin;
DWORD rb;
wchar_t s[MAX_PATH];MyStringCpy(s,MAX_PATH-1,archive::plgns[plgId].pathAndName);//arc->name);
	wchar_t *p = wcsrchr(s,'.');
	if(p) *(p+1) = 0;
	MyStringCat(s,MAX_PATH-1,L"bin");
	HANDLE f = MyFopenViaCrF(s,L"r");//MyStringAddModulePath
	if(!f) return FALSE;
	if(!ReadFile(f,buf,bufLen,&rb,NULL))
		rb=0;
	CloseHandle(f);
	return (rb!=bufLen)?FALSE:TRUE;
}

BOOL CALLBACK CQViewPlgn::saveOptions(int plgId,VOID *buf,int bufLen)
{
	if(plgId<0 || plgId>archive::numPlugins-1) return FALSE;
DWORD rb;
wchar_t s[MAX_PATH];MyStringCpy(s,MAX_PATH-1,archive::plgns[plgId].pathAndName);//arc->name);
	wchar_t *p = wcsrchr(s,'.');
	if(p) *(p+1) = 0;
	MyStringCat(s,MAX_PATH-1,L"bin");
	HANDLE f = MyFopenViaCrF(s,L"w");//MyStringAddModulePath
	if(!f) return FALSE;
	if(!WriteFile(f,buf,bufLen,&rb,NULL))
		rb=0;
	CloseHandle(f);

	if(0==plgId)//Oxirgi dll
	{	if(archive::plgns)
			free(archive::plgns);
		archive::plgns=NULL;
		archive::numPlugins=0;
	}
	return (rb!=bufLen)?FALSE:TRUE;
}

//********** CQViewPlgn *****************
//********** CQViewPlgn *****************
//********** CQViewPlgn *****************
//********** CQViewPlgn *****************
//********** CQViewPlgn *****************
//********** CQViewPlgn *****************
CQViewPlgn::CQViewPlgn():hm(0)
{
}

CQViewPlgn::~CQViewPlgn()
{
}

VOID CQViewPlgn::FreePlugin()
{	if(hm)
	{	FreeLibrary(hm);
		hm=0;
		SetCallbacks$4xxx=0;
		SetId$4=0;
		ShowOptionDialog=0;
		Draw$8=0;
}	}

BOOL CQViewPlgn::LoadPlugin()
{	if(0==hm)
	{	hm = LoadLibrary(pathAndName);
		if(!hm) return FALSE;
		SetCallbacks$4xxx = (QView::SetCallbacks$4xxx_t)GetProcAddress(hm,"SetCallbacks$4xxx");
		ShowOptionDialog = (QView::ShowOptionDialog_t)GetProcAddress(hm,"ShowOptionDialog");
		SetId$4 = (QView::SetId$4_t)GetProcAddress(hm,"SetId$4");
		Draw$8 = (QView::Draw$8_t)GetProcAddress(hm,"Draw$8");
		CloseViewer = (QView::CloseViewer_t)GetProcAddress(hm,"CloseViewer");
		SetCallbacks$4xxx(	saveOptions,
							readOptions);
		SetId$4(idNum);
		return TRUE;
	}	
	return FALSE;
}