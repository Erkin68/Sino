#pragma warning(disable:4996)

#include "BtnBar.h"
#include "windows.h"
#include "strsafe.h"
#include "..\Config.h"
#include "..\Panel.h"
#include "MyShell\MyShell.h"
#include "Execution.h"
#include "MenuUtils.h"
#include "VirtualPanel.h"
#include "shlobj.h"


extern HINSTANCE hInst;
extern CBtnBar saveBar;


BOOL CBarBtn::Execute()
{switch(type)
 {case group:return TRUE;
  case hotKey:
   int iap;iap=Panel::iActivePanel;
   //if(Panel::iActivePanel<0)return FALSE;
   //if(Panel::iActivePanel>conf::Dlg.iTotPanels-1)return FALSE;
   if(iap<0)iap=0;
   else if(iap>conf::Dlg.iTotPanels-1)iap=0;
   panel[iap].ExecuteHotKey(data[0]);
  return TRUE;
  case extFolder:
   return (32<(int)ShellExecute(::hWnd,L"explore",auxPath,NULL,auxPath,SW_SHOWNORMAL));
  case extLink:
   return (32<(int)ShellExecute(::hWnd,L"open",auxPath,NULL,auxPath,SW_SHOWNORMAL));
  case plgDllLink:
	  if(!auxPath)return FALSE;
	  BOOL r;r=menuUtils::RunFromName(::hWnd,auxPath);
	  if(!r)
	  {iap=Panel::iActivePanel;
	   if(iap<0)iap=0;
	   else if(iap>conf::Dlg.iTotPanels-1)iap=0;
	   if((data[0]>0 && data[0]<256) && (data[1]>0 && data[1]<256) && (data[2]>0 && data[2]<256) && (data[3]>0 && data[3]<256))
	   {wchar_t s[64];StringCchPrintf(s,64,L"%d%s%d%s%d%s%d",data[0],L".",data[1],L".",data[2],L".",data[3]);
	    r=vrtlPanels::AttachFromName(&panel[iap],auxPath,s);
	   }
	   else r=vrtlPanels::AttachFromName(&panel[iap],auxPath,panel[iap].GetPath());
	  }
	  return r;
  case plgExeLink:wchar_t *p,pth[MAX_PATH];
	  GetModuleFileName(NULL,pth,MAX_PATH);
	  p=wcsrchr(pth,'\\');if(p)*p=0;
	  SetCurrentDirectory(pth);
	  if(Panel::iActivePanel>-1)
	  {	int hot=panel[Panel::iActivePanel].GetHot();
	    if(hot>0)
		 return Execution::exePE(auxPath,panel[Panel::iActivePanel].GetFullPathAndName(hot));
		else
		 return Execution::exePE(auxPath,panel[Panel::iActivePanel].GetPath());
	  }
	  else
		return Execution::exePE(auxPath,panel[0].GetPath());
  return TRUE;
  case commands:return ExecuteCmndNum();
 }
 return FALSE;
}

BOOL CBarBtn::ExecuteCmndNum()
{
switch(cmndNum)
{case 0://"1.Call menu item.Use up to 3 steps of sub menu in data1/2/3 as menu pos.");
  if(!data[0])return FALSE;
  HMENU hmenu;hmenu=GetMenu(::hWnd);
  if(!hmenu)return FALSE;

  HMENU hsub;hsub=GetSubMenu(hmenu,data[0]-1);
  if(!hsub)return FALSE;

  int iRealIds[2];iRealIds[0]=iRealIds[1]=-1;
  int cnt;cnt = GetMenuItemCount(hsub);
  if(-1==cnt)return FALSE;
  for(int k=0; k<cnt; ++k)
  {int id=GetMenuItemID(hsub,k);
   if(-1==id)continue;
   if(++iRealIds[0]+1==data[1])
    break;//topilmasa, 0-bo'lsin;
  }
  if(!data[1])
  {SendMessage(::hWnd,WM_COMMAND,MAKELONG(iRealIds[0],0),0);
   return TRUE;
  }
  hsub=GetSubMenu(hsub,data[1]-1);
  cnt = GetMenuItemCount(hsub);
  if(-1==cnt)return FALSE;
  for(int k=0; k<cnt; ++k)
  {int id=GetMenuItemID(hsub,k);
   if(-1==id)continue;
   if(++iRealIds[1]+1==data[1])
    break;//topilmasa, 0-bo'lsin;
  }
  SendMessage(::hWnd,WM_COMMAND,MAKELONG(iRealIds[1],0),0);
  return TRUE;
 case 1://"2.Select: all items.");
  SendMessage(::hWnd,WM_COMMAND,MAKELONG(IDM_EDIT_SELECTALL,0),0);//panel[Panel::iActivePanel].ExecuteHotKey(0);
 return TRUE;
 case 2://"3.Select: all folders.");
  SendMessage(::hWnd,WM_COMMAND,MAKELONG(IDM_SELECTALL_FOLDERS,0),0);
 return TRUE;
 case 3://"4.Select: all files.");
  SendMessage(::hWnd,WM_COMMAND,MAKELONG(IDM_SELECTALL_FILES,0),0);
 return TRUE;
 case 4://"5.Unselect: all items.");
  SendMessage(::hWnd,WM_COMMAND,MAKELONG(IDM_UNSELECTALL_ALL,0),0);
 return TRUE;
 case 5://"6.Unselect: all folders.");
  SendMessage(::hWnd,WM_COMMAND,MAKELONG(IDM_UNSELECTALL_FOLDERS,0),0);
 return TRUE;
 case 6://"7.Unselect: all files.");
  SendMessage(::hWnd,WM_COMMAND,MAKELONG(IDM_UNSELECTALL_FILES,0),0);
 return TRUE;
 case 7://"8.Invert selection: all items.");
  SendMessage(::hWnd,WM_COMMAND,MAKELONG(IDM_INVERTSELECTION_ALL,0),0);
 return TRUE;
 case 8://"9.Invert selection: all folders.");
  SendMessage(::hWnd,WM_COMMAND,MAKELONG(IDM_INVERTSELECTION_FOLDERS,0),0);
 return TRUE;
 case 9://"10.Invert selection: all files.");
  SendMessage(::hWnd,WM_COMMAND,MAKELONG(IDM_INVERTSELECTION_FILES,0),0);
 return TRUE;
 case 10://"11.Clipboard: Copy selected files to clipboard.");
  SendMessage(::hWnd,WM_COMMAND,MAKELONG(IDM_EDIT_COPY,0),0);
 return TRUE;
 case 11://"12.Clipboard: Cut selected files to clipboard.");
  SendMessage(::hWnd,WM_COMMAND,MAKELONG(IDM_EDIT_CUT,0),0);
 return TRUE;
 case 12://"13.Clipboard: Past selected files from clipboard.");
  SendMessage(::hWnd,WM_COMMAND,MAKELONG(IDM_EDIT_PAST,0),0);
 return TRUE;
 case 13://"14.Clipboard: Copy list of selected files to clipboard.");
  SendMessage(::hWnd,WM_COMMAND,MAKELONG(IDM_EDIT_COPYALLITEMSASTEXT,0),0);
 return TRUE;
 case 14://"15.Clipboard: Past list of selected files from clipboard.");
  //SendMessage(::hWnd,WM_COMMAND,MAKELONG(IDM_EDIT_COPYALLITEMSASTEXT,0),0);
 return TRUE;
 case 15://"16.Clipboard: Copy all files to clipboard.");
  //SendMessage(::hWnd,WM_COMMAND,MAKELONG(IDM_EDIT_COPYALLITEMSASTEXT,0),0);
 return TRUE;
 case 16://"17.Clipboard: Cut all files to clipboard.");
 return TRUE;
 case 17://"18.Clipboard: Past all files from clipboard.");
 return TRUE;
 case 18://"19.Clipboard: Copy list of all files to clipboard.");
 return TRUE;
 case 19://"20.Clipboard: Past list of all files from clipboard.");
 return TRUE;
 case 20://"21.Main window: Maximimize.");
  ShowWindow(::hWnd,SW_MAXIMIZE);
 return TRUE;
 case 21://"22.Main window: Minimize to taskbar.");
  ShowWindow(::hWnd,SW_MINIMIZE);
 return TRUE;
 case 22://"23.Main window: Exit.");
  SendMessage(::hWnd,IDM_FILE_EXIT,0,0);
 return TRUE;
 case 23://"24.Configuration: Show main dialog.");
  SendMessage(::hWnd,IDM_CONFIGURATION,0,0);
 return TRUE;
 case 24://"25.Configuration: Show languge dialog.");
  SendMessage(::hWnd,IDM_CONFIGURATION_LANGUAGE,0,0);
 return TRUE;
 case 25://"26.Configuration: Show lock via password dialog.");
  SendMessage(::hWnd,IDM_CONFIGURATION_LOCKSUBMENUVIAPASSWORD,0,0);
 return TRUE;
 case 26://"27.Configuration: Show file association/view dialog.");
  SendMessage(::hWnd,IDM_FASSOC_VIEW,0,0);
 return TRUE;
 case 27://"28.Configuration: Show file association/edit dialog.");
  SendMessage(::hWnd,IDM_FASSOC_EDIT,0,0);
 return TRUE;
 case 28://"29.Configuration: Show file association/execute dialog.");
  SendMessage(::hWnd,IDM_FASSOC_EXECUTE,0,0);
 return TRUE;
 case 29://"30.View: to short.");
  SendMessage(::hWnd,IDM_VIEW_SHORT,0,0);
 return TRUE;
 case 30://"31.View: to full.");
  SendMessage(::hWnd,IDM_VIEW_FULL,0,0);
 return TRUE;
 case 31://"32.View: to custom/name.");
  SendMessage(::hWnd,IDM_CUSTOM_NAME,0,0);
 return TRUE;
 case 32://"32.View: to custom/name.");
  SendMessage(::hWnd,IDM_CUSTOM_CREATE_TIME,0,0);
 return TRUE;
 case 33://"32.View: to custom/name.");
  SendMessage(::hWnd,IDM_CUSTOM_WRITE_TIME,0,0);
 return TRUE;
 case 34://"32.View: to custom/name.");
  SendMessage(::hWnd,IDM_CUSTOM_SIZE,0,0);
 return TRUE;
 case 35://"32.View: to custom/name.");
  SendMessage(::hWnd,IDM_CUSTOM_TOTAL_SIZE,0,0);
 return TRUE;
 case 36://"32.View: to custom/name.");
  SendMessage(::hWnd,IDM_CUSTOM_ATTRIBUTE,0,0);
 return TRUE;
 case 37://"32.View: to custom/name.");
  SendMessage(::hWnd,IDM_CUSTOM_STATE,0,0);
 return TRUE;
 case 38://"32.View: to custom/name.");
  SendMessage(::hWnd,IDM_CUSTOM_NAME_LEN,0,0);
 return TRUE;
 case 39://"32.View: to custom/name.");
  SendMessage(::hWnd,IDM_CUSTOM_EXT_LEN,0,0);
 return TRUE;
 case 40://"33.View: Sorting/Folders and files: folders to up.");
  SendMessage(::hWnd,IDM_FOLDERSANDFILESMIXING_FOLDERSTOUP,0,0);
 return TRUE;
 case 41://"34.View: Sorting/Folders and files: files to up.");
  SendMessage(::hWnd,IDM_FOLDERSANDFILESMIXING_FILESTOUP,0,0);
 return TRUE;
 case 42://"35.View: Sorting/Folders and files: mixed.");
  SendMessage(::hWnd,IDM_FOLDERSANDFILESMIXING_MIXED,0,0);
 return TRUE;
 case 43://"36.View: Sorting/Folders: for sizes, to up.");
  SendMessage(::hWnd,IDM_FOLDERSSORTING_BYSIZEUP,0,0);
 return TRUE;
 case 44://"37.View: Sorting/Folders: for sizes, to down.");
  SendMessage(::hWnd,IDM_FOLDERSSORTING_BYSIZEDOWN,0,0);
 return TRUE;
 case 45://"38.View: Sorting/Folders: for alphabet, to up.");
  SendMessage(::hWnd,IDM_FOLDERSSORTING_BYALPHABETUP,0,0);
 return TRUE;
 case 46://"39.View: Sorting/Folders: for alphabet, to down.");
  SendMessage(::hWnd,IDM_FOLDERSSORTING_BYALPHABETDOWN,0,0);
 return TRUE;
 case 47://"40.View: Sorting/Folders: for creation time, to up.");
  SendMessage(::hWnd,IDM_FOLDERSSORTING_BYTIMEUP,0,0);
 return TRUE;
 case 48://"41.View: Sorting/Folders: for creation time, to down.");
  SendMessage(::hWnd,IDM_FOLDERSSORTING_BYTIMEDOWN,0,0);
 return TRUE;
 case 49://"42.View: Sorting/Folders: for type, to up.");
  SendMessage(::hWnd,IDM_FOLDERSSORTING_BYTYPEUP,0,0);
 return TRUE;
 case 50://"43.View: Sorting/Folders: for type, to down.");
  SendMessage(::hWnd,IDM_FOLDERSSORTING_BYTYPEDOWN,0,0);
 return TRUE;
 case 51://"44.View: Sorting/Folders: enum (this means not sorting).");
  SendMessage(::hWnd,IDM_FOLDERSSORTING_NOTSORTING,0,0);
 return TRUE;
 case 52://"45.View: Sorting/Files: for sizes, to up.");
  SendMessage(::hWnd,IDM_FILESSORTING_BYSIZEUP,0,0);
 return TRUE;
 case 53://"46.View: Sorting/Files: for sizes, to down.");
  SendMessage(::hWnd,IDM_FILESSORTING_BYSIZEDOWN,0,0);
 return TRUE;
 case 54://"47.View: Sorting/Files: for alphabet, to up.");
  SendMessage(::hWnd,IDM_FILESSORTING_BYALPHABETUP,0,0);
 return TRUE;
 case 55://"48.View: Sorting/Files: for alphabet, to down.");
  SendMessage(::hWnd,IDM_FILESSORTING_BYALPHABETDOWN,0,0);
 return TRUE;
 case 56://"49.View: Sorting/Files: for creation time, to up.");
  SendMessage(::hWnd,IDM_FILESSORTING_BYTIMEUP,0,0);
 return TRUE;
 case 57://"50.View: Sorting/Files: for creation time, to down.");
  SendMessage(::hWnd,IDM_FILESSORTING_BYTIMEDOWN,0,0);
 return TRUE;
 case 58://"51.View: Sorting/Files: for type, to up.");
  SendMessage(::hWnd,IDM_FILESSORTING_BYTYPEUP,0,0);
 return TRUE;
 case 59://"52.View: Sorting/Files: for type, to down.");
  SendMessage(::hWnd,IDM_FILESSORTING_BYTYPEDOWN,0,0);
 return TRUE;
 case 60://"53.View: Sorting/Files: enum (this means not sorting).");
  SendMessage(::hWnd,IDM_FILESNOTSORTING,0,0);
 return TRUE;
 case 61://"54.Console: call command interpreter direct.");
  SendMessage(::hWnd,IDM_EDIT_COMMANDCONSOLE,0,0);
 return TRUE;
 case 62://"55.Console: call command interpreter via arguments dialog.");
  SendMessage(::hWnd,IDM_EDIT_COMMANDCONSOLE,0,0);
 return TRUE;
 case 63://"56.Direct link via TCP/IP: show main dialog.");
  SendMessage(::hWnd,IDM_LINK_VIATCP,0,0);
 return TRUE;
 case 64://"57.Archive: show add to archive dialog.");
  SendMessage(::hWnd,IDM_ARCHIVE_ADD,0,0);
 return TRUE;
 case 67://"58.Archive: open archive.");
  SendMessage(::hWnd,IDM_ARCHIVE_OPEN,0,0);
 return TRUE;
 case 68://"59.Archive: show add to zip archive dialog.");
  SendMessage(::hWnd,IDM_ARCHIVE_ADD,0,0);
 return TRUE;
 case 69://"60.Archive: open via zip archivier.");
  SendMessage(::hWnd,IDM_ARCHIVE_OPEN,0,0);
 return TRUE;
 case 70://"61.Archive: open via unrar archivier.");
  SendMessage(::hWnd,IDM_ARCHIVE_OPEN,0,0);
 return TRUE;
 case 71://"62.Archive: show add to cab archive dialog.");
  SendMessage(::hWnd,IDM_ARCHIVE_ADD,0,0);
 return TRUE;
 case 72://"63.Archive: open via cab archivier.");
  SendMessage(::hWnd,IDM_ARCHIVE_OPEN,0,0);
 return TRUE;
 case 73://"64.Archive: show add to 7zip archive dialog.");
  SendMessage(::hWnd,IDM_ARCHIVE_ADD,0,0);
 return TRUE;
 case 74://"65.Archive: open via 7zip archivier.");
  SendMessage(::hWnd,IDM_ARCHIVE_OPEN,0,0);
 return TRUE;
 case 75://"66.Allocate of GUID folders: Desktop.");
  SendMessage(::hWnd,IDM_GUIDFOLDERS_DESKTOP,0,0);
 return TRUE;
 case 76://"67.Allocate of GUID folders: Common Desktop Directory.");
  SendMessage(::hWnd,IDM_GUIDFOLDERS_COMMONDESKTOPDIRECTORY,0,0);
 return TRUE;
 case 77://"68.Allocate of GUID folders: Desktop Directory.");
  SendMessage(::hWnd,IDM_GUIDFOLDERS_DESKTOPDIRECTORY,0,0);
 return TRUE;
 case 78://"69.Allocate of GUID folders: Common Documents.");
  SendMessage(::hWnd,IDM_GUIDFOLDERS_COMMONDOCUMENTS,0,0);
 return TRUE;
 case 79://"70.Allocate of GUID folders: My Documents.");
  SendMessage(::hWnd,IDM_GUIDFOLDERS_MYDOCUMENTS,0,0);
 return TRUE;
 case 80://"71.Allocate of GUID folders: Common Admin Tools.");
  SendMessage(::hWnd,IDM_GUIDFOLDERS_COMMONADMINTOOLS,0,0);
 return TRUE;
 case 81://"72.Allocate of GUID folders: Admin Tools.");
  SendMessage(::hWnd,IDM_GUIDFOLDERS_ADMINTOOLS,0,0);
 return TRUE;
 case 82://"73.Allocate of GUID folders: Common Local Startup.");
  SendMessage(::hWnd,IDM_GUIDFOLDERS_NONLOCALSTARTUP,0,0);
 return TRUE;
 case 83://"74.Allocate of GUID folders: Local Startup.");
  SendMessage(::hWnd,IDM_GUIDFOLDERS_LOCALSTARTUP,0,0);
 return TRUE;
 case 84://"75.Allocate of GUID folders: Common Startup.");
  SendMessage(::hWnd,IDM_GUIDFOLDERS_COMMONSTARTUP,0,0);
 return TRUE;
 case 85://"76.Allocate of GUID folders: Non Local Startup.");
  SendMessage(::hWnd,IDM_GUIDFOLDERS_COMMONLOCALSTARTUP,0,0);
 return TRUE;
 case 86://"77.Allocate of GUID folders: Common Application Data.");
  SendMessage(::hWnd,IDM_GUIDFOLDERS_APPLICATIONDATA,0,0);
 return TRUE;
 case 87://"78.Allocate of GUID folders: Application Data.");
  SendMessage(::hWnd,IDM_GUIDFOLDERS_APPLICATIONDATA,0,0);
 return TRUE;
 case 88://"79.Allocate of GUID folders: Favorites.");
  SendMessage(::hWnd,IDM_GUIDFOLDERS_FAVORITES,0,0);
 return TRUE;
 case 89://"80.Allocate of GUID folders: Common Programs.");
  SendMessage(::hWnd,IDM_GUIDFOLDERS_COMMONPROGRAMS,0,0);
 return TRUE;
 case 90://"81.Allocate of GUID folders: Programs.");
  SendMessage(::hWnd,IDM_GUIDFOLDERS_PROGRAMS,0,0);
 return TRUE;
 case 91://"82.Allocate of GUID folders: Common Start.");
  SendMessage(::hWnd,IDM_GUIDFOLDERS_COMMONSTART,0,0);
 return TRUE;
 case 92://"83.Allocate of GUID folders: Start.");
  SendMessage(::hWnd,IDM_GUIDFOLDERS_START,0,0);
 return TRUE;
 case 93://"84.Allocate of GUID folders: Common Template.");
  SendMessage(::hWnd,IDM_GUIDFOLDERS_TEMPLATES,0,0);
 return TRUE;
 case 94://"85.Allocate of GUID folders: Templates.");
  SendMessage(::hWnd,IDM_GUIDFOLDERS_COMMONTEMPLATE,0,0);
 return TRUE;
 case 95://"86.Allocate of GUID folders: Cookies.");
  SendMessage(::hWnd,IDM_GUIDFOLDERS_COOKIES,0,0);
 return TRUE;
 case 96://"87.Allocate of GUID folders: Fonts.");
  SendMessage(::hWnd,IDM_GUIDFOLDERS_FONTS,0,0);
 return TRUE;
 case 97://"88.Allocate of GUID folders: History.");
  SendMessage(::hWnd,IDM_GUIDFOLDERS_HISTORY,0,0);
 return TRUE;
 case 98://"89.Allocate of GUID folders: Internet Cashe.");
  SendMessage(::hWnd,IDM_GUIDFOLDERS_INTERNETCASHE,0,0);
 return TRUE;
 case 99://"80.Allocate of GUID folders: Local Application Data.");
  SendMessage(::hWnd,IDM_GUIDFOLDERS_LOCALAPPLICATIONDATA,0,0);
 return TRUE;
 case 100://"91.Allocate of GUID folders: My Pictures.");
  SendMessage(::hWnd,IDM_GUIDFOLDERS_MYPICTURES,0,0);
 return TRUE;
 case 101://"92.Allocate of GUID folders: Nethood.");
  SendMessage(::hWnd,IDM_GUIDFOLDERS_NETHOOD,0,0);
 return TRUE;
 case 102://"93.Allocate of GUID folders: Profile.");
  SendMessage(::hWnd,IDM_GUIDFOLDERS_PROFILE,0,0);
 return TRUE;
 case 103://"94.Allocate of GUID folders: Program Files.");
  SendMessage(::hWnd,IDM_GUIDFOLDERS_PROGRAM_FILES,0,0);
 return TRUE;
 case 104://"95.Allocate of GUID folders: Common Program Files.");
  SendMessage(::hWnd,IDM_GUIDFOLDERS_COMMONPROGRAMFILES,0,0);
 return TRUE;
 case 105://"96.Allocate of GUID folders: Recent.");
  SendMessage(::hWnd,IDM_GUIDFOLDERS_RECENT,0,0);
 return TRUE;
 case 106://"97.Allocate of GUID folders: SendTo.");
  SendMessage(::hWnd,IDM_GUIDFOLDERS_SENDTO,0,0);
 return TRUE;
 case 107://"98.Allocate of GUID folders: System.");
  SendMessage(::hWnd,IDM_GUIDFOLDERS_SYSTEM,0,0);
 return TRUE;
 case 108://"99.Allocate of GUID folders: Windows.");
  SendMessage(::hWnd,IDM_GUIDFOLDERS_WINDOWS,0,0);
 return TRUE;
 case 109://"100.Allocate of virtual GUID folders: My Computer.");
  SendMessage(::hWnd,IDM_VIRTUALGUIDFOLDERS_MYCOMPUTER,0,0);
 return TRUE;
 case 110://"101.Allocate of virtual GUID folders: Desktop.");
  SendMessage(::hWnd,IDM_VIRTUALGUIDFOLDERS_DESKTOP,0,0);
 return TRUE;
 case 111://"102.Allocate of virtual GUID folders: Control Panel.");
  SendMessage(::hWnd,IDM_VIRTUALGUIDFOLDERS_CONTROLPANEL,0,0);
 return TRUE;
 case 112://"103.Allocate of virtual GUID folders: Network.");
  SendMessage(::hWnd,IDM_VIRTUALGUIDFOLDERS_NETWORK,0,0);
 return TRUE;
 case 113://"104.Allocate of virtual GUID folders: Recycle Bin.");
  SendMessage(::hWnd,IDM_VIRTUALGUIDFOLDERS_RECYCLEBIN,0,0);
 return TRUE;
 case 114://"105.Allocate of virtual GUID folders: Internet.");
  SendMessage(::hWnd,IDM_VIRTUALGUIDFOLDERS_INTERNET,0,0);
 return TRUE;
 case 115://"106.Allocate of virtual GUID folders: Printers.");
  SendMessage(::hWnd,IDM_VIRTUALGUIDFOLDERS_PRINTERS,0,0);
 return TRUE;
 case 116://"107.IP4 scaner: run scan net process.");
  vrtlPanels::AttachPanel$12(&panel[Panel::iActivePanel],vrtlPanels::numIP4Plgn,L"\\\\?\\UNC\\");
 return TRUE;
 case 117://"108.IP4 scaner: link to net node.");
  wchar_t s[64];MyStringCpy(s,MAX_PATH,L"\\\\?\\UNC\\");
  StringCchPrintf(&s[8],32,L"%d%s%d%s%d%s%d",data[0],L".",data[1],L".",data[2],L".",data[3]);
  int l;l=MyStringLength(s,64);
  s[l++]='\\';s[l++]='*';s[l]=0;
  vrtlPanels::AttachPanel$12(&panel[Panel::iActivePanel],vrtlPanels::numIP4Plgn,s);
 return TRUE;
 case 118://"109.IP4 scaner: call search.");
  vrtlPanels::AttachPanel$12(&panel[Panel::iActivePanel],vrtlPanels::numIP4Plgn,L"\\\\?\\UNC\\");
 return TRUE;
 case 119://"110.IP4 scaner: call node search.");
  MyStringCpy(s,MAX_PATH,L"\\\\?\\UNC\\");
  StringCchPrintf(&s[8],32,L"%d%s%d%s%d%s%d",data[0],L".",data[1],L".",data[2],L".",data[3]);
  l=MyStringLength(s,64);
  s[l++]='\\';s[l++]='*';s[l]=0;
  vrtlPanels::AttachPanel$12(&panel[Panel::iActivePanel],vrtlPanels::numIP4Plgn,s);
 return TRUE;
 case 120://"111.Help system: Show contents.");
  SendMessage(::hWnd,IDM_HELP_CONTENTS,0,0);
 return TRUE;
 case 121://"112.Help system: Show index.");
  SendMessage(::hWnd,IDM_HELP_INDEX,0,0);
 return TRUE;
 case 122://"113.Help system: Show search dialog.");
  SendMessage(::hWnd,IDM_HELP_SEARCH,0,0);
 return TRUE;
 case 123://"114.Help system: Plugin writers: Show contents.");
  SendMessage(::hWnd,IDM_HELP_PLUGIN_CONTENTS,0,0);
 return TRUE;
 case 124://"115.Help system: Plugin writers: Show index.");
  SendMessage(::hWnd,IDM_HELP_PLUGIN_INDEX,0,0);
 return TRUE;
 case 125://"116.Help system: Plugin writers: Show search dialog.");
  SendMessage(::hWnd,IDM_HELP_PLUGIN_SEARCH,0,0);
 return TRUE;
 case 126://"117.Help system: Show about dialog.");
  SendMessage(::hWnd,IDM_HELP_ABOUT,0,0);
 return TRUE;
 }
return FALSE;
}