#include "windows.h"
#include "shlobj.h"
#include "MyShell.h"

extern "C"
{
LPITEMIDLIST GetNextItem(LPITEMIDLIST pidl)
{USHORT nLen; 
	if((nLen = pidl->mkid.cb) == 0)return NULL;     
    return (LPITEMIDLIST) (((LPBYTE) pidl) + nLen);
}

UINT GetItemCount(LPITEMIDLIST pidl)
{USHORT nLen;UINT nCount = 0;
    while((nLen = pidl->mkid.cb) != 0)
	{	pidl = GetNextItem (pidl);
        nCount++;
    }return nCount;
}

LPITEMIDLIST DuplicateItem(LPMALLOC pMalloc, LPITEMIDLIST pidl)
{
USHORT nLen;LPITEMIDLIST pidlNew;
	nLen = pidl->mkid.cb;
    if (nLen == 0)return NULL; 
    pidlNew = (LPITEMIDLIST) pMalloc->Alloc(nLen + sizeof (USHORT));
    if (pidlNew == NULL)return NULL;
     CopyMemory (pidlNew, pidl, nLen);
    *((USHORT*) (((LPBYTE) pidlNew) + nLen)) = 0;
    return pidlNew;
}

UINT maxAppndMenuItemID;
__declspec (dllexport) BOOL DoExplorerMenu(HWND hwnd,LPWSTR pszPath,POINT *pt,AddtnMenuItems* addItems)
{
LPMALLOC pMalloc;
LPSHELLFOLDER psfFolder, psfNextFolder;
LPITEMIDLIST pidlMain, pidlItem, pidlNextItem, *ppidl;
LPCONTEXTMENU pContextMenu;
CMINVOKECOMMANDINFOEX ici;
ULONG ulCount, ulAttr;
WCHAR tchPath[MAX_PATH];
WCHAR wchPath[MAX_PATH];    
UINT nCount, nCmd;
BOOL bResult,bCoInitialize=FALSE;
HRESULT hResult;
HMENU hMenu;
POINT point={pt->x,pt->y};
	//
    // Make sure the file name is fully qualified and in Unicode format.
    //
    GetFullPathName(pszPath, sizeof (tchPath) / sizeof (WCHAR), tchPath, NULL);
 
    //if(IsTextUnicode(tchPath, lstrlen (tchPath), NULL))
        MyStringCpy(wchPath, MAX_PATH, (WCHAR*)tchPath);
    //else
    //   MultiByteToWideChar(AreFileApisANSI()?CP_ACP:CP_OEMCP, 0, pszPath, -1, wchPath,
    //                       sizeof (wchPath) / sizeof (WCHAR));
 
    //
    // Get pointers to the shell's IMalloc interface and the desktop's
    // IShellFolder interface.
    //
    bResult = FALSE;
 
    if(!SUCCEEDED(SHGetMalloc(&pMalloc)))
        return bResult;
 
    if(!SUCCEEDED(SHGetDesktopFolder(&psfFolder)))
	{	pMalloc->Release();
        return bResult;
    }
 
    //
    // Convert the path name into a pointer to an item ID list (pidl).
    //
	hResult = psfFolder->ParseDisplayName(hwnd, NULL, wchPath, &ulCount, &pidlMain, &ulAttr);
	if(0x800401f0==hResult)//�� ��� ���������� ����� CoInitialize.
	{	bCoInitialize=TRUE;
		CoInitialize(NULL);
		hResult = psfFolder->ParseDisplayName(hwnd, NULL, wchPath, &ulCount, &pidlMain, &ulAttr);
	}
    if(SUCCEEDED(hResult) && (pidlMain != NULL))
	{	if(nCount = GetItemCount(pidlMain))
		{	// nCount must be > 0
            // Initialize psfFolder with a pointer to the IShellFolder
            // interface of the folder that contains the item whose context
            // menu we're after, and initialize pidlItem with a pointer to
            // the item's item ID. If nCount > 1, this requires us to walk
            // the list of item IDs stored in pidlMain and bind to each
            // subfolder referenced in the list.
            //
            pidlItem = pidlMain;
 
            while(--nCount)
			{   //
                // Create a 1-item item ID list for the next item in pidlMain.
                //
                pidlNextItem = DuplicateItem(pMalloc, pidlItem);
                if(pidlNextItem == NULL)
				{	pMalloc->Free(pidlMain);
                    psfFolder->Release();
                    pMalloc->Release();
					if(bCoInitialize)
						CoUninitialize();
                    return bResult;
                }
 
                //
                // Bind to the folder specified in the new item ID list.
                //
                if(!SUCCEEDED(psfFolder->BindToObject(pidlNextItem,
						NULL, IID_IShellFolder, (void**)&psfNextFolder)))
				{	pMalloc->Free(pidlNextItem);
                    pMalloc->Free(pidlMain);
                    psfFolder->Release();
                    pMalloc->Release();
					if(bCoInitialize)
						CoUninitialize();
                    return bResult;
                }
 
                //
                // Release the IShellFolder pointer to the parent folder
                // and set psfFolder equal to the IShellFolder pointer for
                // the current folder.
                //
                psfFolder->Release();
                psfFolder = psfNextFolder;
 
                //
                // Release the storage for the 1-item item ID list we created
                // just a moment ago and initialize pidlItem so that it points
                // to the next item in pidlMain.
                //
                pMalloc->Free(pidlNextItem);
                pidlItem = GetNextItem(pidlItem);
            }
 
            //
            // Get a pointer to the item's IContextMenu interface and call
            // IContextMenu::QueryContextMenu to initialize a context menu.
            //
            ppidl = &pidlItem;
            if(SUCCEEDED(psfFolder->GetUIObjectOf(hwnd,1,(LPCITEMIDLIST*)ppidl,
				IID_IContextMenu,NULL,(void**)&pContextMenu)))
			{	hMenu = CreatePopupMenu();
                if(SUCCEEDED(pContextMenu->QueryContextMenu(hMenu,
								0, 1, 0x7FFF, CMF_EXPLORE)))
				{	maxAppndMenuItemID=NULL;
					if(addItems)
					{	AddtnMenuItems* pits = addItems;
						int iAddIts=0;
						do	{	iAddIts++;	
								pits = pits->pNext;
							} while(pits);

						int menuCnts = GetMenuItemCount(hMenu);
						for(int m=0; m<menuCnts; m++)
						{	UINT id = GetMenuItemID(hMenu,m);
							if(id>maxAppndMenuItemID)
							if(id<UINT_MAX-iAddIts-1)
								maxAppndMenuItemID = id;
						}
						pits = addItems;
						iAddIts = 1;
						do
						{	if(maxAppndMenuItemID+iAddIts>UINT_MAX-1) break;
							AppendMenu(hMenu,MF_STRING,maxAppndMenuItemID+iAddIts,pits->itemStr);
							pits = pits->pNext;
							++iAddIts;
						} while(pits);
					}

					ClientToScreen(hwnd, &point); 
                    //
                    // Display the context menu.
                    //
                    nCmd = TrackPopupMenu(hMenu, TPM_LEFTALIGN |
                        TPM_LEFTBUTTON | TPM_RIGHTBUTTON | TPM_RETURNCMD,
                        point.x, point.y, 0, hwnd, NULL);
 
                    //
                    // If a command was selected from the menu, execute it.
                    //
                    if(nCmd)
					{	if(addItems && nCmd>maxAppndMenuItemID-1)
						{	AddtnMenuItems* pSelIt = addItems;
							for(UINT i=0; i<nCmd-maxAppndMenuItemID-1; i++)
								pSelIt=pSelIt->pNext;
#pragma message("Shu yerga ham bir qarab qo'y: Utility.cpp 910")
//							SendMessage(panel[pSelIt->iPan].GetHWND(),WM_COMMAND,pSelIt->iMsg,pSelIt->iPanItem);
							bResult = TRUE;
						}
						else
						{	POINT pt={0,0};
							ici.cbSize          = sizeof(CMINVOKECOMMANDINFOEX);
							ici.fMask           = 0;
							ici.fMask           = 0;
							ici.hwnd            = hwnd;
							ici.lpVerb          = LPCSTR(nCmd - 1);
							ici.lpVerbW         = MAKEINTRESOURCE(nCmd - 1);
							ici.lpParameters    = NULL;
							ici.lpParametersW   = NULL;
							ici.lpDirectory     = NULL;
							ici.lpDirectoryW    = NULL;
							ici.nShow           = SW_SHOWNORMAL;
							ici.dwHotKey        = 0;
							ici.hIcon           = NULL;
							ici.lpTitle         = NULL;
							ici.lpTitleW        = NULL;
							ici.ptInvoke        = pt;
							if(SUCCEEDED(pContextMenu->InvokeCommand((CMINVOKECOMMANDINFO*)&ici)))
								bResult = TRUE;
				}	}	}
                DestroyMenu(hMenu);
                pContextMenu->Release();
		}	}
        pMalloc->Free(pidlMain);
    }
 
    //
    // Clean up and return.
    //
    psfFolder->Release();
    pMalloc->Release();
 
	if(bCoInitialize)
		CoUninitialize();

	return bResult;
}

/*__declspec (dllexport) BOOL GetOleClipboardPasteState()
{
BOOL bPaste=FALSE;
	HRESULT hr = CoInitializeEx(NULL,COINIT_MULTITHREADED);//if(OleInitialize(NULL) != S_OK)return FALSE;
	if(!(S_OK==hr || S_FALSE==hr))
	{	CoUninitialize();
		hr = CoInitializeEx(NULL,COINIT_MULTITHREADED);
	}	
	if(S_OK==hr || S_FALSE==hr)
	{	IDataObject *dataObj=NULL;
		OleGetClipboard(&dataObj);
		if(dataObj)
		{	FORMATETC fe;STGMEDIUM stm;
			fe.cfFormat = RegisterClipboardFormat(CFSTR_PREFERREDDROPEFFECT);
			fe.tymed = TYMED_HGLOBAL;
			fe.lindex = -1;
			fe.ptd = 0;
			fe.dwAspect = DVASPECT_CONTENT;
			if(S_OK==dataObj->GetData(&fe, &stm))
			{	if(NULL!=stm.hGlobal)
				{	DWORD *dwTypeOfOperation = (DWORD*)GlobalLock(stm.hGlobal);
					if(dwTypeOfOperation)
					{	if(*dwTypeOfOperation == DROPEFFECT_MOVE)
							bPaste = TRUE;
						GlobalUnlock(stm.hGlobal);
				}	}
				ReleaseStgMedium(&stm);
		}	}
		CoUninitialize();
	}
	return bPaste;
}*/

__declspec (dllexport) BOOL GetOleClipboardPasteState()
{
BOOL bPaste=FALSE;
	UINT uFmtDROPEFFECT_MOVE = RegisterClipboardFormat(CFSTR_PREFERREDDROPEFFECT);
	HGLOBAL hglb = GetClipboardData(uFmtDROPEFFECT_MOVE);
	DWORD *pdw = (DWORD*)GlobalLock(hglb);
	if(2==(*pdw))bPaste=TRUE;// 2 if cut or 5 if copy
	else bPaste=FALSE;//if(5==(*pdw))
	GlobalUnlock(hglb);
	return bPaste;
}

}