#include "windows.h"

#define DLLEXP __declspec(dllexport)

#define MYBTN_CLASSNAME_C L"My_button_class_C"

#define BTN_ADJ_HOR_STYLE	0
#define BTN_ADJ_VER_LSTYLE	0x0001
#define BTN_ADJ_VER_RSTYLE	0x0002

typedef struct DLLEXP tMyButton
{	wchar_t     caption[MAX_PATH];
	HWND		hWnd,hWndPrnt;
	WORD		msgId;
	short		toggleState;
	int			captionLen,xPos,yPos,width,height;
	int			type;
} MyButton;

extern LRESULT CALLBACK BtnWndProc(HWND,UINT,WPARAM,LPARAM);
extern DLLEXP MyButton* MyButtonInit(HWND,wchar_t*,WORD,int,int,int,int,int);
extern DLLEXP MyButton* MyButtonFrRCBtn(HWND,WORD,int);
extern BOOL	MyButtonSetFont(MyButton*);
extern VOID	DLLEXP MyButtonDestroy(MyButton*);
extern __declspec (dllexport) VOID SetFnt(HFONT*);

__inline HWND DLLEXP MyButtonGetHWND(MyButton* btn)
{	if(!btn)return NULL;
	return btn->hWnd;
}