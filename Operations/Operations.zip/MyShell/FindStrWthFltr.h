#ifndef __FindStrWthFltr_H__
#define __FindStrWthFltr_H__

#define DLLEXP __declspec(dllexport)

/*class FindStrWthFltr
{
public:
			FindStrWthFltr(char[]);
		   ~FindStrWthFltr();
	bool	CheckNameAndExt(char*);
	void	PrintState();

	int		GetNumStrs(){return numStrs;}
	char*   GetSubstr(int i){return &fullStr[pStr[i].pos];}

typedef enum TSbStrType
{	path,
	excptPath,
	filtr,
	excptFiltr
} SbStrType;

typedef struct TSubStr
{	int			pos;
	int			fltrExtPos;
	int			fltrNumAsterics;
	int			fltrNumQuestns;
	int			fltrExtNumAsterics;
	int			fltrExtNumQuestns;
	int			ln;
	SbStrType	type;
} SubStr;

typedef struct TFStr
{	TFStr():pos(0),iSubStrs(0),pSubStr(0){}
	int pos;
	int iSubStrs;//probelliklar:
	SubStr *pSubStr;
} FStr;

	int GetFullStrLn(){return lnFullStr;}
protected:

	int  numStrs;
	FStr *pStr;
	char *fullStr;
	int  lnFullStr;

	bool CheckNameWithSubstrFiltr(SubStr*,char*,char*);
};*/

class DLLEXP FindStrWthFltr
{
public:
			FindStrWthFltr(wchar_t[]);
		   ~FindStrWthFltr();
	bool	CheckNameAndExt(wchar_t*,wchar_t* onlyName=0);
	void	PrintState();

	int		GetNumStrs(){return numStrs;}
	wchar_t *GetSubstr(int i){return &fullStr[pStr[i].pos];}

typedef enum TSbStrType
{	path,
	excptPath,
	filtr,
	excptFiltr
} SbStrType;

typedef struct TSubStr
{	int			pos;
	int			fltrExtPos;
	int			fltrNumAsterics;
	int			fltrNumQuestns;
	int			fltrExtNumAsterics;
	int			fltrExtNumQuestns;
	int			ln;
	SbStrType	type;
} SubStr;

typedef struct TFStr
{	TFStr():pos(0),iSubStrs(0),pSubStr(0){}
	int pos;
	int iSubStrs;//probelliklar:
	SubStr *pSubStr;
} FStr;

	int GetFullStrLn(){return lnFullStr;}
protected:

	int  numStrs;
	FStr *pStr;
	wchar_t *fullStr;
	int  lnFullStr;

	bool CheckNameWithSubstrFiltr(SubStr*,wchar_t*,wchar_t*);
};

class DLLEXP FindStrWthFltrA
{
public:
			FindStrWthFltrA(const char[]);
		   ~FindStrWthFltrA();
	bool	CheckNameAndExt(char*);
	void	PrintState();

	int		GetNumStrs(){return numStrs;}
	char*   GetSubstr(int i){return &fullStr[pStr[i].pos];}

typedef enum TSbStrType
{	path,
	excptPath,
	filtr,
	excptFiltr
} SbStrType;

typedef struct TSubStr
{	int			pos;
	int			fltrExtPos;
	int			fltrNumAsterics;
	int			fltrNumQuestns;
	int			fltrExtNumAsterics;
	int			fltrExtNumQuestns;
	int			ln;
	SbStrType	type;
} SubStr;

typedef struct TFStr
{	TFStr():pos(0),iSubStrs(0),pSubStr(0){}
	int pos;
	int iSubStrs;//probelliklar:
	SubStr *pSubStr;
} FStr;

	int GetFullStrLn(){return lnFullStr;}
protected:

	int  numStrs;
	FStr *pStr;
	char *fullStr;
	int  lnFullStr;

	bool CheckNameWithSubstrFiltr(SubStr*,char*,char*);
};

#endif