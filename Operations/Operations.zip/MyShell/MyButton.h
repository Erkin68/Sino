#include "windows.h"

#define DLLEXP __declspec(dllexport)

#define MYBTN_CLASSNAME L"My_button_class"

#define BTN_ADJ_HOR_STYLE	0
#define BTN_ADJ_VER_LSTYLE	0x0001
#define BTN_ADJ_VER_RSTYLE	0x0002


extern LRESULT CALLBACK BtnWndProc(HWND,UINT,WPARAM,LPARAM);


class DLLEXP MyButton
{
static ATOM		MyRegisterClass(HINSTANCE);
static ATOM		regClass;

static HBITMAP hBmpSimpleOld;
static HBITMAP hBmpHoveredOld;
static HBITMAP hBmpHoveredPushedOld;
static HDC hDCSimple;
static HDC hDCHovered;
static HDC hDCHoveredPushed;
static HBRUSH hBrsh;
//static HBRUSH hBrshHatch;
static HPEN hPen;

static MyButton *pFocusedBtn;
static int mRef;

friend LRESULT CALLBACK BtnWndProc(HWND,UINT,WPARAM,LPARAM);

public:
				MyButton(HWND,wchar_t*,WORD,int,int,int,int,int);
				MyButton();
			   ~MyButton();
	BOOL		Init(HWND,wchar_t*,WORD,int,int,int,int,int);
	BOOL		SetFont();

	BOOL		Draw(HDC);
	HWND		GetHWND();
	VOID		Destroy();

private:

	wchar_t     caption[MAX_PATH];
	HWND		hWnd,hWndPrnt;
	WORD		msgId;
//	struct
//	{	short oldPressedAndLeaved	:1;
//		short toggleState			:2;
//	};
	//short		oldPressedAndLeaved;
	short		toggleState;
	int			captionLen,xPos,yPos,width,height;
	int			type;//
};

inline HWND DLLEXP MyButton::GetHWND(){return hWnd;}
