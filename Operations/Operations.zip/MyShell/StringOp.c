#pragma comment(lib, "Ws2_32.lib")


#include "windows.h"
#include "strsafe.h"
#include "commctrl.h"
#include <malloc.h>


#define _CRT_SECURE_NO_WARNINGS



__declspec (dllexport) int MyStringCpyA(char* buf, int mx, char* src)
{	register int l=-1;
	if(!src)
	{	buf[0]=0;
		return 0;
	}
	while(++l<mx)
	{	buf[l] = src[l];
		if(!src[l]) break;//('\0'==src[l])
	}
	if(buf[l])//0 bo'lmasa;
	if(l>=mx)
		buf[l] = 0;
	return l;
}

__declspec (dllexport) int MyStringCpy(wchar_t* buf, int mx, wchar_t* src)
{	register int l=-1;
	if(!src)
	{	buf[0]=0;
		return 0;
	}	
	while(++l<mx)
	{	buf[l] = src[l];
		if(!src[l]) break;//('\0'==src[l])
	}
	if(buf[l])//0 bo'lmasa;
	if(l>=mx)
		buf[l] = 0;
	return l;
}

__declspec (dllexport) int MyStringLengthA(char* buf, int mx)
{	register int l=-1;
	if(!buf)return 0;
	if(!buf[0])return 0;
	while(++l<mx)
	{	if(!buf[l])//(0==buf[l])
			return l;
		if(l>=mx)
			return l;
	};
	return l;
}

__declspec (dllexport) int MyStringLength(wchar_t* buf, int mx)
{	register int l=-1;
	if(!buf)return 0;
	if(!buf[0])return 0;
	while(++l<mx)
	{	if(!buf[l])//(0==buf[l])
			return l;
		if(l>=mx)
			return l;
	};
	return l;
}

__declspec (dllexport) VOID ConvertToLittleA(char *txt, int ln)
{	register int i,LN = ln>0?ln:MAX_PATH;
	for(i=0; i<LN; i++)
	{	if(!ln)
		if(!txt[i])//('\0'==txt[i])
			return;
		if(txt[i]<91)
		{	if(txt[i]>64)
				txt[i]+=32;
		} else
		{	if(txt[i]<224)
			{	if(txt[i]>191)
				txt[i]+=32;
}	}	}	}

__declspec (dllexport) VOID ConvertToLittle(wchar_t *txt, int ln)
{	register int i,LN = ln>0?ln:MAX_PATH;
	for(i=0; i<LN; i++)
	{	if(!ln)
		if(!txt[i])//('\0'==txt[i])
			return;
		if(txt[i]<91)
		{	if(txt[i]>64)
				txt[i]+=32;
		} else
		{	if(txt[i]<224)
			{	if(txt[i]>191)
				txt[i]+=32;
}	}	}	}

__declspec (dllexport) char* ConvertToLittleRA(char *txt, int ln)
{	
static char R[MAX_PATH];
	register int i,LN = ln>0?ln:MAX_PATH;
	for(i=0; i<LN; i++)
	{	R[i]=txt[i];
		if(!ln)
		if(!R[i])//('\0'==txt[i])
			return R;
		if(R[i]<91)
		{	if(R[i]>64)
				R[i]+=32;
		} else
		{	if(R[i]<224)
			{	if(R[i]>191)
				R[i]+=32;
	}	}	}
	return R;
}

__declspec (dllexport) wchar_t* ConvertToLittleR(wchar_t *txt, int ln)
{	
static wchar_t R[MAX_PATH];
	register int i,LN = ln>0?ln:MAX_PATH;
	for(i=0; i<LN; i++)
	{	R[i]=txt[i];
		if(!ln)
		if(!R[i])//('\0'==txt[i])
			return R;
		if(R[i]<91)
		{	if(R[i]>64)
				R[i]+=32;
		} else
		{	if(R[i]<224)
			{	if(R[i]>191)
				R[i]+=32;
	}	}	}
	return R;
}

__declspec (dllexport) unsigned __int64 MyAtoU64A(char *s)
{
register unsigned __int64 rt=0;
char *ps = s;
	while(*ps!=0)
	{	if(*ps < '0')
			return 0;
		if(*ps > '9')
			return 0;
		rt = rt*10 + (*ps - '0');
		ps++;
	}
	return rt;
}

__declspec (dllexport) unsigned __int64 MyAtoU64(wchar_t *s)
{
register unsigned __int64 rt=0;
wchar_t *ps = s;
	while(*ps!=0)
	{	if(*ps < '0')
			return 0;
		if(*ps > '9')
			return 0;
		rt = rt*10 + (*ps - '0');
		ps++;
	}
	return rt;
}

__declspec (dllexport) BOOL MyU64ToA(char* st,int sLen,unsigned __int64 u)
{
register int i,l=0;
register unsigned __int64 delit = u;
static char s[32];
	if(!u)
	{	st[0] = '0';
		st[1] = 0;
		return TRUE;
	}

	while(delit)
	{	s[l++] = delit % 10 + '0';
		delit /= 10;
	}
	for(i=0; i<l; i++)
		st[i] = s[l-i-1];
	st[l] = 0;
	return TRUE;
}

__declspec (dllexport) BOOL MyU64To(wchar_t* st,int sLen,unsigned __int64 u)
{
register int i,l=0;
register unsigned __int64 delit = u;
static wchar_t s[32];
	if(!u)
	{	st[0] = '0';
		st[1] = 0;
		return TRUE;
	}

	while(delit)
	{	s[l++] = delit % 10 + '0';
		delit /= 10;
	}
	for(i=0; i<l; i++)
		st[i] = s[l-i-1];
	st[l] = 0;
	return TRUE;
}

__declspec (dllexport) char* MyStringAddModulePathA(char* name)
{
static char path[MAX_PATH]="";
static char* pend;int l=0;
	if(!path[0])//('\0'==path[0])
	{	l=GetModuleFileNameA(NULL,path,MAX_PATH);
		pend = strrchr(path,'\\')+1;
	}
	if(!pend)pend=&path[l];
	MyStringCpyA(pend,MAX_PATH-1,name);
	return path;
}

__declspec (dllexport) wchar_t* MyStringAddModulePath(wchar_t* name)
{
static wchar_t path[MAX_PATH]=L"";
static wchar_t* pend;int l=0;
	if(!path[0])//('\0'==path[0])
	{	l=GetModuleFileName(NULL,path,MAX_PATH);
		pend = wcsrchr(path,'\\')+1;
	}
	if(!pend)pend=&path[l];
	MyStringCpy(pend,MAX_PATH-1,name);
	return path;
}

__declspec (dllexport) int MyStringCatA(char* buf, int mx, char* src)
{	register int l1=-1,l=-1;
	while(++l<mx)
	{	if(!buf[l]) break;//('\0'==buf[l])
		if(l>=mx) break;
	}
	while(++l1<mx-1)
	{	buf[l+l1] = src[l1];
		if(!src[l1]) break;//('\0'==src[l1])
	}
	if(buf[l+l1])//0 bo'lmasa;
	if(l1>=mx)
		buf[l+(--l1)] = 0;
	return l1;
}

__declspec (dllexport) int MyStringCat(wchar_t* buf, int mx, wchar_t* src)
{	register int l1=-1,l=-1;
	while(++l<mx)
	{	if(!buf[l]) break;//('\0'==buf[l])
		if(l>=mx) break;
	}
	while(++l1<mx-1)
	{	buf[l+l1] = src[l1];
		if(!src[l1]) break;//('\0'==src[l1])
	}
	if(buf[l+l1])//0 bo'lmasa;
	if(l1>=mx)
		buf[l+(--l1)] = 0;
	return l1;
}

__declspec (dllexport) int MyStringEraseEndAndCatA(char* buf, int mx, char* src)
{	register int l1=-1,l=-1;
	while(++l<mx)
	{	if(!buf[l]) break;//(0==buf[l])
		if(l>=mx) break;
	}
	if(l>0) --l;
	while(++l1<mx-1)
	{	buf[l+l1] = src[l1];
		if(!src[l1]) break;//(0==src[l1]) 
	}
	if(buf[l+l1])
	if(l1>=mx)
		buf[l+(--l1)] = 0;
	return l1;
}

__declspec (dllexport) int MyStringEraseEndAndCat(wchar_t* buf, int mx, wchar_t* src)
{	register int l1=-1,l=-1;
	while(++l<mx)
	{	if(!buf[l]) break;//(0==buf[l])
		if(l>=mx) break;
	}
	if(l>0) --l;
	while(++l1<mx-1)
	{	buf[l+l1] = src[l1];
		if(!src[l1]) break;//(0==src[l1]) 
	}
	if(buf[l+l1])
	if(l1>=mx)
		buf[l+(--l1)] = 0;
	return l1;
}

__declspec (dllexport) char *MyStringFindFirstUnmatchA(char *dst, char *src, int ln)
{
register int i;
	for(i=0; i<ln; i++)
	{	if(dst[i] ^ src[i])//(dst[i] != src[i])
			return &dst[i];
	}
	return NULL;
}

__declspec (dllexport) wchar_t *MyStringFindFirstUnmatch(wchar_t *dst, wchar_t *src, int ln)
{
register int i;
	for(i=0; i<ln; i++)
	{	if(dst[i] ^ src[i])//(dst[i] != src[i])
			return &dst[i];
	}
	return NULL;
}

__declspec (dllexport) BOOL MyStrCmpNA(char *str0, char *str1, int n)
{
	register int i,dw,dn = n>>2;//n/4;
	register int d = n & 0x0003;//n%4;
	DWORD *p0 = (DWORD*)str0;
	DWORD *p1 = (DWORD*)str1;
	for(dw=0; dw<dn; dw++)
	{	if(p0[dw] ^ p1[dw])//(p0[dw] != p1[dw])
			return FALSE;
	}
	for(i=n-d; i<n; i++)
	{	if(str0[i] ^ str1[i])//(str0[i] != str1[i])
			return FALSE;
	}
	return TRUE;
}

__declspec (dllexport) BOOL MyStrCmpNW(wchar_t *str0, wchar_t *str1, int n)
{
	register int i,dw,dn = n>>2;//n/4;
	register int d = n & 0x0003;//n%4;
	DWORD *p0 = (DWORD*)str0;
	DWORD *p1 = (DWORD*)str1;
	for(dw=0; dw<dn; dw++)
	{	if(p0[dw] ^ p1[dw])//(p0[dw] != p1[dw])
			return FALSE;
	}
	for(i=n-d; i<n; i++)
	{	if(str0[i] ^ str1[i])//(str0[i] != str1[i])
			return FALSE;
	}
	return TRUE;
}

__declspec (dllexport) BOOL IsBin(char ch)
{
	if(ch >= '0')
	if(ch <= '9')
		return TRUE;
	if(ch >= 'A')
	if(ch <= 'F')
		return TRUE;
	if(ch >= 'a')
	if(ch <= 'f')
		return TRUE;
	return FALSE;
}

/*BOOL IsBin(wchar_t ch)
{
	if(ch >= '0')
	if(ch <= '9')
		return TRUE;
	if(ch >= 'A')
	if(ch <= 'F')
		return TRUE;
	if(ch >= 'a')
	if(ch <= 'f')
		return TRUE;
	return FALSE;
}*/

__declspec (dllexport) char* MyStrCmpNNA(char *str0, char *str1, int N, int n)
{
int i,f,s,fdw;unsigned __int32 *p0;

	register int dw_n = n >> 2;// / 4;
	register int rem_n  = n & 0x0003;// % 4;
	register int dwF = (N - n + 1) >> 2;// / 4;

	unsigned __int32 *p1 = (unsigned __int32*)str1;

	for(s=0; s<4; s++)
	{	p0 = (unsigned __int32*)str0;
		for(f=0; f<dwF; f++)
		{	for(fdw=0; fdw<dw_n; fdw++)
			{	if(p0[fdw] != p1[fdw])//(p0[dw] ^ p1[dw])
					goto Cont;//return FALSE;
			}
			for(i=n-rem_n; i<n; i++)
			{	if(str0[f*4+i] != str1[i])//(str0[i] ^ str1[i])
					goto Cont;//return FALSE;
			}
			return (char*)p0;
		 Cont:
			p0++;// = (DWORD*)(++str0);
		}
		str0++;
	}
	return 0;
}

__declspec (dllexport) char* MyStrCmpBinNA(char *str0, char *str1, int N, int n)//2-str is binary representation;
{	//n num of symbols in str0, for each pair in str1!!!
register int i;
char *s = (char*)_malloca(n/2);
char *ps = s;
	for(i=0; i<n; i++)
	{	if(str1[2*i]>='0' && str1[2*i]<='9')
			*ps = str1[2*i] - '0';
		else if(str1[2*i]>='A' && str1[2*i]<='F')
			*ps = str1[2*i] - 'A' + 10;
		else if(str1[2*i]>='a' && str1[2*i]<='f')
			*ps = str1[2*i] - 'a' + 10;
		ps++;
	}
	ps = MyStrCmpNNA(str0, s, N, n);
	_freea(s);
	return ps;
}

__declspec (dllexport) wchar_t* MyStrCmpNNW(wchar_t *str0, wchar_t *str1, int N, int n)
{
int i,fdw,f,s;unsigned __int32 *p0;
	register int dw_n = n >> 2;// / 4;
	register int rem_n  = n & 0x0003;// % 4;
	register int dwF = (N - n + 1) >> 2;// / 4;

	unsigned __int32 *p1 = (unsigned __int32*)str1;

	for(s=0; s<4; s++)
	{	p0 = (unsigned __int32*)str0;
		for(f=0; f<dwF; f++)
		{	for(fdw=0; fdw<dw_n; fdw++)
			{	if(p0[fdw] != p1[fdw])//(p0[dw] ^ p1[dw])
					goto Cont;//return FALSE;
			}
			for(i=n-rem_n; i<n; i++)
			{	if(str0[f*4+i] != str1[i])//(str0[i] ^ str1[i])
					goto Cont;//return FALSE;
			}
			return (wchar_t*)p0;
		 Cont:
			p0++;// = (DWORD*)(++str0);
		}
		str0++;
	}
//	in int64 size calculate, very small effect:
/*	register int qw_n = n >> 3;// / 8;
	register int rem_n  = n & 0x0007;// % 8;
	register int qwF = (N - n + 1) >> 3;// / 8;

	unsigned __int64 *p1 = (unsigned __int64*)str1;

for(int s=0; s<8; s++)
{	unsigned __int64 *p0 = (unsigned __int64 *)str0;
	for(register int f=0; f<qwF; f++)
	{	for(register int fqw=0; fqw<qw_n; fqw++)
		{	if(p0[fqw] ^ p1[fqw])
				goto Cont;
		}
		for(register int i=n-rem_n; i<n; i++)
		{	if(str0[f*8+i] ^ str1[i])
				goto Cont;
		}
		return (char*)p0;
	 Cont:
		p0++;
	}
	str0++;
}*/
	return 0;
}

__declspec (dllexport) wchar_t* MyStrCmpBinNW(wchar_t *str0, wchar_t *str1, int N, int n)//2-str is binary representation;
{	//n num of symbols in str0, for each pair in str1!!!
register int i;
wchar_t *s = (wchar_t*)_malloca(n);
wchar_t *ps = s;
	for(i=0; i<n; i++)
	{	if(str1[2*i]>='0' && str1[2*i]<='9')
			*ps = str1[2*i] - '0';
		else if(str1[2*i]>='A' && str1[2*i]<='F')
			*ps = str1[2*i] - 'A' + 10;
		else if(str1[2*i]>='a' && str1[2*i]<='f')
			*ps = str1[2*i] - 'a' + 10;
		ps++;
	}
	ps = MyStrCmpNNW(str0, s, N, n);
	_freea(s);
	return ps;
}

__declspec (dllexport) BOOL MyStrCmpNotRelUpRegNA(char *str0, char *str1, int n)//Upper registr unreleated;
{
register int i;
	for(i=0; i<n; i++)
	{	if(str0[i] >= 'A' && str0[i] <= 'Z')
		{	if(str0[i] ^ str1[i] && (str0[i]+32) ^ str1[i])//(str0[i] != str1[i] && str0[i]+32 != str1[i])
				return FALSE;
		}
		else if(str0[i] >= 'a' && str0[i] <= 'z')
		{	if(str0[i] ^ str1[i] && (str0[i]-32) ^ str1[i])//(str0[i] != str1[i] && str0[i]-32 != str1[i])
				return FALSE;
		}
		else if(str0[i] >= '�' && str0[i] <= '�')
		{	if(str0[i] ^ str1[i] && (str0[i]+32) ^ str1[i])//(str0[i] != str1[i] && str0[i]+32 != str1[i])
				return FALSE;
		}
		else if(str0[i] >= '�' && str0[i] <= '�')
		{	if(str0[i] ^ str1[i] && (str0[i]-32) ^ str1[i])//(str0[i] != str1[i] && str0[i]-32 != str1[i])
				return FALSE;
		}
		else if(str0[i] ^ str1[i])//(str0[i] != str1[i])
			return FALSE;
	}
	return TRUE;
}

__declspec (dllexport) BOOL MyStrCmpNotRelUpRegNW(wchar_t *str0, wchar_t *str1, int n)//Upper registr unreleated;
{
register int i;
	for(i=0; i<n; i++)
	{	if(str0[i] >= 'A' && str0[i] <= 'Z')
		{	if(str0[i] ^ str1[i] && (str0[i]+32) ^ str1[i])//(str0[i] != str1[i] && str0[i]+32 != str1[i])
				return FALSE;
		}
		else if(str0[i] >= 'a' && str0[i] <= 'z')
		{	if(str0[i] ^ str1[i] && (str0[i]-32) ^ str1[i])//(str0[i] != str1[i] && str0[i]-32 != str1[i])
				return FALSE;
		}
		else if(str0[i] >= '�' && str0[i] <= '�')
		{	if(str0[i] ^ str1[i] && (str0[i]+32) ^ str1[i])//(str0[i] != str1[i] && str0[i]+32 != str1[i])
				return FALSE;
		}
		else if(str0[i] >= '�' && str0[i] <= '�')
		{	if(str0[i] ^ str1[i] && (str0[i]-32) ^ str1[i])//(str0[i] != str1[i] && str0[i]-32 != str1[i])
				return FALSE;
		}
		else if(str0[i] ^ str1[i])//(str0[i] != str1[i])
			return FALSE;
	}
	return TRUE;
}

/*__declspec (dllexport) char* MyStrRChrN(char* src, int ln, char c, int n)
{
	int Ln = MyStringLength(src,ln);
int k=0;
	for(register int i=Ln-1; i>=0; i--)
	{	if(!(c^src[i]))//(c==src[i])
		{	if(++k>=n)
				return &src[i];
	}	}
	return NULL;
}*/

__declspec (dllexport) wchar_t* MyStrRChrN(wchar_t* src, int ln, wchar_t c, int n)
{
	int Ln = MyStringLength(src,ln);
	int i,k=0;
	for(i=Ln-1; i>=0; i--)
	{	if(!(c^src[i]))//(c==src[i])
		{	if(++k>=n)
				return &src[i];
	}	}
	return NULL;
}

__declspec (dllexport) VOID MyTimeToStringA(char *s, DWORD tick)
{
	register int hour = tick / 3600000;
	register int min = tick / 60000;
	register int sec = (tick / 1000) % 60;
	if(hour)
		StringCchPrintfA(s,MAX_PATH-1,"%.2d:%.2d:%.2d",hour,min,sec);
	else
	{	if(min)
			StringCchPrintfA(s,MAX_PATH-1,"%.2d:%.2d",min,sec);
		else
			StringCchPrintfA(s,MAX_PATH-1,"00:%.2d",sec);
}	}

__declspec (dllexport) VOID MyTimeToString(wchar_t *s, DWORD tick)
{
	register int hour = tick / 3600000;
	register int min = tick / 60000;
	register int sec = (tick / 1000) % 60;
	if(hour)
		StringCchPrintf(s,MAX_PATH-1,L"%.2d:%.2d:%.2d",hour,min,sec);
	else
	{	if(min)
			StringCchPrintf(s,MAX_PATH-1,L"%.2d:%.2d",min,sec);
		else
			StringCchPrintf(s,MAX_PATH-1,L"00:%.2d",sec);
}	}

__declspec (dllexport) int MyStringPrintDecSpaceA(char *str, __int64 d)
{
register __int64 D;char s[32],*ps,*pstr;
int q,q0,q1,q2;
	if(d)
	{	D = d; s[31]=0; ps = &s[30];
		while(D)
		{	q = D % 1000;
			q0 = q % 10;
			q1 = (q / 10) % 10;
			q2 = (q / 100) % 10;
			*ps-- = q0+48;
			*ps-- = q1+48;
			*ps = q2+48;
			D /= 1000;
			if(D){--ps; *ps-- = ' ';}
		}
		pstr = str;
		while(*ps=='0')
			ps++;
		while(ps<&s[31])
			*pstr++ = *ps++;
		*pstr++ = ' ';
		*pstr++ = 'b';
		*pstr = 0;
		return (int)(pstr - str);
	} else
	{	str[0] = '0';
		str[1] = ' ';
		str[2] = 'b';
		str[3] = 0;
		return 2;
}	}

__declspec (dllexport) int MyStringPrintDecSpace(wchar_t *str, __int64 d)
{
register __int64 D; wchar_t s[32],*ps,*pstr;
int q,q0,q1,q2;
	if(d)
	{	D = d; s[31]=0; ps = &s[30];
		while(D)
		{	q = D % 1000;
			q0 = q % 10;
			q1 = (q / 10) % 10;
			q2 = (q / 100) % 10;
			*ps-- = q0+48;
			*ps-- = q1+48;
			*ps = q2+48;
			D /= 1000;
			if(D){--ps; *ps-- = ' ';}
		}
		pstr = str;
		while(*ps=='0')
			ps++;
		while(ps<&s[31])
			*pstr++ = *ps++;
		*pstr++ = ' ';
		*pstr++ = 'b';
		*pstr = 0;
		return (int)(pstr - str);
	} else
	{	str[0] = '0';
		str[1] = ' ';
		str[2] = 'b';
		str[3] = 0;
		return 2;
}	}

__declspec (dllexport) int MyStringPrintDecSpace1(wchar_t *str, __int64 d)
{
register __int64 D; wchar_t s[32],*ps,*pstr;
int q,q0,q1,q2;
	if(d)
	{	D = d; s[31]=0; ps = &s[30];
		while(D)
		{	q = D % 1000;
			q0 = q % 10;
			q1 = (q / 10) % 10;
			q2 = (q / 100) % 10;
			*ps-- = q0+48;
			*ps-- = q1+48;
			*ps = q2+48;
			D /= 1000;
			if(D){--ps; *ps-- = ' ';}
		}
		pstr = str;
		while(*ps=='0')
			ps++;
		while(ps<&s[31])
			*pstr++ = *ps++;
		*pstr++ = ' ';
//		*pstr++ = 'b';
		*pstr = 0;
		return (int)(pstr - str);
	} else
	{	str[0] = '0';
		str[1] = ' ';
//		str[2] = 'b';
		str[3] = 0;
		return 2;
}	}

__declspec (dllexport) BOOL MyStringRemoveLastCharA(char *str,int maxLen, char ch)
{
register int i;
	for(i=0; i<maxLen; i++)
	{	if(!str[i])//(0==str[i])
		{	if(!(ch ^ str[i-1]))//(ch==str[i-1])
			{	str[i-1] = 0;
				return TRUE;
			}
			return FALSE;
	}	}
	return FALSE;
}

__declspec (dllexport) BOOL MyStringRemoveLastChar(wchar_t *str,int maxLen, wchar_t ch)
{
register int i;
	for(i=0; i<maxLen; i++)
	{	if(!str[i])//(0==str[i])
		{	if(!(ch ^ str[i-1]))//(ch==str[i-1])
			{	str[i-1] = 0;
				return TRUE;
			}
			return FALSE;
	}	}
	return FALSE;
}

__declspec (dllexport) BOOL MyStringRemoveLastCharCheckPreA(char *str,int maxLen, char ch0, char ch1)
{
register int i;
	for(i=0; i<maxLen; i++)
	{	if(!str[i])//(0==str[i])
		{	if(!(ch0 ^ str[i-1]))//(ch0==str[i-1])
			if(!(ch1 ^ str[i-2]))//(ch1==str[i-2])
			{	str[i-1] = 0;
				return TRUE;
			}
			return FALSE;
	}	}
	return FALSE;
}

__declspec (dllexport) BOOL MyStringRemoveLastCharCheckPre(wchar_t *str,int maxLen, wchar_t ch0, wchar_t ch1)
{
register int i;
	for(i=0; i<maxLen; i++)
	{	if(!str[i])//(0==str[i])
		{	if(!(ch0 ^ str[i-1]))//(ch0==str[i-1])
			if(!(ch1 ^ str[i-2]))//(ch1==str[i-2])
			{	str[i-1] = 0;
				return TRUE;
			}
			return FALSE;
	}	}
	return FALSE;
}

__declspec (dllexport) BOOL MySubstrA(char *str,char *subStr,int from,int to)
{
register int i;
	for(i=from; i<to; i++)
		subStr[i-from] = str[i];
	subStr[i] = 0;
	return TRUE;
}

__declspec (dllexport) BOOL MySubstr(wchar_t *str,wchar_t *subStr,int from,int to)
{
register int i;
	for(i=from; i<to; i++)
		subStr[i-from] = str[i];
	subStr[i] = 0;
	return TRUE;
}

__declspec (dllexport) BOOL MyInet4StrToDword(wchar_t *str,char *ipstrA,DWORD *dwIP4)
{
register int i,pointCnt=0,kNum=0;
wchar_t ipstr[32],*p=str;

	//Avval raqamgacha kelamiz:
	for(kNum=0; kNum<MAX_PATH; ++kNum)
	{	if(!(*p))break;
		if((*p)>='0')
		if((*p)<='9')break;
		++p;
	}

	for(i=0; i<16; ++i)
	{	if(0==(*p))
		{	//char ipstrA[32];
End:		ipstr[i]=0;
			WideCharToMultiByte(CP_ACP,0,ipstr,-1,ipstrA,i+2,NULL,NULL);
			*dwIP4 = (DWORD)inet_addr(ipstrA);
			if(INADDR_NONE==(*dwIP4))
				return FALSE;
			return TRUE;
		}
		if('.'==(*p))
		{	if(++pointCnt>3)
				goto End;
		}
		if((*p)<'0' || (*p)>'9')
		if((*p)!='.')
			goto End;
		ipstr[i]=(*p++);
	}
	return FALSE;
}

/*__declspec (dllexport) wchar_t* MyWcsstrNoCase(wchar_t* strIn, wchar_t* Chk)
{
wchar_t in[MAX_PATH],chk[MAX_PATH],*p=strIn,*pp=&in[0];
	for(; 0!=(*p); ++p,++pp)
		*pp = towlower(*p);

	for(p=Chk,pp=chk; 0!=(*p); ++p,++pp)
		*pp = towlower(*p);

	wchar_t *ret=wcsstr(in,chk);
	if(ret)
		return &strIn
	return NULL;
}*/

/*static const Byte kUtf8Limits[5] = { 0xC0, 0xE0, 0xF0, 0xF8, 0xFC };
Bool Utf8_To_Utf16(wchar_t *dest, size_t *destLen, const char *src, size_t srcLen)
{
  size_t destPos = 0, srcPos = 0;
  for (;;)
  {
    Byte c;
    int numAdds;
    if (srcPos == srcLen)
    {
      *destLen = destPos;
      return TRUE;
    }
    c = (Byte)src[srcPos++];

    if (c < 0x80)
    {
      if (dest)
        dest[destPos] = (wchar_t)c;
      destPos++;
      continue;
    }
    if (c < 0xC0)
      break;
    for (numAdds = 1; numAdds < 5; numAdds++)
      if (c < kUtf8Limits[numAdds])
        break;
    UInt32 value = (c - kUtf8Limits[numAdds - 1]);

    do
    {
      Byte c2;
      if (srcPos == srcLen)
        break;
      c2 = (Byte)src[srcPos++];
      if (c2 < 0x80 || c2 >= 0xC0)
        break;
      value <<= 6;
      value |= (c2 - 0x80);
    }
    while (--numAdds != 0);
    
    if (value < 0x10000)
    {
      if (dest)
        dest[destPos] = (wchar_t)value;
      destPos++;
    }
    else
    {
      value -= 0x10000;
      if (value >= 0x100000)
        break;
      if (dest)
      {
        dest[destPos + 0] = (wchar_t)(0xD800 + (value >> 10));
        dest[destPos + 1] = (wchar_t)(0xDC00 + (value & 0x3FF));
      }
      destPos += 2;
    }
  }
  *destLen = destPos;
  return False;
}

Bool Utf16_To_Utf8(char *dest, size_t *destLen, const wchar_t *src, size_t srcLen)
{
  size_t destPos = 0, srcPos = 0;
  for (;;)
  {
    unsigned numAdds;
    UInt32 value;
    if (srcPos == srcLen)
    {
      *destLen = destPos;
      return True;
    }
    value = src[srcPos++];
    if (value < 0x80)
    {
      if (dest)
        dest[destPos] = (char)value;
      destPos++;
      continue;
    }
    if (value >= 0xD800 && value < 0xE000)
    {
      UInt32 c2;
      if (value >= 0xDC00 || srcPos == srcLen)
        break;
      c2 = src[srcPos++];
      if (c2 < 0xDC00 || c2 >= 0xE000)
        break;
      value = (((value - 0xD800) << 10) | (c2 - 0xDC00)) + 0x10000;
    }
    for (numAdds = 1; numAdds < 5; numAdds++)
      if (value < (((UInt32)1) << (numAdds * 5 + 6)))
        break;
    if (dest)
      dest[destPos] = (char)(kUtf8Limits[numAdds - 1] + (value >> (6 * numAdds)));
    destPos++;
    do
    {
      numAdds--;
      if (dest)
        dest[destPos] = (char)(0x80 + ((value >> (6 * numAdds)) & 0x3F));
      destPos++;
    }
    while (numAdds != 0);
  }
  *destLen = destPos;
  return False;
}

wchar_t* ToUnicode(char *s)
{
static wchar_t ws[MAX_PATH];
wchar_t *pws=&ws[0];
char cw[2]={0,0};
		
	for(s; *s;)
	{	cw[1]=*s++;
		*pws++ = *((wchar_t*)(cw));
	}
	*pws = 0;
	return ws;
}*/
