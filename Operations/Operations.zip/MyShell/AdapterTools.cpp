#include "Winsock2.h"
#include <iphlpapi.h>

#pragma comment(lib, "Iphlpapi.lib")
#pragma warning(disable:4996)

#define MALLOC(x) HeapAlloc(GetProcessHeap(), 0, (x)) 
#define FREE(x) HeapFree(GetProcessHeap(), 0, (x))


__declspec (dllexport) int GetNetworkAdaptersCount()
{
PIP_ADAPTER_ADDRESSES AdapterAddresses = NULL;
ULONG OutBufferLength = 0;
ULONG RetVal = 0, i;
    
    // The size of the buffer can be different 
    // between consecutive API calls.
    // In most cases, i < 2 is sufficient;
    // One call to get the size and one call to get the actual parameters.
    // But if one more interface is added or addresses are added, 
    // the call again fails with BUFFER_OVERFLOW. 
    // So the number is picked slightly greater than 2. 
    // We use i <5 in the example
    for(i = 0; i < 5; i++)
	{	RetVal = GetAdaptersAddresses(AF_INET, GAA_FLAG_INCLUDE_ALL_INTERFACES, NULL, AdapterAddresses, &OutBufferLength);        
        if(RetVal != ERROR_BUFFER_OVERFLOW)
            break;
        if(AdapterAddresses != NULL)
            FREE(AdapterAddresses);        
        AdapterAddresses = (PIP_ADAPTER_ADDRESSES) MALLOC(OutBufferLength);
        if(AdapterAddresses == NULL)
		{	RetVal = GetLastError();
            break;
	}	}
	int nAdapters = 0;
    if(RetVal == NO_ERROR)
	{ // If successful, output some information from the data we received
      PIP_ADAPTER_ADDRESSES AdapterList = AdapterAddresses;
      while(AdapterList)
	  {	  ++nAdapters;	
		  AdapterList = AdapterList->Next;
    } }
    if (AdapterAddresses != NULL)
        FREE(AdapterAddresses);
	return nAdapters;
}

__declspec (dllexport) BOOL GetNetworkAdapterName(int iAdapter, wchar_t *pName)
{
PIP_ADAPTER_ADDRESSES AdapterAddresses = NULL;
ULONG OutBufferLength = 0;
ULONG RetVal = 0, i;
    
    // The size of the buffer can be different 
    // between consecutive API calls.
    // In most cases, i < 2 is sufficient;
    // One call to get the size and one call to get the actual parameters.
    // But if one more interface is added or addresses are added, 
    // the call again fails with BUFFER_OVERFLOW. 
    // So the number is picked slightly greater than 2. 
    // We use i <5 in the example
    for(i = 0; i < 5; i++)
	{	RetVal = GetAdaptersAddresses(AF_INET, GAA_FLAG_INCLUDE_ALL_INTERFACES, NULL, AdapterAddresses, &OutBufferLength);        
        if(RetVal != ERROR_BUFFER_OVERFLOW)
            break;
        if(AdapterAddresses != NULL)
            FREE(AdapterAddresses);        
        AdapterAddresses = (PIP_ADAPTER_ADDRESSES) MALLOC(OutBufferLength);
        if(AdapterAddresses == NULL)
		{	RetVal = GetLastError();
            break;
	}	}
	int nAdapters = 0;
	*pName = 0;
    if(RetVal == NO_ERROR)
	{ // If successful, output some information from the data we received
      PIP_ADAPTER_ADDRESSES AdapterList = AdapterAddresses;
      while(AdapterList)
	  {	  if(nAdapters==iAdapter)
		  {	  wcscpy(pName,(wchar_t*)AdapterList->AdapterName);	
			  break;
		  }
		  ++nAdapters;	
		  AdapterList = AdapterList->Next;
    } }
    if (AdapterAddresses != NULL)
        FREE(AdapterAddresses);
	return (*pName==0?FALSE:TRUE);
}

__declspec (dllexport) BOOL GetNetworkAdapterDescription(int iAdapter, wchar_t *pDescptn)
{
PIP_ADAPTER_ADDRESSES AdapterAddresses = NULL;
ULONG OutBufferLength = 0;
ULONG RetVal = 0, i;
    
    for(i = 0; i < 5; i++)
	{	RetVal = GetAdaptersAddresses(AF_INET, GAA_FLAG_INCLUDE_ALL_INTERFACES, NULL, AdapterAddresses, &OutBufferLength);        
        if(RetVal != ERROR_BUFFER_OVERFLOW)
            break;
        if(AdapterAddresses != NULL)
            FREE(AdapterAddresses);        
        AdapterAddresses = (PIP_ADAPTER_ADDRESSES) MALLOC(OutBufferLength);
        if(AdapterAddresses == NULL)
		{	RetVal = GetLastError();
            break;
	}	}
	int nAdapters = 0;
	*pDescptn = 0;
    if(RetVal == NO_ERROR)
	{ PIP_ADAPTER_ADDRESSES AdapterList = AdapterAddresses;
      while(AdapterList)
	  {	  if(nAdapters==iAdapter)
		  {	  wcscpy(pDescptn,(wchar_t*)AdapterList->Description);	
			  break;
		  }
		  ++nAdapters;	
		  AdapterList = AdapterList->Next;
    } }
    if (AdapterAddresses != NULL)
        FREE(AdapterAddresses);
	return (*pDescptn==0?FALSE:TRUE);
}

__declspec (dllexport) BOOL GetNetworkAdapterFriendlyName(int iAdapter, wchar_t *pFrName)
{
PIP_ADAPTER_ADDRESSES AdapterAddresses = NULL;
ULONG OutBufferLength = 0;
ULONG RetVal = 0, i;
    
    for(i = 0; i < 5; i++)
	{	RetVal = GetAdaptersAddresses(AF_INET, GAA_FLAG_INCLUDE_ALL_INTERFACES, NULL, AdapterAddresses, &OutBufferLength);        
        if(RetVal != ERROR_BUFFER_OVERFLOW)
            break;
        if(AdapterAddresses != NULL)
            FREE(AdapterAddresses);        
        AdapterAddresses = (PIP_ADAPTER_ADDRESSES) MALLOC(OutBufferLength);
        if(AdapterAddresses == NULL)
		{	RetVal = GetLastError();
            break;
	}	}
	int nAdapters = 0;
	*pFrName = 0;
    if(RetVal == NO_ERROR)
	{ // If successful, output some information from the data we received
      PIP_ADAPTER_ADDRESSES AdapterList = AdapterAddresses;
      while(AdapterList)
	  {	  if(nAdapters==iAdapter)
		  {	  wcscpy(pFrName,(wchar_t*)AdapterList->FriendlyName);	
			  break;
		  }
		  ++nAdapters;	
		  AdapterList = AdapterList->Next;
    } }
    if (AdapterAddresses != NULL)
        FREE(AdapterAddresses);
	return (*pFrName==0?FALSE:TRUE);
}

__declspec (dllexport) BOOL GetNetworkAdapterAddress(int iAdapter, SOCKET_ADDRESS *pAddress)
{
PIP_ADAPTER_ADDRESSES AdapterAddresses = NULL;
ULONG OutBufferLength = 0;
ULONG RetVal = 0, i;
    
    for(i = 0; i < 5; i++)
	{	RetVal = GetAdaptersAddresses(AF_INET, GAA_FLAG_INCLUDE_GATEWAYS|GAA_FLAG_INCLUDE_ALL_INTERFACES,
									  NULL, AdapterAddresses, &OutBufferLength);        
        if(RetVal != ERROR_BUFFER_OVERFLOW)
            break;
        if(AdapterAddresses != NULL)
            FREE(AdapterAddresses);        
        AdapterAddresses = (PIP_ADAPTER_ADDRESSES) MALLOC(OutBufferLength);
        if(AdapterAddresses == NULL)
		{	RetVal = GetLastError();
            break;
	}	}
	int nAdapters = 0;
	BOOL bRet = FALSE;
    if(RetVal == NO_ERROR)
	{ PIP_ADAPTER_ADDRESSES AdapterList = AdapterAddresses;
      while(AdapterList)
	  {	  if(nAdapters==iAdapter)
		  {	  //for(int i=0; i < (int)AdapterList->FirstUnicastAddress->Length; i++)
			  //	pAddress[i] = AdapterList->FirstUnicastAddress->Address[i];//SOCKET_ADDRESS;
			  memcpy(pAddress,&AdapterList->FirstUnicastAddress->Address,sizeof(SOCKET_ADDRESS));
			  bRet = TRUE;	
			  break;
		  }
		  ++nAdapters;	
		  AdapterList = AdapterList->Next;
    } }
    if (AdapterAddresses != NULL)
        FREE(AdapterAddresses);
	return bRet;
}

__declspec (dllexport) BOOL GetNetworkAdapterPhysAddress(int iAdapter, char *pAddress)
{
PIP_ADAPTER_ADDRESSES AdapterAddresses = NULL;
ULONG OutBufferLength = 0;
ULONG RetVal = 0, i;
    
    for(i = 0; i < 5; i++)
	{	RetVal = GetAdaptersAddresses(AF_INET, GAA_FLAG_INCLUDE_GATEWAYS|GAA_FLAG_INCLUDE_ALL_INTERFACES,
									  NULL, AdapterAddresses, &OutBufferLength);        
        if(RetVal != ERROR_BUFFER_OVERFLOW)
            break;
        if(AdapterAddresses != NULL)
            FREE(AdapterAddresses);        
        AdapterAddresses = (PIP_ADAPTER_ADDRESSES) MALLOC(OutBufferLength);
        if(AdapterAddresses == NULL)
		{	RetVal = GetLastError();
            break;
	}	}
	int nAdapters = 0;
	BOOL bRet = FALSE;
    if(RetVal == NO_ERROR)
	{ // If successful, output some information from the data we received
      PIP_ADAPTER_ADDRESSES AdapterList = AdapterAddresses;
      while(AdapterList)
	  {	  if(nAdapters==iAdapter)
		  {	  for(int i=0; i<MAX_ADAPTER_ADDRESS_LENGTH; i++)// 8 ta
				pAddress[i]=AdapterList->PhysicalAddress[i];
			  bRet = TRUE;	
			  break;
		  }
		  ++nAdapters;	
		  AdapterList = AdapterList->Next;
    } }
    if (AdapterAddresses != NULL)
        FREE(AdapterAddresses);
	return bRet;
}