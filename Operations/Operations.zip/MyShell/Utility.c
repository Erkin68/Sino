#include "Windows.h"
#include "strsafe.h"

extern int MyStringCpy(wchar_t*,int, wchar_t*);
extern BOOL IsDirExist(wchar_t*);


__declspec (dllexport) VOID UpItem(HWND prnt, int dlgItem, int y)
{
RECT r;POINT p[2];
HWND chld = GetDlgItem(prnt,dlgItem);
	GetWindowRect(chld,&r);
	p[0].x = r.left; p[0].y = r.top-y;
	p[1].x = r.right;p[1].y = r.bottom-y;
	ScreenToClient(prnt,&p[0]);
	ScreenToClient(prnt,&p[1]);
	MoveWindow(chld,p[0].x,p[0].y,p[1].x-p[0].x,p[1].y-p[0].y,TRUE);
}

__declspec (dllexport) VOID TimeToEdit(FILETIME ft, HWND hDlg, int edtDateId, int edtTimeId)
{
wchar_t s[16];SYSTEMTIME st;FileTimeToSystemTime(&ft,&st);
	StringCchPrintf(s,16,L"%02d.%02d.%04d",st.wDay,st.wMonth,st.wYear);
	SetDlgItemText(hDlg,edtDateId,s);
	StringCchPrintf(s,16,L"%02d.%02d.%02d.%03d",st.wHour,st.wMinute,st.wSecond,st.wMilliseconds);
	SetDlgItemText(hDlg,edtTimeId,s);
}

__declspec (dllexport) VOID LocTimeToEdit(HWND hDlg, int edtDateId, int edtTimeId)
{
wchar_t s[16];SYSTEMTIME st;GetLocalTime(&st);
	StringCchPrintf(s,16,L"%02d.%02d.%04d",st.wDay,st.wMonth,st.wYear);
	SetDlgItemText(hDlg,edtDateId,s);
	StringCchPrintf(s,16,L"%02d.%02d.%02d.%03d",st.wHour,st.wMinute,st.wSecond,st.wMilliseconds);
	SetDlgItemText(hDlg,edtTimeId,s);
}

__declspec (dllexport) HANDLE MyFopenViaCrF(wchar_t *nm,const wchar_t *mode)
{
HANDLE h;
	if(wcsstr(mode,L"rw"))
	{	h = CreateFile(nm,GENERIC_READ|GENERIC_WRITE,
						  FILE_SHARE_READ|FILE_SHARE_WRITE,
						  NULL,
						  OPEN_ALWAYS,
						  FILE_ATTRIBUTE_NORMAL,NULL);
	}
	else if(wcsstr(mode,L"r"))
	{	h = CreateFile(nm,GENERIC_READ,FILE_SHARE_READ,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);
	}
	else if(wcsstr(mode,L"w"))
	{	h = CreateFile(nm,GENERIC_WRITE,FILE_SHARE_WRITE,NULL,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,NULL);
	}
	if(INVALID_HANDLE_VALUE==h)
		return NULL;
	return h;
}

__declspec (dllexport) HANDLE MyFopenViaCrFA(char *nm,const char *mode)
{
HANDLE h;
	if(strstr(mode,"rw"))
	{	h = CreateFileA(nm,GENERIC_READ|GENERIC_WRITE,
						  FILE_SHARE_READ|FILE_SHARE_WRITE,
						  NULL,
						  OPEN_ALWAYS,
						  FILE_ATTRIBUTE_NORMAL,NULL);
	}
	else if(strstr(mode,"r"))
	{	h = CreateFileA(nm,GENERIC_READ,FILE_SHARE_READ,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);
	}
	else if(strstr(mode,"w"))
	{	h = CreateFileA(nm,GENERIC_WRITE,FILE_SHARE_WRITE,NULL,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,NULL);
	}
	if(INVALID_HANDLE_VALUE==h)
		return NULL;
	return h;
}

__declspec (dllexport) VOID AlignDayFrSpin(HWND hDlg,WPARAM wParam,int idEdit,wchar_t* s)
{
	if(SB_THUMBPOSITION==LOWORD(wParam) || SB_THUMBTRACK==LOWORD(wParam))
	{	if(HIWORD(wParam)>50)
		{	if(GetDlgItemText(hDlg,idEdit,s,MAX_PATH))
			{	if(++s[1]>(s[0]<'3'?'9':'1'))
				{	s[1]=s[0]<'3'?'0':'1';
					if(++s[0]>'3')s[0]='3';
				}
				s[10]=0;s[2]=s[5]='.';
				SetDlgItemText(hDlg,idEdit,s);
		}	} else
		{	if(GetDlgItemText(hDlg,idEdit,s,MAX_PATH))
			{	if(--s[1]<(s[0]>'0'?'0':'1'))
				{	s[1]=s[0]>'0'?'9':'1';
					if(--s[0]<'0')s[0]='0';
				}
				s[10]=0;s[2]=s[5]='.';
				SetDlgItemText(hDlg,idEdit,s);
}	}	}	}

__declspec (dllexport) VOID AlignHourFrSpin(HWND hDlg,WPARAM wParam,int idEdit,wchar_t* s)
{
	if(SB_THUMBPOSITION==LOWORD(wParam) || SB_THUMBTRACK==LOWORD(wParam))
	{	if(HIWORD(wParam)>50)
		{	if(GetDlgItemText(hDlg,idEdit,s,MAX_PATH))
			{	if(++s[1]>(s[0]<'2'?'9':'3'))
				{	s[1]=s[0]<'2'?'0':'3';
					if(++s[0]>'2')s[0]='2';
				}
				s[12]=0;s[2]=s[5]=s[8]='.';
				SetDlgItemText(hDlg,idEdit,s);
		}	} else
		{	if(GetDlgItemText(hDlg,idEdit,s,MAX_PATH))
			{	if(--s[1]<'0')
				{	s[1]=s[0]>'0'?'9':'0';
					if(--s[0]<'0')s[0]='0';
				}
				s[12]=0;s[2]=s[5]=s[8]='.';
				SetDlgItemText(hDlg,idEdit,s);
}	}	}	}

__declspec (dllexport) VOID AlignMilsFrSpin(HWND hDlg,WPARAM wParam,int idEdit,wchar_t* s)
{
	if(SB_THUMBPOSITION==LOWORD(wParam) || SB_THUMBTRACK==LOWORD(wParam))
	{	if(HIWORD(wParam)>50)
		{	if(GetDlgItemText(hDlg,idEdit,s,MAX_PATH))
			{	if(++s[11]>'9')
				{	s[11]=(s[9]=='9'&&s[10]=='9')?'9':'0';
					if(++s[10]>'9')
					{	s[10]=s[9]<'9'?'0':'9';
						if(++s[9]>'9') s[9]='9';
				}	}
				s[12]=0;s[2]=s[5]=s[8]='.';
				SetDlgItemText(hDlg,idEdit,s);
		}	} else
		{	if(GetDlgItemText(hDlg,idEdit,s,MAX_PATH))
			{	if(--s[11]<'0')
				{	s[11]=(s[9]=='0'&&s[10]=='0')?'0':'9';
					if(--s[10]<'0')
					{	s[10]=s[9]>'0'?'9':'0';
						if(--s[9]<'0') s[9]='0';
				}	}
				s[12]=0;s[2]=s[5]=s[8]='.';
				SetDlgItemText(hDlg,idEdit,s);
}	}	}	}

__declspec (dllexport) VOID AlignMinFrSpin(HWND hDlg,WPARAM wParam,int idEdit,wchar_t* s)
{
	if(SB_THUMBPOSITION==LOWORD(wParam) || SB_THUMBTRACK==LOWORD(wParam))
	{	if(HIWORD(wParam)>50)
		{	if(GetDlgItemText(hDlg,idEdit,s,MAX_PATH))
			{	if(++s[4]>(s[3]<'6'?'9':'0'))
				{	s[4]=s[3]<'5'?'0':'9';
					if(++s[3]>'5')s[3]='5';
				}
				s[12]=0;s[2]=s[5]=s[8]='.';
				SetDlgItemText(hDlg,idEdit,s);
		}	} else
		{	if(GetDlgItemText(hDlg,idEdit,s,MAX_PATH))
			{	if(--s[4]<'0')
				{	s[4]=s[3]>'0'?'9':'0';
					if(--s[3]<'0')s[3]='0';
				}
				s[12]=0;s[2]=s[5]=s[8]='.';
				SetDlgItemText(hDlg,idEdit,s);
}	}	}	}

__declspec (dllexport) VOID AlignMoonFrSpin(HWND hDlg,WPARAM wParam,int idEdit,wchar_t* s)
{
	if(SB_THUMBPOSITION==LOWORD(wParam) || SB_THUMBTRACK==LOWORD(wParam))
	{	if(HIWORD(wParam)>50)
		{	if(GetDlgItemText(hDlg,idEdit,s,MAX_PATH))
			{	if(++s[4]>(s[3]<'1'?'9':'2'))
				{	s[4]=s[3]<'1'?'0':'2';
					if(++s[3]>'1')s[3]='1';
				}
				s[10]=0;s[2]=s[5]='.';
				SetDlgItemText(hDlg,idEdit,s);
		}	} else
		{	if(GetDlgItemText(hDlg,idEdit,s,MAX_PATH))
			{	if(--s[4]<(s[3]>'0'?'0':'1'))
				{	s[4]=s[3]>'0'?'9':'1';
					if(--s[3]<'0')s[3]='0';
				}
				s[10]=0;s[2]=s[5]='.';
				SetDlgItemText(hDlg,idEdit,s);
}	}	}	}

__declspec (dllexport) VOID AlignSecFrSpin(HWND hDlg,WPARAM wParam,int idEdit,wchar_t* s)
{
	if(SB_THUMBPOSITION==LOWORD(wParam) || SB_THUMBTRACK==LOWORD(wParam))
	{	if(HIWORD(wParam)>50)
		{	if(GetDlgItemText(hDlg,idEdit,s,MAX_PATH))
			{	if(++s[7]>(s[6]<'6'?'9':'0'))
				{	s[7]=s[6]<'5'?'0':'9';
					if(++s[6]>'5')s[6]='5';
				}
				s[12]=0;s[2]=s[5]=s[8]='.';
				SetDlgItemText(hDlg,idEdit,s);
		}	} else
		{	if(GetDlgItemText(hDlg,idEdit,s,MAX_PATH))
			{	if(--s[7]<'0')
				{	s[7]=s[6]>'0'?'9':'0';
					if(--s[6]<'0')s[6]='0';
				}
				s[12]=0;s[2]=s[5]=s[8]='.';
				SetDlgItemText(hDlg,idEdit,s);
}	}	}	}

__declspec (dllexport) VOID AlignYearFrSpin(HWND hDlg,WPARAM wParam,int idEdit,wchar_t* s)
{
	if(SB_THUMBPOSITION==LOWORD(wParam) || SB_THUMBTRACK==LOWORD(wParam))
	{	if(HIWORD(wParam)>50)
		{	if(GetDlgItemText(hDlg,idEdit,s,MAX_PATH))
			{	if(++s[9]>'9')
				{	s[9]=(s[8]=='9'&&s[7]=='9'&&s[6]=='9')?'9':'0';
					if(++s[8]>'9')
					{	s[8]=(s[7]=='9'&&s[6]=='9')?'9':'0';
						if(++s[7]>'9')
						{	s[7] = s[6]=='9'?'9':'0';
							if(++s[6]>'9')s[6]='9';
				}	}	}
				s[10]=0;s[2]=s[5]='.';
				SetDlgItemText(hDlg,idEdit,s);
		}	} else
		{	if(GetDlgItemText(hDlg,idEdit,s,MAX_PATH))
			{	if(--s[9]<'0')
				{	s[9]=(s[8]=='0'&&s[7]=='0'&&s[6]=='0')?'0':'9';
					if(--s[8]<'0')
					{	s[8]=(s[7]=='0'&&s[6]=='0')?'0':'9';
						if(--s[7]<'0')
						{	s[7] = s[6]=='0'?'0':'9';
							if(--s[6]<'0')s[6]='0';
				}	}	}
				s[10]=0;s[2]=s[5]='.';
				SetDlgItemText(hDlg,idEdit,s);
}	}	}	}

__declspec (dllexport) BOOL EditsToFileTime(FILETIME *ft, wchar_t *edtD, wchar_t *edtT)
{
	//edtD[2]=edtD[5]=edtD[10]=0;
	SYSTEMTIME st; st.wDay = (edtD[0]-'0')*10 + edtD[1]-'0';
	st.wMonth = (edtD[3]-'0')*10 + edtD[4]-'0';
	st.wYear = (edtD[6]-'0')*1000 + (edtD[7]-'0')*100 + (edtD[8]-'0')*10 + edtD[9]-'0';

	//edt[2]=edt[5]=edt[8]=edt[12]=0;
	st.wHour = (edtT[0]-'0')*10 + edtT[1]-'0';
	st.wMinute = (edtT[3]-'0')*10 + edtT[4]-'0';
	st.wSecond = (edtT[6]-'0')*10 + edtT[7]-'0';
	st.wMilliseconds = (edtT[9]-'0')*100 + (edtT[10]-'0')*10 + edtT[11]-'0';
	if(!SystemTimeToFileTime(&st,ft))
		return FALSE;
	return TRUE;
}

__declspec (dllexport) BOOL IsCrntOrPrntDirAttrbW(wchar_t* fd)
{//see Naming Conventions in MSDN:
	if('.'==fd[0])
	{	if('\0'==fd[1])//"."
			return FALSE;
		if('.'==fd[1])
			if('\0'==fd[2])//".."
				return FALSE;
	}
	return TRUE;//Hozircha;
}

/*VOID EditToFileTime(HWND hDlg, int edtDateId, int edtTimeId)
{
SYSTEMTIME st;GetLocalTime(&st);
	char s[16];
	StringCchPrintf(s,16,"%2d.%2d.%4d",st.wDay,st.wMonth,st.wYear);
	SetDlgItemText(hDlg,edtDateId,s);
	StringCchPrintf(s,16,"%2d.%2d.%2d.%2d",st.wHour,st.wMinute,st.wSecond,st.wMilliseconds);
	SetDlgItemText(hDlg,edtTimeId,s);
}*/

__declspec (dllexport) void AssertFatal(BOOL b, LPWSTR msg)
{	if(!b)
	{	MessageBox(NULL, msg, L"Err.", MB_OK|MB_SYSTEMMODAL|MB_ICONERROR);
		//ExitProcess(0);
}	}

__declspec (dllexport) void CreateAllDirs(wchar_t *path)
{
wchar_t s[MAX_PATH],*p=&s[0];int ln=MyStringCpy(s,MAX_PATH-1,path);
	for(; p<&s[ln]; ++p)
	{	if('\\'==*p)
		{	*p = 0;
			if(!IsDirExist(s))
			{	if(0==CreateDirectory(s,NULL))
				{	int r = GetLastError();
					if(ERROR_ACCESS_DENIED==r)
					{
			}	}	}
			*p = '\\';
}	}	}

__declspec (dllexport) void ChangePrivilege(DWORD LuidHighPart,DWORD LuidLowPart,BOOL bSet)
{
HANDLE token;
	if(OpenProcessToken(GetCurrentProcess(),TOKEN_ADJUST_PRIVILEGES,&token))
	{	TOKEN_PRIVILEGES priv;priv.PrivilegeCount=1;
		priv.Privileges[0].Attributes=bSet?SE_PRIVILEGE_ENABLED:0;//SE_PRIVILEGE_REMOVED;
		priv.Privileges[0].Luid.LowPart=LuidLowPart;
		priv.Privileges[0].Luid.HighPart=LuidHighPart;
		AdjustTokenPrivileges(token,0,&priv,sizeof priv,0,0);
		CloseHandle(token);
}	}

/*SE_ASSIGNPRIMARYTOKEN_NAME
SE_AUDIT_NAME
SE_BACKUP_NAME
SE_CHANGE_NOTIFY_NAME
SE_CREATE_GLOBAL_NAME
SE_CREATE_PAGEFILE_NAME
SE_CREATE_PERMANENT_NAME
SE_CREATE_SYMBOLIC_LINK_NAME
SE_CREATE_TOKEN_NAME
SE_DEBUG_NAME
SE_ENABLE_DELEGATION_NAME
SE_IMPERSONATE_NAME
SE_INC_BASE_PRIORITY_NAME
SE_INCREASE_QUOTA_NAME
SE_INC_WORKING_SET_NAME
SE_LOAD_DRIVER_NAME
SE_LOCK_MEMORY_NAME
SE_MACHINE_ACCOUNT_NAME
SE_MANAGE_VOLUME_NAME
SE_PROF_SINGLE_PROCESS_NAME
SE_RELABEL_NAME
SE_REMOTE_SHUTDOWN_NAME
SE_RESTORE_NAME
SE_SECURITY_NAME
SE_SHUTDOWN_NAME
SE_SYNC_AGENT_NAME
SE_SYSTEM_ENVIRONMENT_NAME
SE_SYSTEM_PROFILE_NAME
SE_SYSTEMTIME_NAME
SE_TAKE_OWNERSHIP_NAME
SE_TCB_NAME
SE_TIME_ZONE_NAME
SE_TRUSTED_CREDMAN_ACCESS_NAME
SE_UNDOCK_NAME
SE_UNSOLICITED_INPUT_NAME*/
