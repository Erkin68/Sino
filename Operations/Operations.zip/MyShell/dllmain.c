// dllmain.cpp : Defines the entry point for the DLL application.
#include "windows.h"
#include "resource.h"
#include "stdio.h"
#include "strsafe.h"


HINSTANCE hInst;
//HFONT hfBtn=NULL;
const wchar_t szmsgSHAREVIOLATION[] = SHAREVISTRING;  // string for sharing violation
const wchar_t szmsgFILEOK[]         = FILEOKSTRING;   // string for OK button
const wchar_t szCommdlgHelp[]       = HELPMSGSTRING;  // string for Help button
extern UINT cdmsgShareViolation;  // identifier from RegisterWindowMessage
extern UINT cdmsgFileOK        ;  // identifier from RegisterWindowMessage
extern UINT cdmsgHelp          ;  // identifier from RegisterWindowMessage


BOOL bMyFindFirst;
//extern VOID MyButtonDestroyOnDetachDll();
extern int MyStringCpyA(char*,int,char*);
extern int MyStringCpy(wchar_t*,int, wchar_t*);
__declspec (dllexport) VOID InitLOGFONT(LOGFONTW*);

typedef __out HANDLE (WINAPI *FindFirstFileExA_t)(__in LPCSTR,
												  __in FINDEX_INFO_LEVELS,
												  __out LPVOID,
												  __in FINDEX_SEARCH_OPS,
												  __reserved LPVOID,
												  __in DWORD);
typedef __out HANDLE (WINAPI *FindFirstFileExW_t)(__in LPCWSTR,
												  __in FINDEX_INFO_LEVELS,
												  __out LPVOID,
												  __in FINDEX_SEARCH_OPS,
												  __reserved LPVOID,
												  __in DWORD);
//FindFirstFileExW_t MyFindFirstFileEx;
//FindFirstFileExA_t MyFindFirstFileExA;
HANDLE WINAPI MyFindFirstFileExWM(__in  LPCWSTR lpFileName,             // file name
								  __in  FINDEX_INFO_LEVELS fInfoLevelId,// information level
								  __out LPVOID lpFindFileData,          // information buffer
								  __in  FINDEX_SEARCH_OPS fSearchOp,    // filtering type
								  __reserved LPVOID lpSearchFilter,     // search criteria
								  __in DWORD dwAdditionalFlags);		// additional search control
HANDLE WINAPI MyFindFirstFileExAM(__in  LPCSTR lpFileName,              // file name
								  __in  FINDEX_INFO_LEVELS fInfoLevelId,// information level
								  __out LPVOID lpFindFileData,          // information buffer
								  __in  FINDEX_SEARCH_OPS fSearchOp,    // filtering type
								  __reserved LPVOID lpSearchFilter,     // search criteria
								  __in DWORD dwAdditionalFlags);		// additional search control
BOOL APIENTRY DllMain( HMODULE hModule,DWORD  ul_reason_for_call,LPVOID lpReserved)
{
HANDLE h;WIN32_FIND_DATA ff;wchar_t dllname[MAX_PATH];
//LOGFONT hfl={-11,0,0,0,300,0,0,0,204,3,2,1,34,L"Arial"}; 
	switch (ul_reason_for_call)
	{
	case DLL_PROCESS_ATTACH:
		hInst=hModule;
		// Register the window messages to receive.
		cdmsgShareViolation = RegisterWindowMessage(szmsgSHAREVIOLATION);
		cdmsgFileOK         = RegisterWindowMessage(szmsgFILEOK);
		cdmsgHelp           = RegisterWindowMessage(szCommdlgHelp);
		GetModuleFileNameW(hModule,dllname,260);
		bMyFindFirst=FALSE;//MyFindFirstFileEx=NULL;
		h = FindFirstFileExW(dllname,FindExInfoStandard,&ff,FindExSearchLimitToDirectories,NULL,0);
		if(INVALID_HANDLE_VALUE!=h)
		{	FindClose(h);
			if(FILE_ATTRIBUTE_DIRECTORY & ff.dwFileAttributes)
			{	//HMODULE m=LoadLibrary("kernel32.dll");
				//if(m)MyFindFirstFileEx=(FindFirstFileEx_t)GetProcAddress(m,"FindFirstFileExA");
				//if(!MyFindFirstFileEx)
				bMyFindFirst=TRUE;//MyFindFirstFileEx=(FindFirstFileExW_t)FindFirstFileExW;
		}	}
		//InitLOGFONT(&hfl);
		//hfBtn=CreateFontIndirect(&hfl);
		//if(!MyFindFirstFileEx)MyFindFirstFileEx=MyFindFirstFileExWM;

		/*WideCharToMultiByte(CP_OEMCP,0,dllname,-1,dllnameA,259,NULL,NULL);
		MyFindFirstFileExA=NULL;
		h = FindFirstFileExA(dllnameA,FindExInfoStandard,&ff,FindExSearchLimitToDirectories,NULL,0);
		if(INVALID_HANDLE_VALUE!=h)
		{	FindClose(h);
			if(FILE_ATTRIBUTE_DIRECTORY & ff.dwFileAttributes)
			{	//HMODULE m=LoadLibrary("kernel32.dll");
				//if(m)MyFindFirstFileEx=(FindFirstFileEx_t)GetProcAddress(m,"FindFirstFileExA");
				//if(!MyFindFirstFileEx)
				MyFindFirstFileExA=(FindFirstFileExA_t)FindFirstFileExA;
		}	}
		if(!MyFindFirstFileExA)MyFindFirstFileExA=MyFindFirstFileExAM;*/
		break;
	case DLL_THREAD_ATTACH:
	case DLL_THREAD_DETACH:
		break;
	case DLL_PROCESS_DETACH:
		//MyButtonDestroyOnDetachDll();
		//MyButton::DestroyOnDllExit();
		break;
	}
	return TRUE;
}

__declspec (dllexport) LPSTR GetWinNotifyTextA(DWORD msg)
{
	switch(msg)
	{
		case WM_NULL                         :return "WM_NULL";
		case WM_CREATE                       :return "WM_CREATE";
		case WM_DESTROY                      :return "WM_DESTROY";
		case WM_MOVE                         :return "WM_MOVE";
		case WM_SIZE                         :return "WM_SIZE";
		case WM_ACTIVATE                     :return "WM_ACTIVATE";
		case WM_SETFOCUS                     :return "WM_SETFOCUS";
		case WM_KILLFOCUS                    :return "WM_KILLFOCUS";
		case WM_ENABLE                       :return "WM_ENABLE";
		case WM_SETREDRAW                    :return "WM_SETREDRAW";
		case WM_SETTEXT                      :return "WM_SETTEXT";
		case WM_GETTEXT                      :return "WM_GETTEXT";
		case WM_GETTEXTLENGTH                :return "WM_GETTEXTLENGTH";
		case WM_PAINT                        :return "WM_PAINT";
		case WM_CLOSE                        :return "WM_CLOSE";
		case WM_QUERYENDSESSION              :return "WM_QUERYENDSESSION";
		case WM_QUERYOPEN                    :return "WM_QUERYOPEN";
		case WM_ENDSESSION                   :return "WM_ENDSESSION";
		case WM_QUIT                         :return "WM_QUIT";
		case WM_ERASEBKGND                   :return "WM_ERASEBKGND";
		case WM_SYSCOLORCHANGE               :return "WM_SYSCOLORCHANGE";
		case WM_SHOWWINDOW                   :return "WM_SHOWWINDOW";
		case WM_WININICHANGE                 :return "WM_WININICHANGE";
		case WM_DEVMODECHANGE                :return "WM_DEVMODECHANGE";
		case WM_ACTIVATEAPP                  :return "WM_ACTIVATEAPP";
		case WM_FONTCHANGE                   :return "WM_FONTCHANGE";
		case WM_TIMECHANGE                   :return "WM_TIMECHANGE";
		case WM_CANCELMODE                   :return "WM_CANCELMODE";
		case WM_SETCURSOR                    :return "WM_SETCURSOR";
		case WM_MOUSEACTIVATE                :return "WM_MOUSEACTIVATE";
		case WM_CHILDACTIVATE                :return "WM_CHILDACTIVATE";
		case WM_QUEUESYNC                    :return "WM_QUEUESYNC";
		case WM_GETMINMAXINFO                :return "WM_GETMINMAXINFO";
		case WM_PAINTICON                    :return "WM_PAINTICON";
		case WM_ICONERASEBKGND               :return "WM_ICONERASEBKGND";
		case WM_NEXTDLGCTL                   :return "WM_NEXTDLGCTL";
		case WM_SPOOLERSTATUS                :return "WM_SPOOLERSTATUS";
		case WM_DRAWITEM                     :return "WM_DRAWITEM";
		case WM_MEASUREITEM                  :return "WM_MEASUREITEM";
		case WM_DELETEITEM                   :return "WM_DELETEITEM";
		case WM_VKEYTOITEM                   :return "WM_VKEYTOITEM";
		case WM_CHARTOITEM                   :return "WM_CHARTOITEM";
		case WM_SETFONT                      :return "WM_SETFONT";
		case WM_GETFONT                      :return "WM_GETFONT";
		case WM_SETHOTKEY                    :return "WM_SETHOTKEY";
		case WM_GETHOTKEY                    :return "WM_GETHOTKEY";
		case WM_QUERYDRAGICON                :return "WM_QUERYDRAGICON";
		case WM_COMPAREITEM                  :return "WM_COMPAREITEM";
		case WM_GETOBJECT                    :return "WM_GETOBJECT";
		case WM_COMPACTING                   :return "WM_COMPACTING";
		case WM_COMMNOTIFY                   :return "WM_COMMNOTIFY";
		case WM_WINDOWPOSCHANGING            :return "WM_WINDOWPOSCHANGING";
		case WM_WINDOWPOSCHANGED             :return "WM_WINDOWPOSCHANGED";
		case WM_POWER                        :return "WM_POWER";
		case WM_COPYDATA                     :return "WM_COPYDATA";
		case WM_CANCELJOURNAL                :return "WM_CANCELJOURNAL";
		case WM_NOTIFY                       :return "WM_NOTIFY";
		case WM_INPUTLANGCHANGEREQUEST       :return "WM_INPUTLANGCHANGEREQUEST";
		case WM_INPUTLANGCHANGE              :return "WM_INPUTLANGCHANGE";
		case WM_TCARD                        :return "WM_TCARD";
		case WM_HELP                         :return "WM_HELP";
		case WM_USERCHANGED                  :return "WM_USERCHANGED";
		case WM_NOTIFYFORMAT                 :return "WM_NOTIFYFORMAT";
		case WM_CONTEXTMENU                  :return "WM_CONTEXTMENU";
		case WM_STYLECHANGING                :return "WM_STYLECHANGING";
		case WM_STYLECHANGED                 :return "WM_STYLECHANGED";
		case WM_DISPLAYCHANGE                :return "WM_DISPLAYCHANGE";
		case WM_GETICON                      :return "WM_GETICON";
		case WM_SETICON                      :return "WM_SETICON";
		case WM_NCCREATE                     :return "WM_NCCREATE";
		case WM_NCDESTROY                    :return "WM_NCDESTROY";
		case WM_NCCALCSIZE                   :return "WM_NCCALCSIZE";
		case WM_NCHITTEST                    :return "WM_NCHITTEST";
		case WM_NCPAINT                      :return "WM_NCPAINT";
		case WM_NCACTIVATE                   :return "WM_NCACTIVATE";
		case WM_GETDLGCODE                   :return "WM_GETDLGCODE";
		case WM_SYNCPAINT                    :return "WM_SYNCPAINT";
		case WM_NCMOUSEMOVE                  :return "WM_NCMOUSEMOVE";
		case WM_NCLBUTTONDOWN                :return "WM_NCLBUTTONDOWN";
		case WM_NCLBUTTONUP                  :return "WM_NCLBUTTONUP";
		case WM_NCLBUTTONDBLCLK              :return "WM_NCLBUTTONDBLCLK";
		case WM_NCRBUTTONDOWN                :return "WM_NCRBUTTONDOWN";
		case WM_NCRBUTTONUP                  :return "WM_NCRBUTTONUP";
		case WM_NCRBUTTONDBLCLK              :return "WM_NCRBUTTONDBLCLK";
		case WM_NCMBUTTONDOWN                :return "WM_NCMBUTTONDOWN";
		case WM_NCMBUTTONUP                  :return "WM_NCMBUTTONUP";
		case WM_NCMBUTTONDBLCLK              :return "WM_NCMBUTTONDBLCLK";
		case WM_NCXBUTTONDOWN                :return "WM_NCXBUTTONDOWN";
		case WM_NCXBUTTONUP                  :return "WM_NCXBUTTONUP";
		case WM_NCXBUTTONDBLCLK              :return "WM_NCXBUTTONDBLCLK";
		case WM_INPUT_DEVICE_CHANGE          :return "WM_INPUT_DEVICE_CHANGE";
		case WM_KEYFIRST                     :return "WM_KEYFIRST";
		case WM_KEYUP                        :return "WM_KEYUP";
		case WM_CHAR                         :return "WM_CHAR";
		case WM_DEADCHAR                     :return "WM_DEADCHAR";
		case WM_SYSKEYDOWN                   :return "WM_SYSKEYDOWN";
		case WM_SYSKEYUP                     :return "WM_SYSKEYUP";
		case WM_SYSCHAR                      :return "WM_SYSCHAR";
		case WM_SYSDEADCHAR                  :return "WM_SYSDEADCHAR";
		case WM_UNICHAR                      :return "WM_UNICHAR";
		case WM_IME_STARTCOMPOSITION         :return "WM_IME_STARTCOMPOSITION";
		case WM_IME_ENDCOMPOSITION           :return "WM_IME_ENDCOMPOSITION";
		case WM_IME_COMPOSITION              :return "WM_IME_COMPOSITION";
		case WM_INITDIALOG                   :return "WM_INITDIALOG";
		case WM_COMMAND                      :return "WM_COMMAND";
		case WM_SYSCOMMAND                   :return "WM_SYSCOMMAND";
		case WM_TIMER                        :return "WM_TIMER";
		case WM_HSCROLL                      :return "WM_HSCROLL";
		case WM_VSCROLL                      :return "WM_VSCROLL";
		case WM_INITMENU                     :return "WM_INITMENU";
		case WM_INITMENUPOPUP                :return "WM_INITMENUPOPUP";
		case WM_MENUSELECT                   :return "WM_MENUSELECT";
		case WM_MENUCHAR                     :return "WM_MENUCHAR";
		case WM_ENTERIDLE                    :return "WM_ENTERIDLE";
		case WM_MENURBUTTONUP                :return "WM_MENURBUTTONUP";
		case WM_MENUDRAG                     :return "WM_MENUDRAG";
		case WM_MENUGETOBJECT                :return "WM_MENUGETOBJECT";
		case WM_UNINITMENUPOPUP              :return "WM_UNINITMENUPOPUP";
		case WM_MENUCOMMAND                  :return "WM_MENUCOMMAND";
		case WM_CHANGEUISTATE                :return "WM_CHANGEUISTATE";
		case WM_UPDATEUISTATE                :return "WM_UPDATEUISTATE";
		case WM_QUERYUISTATE                 :return "WM_QUERYUISTATE";
		case WM_CTLCOLORMSGBOX               :return "WM_CTLCOLORMSGBOX";
		case WM_CTLCOLOREDIT                 :return "WM_CTLCOLOREDIT";
		case WM_CTLCOLORLISTBOX              :return "WM_CTLCOLORLISTBOX";
		case WM_CTLCOLORBTN                  :return "WM_CTLCOLORBTN";
		case WM_CTLCOLORDLG                  :return "WM_CTLCOLORDLG";
		case WM_CTLCOLORSCROLLBAR            :return "WM_CTLCOLORSCROLLBAR";
		case WM_CTLCOLORSTATIC               :return "WM_CTLCOLORSTATIC";
		case MN_GETHMENU                     :return "MN_GETHMENU";
		case WM_MOUSEFIRST                   :return "WM_MOUSEFIRST";
		case WM_LBUTTONDOWN                  :return "WM_LBUTTONDOWN";
		case WM_LBUTTONUP                    :return "WM_LBUTTONUP";
		case WM_LBUTTONDBLCLK                :return "WM_LBUTTONDBLCLK";
		case WM_RBUTTONDOWN                  :return "WM_RBUTTONDOWN";
		case WM_RBUTTONUP                    :return "WM_RBUTTONUP";
		case WM_RBUTTONDBLCLK                :return "WM_RBUTTONDBLCLK";
		case WM_MBUTTONDOWN                  :return "WM_MBUTTONDOWN";
		case WM_MBUTTONUP                    :return "WM_MBUTTONUP";
		case WM_MBUTTONDBLCLK                :return "WM_MBUTTONDBLCLK";
		case WM_MOUSEWHEEL                   :return "WM_MOUSEWHEEL";
		case WM_XBUTTONDOWN                  :return "WM_XBUTTONDOWN";
		case WM_XBUTTONUP                    :return "WM_XBUTTONUP";
		case WM_XBUTTONDBLCLK                :return "WM_XBUTTONDBLCLK";
		case WM_MOUSEHWHEEL                  :return "WM_MOUSEHWHEEL";
		case WM_PARENTNOTIFY                 :return "WM_PARENTNOTIFY";
		case WM_ENTERMENULOOP                :return "WM_ENTERMENULOOP";
		case WM_EXITMENULOOP                 :return "WM_EXITMENULOOP";
		case WM_NEXTMENU                     :return "WM_NEXTMENU";
		case WM_SIZING                       :return "WM_SIZING";
		case WM_CAPTURECHANGED               :return "WM_CAPTURECHANGED";
		case WM_MOVING                       :return "WM_MOVING";
		case WM_POWERBROADCAST               :return "WM_POWERBROADCAST";
		case WM_DEVICECHANGE                 :return "WM_DEVICECHANGE";
		case WM_MDICREATE                    :return "WM_MDICREATE";
		case WM_MDIDESTROY                   :return "WM_MDIDESTROY";
		case WM_MDIACTIVATE                  :return "WM_MDIACTIVATE";
		case WM_MDIRESTORE                   :return "WM_MDIRESTORE";
		case WM_MDINEXT                      :return "WM_MDINEXT";
		case WM_MDIMAXIMIZE                  :return "WM_MDIMAXIMIZE";
		case WM_MDITILE                      :return "WM_MDITILE";
		case WM_MDICASCADE                   :return "WM_MDICASCADE";
		case WM_MDIICONARRANGE               :return "WM_MDIICONARRANGE";
		case WM_MDIGETACTIVE                 :return "WM_MDIGETACTIVE";
		case WM_MDISETMENU                   :return "WM_MDISETMENU";
		case WM_ENTERSIZEMOVE                :return "WM_ENTERSIZEMOVE";
		case WM_EXITSIZEMOVE                 :return "WM_EXITSIZEMOVE";
		case WM_DROPFILES                    :return "WM_DROPFILES";
		case WM_MDIREFRESHMENU               :return "WM_MDIREFRESHMENU";
		case WM_IME_SETCONTEXT               :return "WM_IME_SETCONTEXT";
		case WM_IME_NOTIFY                   :return "WM_IME_NOTIFY";
		case WM_IME_CONTROL                  :return "WM_IME_CONTROL";
		case WM_IME_COMPOSITIONFULL          :return "WM_IME_COMPOSITIONFULL";
		case WM_IME_SELECT                   :return "WM_IME_SELECT";
		case WM_IME_CHAR                     :return "WM_IME_CHAR";
		case WM_IME_REQUEST                  :return "WM_IME_REQUEST";
		case WM_IME_KEYDOWN                  :return "WM_IME_KEYDOWN";
		case WM_IME_KEYUP                    :return "WM_IME_KEYUP";
		case WM_MOUSEHOVER                   :return "WM_MOUSEHOVER";
		case WM_MOUSELEAVE                   :return "WM_MOUSELEAVE";
		case WM_NCMOUSEHOVER                 :return "WM_NCMOUSEHOVER";
		case WM_NCMOUSELEAVE                 :return "WM_NCMOUSELEAVE";
		case WM_WTSSESSION_CHANGE            :return "WM_WTSSESSION_CHANGE";
		case WM_TABLET_FIRST                 :return "WM_TABLET_FIRST";
		case WM_TABLET_LAST                  :return "WM_TABLET_LAST";
		case WM_CUT                          :return "WM_CUT";
		case WM_COPY                         :return "WM_COPY";
		case WM_PASTE                        :return "WM_PASTE";
		case WM_CLEAR                        :return "WM_CLEAR";
		case WM_UNDO                         :return "WM_UNDO";
		case WM_RENDERFORMAT                 :return "WM_RENDERFORMAT";
		case WM_RENDERALLFORMATS             :return "WM_RENDERALLFORMATS";
		case WM_DESTROYCLIPBOARD             :return "WM_DESTROYCLIPBOARD";
		case WM_DRAWCLIPBOARD                :return "WM_DRAWCLIPBOARD";
		case WM_PAINTCLIPBOARD               :return "WM_PAINTCLIPBOARD";
		case WM_VSCROLLCLIPBOARD             :return "WM_VSCROLLCLIPBOARD";
		case WM_SIZECLIPBOARD                :return "WM_SIZECLIPBOARD";
		case WM_ASKCBFORMATNAME              :return "WM_ASKCBFORMATNAME";
		case WM_CHANGECBCHAIN                :return "WM_CHANGECBCHAIN";
		case WM_HSCROLLCLIPBOARD             :return "WM_HSCROLLCLIPBOARD";
		case WM_QUERYNEWPALETTE              :return "WM_QUERYNEWPALETTE";
		case WM_PALETTEISCHANGING            :return "WM_PALETTEISCHANGING";
		case WM_PALETTECHANGED               :return "WM_PALETTECHANGED";
		case WM_HOTKEY                       :return "WM_HOTKEY";
		case WM_PRINT                        :return "WM_PRINT";
		case WM_PRINTCLIENT                  :return "WM_PRINTCLIENT";
		case WM_APPCOMMAND                   :return "WM_APPCOMMAND";
		case WM_THEMECHANGED                 :return "WM_THEMECHANGED";
		case WM_CLIPBOARDUPDATE              :return "WM_CLIPBOARDUPDATE";
		case WM_DWMCOMPOSITIONCHANGED        :return "WM_DWMCOMPOSITIONCHANGED";
		case WM_DWMNCRENDERINGCHANGED        :return "WM_DWMNCRENDERINGCHANGED";
		case WM_DWMCOLORIZATIONCOLORCHANGED  :return "WM_DWMCOLORIZATIONCOLORCHANGED";
		case WM_DWMWINDOWMAXIMIZEDCHANGE     :return "WM_DWMWINDOWMAXIMIZEDCHANGE";
		case WM_GETTITLEBARINFOEX            :return "WM_GETTITLEBARINFOEX";
		case WM_HANDHELDFIRST                :return "WM_HANDHELDFIRST";
		case WM_HANDHELDLAST                 :return "WM_HANDHELDLAST";
		case WM_AFXFIRST                     :return "WM_AFXFIRST";
		case WM_AFXLAST                      :return "WM_AFXLAST";
		case WM_PENWINFIRST                  :return "WM_PENWINFIRST";
		case WM_PENWINLAST                   :return "WM_PENWINLAST";
		case WM_USER                         :return "WM_USER";
		case 0xc02b							 :return "WM_SHELLHOOKMESSAGE";
	}
	return "Unknown message";
}

__declspec (dllexport) LPWSTR GetWinNotifyText(DWORD msg)
{
	switch(msg)
	{
		case WM_NULL                         :return L"WM_NULL                        ";
		case WM_CREATE                       :return L"WM_CREATE                      ";
		case WM_DESTROY                      :return L"WM_DESTROY                     ";
		case WM_MOVE                         :return L"WM_MOVE                        ";
		case WM_SIZE                         :return L"WM_SIZE                        ";
		case WM_ACTIVATE                     :return L"WM_ACTIVATE                    ";
		case WM_SETFOCUS                     :return L"WM_SETFOCUS                    ";
		case WM_KILLFOCUS                    :return L"WM_KILLFOCUS                   ";
		case WM_ENABLE                       :return L"WM_ENABLE                      ";
		case WM_SETREDRAW                    :return L"WM_SETREDRAW                   ";
		case WM_SETTEXT                      :return L"WM_SETTEXT                     ";
		case WM_GETTEXT                      :return L"WM_GETTEXT                     ";
		case WM_GETTEXTLENGTH                :return L"WM_GETTEXTLENGTH               ";
		case WM_PAINT                        :return L"WM_PAINT                       ";
		case WM_CLOSE                        :return L"WM_CLOSE                       ";
		case WM_QUERYENDSESSION              :return L"WM_QUERYENDSESSION             ";
		case WM_QUERYOPEN                    :return L"WM_QUERYOPEN                   ";
		case WM_ENDSESSION                   :return L"WM_ENDSESSION                  ";
		case WM_QUIT                         :return L"WM_QUIT                        ";
		case WM_ERASEBKGND                   :return L"WM_ERASEBKGND                  ";
		case WM_SYSCOLORCHANGE               :return L"WM_SYSCOLORCHANGE              ";
		case WM_SHOWWINDOW                   :return L"WM_SHOWWINDOW                  ";
		case WM_WININICHANGE                 :return L"WM_WININICHANGE                ";
		case WM_DEVMODECHANGE                :return L"WM_DEVMODECHANGE               ";
		case WM_ACTIVATEAPP                  :return L"WM_ACTIVATEAPP                 ";
		case WM_FONTCHANGE                   :return L"WM_FONTCHANGE                  ";
		case WM_TIMECHANGE                   :return L"WM_TIMECHANGE                  ";
		case WM_CANCELMODE                   :return L"WM_CANCELMODE                  ";
		case WM_SETCURSOR                    :return L"WM_SETCURSOR                   ";
		case WM_MOUSEACTIVATE                :return L"WM_MOUSEACTIVATE               ";
		case WM_CHILDACTIVATE                :return L"WM_CHILDACTIVATE               ";
		case WM_QUEUESYNC                    :return L"WM_QUEUESYNC                   ";
		case WM_GETMINMAXINFO                :return L"WM_GETMINMAXINFO               ";
		case WM_PAINTICON                    :return L"WM_PAINTICON                   ";
		case WM_ICONERASEBKGND               :return L"WM_ICONERASEBKGND              ";
		case WM_NEXTDLGCTL                   :return L"WM_NEXTDLGCTL                  ";
		case WM_SPOOLERSTATUS                :return L"WM_SPOOLERSTATUS               ";
		case WM_DRAWITEM                     :return L"WM_DRAWITEM                    ";
		case WM_MEASUREITEM                  :return L"WM_MEASUREITEM                 ";
		case WM_DELETEITEM                   :return L"WM_DELETEITEM                  ";
		case WM_VKEYTOITEM                   :return L"WM_VKEYTOITEM                  ";
		case WM_CHARTOITEM                   :return L"WM_CHARTOITEM                  ";
		case WM_SETFONT                      :return L"WM_SETFONT                     ";
		case WM_GETFONT                      :return L"WM_GETFONT                     ";
		case WM_SETHOTKEY                    :return L"WM_SETHOTKEY                   ";
		case WM_GETHOTKEY                    :return L"WM_GETHOTKEY                   ";
		case WM_QUERYDRAGICON                :return L"WM_QUERYDRAGICON               ";
		case WM_COMPAREITEM                  :return L"WM_COMPAREITEM                 ";
		case WM_GETOBJECT                    :return L"WM_GETOBJECT                   ";
		case WM_COMPACTING                   :return L"WM_COMPACTING                  ";
		case WM_COMMNOTIFY                   :return L"WM_COMMNOTIFY                  ";
		case WM_WINDOWPOSCHANGING            :return L"WM_WINDOWPOSCHANGING           ";
		case WM_WINDOWPOSCHANGED             :return L"WM_WINDOWPOSCHANGED            ";
		case WM_POWER                        :return L"WM_POWER                       ";
		case WM_COPYDATA                     :return L"WM_COPYDATA                    ";
		case WM_CANCELJOURNAL                :return L"WM_CANCELJOURNAL               ";
		case WM_NOTIFY                       :return L"WM_NOTIFY                      ";
		case WM_INPUTLANGCHANGEREQUEST       :return L"WM_INPUTLANGCHANGEREQUEST      ";
		case WM_INPUTLANGCHANGE              :return L"WM_INPUTLANGCHANGE             ";
		case WM_TCARD                        :return L"WM_TCARD                       ";
		case WM_HELP                         :return L"WM_HELP                        ";
		case WM_USERCHANGED                  :return L"WM_USERCHANGED                 ";
		case WM_NOTIFYFORMAT                 :return L"WM_NOTIFYFORMAT                ";
		case WM_CONTEXTMENU                  :return L"WM_CONTEXTMENU                 ";
		case WM_STYLECHANGING                :return L"WM_STYLECHANGING               ";
		case WM_STYLECHANGED                 :return L"WM_STYLECHANGED                ";
		case WM_DISPLAYCHANGE                :return L"WM_DISPLAYCHANGE               ";
		case WM_GETICON                      :return L"WM_GETICON                     ";
		case WM_SETICON                      :return L"WM_SETICON                     ";
		case WM_NCCREATE                     :return L"WM_NCCREATE                    ";
		case WM_NCDESTROY                    :return L"WM_NCDESTROY                   ";
		case WM_NCCALCSIZE                   :return L"WM_NCCALCSIZE                  ";
		case WM_NCHITTEST                    :return L"WM_NCHITTEST                   ";
		case WM_NCPAINT                      :return L"WM_NCPAINT                     ";
		case WM_NCACTIVATE                   :return L"WM_NCACTIVATE                  ";
		case WM_GETDLGCODE                   :return L"WM_GETDLGCODE                  ";
		case WM_SYNCPAINT                    :return L"WM_SYNCPAINT                   ";
		case WM_NCMOUSEMOVE                  :return L"WM_NCMOUSEMOVE                 ";
		case WM_NCLBUTTONDOWN                :return L"WM_NCLBUTTONDOWN               ";
		case WM_NCLBUTTONUP                  :return L"WM_NCLBUTTONUP                 ";
		case WM_NCLBUTTONDBLCLK              :return L"WM_NCLBUTTONDBLCLK             ";
		case WM_NCRBUTTONDOWN                :return L"WM_NCRBUTTONDOWN               ";
		case WM_NCRBUTTONUP                  :return L"WM_NCRBUTTONUP                 ";
		case WM_NCRBUTTONDBLCLK              :return L"WM_NCRBUTTONDBLCLK             ";
		case WM_NCMBUTTONDOWN                :return L"WM_NCMBUTTONDOWN               ";
		case WM_NCMBUTTONUP                  :return L"WM_NCMBUTTONUP                 ";
		case WM_NCMBUTTONDBLCLK              :return L"WM_NCMBUTTONDBLCLK             ";
		case WM_NCXBUTTONDOWN                :return L"WM_NCXBUTTONDOWN               ";
		case WM_NCXBUTTONUP                  :return L"WM_NCXBUTTONUP                 ";
		case WM_NCXBUTTONDBLCLK              :return L"WM_NCXBUTTONDBLCLK             ";
		case WM_INPUT_DEVICE_CHANGE          :return L"WM_INPUT_DEVICE_CHANGE         ";
		case WM_KEYFIRST                     :return L"WM_KEYFIRST                    ";
		case WM_KEYUP                        :return L"WM_KEYUP                       ";
		case WM_CHAR                         :return L"WM_CHAR                        ";
		case WM_DEADCHAR                     :return L"WM_DEADCHAR                    ";
		case WM_SYSKEYDOWN                   :return L"WM_SYSKEYDOWN                  ";
		case WM_SYSKEYUP                     :return L"WM_SYSKEYUP                    ";
		case WM_SYSCHAR                      :return L"WM_SYSCHAR                     ";
		case WM_SYSDEADCHAR                  :return L"WM_SYSDEADCHAR                 ";
		case WM_UNICHAR                      :return L"WM_UNICHAR                     ";
		case WM_IME_STARTCOMPOSITION         :return L"WM_IME_STARTCOMPOSITION        ";
		case WM_IME_ENDCOMPOSITION           :return L"WM_IME_ENDCOMPOSITION          ";
		case WM_IME_COMPOSITION              :return L"WM_IME_COMPOSITION             ";
		case WM_INITDIALOG                   :return L"WM_INITDIALOG                  ";
		case WM_COMMAND                      :return L"WM_COMMAND                     ";
		case WM_SYSCOMMAND                   :return L"WM_SYSCOMMAND                  ";
		case WM_TIMER                        :return L"WM_TIMER                       ";
		case WM_HSCROLL                      :return L"WM_HSCROLL                     ";
		case WM_VSCROLL                      :return L"WM_VSCROLL                     ";
		case WM_INITMENU                     :return L"WM_INITMENU                    ";
		case WM_INITMENUPOPUP                :return L"WM_INITMENUPOPUP               ";
		case WM_MENUSELECT                   :return L"WM_MENUSELECT                  ";
		case WM_MENUCHAR                     :return L"WM_MENUCHAR                    ";
		case WM_ENTERIDLE                    :return L"WM_ENTERIDLE                   ";
		case WM_MENURBUTTONUP                :return L"WM_MENURBUTTONUP               ";
		case WM_MENUDRAG                     :return L"WM_MENUDRAG                    ";
		case WM_MENUGETOBJECT                :return L"WM_MENUGETOBJECT               ";
		case WM_UNINITMENUPOPUP              :return L"WM_UNINITMENUPOPUP             ";
		case WM_MENUCOMMAND                  :return L"WM_MENUCOMMAND                 ";
		case WM_CHANGEUISTATE                :return L"WM_CHANGEUISTATE               ";
		case WM_UPDATEUISTATE                :return L"WM_UPDATEUISTATE               ";
		case WM_QUERYUISTATE                 :return L"WM_QUERYUISTATE                ";
		case WM_CTLCOLORMSGBOX               :return L"WM_CTLCOLORMSGBOX              ";
		case WM_CTLCOLOREDIT                 :return L"WM_CTLCOLOREDIT                ";
		case WM_CTLCOLORLISTBOX              :return L"WM_CTLCOLORLISTBOX             ";
		case WM_CTLCOLORBTN                  :return L"WM_CTLCOLORBTN                 ";
		case WM_CTLCOLORDLG                  :return L"WM_CTLCOLORDLG                 ";
		case WM_CTLCOLORSCROLLBAR            :return L"WM_CTLCOLORSCROLLBAR           ";
		case WM_CTLCOLORSTATIC               :return L"WM_CTLCOLORSTATIC              ";
		case MN_GETHMENU                     :return L"MN_GETHMENU                    ";
		case WM_MOUSEFIRST                   :return L"WM_MOUSEFIRST                  ";
		case WM_LBUTTONDOWN                  :return L"WM_LBUTTONDOWN                 ";
		case WM_LBUTTONUP                    :return L"WM_LBUTTONUP                   ";
		case WM_LBUTTONDBLCLK                :return L"WM_LBUTTONDBLCLK               ";
		case WM_RBUTTONDOWN                  :return L"WM_RBUTTONDOWN                 ";
		case WM_RBUTTONUP                    :return L"WM_RBUTTONUP                   ";
		case WM_RBUTTONDBLCLK                :return L"WM_RBUTTONDBLCLK               ";
		case WM_MBUTTONDOWN                  :return L"WM_MBUTTONDOWN                 ";
		case WM_MBUTTONUP                    :return L"WM_MBUTTONUP                   ";
		case WM_MBUTTONDBLCLK                :return L"WM_MBUTTONDBLCLK               ";
		case WM_MOUSEWHEEL                   :return L"WM_MOUSEWHEEL                  ";
		case WM_XBUTTONDOWN                  :return L"WM_XBUTTONDOWN                 ";
		case WM_XBUTTONUP                    :return L"WM_XBUTTONUP                   ";
		case WM_XBUTTONDBLCLK                :return L"WM_XBUTTONDBLCLK               ";
		case WM_MOUSEHWHEEL                  :return L"WM_MOUSEHWHEEL                 ";
		case WM_PARENTNOTIFY                 :return L"WM_PARENTNOTIFY                ";
		case WM_ENTERMENULOOP                :return L"WM_ENTERMENULOOP               ";
		case WM_EXITMENULOOP                 :return L"WM_EXITMENULOOP                ";
		case WM_NEXTMENU                     :return L"WM_NEXTMENU                    ";
		case WM_SIZING                       :return L"WM_SIZING                      ";
		case WM_CAPTURECHANGED               :return L"WM_CAPTURECHANGED              ";
		case WM_MOVING                       :return L"WM_MOVING                      ";
		case WM_POWERBROADCAST               :return L"WM_POWERBROADCAST              ";
		case WM_DEVICECHANGE                 :return L"WM_DEVICECHANGE                ";
		case WM_MDICREATE                    :return L"WM_MDICREATE                   ";
		case WM_MDIDESTROY                   :return L"WM_MDIDESTROY                  ";
		case WM_MDIACTIVATE                  :return L"WM_MDIACTIVATE                 ";
		case WM_MDIRESTORE                   :return L"WM_MDIRESTORE                  ";
		case WM_MDINEXT                      :return L"WM_MDINEXT                     ";
		case WM_MDIMAXIMIZE                  :return L"WM_MDIMAXIMIZE                 ";
		case WM_MDITILE                      :return L"WM_MDITILE                     ";
		case WM_MDICASCADE                   :return L"WM_MDICASCADE                  ";
		case WM_MDIICONARRANGE               :return L"WM_MDIICONARRANGE              ";
		case WM_MDIGETACTIVE                 :return L"WM_MDIGETACTIVE                ";
		case WM_MDISETMENU                   :return L"WM_MDISETMENU                  ";
		case WM_ENTERSIZEMOVE                :return L"WM_ENTERSIZEMOVE               ";
		case WM_EXITSIZEMOVE                 :return L"WM_EXITSIZEMOVE                ";
		case WM_DROPFILES                    :return L"WM_DROPFILES                   ";
		case WM_MDIREFRESHMENU               :return L"WM_MDIREFRESHMENU              ";
		case WM_IME_SETCONTEXT               :return L"WM_IME_SETCONTEXT              ";
		case WM_IME_NOTIFY                   :return L"WM_IME_NOTIFY                  ";
		case WM_IME_CONTROL                  :return L"WM_IME_CONTROL                 ";
		case WM_IME_COMPOSITIONFULL          :return L"WM_IME_COMPOSITIONFULL         ";
		case WM_IME_SELECT                   :return L"WM_IME_SELECT                  ";
		case WM_IME_CHAR                     :return L"WM_IME_CHAR                    ";
		case WM_IME_REQUEST                  :return L"WM_IME_REQUEST                 ";
		case WM_IME_KEYDOWN                  :return L"WM_IME_KEYDOWN                 ";
		case WM_IME_KEYUP                    :return L"WM_IME_KEYUP                   ";
		case WM_MOUSEHOVER                   :return L"WM_MOUSEHOVER                  ";
		case WM_MOUSELEAVE                   :return L"WM_MOUSELEAVE                  ";
		case WM_NCMOUSEHOVER                 :return L"WM_NCMOUSEHOVER                ";
		case WM_NCMOUSELEAVE                 :return L"WM_NCMOUSELEAVE                ";
		case WM_WTSSESSION_CHANGE            :return L"WM_WTSSESSION_CHANGE           ";
		case WM_TABLET_FIRST                 :return L"WM_TABLET_FIRST                ";
		case WM_TABLET_LAST                  :return L"WM_TABLET_LAST                 ";
		case WM_CUT                          :return L"WM_CUT                         ";
		case WM_COPY                         :return L"WM_COPY                        ";
		case WM_PASTE                        :return L"WM_PASTE                       ";
		case WM_CLEAR                        :return L"WM_CLEAR                       ";
		case WM_UNDO                         :return L"WM_UNDO                        ";
		case WM_RENDERFORMAT                 :return L"WM_RENDERFORMAT                ";
		case WM_RENDERALLFORMATS             :return L"WM_RENDERALLFORMATS            ";
		case WM_DESTROYCLIPBOARD             :return L"WM_DESTROYCLIPBOARD            ";
		case WM_DRAWCLIPBOARD                :return L"WM_DRAWCLIPBOARD               ";
		case WM_PAINTCLIPBOARD               :return L"WM_PAINTCLIPBOARD              ";
		case WM_VSCROLLCLIPBOARD             :return L"WM_VSCROLLCLIPBOARD            ";
		case WM_SIZECLIPBOARD                :return L"WM_SIZECLIPBOARD               ";
		case WM_ASKCBFORMATNAME              :return L"WM_ASKCBFORMATNAME             ";
		case WM_CHANGECBCHAIN                :return L"WM_CHANGECBCHAIN               ";
		case WM_HSCROLLCLIPBOARD             :return L"WM_HSCROLLCLIPBOARD            ";
		case WM_QUERYNEWPALETTE              :return L"WM_QUERYNEWPALETTE             ";
		case WM_PALETTEISCHANGING            :return L"WM_PALETTEISCHANGING           ";
		case WM_PALETTECHANGED               :return L"WM_PALETTECHANGED              ";
		case WM_HOTKEY                       :return L"WM_HOTKEY                      ";
		case WM_PRINT                        :return L"WM_PRINT                       ";
		case WM_PRINTCLIENT                  :return L"WM_PRINTCLIENT                 ";
		case WM_APPCOMMAND                   :return L"WM_APPCOMMAND                  ";
		case WM_THEMECHANGED                 :return L"WM_THEMECHANGED                ";
		case WM_CLIPBOARDUPDATE              :return L"WM_CLIPBOARDUPDATE             ";
		case WM_DWMCOMPOSITIONCHANGED        :return L"WM_DWMCOMPOSITIONCHANGED       ";
		case WM_DWMNCRENDERINGCHANGED        :return L"WM_DWMNCRENDERINGCHANGED       ";
		case WM_DWMCOLORIZATIONCOLORCHANGED  :return L"WM_DWMCOLORIZATIONCOLORCHANGED ";
		case WM_DWMWINDOWMAXIMIZEDCHANGE     :return L"WM_DWMWINDOWMAXIMIZEDCHANGE    ";
		case WM_GETTITLEBARINFOEX            :return L"WM_GETTITLEBARINFOEX           ";
		case WM_HANDHELDFIRST                :return L"WM_HANDHELDFIRST               ";
		case WM_HANDHELDLAST                 :return L"WM_HANDHELDLAST                ";
		case WM_AFXFIRST                     :return L"WM_AFXFIRST                    ";
		case WM_AFXLAST                      :return L"WM_AFXLAST                     ";
		case WM_PENWINFIRST                  :return L"WM_PENWINFIRST                 ";
		case WM_PENWINLAST                   :return L"WM_PENWINLAST                  ";
		case WM_USER                         :return L"WM_USER                        ";
		case 0xc02b							 :return L"WM_SHELLHOOKMESSAGE			  ";
	}
	return L"Unknown message";
}

//FindNextFile ni ishlatmaganimiz uchun uning My -yi kerakmas;
HANDLE WINAPI MyFindFirstFileExWM(__in  LPCWSTR lpFileName,             // file name
								  __in  FINDEX_INFO_LEVELS fInfoLevelId,// information level
								  __out LPVOID lpFindFileData,          // information buffer
								  __in  FINDEX_SEARCH_OPS fSearchOp,    // filtering type
								  __reserved LPVOID lpSearchFilter,     // search criteria
								  __in DWORD dwAdditionalFlags)			// additional search control
{
wchar_t s[MAX_PATH];int l;
HANDLE hDir,r=FindFirstFileExW(lpFileName,fInfoLevelId,lpFindFileData,fSearchOp,lpSearchFilter,dwAdditionalFlags);
l=MyStringCpy(s,MAX_PATH-1,(wchar_t*)lpFileName);
if('*'==s[l-1])
{	s[l-1]=0;
}
else if('\\'!=s[l-1])
{	s[l++]='\\';
	s[l]=0;
}
hDir = CreateFileW(s,FILE_LIST_DIRECTORY,FILE_SHARE_READ|FILE_SHARE_DELETE,NULL,
						 OPEN_EXISTING,FILE_FLAG_BACKUP_SEMANTICS,NULL);
	if(INVALID_HANDLE_VALUE!=hDir)
	{	CloseHandle(hDir);
		((WIN32_FIND_DATAW*)lpFindFileData)->dwFileAttributes |= FILE_ATTRIBUTE_DIRECTORY;
	}
	return r;

}

HANDLE WINAPI MyFindFirstFileExAM(__in  LPCSTR lpFileName,             // file name
								  __in  FINDEX_INFO_LEVELS fInfoLevelId,// information level
								  __out LPVOID lpFindFileData,          // information buffer
								  __in  FINDEX_SEARCH_OPS fSearchOp,    // filtering type
								  __reserved LPVOID lpSearchFilter,     // search criteria
								  __in DWORD dwAdditionalFlags)			// additional search control
{
int l;char s[MAX_PATH];
HANDLE hDir,r=FindFirstFileExA(lpFileName,fInfoLevelId,lpFindFileData,fSearchOp,lpSearchFilter,dwAdditionalFlags);
l=MyStringCpyA(s,MAX_PATH-1,(char*)lpFileName);
if('*'==s[l-1])
{	s[l-1]=0;
}
else if('\\'!=s[l-1])
{	s[l++]='\\';
	s[l]=0;
}
hDir = CreateFileA(s,FILE_LIST_DIRECTORY,FILE_SHARE_READ|FILE_SHARE_DELETE,NULL,
						 OPEN_EXISTING,FILE_FLAG_BACKUP_SEMANTICS,NULL);
	if(INVALID_HANDLE_VALUE!=hDir)
	{	CloseHandle(hDir);
		((WIN32_FIND_DATA*)lpFindFileData)->dwFileAttributes |= FILE_ATTRIBUTE_DIRECTORY;
	}
	return r;

}

__declspec (dllexport) HICON GetPanelEntryIcon(HWND prnt,int entryType,int entryNum)
{
	switch(entryNum)
	{	case 0:
			return LoadIcon(hInst,MAKEINTRESOURCE(IDI_ICON_Ctrl_A));
		case 1:
			return LoadIcon(hInst,MAKEINTRESOURCE(IDI_ICON_Ctrl_T));
		case 2:
			return LoadIcon(hInst,MAKEINTRESOURCE(IDI_ICON_Ctrl_W));
		case 3:
			return LoadIcon(hInst,MAKEINTRESOURCE(IDI_ICON_F1));
		case 4:
			return LoadIcon(hInst,MAKEINTRESOURCE(IDI_ICON_Ctrl_F1));
		case 5:
			return LoadIcon(hInst,MAKEINTRESOURCE(IDI_ICON_Ctrl_F2));
		case 6:
			return LoadIcon(hInst,MAKEINTRESOURCE(IDI_ICON_Ctrl_F3));
		case 7:
			return LoadIcon(hInst,MAKEINTRESOURCE(IDI_ICON_Ctrl_F4));
		case 8:
			return LoadIcon(hInst,MAKEINTRESOURCE(IDI_ICON_F2));
		case 9:
			return LoadIcon(hInst,MAKEINTRESOURCE(IDI_ICON_F3));
		case 10:
			return LoadIcon(hInst,MAKEINTRESOURCE(IDI_ICON_F4));
		case 11:
			return LoadIcon(hInst,MAKEINTRESOURCE(IDI_ICON_Copy));
		case 12:
			return LoadIcon(hInst,MAKEINTRESOURCE(IDI_ICON_Rename));//IDI_ICON_Backslash));
		case 13:
			return LoadIcon(hInst,MAKEINTRESOURCE(IDI_ICON_Alt_F7));
		case 14:
			return LoadIcon(hInst,MAKEINTRESOURCE(IDI_ICON_F7));
		case 15:
			return LoadIcon(hInst,MAKEINTRESOURCE(IDI_ICON_Backslash));
		case 16:
			return LoadIcon(hInst,MAKEINTRESOURCE(IDI_ICON_NumPud_Plus));
		case 17:
			return LoadIcon(hInst,MAKEINTRESOURCE(IDI_ICON_Space));
		case 18:
			return LoadIcon(hInst,MAKEINTRESOURCE(IDI_ICON_Insert));
		case 19:
			return LoadIcon(hInst,MAKEINTRESOURCE(IDI_ICON_PgUp));
		case 20:
			return LoadIcon(hInst,MAKEINTRESOURCE(IDI_ICON_PgDown));
		case 21:
			return LoadIcon(hInst,MAKEINTRESOURCE(IDI_ICON_End));
		case 22:
			return LoadIcon(hInst,MAKEINTRESOURCE(IDI_ICON_Home));
		case 23:
			return LoadIcon(hInst,MAKEINTRESOURCE(IDI_ICON_Up));
		case 24:
			return LoadIcon(hInst,MAKEINTRESOURCE(IDI_ICON_Down));
		case 25:
			return LoadIcon(hInst,MAKEINTRESOURCE(IDI_ICON_Escape));
		case 27:
			return LoadIcon(hInst,MAKEINTRESOURCE(IDI_ICON_Left));
		case 28:
			return LoadIcon(hInst,MAKEINTRESOURCE(IDI_ICON_Right));
		case 29:
			return LoadIcon(hInst,MAKEINTRESOURCE(IDI_ICON_Alt_Enter));
		case 30:
			return LoadIcon(hInst,MAKEINTRESOURCE(IDI_ICON_Enter));
		case 31:
			return LoadIcon(hInst,MAKEINTRESOURCE(IDI_ICON_Shift_PgUp));			
		case 32:
			return LoadIcon(hInst,MAKEINTRESOURCE(IDI_ICON_Shift_PgDown));
		case 33:
			return LoadIcon(hInst,MAKEINTRESOURCE(IDI_ICON_Shift_Left));
		case 34:
			return LoadIcon(hInst,MAKEINTRESOURCE(IDI_ICON_Shift_Right));
		case 35:
			return LoadIcon(hInst,MAKEINTRESOURCE(IDI_ICON_Shift_End));
		case 36:
			return LoadIcon(hInst,MAKEINTRESOURCE(IDI_ICON_Shift_Home));
		case 37:
			return LoadIcon(hInst,MAKEINTRESOURCE(IDI_ICON_Shift_Up));
		case 38:
			return LoadIcon(hInst,MAKEINTRESOURCE(IDI_ICON_Shift_Down));
		case 39:
			return LoadIcon(hInst,MAKEINTRESOURCE(IDI_ICON_Delete));
		case 40:
			return LoadIcon(hInst,MAKEINTRESOURCE(IDI_ICON_Delete2));
		case 41:
			return LoadIcon(hInst,MAKEINTRESOURCE(IDI_ICON_Shift_Delete));
	}
	return LoadIcon(hInst,MAKEINTRESOURCE(IDI_ICON_EMPTY_ENTRY));
}

__declspec (dllexport) __out HANDLE WINAPI MyFindFirstFileExA(
										LPCTSTR lpFileName,              // file name
										FINDEX_INFO_LEVELS fInfoLevelId, // information level
										LPVOID lpFindFileData,           // information buffer
										FINDEX_SEARCH_OPS fSearchOp,     // filtering type
										LPVOID lpSearchFilter,           // search criteria
										DWORD dwAdditionalFlags)
{
	if(bMyFindFirst)
		return FindFirstFileExA((LPCSTR)lpFileName,fInfoLevelId,lpFindFileData,fSearchOp,lpSearchFilter,dwAdditionalFlags);
	//else
	return MyFindFirstFileExAM((LPCSTR)(lpFileName),fInfoLevelId,lpFindFileData,fSearchOp,lpSearchFilter,dwAdditionalFlags);
}

__declspec (dllexport) __out HANDLE WINAPI MyFindFirstFileEx(
										LPCWSTR lpFileName,              // file name
										FINDEX_INFO_LEVELS fInfoLevelId, // information level
										LPVOID lpFindFileData,           // information buffer
										FINDEX_SEARCH_OPS fSearchOp,     // filtering type
										LPVOID lpSearchFilter,           // search criteria
										DWORD dwAdditionalFlags)
{
	if(bMyFindFirst)
		return FindFirstFileExW(lpFileName,fInfoLevelId,lpFindFileData,fSearchOp,lpSearchFilter,dwAdditionalFlags);
	//else
	return MyFindFirstFileExWM(lpFileName,fInfoLevelId,lpFindFileData,fSearchOp,lpSearchFilter,dwAdditionalFlags);
}

__declspec (dllexport) BOOL IsFileExistA(char *name)
{
WIN32_FIND_DATA ff;
HANDLE			hf = INVALID_HANDLE_VALUE;
	if(!name)return FALSE;
	if(0==name[0])return FALSE;
	hf = MyFindFirstFileExA((LPCTSTR)name,FindExInfoStandard,&ff,FindExSearchNameMatch,NULL,0);
	if(INVALID_HANDLE_VALUE==hf) return FALSE;
	FindClose(hf);
	if(FILE_ATTRIBUTE_DIRECTORY & ff.dwFileAttributes)
		return FALSE;
	return TRUE;
}

__declspec (dllexport) BOOL IsFileExist(wchar_t *name)
{
WIN32_FIND_DATA ff;
HANDLE			hf = INVALID_HANDLE_VALUE;
	if(!name)return FALSE;
	if(0==name[0])return FALSE;
	hf = MyFindFirstFileEx(name,FindExInfoStandard,&ff,FindExSearchNameMatch,NULL,0);
	if(INVALID_HANDLE_VALUE==hf) return FALSE;
	FindClose(hf);
	if(FILE_ATTRIBUTE_DIRECTORY & ff.dwFileAttributes)
		return FALSE;
	return TRUE;
}

extern int MyStringCpy(wchar_t*,int,wchar_t*);
__declspec (dllexport) BOOL IsDirExist(wchar_t *path)
{
/*HANDLE hDir;
WIN32_FIND_DATA ff;
int l;
wchar_t s[MAX_PATH];	__int64 d[6];

	if(!path)return FALSE;
	if(0==path[0])return FALSE;
	l=MyStringCpy(s,MAX_PATH-1,path);

	if(l>4 && '*'==s[l-1] && '.'==s[l-2] && '*'==s[l-3] && '\\'==s[l-4])// oxiri "\*.*"
		;//s[l-4] = 0;	
	else if(l>2 && '*'==s[l-1] && '\\'==s[l-2])// oxiri "\*"
	{ s[l++] = '.';s[l++] = '*';s[l] = 0; }
	else if(l>1 && '\\'==s[l-1] && '\\'!=s[l-2] && '*'!=s[l-2])// oxiri "\"
	{ s[l++] = '*';s[l++] = '.';s[l++] = '*';s[l] = 0; }
	else
	{ s[l++] = '\\';s[l++] = '*';s[l++] = '.';s[l++] = '*';s[l] = 0; }
	hDir = FindFirstFile(s,&ff);QueryPerformanceCounter(&d[1]);da katta chiqdi CrF dan ko'ra;
	if(INVALID_HANDLE_VALUE==hDir)
	{	l=GetLastError();
		return FALSE;
	}FindClose(hDir);
	return TRUE;*/
HANDLE hDir;
wchar_t s[MAX_PATH];
int l;
	if(!path)return FALSE;
	if(0==path[0])return FALSE;
l=MyStringCpy(s,MAX_PATH-1,path);

if('*'==s[l-1])
{	s[l-1]=0;
}
else if('\\'!=s[l-1])
{	if(l<MAX_PATH-1)
	{	s[l++]='\\';
		s[l]=0;
	}
	else return FALSE;
}
	hDir = CreateFileW(s,								  // pointer to the file name
					  FILE_LIST_DIRECTORY,                // access (read/write) mode
					  FILE_SHARE_READ|FILE_SHARE_DELETE,  // share mode
					  NULL,                               // security descriptor
					  OPEN_EXISTING,                      // how to create
					  FILE_FLAG_BACKUP_SEMANTICS,         // file attributes
					  NULL);                              // file with attributes to copy
	if(INVALID_HANDLE_VALUE==hDir) return FALSE;
	CloseHandle(hDir);
	return TRUE;
}

extern int MyStringCpyA(char*,int,char*);
__declspec (dllexport) BOOL IsDirExistA(char *path)
{
HANDLE hDir;
char s[MAX_PATH];
int l;
	if(!path)return FALSE;
	if(0==path[0])return FALSE;
l=MyStringCpyA(s,MAX_PATH-1,path);

if('*'==s[l-1])
{	s[l-1]=0;
}
else if('\\'!=s[l-1])
{	if(l<MAX_PATH-1)
	{	s[l++]='\\';
		s[l]=0;
	}
	else return FALSE;
}
	hDir = CreateFileA(s,								  // pointer to the file name
					  FILE_LIST_DIRECTORY,                // access (read/write) mode
					  FILE_SHARE_READ|FILE_SHARE_DELETE,  // share mode
					  NULL,                               // security descriptor
					  OPEN_EXISTING,                      // how to create
					  FILE_FLAG_BACKUP_SEMANTICS,         // file attributes
					  NULL);                              // file with attributes to copy
	if(INVALID_HANDLE_VALUE==hDir) return FALSE;
	CloseHandle(hDir);
	return TRUE;
}

__declspec (dllexport) int CmpFILETIMEs(FILETIME* f1,FILETIME* f2)
{
	unsigned __int64 f641 = ((unsigned __int64)f1->dwHighDateTime << 32) & (unsigned __int64)f1->dwLowDateTime;
	unsigned __int64 f642 = ((unsigned __int64)f2->dwHighDateTime << 32) & (unsigned __int64)f2->dwLowDateTime;
	if(f641 > f642) return  1;
	if(f641 < f642) return -1;
	return 0;
}

__declspec (dllexport) int CmpFILETIMEsBetween(FILETIME* f1,FILETIME* f2,FILETIME* f3)
{//cmp 3 between 1 & 2:
	unsigned __int64 f641 = ((unsigned __int64)f1->dwHighDateTime << 32) & (unsigned __int64)f1->dwLowDateTime;
	unsigned __int64 f642 = ((unsigned __int64)f2->dwHighDateTime << 32) & (unsigned __int64)f2->dwLowDateTime;
	unsigned __int64 f643 = ((unsigned __int64)f3->dwHighDateTime << 32) & (unsigned __int64)f3->dwLowDateTime;
	if(f641 <= f643)
	if(f642 >= f643)
		return 1;
	return 0;
}

__declspec (dllexport) int CmpFILETIMEsL(FILETIME* f1,LARGE_INTEGER* f2)
{
	unsigned __int64 f641 = ((unsigned __int64)f1->dwHighDateTime << 32) & (unsigned __int64)f1->dwLowDateTime;
	unsigned __int64 f642 = ((unsigned __int64)f2->HighPart << 32) & (unsigned __int64)f2->LowPart;
	if(f641 > f642) return  1;
	if(f641 < f642) return -1;
	return 0;
}

__declspec (dllexport) int CmpFILETIMEsBetweenL(FILETIME* f1,FILETIME* f2,LARGE_INTEGER* f3)
{//cmp 3 between 1 & 2:
	unsigned __int64 f641 = ((unsigned __int64)f1->dwHighDateTime << 32) & (unsigned __int64)f1->dwLowDateTime;
	unsigned __int64 f642 = ((unsigned __int64)f2->dwHighDateTime << 32) & (unsigned __int64)f2->dwLowDateTime;
	unsigned __int64 f643 = ((unsigned __int64)f3->HighPart << 32) & (unsigned __int64)f3->LowPart;
	if(f641 <= f643)
	if(f642 >= f643)
		return 1;
	return 0;
}

__declspec (dllexport) VOID InitLOGFONTA(LOGFONTA* lf)
{
	lf->lfCharSet=204;//Kirill
	lf->lfClipPrecision=2;
	lf->lfEscapement=0;
	StringCchPrintfA(lf->lfFaceName,LF_FACESIZE,"Arial");//"Tahoma");//Arial Narrow");
	lf->lfHeight=-11;//12;
	lf->lfItalic=0;
	lf->lfOrientation=0;
	lf->lfOutPrecision=3;
	lf->lfPitchAndFamily=34;
	lf->lfQuality=1;
	lf->lfStrikeOut=0;
	lf->lfUnderline=0;
	lf->lfWeight=700;//400;
	lf->lfWidth=0;
}

__declspec (dllexport) VOID InitLOGFONT(LOGFONTW* lf)
{
	lf->lfCharSet=204;//Kirill
	lf->lfClipPrecision=2;
	lf->lfEscapement=0;
	StringCchPrintfW(lf->lfFaceName,LF_FACESIZE,L"Arial");//"Tahoma");//Arial Narrow");
	lf->lfHeight=-11;//12;
	lf->lfItalic=0;
	lf->lfOrientation=0;
	lf->lfOutPrecision=3;
	lf->lfPitchAndFamily=34;
	lf->lfQuality=1;
	lf->lfStrikeOut=0;
	lf->lfUnderline=0;
	lf->lfWeight=700;//400;
	lf->lfWidth=0;
}