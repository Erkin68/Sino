// TestMyBtnClass.cpp : Defines the entry point for the application.
//

#include "windows.h"
#include "resource.h"
#include "..\MyButton.h"
#include "..\MyShell.h"


HINSTANCE hInst;
MyButton btn1,btn2,btn3;

INT_PTR CALLBACK MyDlgProc(HWND, UINT, WPARAM, LPARAM);

int APIENTRY WinMain(HINSTANCE hInstance,HINSTANCE hPrevInstance,LPSTR lpCmdLine,int nCmdShow)
{
hInst = hInstance;
	char *s=calcMD5_MAX_PATH_stringA("abra_KadabRa");
	wchar_t *ws=calcMD5_MAX_PATH_string(L"abra_KadabRa");
	return DialogBox(hInst, MAKEINTRESOURCE(IDD_MY_DIALOG), NULL, MyDlgProc);
}

INT_PTR CALLBACK MyDlgProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	UNREFERENCED_PARAMETER(lParam);
	switch (message)
	{
	case WM_INITDIALOG:
		btn1.Init(hDlg,L"Btn1",1,0,10,10,200,50);
		btn2.Init(hDlg,L"Btn2",1,0,250,10,200,50);
		btn3.Init(hDlg,L"Alfabody Btn2",1,0,50,110,50,25);
		return (INT_PTR)TRUE;

	case WM_COMMAND:
		if (LOWORD(wParam) == IDOK || LOWORD(wParam) == IDCANCEL)
		{
			EndDialog(hDlg, LOWORD(wParam));
			return (INT_PTR)TRUE;
		}
		break;
	}
	return (INT_PTR)FALSE;
}