#ifndef _MY_SHELL_H_
#define _MY_SHELL_H_

#include "windows.h"
#include "stdio.h"
#include "resource.h"

extern "C"
{

typedef __out HANDLE (WINAPI *FindFirstFileExA_t)(__in LPCSTR,
												  __in FINDEX_INFO_LEVELS,
												  __out LPVOID,
												  __in FINDEX_SEARCH_OPS,
												  __reserved LPVOID,
												  __in DWORD);
typedef __out HANDLE (WINAPI *FindFirstFileExW_t)(__in LPCWSTR,
												  __in FINDEX_INFO_LEVELS,
												  __out LPVOID,
												  __in FINDEX_SEARCH_OPS,
												  __reserved LPVOID,
												  __in DWORD);
extern HANDLE WINAPI MyFindFirstFileExA(__in  LPCTSTR lpFileName,      // file name
								  __in  FINDEX_INFO_LEVELS fInfoLevelId,// information level
								  __out LPVOID lpFindFileData,          // information buffer
								  __in  FINDEX_SEARCH_OPS fSearchOp,    // filtering type
								  __reserved LPVOID lpSearchFilter,     // search criteria
								  __in DWORD dwAdditionalFlags);		// additionaional search control
extern HANDLE WINAPI MyFindFirstFileEx(__in  LPCWSTR lpFileName,      // file name
								  __in  FINDEX_INFO_LEVELS fInfoLevelId,// information level
								  __out LPVOID lpFindFileData,          // information buffer
								  __in  FINDEX_SEARCH_OPS fSearchOp,    // filtering type
								  __reserved LPVOID lpSearchFilter,     // search criteria
								  __in DWORD dwAdditionalFlags);		// additionaional search control
//extern FindFirstFileExW_t MyFindFirstFileEx;
//extern FindFirstFileExA_t MyFindFirstFileExA;
extern HANDLE WINAPI MyFindFirstFileExWM(__in LPCWSTR lpFileName,      // file name
								 __in  FINDEX_INFO_LEVELS fInfoLevelId,// information level
								 __out LPVOID lpFindFileData,          // information buffer
								 __in  FINDEX_SEARCH_OPS fSearchOp,    // filtering type
								 __reserved LPVOID lpSearchFilter,     // search criteria
								 __in DWORD dwAdditionalFlags);		   // additional search control
extern HANDLE WINAPI MyFindFirstFileExAM(__in LPCSTR lpFileName,              // file name
								 __in  FINDEX_INFO_LEVELS fInfoLevelId,// information level
								 __out LPVOID lpFindFileData,          // information buffer
								 __in  FINDEX_SEARCH_OPS fSearchOp,    // filtering type
								 __reserved LPVOID lpSearchFilter,     // search criteria
								 __in DWORD dwAdditionalFlags);		   // additional search control

extern BOOL IsFileExistA(char*);
extern BOOL IsFileExist(wchar_t*);
extern BOOL IsDirExistA(char*);
extern BOOL IsDirExist(wchar_t*);
extern LPSTR GetWinNotifyTextA(DWORD);
extern LPWSTR GetWinNotifyText(DWORD);
extern BOOL  GetImgResFrPE(HWND,LPWSTR*,LPTSTR*,LPWSTR*,int*);
extern HICON GetPanelEntryIcon(HWND,int,int);


extern int MyStringCpyA(char*,int,char*);
extern int MyStringCpy(wchar_t*,int, wchar_t*);
extern int MyStringLengthA(char*,int);
extern int MyStringLength(wchar_t*,int);
extern VOID ConvertToLittleA(char*,int);
extern VOID ConvertToLittle(wchar_t*,int);
extern char* ConvertToLittleRA(char*,int);
extern wchar_t* ConvertToLittleR(wchar_t*,int);
extern unsigned __int64 MyAtoU64A(char*);
extern unsigned __int64 MyAtoU64(wchar_t *);
extern BOOL MyU64ToA(char*,int,unsigned __int64 );
extern BOOL MyU64To(wchar_t* ,int ,unsigned __int64 );
extern char* MyStringAddModulePathA(char*);
extern wchar_t* MyStringAddModulePath(wchar_t*);
extern int MyStringCatA(char*,int,char*);
extern int MyStringCat(wchar_t*,int,wchar_t*);
extern int MyStringEraseEndAndCatA(char*,int,char*);
extern int MyStringEraseEndAndCat(wchar_t*,int,wchar_t*);
extern char *MyStringFindFirstUnmatchA(char*,char*,int);
extern wchar_t *MyStringFindFirstUnmatch(wchar_t*,wchar_t*,int);
extern BOOL MyStrCmpNA(char*, char*,int);
extern BOOL MyStrCmpNW(wchar_t*,wchar_t*,int);
extern BOOL IsBin(char);
extern char* MyStrCmpBinNA(char*,char*,int,int);
extern wchar_t* MyStrCmpBinNW(wchar_t*,wchar_t*,int,int);
extern BOOL MyStrCmpNotRelUpRegNA(char*, char*, int);
extern BOOL MyStrCmpNotRelUpRegNW(wchar_t*,wchar_t*,int);
extern wchar_t* MyStrRChrN(wchar_t*,int,wchar_t,int);
extern VOID MyTimeToStringA(char*,DWORD);
extern VOID MyTimeToString(wchar_t *,DWORD);
extern int MyStringPrintDecSpaceA(char*, __int64);
extern int MyStringPrintDecSpace(wchar_t*, __int64);
extern int MyStringPrintDecSpace1(wchar_t*, __int64);
extern BOOL MyStringRemoveLastCharA(char*,int,char);
extern BOOL MyStringRemoveLastChar(wchar_t*,int,wchar_t);
extern BOOL MyStringRemoveLastCharCheckPreA(char*,int,char,char);
extern BOOL MyStringRemoveLastCharCheckPre(wchar_t*,int,wchar_t,wchar_t);
extern BOOL MySubstrA(char*,char*,int,int);
extern BOOL MySubstr(wchar_t*,wchar_t*,int,int);
extern char* MyStrCmpNNA(char*,char*,int,int);
extern wchar_t* MyStrCmpNNW(wchar_t*,wchar_t*,int,int);
extern BOOL MyInet4StrToDword(wchar_t*,char*,DWORD*);
//extern wchar_t* MyWcsstrNoCase(wchar_t*,wchar_t*);
extern VOID InitLOGFONTA(LOGFONTA*);
extern VOID InitLOGFONT(LOGFONTW*);
extern int CmpFILETIMEs(FILETIME*,FILETIME*);
extern int CmpFILETIMEsBetween(FILETIME*,FILETIME*,FILETIME*);
extern int CmpFILETIMEsL(FILETIME*,LARGE_INTEGER*);
extern int CmpFILETIMEsBetweenL(FILETIME*,FILETIME*,LARGE_INTEGER*);
extern int fscanLineString(FILE*,int,wchar_t*);
extern int fscanLineString1(FILE*,int,wchar_t*);
extern VOID UpItem(HWND,int,int);
extern VOID TimeToEdit(FILETIME,HWND,int,int);
extern VOID LocTimeToEdit(HWND,int,int);
extern HANDLE MyFopenViaCrF(wchar_t*,const wchar_t*);
extern HANDLE MyFopenViaCrFA(char*,const char*);
extern VOID AlignDayFrSpin(HWND,WPARAM,int,wchar_t*);
extern VOID AlignHourFrSpin(HWND,WPARAM,int,wchar_t*);
extern VOID AlignMilsFrSpin(HWND,WPARAM,int,wchar_t*);
extern VOID AlignMinFrSpin(HWND,WPARAM,int,wchar_t*);
extern VOID AlignMoonFrSpin(HWND,WPARAM,int,wchar_t*);
extern VOID AlignSecFrSpin(HWND,WPARAM,int,wchar_t*);
extern VOID AlignYearFrSpin(HWND,WPARAM,int,wchar_t*);
extern BOOL EditsToFileTime(FILETIME*,wchar_t*,wchar_t*);
extern BOOL IsCrntOrPrntDirAttrbW(wchar_t*);
//extern VOID EditToFileTime(HWND hDlg, int edtDateId, int edtTimeId);
extern void AssertFatal(BOOL,LPWSTR);

extern char* calcMD5_MAX_PATH_stringA(char*);
extern wchar_t* calcMD5_MAX_PATH_string(wchar_t*);

extern HBITMAP BuildBitmapFromIcon(HICON,int,int,int,int,int,int);
extern HBITMAP LoadIconAsBitmap(HMODULE,int);

//UtilityCpp.cpp
typedef struct TAddtnMenuItems
{	TAddtnMenuItems *pNext;
	wchar_t			*itemStr;
	int             iPan;
	int				iPanItem;
	int				iMsg;
} AddtnMenuItems;
extern __declspec (dllexport) BOOL DoExplorerMenu(HWND,LPWSTR,POINT*,AddtnMenuItems*);
extern VOID SetFnt(HFONT*);

extern void __declspec (dllexport) CreateAllDirs(wchar_t*);
extern void __declspec (dllexport) ChangePrivilege(DWORD,DWORD,BOOL);

extern __declspec (dllexport) BOOL GetOleClipboardPasteState();

}


#endif