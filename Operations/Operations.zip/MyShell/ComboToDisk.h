#ifndef _COMBO_TO_DISK_H_
#define _COMBO_TO_DISK_H_

#include "windows.h"


#define DLLEXP __declspec(dllexport)

class DLLEXP CBToDisk
{
public:
static BOOL 	AddToCB(HWND,wchar_t*,BOOL setInEdit=FALSE);
static BOOL	DeleteFrCB(HWND, wchar_t*);
static BOOL	GetCBEditText(HWND, wchar_t*,int);

public:
			CBToDisk();
		   ~CBToDisk();
	BOOL	RealRead(wchar_t*,HWND,int,int);
	BOOL	Read(wchar_t*,HWND,int,int);
	VOID	RealSave();
	BOOL	Save(wchar_t*,HWND,int);
protected:
	VOID	*buf;
	int		cnt;
};

extern CBToDisk selV7PthCB;
extern CBToDisk selV7TxtCB;
extern CBToDisk selV7ExclTxt;
extern CBToDisk selV7NameCB;
extern CBToDisk selPlusCB;
extern CBToDisk selPlusCB1;
extern CBToDisk cmnCmndsCB;
extern CBToDisk pnlPthAndNamesCB[4];//MAX_PANELS];
extern CBToDisk arcCrNamesCB;
extern CBToDisk cmdCB;
extern CBToDisk btnPnlPropIconPthCB;
extern CBToDisk btnPnlPropPthCB;

#define selPlusCBFName L"Config\\CBToDsk.bin:stream2"
#define selPlusCB1FName L"Config\\CBToDsk.bin:stream3"
#define cmnCmndsCBFName L"Config\\CBToDsk.bin:stream4"
#define pnlPthAndNamesCB0FName L"Config\\CBToDsk1.bin"
#define pnlPthAndNamesCB1FName L"Config\\CBToDsk1.bin:stream2"
#define pnlPthAndNamesCB2FName L"Config\\CBToDsk2.bin:stream3"
#define pnlPthAndNamesCB3FName L"Config\\CBToDsk2.bin:stream4"
#define arcCrNamesCBFName L"Config\\CBToDsk3.bin"
#define cmdCbPATH L"Config\\CBToDsk3.bin:stream2"
#define btnPnlPropIconPthCBPATH  L"Config\\CBToDsk3.bin:stream3"
#define btnPnlPropPthCBPATH  L"Config\\CBToDsk4.bin"

#endif