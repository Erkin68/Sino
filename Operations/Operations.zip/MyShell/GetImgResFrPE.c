#include "windows.h"
#include "strsafe.h"
#include "resource.h"
#include <commdlg.h>
#include "Icons.h"


extern HINSTANCE hInst;

extern int MyStringCpy(wchar_t*,int, wchar_t*);
extern BOOL IsDirExist(wchar_t*);
extern int MyStringLength(wchar_t*,int);


int  IsThisValidDllOrExeFile(wchar_t*);
BOOL CALLBACK EnumResTypeProc(HMODULE,LPTSTR,LONG_PTR);
BOOL CALLBACK EnumResNameProc(HMODULE,LPCTSTR,LPTSTR,LONG_PTR);
INT_PTR CALLBACK GetIconFromPEDlg(HWND,UINT,WPARAM,LPARAM);
BOOL NEAR PASCAL TestNotify(HWND,LPOFNOTIFY);
BOOL QueuePEToDlg(HWND hDlg,wchar_t*);

HMODULE hm=0;
int iReses[7];
wchar_t dllExeName[MAX_PATH];
UINT cdmsgShareViolation = 0;  // identifier from RegisterWindowMessage
UINT cdmsgFileOK         = 0;  // identifier from RegisterWindowMessage
UINT cdmsgHelp           = 0;  // identifier from RegisterWindowMessage

LPCWSTR lpres;wchar_t strres[MAX_PATH];
LPTSTR  resType;
int     retResGrpNum;

__declspec (dllexport) BOOL GetImgResFrPE(HWND prnt,LPWSTR *PEModulePathAndName,
										  LPTSTR *lpszType,LPWSTR *lpszRes,int *grpID)
{
int r;OPENFILENAME OpenFileName;
	MyStringCpy(dllExeName,MAX_PATH-1,(wchar_t*)(*PEModulePathAndName));
	if(!IsDirExist(dllExeName))
	{	wchar_t *p = wcsrchr(dllExeName,'\\');
		if(p)*(p+1)=0;
	}
	OpenFileName.lStructSize       = sizeof(OPENFILENAME);
    OpenFileName.hwndOwner         = prnt;
    OpenFileName.hInstance         = hInst;
    OpenFileName.lpstrFilter       = L"From 'exe' files (*.exe)\0*.exe\0From 'dll' files (*.dll)\0*.dll\0Icon files (*.ico)\0*.ico\0Bitmap files (*.bmp)\0*.bmp\0Cursor files (*.cur)\0*.cur\0";//Jpg files (*.jpg)\0*.jpg\0Jpeg files (*.jpeg)\0*.jpeg\0";
    OpenFileName.lpstrCustomFilter = NULL;
    OpenFileName.nMaxCustFilter    = 0;
    OpenFileName.nFilterIndex      = 0;
    OpenFileName.lpstrFile         = dllExeName;
    OpenFileName.nMaxFile          = MAX_PATH;
    OpenFileName.lpstrFileTitle    = NULL;
    OpenFileName.nMaxFileTitle     = 0;
	OpenFileName.lpstrInitialDir   = IsDirExist(dllExeName)?dllExeName:NULL;
	OpenFileName.lpstrTitle        = L"Open a File for image extracting:";
    OpenFileName.nFileOffset       = 0;
    OpenFileName.nFileExtension    = 0;
    OpenFileName.lpstrDefExt       = NULL;
    OpenFileName.lCustData         = (LPARAM)NULL;//(LPARAM)&sMyData;
	OpenFileName.lpfnHook 		   = (LPOFNHOOKPROC)GetIconFromPEDlg;
	OpenFileName.lpTemplateName    = MAKEINTRESOURCE(IDD_DIALOG_GET_ICON_FROM_PE_FILE);
    OpenFileName.Flags             = OFN_SHOWHELP | OFN_EXPLORER | OFN_ENABLEHOOK | OFN_ENABLETEMPLATE;
    r = GetOpenFileName(&OpenFileName);
	if(r)
	{	*lpszType = resType;
		if(((UINT)lpres)<65536)
			*lpszRes = (LPWSTR)lpres;
		else
			MyStringCpy((wchar_t*)(*lpszRes),MAX_PATH-1,(wchar_t*)lpres);
		MyStringCpy((wchar_t*)(*PEModulePathAndName),MAX_PATH-1,(wchar_t*)dllExeName);
		*grpID = retResGrpNum;
	}
	else r = CommDlgExtendedError();
	if(hm) FreeLibrary(hm);
	return (r>0);
}

BOOL CALLBACK EnumResTypeProc(HMODULE hModule,LPTSTR lpszType,LONG_PTR lParam)
{
//int iCursorReses,iAniIconReses,iBmpReses,iCursorReses,iGrCursorReses,iGrIconReses,iIconReses;
	if(RT_ANICURSOR==lpszType)++iReses[0];//++iCursorReses;				21
	else if(RT_ANIICON==lpszType)++iReses[1];//++iAniIconReses;			22
	else if(RT_BITMAP==lpszType)++iReses[2];//++iBmpReses;				2
	else if(RT_CURSOR==lpszType)++iReses[3];//++iCursorReses;			1	
	else if(RT_GROUP_CURSOR==lpszType)++iReses[4];//++iGrCursorReses;	1+11
	else if(RT_GROUP_ICON==lpszType)++iReses[5];//++iGrIconReses;		3+11
	else if(RT_ICON==lpszType)++iReses[6];//++iIconReses;				3
	return TRUE;
}

BOOL CALLBACK EnumResNameProc(HMODULE hModule,LPCTSTR lpszType,LPTSTR lpszName,LONG_PTR lParam)
{
wchar_t ss[MAX_PATH];int l,i;

	if(((unsigned int)lpszName)<65536)
		StringCchPrintfW(ss,32,L"N %d",LOWORD(lpszName));
	else
		MyStringCpy(ss,MAX_PATH-1,(wchar_t*)lpszName);
	l=MyStringLength(ss,MAX_PATH);
	if(RT_ANICURSOR==lpszType)
	{	MyStringCpy(&ss[l],MAX_PATH-1-l,L" RT_ANICURSOR");
		SendMessageW(GetDlgItem((HWND)lParam,IDC_LIST_ICON_RES_NUM),LB_ADDSTRING,0,(LPARAM)ss);
	}
	else if(RT_ANIICON==lpszType)
	{	MyStringCpy(&ss[l],MAX_PATH-1-l,L" RT_ANIICON");
		SendMessageW(GetDlgItem((HWND)lParam,IDC_LIST_ICON_RES_NUM),LB_ADDSTRING,0,(LPARAM)ss);
	}
	else if(RT_BITMAP==lpszType)
	{	MyStringCpy(&ss[l],MAX_PATH-1-l,L" RT_BITMAP");
		SendMessageW(GetDlgItem((HWND)lParam,IDC_LIST_ICON_RES_NUM),LB_ADDSTRING,0,(LPARAM)ss);
	}
	else if(RT_CURSOR==lpszType)
	{	MyStringCpy(&ss[l],MAX_PATH-1-l,L" RT_CURSOR");
		SendMessageW(GetDlgItem((HWND)lParam,IDC_LIST_ICON_RES_NUM),LB_ADDSTRING,0,(LPARAM)ss);
	}
	else if(RT_GROUP_CURSOR==lpszType)
	{	HRSRC hRsrc = FindResource(hModule,lpszName,RT_GROUP_CURSOR);
		HGLOBAL hgl = LoadResource(hModule, hRsrc);
		LPMEMICONDIR lpGrpIconDir = (LPMEMICONDIR)LockResource(hgl);
		//hRsrc = FindResource(hModule, MAKEINTRESOURCE(lpGrpIconDir->idEntries[0].nID ),RT_CURSOR);
		//hgl = LoadResource(hModule, hRsrc);
		//lpIconImage = LockResource(hgl);
		for(i=0; i<lpGrpIconDir->idCount; i++)
		{	StringCchPrintfW(&ss[l],MAX_PATH-1-l,L" RT_GROUP_CURSOR~%d",i);
			SendMessageW(GetDlgItem((HWND)lParam,IDC_LIST_ICON_RES_NUM),LB_ADDSTRING,0,(LPARAM)ss);
		}
		FreeResource(hgl);
	}
	else if(RT_GROUP_ICON==lpszType)
	{	HRSRC hRsrc = FindResourceW(hModule,lpszName,RT_GROUP_ICON);
		HGLOBAL hgl = LoadResource(hModule, hRsrc);
		LPMEMICONDIR lpGrpIconDir = (LPMEMICONDIR)LockResource(hgl);
		//hRsrc = FindResource(hModule, MAKEINTRESOURCE(lpGrpIconDir->idEntries[0].nID),RT_ICON);
		//hGlobal = LoadResource(hModule, hRsrc);
		//lpIconImage = LockResource(hgl);
		for(i=0; i<lpGrpIconDir->idCount; i++)
		{	StringCchPrintfW(&ss[l],MAX_PATH-1-l,L" RT_GROUP_ICON~%d",i);
			SendMessageW(GetDlgItem((HWND)lParam,IDC_LIST_ICON_RES_NUM),LB_ADDSTRING,0,(LPARAM)ss);
		}
		FreeResource(hgl);
	}
	else if(RT_ICON==lpszType)
	{	MyStringCpy(&ss[l],MAX_PATH-1-l,L" RT_ICON");
		SendMessageW(GetDlgItem((HWND)lParam,IDC_LIST_ICON_RES_NUM),LB_ADDSTRING,0,(LPARAM)ss);
	}
	return TRUE;
}

//IN - s da - exeDllName, IN lParam - &pBtn[i] OUT EndDialog 1 -suzsess,0-cancel;
INT_PTR CALLBACK GetIconFromPEDlg(HWND hDlg,UINT message,WPARAM wParam,LPARAM lParam)
{
	//int iCursorReses,iAniIconReses,iBmpReses,iCursorReses,iGrCursorReses,iGrIconReses,iIconReses;
	UNREFERENCED_PARAMETER(lParam);
	switch(message)
	{
	case WM_INITDIALOG:
		return TRUE;
	case WM_NOTIFY:
		TestNotify(hDlg, (LPOFNOTIFY)lParam);
		return 0;
	case WM_COMMAND:
		switch(LOWORD(wParam))
		{	case IDC_LIST_ICON_RES_NUM:
				if(LBN_SELCHANGE==HIWORD(wParam))
				{	int r=(int)SendMessage(GetDlgItem(hDlg,IDC_LIST_ICON_RES_NUM),LB_GETCURSEL,0,0);
					wchar_t *p,ss[MAX_PATH]={0};SendMessageW(GetDlgItem(hDlg,IDC_LIST_ICON_RES_NUM),LB_GETTEXT,r,(LPARAM)ss);
					if(LB_ERR!=r)
					{	HDC dc = GetDC(GetDlgItem(hDlg,IDC_CUSTOM_DRAW_ICON));//RenderItem(r)
						Rectangle(dc,0,0,280,270);
						if(!dc)return 0;
						if('N'==ss[0])
							lpres=(LPCWSTR)_wtoi(&ss[2]);
						else
						{	p = wcsrchr(ss,' ');
							*p = 0;
							MyStringCpy(strres,MAX_PATH,ss);
							lpres=(LPCWSTR)&strres[0];
							*p=' ';
						}
						p=wcsstr(ss,L" RT_")+3;
						if('M' == *(p+4))//RT_BITMAP
						{	HBITMAP h=(HBITMAP)LoadImageW(hm,lpres,IMAGE_BITMAP,0,0,LR_CREATEDIBSECTION | LR_DEFAULTSIZE);
							BITMAP  bm;HDC hMemDC;GetObject(h, sizeof(BITMAP), &bm);
							hMemDC = CreateCompatibleDC( NULL );
							SelectObject(hMemDC,h);
							if(bm.bmWidth>280 || bm.bmHeight>270)
								StretchBlt(dc,0,0,280,270,hMemDC,0,0,bm.bmWidth,bm.bmHeight,SRCCOPY);
							else
								BitBlt(dc,(280-bm.bmWidth)/2,(270-bm.bmHeight)/2,bm.bmWidth,bm.bmHeight,hMemDC,0,0,SRCCOPY);
							DeleteObject(hMemDC);
							DeleteObject(h);
							resType = RT_BITMAP;
						}
						else if('S' == *(p+4) || 'C' == *(p+4))//RT_CURSOR or RT_ANICURSOR
						{	HICON h=(HICON)LoadImageW(hm,lpres,IMAGE_ICON,0,0,0);
							if(!h)//h=ExtractIcon(hInst,dllExeName,(UINT)lpres);
							{	HRSRC res=FindResource(hm,(LPCWSTR)lpres,RT_CURSOR);
								if(!res) res=FindResource(hm,(LPCWSTR)lpres,RT_ANICURSOR);
								if(res)
								{	HGLOBAL hgl=LoadResource(hm,res);
									if(hgl)h=CreateIconFromResource((PBYTE)hgl,SizeofResource(hm,res),FALSE,0x00030000);
									FreeResource(hgl);
							}	}
							if(h)
							{	ICONINFO ii;GetIconInfo(h,&ii);
								if(!DrawIcon(dc,(280-ii.xHotspot)/2,(270-ii.yHotspot)/2,h))
									DrawIconEx(dc,(280-ii.xHotspot)/2,(270-ii.yHotspot)/2,h,0,0,0,NULL,DI_NORMAL);
								DestroyIcon(h);
							}
							resType = ('S' == *(p+4)) ? RT_CURSOR : RT_ANICURSOR;
						}
						else if('N' == *(p+4) || 'I' == *(p+4))//RT_ICON & RT_ANIICON
						{	HICON h=(HICON)LoadImageW(hm,lpres,IMAGE_ICON,0,0,0);
							if(!h)//h=ExtractIcon(hInst,dllExeName,(UINT)lpres);
							{	HRSRC res=FindResource(hm,(LPCWSTR)lpres,RT_ICON);
								if(!res) res=FindResource(hm,(LPCWSTR)lpres,RT_ANIICON);
								if(res)
								{	HGLOBAL hgl=LoadResource(hm,res);
									if(hgl)h=CreateIconFromResource((PBYTE)hgl,SizeofResource(hm,res),TRUE,0x00030000);
									FreeResource(hgl);
							}	}
							if(h)
							{	ICONINFO ii;GetIconInfo(h,&ii);
								if(!DrawIcon(dc,(280-ii.xHotspot)/2,(270-ii.yHotspot)/2,h))
									DrawIconEx(dc,(280-ii.xHotspot)/2,(270-ii.yHotspot)/2,h,0,0,0,NULL,DI_NORMAL);
								DestroyIcon(h);
							}
							resType = ('N' == *(p+4)) ? RT_ICON : RT_ANIICON;
						}
						else if('C' == *(p+7))//RT_GROUP_CURSOR
						{	HRSRC res = FindResourceW(hm,(LPCWSTR)lpres,RT_GROUP_CURSOR);
							HGLOBAL hgl = LoadResource(hm, res);
							LPMEMICONDIR lpGrpIconDir = (LPMEMICONDIR)LockResource(hgl);
							retResGrpNum=_wtoi(wcsrchr(ss,'~')+1);
							res = FindResource(hm,MAKEINTRESOURCE(lpGrpIconDir->idEntries[retResGrpNum].nID),RT_CURSOR);
							if(res)
							{	HGLOBAL hglchld = LoadResource(hm, res);
								if(hglchld)
								{	HICON h=CreateIconFromResource((PBYTE)hglchld,SizeofResource(hm,res),FALSE,0x00030000);
									if(!DrawIcon(dc,(280-lpGrpIconDir->idEntries[retResGrpNum].bWidth)/2,
													(270-lpGrpIconDir->idEntries[retResGrpNum].bHeight)/2,h))
										DrawIconEx(dc,(280-lpGrpIconDir->idEntries[retResGrpNum].bWidth)/2,
													  (270-lpGrpIconDir->idEntries[retResGrpNum].bHeight)/2,h,0,0,0,NULL,DI_NORMAL);
									DestroyIcon(h);
									FreeResource(hglchld);
									resType = RT_GROUP_CURSOR;
							}	}
							FreeResource(hgl);
						}
						else if('I' == *(p+7))//RT_GROUP_ICON
						{	HRSRC res = FindResourceW(hm,(LPCWSTR)lpres,RT_GROUP_ICON);
							HGLOBAL hgl = LoadResource(hm, res);
							LPMEMICONDIR lpGrpIconDir = (LPMEMICONDIR)LockResource(hgl);
							retResGrpNum=_wtoi(wcsrchr(ss,'~')+1);
							res = FindResource(hm,MAKEINTRESOURCE(lpGrpIconDir->idEntries[retResGrpNum].nID),RT_ICON);
							if(res)
							{	HGLOBAL hglchld = LoadResource(hm, res);
								if(hglchld)
								{	HICON h=CreateIconFromResource((PBYTE)hglchld,SizeofResource(hm,res),TRUE,0x00030000);
									if(!DrawIcon(dc,(280-lpGrpIconDir->idEntries[retResGrpNum].bWidth)/2,
													(270-lpGrpIconDir->idEntries[retResGrpNum].bHeight)/2,h))
										DrawIconEx(dc,(280-lpGrpIconDir->idEntries[retResGrpNum].bWidth)/2,
													  (270-lpGrpIconDir->idEntries[retResGrpNum].bHeight)/2,h,0,0,0,NULL,DI_NORMAL);
									DestroyIcon(h);
									FreeResource(hglchld);
									resType = RT_GROUP_ICON;
							}	}
							FreeResource(hgl);
						}
						ReleaseDC(GetDlgItem(hDlg,IDC_CUSTOM_DRAW_ICON),dc);
				}	}
				return 0;
			case IDOK:
				if(hm)FreeLibrary(hm);
				EndDialog(hDlg,1);
				return 0;
			case IDCANCEL:
				if(hm)FreeLibrary(hm);
				EndDialog(hDlg,0);//DestroyWindow(hDlg); if CreateDialog used;
				return 0;
		}
		break;
	default:
		//static int i=0;
		//char ss[32];sprintf(ss,"\n %d ",i++);
		//OutputDebugStringA(ss);
		//OutputDebugStringA(GetWinNotifyText(message));

		if (message == cdmsgFileOK)
		{	SetDlgItemText(hDlg, IDC_EDIT_FILE, ((LPOPENFILENAME)lParam)->lpstrFile);
			break;
		}
		else if(message == 0x84)
		{	/*wchar_t szFile[MAX_PATH];
			int ln = CommDlg_OpenSave_GetFilePath(GetParent(hDlg), szFile, MAX_PATH);
			szFile[ln++]=' ';
			CommDlg_OpenSave_GetSpec(GetParent(hDlg),&szFile[ln], sizeof(szFile));//) <= sizeof(szFile))
			SetDlgItemText(hDlg, IDC_EDIT_FILE, szFile);
			QueuePEToDlg(hDlg,szFile);*/
			break;
		}
		else if (message == cdmsgShareViolation)
		{
			break;
	}	}
	return (INT_PTR)FALSE;
}

BOOL IsExeInPEHeader(wchar_t* buffer, unsigned long size)
{
IMAGE_DOS_HEADER* dos_header;
IMAGE_NT_HEADERS* header;
	wchar_t pe_magic[] = L"\x50\x45\x00\x00\x4c\x01";
	const WORD magic_value = 267;
	// Check whether buffer contains enough bytes to contain a dos header
	if ((long)size < sizeof(IMAGE_DOS_HEADER))
	{
		return FALSE;
	}
	dos_header = (IMAGE_DOS_HEADER*) buffer;
	// Check whether buffer is large enough to contain a PE header
	if ((long)size < dos_header->e_lfanew || (long)size - dos_header->e_lfanew < sizeof(IMAGE_NT_HEADERS))
	{
		return FALSE;
	}
	header = (IMAGE_NT_HEADERS*) (buffer + dos_header->e_lfanew);

	// A PE header should start with this sequence (PE00)
	if (memcmp(header, pe_magic, 6))
		return FALSE;
	// Check magic value
	if (header->OptionalHeader.Magic != magic_value)
		return FALSE;

	// Win32 VersionValue should be zero
	if (header->OptionalHeader.Win32VersionValue != 0)
		return FALSE;

	// Check whether subsystem is sane one
	if (header->OptionalHeader.Subsystem != IMAGE_SUBSYSTEM_NATIVE &&
		header->OptionalHeader.Subsystem != IMAGE_SUBSYSTEM_UNKNOWN &&
		header->OptionalHeader.Subsystem != IMAGE_SUBSYSTEM_WINDOWS_GUI &&
		header->OptionalHeader.Subsystem != IMAGE_SUBSYSTEM_WINDOWS_CUI)
		return FALSE;

	if(!(IMAGE_FILE_EXECUTABLE_IMAGE & header->FileHeader.Characteristics))
		return FALSE;
	// Changes are that this is actually a valid PE header
	return TRUE;
}

int IsThisValidDllOrExeFile(wchar_t *filename)
{
LPVOID lpFileBase;BOOL bFndDll;PIMAGE_DOS_HEADER dosHeader;DWORD rd;
HANDLE hFile = CreateFile(	filename, GENERIC_READ, FILE_SHARE_READ, NULL,
							OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, 0);

    if ( hFile == INVALID_HANDLE_VALUE )
        return FALSE;

	lpFileBase = malloc(sizeof(IMAGE_DOS_HEADER)+2*sizeof(IMAGE_NT_HEADERS));
	ReadFile(hFile,lpFileBase,sizeof(IMAGE_DOS_HEADER)+2*sizeof(IMAGE_NT_HEADERS),&rd,NULL);
	bFndDll=0;
	if(rd!=sizeof(IMAGE_DOS_HEADER)+2*sizeof(IMAGE_NT_HEADERS))
		goto End;
	dosHeader = (PIMAGE_DOS_HEADER)lpFileBase;
    if ( dosHeader->e_magic == IMAGE_DOS_SIGNATURE )
    {   bFndDll = 1;
		if(IsExeInPEHeader( (wchar_t*)dosHeader, sizeof(IMAGE_DOS_HEADER)+2*sizeof(IMAGE_NT_HEADERS) ))
			bFndDll = 2;
    }
End:
    CloseHandle(hFile);
	free(lpFileBase);
	return bFndDll>0?TRUE:FALSE;
}

BOOL QueuePEToDlg(HWND hDlg,wchar_t *szFile)
{
HANDLE h;HDC dc;int i;
	SendMessage(GetDlgItem(hDlg,IDC_LIST_ICON_RES_NUM),LB_RESETCONTENT,0,0);
	if(!IsThisValidDllOrExeFile(szFile))
	{Br://MessageBox(hDlg,L"This is invalid \"exe\" or \"dll\" PE-file",szFile,MB_OK);
		h=LoadImageW(0,szFile,IMAGE_BITMAP,0,0,LR_CREATEDIBSECTION|LR_LOADFROMFILE);
		if(h)
		{	BITMAP bm;
			HDC hMemDC,dc = GetDC(GetDlgItem(hDlg,IDC_CUSTOM_DRAW_ICON));//RenderItem(r)
			Rectangle(dc,0,0,280,270);
			GetObject(h, sizeof(BITMAP), &bm);
			hMemDC = CreateCompatibleDC( NULL );
			SelectObject(hMemDC,h);
			if(bm.bmWidth>280 || bm.bmHeight>270)
				StretchBlt(dc,0,0,280,270,hMemDC,0,0,bm.bmWidth,bm.bmHeight,SRCCOPY);
			else
				BitBlt(dc,(280-bm.bmWidth)/2,(270-bm.bmHeight)/2,bm.bmWidth,bm.bmHeight,hMemDC,0,0,SRCCOPY);
			DeleteObject(hMemDC);
			DeleteObject(h);
			ReleaseDC(GetDlgItem(hDlg,IDC_CUSTOM_DRAW_ICON),dc);
			return TRUE;
		}
		else if(!h)//cursor ham shunga kiradi
		{	HICON h;ICONINFO ii;
			HDC dc = GetDC(GetDlgItem(hDlg,IDC_CUSTOM_DRAW_ICON));//RenderItem(r)
			Rectangle(dc,0,0,280,270);
			h=(HICON)LoadImageW(0,szFile,IMAGE_ICON,0,0,LR_LOADFROMFILE);
			GetIconInfo(h,&ii);
			if(!DrawIcon(dc,(280-ii.xHotspot)/2,(270-ii.yHotspot)/2,h))
				DrawIconEx(dc,(280-ii.xHotspot)/2,(270-ii.yHotspot)/2,h,0,0,0,NULL,DI_NORMAL);
			DestroyIcon(h);
			ReleaseDC(GetDlgItem(hDlg,IDC_CUSTOM_DRAW_ICON),dc);
			return TRUE;
		}
		/*else
		{	HDC dc = GetDC(GetDlgItem(hDlg,IDC_CUSTOM_DRAW_ICON));//RenderItem(r)
			Rectangle(dc,0,0,280,270);
			HICON h=LoadImageW(0,szFile,IMAGE_CURSOR,0,0,LR_LOADFROMFILE);
			ICONINFO ii;GetIconInfo(h,&ii);
			if(!DrawIcon(dc,(280-ii.xHotspot)/2,(270-ii.yHotspot)/2,h))
				DrawIconEx(dc,(280-ii.xHotspot)/2,(270-ii.yHotspot)/2,h,0,0,0,NULL,DI_NORMAL);
			DestroyIcon(h);
			ReleaseDC(GetDlgItem(hDlg,IDC_CUSTOM_DRAW_ICON),dc);
			return TRUE;
		}*/
		return FALSE;
	}
	if(hm)FreeLibrary(hm);
	hm=LoadLibrary(szFile);
	if(!hm)goto Br;

	MyStringCpy(dllExeName,MAX_PATH,szFile);

	for(i=0; i<7; ++i)iReses[i]=0;

	if(!EnumResourceTypes(hm,EnumResTypeProc,0))goto Br;
	if(!iReses[0])if(!iReses[1])if(!iReses[2])if(!iReses[3])if(!iReses[4])if(!iReses[5])if(!iReses[6])
	{   //MessageBox(hDlg,L"This PE-file is not consist valid image resource.",szFile,MB_OK);
		return FALSE;
	}
	if(iReses[0])EnumResourceNamesW(hm,RT_ANICURSOR,EnumResNameProc,(LONG_PTR)hDlg);
	if(iReses[1])EnumResourceNamesW(hm,RT_ANIICON,EnumResNameProc,(LONG_PTR)hDlg);
	if(iReses[2])EnumResourceNamesW(hm,RT_BITMAP,EnumResNameProc,(LONG_PTR)hDlg);
	if(iReses[3])EnumResourceNamesW(hm,RT_CURSOR,EnumResNameProc,(LONG_PTR)hDlg);
	if(iReses[4])EnumResourceNamesW(hm,RT_GROUP_CURSOR,EnumResNameProc,(LONG_PTR)hDlg);
	if(iReses[5])EnumResourceNamesW(hm,RT_GROUP_ICON,EnumResNameProc,(LONG_PTR)hDlg);
	if(iReses[6])EnumResourceNamesW(hm,RT_ICON,EnumResNameProc,(LONG_PTR)hDlg);
	dc = GetDC(GetDlgItem(hDlg,IDC_CUSTOM_DRAW_ICON));
	Rectangle(dc,0,0,280,270);
	ReleaseDC(GetDlgItem(hDlg,IDC_CUSTOM_DRAW_ICON),dc);
	return TRUE;
}

BOOL NEAR PASCAL TestNotify(HWND hDlg, LPOFNOTIFY pofn)
{
wchar_t szFile[MAX_PATH];			
	switch (pofn->hdr.code)
	{
		// The selection has changed. 
		case CDN_SELCHANGE:
		{	int ln = CommDlg_OpenSave_GetFilePath(GetParent(hDlg), szFile, MAX_PATH);
			szFile[ln++]=' ';
			CommDlg_OpenSave_GetSpec(GetParent(hDlg),&szFile[ln], sizeof(szFile));//) <= sizeof(szFile))
			SetDlgItemText(hDlg, IDC_EDIT_FILE, szFile);
			QueuePEToDlg(hDlg,szFile);
		}
		break;

		// A new folder has been opened.
		case CDN_FOLDERCHANGE:
		break;

		// The "Help" pushbutton has been pressed.
		case CDN_HELP:
			//MessageBoxA(hDlg, "Got the Help button notify.", "ComDlg32 Test", MB_OK);
			break;

		// The 'OK' pushbutton has been pressed.
		case CDN_FILEOK:
			// Update the appropriate box.
			//SetDlgItemTextW(hDlg,IDE_SELECTED, pofn->lpOFN->lpstrFile);
			SetWindowLongPtr(hDlg, DWLP_MSGRESULT, 1L);
			break;

		// Received a sharing violation.
		case CDN_SHAREVIOLATION:
			// Update the appropriate box.
			//SetDlgItemText(hDlg, IDE_SELECTED, pofn->pszFile);
			MessageBoxA(hDlg, "Got a sharing violation notify.", "ComDlg32 Test", MB_OK);
			break;
	}

	return(TRUE);
}

__declspec (dllexport) HBITMAP BuildBitmapFromIcon(HICON ic,int szX,int szY,int xPos,int yPos,int w,int h)
{	HDC dsktpDC=GetDC(GetDesktopWindow());
	HDC memDC = CreateCompatibleDC(dsktpDC);
    HBITMAP hBM = CreateCompatibleBitmap(dsktpDC,szX,szY);
    SelectObject(memDC,hBM);
	ReleaseDC(GetDesktopWindow(),dsktpDC);
	//DrawIcon(memDC,xPos,xPos,ic);
	//DrawIconEx(memDC,xPos,xPos,ic,w,h,0,GetStockObject(WHITE_BRUSH),DI_NORMAL);//DI_MASK);
	DrawIconEx(memDC,xPos,xPos,ic,w,h,0,GetStockObject(DC_BRUSH),DI_NORMAL);//DI_MASK);
	//DrawIconEx(memDC,xPos,xPos,ic,w,h,0,NULL,DI_NORMAL);//DI_MASK);
	DeleteObject(memDC);
	DeleteObject(ic);
	return hBM;
}

__declspec (dllexport) HBITMAP LoadIconAsBitmap(HMODULE hm,int iRes)
{	ICONINFO ii;HDC dsktpDC,memDC;HBITMAP hBM;
	HICON hi=LoadImage(hm,MAKEINTRESOURCE(iRes),IMAGE_ICON,0,0,LR_DEFAULTCOLOR);
	if(!hi)return 0;
	GetIconInfo(hi,&ii);
	dsktpDC=GetDC(GetDesktopWindow());
	memDC = CreateCompatibleDC(dsktpDC);
	hBM = CreateCompatibleBitmap(dsktpDC,2*ii.xHotspot,2*ii.yHotspot);
    SelectObject(memDC,hBM);
	ReleaseDC(GetDesktopWindow(),dsktpDC);
	//DrawIcon(memDC,xPos,xPos,ic);
	//DrawIconEx(memDC,xPos,xPos,ic,w,h,0,GetStockObject(WHITE_BRUSH),DI_NORMAL);//DI_MASK);
	DrawIconEx(memDC,0,0,hi,2*ii.xHotspot,2*ii.yHotspot,0,GetStockObject(DC_BRUSH),DI_NORMAL);//DI_MASK);
	//DrawIconEx(memDC,xPos,xPos,ic,w,h,0,NULL,DI_NORMAL);//DI_MASK);
	DeleteObject(memDC);
	DeleteObject(hi);
	return hBM;
}