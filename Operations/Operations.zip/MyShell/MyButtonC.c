#pragma comment(lib, "Comctl32.lib")


#include "MyButtonC.h"
#include "MyShellC.h"
#include "Commctrl.h"
#include "resource.h"
#include "..\..\resource.h"


extern HINSTANCE hInst;
HFONT *hfBtn=NULL;

static ATOM regClass=0;
static HBITMAP hBmpSimpleOld=NULL;
static HBITMAP hBmpHoveredOld;
static HBITMAP hBmpHoveredPushedOld;
static HDC hDCSimple;
static HDC hDCHovered;
static HDC hDCHoveredPushed;
static HBRUSH hBrsh;
//static HBRUSH hBrshHatch;
static HPEN hPen;
static MyButton* pFocusedBtn=NULL;

BOOL MyButtonDraw(MyButton*,HDC);

__declspec (dllexport) VOID SetFnt(HFONT *hf)
{	hfBtn=hf;
}

static ATOM MyRegisterClass(HINSTANCE hInstance)
{
HDC dc;
WNDCLASSEX wcex;
LOGBRUSH lb;DWORD st[2]={1,1};
HBITMAP hBmpSimple,hBmpHovered,hBmpHoveredPushed;
	if(regClass) return regClass;
	wcex.cbSize = sizeof(WNDCLASSEX);
	wcex.style			= CS_HREDRAW | CS_VREDRAW;
	wcex.lpfnWndProc	= BtnWndProc;
	wcex.cbClsExtra		= 0;
	wcex.cbWndExtra		= 0;
	wcex.hInstance		= hInstance;
	wcex.hIcon			= NULL;
	wcex.hCursor		= LoadCursor(NULL, IDC_ARROW);
	wcex.hbrBackground	= (HBRUSH)GetStockObject(BLACK_BRUSH);//(COLOR_WINDOW+1);
	wcex.lpszMenuName	= NULL;
	wcex.lpszClassName	= MYBTN_CLASSNAME_C;
	wcex.hIconSm		= NULL;//LoadIcon(wcex.hInstance, MAKEINTRESOURCE(IDI_SMALL));
	regClass = RegisterClassEx(&wcex);
	hBmpSimple = LoadBitmap(hInst,MAKEINTRESOURCE(IDB_BITMAP_SIMPLE));
	hBmpHovered = LoadBitmap(hInst,MAKEINTRESOURCE(IDB_BITMAP_HOVERED));
	hBmpHoveredPushed = LoadBitmap(hInst,MAKEINTRESOURCE(IDB_BITMAP_HOVERED_PUSHED));

	dc = GetDC(GetDesktopWindow());
	hDCSimple = CreateCompatibleDC(dc);
	hDCHovered = CreateCompatibleDC(dc);
	hDCHoveredPushed = CreateCompatibleDC(dc);
	hBmpSimpleOld = (HBITMAP)SelectObject(hDCSimple,hBmpSimple);
	hBmpHoveredOld = (HBITMAP)SelectObject(hDCHovered,hBmpHovered);
	hBmpHoveredPushedOld = (HBITMAP)SelectObject(hDCHoveredPushed,hBmpHoveredPushed);

	hBrsh = CreateSolidBrush(RGB(23,107,153));
	//hBrshHatch = CreateHatchBrush(HS_HORIZONTAL,RGB(0,0,0));

	ZeroMemory(&lb, sizeof(LOGBRUSH));
	lb.lbStyle = BS_SOLID;
	lb.lbColor = RGB(0,0,0);
	hPen = ExtCreatePen(PS_USERSTYLE, 1, &lb, 2, st);
	//hPen = CreatePen(PS_DASHDOT,1,RGB(0,50,25));
	//hPen = CreatePen(PS_SOLID,4,RGB(0,50,25));

	ReleaseDC(GetDesktopWindow(),dc);
	return regClass;
}

static LRESULT CALLBACK BtnWndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
int i;
HDC hdc;
MyButton *p;
PAINTSTRUCT ps;
MyButton *btn;
HFONT hOldFont;
	
	//static int k=0;
	//wchar_t s[32];wsprintf(s,L"\n %d ",k++);
	//OutputDebugString(s);
	//OutputDebugString(GetWinNotifyText(message));
	//wsprintf(s,L" %x %x",wParam,lParam);
	//OutputDebugString(s);

	btn = (MyButton*)GetWindowLongPtr(hWnd,GWLP_USERDATA);//GetWindowLong(hWnd,GWL_USERDATA);//Hamma(ishlaydigani uchun)
	if(message!=WM_CREATE)
	if(message!=WM_DESTROY)
	if(btn)
	if(1==btn->type || 2==btn->type)
		return DefWindowProc(hWnd, message, wParam, lParam);

	switch (message)
	{
	case WM_CREATE:
		if(NULL==((LPCREATESTRUCT)lParam)->lpCreateParams)
		{	HRGN hRndRgn;
			MyButton *b = (MyButton*)malloc(sizeof(MyButton));
			if(!b)return -1;
			b->hWndPrnt = ((LPCREATESTRUCT)lParam)->hwndParent;
			b->msgId = (WORD)((LPCREATESTRUCT)lParam)->hMenu;
			b->xPos = ((LPCREATESTRUCT)lParam)->x;
			b->yPos = ((LPCREATESTRUCT)lParam)->y;
			b->width = ((LPCREATESTRUCT)lParam)->cx;
			b->height = ((LPCREATESTRUCT)lParam)->cy;
			b->type = 0;
			b->toggleState = 0;
			b->captionLen=MyStringCpy(b->caption,MAX_PATH,(wchar_t*)(((LPCREATESTRUCT)lParam)->lpszName));
			hRndRgn = CreateRoundRectRgn(0,0,b->width,b->height,3,3);
			SetWindowRgn(b->hWnd,hRndRgn,TRUE);
			DeleteObject(hRndRgn);
			SetWindowLongPtr(hWnd,GWLP_USERDATA,(LONG)b);//SetWindowLong(hWnd,GWL_USERDATA,(LONG)b);
		}
		else SetWindowLongPtr(hWnd,GWLP_USERDATA,(LONG)(((LPCREATESTRUCT)lParam)->lpCreateParams));//SetWindowLong(hWnd,GWL_USERDATA,(LONG)(((LPCREATESTRUCT)lParam)->lpCreateParams));
		return 0;//-1 b-sa destroyed;
	case WM_PAINT:
		hdc = BeginPaint(hWnd, &ps);
		if(hfBtn)
			hOldFont=(HFONT)SelectObject(ps.hdc,*hfBtn);
		MyButtonDraw(btn,hdc);
		if(hfBtn)
			SelectObject(ps.hdc,hOldFont);
		EndPaint(hWnd, &ps);
		return 0;
	case WM_MOUSEFIRST://WM_MOUSEMOVE:
		if(1!=btn->toggleState)
		{	TRACKMOUSEEVENT tm_Event;
			tm_Event.cbSize = sizeof(TRACKMOUSEEVENT);
			tm_Event.dwFlags = TME_LEAVE;
			tm_Event.hwndTrack = hWnd;
			TrackMouseEvent(&tm_Event);
			btn->toggleState = (MK_LBUTTON==wParam)?2:1;
			InvalidateRect(hWnd,NULL,FALSE);
		}
		return 0;
	case WM_MOUSELEAVE:
		btn->toggleState = 0;
		InvalidateRect(hWnd,NULL,FALSE);
		return 0;
	case WM_KEYDOWN:
		if(VK_RETURN == wParam || VK_SPACE == wParam)
			goto LBtnDwn;
		return 0;
	case WM_LBUTTONDOWN:
LBtnDwn:btn->toggleState = 2;
		p = pFocusedBtn;
		pFocusedBtn = btn;
		InvalidateRect(hWnd,NULL,FALSE);
		if(p)
			InvalidateRect(p->hWnd,NULL,FALSE);
		return 0;
	case WM_LBUTTONUP:
LBtnUp:	i = btn->toggleState;
		btn->toggleState = 1;
		InvalidateRect(hWnd,NULL,FALSE);
		if(2==i)
			SendMessage(btn->hWndPrnt,WM_COMMAND,MAKELONG(btn->msgId,0),(LPARAM)btn->hWnd);
		return 0;
	case WM_KEYUP:
		if(VK_RETURN == wParam || VK_SPACE == wParam)
			goto LBtnUp;
		return 0;
	case WM_SETFOCUS:
		p = pFocusedBtn;
		pFocusedBtn = btn;
		InvalidateRect(hWnd,NULL,FALSE);
		if(p)
			InvalidateRect(p->hWnd,NULL,FALSE);
		return 0;
	case WM_KILLFOCUS:
		pFocusedBtn = NULL;
		InvalidateRect(hWnd,NULL,FALSE);
		return 0;
	case WM_SETTEXT:
		if(btn)
		{	btn->captionLen=MyStringCpy(btn->caption,MAX_PATH,(wchar_t*)lParam);
			InvalidateRect(btn->hWnd,NULL,FALSE);
		}
		return 0;
	case WM_DESTROY:
		if(btn==pFocusedBtn)
			pFocusedBtn = NULL;
		MyButtonDestroy(btn);
		return 0;
	default:
		return DefWindowProc(hWnd, message, wParam, lParam);
	}
	return 0;
}

__declspec(dllexport) MyButton* MyButtonInit(HWND p,wchar_t* txt,WORD id,int t,int x,int y,int w,int h)
{
HRGN hRndRgn;
MyButton *b = malloc(sizeof(MyButton));
	if(!b)return b;
	b->hWndPrnt = p;
	b->msgId = id;
	b->xPos = x;
	b->yPos = y;
	b->width = w;
	b->height = h;
	b->type = t;
	b->toggleState = 0;
	b->captionLen=MyStringCpy(b->caption,MAX_PATH,txt);
	MyRegisterClass(hInst);
	switch(t)
	{	case 0://MyShell-1:
			b->hWnd = CreateWindowEx(WS_EX_LEFT | WS_EX_LTRREADING | WS_EX_RIGHTSCROLLBAR | WS_EX_NOPARENTNOTIFY,// | WS_EX_CLIENTEDGE,
								(LPCTSTR)regClass,
								b->caption,
								//WS_BORDER | WS_VISIBLE | WS_CHILD,//WS_VISIBLE BS_PUSHBUTTON | BS_PUSHLIKE,
								WS_CHILDWINDOW | WS_VISIBLE | WS_TABSTOP | BS_PUSHBUTTON | BS_TEXT,
								b->xPos,
								b->yPos,
								b->width,
								b->height,
								b->hWndPrnt,
								(HMENU)b->msgId,
								hInst,
								b);
			break;
		case 1://std:
			b->hWnd = CreateWindowEx(WS_EX_LEFT | WS_EX_LTRREADING | WS_EX_RIGHTSCROLLBAR | WS_EX_NOPARENTNOTIFY,// | WS_EX_CLIENTEDGE,
								L"BUTTON",
								b->caption,
								WS_CHILDWINDOW | WS_VISIBLE | WS_TABSTOP | BS_PUSHBUTTON | BS_TEXT,//(WS_VISIBLE | WS_CHILD | BS_OWNERDRAW) : // | BS_PUSHBUTTON,//|BS_OWNERDRAW,
								b->xPos,
								b->yPos,
								b->width,
								b->height,
								b->hWndPrnt,
								(HMENU)b->msgId,
								hInst,
								b);
			break;
		case 2://ownedraw:
			b->hWnd = CreateWindowEx(WS_EX_LEFT | WS_EX_LTRREADING | WS_EX_RIGHTSCROLLBAR | WS_EX_NOPARENTNOTIFY,
								L"BUTTON",
								b->caption,
								WS_VISIBLE | WS_CHILD | BS_OWNERDRAW,
								b->xPos,
								b->yPos,
								b->width,
								b->height,
								b->hWndPrnt,
								(HMENU)b->msgId,
								hInst,
								b);
			break;
	}
	if(b->hWnd)
	{	UpdateWindow(b->hWnd);
		ShowWindow(b->hWnd,SW_SHOW);
	}
	else
	{	free(b);
		return NULL;
	}
	hRndRgn = CreateRoundRectRgn(0,0,b->width,b->height,3,3);
	SetWindowRgn(b->hWnd,hRndRgn,TRUE);
	DeleteObject(hRndRgn);
	//GetTextExtentPoint32
	return b;
}

__declspec(dllexport) MyButton* MyButtonFrRCBtn(HWND dlg,WORD id,int t)
{
wchar_t s[MAX_PATH];int w,h;RECT rc;
HWND bt = GetDlgItem(dlg,id);
	if(!bt)return NULL;
	GetWindowRect(bt,&rc);
	w = rc.right-rc.left;
	h = rc.bottom-rc.top;
	ScreenToClient(dlg,(LPPOINT)&rc.left);
	GetWindowText(bt,s,MAX_PATH);
	DestroyWindow(bt);
	return MyButtonInit(dlg,s,id,t,rc.left,rc.top,w,h);
}

VOID DLLEXP MyButtonDestroy(MyButton *btn)
{	free(btn);
	if(pFocusedBtn==btn)
		pFocusedBtn=NULL;
	return;
}

VOID MyButtonDestroyOnDetachDll()
{	if(hBmpSimpleOld)
	{	DeleteObject(SelectObject(hDCSimple, hBmpSimpleOld));
		DeleteObject(SelectObject(hDCHovered, hBmpHoveredOld));
		DeleteObject(SelectObject(hDCHoveredPushed, hBmpHoveredPushedOld));
		DeleteDC(hDCSimple);
		DeleteDC(hDCHovered);
		DeleteDC(hDCHoveredPushed);
		hBmpSimpleOld = NULL;
		DeleteObject(hBrsh);
		//DeleteObject(hBrshHatch);
		DeleteObject(hPen);
	}
	return;
}

BOOL MyButtonDraw(MyButton *b,HDC dc)
{
HPEN hPenOld;
	RECT rc = {0,0,b->width,b->height};
	//RECT rc = {2,2,width-4,height-4};
	SetBkMode(dc, TRANSPARENT);
	//HPEN hOldPen = (HPEN)SelectObject(dc,hPen);
	switch(b->toggleState)
	{	case 0://simple
			FillRect(dc,&rc,(HBRUSH)GetStockObject(BLACK_BRUSH));
			StretchBlt(dc,2,2,b->width-5,b->height-5,hDCSimple,0,0,1,2,SRCCOPY);//o'rtasi;
			StretchBlt(dc,1,2,1,b->height-5,hDCSimple,0,0,1,2,SRCCOPY);//chap tarafi
			StretchBlt(dc,b->width-3,2,1,b->height-5,hDCSimple,0,0,1,2,SRCCOPY);//o'ng tarafi
			StretchBlt(dc,2,1,b->width-5,1,hDCSimple,0,0,1,1,SRCCOPY);//tepasi;
			StretchBlt(dc,2,b->height-3,b->width-5,1,hDCSimple,0,1,1,1,SRCCOPY);//pasti;
			rc.top-=1;rc.bottom-=1;
			DrawText(dc,b->caption,b->captionLen,&rc,DT_VCENTER|DT_SINGLELINE|DT_CENTER);
			if(b==pFocusedBtn)
			{	hPenOld=(HPEN)SelectObject(dc,hPen);
				MoveToEx(dc,5,2,NULL);LineTo(dc,b->width-5,2);
				MoveToEx(dc,b->width-4,3,NULL);LineTo(dc,b->width-4,b->height-5);
				MoveToEx(dc,b->width-5,b->height-4,NULL);LineTo(dc,5,b->height-4);
				MoveToEx(dc,2,b->height-5,NULL);LineTo(dc,2,2);
				SelectObject(dc,hPenOld);
			}
			break;
		case 1://hover
			FillRect(dc,&rc,hBrsh);
			StretchBlt(dc,2,2,b->width-5,b->height-5,hDCHovered,0,0,1,2,SRCCOPY);//o'rtasi;
			StretchBlt(dc,1,2,1,b->height-5,hDCHovered,0,0,1,2,SRCCOPY);//chap tarafi
			StretchBlt(dc,b->width-3,2,1,b->height-5,hDCHovered,0,0,1,2,SRCCOPY);//o'ng tarafi
			StretchBlt(dc,2,1,b->width-5,1,hDCHovered,0,0,1,1,SRCCOPY);//tepasi;
			StretchBlt(dc,2,b->height-3,b->width-5,1,hDCHovered,0,1,1,1,SRCCOPY);//pasti;
			rc.left+=1;
			rc.right+=1;
			SetTextColor(dc,RGB(102,196,251));
			DrawText(dc,b->caption,b->captionLen,&rc,DT_VCENTER|DT_SINGLELINE|DT_CENTER);
			rc.left-=1;
			rc.top-=1;
			rc.right-=1;
			rc.bottom-=1;
			SetTextColor(dc,RGB(3,70,109));
			DrawText(dc,b->caption,b->captionLen,&rc,DT_VCENTER|DT_SINGLELINE|DT_CENTER);
			if(b==pFocusedBtn)
			{	hPenOld=(HPEN)SelectObject(dc,hPen);
				MoveToEx(dc,5,2,NULL);LineTo(dc,b->width-5,2);
				MoveToEx(dc,b->width-4,3,NULL);LineTo(dc,b->width-4,b->height-5);
				MoveToEx(dc,b->width-5,b->height-4,NULL);LineTo(dc,5,b->height-4);
				MoveToEx(dc,2,b->height-5,NULL);LineTo(dc,2,2);
				SelectObject(dc,hPenOld);
			}
			break;
		case 2://pressed
			FillRect(dc,&rc,hBrsh);
			StretchBlt(dc,3,3,b->width-6,b->height-6,hDCHoveredPushed,0,0,1,2,SRCCOPY);//o'rtasi;
			StretchBlt(dc,2,4,1,b->height-8,hDCHoveredPushed,0,0,1,2,SRCCOPY);//chap tarafi
			StretchBlt(dc,b->width-3,5,1,b->height-9,hDCHoveredPushed,0,0,1,2,SRCCOPY);//o'ng tarafi
			StretchBlt(dc,3,2,b->width-7,1,hDCHoveredPushed,0,0,1,1,SRCCOPY);//tepasi;
			StretchBlt(dc,3,b->height-3,b->width-7,1,hDCHoveredPushed,0,1,1,1,SRCCOPY);//pasti;
			rc.left+=1;
			rc.right+=1;
			rc.top+=1;
			rc.bottom+=1;
			SetTextColor(dc,RGB(102,196,251));
			DrawText(dc,b->caption,b->captionLen,&rc,DT_VCENTER|DT_SINGLELINE|DT_CENTER);
			rc.left-=1;
			rc.top-=1;
			rc.right-=1;
			rc.bottom-=1;
			SetTextColor(dc,RGB(2,60,64));
			DrawText(dc,b->caption,b->captionLen,&rc,DT_VCENTER|DT_SINGLELINE|DT_CENTER);
			if(b==pFocusedBtn)
			{	hPenOld=(HPEN)SelectObject(dc,hPen);
				MoveToEx(dc,5,3,NULL);LineTo(dc,b->width-5,3);
				MoveToEx(dc,b->width-4,6,NULL);LineTo(dc,b->width-4,b->height-7);
				MoveToEx(dc,b->width-6,b->height-4,NULL);LineTo(dc,5,b->height-4);
				MoveToEx(dc,3,b->height-7,NULL);LineTo(dc,3,5);
				SelectObject(dc,hPenOld);
			}
		break;
	}
	//DrawFrameControl(dc,&rc,DFC_BUTTON,DFCS_BUTTONPUSH);
	//DrawCaption(hWnd,dc,&rc,DC_ACTIVE|DC_INBUTTON);
	//DrawFocusRect(dc,&rc);
	//Rectangle(dc,0,0,width,height);
	//TextOut(dc,0,0,caption,wcslen(caption));
	//DeleteObject(SelectObject(dc,hOldPen));
	return TRUE;
}