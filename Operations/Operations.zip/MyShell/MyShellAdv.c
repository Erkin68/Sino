#include "stdio.h"

#pragma warning(disable:4996)



int fscanLineString(FILE *f,int MaxCnt,wchar_t *st)
{	wchar_t *pst = st;
	int i,iAst=0;
	for(i=0; i<MaxCnt; i++)
	{	int r = fwscanf(f,L"%c",pst);//int r = fread(pst,2,1,f);
		if(*pst=='"')
		{	iAst++;
			if(iAst<2) continue;
			if(iAst==2)
			{	*pst = 0x00;
				return (int)(pst-st);
		}	}
		if(EOF==r || r<1)//if(r<2)
		{	*pst = 0x00;
			return (int)(pst-st);
		}
		if(!iAst) continue;
		if(pst>st)
		{	if(0x0a==*pst)//if(0x0d==*(pst-1)) fscanf 0d ni olmaskan;
			if(pst != st)//boshida bo'lsayam 1 marta qo'yib bersun;
			{	*pst = 0x00;
				return (int)(pst-st);
		}	}
		if(0x0a!=*pst)//1-martaga;
			++pst;
	}
	*(pst-1) = 0x00;
	return (int)(pst-st-1);
}

int fscanLineString1(FILE *f, int MaxCnt, wchar_t *st)
{
int l=0,i,r;
fpos_t pos;fgetpos(f,&pos);
	r = (int)fread(st,2,MaxCnt-1,f);
	for(i=0; i<r; i++)
	{	if(*((wchar_t*)&st[i])==0x0a)
		{	l=i;
			st[i]=0;
			break;
	}	}
	if(l>0)
	{	if(l<r)//fseek(f,-2*(r-l+1),SEEK_CUR);
		{	pos += 2*(l+2);
			fsetpos(f,&pos);
		}
		return l;
	}
	//else
	st[r]=0;
	return r;
}
