#pragma comment(lib, "Comctl32.lib")


#include "MyButton.h"
#include "MyShell.h"
#include "Commctrl.h"
#include "resource.h"

extern "C"
{
extern HFONT *hfBtn;
extern HINSTANCE hInst;
}

ATOM MyButton::regClass=0;
HBITMAP MyButton::hBmpSimpleOld=NULL;
HBITMAP MyButton::hBmpHoveredOld;
HBITMAP MyButton::hBmpHoveredPushedOld;
HDC MyButton::hDCSimple;
HDC MyButton:: hDCHovered;
HDC MyButton::hDCHoveredPushed;
HBRUSH MyButton::hBrsh;
//HBRUSH MyButton::hBrshHatch;
HPEN MyButton::hPen;
int MyButton::mRef=0;

MyButton* MyButton::pFocusedBtn=NULL;

ATOM MyButton::MyRegisterClass(HINSTANCE hInstance)
{
	if(!regClass)
	{	WNDCLASSEX wcex;
		wcex.cbSize = sizeof(WNDCLASSEX);
		wcex.style			= CS_HREDRAW | CS_VREDRAW;
		wcex.lpfnWndProc	= BtnWndProc;
		wcex.cbClsExtra		= 0;
		wcex.cbWndExtra		= 0;
		wcex.hInstance		= hInstance;
		wcex.hIcon			= NULL;
		wcex.hCursor		= LoadCursor(NULL, IDC_ARROW);
		wcex.hbrBackground	= (HBRUSH)GetStockObject(BLACK_BRUSH);//(COLOR_WINDOW+1);
		wcex.lpszMenuName	= NULL;
		wcex.lpszClassName	= MYBTN_CLASSNAME;
		wcex.hIconSm		= NULL;//LoadIcon(wcex.hInstance, MAKEINTRESOURCE(IDI_SMALL));
		regClass = RegisterClassEx(&wcex);
	}

	if(0==mRef)
	{	HBITMAP hBmpSimple = LoadBitmap(hInst,MAKEINTRESOURCE(IDB_BITMAP_SIMPLE));
		HBITMAP hBmpHovered = LoadBitmap(hInst,MAKEINTRESOURCE(IDB_BITMAP_HOVERED));
		HBITMAP hBmpHoveredPushed = LoadBitmap(hInst,MAKEINTRESOURCE(IDB_BITMAP_HOVERED_PUSHED));

		HDC dc = GetDC(GetDesktopWindow());
		hDCSimple = CreateCompatibleDC(dc);
		hDCHovered = CreateCompatibleDC(dc);
		hDCHoveredPushed = CreateCompatibleDC(dc);
		hBmpSimpleOld = (HBITMAP)SelectObject(hDCSimple,hBmpSimple);
		hBmpHoveredOld = (HBITMAP)SelectObject(hDCHovered,hBmpHovered);
		hBmpHoveredPushedOld = (HBITMAP)SelectObject(hDCHoveredPushed,hBmpHoveredPushed);

		hBrsh = CreateSolidBrush(RGB(23,107,153));
		//hBrshHatch = CreateHatchBrush(HS_HORIZONTAL,RGB(0,0,0));

		LOGBRUSH lb;DWORD st[2]={1,1};
		ZeroMemory(&lb, sizeof(LOGBRUSH));
		lb.lbStyle = BS_SOLID;
		lb.lbColor = RGB(0,0,0);
		hPen = ExtCreatePen(PS_USERSTYLE, 1, &lb, 2, st);
		//hPen = CreatePen(PS_DASHDOT,1,RGB(0,50,25));
		//hPen = CreatePen(PS_SOLID,4,RGB(0,50,25));
		ReleaseDC(GetDesktopWindow(),dc);
	}
	++mRef;
	return regClass;
}

LRESULT CALLBACK BtnWndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
int i;
HDC hdc;
PAINTSTRUCT ps;

	//static int i=0;
	//wchar_t s[32];wsprintf(s,L"\n %d ",i++);
	//OutputDebugString(s);
	//OutputDebugString(GetWinNotifyText(message));
	//wsprintf(s,L" %x %x",wParam,lParam);
	//OutputDebugString(s);

	MyButton *btn = (MyButton*)GetWindowLongPtr(hWnd,GWLP_USERDATA);//GetWindowLong(hWnd,GWL_USERDATA);//Hamma(ishlaydigani uchun)
	switch (message)
	{
	case WM_CREATE:
		if(NULL==((LPCREATESTRUCT)lParam)->lpCreateParams)
		{	MyButton *b = (MyButton*)malloc(sizeof(MyButton));
			if(!b)return -1;
			b->hWndPrnt = ((LPCREATESTRUCT)lParam)->hwndParent;
			b->msgId = (WORD)((LPCREATESTRUCT)lParam)->hMenu;
			b->xPos = ((LPCREATESTRUCT)lParam)->x;
			b->yPos = ((LPCREATESTRUCT)lParam)->y;
			b->width = ((LPCREATESTRUCT)lParam)->cx;
			b->height = ((LPCREATESTRUCT)lParam)->cy;
			b->type = 0;
			b->toggleState = 0;
			b->captionLen=MyStringCpy(b->caption,MAX_PATH,(wchar_t*)((LPCREATESTRUCT)lParam)->lpszName);
			SetWindowLongPtr(hWnd,GWLP_USERDATA,(LONG)b);//SetWindowLong(hWnd,GWL_USERDATA,(LONG)b);
		}
		else SetWindowLongPtr(hWnd,GWLP_USERDATA,(LONG)(((LPCREATESTRUCT)lParam)->lpCreateParams));//SetWindowLong(hWnd,GWL_USERDATA,(LONG)(((LPCREATESTRUCT)lParam)->lpCreateParams));
		return 0;//-1 b-sa destroyed;
	case WM_PAINT:
		hdc = BeginPaint(hWnd, &ps);
		HFONT hOldFont;
		if(hfBtn)
			hOldFont=(HFONT)SelectObject(ps.hdc,hfBtn);
		btn->Draw(hdc);
		if(hfBtn)
			SelectObject(ps.hdc,hOldFont);
		EndPaint(hWnd, &ps);
		return 0;
	case WM_MOUSEFIRST://WM_MOUSEMOVE:
		if(1!=btn->toggleState)
		{	TRACKMOUSEEVENT tm_Event;
			tm_Event.cbSize = sizeof(TRACKMOUSEEVENT);
			tm_Event.dwFlags = TME_LEAVE;
			tm_Event.hwndTrack = hWnd;
			TrackMouseEvent(&tm_Event);
			btn->toggleState = (MK_LBUTTON==wParam)?2:1;
			InvalidateRect(hWnd,NULL,FALSE);
		}
		return 0;
	case WM_MOUSELEAVE:
		btn->toggleState = 0;
		InvalidateRect(hWnd,NULL,FALSE);
		return 0;
	case WM_KEYDOWN:
		if(VK_RETURN == wParam || VK_SPACE == wParam)
			goto LBtnDwn;
		return 0;
	case WM_LBUTTONDOWN:MyButton* pOldFocused;
LBtnDwn:	btn->toggleState = 2;
		pOldFocused = MyButton::pFocusedBtn;
		InvalidateRect(hWnd,NULL,FALSE);
		if(pOldFocused)
			InvalidateRect(pOldFocused->hWnd,NULL,FALSE);
		return 0;
	case WM_LBUTTONUP:
LBtnUp:	i = btn->toggleState;
		btn->toggleState = 1;
		InvalidateRect(hWnd,NULL,FALSE);
		if(2==i)
			SendMessage(btn->hWndPrnt,WM_COMMAND,MAKELONG(btn->msgId,0),(LPARAM)btn->hWnd);
		return 0;
	case WM_KEYUP:
		if(VK_RETURN == wParam || VK_SPACE == wParam)
			goto LBtnUp;
		return 0;
	case WM_SETFOCUS:
		pOldFocused = MyButton::pFocusedBtn;
		MyButton::pFocusedBtn = btn;
		InvalidateRect(hWnd,NULL,FALSE);
		if(pOldFocused)
			InvalidateRect(pOldFocused->hWnd,NULL,FALSE);
		return 0;
	case WM_KILLFOCUS:
		MyButton::pFocusedBtn = NULL;
		InvalidateRect(hWnd,NULL,FALSE);
		return 0;
	case WM_SETTEXT:
		if(btn)
		{	btn->captionLen=MyStringCpy(btn->caption,MAX_PATH,(wchar_t*)lParam);
			InvalidateRect(btn->hWnd,NULL,FALSE);
		}
	case WM_DESTROY:
		if(btn==MyButton::pFocusedBtn)
			MyButton::pFocusedBtn = NULL;
		btn->Destroy();
		return 0;
	default:
		return DefWindowProc(hWnd, message, wParam, lParam);
	}
	return 0;
}

MyButton::MyButton():captionLen(0),hWndPrnt(NULL),msgId(0),xPos(0),yPos(0),width(100),height(25),type(0),
					 toggleState(0)//,oldPressedAndLeaved(0)	
{
	MyRegisterClass(hInst);
}

DLLEXP MyButton::MyButton(HWND p,wchar_t* txt,WORD id,int t,int x,int y,int w,int h):toggleState(0)
						  //oldPressedAndLeaved(0)
//						:hWndPrnt(p),msgId(id),xPos(x),yPos(y),width(w),height(h),type(t)
{
	MyRegisterClass(hInst);
/*	MyStringCpy(caption,MAX_PATH,txt);
	hWnd = CreateWindow((LPCTSTR)regClass,
						caption,
						WS_VISIBLE | WS_CHILD | BS_PUSHBUTTON | BS_PUSHLIKE,
						xPos,
						yPos,
						width,
						height,
						hWndPrnt,
						NULL,
						hInst,
						NULL);*/
	Init(p,txt,id,t,x,y,w,h);
}

BOOL DLLEXP MyButton::Init(HWND p,wchar_t* txt,WORD id,int t,int x,int y,int w,int h)
{
	hWndPrnt = p;
	msgId = id;
	xPos = x;
	yPos = y;
	width = w;
	height = h;
	type = t;
	captionLen=MyStringCpy(caption,MAX_PATH,txt);
	hWnd = CreateWindowEx(WS_EX_LEFT | WS_EX_LTRREADING | WS_EX_RIGHTSCROLLBAR | WS_EX_NOPARENTNOTIFY,
						(LPCTSTR)regClass,
						caption,
						//WS_BORDER | WS_VISIBLE | WS_CHILD,//WS_VISIBLE BS_PUSHBUTTON | BS_PUSHLIKE,
						WS_CHILDWINDOW | WS_VISIBLE | WS_TABSTOP | BS_PUSHBUTTON | BS_TEXT,
						xPos,
						yPos,
						width,
						height,
						hWndPrnt,
						(HMENU)msgId,
						hInst,
						this);
	if(hWnd)
	{	UpdateWindow(hWnd);
		ShowWindow(hWnd,SW_SHOW);
	}
	HRGN hRndRgn = CreateRoundRectRgn(0,0,width,height,3,3);
	SetWindowRgn(hWnd,hRndRgn,TRUE);
	DeleteObject(hRndRgn);
	//GetTextExtentPoint32
	return (hWnd!=NULL ? TRUE:FALSE);
}

DLLEXP MyButton::~MyButton()
{	
	Destroy();
}

VOID DLLEXP MyButton::Destroy()
{	if(1==mRef)
	{	if(hBmpSimpleOld)
		{	DeleteObject(SelectObject(hDCSimple, hBmpSimpleOld));
			DeleteObject(SelectObject(hDCHovered, hBmpHoveredOld));
			DeleteObject(SelectObject(hDCHoveredPushed, hBmpHoveredPushedOld));
			DeleteDC(hDCSimple);
			DeleteDC(hDCHovered);
			DeleteDC(hDCHoveredPushed);
			hBmpSimpleOld = NULL;
			DeleteObject(hBrsh);
			//DeleteObject(hBrshHatch);
			DeleteObject(hPen);
	}	}
	--mRef;
	return;
}

BOOL MyButton::Draw(HDC dc)
{
HPEN hPenOld;
	RECT rc = {0,0,width,height};
	//RECT rc = {2,2,width-4,height-4};
	SetBkMode(dc, TRANSPARENT);
	//HPEN hOldPen = (HPEN)SelectObject(dc,hPen);
	switch(toggleState)
	{	case 0://simple
			FillRect(dc,&rc,(HBRUSH)GetStockObject(BLACK_BRUSH));
			StretchBlt(dc,2,2,width-5,height-5,hDCSimple,0,0,1,2,SRCCOPY);//o'rtasi;
			StretchBlt(dc,1,2,1,height-5,hDCSimple,0,0,1,2,SRCCOPY);//chap tarafi
			StretchBlt(dc,width-3,2,1,height-5,hDCSimple,0,0,1,2,SRCCOPY);//o'ng tarafi
			StretchBlt(dc,2,1,width-5,1,hDCSimple,0,0,1,1,SRCCOPY);//tepasi;
			StretchBlt(dc,2,height-3,width-5,1,hDCSimple,0,1,1,1,SRCCOPY);//pasti;
			rc.top-=1;rc.bottom-=1;
			DrawText(dc,caption,captionLen,&rc,DT_VCENTER|DT_SINGLELINE|DT_CENTER);
			if(this==pFocusedBtn)
			{	hPenOld=(HPEN)SelectObject(dc,hPen);
				MoveToEx(dc,5,2,NULL);LineTo(dc,width-5,2);
				MoveToEx(dc,width-4,3,NULL);LineTo(dc,width-4,height-5);
				MoveToEx(dc,width-5,height-4,NULL);LineTo(dc,5,height-4);
				MoveToEx(dc,2,height-5,NULL);LineTo(dc,2,2);
				SelectObject(dc,hPenOld);
			}
			break;
		case 1://hover
			FillRect(dc,&rc,hBrsh);
			StretchBlt(dc,2,2,width-5,height-5,hDCHovered,0,0,1,2,SRCCOPY);//o'rtasi;
			StretchBlt(dc,1,2,1,height-5,hDCHovered,0,0,1,2,SRCCOPY);//chap tarafi
			StretchBlt(dc,width-3,2,1,height-5,hDCHovered,0,0,1,2,SRCCOPY);//o'ng tarafi
			StretchBlt(dc,2,1,width-5,1,hDCHovered,0,0,1,1,SRCCOPY);//tepasi;
			StretchBlt(dc,2,height-3,width-5,1,hDCHovered,0,1,1,1,SRCCOPY);//pasti;
			rc.left+=1;
			rc.right+=1;
			SetTextColor(dc,RGB(102,196,251));
			DrawText(dc,caption,captionLen,&rc,DT_VCENTER|DT_SINGLELINE|DT_CENTER);
			rc.left-=1;
			rc.top-=1;
			rc.right-=1;
			rc.bottom-=1;
			SetTextColor(dc,RGB(3,70,109));
			DrawText(dc,caption,captionLen,&rc,DT_VCENTER|DT_SINGLELINE|DT_CENTER);
			if(this==pFocusedBtn)
			{	hPenOld=(HPEN)SelectObject(dc,hPen);
				MoveToEx(dc,5,2,NULL);LineTo(dc,width-5,2);
				MoveToEx(dc,width-4,3,NULL);LineTo(dc,width-4,height-5);
				MoveToEx(dc,width-5,height-4,NULL);LineTo(dc,5,height-4);
				MoveToEx(dc,2,height-5,NULL);LineTo(dc,2,2);
				SelectObject(dc,hPenOld);
			}
			break;
		case 2://pressed
			FillRect(dc,&rc,hBrsh);
			StretchBlt(dc,3,3,width-6,height-6,hDCHoveredPushed,0,0,1,2,SRCCOPY);//o'rtasi;
			StretchBlt(dc,2,4,1,height-8,hDCHoveredPushed,0,0,1,2,SRCCOPY);//chap tarafi
			StretchBlt(dc,width-3,5,1,height-9,hDCHoveredPushed,0,0,1,2,SRCCOPY);//o'ng tarafi
			StretchBlt(dc,3,2,width-7,1,hDCHoveredPushed,0,0,1,1,SRCCOPY);//tepasi;
			StretchBlt(dc,3,height-3,width-7,1,hDCHoveredPushed,0,1,1,1,SRCCOPY);//pasti;
			rc.left+=1;
			rc.right+=1;
			rc.top+=1;
			rc.bottom+=1;
			SetTextColor(dc,RGB(102,196,251));
			DrawText(dc,caption,captionLen,&rc,DT_VCENTER|DT_SINGLELINE|DT_CENTER);
			rc.left-=1;
			rc.top-=1;
			rc.right-=1;
			rc.bottom-=1;
			SetTextColor(dc,RGB(2,60,64));
			DrawText(dc,caption,captionLen,&rc,DT_VCENTER|DT_SINGLELINE|DT_CENTER);
			if(this==pFocusedBtn)
			{	hPenOld=(HPEN)SelectObject(dc,hPen);
				MoveToEx(dc,5,3,NULL);LineTo(dc,width-5,3);
				MoveToEx(dc,width-4,6,NULL);LineTo(dc,width-4,height-7);
				MoveToEx(dc,width-6,height-4,NULL);LineTo(dc,5,height-4);
				MoveToEx(dc,3,height-7,NULL);LineTo(dc,3,5);
				SelectObject(dc,hPenOld);
			}
		break;
	}
	//DrawFrameControl(dc,&rc,DFC_BUTTON,DFCS_BUTTONPUSH);
	//DrawCaption(hWnd,dc,&rc,DC_ACTIVE|DC_INBUTTON);
	//DrawFocusRect(dc,&rc);
	//Rectangle(dc,0,0,width,height);
	//TextOut(dc,0,0,caption,wcslen(caption));
	//DeleteObject(SelectObject(dc,hOldPen));
	return TRUE;
}