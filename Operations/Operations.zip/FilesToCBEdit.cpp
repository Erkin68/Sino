#include "windows.h"
#include "FilesToCBEdit.h"
#include "..\Sino.h"
#include "..\resource.h"
#include "stdio.h"
#include "MyShell\MyShell.h"

namespace FilesToCBEdit
{

HWND hComboEdit,hEdit,dlg,hLB;
wchar_t saveSt[MAX_PATH];
int exitCode,slashCntInPath,fromPos;
BOOL bEnChangeLBSel = FALSE,bOpenDown=FALSE,bDir;


INT_PTR CALLBACK showLBDlgProc(HWND hDlg,UINT message,WPARAM wParam,LPARAM lParam)
{
	UNREFERENCED_PARAMETER(lParam);

/*	static int i=0;
	wchar_t ss[32];wsprintf(ss,L"\n %d ",i++);
	OutputDebugString(ss);
	OutputDebugStringA(GetWinNotifyText(message));*/

	switch(message)
	{
	case WM_INITDIALOG:
		WIN32_FIND_DATAW ffW;HANDLE hFind;int l,cnt;
		dlg = hDlg;
		hLB =GetDlgItem(hDlg,IDC_STATIC1);
		exitCode=0;
		slashCntInPath=0;

		//l=MyStringCpy(saveSt,MAX_PATH-1,(wchar_t*)lParam)-1;
		l=MyStringLength(saveSt,MAX_PATH);
		if(l)--l;
		hFind = MyFindFirstFileEx(saveSt,FindExInfoStandard,&ffW,FindExSearchLimitToDirectories,NULL,0);
		if(INVALID_HANDLE_VALUE==hFind)
		{	DestroyWindow(hDlg);
			exitCode = 4;
			return FALSE;
		}
		cnt = 0;
		do
		{	if(bDir)
			if(!(FILE_ATTRIBUTE_DIRECTORY & ffW.dwFileAttributes))//if(IsDirectory(p->path, &ff, FALSE))
				continue;
			if(IsCrntOrPrntDirAttrb(ffW.cFileName))
			{	MyStringCpy(&saveSt[l],MAX_PATH-1,ffW.cFileName);
				SendMessage(hLB,LB_ADDSTRING,0,(LPARAM)saveSt);
				++cnt;
		}	}
		while(FindNextFile(hFind, &ffW));
		FindClose(hFind);
		saveSt[l]=0;

		if(!cnt)
		{	DestroyWindow(hDlg);
			exitCode = 5;
			return FALSE;
		}
		RecalcDlgHeight(cnt);
		//SetForegroundWindow(hDlg);
		//SetCapture(hDlg);
		//SetWindowLong(hDlg,GWLP_USERDATA,lParam);
		return TRUE;
	case WM_DESTROY:
		dlg=0;
		return 0;
	case WM_COMMAND:
		switch(LOWORD(wParam))
		{	case IDC_STATIC1:
				if(bEnChangeLBSel && LBN_SELCHANGE==HIWORD(wParam))
				{	wchar_t s[MAX_PATH];
					int sl=(int)SendMessage(hLB,LB_GETCURSEL,0,0);
					if(LB_ERR==sl)return (INT_PTR)TRUE;
					SendMessageW(hLB,LB_GETTEXT,sl,(LPARAM)s);
					SetEditText(&s[0]);
					bEnChangeLBSel = FALSE;
				}
				return (INT_PTR)TRUE;
			case IDOK:int sel;
				sel=(int)SendMessageW(hLB,LB_GETCURSEL,0,0);
				if(LB_ERR!=sel)
				{	wchar_t s[MAX_PATH];
					SendMessageW(hLB,LB_GETTEXT,sel,(LPARAM)s);
					SetEditText(&s[0]);
					DestroyWindow(hDlg);
					//PostMessage(hEdit,WM_KEYDOWN,VK_RETURN,0x13);
					exitCode=1;
				}
				return (INT_PTR)TRUE;
			case IDCANCEL:
				SetEditText(&saveSt[0]);
				DestroyWindow(hDlg);
				exitCode=2;
				return (INT_PTR)TRUE;
		}
		break;
	}
	return (INT_PTR)FALSE;
}
	
int Attach(HWND hInComboEdit, HWND hInEdit, BOOL inBDir, BOOL bInOpenDown, wchar_t* sIn, int inFromPos)
{	
wchar_t s[MAX_PATH],*p=&s[0];int l=MyStringCpy(s,MAX_PATH,&sIn[inFromPos]);

	if(1==l)
	{	s[l++]=':';
		s[l++]='\\';
		s[l]=0;
	}
	else if(s[l-1]!='\\')
	{	s[l++]='\\';
		s[l]=0;
	}
	while(!IsDirExist(s))
	{	p = wcsrchr(s,'\\');
		if(p)*p=0;
		else return FALSE;
	}
	l = MyStringLength(s,MAX_PATH-1);
	if('\\'!=s[l-1])
	{	if('*'!=s[l-2])
			s[l++]='\\';
		else if('\\'==s[l-2])
			s[--l]=0;
	}
	s[l]='*';
	s[l+1]=0;
	hComboEdit = hInComboEdit;
	bOpenDown = bInOpenDown;
	fromPos = inFromPos;
	hEdit = hInEdit;
	bDir = inBDir;

	//DialogBoxParam(hInst,MAKEINTRESOURCE(IDD_DIALOG_PATHS_FR_REGISTRY),
	//				 cmdCBEdit,pathsFrRegistryDlgProc,(LPARAM)s);
	MyStringCpy(saveSt,MAX_PATH-1,s);
	dlg=CreateDialogParam(hInst,MAKEINTRESOURCE(IDD_DIALOG_PATHS_FR_REGISTRY),
						  hEdit,showLBDlgProc,(LPARAM)s);
	ShowWindow(dlg,SW_SHOW);
	MSG msg;

	while(dlg && GetMessage(&msg,NULL,NULL,NULL))//for(;;)
	{	//if(!PeekMessage(&msg,NULL,NULL,NULL,PM_REMOVE))
		//	Sleep(25);

		//static int i=0;
		//wchar_t ss[32];wsprintf(ss,L"\n %d ",i++);
		//OutputDebugString(ss);
		//OutputDebugStringA(GetWinNotifyText(msg.message));
		if(WM_KEYFIRST==msg.message)
		{	if(0x27==msg.wParam)//right & enter
			{	int sl=(int)SendMessage(hLB,LB_GETCURSEL,0,0);
				if(LB_ERR==sl)return (INT_PTR)TRUE;
				SendMessageW(hLB,LB_GETTEXT,sl,(LPARAM)s);
				SetEditText(&s[0]);
				DestroyWindow(dlg);
				exitCode=6;
				return exitCode;
			} else if(0x25==msg.wParam)//left;
			{	int sl=(int)SendMessage(hLB,LB_GETCURSEL,0,0);
				if(LB_ERR==sl)return (INT_PTR)TRUE;
				SendMessageW(hLB,LB_GETTEXT,sl,(LPARAM)s);
				SetEditText(&s[0]);
				continue;
			}else if(VK_PRIOR<=msg.wParam && VK_DOWN>=msg.wParam)
			{	bEnChangeLBSel = TRUE;
			}
			else if(VK_RETURN==msg.wParam)
			{	DestroyWindow(dlg);
				exitCode=6;
				return exitCode;
		}	}

		if(IsDialogMessage(dlg, &msg))
		{	if(exitCode>0)//WM_DESTROY==msg.message)
				break;
		}
		else
        {	TranslateMessage(&msg);
			DispatchMessage(&msg);
			if(WM_LBUTTONDOWN==msg.message)
			{Br:DestroyWindow(dlg);
				exitCode = 3;
				break;
		}	}
		if(WM_CHAR==msg.message)
		{	l=GetEditText(&s[0]);
			if(8==msg.wParam)//backsl
			{	s[--l]=0;
				SetEditText(&s[0]);
				if(l<1)goto Br;
				if(-1==RebuildLB(&s[0]))
					goto Br;
			}
			else
			{	//if(!('\\'==s[l-1] && '\\'==msg.wParam))
				{	s[l++]=(wchar_t)msg.wParam;
					s[l]=0;
					SetEditText(&s[0]);
					if(!AnalyzeEdit(&s[0]))
						goto Br;
		}	}	}
		//static int i=0;
		//char ss[32];sprintf(ss,"\n %d %x %x %x ",i++, msg.message, msg.wParam, msg.lParam);
		//OutputDebugStringA(ss);
		//OutputDebugStringA(GetWinNotifyText(msg.message));
	}//	}
	return exitCode;
}

wchar_t s[MAX_PATH];//int iLongLength = -1;int longLength=0;
BOOL AnalyzeEdit(wchar_t *sIn)
{
	//static int i=0;
	//char ss[32];sprintf(ss,"\n %d ",i++);
	//OutputDebugStringA(ss);
	//OutputDebugString(sIn);


	int l = MyStringLength(sIn,MAX_PATH);
	if(l<1)return FALSE;
	/*wchar_t txt[MAX_PATH];int toSlashLn,l=MyStringCpy(txt,MAX_PATH-1,sIn);
	wchar_t *pLastSlash = wcsrchr(txt,'\\');
	if(pLastSlash)
	{	*(pLastSlash+1)=0;
		toSlashLn = pLastSlash-&txt[0];
	} else toSlashLn = l;*/
	int iLBCnt = (int)SendMessage(hLB,LB_GETCOUNT,0,0);
	if(LB_ERR==iLBCnt)return FALSE;

	//bEnChangeLBSel = FALSE;
	for(int i=0; i<iLBCnt; i++)
	{	SendMessageW(hLB,LB_GETTEXT,i,(LPARAM)s);
		if(!_wcsnicmp(s,sIn,l))//if(wcsstr(s,sIn))//if(!_wcsicmp(s,sIn))//if(!wcsicmp(s,txt))
		{	SendMessage(hLB,LB_SETCURSEL,i,0);
			//bEnChangeLBSel = TRUE;			
			return TRUE;
	}	}
	//bEnChangeLBSel = TRUE;
	return FALSE;
}

int RebuildLB(wchar_t *sIn)
{	
wchar_t *p;//,t[MAX_PATH];
	//avval shu listdagi narsa bormu, sIn niki b-n, shuni aniqlaymiz:
/*	MyStringCpy(s,MAX_PATH-1,sIn);
	p = wcsrchr(s,'\\');
	if(!p) goto Reb;
	*p=0;
	SendMessage(hLB,LB_GETTEXT,0,(LPARAM)t);
	p = wcsrchr(t,'\\');
	if(!p) goto Reb;
	if(0==_wcsnicmp(s,t,p-&t[0]))
		return FALSE;*/
	if(0==slashCntInPath)
	{	int r=(int)SendMessage(hLB,LB_GETTEXT,0,(LPARAM)s);
		if(LB_ERR==r) goto Reb;
		for(int i=0; i<r; i++)
		{	if('\\'==s[i])
				++slashCntInPath;
	}	}
	int inSlashNum=0;
	for(p=sIn;*p;)
	{	if('\\'==*p)
			++inSlashNum;
		++p;
	}
	if(inSlashNum==slashCntInPath)
		return 0;
Reb:
	MyStringCpy(saveSt,MAX_PATH-1,sIn);
	p = wcsrchr(saveSt,'\\');
	if(p)*p=0;		
	while(!IsDirExist(saveSt))
	{	p = wcsrchr(saveSt,'\\');
		if(p)*p=0;
		else return 0;
	}
	int l = MyStringLength(saveSt,MAX_PATH-1);
	if('\\'!=saveSt[l-1])if('*'!=saveSt[l-2])saveSt[l++]='\\';
	saveSt[l]='*';
	saveSt[l+1]=0;

	SendMessage(hLB,LB_RESETCONTENT,0,0);

	WIN32_FIND_DATAW ffW;
	HANDLE hFind = MyFindFirstFileEx(saveSt,FindExInfoStandard,&ffW,FindExSearchLimitToDirectories,NULL,0);
	if(INVALID_HANDLE_VALUE==hFind)
		return FALSE;
	int cnt = 0;
	do
	{	if(bDir)
		if(!(FILE_ATTRIBUTE_DIRECTORY & ffW.dwFileAttributes))//if(IsDirectory(p->path, &ff, FALSE))
			continue;
		if(IsCrntOrPrntDirAttrb(ffW.cFileName))
		{	MyStringCpy(&saveSt[l],MAX_PATH-1,ffW.cFileName);
			SendMessage(hLB,LB_ADDSTRING,0,(LPARAM)saveSt);
			++cnt;
	}	}
	while(FindNextFile(hFind, &ffW));
	FindClose(hFind);
	saveSt[l]=0;
	RecalcDlgHeight(cnt);
	if(!AnalyzeEdit(sIn))
		return -1;
	return 1;
}

BOOL RecalcDlgHeight(int totItemsCnt)
{
RECT rc,rcPrnt,rcClnt;
int width,height,itH;

	::GetWindowRect(dlg, &rc);
	::GetWindowRect(hComboEdit,&rcPrnt);

	width = rc.right - rc.left;
	height = rc.bottom - rc.top;
	itH = (int)SendMessage(hLB,LB_GETITEMHEIGHT,0,0);
	if(height>itH*totItemsCnt)
	{	height = 2+totItemsCnt*itH;
		MoveWindow(hLB,0,0,width,height,TRUE);
		::GetClientRect(dlg,&rcClnt);
		height += (rc.bottom - rc.top)-(rcClnt.bottom-rcClnt.top);
		MoveWindow(dlg, rcPrnt.left, bOpenDown?rcPrnt.bottom:(rcPrnt.top-height), width, height, TRUE);
		return TRUE;
	}
	else if(height<itH*30)
	{	height = 2+30*itH;
		MoveWindow(hLB,0,0,width,height,TRUE);
		::GetClientRect(dlg,&rcClnt);
		height += (rc.bottom - rc.top)-(rcClnt.bottom-rcClnt.top);
		MoveWindow(dlg, rcPrnt.left, bOpenDown?rcPrnt.bottom:(rcPrnt.top-height), width, height, TRUE);
		return TRUE;
	}
	MoveWindow(dlg, rcPrnt.left, bOpenDown?rcPrnt.bottom:(rcPrnt.top-height), width, height, TRUE);
	return FALSE;
}

int GetEditText(wchar_t *s)
{
	if(!fromPos)
		return GetWindowText(hEdit,s,MAX_PATH);
	wchar_t ss[MAX_PATH];
	int l=GetWindowText(hEdit,ss,MAX_PATH);
	MyStringCpy(s,l-fromPos,&ss[fromPos]);
	return l-fromPos;
}

BOOL SetEditText(wchar_t *s)
{
	if(!fromPos)
		return SetWindowText(hEdit,s);
	wchar_t ss[MAX_PATH];
	int l = GetWindowText(hEdit,ss,MAX_PATH);
	MyStringCpy(&ss[fromPos],MAX_PATH,s);
	return SetWindowText(hEdit,ss);
}

}//end of namespace