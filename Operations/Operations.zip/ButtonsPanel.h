#ifndef _BUTTONS_PANEL_H_
#define _BUTTONS_PANEL_H_

#include "windows.h"
#include "..\Toolcha.h"


namespace BtnsPanel
{

extern BOOL Create();
extern VOID Free();
extern VOID Hide();
extern BOOL IsPointInsideRect(POINT*);
extern VOID Render(HDC,RECT*,int,int);

extern HWND			hBtnsPnlWnd;
extern MyToolTip	toolTip;
extern BOOL			bNoHide;
extern int			iOpenState;


class Btn
{
public:

	static wchar_t* GetHotKeyToolString(int);
	static int Expand();
	static int GetFromPosXY(int,int);
	static BOOL LoadAll(HWND);
	static BOOL SaveAll();
	static VOID DeleteAllBtns(HWND);
	static VOID DeleteAllFolderBtns(HWND);
	static VOID DeleteAllLinkBtns(HWND);

	static int iAllocNum,iBtns,iSelected;
	static float kScl;
	static float kHeight;
	static Btn *pBtns;


			Btn();
		   ~Btn();
    union
	{	HBITMAP hBMP;
		HICON	hIcon;
	};
	HDC dc;
	typedef enum TCmndType
	{	hotKey=0,
		extFolder=1,
		extLink=2,
		archPlgLnk=3,
		imgViewPlgLnk=4,
		mnuUtilPlgLnk=5,
		schPlgLnk=6,
		vrtPnlPlgLnk=7
	} CmndType;
	CmndType cmndType;
	typedef enum TIconFileType
	{	frExe=0,
		frDll=1,
		frIco=2,
		frBmp=3,
		frCur=4
	} IconFileType;
	IconFileType iconFileType;
	int iCmndNum;
	int x,y,w,h;
	wchar_t icoPth[MAX_PATH];
	wchar_t pth[MAX_PATH];
	LPTSTR resType;
	wchar_t resNameW[MAX_PATH];LPWSTR resName;
	int resChild;

	wchar_t*	GetToolString();
	VOID		Free();
	BOOL		Execute(HWND);
	VOID		Delete(HWND);
	BOOL		Load(HWND);
	BOOL		LoadBMPFrPE(HWND);
	BOOL		LoadFrBMP(HWND);
	BOOL		LoadCursorFrPE(HWND);
	BOOL		LoadIconFrPE(HWND);
	BOOL		LoadIconFrPECursResGroup(HWND);
	BOOL		LoadIconFrPEIconResGroup(HWND);
	VOID		Render(HDC,int bRndrBck=0);
};

extern Btn*		pBtns;


};



#endif