#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include "shlobj.h"
#include "strsafe.h"
#include "..\Sino.h"
#include "..\Config.h"
#include "MyErrors.h"
#include "Winsock2.h"
#include "MSWSock.h"
#include "LinkSocket.h"
#include "MyShell\MyShell.h"
#include "Backgrnd thread copy operation.h"
#include "..\WindowsManagmentInstrumentation.h"


namespace linkSock
{

//Src panel,koneshno:

//Copy qilinadigan jami fayllar hajmini hisoblaydur;
VOID CalcSrcAndAvailableDestSize()
{
	//OutputDebugString("\nCalcSrcAndAvailableDestSize 1");

	fCopyOper::srcSz = 0;
	for(int i=0; i<panel[fCopyOper::srcPanel].GetTotItems(); i++)//srcCnt
	{	//OutputDebugString("\nCalcSrcAndAvailableDestSize 2");
		if(selected==panel[fCopyOper::srcPanel].GetItem(i)->state  || (0==panel[fCopyOper::srcPanel].GetTotSelects() && i==panel[fCopyOper::srcPanel].GetHot()))
		{	//OutputDebugString("\nCalcSrcAndAvailableDestSize 3");
			if(file == panel[fCopyOper::srcPanel].GetItem(i)->attribute)
			{	//OutputDebugString("\nCalcSrcAndAvailableDestSize 4");
				if(fCopyOper::IsFileExtIncludeCopyFilter(i))
					fCopyOper::srcSz += panel[fCopyOper::srcPanel].GetItem(i)->size;
			}
			else if(folder == panel[fCopyOper::srcPanel].GetItem(i)->attribute)
			{	//OutputDebugString("\nCalcSrcAndAvailableDestSize 5");
				wchar_t s[MAX_PATH];
				int l=panel[fCopyOper::srcPanel].GetFullPathAndName(i,s,MAX_PATH);
				s[l++]='\\';//MyStringCat(s,MAX_PATH,"\\*");
				s[l++]='*';
				s[l]=0;
				if(socketCl!=panel[fCopyOper::srcPanel].GetEntry()->GetCrntRecType())
					fCopyOper::AddFolderSize(s);
				else
				{	unsigned __int64* p = (unsigned __int64*)SendToServerMsg(fCopyOper::srcPanel,LNKSCKMSG_GET_FOLDER_SIZE_FROM_SERVER,s);
					if(p)
						fCopyOper::srcSz += *p;
	}	}	}	}//Destniyam hisoblab qo'yaylik:
	//avDstSz 
	//OutputDebugString("\nCalcSrcAndAvailableDestSize 6");
	if(socketCl!=panel[fCopyOper::destPanel].GetEntry()->GetCrntRecType())
	{	//OutputDebugString("\nCalcSrcAndAvailableDestSize 7");
		int dr = myWMI::IsNameDrive(fCopyOper::destPath);
		if(dr>-1)
		{	//OutputDebugString("\nCalcSrcAndAvailableDestSize 8");
			wchar_t p[4]={fCopyOper::destPath[0],fCopyOper::destPath[1],0,0};
			fCopyOper::avDstSz = myWMI::GetLogicalDriveAvailableMem(p);
	}	}
	else
	{	//OutputDebugString("\nCalcSrcAndAvailableDestSize 9");
		wchar_t wp[4]={fCopyOper::destPath[0],fCopyOper::destPath[1],0,0};
		unsigned __int64* pp = (unsigned __int64*)SendToServerMsg(fCopyOper::destPanel,LNKSCKMSG_GET_DRIVE_AVIALABLE_MEM,&wp[0]);
		if(pp)
			fCopyOper::avDstSz = *pp;
		//OutputDebugString("\nCalcSrcAndAvailableDestSize 10");
}	}

int CheckCopyFilesToExisting(HWND prnt, wchar_t *fromFilePathAndName,
							 wchar_t *toFilePathAndName,
							 WIN32_FIND_DATA **fFrom,
							 WIN32_FIND_DATA **fTo)

{
	*fFrom = 0;*fTo=0;
	if(skipAll==enCheckCopyFilesToExisting)
		return skipAll;
	else if(overwriteAll==enCheckCopyFilesToExisting)
		return overwriteAll;
	else if(renameAll==enCheckCopyFilesToExisting)
		return renameAll;
	else if(overwriteOldestAll==enCheckCopyFilesToExisting)
		return overwriteOldestAll;
	else if(overwriteLatestAll==enCheckCopyFilesToExisting)
		return overwriteLatestAll;
	else if(overwriteBigestAll==enCheckCopyFilesToExisting)
		return overwriteBigestAll;
	else if(overwriteLittlestAll==enCheckCopyFilesToExisting)
		return overwriteLittlestAll;

static WIN32_FIND_DATA ff[2];
HANDLE			hf = INVALID_HANDLE_VALUE;
static wchar_t  buf[MAX_PATH];

	if(socketCl!=panel[fCopyOper::destPanel].GetEntry()->GetCrntRecType())
	{	ZeroMemory(&ff[1],sizeof(WIN32_FIND_DATA));
		hf = FindFirstFile(toFilePathAndName, &ff[1]);
		if(INVALID_HANDLE_VALUE==hf) return overwrite;
		FindClose(hf);
	}
	else
	{	if(!SendToServerMsg(fCopyOper::destPanel,LNKSCKMSG_FindFirstFile,toFilePathAndName,&ff[1]))
			return overwrite;
	}
	*fTo=&ff[1];

	if(socketCl!=panel[fCopyOper::srcPanel].GetEntry()->GetCrntRecType())
	{	ZeroMemory(&ff[0],sizeof(WIN32_FIND_DATA));
		hf = FindFirstFile(fromFilePathAndName, &ff[0]);
		if(INVALID_HANDLE_VALUE==hf) return overwrite;
		FindClose(hf);
	}
	else
	{	if(!SendToServerMsg(fCopyOper::srcPanel,LNKSCKMSG_FindFirstFile,fromFilePathAndName,&ff[0]))
			return overwrite;
	}
	*fFrom=&ff[0];

    //OutputDebugString("\nCheckCopyFilesToExisting post normally;");

	if(0==ff[0].nFileSizeLow)if(0==ff[0].nFileSizeHigh)
	if(0!=ff[1].nFileSizeLow ||	0!=ff[1].nFileSizeHigh)
	{	//OutputDebugString("\nCheckCopyFilesToExisting return FALSE;");
		return overwrite;
	}

	if(0==ff[1].nFileSizeLow)if(0==ff[1].nFileSizeHigh)
	if(0!=ff[0].nFileSizeLow ||	0!=ff[0].nFileSizeHigh)
	{	//OutputDebugString("\nCheckCopyFilesToExisting return FALSE 2;");
		return overwrite;
	}

	StringCchPrintf(ff[0].cFileName,260,fromFilePathAndName);
	StringCchPrintf(ff[1].cFileName,260,toFilePathAndName);
	//OutputDebugString("\nCheckCopyFilesToExisting return r;");
	return (int)DialogBoxParam(hInst,MAKEINTRESOURCE(IDD_COPY_FILE_EXIST),
						  prnt,fBckgrndCopyOper::CopyFileExistDlgProc,(LPARAM)ff);
}

int GetFilesInFolder(wchar_t *path, VOID *dst, int dstSz, int *blckSz, int iFolderDwn)//reentrance:
{
WIN32_FIND_DATA ff;
HANDLE hf = INVALID_HANDLE_VALUE;
int tot = 0;

	wchar_t *pdst = (wchar_t*)dst;
	int sz = 0;

	hf = MyFindFirstFileEx(path,FindExInfoStandard,&ff,FindExSearchLimitToDirectories,NULL,0);
	if(INVALID_HANDLE_VALUE==hf) return tot;

	if(FILE_ATTRIBUTE_DIRECTORY & ff.dwFileAttributes)//if(IsDirectory(path, &ff, TRUE))
	{	if(IsCrntOrPrntDirAttrb(ff.cFileName))
		{	wchar_t s[MAX_PATH];
			int l=MyStringCpy(s,MAX_PATH,path);
			if('*'==s[l-1])//MyStringRemoveLastCharCheckPre(s,MAX_PATH,'*','\\');
			if('\\'==s[l-2])
				s[--l]=0;
			l+=MyStringCpy(s,MAX_PATH-l,ff.cFileName);//MyStringCat(s,MAX_PATH,ff.cFileName);
			//int l = MyStringLength(s,MAX_PATH);

			if(0==iFolderDwn)
			{	sz += MyStringCpy(pdst,MAX_PATH,s)+1;
				pdst = ((wchar_t*)dst) + sz;
				*pdst++=1;//folder attrb
				++sz;
				++tot;//folderniyam;
			}

			s[l++]='\\';//MyStringCat(s,MAX_PATH,"\\*");
			s[l++]='*';
			s[l]=0;
			tot += GetFilesInFolder(s,pdst,dstSz-(*blckSz),&sz,iFolderDwn);
			pdst = (wchar_t*)dst + sz;

			if(1==iFolderDwn)
			{	s[l]=0;
				sz += MyStringCpy(pdst,MAX_PATH,s)+1;
				pdst = ((wchar_t*)dst) + sz;
				*pdst++=1;//folder attrb
				++sz;
				++tot;//folderniyam;
			}

			if(sz+(*blckSz) > dstSz-MAX_PATH)goto End;
	}	}
	else
	{	if(fCopyOper::IsFileExtIncludeCopyFilterI(ff.cFileName))
		{	//char s[MAX_PATH];
			int l=MyStringCpy(pdst,MAX_PATH,path);//s
			if('*'==pdst[l-1])//MyStringRemoveLastCharCheckPre(s,MAX_PATH,'*','\\');
			if('\\'==pdst[l-2])
				pdst[--l]=0;
			MyStringCpy(&pdst[l],MAX_PATH-l,ff.cFileName);//MyStringCat(s,MAX_PATH,ff.cFileName);

			sz += l+1;//MyStringCpy(pdst,MAX_PATH,s)+1;
			pdst = ((wchar_t*)dst) + sz;
			*pdst++=2;//file attrb
			++sz;
			*((unsigned __int64*)pdst) = ((unsigned __int64)ff.nFileSizeHigh<<32) | ff.nFileSizeLow;
			pdst += sizeof(__int64);
			sz += sizeof(__int64);
			++tot;
			if(sz+(*blckSz) > dstSz-MAX_PATH)goto End;
	}	}

	while(FindNextFile(hf, &ff))
	{	if(FILE_ATTRIBUTE_DIRECTORY & ff.dwFileAttributes)//if(IsDirectory(path, &ff, FALSE))
		{	if(IsCrntOrPrntDirAttrb(ff.cFileName))
			{	wchar_t s[MAX_PATH];
				int l=MyStringCpy(s,MAX_PATH,path);
				if('*'==s[l-1])//MyStringRemoveLastCharCheckPre(s,MAX_PATH,'*','\\');
				if('\\'==s[l-2])
					s[--l]=0;
				l+=MyStringCpy(&s[l],MAX_PATH-l,ff.cFileName);//MyStringCat(s,MAX_PATH,ff.cFileName);
				//int l = MyStringLength(s,MAX_PATH);

				if(0==iFolderDwn)
				{	sz += MyStringCpy(pdst,MAX_PATH,s)+1;
					pdst = ((wchar_t*)dst) + sz;
					*pdst++=1;//folder attrb
					++sz;
					++tot;//folderniyam;
				}

				s[l++]='\\';//MyStringCat(s,MAX_PATH,"\\*");
				s[l++]='*';
				s[l]=0;
				tot += GetFilesInFolder(s,pdst,dstSz-(*blckSz),&sz,iFolderDwn);
				pdst = (wchar_t*)dst + sz;

				if(1==iFolderDwn)
				{	s[l]=0;
					sz += MyStringCpy(pdst,MAX_PATH,s)+1;
					pdst = ((wchar_t*)dst) + sz;
					*pdst++=1;//folder attrb
					++sz;
					++tot;//folderniyam;
				}

				if(sz+(*blckSz) > dstSz-MAX_PATH)goto End;
		}	}
		else
		{	if(fCopyOper::IsFileExtIncludeCopyFilterI(ff.cFileName))
			{	//char s[MAX_PATH]; MyStringCpy(s,MAX_PATH,path);
				int l=MyStringCpy(pdst,MAX_PATH,path);
				if('*'==pdst[l-1])//MyStringRemoveLastCharCheckPre(s,MAX_PATH,'*','\\');
				if('\\'==pdst[l-2])
					pdst[--l]=0;
				l+=MyStringCpy(&pdst[l],MAX_PATH-l,ff.cFileName);//MyStringCat(s,MAX_PATH,ff.cFileName);

				sz += l+1;//MyStringCpy(pdst,MAX_PATH,s)+1;
				pdst = ((wchar_t*)dst) + sz;
				*pdst++=2;//file attrb
				++sz;
				*((unsigned __int64*)pdst) = ((unsigned __int64)ff.nFileSizeHigh<<32) | ff.nFileSizeLow;
				pdst += sizeof(__int64);
				sz += sizeof(__int64);
				++tot;
				if(sz+(*blckSz) > dstSz-MAX_PATH)goto End;
	}	}	}
End:
	FindClose(hf);
	(*blckSz) += sz;
	return tot;
}

int GetSelectedFiles(CpyStack *stack)
{
int tot=0;
	for(int i=0; i<panel[fCopyOper::srcPanel].GetTotItems(); i++)
	{	if(selected==panel[fCopyOper::srcPanel].GetItem(i)->state || (0==panel[fCopyOper::srcPanel].GetTotSelects() && i==panel[fCopyOper::srcPanel].GetHot()))
		{	if(file == panel[fCopyOper::srcPanel].GetItem(i)->attribute)
			{	MyStringCpy(stack[tot].Name,MAX_PATH,panel[fCopyOper::srcPanel].GetItem(i)->Name);
				int l=MyStringCpy(stack[tot].FullPathAndName,MAX_PATH,panel[fCopyOper::srcPanel].GetPath());

				if('*'==stack[tot].FullPathAndName[l-1])//MyStringRemoveLastCharCheckPre(stack[tot].FullPathAndName,MAX_PATH,'*','\\');
				if('\\'==stack[tot].FullPathAndName[l-2])
					stack[tot].FullPathAndName[--l]=0;	
				l+=MyStringCpy(&stack[tot].FullPathAndName[l],MAX_PATH-l,panel[fCopyOper::srcPanel].GetItem(i)->Name);//MyStringCat(stack[tot].FullPathAndName,MAX_PATH,panel[fCopyOper::srcPanel].GetItem(i)->Name);
				stack[tot].size = panel[fCopyOper::srcPanel].GetItem(i)->size;
				stack[tot].attribute = file;
				++tot;
			}
			else if(folder == panel[fCopyOper::srcPanel].GetItem(i)->attribute)
			{	int l=panel[fCopyOper::srcPanel].GetFullPathAndName(i,stack[tot].FullPathAndName,MAX_PATH);
				MyStringCpy(stack[tot].Name,MAX_PATH,panel[fCopyOper::srcPanel].GetItem(i)->Name);
				stack[tot].attribute = folder;
				int saveTot=tot;
				++tot;//folderniyam;

				stack[saveTot].FullPathAndName[l]='\\';//MyStringCat(pth,MAX_PATH,"\\*");
				stack[saveTot].FullPathAndName[l+1]='*';
				stack[saveTot].FullPathAndName[l+2]=0;
				if(socketCl!=panel[fCopyOper::srcPanel].GetEntry()->GetCrntRecType())
					tot += fCopyOper::GetFilesInFolder(stack[saveTot].FullPathAndName,&stack[tot]);
				else
					tot += SendToServerMsg(fCopyOper::srcPanel,LNKSCKMSG_GET_FILES_IN_FOLDER,stack[saveTot].FullPathAndName,&stack[tot],0);//folders up, for copy
				stack[saveTot].FullPathAndName[l]=0;
 	}	}	}
	return tot;
}

int GetSelectedFilesCnt()
{
int tot=0;
 for(int i=0; i<panel[fCopyOper::srcPanel].GetTotItems(); i++)
 {	if(selected==panel[fCopyOper::srcPanel].GetItem(i)->state || (0==panel[fCopyOper::srcPanel].GetTotSelects() && i==panel[fCopyOper::srcPanel].GetHot()))
	{	if(file == panel[fCopyOper::srcPanel].GetItem(i)->attribute)
			++tot;
		else if(folder == panel[fCopyOper::srcPanel].GetItem(i)->attribute)
		{	wchar_t pth[MAX_PATH]; 
			int l=panel[fCopyOper::srcPanel].GetFullPathAndName(i,pth,MAX_PATH);
			++tot;//folderniyam;				
			pth[l++]='\\';//MyStringCat(pth,MAX_PATH,"\\*");
			pth[l++]='*';
			pth[l]=0;

			if(socketCl!=panel[fCopyOper::srcPanel].GetEntry()->GetCrntRecType())
				tot += fCopyOper::GetFilesCntInFolder(pth);
			else
				tot += SendToServerMsg(fCopyOper::srcPanel,LNKSCKMSG_GET_FILES_CNT_IN_FOLDER,pth);
 }	}	}
 return tot;
}

INT_PTR CALLBACK CopyQueueDlgProc(HWND hDlg,UINT message,WPARAM wParam,LPARAM lParam)
{
static HFONT hf=0;static int hfRef=0;//obshiy hf, dinamik uchun emas:
static HBRUSH br=0;
static HBRUSH brHtBk=0;
	UNREFERENCED_PARAMETER(lParam);
	switch(message)
	{
	case WM_INITDIALOG:
		//OutputDebugString("\nCopyQueueDlgProc WM_INITDIALOG 1");
		//Adjust to center:
		RECT rc; GetWindowRect(hDlg, &rc);
		int width,left,height,top;

		width = rc.right - rc.left;
		left = conf::wndLeft + (conf::wndWidth - width)/2;

		height = rc.bottom - rc.top;
		top = conf::wndTop + (conf::wndHeight - height)/2;
		MoveWindow(hDlg, left, top+20, width, height, TRUE);

		//Load language strings:
		wchar_t s[MAX_PATH];
		LoadString(hInst,IDS_STRINGSW_46,s,MAX_PATH);
		SetWindowText(hDlg,s);
		LoadString(hInst,IDS_STRINGSW_47,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_STATIC,s);
		LoadString(hInst,IDS_STRINGSW_48,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_STATIC5,s);
		LoadString(hInst,IDS_STRINGSW_49,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_BUTTON_TO_BACKGROUND_COPY_QUEUE,s);
		LoadString(hInst,IDS_STRINGSW_50,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_BUTTON_STOP,s);
		LoadString(hInst,IDS_STRINGSW_13,s,MAX_PATH);
		SetDlgItemText(hDlg,IDCANCEL,s);

		PostMessage(GetDlgItem(hDlg,IDC_PROGRESS_COPY_SINGLE),PBM_SETRANGE,0,MAKELPARAM(0,1000));
		PostMessage(GetDlgItem(hDlg,IDC_PROGRESS_COPY_TOTAL ),PBM_SETRANGE,0,MAKELPARAM(0,1000));
		PostMessage(GetDlgItem(hDlg,IDC_PROGRESS_COPY_SINGLE),PBM_SETSTEP,1,0);
		PostMessage(GetDlgItem(hDlg,IDC_PROGRESS_COPY_TOTAL ),PBM_SETSTEP,1,0);

		EnableWindow(GetDlgItem(hDlg,IDC_BUTTON_TO_BACKGROUND_COPY_QUEUE),FALSE);

		SendMessage(hDlg,WM_USER+1,0,0);
		SetWindowLongPtr(hDlg,GWLP_USERDATA,lParam);
		if(!lParam) return TRUE;//Agar confDlg dan chaqirilgan b-sa,rang-shriftlarini o'zgartirish uchun;

		//OutputDebugString("\nCopyQueueDlgProc WM_INITDIALOG 2");

		/*CalcSrcAndAvailableDestSize(); threadga ko'chiraman, wait ishlataman;

		//OutputDebugString("\nCopyQueueDlgProc WM_INITDIALOG 3");

		if(fCopyOper::avDstSz < fCopyOper::srcSz)
		{	char txt[MAX_PATH];StringCchPrintf(txt,MAX_PATH,"Available memory in %s is: %d, but needed %d. Start copy to available?",fCopyOper::avDstSz,fCopyOper::srcSz);
			if(IDCANCEL==MessageBox(NULL,txt,"Warn:",MB_OKCANCEL))
			{	EndDialog(hDlg,0);
				return TRUE;
		}	}
		fCopyOper::copySrcSz = 0;*/
		static DWORD cpyThrdId;
		CreateThread(NULL,1024,(LPTHREAD_START_ROUTINE)cpyFileExThrdFnc,hDlg,0,&cpyThrdId);
		return TRUE;
	case WM_CTLCOLORSTATIC:
	case WM_CTLCOLORDLG:HDC dc;dc = (HDC)wParam;
		SetTextColor(dc,conf::Dlg.dlgRGBs[1][1]);
		SetBkColor(dc,conf::Dlg.dlgRGBs[1][2]);
		return (INT_PTR)br;
	case WM_CTLCOLOREDIT:dc = (HDC)wParam;
		SetTextColor(dc,conf::Dlg.dlgRGBs[1][1]);
		SetBkColor(dc,conf::Dlg.dlgRGBs[1][2]);
		return (INT_PTR)br;
	case WM_CTLCOLORBTN:dc=(HDC)wParam;
		SetTextColor(dc,conf::Dlg.dlgRGBs[1][4]);
		SetBkColor(dc,conf::Dlg.dlgRGBs[1][5]);
		return (INT_PTR)brHtBk;
	case WM_DRAWITEM://WM_CTLCOLORBTN dagi knopkalar:
		LPDRAWITEMSTRUCT lpdis;lpdis = (LPDRAWITEMSTRUCT)lParam;
		GetWindowText(lpdis->hwndItem,s,64);
		UINT uStyle;uStyle = DFCS_BUTTONPUSH;
		rc = lpdis->rcItem;
		if(lpdis->itemState & ODS_SELECTED)
		{	uStyle |= DFCS_PUSHED;
			rc.left+=2;rc.top+=2;
		}
		DrawFrameControl(lpdis->hDC, &lpdis->rcItem, DFC_BUTTON, uStyle);
		if(lpdis->itemState & ODS_SELECTED)
			{rc.left+=1;rc.top+=1;rc.bottom-=2;rc.right-=3;}
		else
			{rc.left+=1;rc.top+=2;rc.bottom-=3;rc.right-=3;}
		FillRect(lpdis->hDC,&rc,brHtBk);//DrawText(lpdis->hDC,"                                                  ",50,&rc,DT_SINGLELINE|DT_VCENTER|DT_INTERNAL|DT_LEFT);
		if(lpdis->itemState & ODS_SELECTED)
			{rc.left-=1;rc.top-=1;rc.bottom+=3;rc.right+=3;}
		else
			{rc.left-=1;rc.top-=2;rc.bottom+=2;rc.right+=3;}
		DrawText(lpdis->hDC,s,MyStringLength(s,64),&rc,DT_SINGLELINE|DT_VCENTER|DT_CENTER);
		return TRUE;
	case WM_USER+1://hf obshiy uchun, dinamik o'zgartirish uchun emas:
		if(0==hfRef)
		{	hf = CreateFontIndirectW(&conf::Dlg.dlgFnts[1]);
			br = CreateSolidBrush(conf::Dlg.dlgRGBs[1][0]);
			brHtBk = CreateSolidBrush(conf::Dlg.dlgRGBs[1][5]);
		}
		SendMessage(GetDlgItem(hDlg,IDC_STATIC),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_STATIC5),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_BUTTON_TO_BACKGROUND_COPY_QUEUE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_BUTTON_STOP),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDCANCEL),WM_SETFONT,(WPARAM)hf,TRUE);
		++hfRef;
		return 0;//GWLP_USERDATA
	case WM_DESTROY:
		if(--hfRef<1)
		{	DeleteObject(hf);
			DeleteObject(br);
			DeleteObject(brHtBk);
		}
		return 0;
	case WM_USER+2://Dinamik o'zgartirish uchun:
		DeleteObject(hf);hfRef=1;
		hf = CreateFontIndirectW(&conf::Dlg.dlgFnts[1]);
		SendMessage(GetDlgItem(hDlg,IDC_STATIC),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_STATIC5),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_BUTTON_TO_BACKGROUND_COPY_QUEUE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_BUTTON_STOP),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDCANCEL),WM_SETFONT,(WPARAM)hf,TRUE);
		return 0;//GWLP_USERDATA
	case WM_USER+3://Dinamik o'zgartirish uchun, colorni:
		DeleteObject(br);DeleteObject(brHtBk);hfRef=1;
		br = CreateSolidBrush(conf::Dlg.dlgRGBs[1][0]);
		brHtBk = CreateSolidBrush(conf::Dlg.dlgRGBs[1][5]);
		RedrawWindow(hDlg,NULL,NULL,RDW_INVALIDATE|RDW_ALLCHILDREN);
		return 0;//GWLP_USERDATA
	case WM_COMMAND:
		switch(LOWORD(wParam))
		{	case IDC_BUTTON_STOP:
				if(!GetWindowLongPtr(hDlg,GWLP_USERDATA))return TRUE;
				PostThreadMessage(cpyThrdId,MYWM_STOP,0,0);
				return (INT_PTR)TRUE;
			case IDCANCEL:
				if(!GetWindowLongPtr(hDlg,GWLP_USERDATA))return TRUE;
				PostThreadMessage(cpyThrdId,MYWM_CANCEL,0,0);
				EndDialog(hDlg,0);
				return (INT_PTR)TRUE;
		}
		break;
	}
	return (INT_PTR)FALSE;
}

DWORD CALLBACK cpyPrgrssRout(LARGE_INTEGER	TotalFileSize,
							 LARGE_INTEGER	TotalBytesTransferred,
							 LARGE_INTEGER	StreamSize,
							 LARGE_INTEGER	StreamBytesTransferred,
							 DWORD			dwStreamNumber,
							 DWORD			dwCallbackReason,
							 HANDLE			hSourceFile,
							 HANDLE			hDestinationFile,
							 LPVOID			lpData)
{
	cpyTrdDat *pdat = (cpyTrdDat*)lpData;
	__int64 tfs = ((__int64)TotalFileSize.HighPart << 32) | TotalFileSize.LowPart;
	__int64 tbt = ((__int64)TotalBytesTransferred.HighPart << 32) | TotalBytesTransferred.LowPart;
	double prgrsPos = tfs?(1000.0*tbt/tfs):1000.0;
	PostMessage(GetDlgItem(pdat->hDlg,IDC_PROGRESS_COPY_SINGLE),PBM_SETPOS,(int)prgrsPos,0);

	tbt += fCopyOper::copySrcSz;
	double prgrsPosTot = tfs?(1000.0*tbt/fCopyOper::srcSz):1000.0;
	PostMessage(GetDlgItem(pdat->hDlg,IDC_PROGRESS_COPY_TOTAL),PBM_SETPOS,(int)prgrsPosTot,0);

	// ***************** % calculating: ***********************
	wchar_t s[MAX_PATH];StringCchPrintf(s,MAX_PATH,L"%.2f %s",0.1f*prgrsPos,L"%");
	SetDlgItemText(pdat->hDlg,IDC_STATIC1,s);
	StringCchPrintf(s,MAX_PATH,L"%.2f %s",100.0-0.1*prgrsPos,L"%");
	SetDlgItemText(pdat->hDlg,IDC_STATIC3,s);
	StringCchPrintf(s,MAX_PATH,L"%.2f %s",tfs?(100.0*tbt/fCopyOper::srcSz):100.0,L"%");
	SetDlgItemText(pdat->hDlg,IDC_STATIC6,s);
	StringCchPrintf(s,MAX_PATH,L"%.2f %s",tfs?(100.0-100.0*tbt/fCopyOper::srcSz):100.0,L"%");
	SetDlgItemText(pdat->hDlg,IDC_STATIC8,s);

	// ***************** tick calculating: ********************
	DWORD tick = GetTickCount() - pdat->beginTick - pdat->stopTick[0];
	MyTimeToString(s, tick);
	SetDlgItemText(pdat->hDlg,IDC_STATIC2,s);
	if(prgrsPos>0.0f)
	{	MyTimeToString(s, (int)(tick*(1000.0f-prgrsPos)/prgrsPos));
		SetDlgItemText(pdat->hDlg,IDC_STATIC4,s);
	}
	
	tick = GetTickCount() - pdat->beginTickTot - pdat->stopTickTot[0];
	MyTimeToString(s, tick);
	SetDlgItemText(pdat->hDlg,IDC_STATIC7,s);
	if(prgrsPosTot>0.0f)
	{	MyTimeToString(s, (int)(tick*(1.0f-0.001f*prgrsPosTot)/(0.001f*prgrsPosTot)));
		SetDlgItemText(pdat->hDlg,IDC_STATIC9,s);
	}
	
	if(pdat->bCancel)
		return PROGRESS_CANCEL;

	//Agar 1tagina fayl b-sa:
	MSG msg;//Only thread message:

Loop:
	//message from thread queue:
	if(PeekMessage(&msg,(HWND)-1,MYWM_CANCEL-1,MYWM_CANCEL+10,PM_REMOVE))
	{	
		//static int i=0;
		//char ss[32];sprintf(ss,"\n %d ",i++);
		//OutputDebugString(ss);
		//OutputDebugString(GetWinNotifyText(msg.message));

		switch(msg.message)
		{	case MYWM_CANCEL:
				return PROGRESS_CANCEL;
			case MYWM_STOP:
				if(pdat->bStop)
				{	LoadString(hInst,IDS_STRINGSW_50,s,MAX_PATH);
					SetDlgItemText(pdat->hDlg,IDC_BUTTON_STOP,s);
					pdat->stopTick[0] = GetTickCount() - pdat->stopTick[1];
					pdat->stopTickTot[0] = GetTickCount() - pdat->stopTickTot[1];
					pdat->bStop = FALSE;
				}
				else
				{	LoadString(hInst,IDS_STRINGSW_3,s,MAX_PATH);
					SetDlgItemText(pdat->hDlg,IDC_BUTTON_STOP,s);
					pdat->bStop = TRUE;
					pdat->stopTick[1] = pdat->stopTickTot[1] = GetTickCount();
					Sleep(250);
					goto Loop;
				}
				break;
 	}	}
	else if(pdat->bStop)
	{	Sleep(250);
		goto Loop;
	}

	return PROGRESS_CONTINUE;
}

BOOL WINAPI MyLinkSockCopyFileEx( __in	LPCTSTR lpExistingFileName,
								  __in  LPCTSTR lpNewFileName,
								  __in  LPPROGRESS_ROUTINE lpProgressRoutine,
								  __in  LPVOID lpData,
								  __in  LPBOOL pbCancel,
								  __in  DWORD dwCopyFlags)
{
	if(socketCl==panel[fCopyOper::destPanel].GetEntry()->GetCrntRecType())
	{//copy to server:
		//OutputDebugString("\nMyLinkSockCopyFileEx 1;");
		if(!SendToServerMsg(fCopyOper::destPanel,LNKSCKMSG_COPY_FILE_TO_SERVER,lpExistingFileName,
			lpNewFileName,lpProgressRoutine,lpData,pbCancel,dwCopyFlags))
			return FALSE;
	}
	else//copy from server:
	{	//OutputDebugString("\nMyLinkSockCopyFileEx 2;");
		if(!SendToServerMsg(fCopyOper::srcPanel,LNKSCKMSG_COPY_FILE_FROM_SERVER,lpExistingFileName,
				lpNewFileName,lpProgressRoutine,lpData,pbCancel,dwCopyFlags))
			return FALSE;
	}
	/*lpProgressRoutine(LARGE_INTEGER	TotalFileSize,
						LARGE_INTEGER	TotalBytesTransferred,
						0,//LARGE_INTEGER	StreamSize,
						0,//LARGE_INTEGER	StreamBytesTransferred,
						0,//DWORD			dwStreamNumber,
						0,//DWORD			dwCallbackReason,
						0,//HANDLE			hSourceFile,
						0,//HANDLE			hDestinationFile,
						lpData);*/
	return TRUE;
}

BOOL WINAPI MyLinkSockCopyRenameFileEx( 
								  __in	LPCTSTR lpExistingFileName,
								  __in  LPCTSTR lpNewFileName,
								  __in  LPPROGRESS_ROUTINE lpProgressRoutine,
								  __in  LPVOID lpData,
								  __in  LPBOOL pbCancel,
								  __in  DWORD dwCopyFlags)
{
	if(socketCl==panel[fCopyOper::destPanel].GetEntry()->GetCrntRecType())
	{//copy to server:
		if(!SendToServerMsg(fCopyOper::destPanel,
							LNKSCKMSG_COPY_RENAME_IF_EXIST_FILE_TO_SERVER,
							lpExistingFileName,lpNewFileName,lpProgressRoutine,
							lpData,pbCancel,dwCopyFlags))
			return FALSE;
	}
	else//copy from server:
	{	if(!SendToServerMsg(fCopyOper::srcPanel,LNKSCKMSG_COPY_RENAME_IF_EXIST_FILE_FROM_SERVER,lpExistingFileName,
				lpNewFileName,lpProgressRoutine,lpData,pbCancel,dwCopyFlags))
			return FALSE;
	}
	return TRUE;
}

BOOL WINAPI MyLinkSockCopyOverwriteOldestFileWithProgress(
								  __in	LPCTSTR lpExistingFileName,
								  __in  LPCTSTR lpNewFileName,
								  __in  LPPROGRESS_ROUTINE lpProgressRoutine,
								  __in  LPVOID lpData,
								  __in  LPBOOL pbCancel,
								  __in  DWORD dwCopyFlags,
								  __in  WIN32_FIND_DATA *fExist,
								  __in  WIN32_FIND_DATA *fNew)
{
	if(fExist && fNew)
	{	unsigned __int64 f0=((unsigned __int64)fExist->ftLastWriteTime.dwHighDateTime<<32) &
							 (unsigned __int64)fExist->ftLastWriteTime.dwLowDateTime;
		unsigned __int64 f1=((unsigned __int64)fNew->ftLastWriteTime.dwHighDateTime<<32) &
							 (unsigned __int64)fNew->ftLastWriteTime.dwLowDateTime;
		if(f0<f1)return TRUE;
	}

	if(socketCl==panel[fCopyOper::destPanel].GetEntry()->GetCrntRecType())
	{//copy to server:
		if(!SendToServerMsg(fCopyOper::destPanel,LNKSCKMSG_COPY_FILE_TO_SERVER,lpExistingFileName,
			lpNewFileName,lpProgressRoutine,lpData,pbCancel,dwCopyFlags))
			return FALSE;
	}
	else//copy from server:
	{	if(!SendToServerMsg(fCopyOper::srcPanel,LNKSCKMSG_COPY_FILE_FROM_SERVER,lpExistingFileName,
				lpNewFileName,lpProgressRoutine,lpData,pbCancel,dwCopyFlags))
			return FALSE;
	}
	return TRUE;
}

BOOL WINAPI MyLinkSockCopyOverwriteLatestFileWithProgress(
								  __in	LPCTSTR lpExistingFileName,
								  __in  LPCTSTR lpNewFileName,
								  __in  LPPROGRESS_ROUTINE lpProgressRoutine,
								  __in  LPVOID lpData,
								  __in  LPBOOL pbCancel,
								  __in  DWORD dwCopyFlags,
								  __in  WIN32_FIND_DATA *fExist,
								  __in  WIN32_FIND_DATA *fNew)
{
	if(fExist && fNew)
	{	unsigned __int64 f0=((unsigned __int64)fExist->ftLastWriteTime.dwHighDateTime<<32) &
							 (unsigned __int64)fExist->ftLastWriteTime.dwLowDateTime;
		unsigned __int64 f1=((unsigned __int64)fNew->ftLastWriteTime.dwHighDateTime<<32) &
							 (unsigned __int64)fNew->ftLastWriteTime.dwLowDateTime;
		if(f0>f1)return TRUE;
	}

	if(socketCl==panel[fCopyOper::destPanel].GetEntry()->GetCrntRecType())
	{//copy to server:
		if(!SendToServerMsg(fCopyOper::destPanel,LNKSCKMSG_COPY_FILE_TO_SERVER,lpExistingFileName,
			lpNewFileName,lpProgressRoutine,lpData,pbCancel,dwCopyFlags))
			return FALSE;
	}
	else//copy from server:
	{	if(!SendToServerMsg(fCopyOper::srcPanel,LNKSCKMSG_COPY_FILE_FROM_SERVER,lpExistingFileName,
				lpNewFileName,lpProgressRoutine,lpData,pbCancel,dwCopyFlags))
			return FALSE;
	}
	return TRUE;
}

BOOL WINAPI MyLinkSockCopyOverwriteBigestFileWithProgress(
								  __in	LPCTSTR lpExistingFileName,
								  __in  LPCTSTR lpNewFileName,
								  __in  LPPROGRESS_ROUTINE lpProgressRoutine,
								  __in  LPVOID lpData,
								  __in  LPBOOL pbCancel,
								  __in  DWORD dwCopyFlags,
								  __in  WIN32_FIND_DATA *fExist,
								  __in  WIN32_FIND_DATA *fNew)
{
	if(fExist && fNew)
	{	unsigned __int64 f0=((unsigned __int64)fExist->nFileSizeHigh<<32) &
							 (unsigned __int64)fExist->nFileSizeLow;
		unsigned __int64 f1=((unsigned __int64)fNew->nFileSizeHigh<<32) &
							 (unsigned __int64)fNew->nFileSizeLow;
		if(f0>f1)return TRUE;
	}

	if(socketCl==panel[fCopyOper::destPanel].GetEntry()->GetCrntRecType())
	{//copy to server:
		if(!SendToServerMsg(fCopyOper::destPanel,LNKSCKMSG_COPY_FILE_TO_SERVER,lpExistingFileName,
			lpNewFileName,lpProgressRoutine,lpData,pbCancel,dwCopyFlags))
			return FALSE;
	}
	else//copy from server:
	{	if(!SendToServerMsg(fCopyOper::srcPanel,LNKSCKMSG_COPY_FILE_FROM_SERVER,lpExistingFileName,
				lpNewFileName,lpProgressRoutine,lpData,pbCancel,dwCopyFlags))
			return FALSE;
	}
	return TRUE;
}

BOOL WINAPI MyLinkSockCopyOverwriteLittlestFileWithProgress(
								  __in	LPCTSTR lpExistingFileName,
								  __in  LPCTSTR lpNewFileName,
								  __in  LPPROGRESS_ROUTINE lpProgressRoutine,
								  __in  LPVOID lpData,
								  __in  LPBOOL pbCancel,
								  __in  DWORD dwCopyFlags,
								  __in  WIN32_FIND_DATA *fExist,
								  __in  WIN32_FIND_DATA *fNew)
{
	if(fExist && fNew)
	{	unsigned __int64 f0=((unsigned __int64)fExist->nFileSizeHigh<<32) &
							 (unsigned __int64)fExist->nFileSizeLow;
		unsigned __int64 f1=((unsigned __int64)fNew->nFileSizeHigh<<32) &
							 (unsigned __int64)fNew->nFileSizeLow;
		if(f0>f1)return TRUE;
	}

	if(socketCl==panel[fCopyOper::destPanel].GetEntry()->GetCrntRecType())
	{//copy to server:
		if(!SendToServerMsg(fCopyOper::destPanel,LNKSCKMSG_COPY_FILE_TO_SERVER,lpExistingFileName,
			lpNewFileName,lpProgressRoutine,lpData,pbCancel,dwCopyFlags))
			return FALSE;
	}
	else//copy from server:
	{	if(!SendToServerMsg(fCopyOper::srcPanel,LNKSCKMSG_COPY_FILE_FROM_SERVER,lpExistingFileName,
				lpNewFileName,lpProgressRoutine,lpData,pbCancel,dwCopyFlags))
			return FALSE;
	}
	return TRUE;
}

BOOL WINAPI MyLinkSockCreateDirectory(__in LPCTSTR lpPathName)
{
	if(!SendToServerMsg(fCopyOper::destPanel,LNKSCKMSG_CREATE_FOLDER,lpPathName))
		return FALSE;
	return TRUE;
}

BOOL MyTransmitFile(int iPanel,SOCKET hSocket,HANDLE hFile)
{
	DWORD rb = 0;
	do
	{	if(!ReadFile(hFile,rsBuf[iPanel],conf::Dlg.dwSockBufSize,&rb,NULL))
			break;
		if(!CheckForSend(hSocket,conf::Dlg.dwSockTimeout/70))
			return FALSE;
		if(rb>0)
			rb=sendto(hSocket,(const char*)rsBuf[iPanel],
					rb,0,(sockaddr*)&linkAddr[iPanel],sizeof(linkAddr[iPanel]));
	} while(rb>0);
	return TRUE;
}

int MyWSARecv(int iPanel,SOCKET s,CHAR* buf,int sz,DWORD *rn)
{
/*WSABUF wb;
	wb.buf=buf;wb.len=sz;
	int r = WSARecv(s,&wb,1,rn,0,NULL,NULL);
	if(r)
	{	r =  WSAGetLastError();
		Err::FlipMsg("WSARecv err.",2000);
		if(r) return r;
	}
	return 0;*/
	if(!CheckForRecv(s,2000))
		return FALSE;
	int r = recv(s,buf,sz,0);
	if(SOCKET_ERROR == *rn)
	{	*rn =  WSAGetLastError();
		if(*rn)
		{	Err::FlipMsg(L"WSASendTo err.",2000);
			return *rn;
	}	}
	return 0;
}

int MyWSASendTo(int iPanel,SOCKET s,CHAR* buf,int sz,DWORD *rn)
{
/*WSABUF wb;
	wb.buf=buf;wb.len=sz;
	int r = WSASendTo(s,&wb,1,rn,0,(sockaddr*)&linkAddr[iPanel],sizeof(linkAddr[iPanel]),NULL,NULL);
	if(r)
	{	r =  WSAGetLastError();
		if(r)
		{	Err::FlipMsg("WSASendTo err.",2000);
			return r;
	}	}
	return 0;*/
	if(!CheckForSend(s,2000))
		return FALSE;
	*rn = sendto(s,buf,sz,0,(sockaddr*)&linkAddr[iPanel],sizeof(linkAddr[iPanel]));
	if(SOCKET_ERROR == *rn)
	{	*rn =  WSAGetLastError();
		if(*rn)
		{	Err::FlipMsg(L"WSASendTo err.",2000);
			return *rn;
	}	}
	return 0;
}

BOOL OnDirectoryChangeNotify(int iPanel, wchar_t* notifyPath)
{
	if(socketCl==panel[iPanel].GetEntry()->GetCrntRecType())
		return FALSE;
	int* iSnd = (int*)rsBuf[iPanel];
	iSnd[0] = LNKSCKMSG_ON_DIRECTORY_CHANGE_NOTIFY;

int l=0;
	if(notifyPath)l = MyStringCpy((wchar_t*)&iSnd[1],MAX_PATH,notifyPath);
	else l = MyStringCpy((wchar_t*)&iSnd[1],MAX_PATH,panel[iPanel].GetPath());
	if('*'!=rsBuf[iPanel][sizeof(int)+sizeof(wchar_t)*(l-1)] ||
		'\\'!=rsBuf[iPanel][sizeof(int)+sizeof(wchar_t)*(l-2)])
	{	((wchar_t*)&iSnd[1])[l++]='\\';//l += MyStringCat((char*)&iSnd[1],MAX_PATH,"\\*");
		((wchar_t*)&iSnd[1])[l++]='*';
		((wchar_t*)&iSnd[1])[l]=0;
	}
	wchar_t msgToInfo[MAX_PATH];StringCchPrintf(msgToInfo,MAX_PATH,L"FolderIn:%s",(wchar_t*)&iSnd[1]);

int totFolders=0,totFiles=0;
int totSended=0;

	wchar_t *pBeg = ((wchar_t*)&iSnd[1]);
	wchar_t *pEnd = ((wchar_t*)iSnd)+conf::Dlg.dwSockBufSize;
	WIN32_FIND_DATA ff;DWORD r;
	HANDLE hFind = MyFindFirstFileEx(pBeg,FindExInfoStandard,&ff,FindExSearchLimitToDirectories,NULL,0);
	pBeg += l+1;

	if(INVALID_HANDLE_VALUE==hFind) return FALSE;
	if(FILE_ATTRIBUTE_DIRECTORY & ff.dwFileAttributes)//if(IsDirectory(p->path, &ff, TRUE))
	{	if(IsCrntOrPrntDirAttrb(ff.cFileName))
		{	totFolders++;
			CpyMyFindData((SOCKWIN32_FIND_DATA**)&pBeg,&ff);
			if(pBeg>pEnd)
			{	if(MyWSASendTo(iPanel,sockSrvrCl[iPanel],(CHAR*)iSnd,
							  (int)((char*)pBeg - (char*)iSnd),&r))
					return FALSE;
				totSended += (int)((char*)pBeg - (char*)iSnd);
				pBeg = (wchar_t*)iSnd;
	}	}	}
	else
	{	CpyMyFindData((SOCKWIN32_FIND_DATA**)&pBeg,&ff);
		if(pBeg>pEnd)
		{	if(MyWSASendTo(iPanel,sockSrvrCl[iPanel],(CHAR*)iSnd,
							(int)((char*)pBeg - (char*)iSnd),&r))
			return FALSE;
			totSended += (int)((char*)pBeg - (char*)iSnd);
			pBeg = (wchar_t*)iSnd;
	}	}

	while(FindNextFile(hFind, &ff))
	{	if(FILE_ATTRIBUTE_DIRECTORY & ff.dwFileAttributes)//if(IsDirectory(p->path, &ff, FALSE))
		{	if(IsCrntOrPrntDirAttrb(ff.cFileName))
			{	totFolders++;
				CpyMyFindData((SOCKWIN32_FIND_DATA**)&pBeg,&ff);
				if(pBeg>pEnd)
				{	if(MyWSASendTo(iPanel,sockSrvrCl[iPanel],(CHAR*)iSnd,
									(int)((char*)pBeg - (char*)iSnd),&r))
						return FALSE;				
					totSended += (int)((char*)pBeg - (char*)iSnd);
					pBeg = (wchar_t*)iSnd;
		}	}	}
		else
		{	totFiles++;
			CpyMyFindData((SOCKWIN32_FIND_DATA**)&pBeg,&ff);
			if(pBeg>pEnd)
			{	if(MyWSASendTo(iPanel,sockSrvrCl[iPanel],(CHAR*)iSnd,
									(int)((char*)pBeg-(char*)iSnd),&r))
					return FALSE;									
				totSended += (int)((char*)pBeg-(char*)iSnd);
				pBeg = (wchar_t*)iSnd;
	}	}	}
	FindClose(hFind);
	if(pBeg > ((wchar_t*)iSnd))
	{	if(MyWSASendTo(iPanel,sockSrvrCl[iPanel],(CHAR*)iSnd,
						(int)((char*)pBeg-(char*)iSnd),&r))
			return FALSE;									
		totSended += (int)((char*)pBeg-(char*)iSnd);
	}

	wchar_t st[128];StringCchPrintf(st,128,L"OnDirChNot.Tot.sended bytes:%d,folders:%d,files:%d",
					totSended,totFolders,totFiles);
	AddStrToMultilineEdt(sockDlg[iPanel],IDC_EDIT_SPEED,msgToInfo,st);

	return TRUE;
}	

VOID cpyFileExThrdFnc(LPVOID lpar)
{
cpyTrdDat dat; dat.hDlg = (HWND)lpar;
	dat.bStop = FALSE;
	dat.bCancel = FALSE;
	dat.thrId = GetCurrentThreadId();
	dat.beginTick = dat.beginTickTot = GetTickCount();
	dat.stopTick[0] = dat.stopTickTot[0] = 0;
	enCheckCopyFilesToExisting = showEach;

	CalcSrcAndAvailableDestSize();// threadga ko'chiraman, wait ishlatganim uchun;

	//OutputDebugString("\nCopyQueueDlgProc WM_INITDIALOG 3");

	if(fCopyOper::avDstSz < fCopyOper::srcSz)
	{	wchar_t txt[MAX_PATH];StringCchPrintf(txt,MAX_PATH,L"Available memory in %s is: %d, but needed %d. Start copy to available?",fCopyOper::avDstSz,fCopyOper::srcSz);
		if(IDCANCEL==MessageBox(NULL,txt,L"Warn:",MB_OKCANCEL))
			goto End;
	}
	fCopyOper::copySrcSz = 0;






 wchar_t dst[MAX_PATH],buf[MAX_PATH];
 size_t dstPathLn;

 int totFiles = 0;
 if(socketCl!=panel[fCopyOper::srcPanel].GetEntry()->GetCrntRecType())
	totFiles = fCopyOper::GetSelectedFilesCnt();
 else
	totFiles = GetSelectedFilesCnt();
 dat.stack = (CpyStack*)malloc(totFiles*sizeof(CpyStack));
 GetSelectedFiles(dat.stack);//for copy oper, folders up, files down to list;
 fCopyOper::CutSelectedNames(dat.stack,panel[fCopyOper::srcPanel].GetPath(),totFiles);


 dstPathLn=MyStringCpy(dst,MAX_PATH,fCopyOper::destPath);
 if(fCopyOper::allToRenFolder==fCopyOper::srcType)
 {	dst[dstPathLn++]='\\';//MyStringCat(dst,MAX_PATH,"\\");//Yangi yo'l kiritsa;
 	dst[dstPathLn]=0;
	if(socketCl==panel[fCopyOper::destPanel].GetEntry()->GetCrntRecType())
	{	if(!MyLinkSockCreateDirectory(dst))//yangi yo'lini avval yaratib olsun;
			goto End;
	}
	else//socket-source;
	{	if(!MyCreateDirectory(dst,NULL))//yangi yo'lini avval yaratib olsun;
			goto End;
 }  }

 for(dat.iCrntFileCopy=0; dat.iCrntFileCopy<totFiles; dat.iCrntFileCopy++)
 {


 if(fCopyOper::unchange==fCopyOper::srcType)
	MyStringCpy(&dst[dstPathLn],MAX_PATH-(int)dstPathLn,dat.stack[dat.iCrntFileCopy].Name);//MyStringCat(dst,MAX_PATH,dat.stack[dat.iCrntFileCopy].Name);
 else
 {	if(fCopyOper::allToRenFolder==fCopyOper::srcType)
	{	//char *p=NULL;
		//if(dat.iCrntFileCopy>0)
		//if(folder==dat.stack[dat.iCrntFileCopy].attribute)//o'zgartirsa:
		//	p = strchr(dat.stack[dat.iCrntFileCopy].Name,'\\');
		MyStringCpy(&dst[dstPathLn],MAX_PATH-(int)dstPathLn,dat.stack[dat.iCrntFileCopy].Name);//MyStringCat(dst,MAX_PATH,dat.stack[dat.iCrntFileCopy].Name);
 	}
	else if(fCopyOper::rename1Folder==fCopyOper::srcType)
	{	if(dat.iCrntFileCopy>0)
		{	wchar_t *p=NULL;
			if(folder==dat.stack[0].attribute)//o'zgartirsa:
				p = wcschr(dat.stack[dat.iCrntFileCopy].Name,'\\');
			MyStringCpy(&dst[dstPathLn],MAX_PATH-(int)dstPathLn,p?p:dat.stack[dat.iCrntFileCopy].Name);//MyStringCat(dst,MAX_PATH,p?p:dat.stack[dat.iCrntFileCopy].Name);
 }	}	}


 if(file==dat.stack[dat.iCrntFileCopy].attribute)
 { if(!wcscmp(dat.stack[dat.iCrntFileCopy].FullPathAndName,dst))
   {	LoadString(hInst,IDS_STRINGSW_51,buf,MAX_PATH);
		MessageBox(NULL,buf,L"Err.",MB_OK);
   }
   else
   {BOOL r; WIN32_FIND_DATA *fFrom,*fTo;
	//if(socketCl!=panel[fCopyOper::destPanel].GetEntry()->GetCrntRecType())
	//	r=fBckgrndCopyOper::CheckCopyFilesToExisting(dat.hDlg,dat.stack[dat.iCrntFileCopy].FullPathAndName,dst);
	//else
		r=CheckCopyFilesToExisting(dat.hDlg,dat.stack[dat.iCrntFileCopy].FullPathAndName,dst,&fFrom,&fTo);
	if(r==skipAll || r==skip)
     	goto skipOne;
	else if(r==cancel)
		goto End;
	else if(r==overwrite || r==overwriteAll)
    {//OutputDebugString("\ngo to MyLinkSockCopyFileEx;");
	 if(!MyLinkSockCopyFileEx(dat.stack[dat.iCrntFileCopy].FullPathAndName,dst,cpyPrgrssRout,&dat,FALSE,0))
	 {	dat.bStop = FALSE;
		//OutputDebugString("\ncpyFileExThrdFnc, goto End");
		goto End;
     }}
	else if(r==rename1 || r==renameAll)
    {//OutputDebugString("\ngo to MyLinkSockCopyFileEx;");
	 if(!MyLinkSockCopyRenameFileEx(dat.stack[dat.iCrntFileCopy].FullPathAndName,dst,cpyPrgrssRout,&dat,FALSE,0))
	 {	dat.bStop = FALSE;
		goto End;
    }}
    else if(r==overwriteOldest || r==overwriteOldestAll)
    {if(!MyLinkSockCopyOverwriteOldestFileWithProgress(dat.stack[dat.iCrntFileCopy].FullPathAndName,dst,cpyPrgrssRout,&dat,FALSE,0,fFrom,fTo))
	 {	dat.bStop = FALSE;
		goto End;
	}}
    else if(r==overwriteLatest || r==overwriteLatestAll)
    {if(!MyLinkSockCopyOverwriteLatestFileWithProgress(dat.stack[dat.iCrntFileCopy].FullPathAndName,dst,cpyPrgrssRout,&dat,FALSE,0,fFrom,fTo))
	 {	dat.bStop = FALSE;
		goto End;
	}}
    else if(r==overwriteBigest || r==overwriteBigestAll)
    {if(!MyLinkSockCopyOverwriteBigestFileWithProgress(dat.stack[dat.iCrntFileCopy].FullPathAndName,dst,cpyPrgrssRout,&dat,FALSE,0,fFrom,fTo))
	 {	dat.bStop = FALSE;
		goto End;
	}}
    else if(r==overwriteLittlest || r==overwriteLittlestAll)
    {if(!MyLinkSockCopyOverwriteLittlestFileWithProgress(dat.stack[dat.iCrntFileCopy].FullPathAndName,dst,cpyPrgrssRout,&dat,FALSE,0,fFrom,fTo))
	 {	dat.bStop = FALSE;
		goto End;
   }}}

   //OutputDebugString("\ncpyFileExThrdFnc, CheckCopyFilesToExisting post normally;");

   fCopyOper::copySrcSz += dat.stack[dat.iCrntFileCopy].size;
   fCopyOper::avDstSz -= dat.stack[dat.iCrntFileCopy].size;
   PostMessage(GetDlgItem(dat.hDlg,IDC_PROGRESS_COPY_SINGLE),PBM_SETPOS,1000,0);
   PostMessage(GetDlgItem(dat.hDlg,IDC_PROGRESS_COPY_TOTAL ),PBM_SETPOS,
   (int)(fCopyOper::srcSz?(1000.0f*fCopyOper::copySrcSz/fCopyOper::srcSz):1000.0f),0);
   dat.stopTick[0] = 0;
   dat.beginTick = GetTickCount();
 }
 else
 {	if(socketCl==panel[fCopyOper::destPanel].GetEntry()->GetCrntRecType())
	{	if(!MyLinkSockCreateDirectory(dst))
			goto End;
    }
	else
	{	if(!MyCreateDirectory(dst,NULL))
			goto End;
 }  }
skipOne:
 dst[dstPathLn]=0;
	
Loop:
	MSG msg;//Only thread message:
	if(PeekMessage(&msg,(HWND)-1,MYWM_CANCEL-1,MYWM_CANCEL+10,PM_REMOVE))
	{	
		//static int i=0;
		//char ss[32];sprintf(ss,"\n %d ",i++);
		//OutputDebugString(ss);
		//OutputDebugString(GetWinNotifyText(msg.message));
		
		switch(msg.message)
		{	case MYWM_CANCEL:
				dat.bCancel = TRUE;
				goto End;
			case MYWM_STOP:
				wchar_t s[MAX_PATH];
				if(dat.bStop)
				{	LoadString(hInst,IDS_STRINGSW_50,s,MAX_PATH);
					SetDlgItemText(dat.hDlg,IDC_BUTTON_STOP,s);
					dat.bStop = FALSE;
				}
				else
				{	LoadString(hInst,IDS_STRINGSW_3,s,MAX_PATH);
					SetDlgItemText(dat.hDlg,IDC_BUTTON_STOP,s);
					dat.bStop = TRUE;
					Sleep(250);
					goto Loop;
				}
				break;
 	}	}
	else if(dat.bStop)
	{	Sleep(250);
		goto Loop;
}	}
End:
 EndDialog(dat.hDlg,0);//DialogBox(CopyQueueDlgProc) ishlatilganligi uchun;
 if(dat.stack) free(dat.stack);

 //1 marta optom Notify yuborsun:
 if(sockDlg[fCopyOper::destPanel])
 if(socketCl==panel[fCopyOper::destPanel].GetEntry()->GetCrntRecType())
	SendToServerMsg(fCopyOper::destPanel,LNKSCKMSG_ON_DIRECTORY_CHANGE_NOTIFY,panel[fCopyOper::destPanel].GetPath());

 ExitThread(0);
}

} //end of namespace LinkSock