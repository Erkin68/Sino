#ifndef _LANGUAGE_H_
#define _LANGUAGE_H_

#include "windows.h"

namespace language
{
	extern BOOL			SetInStartup(HWND);
	extern INT_PTR CALLBACK DlgProc(HWND,UINT,WPARAM,LPARAM);
	extern BOOL			Set(int,HWND);
	extern VOID			Destroy();
	extern VOID ChangeMenuBitmap(HWND,int,int,int);
}

#endif