#ifndef _Backgrnd_thread_move_operation_h
#define _Backgrnd_thread_move_operation_h

#include "windows.h"

namespace fBckgrndMoveOper
{
	extern BOOL	AddToQueueFrMoveOperation();
	extern BOOL	ShowCopyDlg();
}

#endif