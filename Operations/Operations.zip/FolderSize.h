

namespace FolderSize
{
	extern __int64 GetFolderSize(wchar_t*,int);
	extern BOOL CalcFldrSize(int,int);
	extern DWORD WINAPI mainThrd();

	extern BOOL bCritSctn;
	extern HANDLE hThrd;
	extern DWORD thrdId;
	extern wchar_t pth[MAX_PATH];
}
