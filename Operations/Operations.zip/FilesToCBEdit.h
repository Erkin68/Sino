#ifndef _FILES_TO_CB_EDIT_H_
#define _FILES_TO_CB_EDIT_H_


namespace FilesToCBEdit
{
	extern INT_PTR CALLBACK showLBDlgProc(HWND,UINT,WPARAM,LPARAM);
	extern int  Attach(HWND,HWND,BOOL,BOOL,wchar_t*,int);
	extern BOOL AnalyzeEdit(wchar_t*);
	extern BOOL RebuildLB(wchar_t*);
	extern BOOL RecalcDlgHeight(int);
	extern int  GetEditText(wchar_t*);
	extern BOOL SetEditText(wchar_t*);
}//end of registry
#endif
