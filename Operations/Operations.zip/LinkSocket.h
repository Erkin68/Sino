#include "windows.h"
#include "CopyOperation.h"
#include "..\Panel.h"


#define MW_RECV_SERVER			WM_USER+20
#define MW_RECV_CLIENT			WM_USER+21

typedef struct TSOCKWIN32_FIND_DATA
{DWORD    dwFileAttributes; 
 FILETIME ftCreationTime; 
 FILETIME ftLastAccessTime; 
 FILETIME ftLastWriteTime; 
 DWORD    nFileSizeHigh; 
 DWORD    nFileSizeLow; 
 DWORD    dwReserved0; 
 DWORD    dwReserved1; 
 WCHAR    cAlternateFileName[14]; 
 WCHAR	  cFileName[1];//[ MAX_PATH ];
} SOCKWIN32_FIND_DATA;

namespace linkSock
{
#define MYWM_CANCEL		 0x7f00
#define MYWM_STOP		 0x7f01
#define MYWM_GOTOBCKGRND 0x7f02

struct in_addr6
{
	u_char    s6_addr[16];         /* IPv6 address */
};
struct sockaddr_in6
{
	short             sin6_family;   /* AF_INET6 */
    u_short           sin6_port;     /* Transport level port number */
    u_long            sin6_flowinfo; /* IPv6 flow information */
    struct in_addr6   sin6_addr;     /* IPv6 address */
};

//#define conf::Dlg.dwSockBufSize					524288
#define LNKSCKMSG_INIT_DLG_PAR							0
#define LNKSCKMSG_FOLDER_ENUM_LIST						1
#define LNKSCKMSG_ABORT									2
#define LNKSCKMSG_FOLDERIN								3
#define LNKSCKMSG_FOLDERUP								4
#define LNKSCKMSG_ON_DIRECTORY_CHANGE_NOTIFY			5
#define LNKSCKMSG_CLIENT_IDENTIFY						6
#define LNKSCKMSG_CREATE_FOLDER							7
#define LNKSCKMSG_CREATE_FOLDER_NOT_WAIT				8
#define LNKSCKMSG_COPY_FILE_TO_SERVER					9
#define LNKSCKMSG_COPY_RENAME_IF_EXIST_FILE_TO_SERVER	10
#define LNKSCKMSG_COPY_FILE_FROM_SERVER					11
#define LNKSCKMSG_GET_FOLDER_SIZE_FROM_SERVER			12
#define LNKSCKMSG_COPY_RENAME_IF_EXIST_FILE_FROM_SERVER 13
#define LNKSCKMSG_ACKNOWLEDGE							14
#define LNKSCKMSG_GET_DRIVE_AVIALABLE_MEM				15
#define LNKSCKMSG_GET_FILES_IN_FOLDER					16
#define LNKSCKMSG_GET_FILES_CNT_IN_FOLDER				17
#define LNKSCKMSG_FindFirstFile							18
#define LNKSCKMSG_DeleteFile							19
#define LNKSCKMSG_RemoveDirectory						20
#define LNKSCKMSG_RenameFileOrDirectory					21


	extern INT_PTR CALLBACK DlgProc(HWND,UINT,WPARAM,LPARAM);
	extern BOOL DoClient();
	extern BOOL DoServer();

	//Client part of panel queue:******************************
	extern BOOL FolderInClient(Panel*,int);					//*
	extern BOOL FolderUpClient(Panel*,int);					//*
	//*********************************************************

	extern BOOL CheckForRecv(SOCKET,long);
	extern BOOL CheckForSend(SOCKET,long);
	extern BOOL ReceiveFrClientMsg(int,WPARAM,LPARAM);
	extern BOOL ReceiveFrServerMsg(int,WPARAM,LPARAM);
	extern BOOL SendToClientMsg(int,int,...);
	extern BOOL SendToServerMsg(int,int,...);

	//Copy queue:
	extern VOID AddStrToMultilineEdt(HWND,int,wchar_t*,wchar_t*);
	extern INT_PTR CALLBACK CopyQueueDlgProc(HWND,UINT,WPARAM,LPARAM);
	extern VOID cpyFileExThrdFnc(LPVOID);
	extern VOID CpyMyFindData(SOCKWIN32_FIND_DATA**,WIN32_FIND_DATA*);
	extern VOID CalcSrcAndAvailableDestSize();
	extern int GetSelectedFiles(CpyStack*);
	extern int GetSelectedFilesCnt();
	extern BOOL WINAPI MyLinkSockCreateDirectory(__in LPCTSTR);
	extern int GetFilesInFolder(wchar_t*,VOID*,int,int*,int);
	extern BOOL MyTransmitFile(int,SOCKET,HANDLE);
	extern BOOL OnDirectoryChangeNotify(int,wchar_t*);
	extern int MyWSARecv(int,SOCKET,CHAR*,int,DWORD*);
	extern int MyWSASendTo(int,SOCKET,CHAR*,int,DWORD*);

	//Renmove queue:
	extern INT_PTR CALLBACK RMCopyQueueDlgProc(HWND,UINT,WPARAM,LPARAM);

	extern int dlgRetCode;
	extern SOCKET sockSrvrCl[MAX_PANELS];
	extern HWND	sockDlg[MAX_PANELS];
	extern BYTE* rsBuf[MAX_PANELS];
	extern sockaddr_in6 linkAddr[MAX_PANELS];
	extern int accessType[MAX_PANELS];
};
