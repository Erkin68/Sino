#include "..\Sino.h"
#include "..\Config.h"
#include "strsafe.h"
#include "MyErrors.h"
#include "MyShell\MyShell.h"
//#include "MyShell\MyButtonC++.h"
#include "DeleteOperation.h"
#include "Backgrnd thread copy operation.h"



EnCheckCopyFilesToExisting enCheckCopyFilesToExisting;



namespace fBckgrndCopyOper
{

#define MYWM_CANCEL	0x7f00
#define MYWM_STOP   0x7f01

CRITICAL_SECTION critSect;
HWND	dlg(NULL);
DWORD   cpyThrdId;
unsigned __int64 totSizes;
unsigned __int64 copyedSizes;


INT_PTR CALLBACK BckgrndCopyDlgProc(HWND hDlg,UINT message,WPARAM wParam,LPARAM lParam)
{
static HFONT hf=0;static int hfRef=0;//obshiy hf, dinamik uchun emas:
static HBRUSH br=0;
static HBRUSH brHtBk=0;
	UNREFERENCED_PARAMETER(lParam);
	switch(message)
	{
	case WM_INITDIALOG:

		InitializeCriticalSection(&critSect);

		//Adjust:
		RECT rc; GetWindowRect(hDlg, &rc);
		int width,height;
		width = rc.right - rc.left;
		height = rc.bottom - rc.top;
		MoveWindow(hDlg, conf::bckgrndCpyDlgPozX, conf::bckgrndCpyDlgPozY, width, height, TRUE);//MoveWindow(hDlg, left, top+20, width, height, TRUE);

		//Load language strings:
		wchar_t s[MAX_PATH];
		LoadString(hInst,IDS_STRINGSW_46,s,MAX_PATH);
		SetWindowText(hDlg,s);
		LoadString(hInst,IDS_STRINGSW_47,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_STATIC,s);
		LoadString(hInst,IDS_STRINGSW_48,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_STATIC5,s);
		LoadString(hInst,IDS_STRINGSW_50,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_BUTTON_STOP,s);
		LoadString(hInst,IDS_STRINGSW_13,s,MAX_PATH);
		SetDlgItemText(hDlg,IDCANCEL,s);

		PostMessage(GetDlgItem(hDlg,IDC_PROGRESS_COPY_SINGLE),PBM_SETRANGE,0,MAKELPARAM(0,1000));
		PostMessage(GetDlgItem(hDlg,IDC_PROGRESS_COPY_TOTAL ),PBM_SETRANGE,0,MAKELPARAM(0,1000));
		PostMessage(GetDlgItem(hDlg,IDC_PROGRESS_COPY_SINGLE),PBM_SETSTEP,1,0);
		PostMessage(GetDlgItem(hDlg,IDC_PROGRESS_COPY_TOTAL ),PBM_SETSTEP,1,0);

		//MyButtonFrRCBtn(hDlg,IDC_BUTTON_STOP,conf::Dlg.iBtnsType);
		//MyButtonFrRCBtn(hDlg,IDCANCEL,conf::Dlg.iBtnsType);

		SendMessage(hDlg,WM_USER+1,0,0);
		SetWindowLongPtr(hDlg,GWLP_USERDATA,lParam);
		return TRUE;
	case WM_USER:
		if(1==wParam)//destroy command from thread
		{	DestroyWindow(hDlg);
			dlg = NULL;
		}
		break;
	case WM_CTLCOLORSTATIC:
	case WM_CTLCOLORDLG:
		if(2==conf::Dlg.iBtnsType)
		{	HDC dc;dc = (HDC)wParam;
			SetTextColor(dc,conf::Dlg.dlgRGBs[2][1]);
			SetBkColor(dc,conf::Dlg.dlgRGBs[2][2]);
			return (INT_PTR)br;
		}return 0;
	case WM_CTLCOLOREDIT:
		if(2==conf::Dlg.iBtnsType)
		{	HDC dc = (HDC)wParam;
			SetTextColor(dc,conf::Dlg.dlgRGBs[2][1]);
			SetBkColor(dc,conf::Dlg.dlgRGBs[2][2]);
			return (INT_PTR)br;
		}return 0;
	case WM_CTLCOLORBTN:
		if(2==conf::Dlg.iBtnsType)
		{	HDC dc=(HDC)wParam;
			SetTextColor(dc,conf::Dlg.dlgRGBs[2][4]);
			SetBkColor(dc,conf::Dlg.dlgRGBs[2][5]);
			return (INT_PTR)brHtBk;
		}return 0;
	case WM_DRAWITEM://WM_CTLCOLORBTN dagi knopkalar:
		if(2==conf::Dlg.iBtnsType)
		{	LPDRAWITEMSTRUCT lpdis;lpdis = (LPDRAWITEMSTRUCT)lParam;
			GetWindowText(lpdis->hwndItem,s,64);
			UINT uStyle;uStyle = DFCS_BUTTONPUSH;
			rc = lpdis->rcItem;
			if(lpdis->itemState & ODS_SELECTED)
			{	uStyle |= DFCS_PUSHED;
				rc.left+=2;rc.top+=2;
			}
			DrawFrameControl(lpdis->hDC, &lpdis->rcItem, DFC_BUTTON, uStyle);
			if(lpdis->itemState & ODS_SELECTED)
				{rc.left+=1;rc.top+=1;rc.bottom-=2;rc.right-=3;}
			else
				{rc.left+=1;rc.top+=2;rc.bottom-=3;rc.right-=3;}
			FillRect(lpdis->hDC,&rc,brHtBk);//DrawText(lpdis->hDC,L"                                                  ",50,&rc,DT_SINGLELINE|DT_VCENTER|DT_INTERNAL|DT_LEFT);
			if(lpdis->itemState & ODS_SELECTED)
				{rc.left-=1;rc.top-=1;rc.bottom+=3;rc.right+=3;}
			else
				{rc.left-=1;rc.top-=2;rc.bottom+=2;rc.right+=3;}
			DrawText(lpdis->hDC,s,MyStringLength(s,64),&rc,DT_SINGLELINE|DT_VCENTER|DT_CENTER);
			return TRUE;
		}return 0;
	case WM_USER+1://hf obshiy uchun, dinamik o'zgartirish uchun emas:
		if(0==hfRef)
		{	hf = CreateFontIndirect(&conf::Dlg.dlgFnts[2]);
			br = CreateSolidBrush(conf::Dlg.dlgRGBs[2][0]);
			brHtBk = CreateSolidBrush(conf::Dlg.dlgRGBs[2][5]);
		}
		SendMessage(GetDlgItem(hDlg,IDC_STATIC4),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_STATIC8),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_BUTTON_STOP),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDCANCEL),WM_SETFONT,(WPARAM)hf,TRUE);
		++hfRef;
		return 0;//GWL_USERDATA
	case WM_DESTROY:
		if(--hfRef<1)
		{	DeleteObject(hf);
			DeleteObject(br);
			DeleteObject(brHtBk);
		}
		DeleteCriticalSection(&critSect);
		return 0;
	case WM_USER+2://Dinamik o'zgartirish uchun:
		DeleteObject(hf);hfRef=1;
		hf = CreateFontIndirect(&conf::Dlg.dlgFnts[2]);
		SendMessage(GetDlgItem(hDlg,IDC_STATIC4),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_STATIC8),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_BUTTON_STOP),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDCANCEL),WM_SETFONT,(WPARAM)hf,TRUE);
		return 0;//GWL_USERDATA
	case WM_USER+3://Dinamik o'zgartirish uchun, colorni:
		DeleteObject(br);DeleteObject(brHtBk);hfRef=1;
		br = CreateSolidBrush(conf::Dlg.dlgRGBs[2][0]);
		brHtBk = CreateSolidBrush(conf::Dlg.dlgRGBs[2][5]);
		RedrawWindow(hDlg,NULL,NULL,RDW_INVALIDATE|RDW_ALLCHILDREN);
		return 0;//GWL_USERDATA
	case WM_MOVE:
		conf::bckgrndCpyDlgPozX = (int)(short) LOWORD(lParam);
		conf::bckgrndCpyDlgPozY = (int)(short) HIWORD(lParam);   
		break;
	case WM_COMMAND:
		switch(LOWORD(wParam))
		{	case IDC_BUTTON_STOP:
				if(!GetWindowLongPtr(hDlg,GWLP_USERDATA)) return TRUE;
				PostThreadMessage(cpyThrdId,MYWM_STOP,0,0);
				return (INT_PTR)TRUE;
			case IDCANCEL:
				if(!GetWindowLongPtr(hDlg,GWLP_USERDATA)) return TRUE;
				PostThreadMessage(cpyThrdId,MYWM_CANCEL,0,0);
 				DestroyWindow(hDlg);
				dlg = NULL;
				return (INT_PTR)TRUE;
		}
		break;
	}
	return (INT_PTR)FALSE;
}

BOOL ShowCopyDlg()
{
	if(dlg) return FALSE;
	dlg = CreateDialogParam(hInst,MAKEINTRESOURCE(IDD_DIALOG_COPY_BACKGROUND_QUEUE),
                       NULL,(DLGPROC)BckgrndCopyDlgProc,1);
	if(!dlg)Err::fatalExit(L"CreateDialog failed!!!",dlg);
    ShowWindow(dlg,SW_SHOW);
	return TRUE;
}

DWORD CALLBACK bckgrndCpyPrgrssRout(
							LARGE_INTEGER	TotalFileSize,
							LARGE_INTEGER	TotalBytesTransferred,
							LARGE_INTEGER	StreamSize,
							LARGE_INTEGER	StreamBytesTransferred,
							DWORD			dwStreamNumber,
							DWORD			dwCallbackReason,
							HANDLE			hSourceFile,
							HANDLE			hDestinationFile,
							LPVOID			lpData)
{
	cpyTrdDat *pdat = (cpyTrdDat*)lpData;
#define dlg pdat->hDlg
	__int64 tfs = ((__int64)TotalFileSize.HighPart << 32) | TotalFileSize.LowPart;
	__int64 tbt = ((__int64)TotalBytesTransferred.HighPart << 32) | TotalBytesTransferred.LowPart;
	double prgrsPos = tfs?(1000.0*tbt/tfs):1000.0;
	copyedSizes += tbt;
	PostMessage(GetDlgItem(dlg,IDC_PROGRESS_COPY_SINGLE),PBM_SETPOS,(int)prgrsPos,0);
	double prgrsPosTot = tfs?(1000.0*tbt/totSizes):1000.0;
	PostMessage(GetDlgItem(dlg,IDC_PROGRESS_COPY_TOTAL ),PBM_SETPOS,(int)prgrsPosTot,0);

	// ***************** % calculating: ***********************
	wchar_t s[MAX_PATH];StringCchPrintf(s,MAX_PATH,L"%.2f %s",0.1f*prgrsPos,L"%");
	SetDlgItemText(dlg,IDC_STATIC1,s);
	StringCchPrintf(s,MAX_PATH,L"%.2f %s",100.0-0.1*prgrsPos,L"%");
	SetDlgItemText(dlg,IDC_STATIC3,s);
	StringCchPrintf(s,MAX_PATH,L"%.2f %s",tfs?(100.0*tbt/totSizes):100.0,L"%");
	SetDlgItemText(dlg,IDC_STATIC6,s);
	StringCchPrintf(s,MAX_PATH,L"%.2f %s",tfs?(100.0-100.0*tbt/totSizes):100.0,L"%");
	SetDlgItemText(dlg,IDC_STATIC8,s);

	// ***************** tick calculating: ********************
	DWORD tick = GetTickCount() - pdat->beginTick - pdat->stopTick[0];
	MyTimeToString(s, tick);
	SetDlgItemText(pdat->hDlg,IDC_STATIC2,s);
	if(prgrsPos>0.0f)
	{	MyTimeToString(s, (int)(tick*(1000.0f-prgrsPos)/prgrsPos));
		SetDlgItemText(pdat->hDlg,IDC_STATIC4,s);
	}
	
	tick = GetTickCount() - pdat->beginTickTot - pdat->stopTickTot[0];
	MyTimeToString(s, tick);
	SetDlgItemText(pdat->hDlg,IDC_STATIC7,s);
	if(prgrsPosTot>0.0f)
	{	MyTimeToString(s, (int)(tick*(1.0f-0.001f*prgrsPosTot)/(0.001f*prgrsPosTot)));
		SetDlgItemText(pdat->hDlg,IDC_STATIC9,s);
	}



	//message from thread queue:
	MSG msg;
Loop:
	if(PeekMessage(&msg,(HWND)-1,0,0,PM_REMOVE))
	{	
		//static int i=0;
		//wchar_t ss[32];sprintf(ss,L"\n %d ",i++);
		//OutputDebugString(ss);
		//OutputDebugString(GetWinNotifyText(msg.message));
		
		switch(msg.message)
		{	case MYWM_CANCEL:
				return PROGRESS_CANCEL;
			case MYWM_STOP:
				if(pdat->bStop)
				{	LoadString(hInst,IDS_STRINGSW_50,s,MAX_PATH);
					SetDlgItemText(dlg,IDC_BUTTON_STOP,s);
					pdat->stopTick[0] = GetTickCount() - pdat->stopTick[1];
					pdat->stopTickTot[0] = GetTickCount() - pdat->stopTickTot[1];
					pdat->bStop = FALSE;
				}
				else
				{	LoadString(hInst,IDS_STRINGSW_3,s,MAX_PATH);
					SetDlgItemText(dlg,IDC_BUTTON_STOP,s);
					pdat->stopTick[1] = pdat->stopTickTot[1] = GetTickCount();
					pdat->bStop = TRUE;
					Sleep(250);
					goto Loop;
				}
				break;
 	}	}
	else if(pdat->bStop)
	{	Sleep(250);
		goto Loop;
	}

	return PROGRESS_CONTINUE;
#undef dlg
}

INT_PTR CALLBACK CopyFileExistDlgProc(HWND hDlg,UINT message,WPARAM wParam,LPARAM lParam)
{
WIN32_FIND_DATA *pff;
	switch(message)
	{
	case WM_INITDIALOG:
		//Adjust to center:
		RECT rc; GetWindowRect(hDlg, &rc);
		int width,left,height,top;

		width = rc.right - rc.left;
		left = conf::wndLeft + (conf::wndWidth - width)/2;

		height = rc.bottom - rc.top;
		top = conf::wndTop + (conf::wndHeight - height)/2;
		MoveWindow(hDlg, left, top+20, width, height, TRUE);

		wchar_t s[MAX_PATH],s1[MAX_PATH];
		LoadString(hInst,IDS_STRINGSW_52,s,MAX_PATH);
		SetWindowText(hDlg,s);
		LoadString(hInst,IDS_STRINGSW_53,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_STATIC1,s);
		LoadString(hInst,IDS_STRINGSW_54,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_STATIC2,s);
		LoadString(hInst,IDS_STRINGSW_53,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_STATIC3,s);
		LoadString(hInst,IDS_STRINGSW_54,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_STATIC4,s);
		LoadString(hInst,IDS_STRINGSW_55,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_STATIC2,s);
		LoadString(hInst,IDS_STRINGSW_56,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_STATIC6,s);
		LoadString(hInst,IDS_STRINGSW_57,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_STATIC7,s);
		LoadString(hInst,IDS_STRINGSW_58,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_STATIC8,s);
		LoadString(hInst,IDS_STRINGSW_59,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_STATIC9,s);
		LoadString(hInst,IDS_STRINGSW_60,s,MAX_PATH);
		SetDlgItemText(hDlg,IDOK,s);
		MyStringCat(s,MAX_PATH,L" ");
		LoadString(hInst,IDS_STRINGSW_61,s1,MAX_PATH);
		MyStringCat(s,MAX_PATH,s1);
		SetDlgItemText(hDlg,IDOK_ALL,s);
		LoadString(hInst,IDS_STRINGSW_216,s,MAX_PATH);
		SetDlgItemText(hDlg,IDSKIP,s);
		LoadString(hInst,IDS_STRINGSW_61,s1,MAX_PATH);
		MyStringCat(s,MAX_PATH,s1);
		SetDlgItemText(hDlg,IDSKIP_ALL,s);
		LoadString(hInst,IDS_STRINGSW_13,s,MAX_PATH);
		SetDlgItemText(hDlg,IDCANCEL,s);

		LoadString(hInst,IDS_STRINGSW_60,s,MAX_PATH);
		MyStringCat(s,MAX_PATH,L" ");
		LoadString(hInst,IDS_STRINGSW_209,s1,MAX_PATH);
		MyStringCat(s,MAX_PATH,s1);
		SetDlgItemText(hDlg,IDOVERWRITE_OLDEST,s);
		MyStringCat(s,MAX_PATH,L" ");
		LoadString(hInst,IDS_STRINGSW_61,s1,MAX_PATH);
		MyStringCat(s,MAX_PATH,s1);
		SetDlgItemText(hDlg,IDOVERWRITE_OLDEST_ALL,s);

		LoadString(hInst,IDS_STRINGSW_60,s,MAX_PATH);
		MyStringCat(s,MAX_PATH,L" ");
		LoadString(hInst,IDS_STRINGSW_210,s1,MAX_PATH);
		MyStringCat(s,MAX_PATH,s1);
		SetDlgItemText(hDlg,IDOVERWRITE_LATEST,s);
		MyStringCat(s,MAX_PATH,L" ");
		LoadString(hInst,IDS_STRINGSW_61,s1,MAX_PATH);
		MyStringCat(s,MAX_PATH,s1);
		SetDlgItemText(hDlg,IDOVERWRITE_LATEST_ALL,s);

		LoadString(hInst,IDS_STRINGSW_60,s,MAX_PATH);
		MyStringCat(s,MAX_PATH,L" ");
		LoadString(hInst,IDS_STRINGSW_211,s1,MAX_PATH);
		MyStringCat(s,MAX_PATH,s1);
		SetDlgItemText(hDlg,IDOVERWRITE_BIGS,s);
		MyStringCat(s,MAX_PATH,L" ");
		LoadString(hInst,IDS_STRINGSW_61,s1,MAX_PATH);
		MyStringCat(s,MAX_PATH,s1);
		SetDlgItemText(hDlg,IDOVERWRITE_BIGS_ALL,s);

		LoadString(hInst,IDS_STRINGSW_60,s,MAX_PATH);
		MyStringCat(s,MAX_PATH,L" ");
		LoadString(hInst,IDS_STRINGSW_212,s1,MAX_PATH);
		MyStringCat(s,MAX_PATH,s1);
		SetDlgItemText(hDlg,IDOVERWRITE_LITTLES,s);
		MyStringCat(s,MAX_PATH,L" ");
		LoadString(hInst,IDS_STRINGSW_61,s1,MAX_PATH);
		MyStringCat(s,MAX_PATH,s1);
		SetDlgItemText(hDlg,IDOVERWRITE_LITTLES_ALL,s);


		pff = (WIN32_FIND_DATA*)(lParam);
		SetDlgItemText(hDlg,IDC_EDIT_SRC_PATH,pff[0].cFileName);
		SetDlgItemText(hDlg,IDC_EDIT_DEST_PATH,pff[1].cFileName);
		
		unsigned __int64 sz;sz = ((unsigned __int64)pff[0].nFileSizeHigh << 32) | pff[0].nFileSizeLow;
		StringCchPrintf(s,MAX_PATH,L"%d",sz);
		SetDlgItemText(hDlg,IDC_EDIT_SRC_SIZE,s);
		sz = ((unsigned __int64)pff[1].nFileSizeHigh << 32) | pff[1].nFileSizeLow;
		StringCchPrintf(s,MAX_PATH,L"%d",sz);
		SetDlgItemText(hDlg,IDC_EDIT_DEST_SIZE,s);
		
		FILETIME ft;SYSTEMTIME st;
		if(FileTimeToLocalFileTime(&pff[0].ftCreationTime,&ft) != 0)
        {	if(FileTimeToSystemTime(&ft, &st) != 0)
			{	StringCchPrintf(s,MAX_PATH,L"%d.%d.%d  %d:%d:%d",
								st.wDay,st.wMonth,st.wYear,
								st.wHour,st.wMinute,st.wSecond);
				SetDlgItemText(hDlg,IDC_EDIT_SRC_CREATE_TIME,s);
		}	}
		if(FileTimeToLocalFileTime(&pff[1].ftCreationTime,&ft) != 0)
        {	if(FileTimeToSystemTime(&ft, &st) != 0)
			{	StringCchPrintf(s,MAX_PATH,L"%d.%d.%d  %d:%d:%d",
								st.wDay,st.wMonth,st.wYear,
								st.wHour,st.wMinute,st.wSecond);
				SetDlgItemText(hDlg,IDC_EDIT_DEST_CREATE_TIME,s);
		}	}

		if(FileTimeToLocalFileTime(&pff[0].ftLastWriteTime,&ft) != 0)
        {	if(FileTimeToSystemTime(&ft, &st) != 0)
			{	StringCchPrintf(s,MAX_PATH,L"%d.%d.%d  %d:%d:%d",
								st.wDay,st.wMonth,st.wYear,
								st.wHour,st.wMinute,st.wSecond);
				SetDlgItemText(hDlg,IDC_EDIT_SRC_LAST_WRITE_TIME,s);
		}	}
		if(FileTimeToLocalFileTime(&pff[1].ftLastWriteTime,&ft) != 0)
        {	if(FileTimeToSystemTime(&ft, &st) != 0)
			{	StringCchPrintf(s,MAX_PATH,L"%d.%d.%d  %d:%d:%d",
								st.wDay,st.wMonth,st.wYear,
								st.wHour,st.wMinute,st.wSecond);
				SetDlgItemText(hDlg,IDC_EDIT_DEST_LAST_WRITE_TIME,s);
		}	}

		if(FileTimeToLocalFileTime(&pff[0].ftLastAccessTime,&ft) != 0)
        {	if(FileTimeToSystemTime(&ft, &st) != 0)
			{	StringCchPrintf(s,MAX_PATH,L"%d.%d.%d  %d:%d:%d",
								st.wDay,st.wMonth,st.wYear,
								st.wHour,st.wMinute,st.wSecond);
				SetDlgItemText(hDlg,IDC_EDIT_SRC_LAST_ACCESS_TIME,s);
		}	}
		if(FileTimeToLocalFileTime(&pff[1].ftLastAccessTime,&ft) != 0)
        {	if(FileTimeToSystemTime(&ft, &st) != 0)
		{	StringCchPrintf(s,MAX_PATH,L"%d.%d.%d  %d:%d:%d",
								st.wDay,st.wMonth,st.wYear,
								st.wHour,st.wMinute,st.wSecond);
				SetDlgItemText(hDlg,IDC_EDIT_DEST_LAST_ACCESS_TIME,s);
		}	}

		if(FILE_ATTRIBUTE_ARCHIVE==pff[0].dwFileAttributes)
			SetDlgItemText(hDlg,IDC_EDIT_SRC_ATTRIBUTE,L"Archive");
		else if(FILE_ATTRIBUTE_COMPRESSED==pff[0].dwFileAttributes)
			SetDlgItemText(hDlg,IDC_EDIT_SRC_ATTRIBUTE,L"Compressed");
		else if(FILE_ATTRIBUTE_DEVICE==pff[0].dwFileAttributes)
			SetDlgItemText(hDlg,FILE_ATTRIBUTE_DEVICE,L"Device");
		else if(FILE_ATTRIBUTE_DIRECTORY==pff[0].dwFileAttributes)
			SetDlgItemText(hDlg,IDC_EDIT_SRC_ATTRIBUTE,L"Directory");
		else if(FILE_ATTRIBUTE_ENCRYPTED==pff[0].dwFileAttributes)
			SetDlgItemText(hDlg,IDC_EDIT_SRC_ATTRIBUTE,L"Encrypted");
		else if(FILE_ATTRIBUTE_HIDDEN==pff[0].dwFileAttributes)
			SetDlgItemText(hDlg,IDC_EDIT_SRC_ATTRIBUTE,L"Hidden");
		else if(FILE_ATTRIBUTE_NORMAL==pff[0].dwFileAttributes)
			SetDlgItemText(hDlg,IDC_EDIT_SRC_ATTRIBUTE,L"Normal");
		else if(FILE_ATTRIBUTE_NOT_CONTENT_INDEXED==pff[0].dwFileAttributes)
			SetDlgItemText(hDlg,IDC_EDIT_SRC_ATTRIBUTE,L"Not content indexed");
		else if(FILE_ATTRIBUTE_OFFLINE==pff[0].dwFileAttributes)
			SetDlgItemText(hDlg,IDC_EDIT_SRC_ATTRIBUTE,L"Offline");		
		else if(FILE_ATTRIBUTE_READONLY==pff[0].dwFileAttributes)
			SetDlgItemText(hDlg,IDC_EDIT_SRC_ATTRIBUTE,L"Readonly");
		else if(FILE_ATTRIBUTE_REPARSE_POINT==pff[0].dwFileAttributes)
			SetDlgItemText(hDlg,IDC_EDIT_SRC_ATTRIBUTE,L"Reparsepoint");
		else if(FILE_ATTRIBUTE_SPARSE_FILE==pff[0].dwFileAttributes)
			SetDlgItemText(hDlg,IDC_EDIT_SRC_ATTRIBUTE,L"Sparsefile");
		else if(FILE_ATTRIBUTE_SYSTEM==pff[0].dwFileAttributes)
			SetDlgItemText(hDlg,IDC_EDIT_SRC_ATTRIBUTE,L"System");
		else if(FILE_ATTRIBUTE_TEMPORARY==pff[0].dwFileAttributes)
			SetDlgItemText(hDlg,IDC_EDIT_SRC_ATTRIBUTE,L"Temporary");
		else if(FILE_ATTRIBUTE_VIRTUAL==pff[0].dwFileAttributes)
			SetDlgItemText(hDlg,IDC_EDIT_SRC_ATTRIBUTE,L"Virtual");

		if(FILE_ATTRIBUTE_ARCHIVE==pff[1].dwFileAttributes)
			SetDlgItemText(hDlg,IDC_EDIT_SRC_ATTRIBUTE,L"Archive");
		else if(FILE_ATTRIBUTE_COMPRESSED==pff[1].dwFileAttributes)
			SetDlgItemText(hDlg,IDC_EDIT_SRC_ATTRIBUTE,L"Compressed");
		else if(FILE_ATTRIBUTE_DEVICE==pff[1].dwFileAttributes)
			SetDlgItemText(hDlg,FILE_ATTRIBUTE_DEVICE,L"Device");
		else if(FILE_ATTRIBUTE_DIRECTORY==pff[1].dwFileAttributes)
			SetDlgItemText(hDlg,IDC_EDIT_SRC_ATTRIBUTE,L"Directory");
		else if(FILE_ATTRIBUTE_ENCRYPTED==pff[1].dwFileAttributes)
			SetDlgItemText(hDlg,IDC_EDIT_SRC_ATTRIBUTE,L"Encrypted");
		else if(FILE_ATTRIBUTE_HIDDEN==pff[1].dwFileAttributes)
			SetDlgItemText(hDlg,IDC_EDIT_SRC_ATTRIBUTE,L"Hidden");
		else if(FILE_ATTRIBUTE_NORMAL==pff[1].dwFileAttributes)
			SetDlgItemText(hDlg,IDC_EDIT_SRC_ATTRIBUTE,L"Normal");
		else if(FILE_ATTRIBUTE_NOT_CONTENT_INDEXED==pff[1].dwFileAttributes)
			SetDlgItemText(hDlg,IDC_EDIT_SRC_ATTRIBUTE,L"Not content indexed");
		else if(FILE_ATTRIBUTE_OFFLINE==pff[1].dwFileAttributes)
			SetDlgItemText(hDlg,IDC_EDIT_SRC_ATTRIBUTE,L"Offline");		
		else if(FILE_ATTRIBUTE_READONLY==pff[1].dwFileAttributes)
			SetDlgItemText(hDlg,IDC_EDIT_SRC_ATTRIBUTE,L"Readonly");
		else if(FILE_ATTRIBUTE_REPARSE_POINT==pff[1].dwFileAttributes)
			SetDlgItemText(hDlg,IDC_EDIT_SRC_ATTRIBUTE,L"Reparsepoint");
		else if(FILE_ATTRIBUTE_SPARSE_FILE==pff[1].dwFileAttributes)
			SetDlgItemText(hDlg,IDC_EDIT_SRC_ATTRIBUTE,L"Sparsefile");
		else if(FILE_ATTRIBUTE_SYSTEM==pff[1].dwFileAttributes)
			SetDlgItemText(hDlg,IDC_EDIT_SRC_ATTRIBUTE,L"System");
		else if(FILE_ATTRIBUTE_TEMPORARY==pff[1].dwFileAttributes)
			SetDlgItemText(hDlg,IDC_EDIT_SRC_ATTRIBUTE,L"Temporary");
		else if(FILE_ATTRIBUTE_VIRTUAL==pff[1].dwFileAttributes)
			SetDlgItemText(hDlg,IDC_EDIT_SRC_ATTRIBUTE,L"Virtual");

		return TRUE;
	//case WM_DESTROY:
	//	return TRUE;
	case WM_COMMAND:
		switch(LOWORD(wParam))
		{	case IDOK:
				EndDialog(hDlg,overwrite);
				return (INT_PTR)TRUE;
			case IDOK_ALL:
				EndDialog(hDlg,overwriteAll);
				return (INT_PTR)TRUE;
			case IDCANCEL:
				EndDialog(hDlg,cancel);
				return (INT_PTR)TRUE;
			case IDSKIP_ALL:
				EndDialog(hDlg,skipAll);
				return (INT_PTR)TRUE;
			case IDRENAME:
				EndDialog(hDlg,rename1);
				return (INT_PTR)TRUE;
			case IDRENAME_ALL:
				EndDialog(hDlg,renameAll);
				return (INT_PTR)TRUE;
			case IDOVERWRITE_OLDEST_ALL:
				EndDialog(hDlg,overwriteOldestAll);
				return (INT_PTR)TRUE;
			case IDOVERWRITE_OLDEST:
				EndDialog(hDlg,overwriteOldest);
				return (INT_PTR)TRUE;
			case IDOVERWRITE_LATEST_ALL:
				EndDialog(hDlg,overwriteLatestAll);
				return (INT_PTR)TRUE;
			case IDOVERWRITE_LATEST:
				EndDialog(hDlg,overwriteLatest);
				return (INT_PTR)TRUE;
			case IDOVERWRITE_BIGS_ALL:
				EndDialog(hDlg,overwriteBigestAll);
				return (INT_PTR)TRUE;
			case IDOVERWRITE_BIGS:
				EndDialog(hDlg,overwriteBigest);
				return (INT_PTR)TRUE;
			case IDOVERWRITE_LITTLES_ALL:
				EndDialog(hDlg,overwriteLittlestAll);
				return (INT_PTR)TRUE;
			case IDOVERWRITE_LITTLES:
				EndDialog(hDlg,overwriteLittlest);
				return (INT_PTR)TRUE;
		}
		break;
	}
	return (INT_PTR)FALSE;
}

int CheckCopyFilesToExisting(HWND prnt, wchar_t *fromFilePathAndName,
							 wchar_t *toFilePathAndName)
{
WIN32_FIND_DATA ff[2];
HANDLE			hf = INVALID_HANDLE_VALUE;
static wchar_t buf[MAX_PATH];

	ZeroMemory(&ff[1],sizeof(WIN32_FIND_DATA));
	hf = FindFirstFile(toFilePathAndName, &ff[0]);
	if(INVALID_HANDLE_VALUE==hf) return overwrite;
	FindClose(hf);

	ZeroMemory(&ff[1],sizeof(WIN32_FIND_DATA));
	hf = FindFirstFile(fromFilePathAndName, &ff[1]);
	if(INVALID_HANDLE_VALUE==hf) return overwrite;
	FindClose(hf);

	if(skipAll==enCheckCopyFilesToExisting)
		return skipAll;
	else if(overwriteAll==enCheckCopyFilesToExisting)
		return overwriteAll;
	else if(renameAll==enCheckCopyFilesToExisting)
		return renameAll;
	else if(overwriteOldestAll==enCheckCopyFilesToExisting)
		return overwriteOldestAll;
	else if(overwriteLatestAll==enCheckCopyFilesToExisting)
		return overwriteLatestAll;
	else if(overwriteBigestAll==enCheckCopyFilesToExisting)
		return overwriteBigestAll;
	else if(overwriteLittlestAll==enCheckCopyFilesToExisting)
		return overwriteLittlestAll;

/*	ZeroMemory(&ff[1],sizeof(WIN32_FIND_DATA));
	hf = FindFirstFile(toFilePathAndName, &ff[0]);
	if(INVALID_HANDLE_VALUE==hf) return overwrite;
	FindClose(hf);

	ZeroMemory(&ff[1],sizeof(WIN32_FIND_DATA));
	hf = FindFirstFile(fromFilePathAndName, &ff[1]);
	if(INVALID_HANDLE_VALUE==hf) return overwrite;
	FindClose(hf);*/

	if(0==ff[0].nFileSizeLow)if(0==ff[0].nFileSizeHigh)
	if(0!=ff[1].nFileSizeLow ||	0!=ff[1].nFileSizeHigh)
		return overwrite;

	if(0==ff[1].nFileSizeLow)if(0==ff[1].nFileSizeHigh)
	if(0!=ff[0].nFileSizeLow ||	0!=ff[0].nFileSizeHigh)
		return overwrite;

	StringCchPrintf(ff[0].cFileName,260,fromFilePathAndName);
	StringCchPrintf(ff[1].cFileName,260,toFilePathAndName);
	return (int)DialogBoxParam(hInst,MAKEINTRESOURCE(IDD_COPY_FILE_EXIST),
		   				       prnt,CopyFileExistDlgProc,(LPARAM)ff);
}

VOID bckgrndCpyFileExThrdFnc(LPVOID lpar)
{
cpyTrdDat dat; dat.hDlg = (HWND)lpar;
	dat.bStop = FALSE;
	dat.bCancel = FALSE;
	dat.bSwtchToBckgrnd = FALSE;
	dat.thrId = GetCurrentThreadId();
	dat.beginTick = dat.beginTickTot = GetTickCount();
	dat.stopTick[0] = dat.stopTickTot[0] = 0;
	enCheckCopyFilesToExisting = showEach;

HWND ed1 = GetDlgItem(dat.hDlg,IDC_EDIT_COPY_BCKGRND_QUEUE);
HWND ed2 = GetDlgItem(dat.hDlg,IDC_EDIT_COPY_BCKGRND_QUEUE2);
	Err::AssertFatal(edt1 && edt2,L"Err. gettting bck.cpy dialog edit control!");

 int cnt=0;BOOL bSkipAll=FALSE;
 for(;;)
 {EnterCriticalSection(&critSect);
  int totalItems = (int)SendMessage(ed1,EM_GETLINECOUNT,0,0);
  if(totalItems < SendMessage(ed2,EM_GETLINECOUNT,0,0))
	totalItems = (int)SendMessage(ed2,EM_GETLINECOUNT,0,0);
  LeaveCriticalSection(&critSect);

  wchar_t txt1[255];WORD *pw = (WORD*)txt1; *pw = 255;
  int l1 = (int)SendMessage(ed1,EM_GETLINE,0,(LPARAM)txt1);
  wchar_t txt2[255];pw = (WORD*)txt2; *pw = 255;
  int l2 = (int)SendMessage(ed2,EM_GETLINE,0,(LPARAM)txt2);
  //Selecting first line:**************************************************
  //SendMessage(ed1,EM_SETSEL,0,l1+2);SendMessage(ed2,EM_SETSEL,0,l2+2);

  if(!l1)if(!l2) break;//oxiri;
  txt1[l1] = 0; txt2[l2] = 0;
  if(!l1)
  {
LoopCreate:
   if(!MyCreateDirectory(txt2,NULL) && (!bSkipAll))
   {	LPVOID* par[2]={(LPVOID*)GetLastError(),(LPVOID*)txt2};
		int r = (int)DialogBoxParam(hInst,MAKEINTRESOURCE(IDD_DIALOG_CHOISE_ACTION),dat.hDlg,fDelOper::actnDlgProc,(LPARAM)par);
		if(0==r) goto End;//Cancel action;
		if(1==r) goto LoopCreate;
		if(3==r)
			bSkipAll=TRUE;//2-skip,3-skipAll;
  }}
  else
  {	if(!wcscmp(txt1,txt2))
    {	LoadString(hInst,IDS_STRINGSW_51,txt1,MAX_PATH);
		MessageBox(NULL,txt1,L"Err.",MB_OK);
    }
    else
	{int r=CheckCopyFilesToExisting(dat.hDlg,txt1,txt2);
	 if(r==skipAll || r==skip)
     	goto skipOne;
	 else if(r==cancel)
     	goto End;
	 else if(r==overwrite || r==overwriteAll)
     {
LoopCopy:
	  if(!MyCopyFileEx(txt1,txt2,bckgrndCpyPrgrssRout,&dat,FALSE,0) && (!bSkipAll))
	  {	LPVOID* par[3]={(LPVOID*)GetLastError(),(LPVOID*)txt1,(LPVOID*)txt2};
		int r = (int)DialogBoxParam(hInst,MAKEINTRESOURCE(IDD_DIALOG_CHOISE_ACTION),dat.hDlg,fDelOper::actnDlgProc1,(LPARAM)par);
		if(0==r) goto End;//Cancel action;
		if(1==r) goto LoopCopy;
		if(3==r)
			bSkipAll=TRUE;//2-skip,3-skipAll;
	 }}
     else if(r==rename1 || r==renameAll)
     {
LoopRename:
	  if(!MyCopyRenameFileEx(txt1,txt2,bckgrndCpyPrgrssRout,&dat,FALSE,0) && (!bSkipAll))
	  {	LPVOID* par[3]={(LPVOID*)GetLastError(),(LPVOID*)txt1,(LPVOID*)txt2};
		int r = (int)DialogBoxParam(hInst,MAKEINTRESOURCE(IDD_DIALOG_CHOISE_ACTION),dat.hDlg,fDelOper::actnDlgProc1,(LPARAM)par);
		if(0==r) goto End;//Cancel action;
		if(1==r) goto LoopRename;
		if(3==r)
			bSkipAll=TRUE;//2-skip,3-skipAll;
	 }}
     else if(r==overwriteOldest || r==overwriteOldestAll)
     {
LoopOverOldest:
	  if(!MyCopyOverwriteOldestFileEx(txt1,txt2,bckgrndCpyPrgrssRout,&dat,FALSE,0) && (!bSkipAll))
	  {	LPVOID* par[3]={(LPVOID*)GetLastError(),(LPVOID*)txt1,(LPVOID*)txt2};
		int r = (int)DialogBoxParam(hInst,MAKEINTRESOURCE(IDD_DIALOG_CHOISE_ACTION),dat.hDlg,fDelOper::actnDlgProc1,(LPARAM)par);
		if(0==r) goto End;//Cancel action;
		if(1==r) goto LoopOverOldest;
		if(3==r)
			bSkipAll=TRUE;//2-skip,3-skipAll;
	 }}
     else if(r==overwriteLatest || r==overwriteLatestAll)
     {
LoopOverLatest:
	  if(!MyCopyOverwriteLatestFileEx(txt1,txt2,bckgrndCpyPrgrssRout,&dat,FALSE,0) && (!bSkipAll))
	  {	LPVOID* par[3]={(LPVOID*)GetLastError(),(LPVOID*)txt1,(LPVOID*)txt2};
		int r = (int)DialogBoxParam(hInst,MAKEINTRESOURCE(IDD_DIALOG_CHOISE_ACTION),dat.hDlg,fDelOper::actnDlgProc1,(LPARAM)par);
		if(0==r) goto End;//Cancel action;
		if(1==r) goto LoopOverLatest;
		if(3==r)
			bSkipAll=TRUE;//2-skip,3-skipAll;
	 }}
     else if(r==overwriteBigest || r==overwriteBigestAll)
     {
LoopOverBigest:
	  if(!MyCopyOverwriteBigestFileEx(txt1,txt2,bckgrndCpyPrgrssRout,&dat,FALSE,0) && (!bSkipAll))
	  {	LPVOID* par[3]={(LPVOID*)GetLastError(),(LPVOID*)txt1,(LPVOID*)txt2};
		int r = (int)DialogBoxParam(hInst,MAKEINTRESOURCE(IDD_DIALOG_CHOISE_ACTION),dat.hDlg,fDelOper::actnDlgProc1,(LPARAM)par);
		if(0==r) goto End;//Cancel action;
		if(1==r) goto LoopOverBigest;
		if(3==r)
			bSkipAll=TRUE;//2-skip,3-skipAll;
	 }}
     else if(r==overwriteLittlest || r==overwriteLittlestAll)
     {
LoopOverLittlest:
	  if(!MyCopyOverwriteLittlestFileEx(txt1,txt2,bckgrndCpyPrgrssRout,&dat,FALSE,0) && (!bSkipAll))
	  {	LPVOID* par[3]={(LPVOID*)GetLastError(),(LPVOID*)txt1,(LPVOID*)txt2};
		int r = (int)DialogBoxParam(hInst,MAKEINTRESOURCE(IDD_DIALOG_CHOISE_ACTION),dat.hDlg,fDelOper::actnDlgProc1,(LPARAM)par);
		if(0==r) goto End;//Cancel action;
		if(1==r) goto LoopOverLittlest;
		if(3==r)
			bSkipAll=TRUE;//2-skip,3-skipAll;
	}}}

skipOne:
	PostMessage(GetDlgItem(dat.hDlg,IDC_PROGRESS_COPY_SINGLE),PBM_SETPOS,1000,0);
	PostMessage(GetDlgItem(dat.hDlg,IDC_PROGRESS_COPY_TOTAL ),PBM_SETPOS,
    (int)(1000.0f*(copyedSizes)/totSizes),0);
  }
  
  //Delete line from edits:
  EnterCriticalSection(&critSect);
  SendMessage(ed1,EM_SETSEL,0,l1+2);SendMessage(ed2,EM_SETSEL,0,l2+2);
  SendMessage(ed1,WM_CLEAR,0,0);SendMessage(ed2,WM_CLEAR,0,0);

  //Selecting first line:**************************************************
  //pw = (WORD*)txt1; *pw = 255;											//*
  //l1 = SendMessage(ed1,EM_GETLINE,0,(LPARAM)txt1);						//*
  //pw = (WORD*)txt2; *pw = 255;											//*
  //l2 = SendMessage(ed2,EM_GETLINE,0,(LPARAM)txt2);						//*
  //SendMessage(ed1,EM_SETSEL,0,l1+2);SendMessage(ed2,EM_SETSEL,0,l2+2);	//*

  LeaveCriticalSection(&critSect);

Loop:
	MSG msg;//Only thread message:
	if(PeekMessage(&msg,(HWND)-1,0,0,PM_REMOVE))
	{	
		
		//static int i=0;
		//wchar_t ss[32];sprintf(ss,L"\n %d ",i++);
		//OutputDebugString(ss);
		//OutputDebugString(GetWinNotifyText(msg.message));
		
		switch(msg.message)
		{	//case MYWM_CANCEL:
				//dat.bCancel = TRUE;
			//	goto End;
			case MYWM_STOP:
				wchar_t s[MAX_PATH];
				if(dat.bStop)
				{	LoadString(hInst,IDS_STRINGSW_50,s,MAX_PATH);
					SetDlgItemText(dat.hDlg,IDC_BUTTON_STOP,s);
					dat.bStop = FALSE;
				}
				else
				{	LoadString(hInst,IDS_STRINGSW_3,s,MAX_PATH);
					SetDlgItemText(dat.hDlg,IDC_BUTTON_STOP,s);
					dat.bStop = TRUE;
					Sleep(250);
					goto Loop;
				}
				break;
 	}	}
	else if(dat.bStop)
	{	Sleep(250);
		goto Loop;
}	}
End:
 SendMessage(dat.hDlg,WM_USER,1,0);//Destroy wia EndDialog, end zero dlg(0)
 //if(dat.stack) free(dat.stack);
 ExitThread(0);
#undef dlg
}

BOOL AddToQueueFrCopyOperation()
{
	BOOL r = ShowCopyDlg();
	if(r)// CreateThread:
	{	totSizes = 0;
		copyedSizes = 0;
		CreateThread(NULL,1024,(LPTHREAD_START_ROUTINE)bckgrndCpyFileExThrdFnc,
					 dlg,0,&cpyThrdId);
	}
	EnterCriticalSection(&critSect);
	totSizes += fCopyOper::GetSelectedFilesToDlg(GetDlgItem(dlg,IDC_EDIT_COPY_BCKGRND_QUEUE),
									GetDlgItem(dlg,IDC_EDIT_COPY_BCKGRND_QUEUE2));
	LeaveCriticalSection(&critSect);
	return TRUE;
}

}//end of namespace