#include "VirtualPanel.h"
#include "strsafe.h"
#include "..\Operations\MyErrors.h"
#include "..\Operations\Execution.h"
#include "..\Operations\MyShell\MyShell.h"
#include "..\config.h"
#include "..\Sino.h"
#include <locale.h>
#include <Psapi.h>




namespace vrtlPanels
{

int numPlugins,	numIP4Plgn;
CVirtPnlPlgn *plgns=NULL;

BOOL AttachPanel$12(LPVOID panel,int iplg,wchar_t *path)
{
LPVOID plgObj=0;
	if(iplg<0) return FALSE;
	if(iplg>numPlugins-1) return FALSE;
BEGIN_TRY
	if(plgns[iplg].LoadPlugin())
	{	plgObj=plgns[iplg].AttachPanel$12(((Panel*)panel)->GetHWND(),panel,path);
		if(!plgObj)
			plgns[iplg].FreePlugin();
	}
END_TRY
{	
	plgObj=FALSE;
}
	if(plgObj)
	{	if(plgns[iplg].EnumDir$12 && plgns[iplg].GetReadyForEnumDir$12(((Panel*)panel)->GetHWND(),plgObj,path))
		{	((Panel*)panel)->SetVirtual(path,plgObj,iplg);
			if(!plgns[iplg].EnumDir$12(((Panel*)panel)->GetHWND(),plgObj,path))
				return FALSE;
			((Panel*)panel)->AdjustScrollity();
			((Panel*)panel)->Sort();
			((Panel*)panel)->ShowPathAndName(0);
			((Panel*)panel)->SetFocus();
		}
		else
		{	MessageBox(((Panel*)panel)->GetHWND(),L"EnumDir$12 not allowed for path:",path,MB_OK);
			plgns[iplg].DetachPanel$8(plgObj,panel);
			plgns[iplg].FreePlugin();
			((Panel*)panel)->ShowPathAndName(0);
			return FALSE;
	}	}
return plgObj?TRUE:FALSE;
}

VOID ListVirtPnlDirLoadPlugins(wchar_t *path)
{
WIN32_FIND_DATA ff;
HANDLE hf = INVALID_HANDLE_VALUE;
wchar_t s[MAX_PATH];
	int l=MyStringCpy(s,MAX_PATH-1,path);
	if(MyStringRemoveLastCharCheckPre(s,MAX_PATH-1,'*','\\'))
		--l;

	hf = MyFindFirstFileEx(path,FindExInfoStandard,&ff,FindExSearchLimitToDirectories,NULL,0);
	do
	{	if(INVALID_HANDLE_VALUE==hf) return;
		if(FILE_ATTRIBUTE_DIRECTORY & ff.dwFileAttributes)//if(IsDirectory(path, &ff, FALSE))
		{	if(IsCrntOrPrntDirAttrb(ff.cFileName))
			{	int n=MyStringCpy(&s[l],MAX_PATH-1,ff.cFileName);
				MyStringCpy(&s[l+n],MAX_PATH-1-l,L"\\*");
				ListVirtPnlDirLoadPlugins(s);
		}	}
		else
			TryLoadPlugin(s,ff.cFileName,l);
	}
	while(FindNextFile(hf, &ff));
	FindClose(hf);
}

VOID FreePlugins()//CArch::~CArch ga qara, ochiq qolib ketgan arxivlar qoladur;
{
	//free(plgns);
	//plgns=NULL;
	//numPlugins=0;
	for(int p=0; p<conf::Dlg.iTotPanels; p++)
	{	while(virtualPanel==panel[p].GetEntry()->GetCrntRecType())
		{	panel[p].FolderUp(0);
}	}	}

VOID LoadPlugins(HWND wnd)
{
	numPlugins=0;
	numIP4Plgn = -1;
	wchar_t *vrtPnlPlgPth = MyStringAddModulePath(L"Plugins\\Virtual panel\\*");
	ListVirtPnlDirLoadPlugins(vrtPnlPlgPth);
	SetMenusInStartup(wnd);
}

BOOL AttachFromName(LPVOID panel,wchar_t *name,wchar_t* path)
{
wchar_t *pname=wcsrchr(name,'\\');if(pname)++pname;else pname=name;
int ln=MyStringLength(pname,MAX_PATH);
	for(int i=0; i<numPlugins; i++)
	{wchar_t *p=wcsrchr(plgns[i].pathAndName,'\\');if(p)++p;else p=&plgns[i].pathAndName[0];
	 int l=MyStringLength(p,MAX_PATH);
	 if(l!=ln)continue;
	 if(0==_wcsnicmp(pname,p,l))
	 {	if(i==numIP4Plgn)
		{if(path[0]>='0' && path[0]<='9')
		 {wchar_t s[64]=L"\\\\?\\UNC\\";
	      int l=9+MyStringCpy(&s[9],53,path);
		  s[l++]='\\';s[l++]='*';s[l]=0;
		  AttachPanel$12(panel,i,s);
	     }
		 else AttachPanel$12(panel,i,L"");//\\\\?\\UNC\\*");
	    }
		else AttachPanel$12(panel,i,path);
		return TRUE;
	}}
	return FALSE;
}

VOID TryLoadPlugin(wchar_t *pth,wchar_t* name,int l)
{//LoadLibrary da exception beradur;
	if(numPlugins>conf::Dlg.totalAllovedArchvr * 5)
	{	Err::msg(hWnd,0,L"There are any virtual panel plugins(above 100), ignore others...");
		return;
	}

	MyStringCpy(&pth[l],MAX_PATH-1,name);

	if(!Execution::IsThisValidDllFile(pth))
		return;

BEGIN_TRY


HMODULE hm = LoadLibraryEx(pth,NULL,DONT_RESOLVE_DLL_REFERENCES);
	if(!hm)
	{	//Err::msg(hWnd,-1,pth);
		return;
	}

	typedef BOOL (*ProcessView$4_t)(wchar_t*);
	/*Load$24_t Load$24 = (Load$24_t)GetProcAddress(hm,"Load$24");
	if(!Load$24)
	{	Err::msg(0,-1,L"Load$24 procedure is not founded.");
Fall:	FreeLibrary(hm);
		return;
	}*/
	GetPluginType_t GetPluginType = (GetPluginType_t)GetProcAddress(hm,"GetPluginType");
	if(!GetPluginType) goto Fall;
	SetCallbacks$4xxx_t SetCallbacks$4xxx = (SetCallbacks$4xxx_t)GetProcAddress(hm,"SetCallbacks$4xxx");
	if(!SetCallbacks$4xxx) goto Fall;
	GetPluginDescription_t GetPluginDescription = (GetPluginDescription_t)GetProcAddress(hm,"GetPluginDescription");
	if(!GetPluginDescription) goto Fall;
	GetPluginName_t GetPluginName = (GetPluginName_t)GetProcAddress(hm,"GetPluginName");
	if(!GetPluginName) goto Fall;
	ShowOptionDialog_t ShowOptionDialog = (ShowOptionDialog_t)GetProcAddress(hm,"ShowOptionDialog");
	if(!ShowOptionDialog) goto Fall;
	SetId$4_t SetId$4 = (SetId$4_t)GetProcAddress(hm,"SetId$4");
	if(!SetId$4) goto Fall;
	AttachPanel$12_t AttachPanel$12 = (AttachPanel$12_t)GetProcAddress(hm,"AttachPanel$12");
	if(!AttachPanel$12) goto Fall;
	EnumDir$12_t EnumDir$12 = (EnumDir$12_t)GetProcAddress(hm,"EnumDir$12");
	if(!EnumDir$12) goto Fall;
	DetachPanel$8_t  DetachPanel$8 = (DetachPanel$8_t)GetProcAddress(hm,"DetachPanel$8");
	if(!DetachPanel$8) goto Fall;
	GetItemPathAndName$16_t GetItemPathAndName$16 = (GetItemPathAndName$16_t)GetProcAddress(hm,"GetItemPathAndName$16");
	if(!GetItemPathAndName$16) goto Fall;

	FreeLibrary(hm);
	hm = LoadLibrary(pth);//DllMain ni yuklasin, endi;
	if(!hm) return;
	GetPluginType = (GetPluginType_t)GetProcAddress(hm,"GetPluginType");
	SetCallbacks$4xxx = (SetCallbacks$4xxx_t)GetProcAddress(hm,"SetCallbacks$4xxx");
	GetPluginDescription = (GetPluginDescription_t)GetProcAddress(hm,"GetPluginDescription");
	GetPluginName = (GetPluginName_t)GetProcAddress(hm,"GetPluginName");
	ShowOptionDialog = (ShowOptionDialog_t)GetProcAddress(hm,"ShowOptionDialog");
	SetId$4 = (SetId$4_t)GetProcAddress(hm,"SetId$4");
	AttachPanel$12 = (AttachPanel$12_t)GetProcAddress(hm,"AttachPanel$12");
	EnumDir$12 = (EnumDir$12_t)GetProcAddress(hm,"EnumDir$12");
	GetReadyForEnumDir$12_t GetReadyForEnumDir$12 = (GetReadyForEnumDir$12_t)GetProcAddress(hm,"GetReadyForEnumDir$12");
	DetachPanel$8 = (DetachPanel$8_t)GetProcAddress(hm,"DetachPanel$8");
	GetItemPathAndName$16 = (GetItemPathAndName$16_t)GetProcAddress(hm,"GetItemPathAndName$16");
	ShowSearchDlg$20_t ShowSearchDlg$20 = (ShowSearchDlg$20_t)GetProcAddress(hm,"ShowSearchDlg$20");

	EventPanelResizing$8_t EventPanelResizing$8 = (EventPanelResizing$8_t)GetProcAddress(hm,"EventPanelResizing$8");
	//EventPanelItemClick$16_t  EventPanelItemClick$16 = (EventPanelItemClick$16_t)GetProcAddress(hm,"EventPanelItemClick$16");
	//EventPanelReady$8_t EventPanelReady$8 = (EventPanelReady$8_t)GetProcAddress(hm,"EventPanelReady$8");

	int t=GetPluginType();
	if(t!=402)// goto Fall;
	{	Err::msg(0,-1,L"Load$24 procedure is not founded.");
Fall:	FreeLibrary(hm);
		return;
	}
	MODULEINFO mi;
	GetModuleInformation(GetCurrentProcess(),hm,&mi,sizeof(mi));

	if(!plgns) plgns = (CVirtPnlPlgn*)malloc((numPlugins+1)*sizeof(CVirtPnlPlgn));
	else  plgns = (CVirtPnlPlgn*)realloc(plgns,(numPlugins+1)*sizeof(CVirtPnlPlgn));
	plgns[numPlugins].CVirtPnlPlgn::CVirtPnlPlgn();
	plgns[numPlugins].GetPluginType = GetPluginType;
	plgns[numPlugins].SetCallbacks$4xxx = SetCallbacks$4xxx;
	plgns[numPlugins].GetPluginDescription = GetPluginDescription;
	plgns[numPlugins].SetId$4 = SetId$4;
	plgns[numPlugins].GetPluginName = GetPluginName;

	plgns[numPlugins].AttachPanel$12 = AttachPanel$12;
	plgns[numPlugins].EnumDir$12 = EnumDir$12;
	plgns[numPlugins].GetReadyForEnumDir$12 = GetReadyForEnumDir$12;
	plgns[numPlugins].DetachPanel$8 = DetachPanel$8;
	plgns[numPlugins].GetItemPathAndName$16 =  GetItemPathAndName$16;
	plgns[numPlugins].ShowSearchDlg$20 = ShowSearchDlg$20;

	plgns[numPlugins].EventPanelResizing$8 = EventPanelResizing$8;
	//plgns[numPlugins].EventPanelItemClick$16 = EventPanelItemClick$16;
	//plgns[numPlugins].EventPanelReady$8 = EventPanelReady$8;

	plgns[numPlugins].type = t;
	if(GetPluginDescription)MyStringCpy(plgns[numPlugins].descrpn,MAX_PATH,(wchar_t*)GetPluginDescription());
	else plgns[numPlugins].descrpn[0]=0;
	if(GetPluginName)MyStringCpy(plgns[numPlugins].name,MAX_PATH,(wchar_t*)GetPluginName());
	else plgns[numPlugins].name[0]=0;
	SetCallbacks$4xxx(	CVirtPnlPlgn::saveOptions,
						CVirtPnlPlgn::readOptions,
						CVirtPnlPlgn::addItemToPanelList,
						CVirtPnlPlgn::changeItemInPanelList,
						CVirtPnlPlgn::closeEvent,
						CVirtPnlPlgn::setPanelPath
						//CVirtPnlPlgn::render,
						//CVirtPnlPlgn::freePanel,
						//CVirtPnlPlgn::selectItem
						);
	MyStringCpy(plgns[numPlugins].pathAndName,MAX_PATH-1,pth);
	plgns[numPlugins].idNum = numPlugins;
	plgns[numPlugins].SetId$4(numPlugins);

	if(0==wcscmp(plgns[numPlugins].name,L"AdptrIP4Scan"))
		numIP4Plgn = numPlugins;
	//plgns[numPlugins].FreePlugin();

	++numPlugins;
END_TRY
{
	Err::msg1(NULL,0,pth,L"Err.loading virtual panel plgn.");
}}

BOOL EventPanelResizing$8(HWND prnt,int iplg,LPVOID plgObj)
{
	if(!plgObj) return FALSE;
	if(iplg<0) return FALSE;
	if(iplg>numPlugins-1) return FALSE;
	if(!plgns[iplg].EventPanelResizing$8) return FALSE;
BEGIN_TRY
	return plgns[iplg].EventPanelResizing$8(prnt,plgObj);
END_TRY
{	Err::msg(NULL,0,L"Err.EventPanelResizing$8 virtual panel plgn.");
	return FALSE;
}}

/*BOOL EventPanelItemClick$16(HWND prnt,int iplg,LPVOID plgObj,int itemId,wchar_t *itemName)
{
	if(!plgObj) return FALSE;
	if(iplg<0) return FALSE;
	if(iplg>numPlugins-1) return FALSE;
	if(!plgns[iplg].EventPanelItemClick$16) return FALSE;
BEGIN_TRY
	return plgns[iplg].EventPanelItemClick$16(prnt,plgObj,itemId,itemName);
END_TRY
{	Err::msg(NULL,0,L"Err.EventPanelItemClick$16 virtual panel plgn.");
	return FALSE;
}}*/

/*BOOL EventPanelReady$8(HWND prnt,int iplg,LPVOID plgObj)
{
	if(!plgObj) return FALSE;
	if(iplg<0) return FALSE;
	if(iplg>numPlugins-1) return FALSE;
	if(!plgns[iplg].EventPanelReady$8) return FALSE;
BEGIN_TRY
	plgns[iplg].EventPanelReady$8(prnt,plgObj);
	return TRUE;
END_TRY
{	Err::msg(NULL,0,L"Err.EventPanelReady$8 virtual panel plgn.");
	return FALSE;
}}*/

BOOL SetMenusInStartup(HWND hWnd)
{
wchar_t st[MAX_PATH];
HMENU virtPnlMnu=NULL;
MENUITEMINFO mi; mi.cbSize = sizeof(MENUITEMINFO);
	mi.fMask=MIIM_STRING; mi.fType=MFT_STRING;mi.dwTypeData=&st[0];
		
	//Setup menu items:
	HMENU hm = GetMenu(hWnd);
	if(!hm) return FALSE;
	int vrtlPnlMnuNum=-1,cItems = GetMenuItemCount(hm);
	if(cItems<1 || cItems>100) return FALSE;

	for(int i=0; i<cItems; i++)
	{	mi.cch=MAX_PATH-1;
		GetMenuItemInfo(hm,i,TRUE,&mi);
		if(!wcscmp(st,L"Virtual panel"))
		{	virtPnlMnu = GetSubMenu(hm,i);// 0 bo'larkan menu pustoy bo'lsa, hecha bo'lmasa separator qo'y;
			if(!virtPnlMnu) return NULL;
			LoadString(hInst,IDS_STRINGSW_292,st,MAX_PATH-1);
			mi.dwTypeData = &st[0];
			if(!SetMenuItemInfo(hm,i,TRUE,&mi))
				Err::msg(hWnd,-1,L"SetMenuItemInfo");
			break;
	}	}

	int iApndMnu=0;
	mi.fMask=MIIM_STRING|MIIM_ID;
	for(int p=0; p<numPlugins; p++)
	{	StringCchPrintf(st,MAX_PATH-1,L"%s...plugin",plgns[p].name);
		mi.dwTypeData = st;
		mi.wID = 0x0fff-(iApndMnu++);//0xffff-(iApndMnu++); ->menuUtils niki;
		InsertMenuItem(virtPnlMnu,0,TRUE,&mi);
		plgns[p].mnuIdNum = mi.wID;
	}
	return TRUE;
}

BOOL IsKeyExist(int k)
{
BOOL r=FALSE;
	for(int i=0; i<numPlugins; i++)
	{	if(i==k)continue;
		if(plgns[i].key.key==plgns[k].key.key)
		if(plgns[i].key.bCtrl==plgns[k].key.bCtrl)
		if(plgns[i].key.bAlt==plgns[k].key.bAlt)
		if(plgns[i].key.bShft==plgns[k].key.bShft)
			return TRUE;
	}
	return FALSE;
}

BOOL IsExistAny()
{	for(int i=0; i<conf::Dlg.iTotPanels; i++)
	{	if(virtualPanel==panel[i].GetEntry()->GetCrntRecType())
			return TRUE;
	}
	return FALSE;
}

BOOL CheckKeys(conf::STKey *key,Panel *pnl)
{
	for(int i=0; i<numPlugins; i++)
	{	if(plgns[i].key.key==key->key)
		if(plgns[i].key.bCtrl==key->bCtrl)
		if(plgns[i].key.bAlt==key->bAlt)
		if(plgns[i].key.bShft==key->bShft)
		{	if(plgns[i].AttachPanel$12(pnl->GetHWND(),pnl,L""))
			{	return TRUE;
	}	}	}
	return FALSE;
}

BOOL CheckFromMenuId(HWND wnd,WPARAM wParam,Panel* pnl)
{	
	wchar_t s[128];//MENUITEMINFO mi;mi.cbSize=sizeof(mi);mi.fMask=MIIM_STRING;
			   //   		  mi.fType=MFT_STRING;mi.dwTypeData=s;
HMENU hm = GetMenu(wnd);
	wParam &= 0x0fff;//only loword
	for(int i=0; i<numPlugins; i++)
	{	if(plgns[i].mnuIdNum==wParam)
		{	//HMENU sm=GetSubMenu(hm,plgns[i].mnuPos);
			GetMenuString(hm,(UINT)wParam,s,127,MF_BYCOMMAND);//GetMenuItemInfo(sm,wParam,FALSE,&mi);
			wchar_t *p=wcsstr(s,L"...plugin");
			if(p)(*p)=0;
			if(0==wcscmp(s,plgns[i].name))
			{	if(AttachPanel$12(pnl,i,L""))
				{	
				}
				return TRUE;
	}	}	}
	return FALSE;
}

VOID ShowSearchDlg$20(Panel *p)
{
LPVOID buf;DWORD buflen;EntryType t=virtualPanel;
	int r=plgns[p->GetiVPPlg()].ShowSearchDlg$20(p->GetHWND(),
												p->GetVPPlgObj(),
												p->GetPath(),
												&buf,&buflen);
	if(3==r)//Ustiga Enter qilgan bo'lsa:
	{	buf = ((char*)buf)+sizeof(int);
		wchar_t pth[MAX_PATH]=L"\\\\?\\UNC\\";int l=MyStringCpy(&pth[8],MAX_PATH-9,(wchar_t*)buf);
		wchar_t *pch=wcsrchr(pth,'\\');
		if(!pch)pch=&pth[l];else ++pch;
		l=(int)(pch-&pth[0]);
		wchar_t stck[2]={*pch,*(pch+1)};
		*pch++='*';*pch=0;
		if(0==wcscmp(p->GetPath(),pth))
		{p->FreeSelection();
		 p->SetHot(p->FindItem(&((wchar_t*)buf)[l]),TRUE);
		}
		else
		{p->FreeMem();//search.panel->FreeSelection();
		 p->AddItem(L"..",0);
		 plgns[p->GetiVPPlg()].EnumDir$12(p->GetHWND(),p->GetVPPlgObj(),pth);
		 p->AdjustScrollity();
		 p->ClrScr();
		 p->Render();
		 *pch-- = stck[1];*pch-- = stck[0];
		 p->SetHot(p->FindItem(pch+1),TRUE);
		}
	}else if(0<r)//Random path qilgan bo'lsa:
	{	plgns[p->GetiVPPlg()].DetachPanel$8(p->GetVPPlgObj(),p);
		plgns[p->GetiVPPlg()].FreePlugin();
		p->FreeMem();//search.panel->FreeSelection();
		p->GetPath()[0] = 0;
		p->SetPathLn(0);
		while(virtualPanel==t)
			t=p->GetEntry()->Pop();
		p->GetEntry()->Push(p->GetPath(),rndPathList,0);
		p->FillRandomPathListIP4(buf);
		p->AdjustScrollity();
		p->SetHot(0);
		p->ClrScr();
		p->Render();
}	}

}//end of namespace

//Class CVirtPnlPlgn ****
//Class CVirtPnlPlgn ****
//Class CVirtPnlPlgn ****
//Class CVirtPnlPlgn ****
//Class CVirtPnlPlgn ****
//Class CVirtPnlPlgn ****
//Class CVirtPnlPlgn ****
//Class CVirtPnlPlgn ****
//Class CVirtPnlPlgn ****
//Class CVirtPnlPlgn ****
//Class CVirtPnlPlgn ****
CVirtPnlPlgn::CVirtPnlPlgn():idNum(0),mRef(0),hm(NULL)
{
}

CVirtPnlPlgn::~CVirtPnlPlgn()
{
}

BOOL CALLBACK CVirtPnlPlgn::readOptions(int plgId,VOID *buf,int bufLen)
{
	if(plgId<0) return FALSE;//|| plgId>fSearchViaF7::numPlugins-1) return FALSE; ni qo'ymaymiz, hali numPlugins 1ta oshmagan bo'lishi mumkin;
DWORD rb;
wchar_t s[MAX_PATH];MyStringCpy(s,MAX_PATH-1,vrtlPanels::plgns[plgId].pathAndName);
	wchar_t *p = wcsrchr(s,'.');
	if(p) *(p+1) = 0;
	MyStringCat(s,MAX_PATH-1,L"bin");
	HANDLE f = MyFopenViaCrF(s,L"r");
	if(!f) return FALSE;
	if(!ReadFile(f,buf,bufLen,&rb,NULL))
		rb=0;
	if(!ReadFile(f,&vrtlPanels::plgns[plgId].key,sizeof(vrtlPanels::plgns[plgId].key),&rb,NULL))
		rb=0;
	CloseHandle(f);
	return (rb!=bufLen)?FALSE:TRUE;
}

BOOL CALLBACK CVirtPnlPlgn::saveOptions(int plgId,VOID *buf,int bufLen)
{
	if(plgId<0 || plgId>vrtlPanels::numPlugins-1) return FALSE;
DWORD rb;
wchar_t s[MAX_PATH];MyStringCpy(s,MAX_PATH-1,vrtlPanels::plgns[plgId].pathAndName);
	wchar_t *p = wcsrchr(s,'.');
	if(p) *(p+1) = 0;
	MyStringCat(s,MAX_PATH-1,L"bin");
	HANDLE f = MyFopenViaCrF(s,L"w");
	if(!f) return FALSE;
	if(!WriteFile(f,buf,bufLen,&rb,NULL))
		rb=0;
	if(!WriteFile(f,&vrtlPanels::plgns[plgId].key,sizeof(vrtlPanels::plgns[plgId].key),&rb,NULL))
		rb=0;
	CloseHandle(f);
	return (rb!=bufLen)?FALSE:TRUE;
}

int CALLBACK CVirtPnlPlgn::addItemToPanelList(IN LPVOID host,wchar_t* name,HICON ic,
											  WIN32_FIND_DATAW *ffdata,DWORD itemId,BOOL bRedraw)
{
	return ((Panel*)host)->AddItem( name,(FILE_ATTRIBUTE_DIRECTORY & ffdata->dwFileAttributes)?folder:file,
									ic,ffdata,itemId,bRedraw);
}

int CALLBACK CVirtPnlPlgn::changeItemInPanelList(IN LPVOID host,wchar_t* oldName,wchar_t* newName,BOOL bRedraw)
{
	int itemNumber = ((Panel*)host)->FindItem(oldName,0);
	if(-1 == itemNumber) return -1;
	((Panel*)host)->GetItem(itemNumber)->SetName((Panel*)host,newName,FALSE);//not file;

	if(bRedraw)
	{	int tmp = ((Panel*)host)->GetItem(itemNumber)->GetNameWidth() + ((Panel*)host)->GetItem(itemNumber)->GetExtWidth() + MIN_DIST_FROM_NAME_AND_EXTENSION_PLUS_MIN_DIST_FROM_COLUMNS;
		if(((Panel*)host)->GetItemMaxWidth() < tmp)//szName.cx + szExt.cx + MIN_DIST_FROM_NAME_AND_EXTENSION_PLUS_MIN_DIST_FROM_COLUMNS)
			((Panel*)host)->SetItemMaxWidth(tmp);//szName.cx + szExt.cx + MIN_DIST_FROM_NAME_AND_EXTENSION_PLUS_MIN_DIST_FROM_COLUMNS;
		//((Panel*)host)->GetItem(itemNumber)->Render(0,(Panel*)host,0);
		((Panel*)host)->AdjustScrollity();
		((Panel*)host)->ScrollItemToView(((Panel*)host)->GetHot());
		((Panel*)host)->ClrScr();
		((Panel*)host)->Render(NULL);
	}
	return itemNumber;
}

/*int CALLBACK CVirtPnlPlgn::freePanel(IN LPVOID host,BOOL bRedraw)
{
	((Panel*)host)->FreeMem();
	((Panel*)host)->AddItem(L"..",0);
	if(bRedraw)
		((Panel*)host)->Render(0);
	return 0;
}*/

int CALLBACK CVirtPnlPlgn::setPanelPath(IN LPVOID host,wchar_t *path,int ln)
{
	((Panel*)host)->SetPath(path,ln,FALSE);//Not check for existing;
	return 0;
}

/*int CALLBACK CVirtPnlPlgn::render(IN LPVOID host)
{
	((Panel*)host)->Sort();
	((Panel*)host)->AdjustHorScrollity();
	((Panel*)host)->ScrollItemToView(((Panel*)host)->GetHot());
	((Panel*)host)->ClrScr();
	((Panel*)host)->Render(0);

	//((Panel*)panel)->AdjustHorScrollity();
	//((Panel*)panel)->SetHot(0);
	//((Panel*)panel)->ScrollItemToView(0);
	//((Panel*)panel)->ClrScr();
	//((Panel*)panel)->Sort();
	//((Panel*)panel)->Render(0);
	//((Panel*)panel)->ShowPathAndName(0);
	//((Panel*)panel)->ChangeSheetTabPath();
	//((Panel*)panel)->SetFocus();
	return 0;
}*/

/*int CALLBACK CVirtPnlPlgn::selectItem(IN LPVOID host,int id,wchar_t* name)
{
//int ln=MyStringLength(name,MAX_PATH);
	for(int i=1; i<((Panel*)host)->GetTotItems(); ++i)
	{	if(0==wcscmp(((Panel*)host)->GetItem(i)->Name,name))//if(0==_wcsnicmp(((Panel*)host)->GetItem(i)->Name,name,ln))
		{	((Panel*)host)->Render(0);
			((Panel*)host)->FreeSelection();
			((Panel*)host)->SetHot(i,TRUE);
			return 0;
	}	}
	return 0;
}*/

BOOL CALLBACK CVirtPnlPlgn::closeEvent(int plgId, LPVOID host)
{
	if(plgId<0) return FALSE;//|| plgId>fSearchViaF7::numPlugins-1) return FALSE; ni qo'ymaymiz, hali numPlugins 1ta oshmagan bo'lishi mumkin;
	((Panel*)host)->FolderUpVirtualPanel(0,TRUE);
	return TRUE;
}

VOID CVirtPnlPlgn::FreePlugin()
{
if(0==mRef)
{	if(hm) FreeLibrary(hm);
		hm = 0;
	GetPluginType = 0;
	SetCallbacks$4xxx = 0;
	SetId$4 = 0;
	GetPluginDescription = 0;
	GetPluginName = 0;
	ShowOptionDialog = 0;

	AttachPanel$12 = 0;
	EnumDir$12 = 0;
	GetReadyForEnumDir$12 = 0;
	DetachPanel$8 = 0;
	GetItemPathAndName$16 = 0;
	ShowSearchDlg$20 = 0;
	GetStrForTooltip$20 = 0;
	EventPanelResizing$8 = 0;
	ShowSearchDlg$20 = 0;
}
if(mRef>0)--mRef;
}

BOOL CVirtPnlPlgn::LoadPlugin()
{
if(0==mRef)
{	if(!hm)
	{	hm = LoadLibrary(pathAndName);
		if(!hm) return FALSE;

		//Standard functions:
		GetPluginType = (vrtlPanels::GetPluginType_t)GetProcAddress(hm,"GetPluginType");
		SetCallbacks$4xxx = (vrtlPanels::SetCallbacks$4xxx_t)GetProcAddress(hm,"SetCallbacks$4xxx");
		SetId$4 = (vrtlPanels::SetId$4_t)GetProcAddress(hm,"SetId$4");
		GetPluginDescription = (vrtlPanels::GetPluginDescription_t)GetProcAddress(hm,"GetPluginDescription");
		GetPluginName = (vrtlPanels::GetPluginName_t)GetProcAddress(hm,"GetPluginName");
		ShowOptionDialog = (vrtlPanels::ShowOptionDialog_t)GetProcAddress(hm,"ShowOptionDialog");
		AttachPanel$12 = (vrtlPanels::AttachPanel$12_t)GetProcAddress(hm,"AttachPanel$12");
		EnumDir$12 = (vrtlPanels::EnumDir$12_t)GetProcAddress(hm,"EnumDir$12");
		GetReadyForEnumDir$12 = (vrtlPanels::GetReadyForEnumDir$12_t)GetProcAddress(hm,"GetReadyForEnumDir$12");
		DetachPanel$8 = (vrtlPanels::DetachPanel$8_t)GetProcAddress(hm,"DetachPanel$8");
		GetItemPathAndName$16 = (vrtlPanels::GetItemPathAndName$16_t)GetProcAddress(hm,"GetItemPathAndName$16");
		GetStrForTooltip$20 = (vrtlPanels::GetStrForTooltip$20_t)GetProcAddress(hm,"GetStrForTooltip$20");
		ShowSearchDlg$20 = (vrtlPanels::ShowSearchDlg$20_t)GetProcAddress(hm,"ShowSearchDlg$20");

		//Events:
		EventPanelResizing$8 = (vrtlPanels::EventPanelResizing$8_t)GetProcAddress(hm,"EventPanelResizing$8");
		//EventPanelItemClick$16 = (vrtlPanels::EventPanelItemClick$16_t)GetProcAddress(hm,"EventPanelItemClick$16");
		//EventPanelReady$8 = (vrtlPanels::EventPanelReady$8_t)GetProcAddress(hm,"EventPanelReady$8");

		//Callbacks:
		SetCallbacks$4xxx(	CVirtPnlPlgn::saveOptions,
							CVirtPnlPlgn::readOptions,
							CVirtPnlPlgn::addItemToPanelList,
							CVirtPnlPlgn::changeItemInPanelList,
							CVirtPnlPlgn::closeEvent,
							CVirtPnlPlgn::setPanelPath
							//CVirtPnlPlgn::render,
							//CVirtPnlPlgn::freePanel,
							//CVirtPnlPlgn::selectItem
						 );
		SetId$4(idNum);
}	}
++mRef;
	return TRUE;
}