#ifndef _Q_VIEW_H
#define _Q_VIEW_H

#include "windows.h"
#include "..\config.h"


class CQViewPlgn;
namespace QView
{
	typedef const int (*GetPluginType_t)();
	typedef VOID (*SetCallbacks$4xxx_t)(LPVOID,...);
	typedef VOID (*SetId$4_t)(int);
	typedef const wchar_t* (*GetPluginDescription_t)();
	typedef VOID (*ShowOptionDialog_t)();
	typedef const wchar_t* (*GetPluginName_t)();
	typedef const wchar_t* (*GetExtensions_t)();
	typedef BOOL (*Draw$8_t)(HWND,wchar_t*);
	typedef VOID (*CloseViewer_t)();

	extern VOID FreePlugins();
	extern VOID LoadPlugins(HWND);
	extern BOOL Draw(wchar_t*);
	//extern VOID TryLoadPlugin(wchar_t*,wchar_t*,int);
	extern BOOL Open(int,int);
	extern BOOL Close();
	extern int FindPlugin(wchar_t*);
	extern BOOL IsExistAny();

	extern CQViewPlgn *plgns;
	extern int numPlugins;
}

class CQViewPlgn
{
public:
static BOOL   CALLBACK saveOptions(int,VOID*,int);
static BOOL   CALLBACK readOptions(int,VOID*,int);

	CQViewPlgn();
	~CQViewPlgn();
	HMODULE hm;
	wchar_t pathAndName[MAX_PATH],descrpn[MAX_PATH],extnsn[MAX_PATH];
	int  idNum;

	BOOL LoadPlugin();
	VOID FreePlugin();

	QView::GetPluginType_t GetPluginType;
	QView::SetCallbacks$4xxx_t SetCallbacks$4xxx;
	QView::SetId$4_t SetId$4;
	QView::GetPluginDescription_t GetPluginDescription;
	QView::ShowOptionDialog_t ShowOptionDialog;
	QView::GetPluginName_t GetPluginName;
	QView::GetExtensions_t GetExtensions;
	QView::Draw$8_t Draw$8;
	QView::CloseViewer_t CloseViewer;
};

#endif