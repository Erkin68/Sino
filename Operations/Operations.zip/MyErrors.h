#ifndef _MY_ERRORS_H_
#define _MY_ERRORS_H_

#include "windows.h"

namespace Err
{
	extern void AssertFatal(BOOL,LPWSTR);
	extern void fatalExit(wchar_t*,HWND);
	extern void FlipMsg(wchar_t*,int);
	extern BOOL PasswordCheck(wchar_t*,HWND,int);
	extern void msg(HWND,DWORD,wchar_t*);
	extern void msg1(HWND,DWORD,wchar_t*,wchar_t*);
	extern void msg2(HWND,DWORD,wchar_t*,wchar_t*,wchar_t*);
	extern void msg2A(HWND,DWORD,char*,char*,char*);
	extern void msgC2(HWND,DWORD,wchar_t*,wchar_t*,wchar_t*);
	extern void SockMsg(wchar_t*);
	extern BOOL SockChkMsg(int,wchar_t*);
}

#endif //#define _MY_ERRORS_H_
