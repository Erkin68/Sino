#include "DragInterface.h"
#include "ButtonsPanel.h"
#include "Execution.h"
#include "shlobj.h"
#include "stdio.h"
#include "MyShell\MyShell.h"
#include "MyShell\ComboToDisk.h"
#include "..\sino.h"
#include "..\DiskToolbar.h"
#include "..\MyCommonControls.h"
#include "..\WindowsManagmentInstrumentation.h"


using namespace BtnsPanel;


extern BOOL IsDirExist(char*);



//************ DropSource *****************
//************ DropSource *****************
//************ DropSource *****************
//************ DropSource *****************
/*ULONG __stdcall DropSource::AddRef(void)
{
	OutputDebugString(L" DropSource::AddRef");
	return ++m_cRef;
};

ULONG __stdcall DropSource::Release(void)
{ 
	OutputDebugString(L" DropSource::Release");
	if (--m_cRef != 0)
	{	return m_cRef;
	}
	delete this;
	return 0;
};

HRESULT __stdcall DropSource::GiveFeedback(DWORD dwEffect)
{
static int i=0;wchar_t ss[32];wsprintf(ss,L"\n %d",++i);
	OutputDebugString(ss);
	//return S_OK;
	switch(dwEffect)
	{	case DROPEFFECT_NONE:
			OutputDebugString(L" DropSource::GiveFeedback DROPEFFECT_NONE");
			return DRAGDROP_S_USEDEFAULTCURSORS;
		case DROPEFFECT_COPY:
			OutputDebugString(L" DropSource::GiveFeedback DROPEFFECT_COPY");
			return ResultFromScode(DRAGDROP_S_USEDEFAULTCURSORS);
		case DROPEFFECT_MOVE:
			OutputDebugString(L" DropSource::GiveFeedback DROPEFFECT_MOVE");
			return ResultFromScode(DRAGDROP_S_USEDEFAULTCURSORS);
		case DROPEFFECT_LINK:
			OutputDebugString(L" DropSource::GiveFeedback DROPEFFECT_LINK");
			return ResultFromScode(DRAGDROP_S_USEDEFAULTCURSORS);
		case DROPEFFECT_SCROLL:
			OutputDebugString(L" DropSource::GiveFeedback DROPEFFECT_SCROLL");
			return ResultFromScode(DRAGDROP_S_USEDEFAULTCURSORS);
	}
	OutputDebugString(L" DropSource::GiveFeedback NOERROR");
	return NOERROR;
}

HRESULT __stdcall DropSource::QueryContinueDrag(BOOL fEscapePressed, DWORD grfKeyState)
{
static int i=0;wchar_t ss[128];wsprintf(ss,L"\n%d DropSource::QueryContinueDrag",++i);
	OutputDebugString(ss);
	
// If ESC key has been pressed, just cancel.
	if (fEscapePressed)
	{	OutputDebugString(L"return DRAGDROP_S_CANCEL");
		return ResultFromScode(DRAGDROP_S_CANCEL);
	}
    // If mouse left button is up, do the drop.
    if (!(grfKeyState & MK_LBUTTON))//else if (!(grfKeyState & MK_LBUTTON) && !(grfKeyState & MK_RBUTTON))
	{	OutputDebugString(L"return DRAGDROP_S_DROP");
		return ResultFromScode(DRAGDROP_S_DROP);
	}
	OutputDebugString(L"return NOERROR");
    return NOERROR; // Carry on.
}

HRESULT __stdcall DropSource::QueryInterface(REFIID riid, void **ppv)
{
	OutputDebugString(L" DropSource::QueryInterface");
	*ppv = NULL;
	if (riid == IID_IUnknown)
       *ppv = this;
	if(riid == IID_IDropSource)
		*ppv = this;
	if(NULL == *ppv)
		return ResultFromScode(E_NOINTERFACE);
	((IUnknown*)*ppv)->AddRef();
	return NOERROR;
}*/

//************ DropTarget *****************
//************ DropTarget *****************
//************ DropTarget *****************
//************ DropTarget *****************
//************ DropTarget *****************
//************ DropTarget *****************
//************ DropTarget *****************
//************ DropTarget *****************
ULONG __stdcall DropTarget::AddRef(void)
{
	//if(!m_NotImplCursor)
	//	m_NotImplCursor = LoadCursor(hInst,(LPCSTR)IDC_CURSOR_DRAG_NOT_IMPL);
	//if(!m_AddToFolderCursor)
	//	m_AddToFolderCursor = LoadCursor(hInst,(LPCSTR)IDC_CURSOR_DRAG_ADD_TO_FOLDER);
	//if(!m_AddToCrntFolderCursor)
	//	m_AddToCrntFolderCursor = LoadCursor(hInst,(LPCSTR)IDC_CURSOR_DRAG_ADD_TO_CRNT_FOLDER);
	return ++m_cRef;
}

ULONG __stdcall DropTarget::Release(void)
{ 
	iPan = -1;

	//wchar_t ss[32];wsprintf(ss,L"\n DropTarget::Release,iPan = %d",iPan);
	//OutputDebugString(ss);

	if (--m_cRef != 0)
		return m_cRef;
	//if(m_NotImplCursor)DestroyCursor(m_NotImplCursor);
	//m_NotImplCursor = NULL;
	//if(m_AddToFolderCursor)DestroyCursor(m_AddToFolderCursor);
	//m_AddToFolderCursor = NULL;
	//if(m_AddToCrntFolderCursor)DestroyCursor(m_AddToCrntFolderCursor);
	//m_AddToCrntFolderCursor = NULL;
	delete this;
	return 0;
}

DWORD DropTarget::DropEffect(DWORD grfKeyState, POINTL pt, DWORD dwAllowed)
{
	DWORD dwEffect = 0;

	// 1. check "pt" -> do we allow a drop at the specified coordinates?
	
	// 2. work out that the drop-effect should be based on grfKeyState
	if(grfKeyState & MK_CONTROL)
	{
		dwEffect = dwAllowed & DROPEFFECT_COPY;
	}
	else if(grfKeyState & MK_SHIFT)
	{
		dwEffect = dwAllowed & DROPEFFECT_MOVE;
	}
	
	// 3. no key-modifiers were specified (or drop effect not allowed), so
	//    base the effect on those allowed by the dropsource
	if(dwEffect == 0)
	{
		if(dwAllowed & DROPEFFECT_COPY) dwEffect = DROPEFFECT_COPY;
		if(dwAllowed & DROPEFFECT_MOVE) dwEffect = DROPEFFECT_MOVE;
	}
	
	return dwEffect;
}

bool DropTarget::QueryDataObject(IDataObject *pDataObject)
{
	FORMATETC fmtetc = { CF_HDROP, 0, DVASPECT_CONTENT, -1, TYMED_HGLOBAL };
	// does the data object support CF_TEXT using a HGLOBAL?
	return pDataObject->QueryGetData(&fmtetc) == S_OK ? true : false;
}

HRESULT __stdcall DropTarget::DragEnter(IDataObject* pDataObj, DWORD grfKeyState, 
										POINTL pt, DWORD* pdwEffect)
{
	//OutputDebugString(L"\nDragEnter");
	m_bCanAcceptDrop = QueryDataObject(pDataObj);
	if(m_bCanAcceptDrop)
	{	iPan = Panel::IsPointInsidePanelRect((POINT*)&pt);		
		if(iPan!=-1)
		{	//if(0==iPan)OutputDebugString(L" panel 0");
			//else OutputDebugString(L" panel 1");
			if(1==panel[iPan].bDrag)
			{	*pdwEffect = DROPEFFECT_NONE;
				//OutputDebugString(L"\nDragEnter DROPEFFECT_NONE 1");
				return S_OK;
		}	}
		else
		{	iPan = CmnCntrl::IsPointInsidePatnAndNameEditRect((POINT*)&pt);
			if(-1==iPan)
			{	iPan = DskToolBar::IsPointInsideRect((POINT*)&pt);
				if(-1==iPan)
				{	if(!CmnCntrl::IsPointInsideCmndCBEdit((POINT*)&pt))
					{	*pdwEffect = DROPEFFECT_NONE;
						//OutputDebugString(L"\n DROPEFFECT_NONE 1");
		}	}	}	}
		*pdwEffect = DropEffect(grfKeyState, pt, *pdwEffect);
		SetFocus(hWnd);
	}
	else
		*pdwEffect = DROPEFFECT_NONE;
    return S_OK;
}

HRESULT __stdcall DropTarget::DragOver(DWORD grfKeyState,POINTL pt,DWORD *pdwEffect)
{
	//OutputDebugString(L"\nDragOver");
	if(m_bCanAcceptDrop)
	{	int iPanL = Panel::IsPointInsidePanelRect((POINT*)&pt);
		if(iPanL!=-1)
		{	iPan = iPanL;
			if(1==panel[iPanL].bDrag)
			{	*pdwEffect = DROPEFFECT_NONE;//DROPEFFECT_NONE; edi
				return S_OK;
		}	}
		else
		{	iPanL = CmnCntrl::IsPointInsidePatnAndNameEditRect((POINT*)&pt);
			if(-1==iPanL)
			{	iPanL = DskToolBar::IsPointInsideRect((POINT*)&pt);
				if(-1==iPanL)
				{	if(!CmnCntrl::IsPointInsideCmndCBEdit((POINT*)&pt))
					{	*pdwEffect = DROPEFFECT_NONE;
						return S_OK;
		}	}	}	}
		*pdwEffect = DropEffect(grfKeyState, pt, *pdwEffect);
	}
	else
	{
		*pdwEffect = DROPEFFECT_NONE;
	}
	return S_OK;
}

HRESULT __stdcall DropTarget::DragLeave()
{
	m_bCanAcceptDrop = false;
	iPan = -1;
	KillTimer(hWnd, 0x12345678);
	return S_OK;
}

HRESULT __stdcall DropTarget::Drop(IDataObject *pDataObj,DWORD grfKeyState,POINTL pt,DWORD *pdwEffect)
{
	if(m_bCanAcceptDrop)
	{	STGMEDIUM stgm;
		FORMATETC fe = {CF_HDROP, NULL, DVASPECT_CONTENT, -1, TYMED_HGLOBAL};
        if(SUCCEEDED (pDataObj->GetData (&fe, &stgm)) && stgm.hGlobal != NULL)
		{	DROPFILES* pDrop = (DROPFILES*)GlobalLock(stgm.hGlobal);
			if(pDrop)
			{	if(BtnsPanel::IsPointInsideRect((POINT*)&pt))
					DropToBtnsPnl(pDrop,(POINT*)&pt);
				else
				{	int iPan = Panel::IsPointInsidePanelRect((POINT*)&pt);//GetPanelFromPoint((POINT*)&pt);
					if(-1==iPan)
					{	iPan = CmnCntrl::IsPointInsidePatnAndNameEditRect((POINT*)&pt);
						if(-1==iPan)
						{	iPan = DskToolBar::IsPointInsideRect((POINT*)&pt);
							if(-1==iPan)
							{	if(!CmnCntrl::IsPointInsideCmndCBEdit((POINT*)&pt))
									*pdwEffect = DROPEFFECT_NONE;
								else
									DropToCmndCBEdit(pDrop,(POINT*)&pt);
							}
							else
								DropToDiskBtnToolbar(pDrop,(POINT*)&pt);
						}
						else
							DropToPathAndNameEdit(iPan,pDrop,(POINT*)&pt);
					}
					else
						DropToPanel(iPan,pDrop,(POINT*)&pt);
				}
				GlobalUnlock(stgm.hGlobal);
			}
			::ReleaseStgMedium (&stgm);
			*pdwEffect = (grfKeyState & MK_CONTROL) ? DROPEFFECT_COPY : DROPEFFECT_MOVE;
			return S_OK;
	}	}
	else//Ozinikiga tashlashi mumkinmu:
	{	STGMEDIUM stgm;
		FORMATETC fe = {CF_HDROP, NULL, DVASPECT_CONTENT, -1, TYMED_HGLOBAL};
        if(SUCCEEDED (pDataObj->GetData (&fe, &stgm)) && stgm.hGlobal != NULL)
		{	DROPFILES* pDrop = (DROPFILES*)GlobalLock(stgm.hGlobal);
			if(pDrop)
			{	if(BtnsPanel::IsPointInsideRect((POINT*)&pt))
					DropToBtnsPnl(pDrop,(POINT*)&pt);
				else
				{	int iPan = Panel::IsPointInsidePanelRect((POINT*)&pt);//GetPanelFromPoint((POINT*)&pt);
					if(-1==iPan)
					{	iPan = CmnCntrl::IsPointInsidePatnAndNameEditRect((POINT*)&pt);
						if(-1==iPan)
						{	iPan = DskToolBar::IsPointInsideRect((POINT*)&pt);
							if(-1==iPan)
							{	if(!CmnCntrl::IsPointInsideCmndCBEdit((POINT*)&pt))
									*pdwEffect = DROPEFFECT_NONE;
								else
									DropToCmndCBEdit(pDrop,(POINT*)&pt);
							}
							else
								DropToDiskBtnToolbar(pDrop,(POINT*)&pt);
						}
						else
							DropToPathAndNameEdit(iPan,pDrop,(POINT*)&pt);
					}
					else
						DropToPanel(iPan,pDrop,(POINT*)&pt);
				}
				GlobalUnlock(stgm.hGlobal);
			}
			::ReleaseStgMedium (&stgm);
			*pdwEffect = (grfKeyState & MK_CONTROL) ? DROPEFFECT_COPY : DROPEFFECT_MOVE;
			return S_OK;
	}	}
	// If we make it to here, the drop did not succeed.
	*pdwEffect = DROPEFFECT_NONE;
    return S_OK;
}

HRESULT __stdcall DropTarget::DropToDiskBtnToolbar(DROPFILES* pDrop,POINT* pt)
{
	int iDsk = DskToolBar::GetBtn(pt);
	if(-1==iDsk) return E_FAIL;
	wchar_t dst[MAX_PATH];MyStringCpy(dst,MAX_PATH,myWMI::GetLogicalDriveName(iDsk));
	int ln = MyStringLength(dst,MAX_PATH);

	TCHAR* it = (TCHAR*)(((CHAR*)pDrop) + pDrop->pFiles);
	if(pDrop->fWide)
	{	wchar_t* pitw = (wchar_t*)it;
		{	wchar_t *pN = wcsrchr(pitw,'\\');
			if(pN)
			{	int LN=MyStringLength(dst,MAX_PATH);
				dst[LN+1]=0;//Double null terminated;
				SHFILEOPSTRUCTW fo;fo.hwnd=::hWnd;fo.wFunc=FO_COPY;
				fo.pFrom=(wchar_t*)pitw;fo.pTo=dst;fo.fFlags=FOF_WANTNUKEWARNING;
				SHFileOperation(&fo);
				dst[ln]=0;
	}	}	}
	/*else
	{	char* pit = it;
		//do
		{	char *pN = strrchr(it,'\\');
			if(pN)
			{	//MyStringCat(dst,MAX_PATH,pN+1);
				int LN=MyStringLength(dst,MAX_PATH);
				dst[LN+1]=0;
				SHFILEOPSTRUCT fo;fo.hwnd=::hWnd;fo.wFunc=FO_COPY;
				fo.pFrom=it;fo.pTo=dst;fo.fFlags=FOF_WANTNUKEWARNING;
				SHFileOperation(&fo);
				dst[ln]=0;
	}	}	}*/

	return S_OK;
}

HRESULT __stdcall DropTarget::DropToBtnsPnl(DROPFILES* pDrop,POINT* pt)
{
	int x = pt->x;
	int y = pt->y;
	int add=0;
	POINT ptBtn;

	TCHAR* it = (TCHAR*)(((CHAR*)pDrop) + pDrop->pFiles);
	if(pDrop->fWide)
	{	wchar_t* pitw = (wchar_t*)it;
		while(pitw && (*pitw))
		{	int LN=MyStringLength(pitw,MAX_PATH);
			int numNewIt=Btn::Expand();
			if(numNewIt<0)
			{	MessageBox(hBtnsPnlWnd,L"Err.allocating memory for:",L"Panel folder button",MB_OK);
				return FALSE;
			}
			ptBtn.x = x-16;
			ptBtn.y = y-16;
			ScreenToClient(BtnsPanel::hBtnsPnlWnd,&ptBtn);
			Btn::pBtns[numNewIt].x = ptBtn.x;//x-16;
			Btn::pBtns[numNewIt].y = ptBtn.y;//y-16;
			MyStringCpy(Btn::pBtns[numNewIt].pth,MAX_PATH-1,pitw);
			Btn::pBtns[numNewIt].resType=RT_ICON;
			if(IsFileExist(pitw))
			{	Btn::pBtns[numNewIt].cmndType = Btn::extLink;
				SHFILEINFO si;
				if(SUCCEEDED(SHGetFileInfo(pitw,0,&si,sizeof(SHFILEINFO),SHGFI_ICONLOCATION|SHGFI_ICON|SHGFI_ICON)))
				{	MyStringCpy(Btn::pBtns[numNewIt].icoPth,MAX_PATH-1,si.szDisplayName);
					if(!Btn::pBtns[numNewIt].icoPth[0])
						if(Execution::IsThisValidDllOrExeFile(pitw))
						{	MyStringCpy(Btn::pBtns[numNewIt].icoPth,MAX_PATH-1,pitw);
							Btn::pBtns[numNewIt].hIcon=si.hIcon;
							Btn::pBtns[numNewIt].resName=(LPWSTR)si.iIcon;
							Btn::pBtns[numNewIt].iconFileType=Btn::frDll;
							ICONINFO ii;GetIconInfo(Btn::pBtns[numNewIt].hIcon,&ii);
							Btn::pBtns[numNewIt].w = ii.xHotspot*2;
							Btn::pBtns[numNewIt].h = ii.yHotspot*2;
						}
						else goto NullIcon;
				} else
				{NullIcon:	MyStringCpy(Btn::pBtns[numNewIt].icoPth,MAX_PATH-1,L"NULL");
					Btn::pBtns[numNewIt].hIcon=LoadIcon(hInst,MAKEINTRESOURCE(IDI_ICON_FILE));
					Btn::pBtns[numNewIt].resName=(LPWSTR)IDI_ICON_FILE;
					Btn::pBtns[numNewIt].resType=RT_ICON;
					Btn::pBtns[numNewIt].iconFileType=Btn::frExe;
					ICONINFO ii;GetIconInfo(Btn::pBtns[numNewIt].hIcon,&ii);
					Btn::pBtns[numNewIt].w = ii.xHotspot*2;
					Btn::pBtns[numNewIt].h = ii.yHotspot*2;
			}	}
			else//if(IsDirExist(dst))
			{	Btn::pBtns[numNewIt].cmndType = Btn::extFolder;
				MyStringCpy(Btn::pBtns[numNewIt].icoPth,MAX_PATH-1,L"NULL");
				Btn::pBtns[numNewIt].hIcon=LoadIcon(hInst,MAKEINTRESOURCE(IDI_ICON_FOLDER));
				Btn::pBtns[numNewIt].resName=(LPWSTR)IDI_ICON_FOLDER;
				Btn::pBtns[numNewIt].iconFileType=Btn::frExe;
				ICONINFO ii;GetIconInfo(Btn::pBtns[numNewIt].hIcon,&ii);
				Btn::pBtns[numNewIt].w = ii.xHotspot*2;
				Btn::pBtns[numNewIt].h = ii.yHotspot*2;
			}
			x += Btn::pBtns[numNewIt].w+4;
			if(x>pt->x+150)
			{	x = pt->x;
				y+= Btn::pBtns[numNewIt].h+4;
			}
			pitw += LN+1;
			++add;
	}	}
	if(add)//x!=pt->x || y!=pt->y)
		BtnsPanel::Render(0,0,0,0);
	return S_OK;
}

HRESULT __stdcall DropTarget::DropToPanel(int iPan,DROPFILES* pDrop,POINT* pt)
{
	if(archElem==panel[iPan].GetEntry()->GetCrntRecType())
		return DropToPanelArch(iPan,pDrop,pt);
wchar_t dst[MAX_PATH];int l;
	ScreenToClient(panel[iPan].GetHWND(),pt);
	l=MyStringCpy(dst,MAX_PATH,panel[iPan].GetPath());
	if('*'==dst[l-1])//MyStringRemoveLastChar(dst,MAX_PATH,'*');
	if('\\'==dst[l-2])
		dst[--l]=0;
	int overItem = panel[iPan].GetItemNum(pt->x, pt->y);
	if(panel[iPan].GetItem(overItem)->attribute==folder)
	{	l+=MyStringCpy(&dst[l],MAX_PATH-l,panel[iPan].GetItem(overItem)->Name);//MyStringCat(dst,MAX_PATH,panel[iPan].GetItem(overItem)->Name);
		dst[l++]='\\';//MyStringCat(dst,MAX_PATH,"\\");
		dst[l]=0;
	}
	//int ln = MyStringLength(dst,MAX_PATH);

	wchar_t* it = (wchar_t*)(((char*)pDrop) + pDrop->pFiles);
	if(pDrop->fWide)
	{	wchar_t* pitw = (wchar_t*)it;
		//do use multifile verison of SHFileOp
		{	wchar_t *pN = wcsrchr(pitw,'\\');
			if(pN)
			{	//MyStringCat(dstw,MAX_PATH,pN+1); for multiple src show only paths
				//int LN=MyStringLength(dstw,MAX_PATH);
				dst[l+1]=0;//Double null terminated;
				SHFILEOPSTRUCTW fo;fo.hwnd=::hWnd;fo.wFunc=FO_COPY;
				fo.pFrom=(wchar_t*)pitw;fo.pTo=dst;fo.fFlags=FOF_WANTNUKEWARNING;
				SHFileOperation(&fo);
				dst[l]=0;
			}
			//int pitwLn = MyStringLength(pitw,MAX_PATH);
			//pitw += pitwLn+1;
		}// while(*pitw!=0);
	}
	/*else
	{	wchar_t* pit = it;
		//do
		{	int LN=l;char *pN = strrchr(it,'\\');
			if(pN)
				LN+=MyStringCpy(&dst[l],MAX_PATH-l,pN+1);//MyStringCat(dst,MAX_PATH,pN+1);
			else
				LN+=MyStringCpy(&dst[l],MAX_PATH-l,it);
				//int LN=MyStringLength(dst,MAX_PATH);
				dst[LN+1]=0;//LN+1 double nulled;
				SHFILEOPSTRUCT fo;fo.hwnd=::hWnd;fo.wFunc=FO_COPY;
				fo.pFrom=it;fo.pTo=dst;fo.fFlags=FOF_WANTNUKEWARNING;
				SHFileOperation(&fo);
				//dst[l]=0;
		}
			//int pitLn = MyStringLength(pit,MAX_PATH);
			//pit += pitLn+1;
	}// while(*pit!=0);*/
	return S_OK;
}

HRESULT __stdcall DropTarget::DropToPanelArch(int iPan,DROPFILES* pDrop,POINT* pt)
{
//wchar_t s[MAX_PATH];
wchar_t fullPathAndName[MAX_PATH],relPathAndName[MAX_PATH];int l;
	ScreenToClient(panel[iPan].GetHWND(),pt);
	l=MyStringCpy(relPathAndName,MAX_PATH-1,panel[iPan].GetArcPath());
	//if(AreFileApisANSI())
	//{	MultiByteToWideChar(CP_ACP,MB_PRECOMPOSED,relPathAndName,MAX_PATH-1,s,MAX_PATH);
	//	WideCharToMultiByte(CP_OEMCP,0,s,-1,relPathAndName,MAX_PATH-1,NULL,NULL);
	//}
	if(l)
	if(relPathAndName[l-1]!='\\')
	{	relPathAndName[l++]='\\';
		relPathAndName[l]=0;
	}
	
	panel[iPan].GetArch()->Close$4();
	panel[iPan].GetArch()->Open$12(panel[iPan].GetArcFilePathAndName(),panel[iPan].GetArch()->GetPlgNum(),2);//opn exstng
	archive::plgns[panel[iPan].GetArch()->GetPlgNum()].RebuildCheckExistings$8(
				panel[iPan].GetArch()->GetPlgObj(),L"");

	TCHAR* it = (TCHAR*)(((CHAR*)pDrop) + pDrop->pFiles);
	do
	{	/*if(pDrop->fWide)
		{	it+=2*WideCharToMultiByte(CP_OEMCP,0,(LPCWSTR)it,-1,fullPathAndName,MAX_PATH-1,NULL,NULL);
		}
		else*/
		{	it+=MyStringCpy(fullPathAndName,MAX_PATH-l,it);
		}
		wchar_t *pext = wcsrchr(fullPathAndName,'\\');
		if(!pext)pext=&fullPathAndName[0];
		else ++pext;
		/*if((!pDrop->fWide) && AreFileApisANSI())
		{	MultiByteToWideChar(CP_ACP,MB_PRECOMPOSED,pext,MAX_PATH-1,s,MAX_PATH);
			WideCharToMultiByte(CP_OEMCP,0,s,-1,pext,MAX_PATH-1,NULL,NULL);
		}*/
		int a=MyStringCpy(&relPathAndName[l],MAX_PATH-1-l,pext);
		if(IsDirExist(fullPathAndName))
		{	relPathAndName[l+a] = '\\';
			relPathAndName[l+a+1] = 0;
			archive::plgns[panel[iPan].GetArch()->GetPlgNum()].CreateDir$24(
				panel[iPan].GetArch()->GetPlgObj(),
				fullPathAndName,
				relPathAndName,
				L"",//password,
				9,
				FALSE);
		}
		else
		{	archive::plgns[panel[iPan].GetArch()->GetPlgNum()].Add$24(
				panel[iPan].GetArch()->GetPlgObj(),
				fullPathAndName,
				relPathAndName,
				L"",//password,
				9,
				FALSE);
	}	}
	while(*it!=0);

	panel[iPan].GetArch()->Close$4();
	panel[iPan].GetArch()->OpenForUnpacking$8(panel[iPan].GetArcFilePathAndName(),panel[iPan].GetArch()->GetPlgNum());
	int id;id=panel[iPan].GetHot();
	if(id<0 || id>panel[iPan].GetTotItems()-1)
		id = panel[iPan].GetSelectedItemNum(0);
	if(id>0 && id<panel[iPan].GetTotItems())
		MyStringCpy(panel[iPan].findItemName,MAX_PATH-1,panel[iPan].GetItem(id)->Name);
	panel[iPan].FreeMem();//p->FreeSelection(); shartmas
	panel[iPan].FillArchItems(panel[iPan].GetArcPath());
	panel[iPan].ChangeSheetTabPath();
	panel[iPan].AdjustScrollity();
	if(id>0 && id<panel[iPan].GetTotItems())
		panel[iPan].FindItem(panel[iPan].findItemName);
	else
		panel[iPan].ScrollItemToView(0);
	panel[iPan].ClrScr();
	panel[iPan].Render(NULL);
	panel[iPan].SetFocus();

	return S_OK;
}

HRESULT __stdcall DropTarget::DropToPathAndNameEdit(int iPan,DROPFILES* pDrop,POINT* pt)
{
	TCHAR* it = (TCHAR*)(((CHAR*)pDrop) + pDrop->pFiles);
	if(pDrop->fWide)
		SetWindowText(panel[iPan].GetPathAndNameEdt(1),(wchar_t*)it);
	//else
	//	SetWindowText(panel[iPan].GetPathAndNameEdt(1),(char*)it);

	return S_OK;
}

HRESULT __stdcall DropTarget::DropToCmndCBEdit(DROPFILES* pDrop,POINT* pt)
{
	TCHAR* it = (TCHAR*)(((CHAR*)pDrop) + pDrop->pFiles);
	if(pDrop->fWide)
	{	SetWindowText(cmndsCBEdt,(wchar_t*)it);
		CBToDisk::AddToCB(cmndsCB,(wchar_t*)it);
	}
	//else
	//	SetWindowText(panel[iPan].GetPathAndNameEdt(1),(char*)it);

	return S_OK;
}

HRESULT __stdcall DropTarget::QueryInterface(REFIID riid, void **ppv)
{
    HRESULT hr = E_NOINTERFACE;
    IUnknown *pUnknown = NULL;
    
    if (!ppv)
	{	return E_POINTER;
	}
    
    *ppv = NULL;
    
    if (riid == IID_IUnknown)
        pUnknown = static_cast<IUnknown*>(this);
    else if (riid == IID_IDropTarget)
        pUnknown = static_cast<IDropTarget*>(this);
    
    *ppv = pUnknown;
    if (pUnknown)
    {   pUnknown->AddRef();
		return S_OK;
    } 
    else
	{   return E_NOINTERFACE;
}	}


//****************    DragDataObject   ******************
//****************    DragDataObject   ******************
//****************    DragDataObject   ******************
//****************    DragDataObject   ******************
//****************    DragDataObject   ******************
//****************    DragDataObject   ******************
//****************    DragDataObject   ******************
//****************    DragDataObject   ******************
//****************    DragDataObject   ******************
//****************    DragDataObject   ******************
//****************    DragDataObject   ******************
/*ULONG __stdcall DragDataObject::AddRef(void)
{
	return ++refs;
	//return InterlockedIncrement(&refs);
}

ULONG __stdcall DragDataObject::Release(void)
{
	if(--refs != 0)
	{	return refs;
	}
	delete this;
	return refs;
};

HRESULT __stdcall DragDataObject::GetData(	FORMATETC __RPC_FAR *pformatetcIn,
											STGMEDIUM __RPC_FAR *pmedium)
{
static int i=0;wchar_t ss[128];wsprintf(ss,L"\n %d DragDataObject::GetData ",++i);
	OutputDebugString(ss);
	if(archElem==pan->GetEntry()->GetCrntRecType())
	{	OutputDebugString(L"return E_FAIL");
		return E_FAIL;
	}

if ((pformatetcIn->dwAspect & DVASPECT_CONTENT) &&
		(pformatetcIn->tymed & TYMED_HGLOBAL) &&
		(pformatetcIn->cfFormat == CF_HDROP))
{
	//Avval qancha joy kerakligini hisoblaymiz:
	int sz=sizeof(DROPFILES)+1;
	if(pan->GetTotSelects()>1)
	{	for(int i=0; i<pan->GetTotItems(); i++)
		{	if(selected==pan->GetItem(i)->state || pan->GetHot()==i)
			{	wchar_t*s = pan->GetFullPathAndName(i);
				int ln = MyStringLength(s,MAX_PATH);
				sz += ln+1;
	}	}	}
	else
	{	int h = pan->GetHot();
		if(h>0)
		{	wchar_t*s = pan->GetFullPathAndName(h);
			int ln = MyStringLength(s,MAX_PATH);
			sz += ln+1;
	}	}
	HGLOBAL hgDrop = (void*)GlobalAlloc(GHND | GMEM_SHARE, 2*sz);//use unicode version
	DROPFILES*  pDrop = (DROPFILES*)GlobalLock(hgDrop);

    if(NULL == pDrop)
    {	GlobalFree ( hgDrop );
		OutputDebugString(L"return E_FAIL2");
        return E_FAIL;
    }

	//Endi to'ldiramiz:
	// Fill in the DROPFILES struct.
    pDrop->pFiles = sizeof(DROPFILES);
	GetCursorPos(&pDrop->pt);
//#ifdef _UNICODE
    // If we're compiling for Unicode, set the Unicode flag in the struct to
    // indicate it contains Unicode strings.
	pDrop->fWide = TRUE;
//#else
	//pDrop->fWide = FALSE;
//#endif

    // Copy all the filenames into memory after
    // the end of the DROPFILES struct.
//TCHAR* ptr = (TCHAR*)(LPBYTE(pDrop) + sizeof(DROPFILES));
WCHAR* ptr = (WCHAR*)(LPBYTE(pDrop) + sizeof(DROPFILES));

	if(pan->GetTotSelects()>1)
	{   for(int i=0; i<pan->GetTotItems(); i++)
		{	if(selected==pan->GetItem(i)->state
					|| pan->GetHot()==i)
			{	pan->GetFullPathAndName(i,ptr,MAX_PATH);
				int ln = MyStringLength(ptr,MAX_PATH);
				ptr += ln+1;
	}	}	}
	else
	{	int h = pan->GetHot();
		if(h>0)
		{	pan->GetFullPathAndName(h,ptr,MAX_PATH);
			int ln = MyStringLength(ptr,MAX_PATH);
			ptr += ln+1;
	}	}
    GlobalUnlock(hgDrop);
	pmedium->tymed=TYMED_HGLOBAL;
    pmedium->hGlobal=hgDrop;
	pmedium->pUnkForRelease=NULL;
	OutputDebugString(L"return S_OK");
    return S_OK;
}//else
OutputDebugString(L"return DV_E_FORMATETC");
return DV_E_FORMATETC;
}

HRESULT __stdcall DragDataObject::GetDataHere(FORMATETC __RPC_FAR* pformatetc,
										  STGMEDIUM __RPC_FAR *pmedium)
{
	OutputDebugString(L"\n DragDataObject::GetDataHere");
	pmedium->tymed=TYMED_NULL;
    return DV_E_TYMED;
}

HRESULT __stdcall DragDataObject::GetCanonicalFormatEtc(FORMATETC __RPC_FAR *pformatectIn,
												 FORMATETC __RPC_FAR *pformatetcOut)
{
	OutputDebugString(L"\n DragDataObject::GetCanonicalFormatEtc");
	return DATA_S_SAMEFORMATETC;
}

HRESULT __stdcall DragDataObject::SetData(FORMATETC __RPC_FAR *pformatetc,
									  STGMEDIUM __RPC_FAR *pmedium,
									  BOOL fRelease)
{
	OutputDebugString(L"\n DragDataObject::SetData");
	return E_NOTIMPL;
}

HRESULT __stdcall DragDataObject::EnumFormatEtc(DWORD dwDirection,
							 IEnumFORMATETC __RPC_FAR *__RPC_FAR *ppenumFormatEtc)
{
	OutputDebugString(L"\n DragDataObject::EnumFormatEtc");
	return E_NOTIMPL;
}

HRESULT __stdcall DragDataObject::DAdvise(FORMATETC __RPC_FAR *pformatetc,
									  DWORD advf,
									  IAdviseSink __RPC_FAR *pAdvSink,
									  DWORD __RPC_FAR *pdwConnection)
{
	OutputDebugString(L"\n DragDataObject::DAdvise");
	return ResultFromScode(OLE_S_USEREG);//return E_NOTIMPL;
}

HRESULT __stdcall DragDataObject::DUnadvise(DWORD dwConnection)
{
	OutputDebugString(L"\n DragDataObject::DUnadvise");
	return OLE_E_ADVISENOTSUPPORTED;
}

HRESULT __stdcall DragDataObject::EnumDAdvise(IEnumSTATDATA __RPC_FAR *__RPC_FAR *ppenumAdvise)
{
	OutputDebugString(L"\n DragDataObject::GetDataHere");
	return OLE_E_ADVISENOTSUPPORTED;
}

HRESULT __stdcall DragDataObject::QueryGetData(FORMATETC __RPC_FAR *pformatetc)
{
	if ((pformatetc->dwAspect & DVASPECT_CONTENT) &&
		(pformatetc->tymed & TYMED_HGLOBAL) &&
		(pformatetc->cfFormat == CF_HDROP))
	{	OutputDebugString(L"\n DragDataObject::QueryGetData return S_OK");
		return S_OK;
	}
	OutputDebugString(L"\n DragDataObject::QueryGetData return DV_E_FORMATETC");
	return DV_E_FORMATETC;
}

HRESULT __stdcall DragDataObject::QueryInterface(REFIID riid,void __RPC_FAR *__RPC_FAR *ppvObject)
{
	*ppvObject=NULL;
	if(riid == IID_IUnknown)
		*ppvObject=this;
	else if(riid == IID_IPersistFile)
       *ppvObject=this;
	else if(riid == IID_IDataObject)
       *ppvObject=this;
	if(NULL==*ppvObject)
	{	OutputDebugString(L"\n DragDataObject::QueryInterface return E_NOINTERFACE");
		return ResultFromScode(E_NOINTERFACE);
	}
	((IUnknown*)*ppvObject)->AddRef();
	OutputDebugString(L"\n DragDataObject::QueryInterface return NOERROR");
	return NOERROR;
}*/