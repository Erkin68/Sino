#ifndef _ACTNS_BUTTONS_PANEL_H_
#define _ACTNS_BUTTONS_PANEL_H_

#include "windows.h"
#include "..\Toolcha.h"

class CBtnBar;
class CBarBtn
{
public:
			CBarBtn();
		   ~CBarBtn();

 BOOL Execute();
 BOOL ExecuteCmndNum();
 VOID Free(int);
 VOID Render(HDC,CBtnBar*);
 VOID RenderClose(HDC,CBtnBar*);
 VOID LoadHintString(int);
 VOID SetHint(wchar_t*);
 VOID SetIconPath(wchar_t*);
 VOID SetAuxPath(wchar_t*);

typedef enum TBarBtnType
{	group=0,
	hotKey=1,
	extFolder=2,
	extLink=3,
	plgDllLink=4,
	plgExeLink=5,
	commands=6
} BarBtnType;
	BarBtnType type;
	int cmndNum;

typedef enum TState
{	normal=0,
	hovered=1,
	pressed=2,
	clearBack=3,
	toolTrack=4,//aux - boshqalarga ta'siri yo'q, faqat tool ni qimirlatish uchun kerak;
	setCapture=5,//aux
	releaseCapture=6,//aux
	released=7//aux
} State;
	State state;

	int icoResNum,iconPathLn;
	struct
	{int icoResGroup:1;//0-RT_GROUP_ICON,1-RT_ICON
	};
	int xPos,yPos;
	wchar_t *iconPath;
	HICON	icon;

	wchar_t *hintStr;
	int hintStrLn;
typedef enum THintType
{	none=0,
	frSino=1,
	//frShell=2,
	//frExmod=3,
	direct=2
} HintType;
	HintType hintType;

	int data[4];
	int hintResNum;

	wchar_t *auxPath;
	int auxPathLn;
};

class CBtnBar
{
friend BOOL SetSelectItem(HWND,int,CBtnBar*,int);
friend BOOL	SetHintStr(HWND,CBtnBar*,int);
friend BOOL SetBtnIconResNum(HWND,CBtnBar*,int,int);
public:
static ATOM ActnBarClass;

static LRESULT CALLBACK WndProc(HWND,UINT,WPARAM,LPARAM);
static INT_PTR CALLBACK propDlgProc(HWND,UINT,WPARAM,LPARAM);
static BOOL RegisterActnClass();

public:
static HDC  hHoveredBtnDC;
static HDC  hPressedBtnDC;
static VOID	Free();

public:
			CBtnBar(int);
		   ~CBtnBar();

 BOOL	    Copy(CBtnBar*);
 BOOL		InsertGroupBtn(int);
 BOOL		DeleteBtn(int);
 int		Create(HWND,int,int,int,int);
 BOOL		TopCreateOnFail();
 VOID		Destroy();
 int		Resize(int);
 VOID		Render(HDC);
 VOID		RenderBtn(HDC,int);
 int		CalcHeight(int);
 VOID		MouseAction(int,CBarBtn::TState,int x=0,int y=0);
 BOOL	    GetItemInfoStr(int,wchar_t*,int);

 BOOL		InitUt();
 BOOL		Read(wchar_t*);
 BOOL		ReadIcons();
 BOOL		ReadUtIcons();
 BOOL		Save(wchar_t*);
 BOOL		Reset();
 int		GetItemFromPos(int,int);
 int        GetHeight(){return height;}
 CBarBtn*   GetBtns(){return pBtns;}
 HWND       GetWindow(){return hWnd;}

 int  ELEM_WIDTH;
 int  ELEM_HEIGHT;
 int  CLOSE_WIDTH;
 int  VIA_ELEM_WIDTH;
 int  VIA_ELEM_HEIGHT;
 MyToolTip	toolTip;

protected:
 VOID FreeBtns(int);
 BOOL FreeIcons();

 HWND hWnd;
 RECT rcClient;
 int  crntActBtn;
 int  xPos,yPos,width,height;
 int  type;//0-top,1-bottom(utiltyExe)

 int numBtns;
 BOOL bCapture;
 CBarBtn *pBtns;
};

extern CBtnBar topBar,bottomBar;

#endif