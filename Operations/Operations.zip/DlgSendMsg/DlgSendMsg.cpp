// DlgSendMsg.cpp : Defines the entry point for the application.
//

#include "windows.h"
#include "DlgSendMsg.h"

#define MAX_LOADSTRING 100

// Global Variables:
HINSTANCE hInst;								// current instance
HWND hDlgHook=0,hBtnHook=0,hEdtUserHook=0,hEdtPasswordHook=0;

// Forward declarations of functions included in this code module:
INT_PTR CALLBACK	MainDlg(HWND, UINT, WPARAM, LPARAM);
VOID OnTimerTicked(HWND);


int APIENTRY WinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPSTR     lpCmdLine,
                     int       nCmdShow)
{
	hInst = hInstance;
	return DialogBox(hInst, MAKEINTRESOURCE(IDD_MAINDLG), GetDesktopWindow(), MainDlg);
}

unsigned int atohex(wchar_t *s)
{int r=0;
	for(wchar_t *p=s; *p;)
	{	wchar_t ch = *p;
		if(ch>='0' && ch<='9')
			ch -= '0';
		else if(ch>='a' && ch<='f')
			ch = 10+ch-'a';
		else if(ch>='A' && ch<='F')
			ch = 10+ch-'A';
		else
		{	MessageBox(NULL,L"Uncorrect hex value",L"Err.",MB_OK);
			return 0;
		}
		r = (r<<4) | ch;
		++p;
	}
	return r;
}

// Message handler for about box.
INT_PTR CALLBACK MainDlg(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{wchar_t s[MAX_PATH];
	UNREFERENCED_PARAMETER(lParam);
	switch (message)
	{
	case WM_INITDIALOG:
		return (INT_PTR)TRUE;

	case WM_COMMAND:
		switch(LOWORD(wParam))
		{	case IDOK:
				EndDialog(hDlg, LOWORD(wParam));
				return (INT_PTR)TRUE;
			case IDCANCEL:
				EndDialog(hDlg, LOWORD(wParam));
				return (INT_PTR)TRUE;
			case IDC_BUTTON_SEND:
				GetDlgItemText(hDlg,IDC_EDIT_HNDL_DLG,s,MAX_PATH);
				hDlgHook = (HWND)atohex(s);
				if(!hDlgHook) return 0;
				GetDlgItemText(hDlg,IDC_EDIT_BUTTON_HOOK,s,MAX_PATH);
				hBtnHook = (HWND)atohex(s);
				if(!hBtnHook) return 0;
				GetDlgItemText(hDlg,IDC_EDIT_EDIT_USER_HOOK,s,MAX_PATH);
				hEdtUserHook = (HWND)atohex(s);
				if(!hEdtUserHook) return 0;
				GetDlgItemText(hDlg,IDC_EDIT_PASSWORD_HOOK,s,MAX_PATH);
				hEdtPasswordHook = (HWND)atohex(s);
				if(!hEdtPasswordHook) return 0;
				GetDlgItemText(hDlg,IDC_EDIT_TIMER,s,MAX_PATH);
				int elapse;elapse = _wtoi(s);				
				SetTimer(hDlg,1,elapse,NULL);
				return 0;
			case IDC_BUTTON_STOP:
				KillTimer(hDlg,1);
				return (INT_PTR)TRUE;
			case WM_TIMER:
				OnTimerTicked(hDlg);
				return 0;
		}		
		break;
	}
	return (INT_PTR)FALSE;
}

VOID OnTimerTicked(HWND hDlg)
{
	SetWindowText(hEdtUserHook,L"user");
	SetWindowText(hEdtPasswordHook,L"1111");
	SendMessage(hBtnHook,WM_LBUTTONDOWN,0,0);
}