#include "DeleteOperation.h"
#include "strsafe.h"
#include "LinkSocket.h"
#include "..\Sino.h"
#include "..\Config.h"
#include "..\Panel.h"
#include "MyErrors.h"
#include "MyShell\MyShell.h"
//#include "MyShell\MyButtonC++.h"
#include "shlobj.h"
#include "shlwapi.h"



namespace fDelOper
{

#define MYWM_CANCEL	0x7f00
#define MYWM_STOP   0x7f01
enum
{	mSHFileOperation,
    mDeleteFile
} deleteMethod(mDeleteFile);//mSHFileOperation);


BOOL AskForDelete(int selCnt,CpyStack* stack)
{
	wchar_t msg[MAX_PATH*10];wchar_t* pmsg = &msg[0];
	for(int i=0; i<(selCnt>9?10:selCnt); i++)
	{	StringCchPrintf(pmsg,MAX_PATH-1,stack[i].FullPathAndName);
		size_t l = MyStringLength(pmsg,MAX_PATH);//StringCchLength(pmsg,MAX_PATH-1,&l);
		pmsg+=l; *pmsg++ = 0x0d; *pmsg++ = 0x0a;
	}
	if(selCnt>9)
		{*pmsg++ = '.'; *pmsg++ = '.'; *pmsg++ = '.';}
	*pmsg = 0;
	int r = MessageBox(hWnd,msg,L"Delete following files:",MB_YESNOCANCEL|MB_ICONWARNING|MB_SYSTEMMODAL);
	if(IDCANCEL==r)
	{	return FALSE;
	}
	else if(IDNO==r)
	{	return FALSE;
	}
	return TRUE;
}

int GetFilesInFolder(wchar_t *path, CpyStack *stack)//reentrance,copynikidan farq qiladur;
{
WIN32_FIND_DATAW ff;
HANDLE hf = INVALID_HANDLE_VALUE;

int tot = 0;

	hf = MyFindFirstFileEx(path,FindExInfoStandard,&ff,FindExSearchLimitToDirectories,NULL,0);
	do
	{	if(INVALID_HANDLE_VALUE==hf) return tot;
		if(FILE_ATTRIBUTE_DIRECTORY & ff.dwFileAttributes)//if(IsDirectory(path, &ff, FALSE))
		{	if(IsCrntOrPrntDirAttrb(ff.cFileName))
			{	wchar_t s[MAX_PATH];
				int l=MyStringCpy(s,MAX_PATH-1,path);
				if('*'==s[l-1])
				if('\\'==s[l-2])
					s[--l]=0;
				l+=MyStringCpy(&s[l],MAX_PATH-l+1,ff.cFileName);
				s[l]='\\';
				s[l+1]='*';
				s[l+2]=0;
				tot += GetFilesInFolder(s,&stack[tot]);
				s[l]=0;
				MyStringCpy(stack[tot].FullPathAndName,MAX_PATH-1,s);
				MyStringCpy(stack[tot].Name,MAX_PATH-1,ff.cFileName);
				stack[tot].attribute = folder;
				++tot;//folderniyam;
		}	}
		else
		{	MyStringCpy(stack[tot].Name,MAX_PATH-1,ff.cFileName);
			int l=MyStringCpy(stack[tot].FullPathAndName,MAX_PATH-1,path);
			if('*'==stack[tot].FullPathAndName[l-1])//MyStringRemoveLastCharCheckPre(stack[tot].FullPathAndName,MAX_PATH-1,'*','\\');
			if('\\'==stack[tot].FullPathAndName[l-2])
				stack[tot].FullPathAndName[--l]=0;

			l+=MyStringCpy(&stack[tot].FullPathAndName[l],MAX_PATH-l,ff.cFileName);//MyStringCat(stack[tot].FullPathAndName,MAX_PATH-1,ff.cFileName);
			stack[tot].size = ((unsigned __int64)ff.nFileSizeHigh<<32) | ff.nFileSizeLow;
			stack[tot].attribute = file;
			++tot;
	}	}	
	while(FindNextFile(hf, &ff));
	FindClose(hf);
	return tot;
}

int GetSelectedFiles(Panel *p,CpyStack* stack,BOOL listFolders)
{
int tot=0;
	
 if(mSHFileOperation==deleteMethod)
 {	for(int i=0; i<p->GetTotItems(); i++)
	{	if(selected==p->GetItem(i)->state || (0==p->GetTotSelects() && i==p->GetHot()))
		{	if(i<1) continue;
			{	if(rndPathList==p->GetEntry()->GetCrntRecType())
				{	
					MyStringCpy(stack[tot].FullPathAndName,MAX_PATH-1,p->GetItem(i)->Name);				
				}
				else
				{	MyStringCpy(stack[tot].Name,MAX_PATH-1,p->GetItem(i)->Name);
					int l=MyStringCpy(stack[tot].FullPathAndName,MAX_PATH-1,p->GetPath());
					if('*'==stack[tot].FullPathAndName[l-1])//MyStringRemoveLastCharCheckPre(stack[tot].FullPathAndName,MAX_PATH-1,'*','\\');
					if('\\'==stack[tot].FullPathAndName[l-2])
						stack[tot].FullPathAndName[--l]=0;
					MyStringCpy(&stack[tot].FullPathAndName[l],MAX_PATH-l,p->GetItem(i)->Name);//MyStringCat(stack[tot].FullPathAndName,MAX_PATH-1,p->GetItem(i)->Name);
				}
				stack[tot].size = p->GetItem(i)->size;
				stack[tot].attribute = file;
				++tot;
 }	}	}	}
 else if(mDeleteFile==deleteMethod)
 {	for(int i=1; i<p->GetTotItems(); i++)
	{	if(selected==p->GetItem(i)->state || (0==p->GetTotSelects() && i==p->GetHot()))
		{	if(file == p->GetItem(i)->attribute)
			{	if(rndPathList==p->GetEntry()->GetCrntRecType())
				{	
					MyStringCpy(stack[tot].FullPathAndName,MAX_PATH-1,p->GetItem(i)->Name);				
				}
				else
				{	MyStringCpy(stack[tot].Name,MAX_PATH-1,p->GetItem(i)->Name);
					int l=MyStringCpy(stack[tot].FullPathAndName,MAX_PATH-1,p->GetPath());
					if('*'==stack[tot].FullPathAndName[l-1])//MyStringRemoveLastCharCheckPre(stack[tot].FullPathAndName,MAX_PATH-1,'*','\\');
					if('\\'==stack[tot].FullPathAndName[l-2])
						stack[tot].FullPathAndName[--l]=0;
					MyStringCpy(&stack[tot].FullPathAndName[l],MAX_PATH-l,p->GetItem(i)->Name);//MyStringCat(stack[tot].FullPathAndName,MAX_PATH-1,p->GetItem(i)->Name);
				}
				stack[tot].size = p->GetItem(i)->size;
				stack[tot].attribute = file;
				++tot;
			}
			else if(folder == p->GetItem(i)->attribute)
			{	wchar_t pth[MAX_PATH];
				int l=p->GetFullPathAndName(i,pth,MAX_PATH);
				if(listFolders)//Avval folder ichilarini,
				{	pth[l]='\\';//MyStringCat(pth,MAX_PATH-1,"\\*");
					pth[l+1]='*';
					pth[l+2]=0;
					tot += GetFilesInFolder(pth,&stack[tot]);//fCopyniki bo'lmaydi,
					pth[l]=0;//chunki u avval dir ni tiqadi;bizga esa avval ichidagini
				}//keyin o'zini;                   tiqishi kerak;
				if(rndPathList==p->GetEntry()->GetCrntRecType())
					MyStringCpy(stack[tot].FullPathAndName,MAX_PATH-1,p->GetItem(i)->Name);				
				else
				{	MyStringCpy(stack[tot].Name,MAX_PATH-1,p->GetItem(i)->Name);
					MyStringCpy(stack[tot].FullPathAndName,MAX_PATH-1,pth);
				}
				stack[tot].attribute = folder;
				++tot;//folderniyam;
 }	}	}	}
 return tot;
}

int GetSelectedFilesFrSockSrvr(Panel *p,CpyStack* stack,BOOL listFolders)
{
int tot=0;
	
 if(mSHFileOperation==deleteMethod)
 {	for(int i=0; i<p->GetTotItems(); i++)
	{	if(selected==p->GetItem(i)->state || (0==p->GetTotSelects() && i==p->GetHot()))
		{	if(i<1) continue;
			{	if(rndPathList==p->GetEntry()->GetCrntRecType())
				{	
					MyStringCpy(stack[tot].FullPathAndName,MAX_PATH-1,p->GetItem(i)->Name);
				}
				else
				{	MyStringCpy(stack[tot].Name,MAX_PATH-1,p->GetItem(i)->Name);
					int l=MyStringCpy(stack[tot].FullPathAndName,MAX_PATH-1,p->GetPath());
					if('*'==stack[tot].FullPathAndName[l-1])//MyStringRemoveLastCharCheckPre(stack[tot].FullPathAndName,MAX_PATH-1,'*','\\');
					if('\\'==stack[tot].FullPathAndName[l-2])
						stack[tot].FullPathAndName[--l]=0;
					MyStringCpy(&stack[tot].FullPathAndName[l],MAX_PATH-l,p->GetItem(i)->Name);//MyStringCat(stack[tot].FullPathAndName,MAX_PATH-1,p->GetItem(i)->Name);
				}
				stack[tot].size = p->GetItem(i)->size;
				stack[tot].attribute = file;
				++tot;
 }	}	}	}
 else if(mDeleteFile==deleteMethod)
 {	for(int i=1; i<p->GetTotItems(); i++)
	{	if(selected==p->GetItem(i)->state || (0==p->GetTotSelects() && i==p->GetHot()))
		{	if(file == p->GetItem(i)->attribute)
			{	if(rndPathList==p->GetEntry()->GetCrntRecType())
				{	
					MyStringCpy(stack[tot].FullPathAndName,MAX_PATH-1,p->GetItem(i)->Name);				
				}
				else
				{	MyStringCpy(stack[tot].Name,MAX_PATH-1,p->GetItem(i)->Name);
					int l=MyStringCpy(stack[tot].FullPathAndName,MAX_PATH-1,p->GetPath());
					if('*'==stack[tot].FullPathAndName[l-1])//MyStringRemoveLastCharCheckPre(stack[tot].FullPathAndName,MAX_PATH-1,'*','\\');
					if('\\'==stack[tot].FullPathAndName[l-2])
						stack[tot].FullPathAndName[--l]=0;
					MyStringCpy(&stack[tot].FullPathAndName[l],MAX_PATH-l,p->GetItem(i)->Name);//MyStringCat(stack[tot].FullPathAndName,MAX_PATH-1,p->GetItem(i)->Name);
				}
				stack[tot].size = p->GetItem(i)->size;
				stack[tot].attribute = file;
				++tot;
			}
			else if(folder == p->GetItem(i)->attribute)
			{	wchar_t pth[MAX_PATH];
				int l=p->GetFullPathAndName(i,pth,MAX_PATH);
				if(listFolders)//Avval folder ichilarini,
				{	pth[l]='\\';//MyStringCat(pth,MAX_PATH-1,"\\*");
					pth[l+1]='*';
					pth[l+2]=0;
					tot += linkSock::SendToServerMsg(p->iThis,LNKSCKMSG_GET_FILES_IN_FOLDER,pth,&stack[tot],1);//folders down, for deleting
					pth[l]=0;
				}//keyin o'zini;
				if(rndPathList==p->GetEntry()->GetCrntRecType())
					MyStringCpy(stack[tot].FullPathAndName,MAX_PATH-1,p->GetItem(i)->Name);				
				else
				{	MyStringCpy(stack[tot].Name,MAX_PATH-1,p->GetItem(i)->Name);
					MyStringCpy(stack[tot].FullPathAndName,MAX_PATH-1,pth);
				}
				stack[tot].attribute = folder;
				++tot;//folderniyam;
 }	}	}	}
 return tot;
}

int GetFilesCntInFolder(wchar_t *path)//reentrance:
{
WIN32_FIND_DATA ff;
HANDLE hf = INVALID_HANDLE_VALUE;

int tot = 0;
wchar_t s[MAX_PATH];
	int l=MyStringCpy(s,MAX_PATH-1,path);
	if('*'==s[l-1])//MyStringRemoveLastCharCheckPre(s,MAX_PATH-1,'*','\\');
	if('\\'==s[l-2])
		s[--l]=0;
	
	hf = MyFindFirstFileEx(path,FindExInfoStandard,&ff,FindExSearchLimitToDirectories,NULL,0);
	do
	{	if(INVALID_HANDLE_VALUE==hf) return tot;
		if(FILE_ATTRIBUTE_DIRECTORY & ff.dwFileAttributes)//if(IsDirectory(path, &ff, FALSE))
		{	if(IsCrntOrPrntDirAttrb(ff.cFileName))
			{	int n=MyStringCpy(&s[l],MAX_PATH-l,ff.cFileName);//MyStringCat(s,MAX_PATH-1,ff.cFileName);
				++tot;//folderniyam;
				s[l+n]='\\';++n;//MyStringCat(s,MAX_PATH-1,"\\*");
				s[l+n]='*';++n;
				s[l+n]=0;
				tot += GetFilesCntInFolder(s);
		}	}
		else
		{	++tot;
	}	}
	while(FindNextFile(hf, &ff));
	FindClose(hf);
	return tot;
}

int GetSelectedFilesCnt(Panel *p,BOOL listFolders,int *fsrtSelIdNum)
{
	int tot=p->GetTotSelects();
	if(!tot)//hot ni kavlaymiz;
	{	int ht=p->GetHot();
		if(ht>0 && ht<p->GetTotItems())
		{	*fsrtSelIdNum = ht;
			if(file == p->GetItem(ht)->attribute)
				return 1;
			else if(folder == p->GetItem(ht)->attribute)
			{	wchar_t pth[MAX_PATH]; 
				int l=p->GetFullPathAndName(ht,pth,MAX_PATH);
				++tot;//folderniyam;
				if(mSHFileOperation!=deleteMethod)
				{	if(listFolders)
					{	pth[l++]='\\';//MyStringCat(pth,MAX_PATH-1,"\\*");
						pth[l++]='*';
						pth[l]=0;
						tot += GetFilesCntInFolder(pth);
			}	}	}
			return tot;
		}
		else return 0;
	}
	tot=0;
	*fsrtSelIdNum = 0;
	tot = 0;
	for(int i=1; i<p->GetTotItems(); i++)
	{	if(selected==p->GetItem(i)->state)
		{	if(*fsrtSelIdNum == 0)
				*fsrtSelIdNum = i;
			if(file == p->GetItem(i)->attribute)
				++tot;
			else if(folder == p->GetItem(i)->attribute)
			{	wchar_t pth[MAX_PATH]; 
				int l=p->GetFullPathAndName(i,pth,MAX_PATH);
				++tot;//folderniyam;
				if(mSHFileOperation!=deleteMethod)
				{	if(listFolders)
					{	pth[l++]='\\';//MyStringCat(pth,MAX_PATH-1,"\\*");
						pth[l++]='*';
						pth[l]=0;
						tot += GetFilesCntInFolder(pth);
	}	}	}	}	}
	return tot;
}

int GetSelectedFilesCntFrSockSrvr(Panel *p,BOOL listFolders,int *fsrtSelIdNum)
{
	int tot=p->GetTotSelects();
	if(!tot)//hot ni kavlaymiz;
	{	int ht=p->GetHot();
		if(ht>0 && ht<p->GetTotItems())
		{	*fsrtSelIdNum = ht;
			if(file == p->GetItem(ht)->attribute)
				return 1;
			else if(folder == p->GetItem(ht)->attribute)
			{	wchar_t pth[MAX_PATH]; 
				int l=p->GetFullPathAndName(ht,pth,MAX_PATH);
				++tot;//folderniyam;
				if(mSHFileOperation!=deleteMethod)
				{	if(listFolders)
					{	pth[l++]='\\';//MyStringCat(pth,MAX_PATH-1,"\\*");
						pth[l++]='*';
						pth[l]=0;
						tot += linkSock::SendToServerMsg(p->iThis,LNKSCKMSG_GET_FILES_CNT_IN_FOLDER,pth);
			}	}	}
			return tot;
		}
		else return 0;
	}
	tot=0;
	*fsrtSelIdNum = 0;
	tot = 0;
	for(int i=1; i<p->GetTotItems(); i++)
	{	if(selected==p->GetItem(i)->state)
		{	if(*fsrtSelIdNum == 0)
				*fsrtSelIdNum = i;
			if(file == p->GetItem(i)->attribute)
				++tot;
			else if(folder == p->GetItem(i)->attribute)
			{	wchar_t pth[MAX_PATH]; 
				int l=p->GetFullPathAndName(i,pth,MAX_PATH);
				++tot;//folderniyam;
				if(mSHFileOperation!=deleteMethod)
				{	if(listFolders)
					{	pth[l++]='\\';//MyStringCat(pth,MAX_PATH-1,"\\*");
						pth[l++]='*';
						pth[l]=0;
						tot += linkSock::SendToServerMsg(p->iThis,LNKSCKMSG_GET_FILES_CNT_IN_FOLDER,pth);
	}	}	}	}	}
	return tot;
}

int CollectSelections(Panel *p,BOOL listFolders, CpyStack** st,int* fsrtSelIdNum)
{
int selCnt=0;
	int s  = p->GetTotSelects();
	if(0==s)
	{	s = p->GetHot();
		if(s<0) return 0;
		selCnt = 1;
	}
	else if(s<1) return 0;
	else selCnt = s;

int realSelCnt;
	if(socketCl==p->GetEntry()->GetCrntRecType())
		realSelCnt = GetSelectedFilesCntFrSockSrvr(p,listFolders,fsrtSelIdNum);
	else if(archElem==p->GetEntry()->GetCrntRecType())
		realSelCnt = archive::GetCpySelectedFilesCnt(p);
	else
		realSelCnt = GetSelectedFilesCnt(p,listFolders,fsrtSelIdNum);

	if(realSelCnt<1) return 0;

	*st = (CpyStack*)malloc(realSelCnt*sizeof(CpyStack));
	if(socketCl==p->GetEntry()->GetCrntRecType())
		GetSelectedFilesFrSockSrvr(p,*st,listFolders);
	else if(archElem==p->GetEntry()->GetCrntRecType())
		archive::GetCpySelectedFiles(*st,p);
	else
		GetSelectedFiles(p,*st,listFolders);
	selCnt = realSelCnt;

	return selCnt;
}

INT_PTR CALLBACK actnDlgProc(HWND hDlg,UINT message,WPARAM wParam,LPARAM lParam)
{
static HFONT hf=0;static int hfRef=0;//obshiy hf, dinamik uchun emas:
static HBRUSH br=0;
static HBRUSH brHtBk=0;
static LPVOID **swToBckgrnd;

	UNREFERENCED_PARAMETER(lParam);
	switch(message)
	{
	case WM_INITDIALOG:
		//OutputDebugString("\nCopyQueueDlgProc WM_INITDIALOG 0");

		//Adjust to center:
		RECT rc; GetWindowRect(hDlg, &rc);
		int width,left,height,top;

		width = rc.right - rc.left;
		left = conf::wndLeft + (conf::wndWidth - width)/2;

		height = rc.bottom - rc.top;
		top = conf::wndTop + (conf::wndHeight - height)/2;
		MoveWindow(hDlg, left, top+20, width, height, TRUE);

		//Load language strings:
		wchar_t s[MAX_PATH];
		LoadString(hInst,IDS_STRINGSW_213,s,MAX_PATH);
		SetWindowText(hDlg,s);
		LoadString(hInst,IDS_STRINGSW_215,s,MAX_PATH);
		SetDlgItemText(hDlg,IDREPEAT,s);
		LoadString(hInst,IDS_STRINGSW_216,s,MAX_PATH);
		SetDlgItemText(hDlg,IDSKIP,s);
		MyStringCat(s,MAX_PATH-1,L" ");
		wchar_t s1[16];
		LoadString(hInst,IDS_STRINGSW_61,s1,MAX_PATH);
		MyStringCat(s,MAX_PATH-1,s1);
		SetDlgItemText(hDlg,IDSKIP_ALL,s);
		LoadString(hInst,IDS_STRINGSW_13,s,MAX_PATH);
		SetDlgItemText(hDlg,IDCANCEL,s);

		//LoadString(hInst,IDS_STRINGSW_214,s,MAX_PATH);
		//SetDlgItemText(hDlg,IDC_STATIC,s);
		if(!lParam) return TRUE;//Agar confDlg dan chaqirilgan b-sa,rang-shriftlarini o'zgartirish uchun;
		LPVOID* par;par = (LPVOID*)lParam;LPVOID lpMsgBuf;		
		FormatMessage(
			FORMAT_MESSAGE_ALLOCATE_BUFFER | 
			FORMAT_MESSAGE_FROM_SYSTEM |
			FORMAT_MESSAGE_IGNORE_INSERTS,
			NULL,
			(DWORD)par[0],//GetLastError() edi;
			MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
			(LPTSTR) &lpMsgBuf,
			0, NULL );
		StringCchPrintf(s,MAX_PATH-1,L"Failed with error %d",(DWORD)par[0]);
		SetDlgItemText(hDlg,IDC_STATIC,s);
		SetDlgItemText(hDlg,IDC_STATIC1,(LPCWSTR)lpMsgBuf);
		LocalFree(lpMsgBuf);

		SendMessage(hDlg,WM_USER+1,0,0);
		SetDlgItemText(hDlg,IDC_EDIT_FILES,(LPCWSTR)par[1]);

		//MyButtonFrRCBtn(hDlg,IDREPEAT,conf::Dlg.iBtnsType);
		//MyButtonFrRCBtn(hDlg,IDCANCEL,conf::Dlg.iBtnsType);
		//MyButtonFrRCBtn(hDlg,IDSKIP_ALL,conf::Dlg.iBtnsType);
		//MyButtonFrRCBtn(hDlg,IDSKIP,conf::Dlg.iBtnsType);

		return TRUE;
	case WM_CTLCOLORSTATIC:
	case WM_CTLCOLORDLG:
		if(2==conf::Dlg.iBtnsType)
		{	HDC dc;dc = (HDC)wParam;
			SetTextColor(dc,conf::Dlg.dlgRGBs[1][1]);
			SetBkColor(dc,conf::Dlg.dlgRGBs[1][2]);
			return (INT_PTR)br;
		}return 0;
	case WM_CTLCOLOREDIT:
		if(2==conf::Dlg.iBtnsType)
		{	HDC dc = (HDC)wParam;
			SetTextColor(dc,conf::Dlg.dlgRGBs[1][1]);
			SetBkColor(dc,conf::Dlg.dlgRGBs[1][2]);
			return (INT_PTR)br;
		}return 0;
	case WM_CTLCOLORBTN:
		if(2==conf::Dlg.iBtnsType)
		{	HDC dc=(HDC)wParam;
			SetTextColor(dc,conf::Dlg.dlgRGBs[1][4]);
			SetBkColor(dc,conf::Dlg.dlgRGBs[1][5]);
			return (INT_PTR)brHtBk;
		}return 0;
	case WM_DRAWITEM://WM_CTLCOLORBTN dagi knopkalar:
		if(2==conf::Dlg.iBtnsType)
		{	LPDRAWITEMSTRUCT lpdis;lpdis = (LPDRAWITEMSTRUCT)lParam;
			GetWindowText(lpdis->hwndItem,s,64);
			UINT uStyle;uStyle = DFCS_BUTTONPUSH;
			rc = lpdis->rcItem;
			if(lpdis->itemState & ODS_SELECTED)
			{	uStyle |= DFCS_PUSHED;
				rc.left+=2;rc.top+=2;
			}
			DrawFrameControl(lpdis->hDC, &lpdis->rcItem, DFC_BUTTON, uStyle);
			if(lpdis->itemState & ODS_SELECTED)
				{rc.left+=1;rc.top+=1;rc.bottom-=2;rc.right-=3;}
			else
				{rc.left+=1;rc.top+=2;rc.bottom-=3;rc.right-=3;}
			FillRect(lpdis->hDC,&rc,brHtBk);//DrawText(lpdis->hDC,"                                                  ",50,&rc,DT_SINGLELINE|DT_VCENTER|DT_INTERNAL|DT_LEFT);
			if(lpdis->itemState & ODS_SELECTED)
				{rc.left-=1;rc.top-=1;rc.bottom+=3;rc.right+=3;}
			else
				{rc.left-=1;rc.top-=2;rc.bottom+=2;rc.right+=3;}
			DrawText(lpdis->hDC,s,MyStringLength(s,64),&rc,DT_SINGLELINE|DT_VCENTER|DT_CENTER);
			return TRUE;
		}return 0;
	case WM_USER+1://hf obshiy uchun, dinamik o'zgartirish uchun emas:
		if(0==hfRef)
		{	hf = CreateFontIndirect(&conf::Dlg.dlgFnts[1]);
			br = CreateSolidBrush(conf::Dlg.dlgRGBs[1][0]);
			brHtBk = CreateSolidBrush(conf::Dlg.dlgRGBs[1][5]);
		}
		SendMessage(GetDlgItem(hDlg,IDC_STATIC),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_STATIC5),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_BUTTON_TO_BACKGROUND_COPY_QUEUE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_BUTTON_STOP),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDCANCEL),WM_SETFONT,(WPARAM)hf,TRUE);
		++hfRef;
		return 0;
	case WM_DESTROY:
		if(--hfRef<1)
		{	DeleteObject(hf);
			DeleteObject(br);
			DeleteObject(brHtBk);
		}
		return 0;
	case WM_COMMAND:static int sx=0;static int sy=0;
		switch(LOWORD(wParam))
		{	case IDREPEAT:
				EndDialog(hDlg,1);
				return (INT_PTR)TRUE;
			case IDSKIP_ALL:
				EndDialog(hDlg,3);
				return (INT_PTR)TRUE;
			case IDSKIP:
				EndDialog(hDlg,2);
				return (INT_PTR)TRUE;
			case IDCANCEL:
				EndDialog(hDlg,0);
				return (INT_PTR)TRUE;
		}
		break;
	}
	return (INT_PTR)FALSE;
}

//Xuddi yuqoridagi, lekin parametrida 2 ta text bor;
INT_PTR CALLBACK actnDlgProc1(HWND hDlg,UINT message,WPARAM wParam,LPARAM lParam)
{
static HFONT hf=0;static int hfRef=0;//obshiy hf, dinamik uchun emas:
static HBRUSH br=0;
static HBRUSH brHtBk=0;
static LPVOID **swToBckgrnd;
static wchar_t RetCar[3] = { 0x0d, 0x0a, 0x00 };

	UNREFERENCED_PARAMETER(lParam);
	switch(message)
	{
	case WM_INITDIALOG:
		//OutputDebugString("\nCopyQueueDlgProc WM_INITDIALOG 0");

		//Adjust to center:
		RECT rc; GetWindowRect(hDlg, &rc);
		int width,left,height,top;

		width = rc.right - rc.left;
		left = conf::wndLeft + (conf::wndWidth - width)/2;

		height = rc.bottom - rc.top;
		top = conf::wndTop + (conf::wndHeight - height)/2;
		MoveWindow(hDlg, left, top+20, width, height, TRUE);

		//Load language strings:
		wchar_t s[MAX_PATH];
		LoadString(hInst,IDS_STRINGSW_213,s,MAX_PATH);
		SetWindowText(hDlg,s);
		LoadString(hInst,IDS_STRINGSW_215,s,MAX_PATH);
		SetDlgItemText(hDlg,IDREPEAT,s);
		LoadString(hInst,IDS_STRINGSW_216,s,MAX_PATH);
		SetDlgItemText(hDlg,IDSKIP,s);
		MyStringCat(s,MAX_PATH-1,L" ");
		wchar_t s1[16];
		LoadString(hInst,IDS_STRINGSW_61,s1,MAX_PATH);
		MyStringCat(s,MAX_PATH-1,s1);
		SetDlgItemText(hDlg,IDSKIP_ALL,s);
		LoadString(hInst,IDS_STRINGSW_13,s,MAX_PATH);
		SetDlgItemText(hDlg,IDCANCEL,s);

		//LoadString(hInst,IDS_STRINGSW_214,s,MAX_PATH);
		//SetDlgItemText(hDlg,IDC_STATIC,s);
		if(!lParam) return TRUE;//Agar confDlg dan chaqirilgan b-sa,rang-shriftlarini o'zgartirish uchun;
		LPVOID* par;par = (LPVOID*)lParam;LPVOID lpMsgBuf;		
		FormatMessage(
			FORMAT_MESSAGE_ALLOCATE_BUFFER | 
			FORMAT_MESSAGE_FROM_SYSTEM |
			FORMAT_MESSAGE_IGNORE_INSERTS,
			NULL,
			(DWORD)par[0],//GetLastError() edi;
			MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
			(LPTSTR) &lpMsgBuf,
			0, NULL );
		StringCchPrintf(s,MAX_PATH-1,L"Failed with error %d",(DWORD)par[0]);
		SetDlgItemText(hDlg,IDC_STATIC,s);
		SetDlgItemText(hDlg,IDC_STATIC1,(LPCWSTR)lpMsgBuf);
		LocalFree(lpMsgBuf);

		SendMessage(hDlg,WM_USER+1,0,0);

		SendMessage(GetDlgItem(hDlg,IDC_EDIT_FILES),EM_REPLACESEL,(WPARAM)FALSE,(LPARAM)par[1]);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_FILES),EM_REPLACESEL,(WPARAM)FALSE,(LPARAM)(LPCSTR)RetCar);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_FILES),EM_SCROLLCARET,(WPARAM)0, (LPARAM)0);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_FILES),EM_REPLACESEL,(WPARAM)FALSE,(LPARAM)par[2]);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_FILES),EM_REPLACESEL,(WPARAM)FALSE,(LPARAM)(LPCSTR)RetCar);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_FILES),EM_SCROLLCARET,(WPARAM)0, (LPARAM)0);
		return TRUE;
	case WM_CTLCOLORSTATIC:
	case WM_CTLCOLORDLG:HDC dc;dc = (HDC)wParam;
		SetTextColor(dc,conf::Dlg.dlgRGBs[1][1]);
		SetBkColor(dc,conf::Dlg.dlgRGBs[1][2]);
		return (INT_PTR)br;
	case WM_CTLCOLOREDIT:dc = (HDC)wParam;
		SetTextColor(dc,conf::Dlg.dlgRGBs[1][1]);
		SetBkColor(dc,conf::Dlg.dlgRGBs[1][2]);
		return (INT_PTR)br;
	case WM_CTLCOLORBTN:dc=(HDC)wParam;
		SetTextColor(dc,conf::Dlg.dlgRGBs[1][4]);
		SetBkColor(dc,conf::Dlg.dlgRGBs[1][5]);
		return (INT_PTR)brHtBk;
	case WM_DRAWITEM://WM_CTLCOLORBTN dagi knopkalar:
		LPDRAWITEMSTRUCT lpdis;lpdis = (LPDRAWITEMSTRUCT)lParam;
		GetWindowText(lpdis->hwndItem,s,64);
		UINT uStyle;uStyle = DFCS_BUTTONPUSH;
		rc = lpdis->rcItem;
		if(lpdis->itemState & ODS_SELECTED)
		{	uStyle |= DFCS_PUSHED;
			rc.left+=2;rc.top+=2;
		}
		DrawFrameControl(lpdis->hDC, &lpdis->rcItem, DFC_BUTTON, uStyle);
		if(lpdis->itemState & ODS_SELECTED)
			{rc.left+=1;rc.top+=1;rc.bottom-=2;rc.right-=3;}
		else
			{rc.left+=1;rc.top+=2;rc.bottom-=3;rc.right-=3;}
		FillRect(lpdis->hDC,&rc,brHtBk);//DrawText(lpdis->hDC,"                                                  ",50,&rc,DT_SINGLELINE|DT_VCENTER|DT_INTERNAL|DT_LEFT);
		if(lpdis->itemState & ODS_SELECTED)
			{rc.left-=1;rc.top-=1;rc.bottom+=3;rc.right+=3;}
		else
			{rc.left-=1;rc.top-=2;rc.bottom+=2;rc.right+=3;}
		DrawText(lpdis->hDC,s,MyStringLength(s,64),&rc,DT_SINGLELINE|DT_VCENTER|DT_CENTER);
		return TRUE;
	case WM_USER+1://hf obshiy uchun, dinamik o'zgartirish uchun emas:
		if(0==hfRef)
		{	hf = CreateFontIndirect(&conf::Dlg.dlgFnts[1]);
			br = CreateSolidBrush(conf::Dlg.dlgRGBs[1][0]);
			brHtBk = CreateSolidBrush(conf::Dlg.dlgRGBs[1][5]);
		}
		SendMessage(GetDlgItem(hDlg,IDC_STATIC),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_STATIC5),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_BUTTON_TO_BACKGROUND_COPY_QUEUE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_BUTTON_STOP),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDCANCEL),WM_SETFONT,(WPARAM)hf,TRUE);
		++hfRef;
		return 0;
	case WM_DESTROY:
		if(--hfRef<1)
		{	DeleteObject(hf);
			DeleteObject(br);
			DeleteObject(brHtBk);
		}
		return 0;
	case WM_COMMAND:static int sx=0;static int sy=0;
		switch(LOWORD(wParam))
		{	case IDREPEAT:
				EndDialog(hDlg,1);
				return (INT_PTR)TRUE;
			case IDSKIP_ALL:
				EndDialog(hDlg,3);
				return (INT_PTR)TRUE;
			case IDSKIP:
				EndDialog(hDlg,2);
				return (INT_PTR)TRUE;
			case IDCANCEL:
				EndDialog(hDlg,0);
				return (INT_PTR)TRUE;
		}
		break;
	}
	return (INT_PTR)FALSE;
}

VOID deleteExThrdFnc(LPVOID *par)
{	
	CpyStack *stack(NULL);
	HWND dlg = (HWND)par[3];//(HWND*)(((LPVOID*)lpvData)[0] = par[3]);//Dlg
	BOOL bSfhtDel = (BOOL)par[1];//Delete or shift+delete
	Panel* p = (Panel*)par[0];//par[3]}; par[2]-sw to bckgrnd;
	/*LPVOID lpvData = (LPVOID*)LocalAlloc(LPTR, 32);
	if(!TlsSetValue(dwTlsIndex, lpvData))
	{	Err::FlipMsg("TlsSetValue error",2500);
		ExitThread(0);
		return;
	}*/
	if(socketCl==p->GetEntry()->GetCrntRecType())
	{	if(linkSock::accessType[p->iThis]<1)//only read;
		{	SendMessage(dlg,WM_USER+4,0,0);//DestroyWindow(dlg);//can't destroy wnd in different thread;
			Err::msg(p->GetHWND(),0,L"Access write deneeded.");
			ExitThread(0);
	}	}
 
	int frstSel=0,ih = p->GetHot();
	int selCnt = CollectSelections(p,TRUE,&stack,&frstSel);
	if(!selCnt)
		goto End;
	p->FreeSelection();
	p->SetHot(frstSel);

	if(bSfhtDel || archElem==p->GetEntry()->GetCrntRecType())
	{	if(!AskForDelete(selCnt,stack))
			goto End;
	}

	PostMessage(GetDlgItem(dlg,IDC_PROGRESS_COPY_TOTAL ),PBM_SETPOS,0,0);
	BOOL bSkipAll=FALSE;

	if(archElem==p->GetEntry()->GetCrntRecType())
	{	if(archive::plgns[p->GetArch()->plgNum].hm)
			archive::plgns[p->GetArch()->plgNum].Close$4(p->GetArch()->plgObj);
		p->GetArch()->plgObj=0;
		p->GetArch()->Open$12(p->GetArch()->name,p->GetArch()->plgNum,2);//opn exstng
	}

	for(int i=0; i<selCnt; i++)//ExecDeleteToRecycler();
	{	PostMessage(GetDlgItem(dlg,IDC_PROGRESS_COPY_SINGLE ),PBM_SETPOS,0,0);
		if(bSfhtDel)
		{	//File:
			if(file==stack[i].attribute)
			{	
LoopDelete:		BOOL r;
				if(socketCl==p->GetEntry()->GetCrntRecType())
				{
					r = linkSock::SendToServerMsg(p->iThis,LNKSCKMSG_DeleteFile,stack[i].FullPathAndName) && (!bSkipAll);
				}
				else if(archElem==p->GetEntry()->GetCrntRecType())
				{
					r = p->GetArch()->Delete$8(p->GetArcItPathAndName(stack[i].Name),FALSE) && (!bSkipAll);
				}
				else
				{	r = DeleteFile(stack[i].FullPathAndName) && (!bSkipAll);
					if(!r)
					{	r=MySHFileOperation(FO_DELETE,stack[i].FullPathAndName,NULL,
									FOF_SILENT|FOF_NOCONFIRMATION|FOF_NOCONFIRMMKDIR,FALSE);
						if(!r)
						{	r=MySHFileOperation(FO_DELETE,stack[i].FullPathAndName,NULL,
								FOF_ALLOWUNDO|FOF_SILENT|FOF_NOCONFIRMATION|FOF_NOCONFIRMMKDIR,FALSE);
							if(!r)
								r=MyDeleteTryUnicode(dlg,&stack[i]);
				}	}	}
				if(!r)
				{	//MySHFileOperation(FO_DELETE,stack[i].FullPathAndName,NULL,0);
					LPVOID* par[2]={(LPVOID*)GetLastError(),(LPVOID*)stack[i].FullPathAndName};
					int r = (int)DialogBoxParam(hInst,MAKEINTRESOURCE(IDD_DIALOG_CHOISE_ACTION),dlg,actnDlgProc,(LPARAM)par);
					if(0==r) goto End;//Cancel action;
					if(1==r) goto LoopDelete;
					if(3==r) bSkipAll=TRUE;//2-skip,3-skipAll;
			}	}
			//Directory:
			else if(folder==stack[i].attribute)
			{	
LoopRemove:		BOOL r;
				if(socketCl==p->GetEntry()->GetCrntRecType())
				{	r = linkSock::SendToServerMsg(p->iThis,LNKSCKMSG_RemoveDirectory,stack[i].FullPathAndName) && (!bSkipAll);
				}
				else if(archElem==p->GetEntry()->GetCrntRecType())
				{
					r = p->GetArch()->Delete$8(p->GetArcItPathAndName(stack[i].Name),TRUE) && (!bSkipAll);
				}
				else
				{
					r = RemoveDirectory(stack[i].FullPathAndName) && (!bSkipAll);
				}

				if(!r)
				{	//MySHFileOperation(FO_DELETE,stack[i].FullPathAndName,NULL,
					//					FOF_SIMPLEPROGRESS,TRUE);//FOF_NOCONFIRMATION//FOF_WANTNUKEWARNING
					LPVOID* par[2]={(LPVOID*)GetLastError(),(LPVOID*)stack[i].FullPathAndName};
					int r = (int)DialogBoxParam(hInst,MAKEINTRESOURCE(IDD_DIALOG_CHOISE_ACTION),dlg,actnDlgProc,(LPARAM)par);
					if(0==r) goto End;//Cancel action;
					if(1==r) goto LoopRemove;
					if(3==r) bSkipAll=TRUE;//2-skip,3-skipAll;
		}	}	}
		else if(archElem==p->GetEntry()->GetCrntRecType())
		{
			p->GetArch()->Delete$8(p->GetArcItPathAndName(stack[i].Name),folder==stack[i].attribute) && (!bSkipAll);
		}
		else
		{	MySHFileOperation(FO_DELETE,stack[i].FullPathAndName,NULL,
				FOF_ALLOWUNDO|FOF_SILENT|FOF_NOCONFIRMATION|FOF_NOCONFIRMMKDIR,FALSE);
		}

		PostMessage(GetDlgItem(dlg,IDC_PROGRESS_COPY_SINGLE),PBM_SETPOS,1000,0);
		if(selCnt>0)
			PostMessage(GetDlgItem(dlg,IDC_PROGRESS_COPY_TOTAL),PBM_SETPOS,i*1000/selCnt,0);

Loop:
		BOOL bStop=FALSE; MSG msg;//Only thread message:
		if(PeekMessage(&msg,(HWND)-1,MYWM_CANCEL-1,MYWM_CANCEL+10,PM_REMOVE))
		{		
			switch(msg.message)
			{	case MYWM_CANCEL:
					goto End;
				case MYWM_STOP:
					wchar_t s[MAX_PATH];
					if(bStop)
					{	LoadString(hInst,IDS_STRINGSW_50,s,MAX_PATH);
						SetDlgItemText(dlg,IDC_BUTTON_STOP,s);
						bStop = FALSE;
					}
					else
					{	LoadString(hInst,IDS_STRINGSW_3,s,MAX_PATH);
						SetDlgItemText(dlg,IDC_BUTTON_STOP,s);
						bStop = TRUE;
						Sleep(250);
						goto Loop;
					}
					break;
 		}	}
		else if(bStop)
		{	Sleep(250);
			goto Loop;
	 }	}

End:

	if(archElem==p->GetEntry()->GetCrntRecType())
	{	p->GetArch()->Close$4();
		p->GetArch()->OpenForUnpacking$8(p->GetArch()->name,p->GetArch()->plgNum);
	}

	if(stack)free(stack);
	PostMessage(dlg,WM_USER+4,0,0);//DestroyWindow(dlg);//can't destroy wnd in different thread;
	//lpvData = TlsGetValue(dwTlsIndex);
	//if(lpvData != 0)
	//	LocalFree((HLOCAL)lpvData);
	if(socketCl==p->GetEntry()->GetCrntRecType())
		linkSock::SendToServerMsg(p->iThis,LNKSCKMSG_ON_DIRECTORY_CHANGE_NOTIFY,p->GetPath());
	ExitThread(0);
}

INT_PTR CALLBACK DeleteQueueDlgProc(HWND hDlg,UINT message,WPARAM wParam,LPARAM lParam)
{
static HFONT hf=0;static int hfRef=0;//obshiy hf, dinamik uchun emas:
static HBRUSH br=0;
static HBRUSH brHtBk=0;
static LPVOID **swToBckgrnd;

	UNREFERENCED_PARAMETER(lParam);
	switch(message)
	{
	case WM_INITDIALOG:
		//OutputDebugString("\nCopyQueueDlgProc WM_INITDIALOG 0");

		//Adjust to center:
		RECT rc; GetWindowRect(hDlg, &rc);
		int width,left,height,top;

		width = rc.right - rc.left;
		left = conf::wndLeft + (conf::wndWidth - width)/2;

		height = rc.bottom - rc.top;
		top = conf::wndTop + (conf::wndHeight - height)/2;
		MoveWindow(hDlg, left, top+20, width, height, TRUE);

		//Load language strings:
		wchar_t s[MAX_PATH];
		LoadString(hInst,IDS_STRINGSW_203,s,MAX_PATH);//46
		SetWindowText(hDlg,s);
		//LoadString(hInst,IDS_STRINGSW_47,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_STATIC,s);
		LoadString(hInst,IDS_STRINGSW_48,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_STATIC5,s);
		LoadString(hInst,IDS_STRINGSW_49,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_BUTTON_TO_BACKGROUND_COPY_QUEUE,s);
		LoadString(hInst,IDS_STRINGSW_50,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_BUTTON_STOP,s);
		LoadString(hInst,IDS_STRINGSW_13,s,MAX_PATH);
		SetDlgItemText(hDlg,IDCANCEL,s);

		PostMessage(GetDlgItem(hDlg,IDC_PROGRESS_COPY_SINGLE),PBM_SETRANGE,0,MAKELPARAM(0,1000));
		PostMessage(GetDlgItem(hDlg,IDC_PROGRESS_COPY_TOTAL ),PBM_SETRANGE,0,MAKELPARAM(0,1000));
		PostMessage(GetDlgItem(hDlg,IDC_PROGRESS_COPY_SINGLE),PBM_SETSTEP,1,0);
		PostMessage(GetDlgItem(hDlg,IDC_PROGRESS_COPY_TOTAL ),PBM_SETSTEP,1,0);

		SendMessage(hDlg,WM_USER+1,0,0);
		if(!lParam) return TRUE;//Agar confDlg dan chaqirilgan b-sa,rang-shriftlarini o'zgartirish uchun;

		DWORD cpyThrdId;LPVOID** par;par=(LPVOID**)lParam;par[3]=(LPVOID*)hDlg;
		par[4]=(LPVOID*)CreateThread(NULL,1024,(LPTHREAD_START_ROUTINE)deleteExThrdFnc,
							par,0,&cpyThrdId);
		if(!par[4])
		{	Err::FlipMsg(L"Create delete thread error.",2500);
			EndDialog(hDlg,0);//DestroyWindow(hDlg);
		}
		SetWindowLong(hDlg,GWLP_USERDATA,cpyThrdId);
		swToBckgrnd = &par[2];

		//MyButtonFrRCBtn(hDlg,IDC_BUTTON_TO_BACKGROUND_COPY_QUEUE,conf::Dlg.iBtnsType);
		//MyButtonFrRCBtn(hDlg,IDC_BUTTON_STOP,conf::Dlg.iBtnsType);
		//MyButtonFrRCBtn(hDlg,IDCANCEL,conf::Dlg.iBtnsType);

		return TRUE;
	case WM_CTLCOLORSTATIC:
	case WM_CTLCOLORDLG:
		if(2==conf::Dlg.iBtnsType)
		{	HDC dc;dc = (HDC)wParam;
			SetTextColor(dc,conf::Dlg.dlgRGBs[1][1]);
			SetBkColor(dc,conf::Dlg.dlgRGBs[1][2]);
			return (INT_PTR)br;
		}return 0;
	case WM_CTLCOLOREDIT:
		if(2==conf::Dlg.iBtnsType)
		{	HDC dc = (HDC)wParam;
			SetTextColor(dc,conf::Dlg.dlgRGBs[1][1]);
			SetBkColor(dc,conf::Dlg.dlgRGBs[1][2]);
			return (INT_PTR)br;
		}return 0;
	case WM_CTLCOLORBTN:
		if(2==conf::Dlg.iBtnsType)
		{	HDC dc=(HDC)wParam;
			SetTextColor(dc,conf::Dlg.dlgRGBs[1][4]);
			SetBkColor(dc,conf::Dlg.dlgRGBs[1][5]);
			return (INT_PTR)brHtBk;
		}return 0;
	case WM_DRAWITEM://WM_CTLCOLORBTN dagi knopkalar:
		if(2==conf::Dlg.iBtnsType)
		{	LPDRAWITEMSTRUCT lpdis;lpdis = (LPDRAWITEMSTRUCT)lParam;
			GetWindowText(lpdis->hwndItem,s,64);
			UINT uStyle;uStyle = DFCS_BUTTONPUSH;
			rc = lpdis->rcItem;
			if(lpdis->itemState & ODS_SELECTED)
			{	uStyle |= DFCS_PUSHED;
				rc.left+=2;rc.top+=2;
			}
			DrawFrameControl(lpdis->hDC, &lpdis->rcItem, DFC_BUTTON, uStyle);
			if(lpdis->itemState & ODS_SELECTED)
				{rc.left+=1;rc.top+=1;rc.bottom-=2;rc.right-=3;}
			else
				{rc.left+=1;rc.top+=2;rc.bottom-=3;rc.right-=3;}
			FillRect(lpdis->hDC,&rc,brHtBk);//DrawText(lpdis->hDC,"                                                  ",50,&rc,DT_SINGLELINE|DT_VCENTER|DT_INTERNAL|DT_LEFT);
			if(lpdis->itemState & ODS_SELECTED)
				{rc.left-=1;rc.top-=1;rc.bottom+=3;rc.right+=3;}
			else
				{rc.left-=1;rc.top-=2;rc.bottom+=2;rc.right+=3;}
			DrawText(lpdis->hDC,s,MyStringLength(s,64),&rc,DT_SINGLELINE|DT_VCENTER|DT_CENTER);
			return TRUE;
		}return 0;
	case WM_USER+1://hf obshiy uchun, dinamik o'zgartirish uchun emas:
		if(0==hfRef)
		{	hf = CreateFontIndirect(&conf::Dlg.dlgFnts[1]);
			br = CreateSolidBrush(conf::Dlg.dlgRGBs[1][0]);
			brHtBk = CreateSolidBrush(conf::Dlg.dlgRGBs[1][5]);
		}
		SendMessage(GetDlgItem(hDlg,IDC_STATIC),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_STATIC5),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_BUTTON_TO_BACKGROUND_COPY_QUEUE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_BUTTON_STOP),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDCANCEL),WM_SETFONT,(WPARAM)hf,TRUE);
		++hfRef;
		return 0;
	case WM_USER+4://from thread, close notify:
		EndDialog(hDlg,0);//DestroyWindow(hDlg);
		return 0;
	case WM_DESTROY:
		if(--hfRef<1)
		{	DeleteObject(hf);
			DeleteObject(br);
			DeleteObject(brHtBk);
		}
		return 0;
	case WM_COMMAND:static int sx=0;static int sy=0;
		switch(LOWORD(wParam))
		{	case IDC_BUTTON_TO_BACKGROUND_COPY_QUEUE://cpyThrdId - GWLP_USERDATA
				//DWORD thdId = GetWindowLong(hDlg,GWLP_USERDATA);
				RECT rc; GetWindowRect(hDlg, &rc);
				MoveWindow(hDlg,sx,sy,rc.right-rc.left,rc.bottom-rc.top,TRUE);
				sy+=25;if(sy>800){sy=0;sx+=25;if(sx>1024)sx=0;}
				*swToBckgrnd = (LPVOID*)1;//Buni chaqirgan proc uchun;
				return (INT_PTR)TRUE;
			case IDC_BUTTON_STOP://cpyThrdId - GWLP_USERDATA
				PostThreadMessage(GetWindowLong(hDlg,GWLP_USERDATA),MYWM_STOP,0,0);
				return (INT_PTR)TRUE;
			case IDCANCEL://cpyThrdId - GWLP_USERDATA
				PostThreadMessage(GetWindowLong(hDlg,GWLP_USERDATA),MYWM_CANCEL,0,0);
				EndDialog(hDlg,0);//DestroyWindow(hDlg);
				return (INT_PTR)TRUE;
		}
		break;
	}
	return (INT_PTR)FALSE;
}

BOOL Delete(Panel *p, BOOL toRecycle)
{
	if(p->GetTotSelects()==0)
	if(p->GetHot()<1 || p->GetHot()>p->GetTotItems()-1)
		return TRUE;

//method : delete, not switch to background, dlg, thread handle;
	LPVOID* par[5]={(LPVOID*)p,
					reinterpret_cast<LPVOID*>(toRecycle?1:0),
					(LPVOID*)0,
					(LPVOID*)0,
					(LPVOID*)0};
	DialogBoxParam(hInst,MAKEINTRESOURCE(IDD_DIALOG_COPY_QUEUE),
				   hWnd,DeleteQueueDlgProc,(LPARAM)par);
	if(archElem==p->GetEntry()->GetCrntRecType())//ChangeNotify qilishi kerak narsa:
	{	p->FreeMem();//p->FreeSelection(); shartmas
		p->FillArchItems(p->GetEntry()->GetCrntRecArchPath());
		p->ChangeSheetTabPath();
		p->AdjustScrollity();
		p->ScrollItemToView(p->GetHot());
		p->ClrScr();
		p->Render(NULL);
	}
	p->SetFocus();
	return TRUE;
}


}//end of namespace fDelOper