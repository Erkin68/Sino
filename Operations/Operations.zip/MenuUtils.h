#ifndef _MENU_UTILS_H
#define _MENU_UTILS_H

#include "windows.h"
#include "..\config.h"


class CMnuUtPlgn;
namespace menuUtils
{
	typedef const int (*GetPluginType_t)();
	typedef VOID (*SetCallbacks$4xxx_t)(LPVOID,...);
	typedef VOID (*SetId$4_t)(int);
	typedef const wchar_t* (*GetPluginDescription_t)();
	typedef VOID (*ShowOptionDialog_t)();
	typedef BOOL (*Run$4_t)(HWND prnt);
	typedef const wchar_t* (*GetPluginName_t)();
	typedef int (*GetMenuNum_t)();
	typedef int (*GetMenuPos_t)();
	typedef const wchar_t* (*GetMenuItemText_t)();
	typedef const wchar_t* (*GetMenuText_t)();

	extern BOOL IsKeyExist(int);
	extern VOID FreePlugins();
	extern VOID LoadPlugins(HWND);
	extern VOID TryLoadPlugin(wchar_t*,wchar_t*);
	extern BOOL SetMenusInStartup(HWND);
	extern BOOL Run$4(HWND,int);
	extern BOOL RunFromName(HWND,wchar_t*);
	extern BOOL CheckKeys(HWND,conf::STKey*);
	extern BOOL CheckFromMenuId(HWND,WPARAM);

	extern CMnuUtPlgn *plgns;
	extern int numPlugins;
}

class CMnuUtPlgn
{
public:

//First public functns for calling from plugins:
static BOOL   CALLBACK saveOptions(int,VOID*,int);
static BOOL   CALLBACK readOptions(int,VOID*,int);
static int    CALLBACK getTotPanels();
static int    CALLBACK getCrntPanelNum();
static wchar_t *CALLBACK getPanelPath(int);
static BOOL   CALLBACK getPanelCrntItem(int,WIN32_FIND_DATA*);
static LPVOID CALLBACK getPanelSelectedItems(int,int*);
static unsigned __int64* CALLBACK CMnuUtPlgn::GetLogicalDriveSpace(int);
//static VOID CALLBACK MayFreePluginDll(int);



	CMnuUtPlgn();
	~CMnuUtPlgn();
	HMODULE hm;
	//int	dllSize;
	wchar_t pathAndName[MAX_PATH],descrpn[MAX_PATH],extnsn[16],mnuTxt[32];
	int  type,idNum,mnuIdNum,mnuPos;
	BOOL bOpen;
	conf::TKey key;

	BOOL LoadPlugin();
	VOID FreePlugin();

	menuUtils::GetPluginType_t GetPluginType;
	menuUtils::SetCallbacks$4xxx_t SetCallbacks$4xxx;
	menuUtils::SetId$4_t SetId$4;
	menuUtils::GetPluginDescription_t GetPluginDescription;
	menuUtils::ShowOptionDialog_t ShowOptionDialog;
	menuUtils::Run$4_t Run$4;
	menuUtils::GetPluginName_t GetPluginName;
	menuUtils::GetMenuNum_t GetMenuNum;
	menuUtils::GetMenuPos_t GetMenuPos;
	menuUtils::GetMenuItemText_t GetMenuItemText;
	menuUtils::GetMenuText_t GetMenuText;
};

#endif
