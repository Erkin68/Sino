#ifndef _RENMOVE_H_
#define _RENMOVE_H_


#include "windows.h"
#include "CopyOperation.h"


class Panel;
namespace fRenMove
{
	extern BOOL	ShowCopyDlg(Panel*);
	extern BOOL	FillCopyFilesInfo(HWND,LPARAM,int);
	extern int		GetSelectedFiles(CpyStack*);
	extern int		GetSelectedFilesCnt();
	extern unsigned __int64 GetSelectedFilesToDlg(HWND,HWND);

	typedef enum
	{	unchange,     //use asterics('\'+'*'+'0') symbol at the end;
		rename1File,  //1 ta fayl,  u ham bo'lsa nomini o'zgartirish kerak;
		rename1Folder,//1 ta folder,u ham bo'lsa nomini o'zgartirish kerak;
		allToRenFolder//hammasini 1 ta yangi folderga tiqish kerak;
	} SrcType;
	typedef enum												 //kerak bo'lsa!!!
	{	single,
		addToBack
	} CopyType;
	typedef enum
	{	mMoveFileWithProgress,
		mSHFileOperation
	} CopyMethod;
	extern SrcType srcType;
	extern CopyType copyType;
	extern CopyMethod copyMethod;

	extern int srcPanel,destPanel,srcCnt,srcDirCnt;
	extern unsigned __int64 srcSz,copySrcSz,avDstSz;
	extern wchar_t	destPath[MAX_PATH];//agar 1- ning nomi o'zgartirilishi
};

#endif
