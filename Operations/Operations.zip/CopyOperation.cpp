#include "shlobj.h"
#include "strsafe.h"
#include "..\Sino.h"
#include "..\Config.h"
#include "LinkSocket.h"
#include "MyErrors.h"
#include "MyShell\MyShell.h"
//#include "MyShell\MyButtonC++.h"
#include "DeleteOperation.h"
#include "Backgrnd thread copy operation.h"
#include "..\WindowsManagmentInstrumentation.h"



BOOL SelectListBoxItems(HWND hLB,int bSelect)//0-select,1-unselect
{	if(LB_ERR==SendMessage(hLB,LB_SELITEMRANGE,0==bSelect?TRUE:FALSE,
			MAKELPARAM(0,SendMessage(hLB,LB_GETCOUNT,0,0))))
		return FALSE;
	return TRUE;
}
BOOL EraseFilesFrLB(HWND hLB,int bSelect)//0-all,1-selected
{	wchar_t s[MAX_PATH];
	int iTot=(int)SendMessage(hLB,LB_GETCOUNT,0,0);
	if(1==bSelect)
	{	int iSel=(int)SendMessage(hLB,LB_GETSELCOUNT,0,0);
		if(LB_ERR==iSel)return FALSE;
		int *pSels=(int*)malloc(iSel*sizeof(int));
		if(!pSels)return FALSE;
		if(LB_ERR!=SendMessage(hLB,LB_GETSELITEMS,iSel,(LPARAM)pSels))
		{	for(int i=0; i<iSel; ++i)
			{	if(LB_ERR!=SendMessage(hLB,LB_GETTEXT,pSels[i],(LPARAM)s))
				{	if(!DeleteFile(s))
					{	if(!MySHFileOperation(FO_DELETE,s,NULL,
								FOF_SILENT|FOF_NOCONFIRMATION|FOF_NOCONFIRMMKDIR,FALSE))
							MySHFileOperation(FO_DELETE,s,NULL,
								FOF_ALLOWUNDO|FOF_SILENT|FOF_NOCONFIRMATION|FOF_NOCONFIRMMKDIR,FALSE);
		}	}	}	}
		free(pSels);
		return TRUE;
	}//else
	for(int i=0; i<iTot; ++i)
	{	if(LB_ERR!=SendMessage(hLB,LB_GETTEXT,i,(LPARAM)s))
		{	if(!DeleteFile(s))
			{	if(!MySHFileOperation(FO_DELETE,s,NULL,
						FOF_SILENT|FOF_NOCONFIRMATION|FOF_NOCONFIRMMKDIR,FALSE))
					MySHFileOperation(FO_DELETE,s,NULL,
						FOF_ALLOWUNDO|FOF_SILENT|FOF_NOCONFIRMATION|FOF_NOCONFIRMMKDIR,FALSE);
	}	}	}
	return TRUE;
}

namespace fCopyOper
{

#define MYWM_CANCEL		 0x7f00
#define MYWM_STOP		 0x7f01
#define MYWM_GOTOBCKGRND 0x7f02


int		srcPanel,destPanel,srcCnt;
unsigned __int64 srcSz,copySrcSz,avDstSz;
wchar_t	 destPath[MAX_PATH]=L"";
SrcType srcType;
CopyType copyType;
CopyMethod copyMethod(mCopyFileEx);


HHOOK copyDlgHook;
LRESULT CALLBACK GetMsgProc(int nCode, WPARAM wParam, LPARAM lParam) 
{ 
/*MSG* msg = (MSG*)lParam;
	if(WM_CHAR==msg->message)
	{	if(0x3==msg->wParam)
		{	if(msg->lParam & 0x00200000)
				PostMessage(GetParent(msg->hwnd),WM_USER,1,(LPARAM)msg->hwnd);//Ctrl+C
		} else if(0x16==msg->wParam)
		{	if(msg->lParam & 0x00200000)
				PostMessage(GetParent(msg->hwnd),WM_USER,2,(LPARAM)msg->hwnd);//Ctrl+V
	}	}*/
    return CallNextHookEx(copyDlgHook, nCode, wParam, lParam);
} 

//Qaysi paneldan qaysisga, shuni aniqlab, yo'llarini to'g'rilaydi:
BOOL FillCopyFilesInfo(HWND hDlg, LPARAM lParam,int iPanSel)
{
wchar_t s[MAX_PATH];

	int numAllowedDestPanels = conf::Dlg.iTotPanels-1;
	destPanel = ((Panel*)lParam)->iOpponent;
	if(1==numAllowedDestPanels)
	{	ShowWindow(GetDlgItem(hDlg,IDC_COPY_STATIC_3),SW_HIDE);
		ShowWindow(GetDlgItem(hDlg,IDC_COMBO_PANEL),SW_HIDE);
		SetDlgItemText(hDlg,IDC_EDIT_DEST_PATH,panel[destPanel].GetPath());
	}
	else if(2==numAllowedDestPanels)
	{	for(int i=0; i<3; ++i)
		{	if(i!=((Panel*)lParam)->iThis)
			{	StringCchPrintf(s,4,L"%d",i+1);
				SendMessage(GetDlgItem(hDlg,IDC_COMBO_PANEL),CB_INSERTSTRING,(WPARAM)-1,(LPARAM)s);
		}	}
		StringCchPrintf(s,4,L"%d",destPanel+1);
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_PANEL),CB_SETCURSEL,iPanSel,0);
		//SetDlgItemText(hDlg,IDC_EDIT_DEST_PATH,panel[destPanel].path);
		SendMessage(hDlg,WM_COMMAND,MAKELONG(IDC_COMBO_PANEL,CBN_SELCHANGE),0);
	}
	else if(3==numAllowedDestPanels)
	{	for(int i=0; i<4; ++i)
		{	if(i!=((Panel*)lParam)->iThis)
			{	StringCchPrintf(s,4,L"%d",i+1);
				SendMessage(GetDlgItem(hDlg,IDC_COMBO_PANEL),CB_INSERTSTRING,(WPARAM)-1,(LPARAM)s);
		}	}
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_PANEL),CB_SETCURSEL,iPanSel,0);
		//SetDlgItemText(hDlg,IDC_EDIT_DEST_PATH,panel[destPanel].path);
		SendMessage(hDlg,WM_COMMAND,MAKELONG(IDC_COMBO_PANEL,CBN_SELCHANGE),0);
	}
int r;
	srcPanel = ((Panel*)lParam)->iThis;
	srcCnt = panel[srcPanel].GetTotSelects();
	if(srcCnt<1)
	{	int id = panel[srcPanel].GetHot();
		if(id<1 && id>panel[srcPanel].GetTotItems())
		{	MessageBox(NULL,L"Please, select any files for copy, then try to copy...", L"Warn.",MB_OK|MB_ICONWARNING|MB_SYSTEMMODAL);
			return FALSE;
		}
		if(archElem==panel[destPanel].GetEntry()->GetCrntRecType())
			r=MyStringCpy(s,MAX_PATH-1,panel[destPanel].GetArcItFullPathAndName(0));
		else
			r=panel[destPanel].GetPath(s);
		if('*'==s[r-1] && '\\'==s[r-2])
			s[--r]=0;
		else if('\\'!=s[r-1])
			s[r++]='\\';
		MyStringCpy(&s[r],MAX_PATH-r,panel[srcPanel].GetItem(id)->Name);
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_FILES_TO_COPY),CB_INSERTSTRING,(WPARAM)-1,
			(LPARAM)&s[r]);//panel[srcPanel].GetItem(id)->Name);
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_FILES_TO_COPY),WM_SETTEXT,0,(LPARAM)&s[r+1]);//panel[srcPanel].GetItem(id)->Name);
		r=(int)SendMessage(GetDlgItem(hDlg,IDC_COMBO_FILES_TO_COPY),CB_SETEDITSEL,-1,(LPARAM)MAKELONG(0,-1));

		if(archElem==panel[destPanel].GetEntry()->GetCrntRecType())
			SendMessage(GetDlgItem(hDlg,IDC_EDIT_DEST_ARCHIVE),CB_ADDSTRING,0,(LPARAM)s);
		SetDlgItemText(hDlg,IDC_EDIT_DEST_PATH,s);
		srcCnt = 1;
	}
	else
	{	for(int i=0; i<panel[srcPanel].GetTotItems(); i++)
		{	if(selected==panel[srcPanel].GetItem(i)->state)
			{	SendMessage(GetDlgItem(hDlg,IDC_COMBO_FILES_TO_COPY),CB_INSERTSTRING,(WPARAM)-1,
					(LPARAM)panel[srcPanel].GetItem(i)->Name);
				if(!i)
				SendMessage(GetDlgItem(hDlg,IDC_COMBO_FILES_TO_COPY),WM_SETTEXT,0,(LPARAM)panel[srcPanel].GetItem(i)->Name);
		}	}
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_FILES_TO_COPY),CB_SETEDITSEL,0,(LPARAM)MAKELONG(0,-1));
		if(archElem==panel[destPanel].GetEntry()->GetCrntRecType())
			r=MyStringCpy(s,MAX_PATH-1,panel[destPanel].GetArcItFullPathAndName(0));
		else
			r=panel[destPanel].GetPath(s);
		if(archElem==panel[destPanel].GetEntry()->GetCrntRecType())
			SendMessage(GetDlgItem(hDlg,IDC_EDIT_DEST_ARCHIVE),CB_ADDSTRING,0,(LPARAM)s);
		SetDlgItemText(hDlg,IDC_EDIT_DEST_PATH,s);
	}
	SendMessage(GetDlgItem(hDlg,IDC_COMBO_FILES_TO_COPY),CB_SETCURSEL,0,0);
	SetFocus(GetDlgItem(hDlg,IDC_EDIT_DEST_PATH));
	SendMessage(GetDlgItem(hDlg,IDC_EDIT_DEST_PATH),EM_SETSEL,0,0);
	return TRUE;
}

INT_PTR CALLBACK CopyDlgProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
static int iPanSel=0;
static HFONT hf=0;static int hfRef=0;//obshiy hf, dinamik uchun emas:
static HBRUSH br=0;
static HBRUSH brHtBk=0;
	UNREFERENCED_PARAMETER(lParam);
	
	//static int i=0;
	//char ss[32];sprintf(ss,"\n %d ",i++);
	//OutputDebugString(ss);
	//OutputDebugString(GetWinNotifyText(message));

	switch (message)
	{
	//case WM_GETDLGCODE:
    //    return DLGC_WANTALLKEYS;
	case WM_INITDIALOG:
		//Adjust to center:
		RECT rc; GetWindowRect(hDlg, &rc);
		int width,left,height,top;

		width = rc.right - rc.left;
		left = conf::wndLeft + (conf::wndWidth - width)/2;

		height = rc.bottom - rc.top;
		top = conf::wndTop + (conf::wndHeight - height)/2;
		MoveWindow(hDlg, left, top+20, width, height, TRUE);

		//Load language strings:
		wchar_t s[MAX_PATH];
		LoadString(hInst,IDS_STRINGSW_36,s,MAX_PATH);
		SetWindowText(hDlg,s);
		LoadString(hInst,IDS_STRINGSW_37,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_COPY_STATIC_1,s);
		LoadString(hInst,IDS_STRINGSW_38,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_COPY_STATIC_2,s);
		LoadString(hInst,IDS_STRINGSW_39,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_CHECK_EXCEPTION_OR_SELECTION,s);
		LoadString(hInst,IDS_STRINGSW_40,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_CHECK_EXCEPTION_OR_SELECTION1,s);
		LoadString(hInst,IDS_STRINGSW_41,s,MAX_PATH);
		SetDlgItemText(hDlg,IDOK,s);
		LoadString(hInst,IDS_STRINGSW_42,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_BUTTON_ADD_TO_QUEUE,s);
		LoadString(hInst,IDS_STRINGSW_13,s,MAX_PATH);
		SetDlgItemText(hDlg,IDCANCEL,s);
		LoadString(hInst,IDS_STRINGSW_43,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_CHECK_CHANGE_DEFAULT,s);
		LoadString(hInst,IDS_STRINGSW_44,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_COPY_STATIC_3,s);
		LoadString(hInst,IDS_STRINGSW_45,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_BUTTON_BROWSE,s);

		//Copy file filters:
		conf::GetCopyDlgFiltrStr(hDlg,IDC_COMBO_FILES_EXCEPT);

		//Checks:
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_EXCEPTION_OR_SELECTION),
			BM_SETCHECK,conf::bCopyDlgChkBtn[0]?BST_CHECKED:BST_UNCHECKED,0);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_EXCEPTION_OR_SELECTION1),
			BM_SETCHECK,conf::bCopyDlgChkBtn[1]?BST_CHECKED:BST_UNCHECKED,0);
		if(lParam)
			if(!FillCopyFilesInfo(hDlg,lParam,iPanSel))
				EndDialog(hDlg,TRUE);

		if(socketCl==panel[srcPanel].GetEntry()->GetCrntRecType() ||
		  (socketCl==panel[destPanel].GetEntry()->GetCrntRecType() &&
		   2==conf::Dlg.iTotPanels))
		{	EnableWindow(GetDlgItem(hDlg,IDC_BUTTON_ADD_TO_QUEUE),FALSE);
			EnableWindow(GetDlgItem(hDlg,IDC_BUTTON_BROWSE),FALSE);
			EnableWindow(GetDlgItem(hDlg,IDC_CHECK_EXCEPTION_OR_SELECTION),FALSE);
			EnableWindow(GetDlgItem(hDlg,IDC_CHECK_EXCEPTION_OR_SELECTION1),FALSE);
			EnableWindow(GetDlgItem(hDlg,IDC_COMBO_FILES_EXCEPT),FALSE);
		}

		SendMessage(hDlg,WM_USER+1,0,0);
		//HWND h;h=SetFocus(GetDlgItem(hDlg,IDOK));//Ownedrawda defaultbutton bo'lmaydur;
		SetWindowLongPtr(hDlg,GWLP_USERDATA,lParam);
		//Jami systema uchun Btn rangini o'zgartirish:
		//CONST INT sind[2] = {COLOR_BTNFACE,COLOR_BTNTEXT};
		//SetSysColors(2,sind,&conf::Dlg.dlgRGBs[0][0]);
		//MyButtonFrRCBtn(hDlg,IDC_BUTTON_BROWSE,conf::Dlg.iBtnsType);
		//MyButtonFrRCBtn(hDlg,IDOK,conf::Dlg.iBtnsType);
		//MyButtonFrRCBtn(hDlg,IDC_BUTTON_ADD_TO_QUEUE,conf::Dlg.iBtnsType);
		//MyButtonFrRCBtn(hDlg,IDCANCEL,conf::Dlg.iBtnsType);
		return TRUE;
	case WM_CTLCOLORSTATIC:
	case WM_CTLCOLORDLG:
		if(2==conf::Dlg.iBtnsType)//ownedraw
		{	HDC dc = (HDC)wParam;
			SetTextColor(dc,conf::Dlg.dlgRGBs[0][1]);
			SetBkColor(dc,conf::Dlg.dlgRGBs[0][2]);
			return (INT_PTR)br;
		}return 0;
	case WM_CTLCOLOREDIT:
		if(2==conf::Dlg.iBtnsType)//ownedraw
		{	HDC dc = (HDC)wParam;
			SetTextColor(dc,conf::Dlg.dlgRGBs[0][1]);
			SetBkColor(dc,conf::Dlg.dlgRGBs[0][2]);
			return (INT_PTR)br;
		}return 0;
	case WM_CTLCOLORBTN:
		if(2==conf::Dlg.iBtnsType)//ownedraw
		{	HDC dc=(HDC)wParam;
			SetTextColor(dc,conf::Dlg.dlgRGBs[0][4]);
			SetBkColor(dc,conf::Dlg.dlgRGBs[0][5]);
			return (INT_PTR)brHtBk;
		}return 0;
	case WM_DRAWITEM://WM_CTLCOLORBTN dagi knopkalar:
		if(2==conf::Dlg.iBtnsType)//ownedraw
		{	LPDRAWITEMSTRUCT lpdis;lpdis = (LPDRAWITEMSTRUCT)lParam;
			GetWindowText(lpdis->hwndItem,s,64);
			UINT uStyle;uStyle = DFCS_BUTTONPUSH;
			rc = lpdis->rcItem;
			if(lpdis->itemState & ODS_SELECTED)
			{	uStyle |= DFCS_PUSHED|DFCS_TRANSPARENT;
				rc.left+=2;rc.top+=2;
			}
			DrawFrameControl(lpdis->hDC, &lpdis->rcItem, DFC_BUTTON, uStyle);
			if(lpdis->itemState & ODS_SELECTED)
				{rc.left+=1;rc.top+=1;rc.bottom-=2;rc.right-=3;}
			else
				{rc.left+=1;rc.top+=2;rc.bottom-=3;rc.right-=3;}
			FillRect(lpdis->hDC,&rc,brHtBk);//DrawText(lpdis->hDC,"                                                  ",50,&rc,DT_SINGLELINE|DT_VCENTER|DT_INTERNAL|DT_LEFT);
			if(lpdis->itemState & ODS_SELECTED)
				{rc.left-=1;rc.top-=1;rc.bottom+=3;rc.right+=3;}
			else
				{rc.left-=1;rc.top-=2;rc.bottom+=2;rc.right+=3;}
			DrawText(lpdis->hDC,s,MyStringLength(s,64),&rc,DT_SINGLELINE|DT_VCENTER|DT_CENTER);
			return TRUE;
		}return 0;
	/*case WM_USER:
		switch(wParam)
		{	case 1://Ctrl+C
				if((HWND)lParam==GetDlgItem(hDlg,IDC_COMBO_FILES_TO_COPY) ||
				   (HWND)lParam==GetDlgItem(hDlg,IDC_EDIT_DEST_PATH) ||
				   (HWND)lParam==GetDlgItem(hDlg,IDC_COMBO_FILES_EXCEPT))
				{	if(!OpenClipboard(hDlg)) 
						break;
					EmptyClipboard();
					SendMessage((HWND)lParam,EM_GETSEL,(WPARAM)s,(LPARAM)s1);//GetWindowText((HWND)lParam,s,MAX_PATH);
					SetClipboardData(CF_TEXT, s);
					CloseClipboard();
				}
				break;
			case 2://Ctrl+V
				break;
		}
		return TRUE;*/
	case WM_USER+1://hf obshiy uchun, dinamik o'zgartirish uchun emas:
		if(0==hfRef)
		{	hf = CreateFontIndirect(&conf::Dlg.dlgFnts[0]);
			br = CreateSolidBrush(conf::Dlg.dlgRGBs[0][0]);
			brHtBk = CreateSolidBrush(conf::Dlg.dlgRGBs[0][5]);
		}
		SendMessage(GetDlgItem(hDlg,IDC_COPY_STATIC_1),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_COPY_STATIC_2),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_COPY_STATIC_3),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_EXCEPTION_OR_SELECTION),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_EXCEPTION_OR_SELECTION1),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_CHANGE_DEFAULT),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_BUTTON_BROWSE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDOK),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_BUTTON_ADD_TO_QUEUE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDCANCEL),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_FILES_TO_COPY),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_DEST_PATH),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_FILES_EXCEPT),WM_SETFONT,(WPARAM)hf,TRUE);
		++hfRef;
		return 0;//GWLP_USERDATA
	case WM_DESTROY:
		if(--hfRef<1)
		{	DeleteObject(hf);
			DeleteObject(br);
			DeleteObject(brHtBk);
		}
		return 0;
	case WM_USER+2://Dinamik o'zgartirish uchun:
		DeleteObject(hf);hfRef=1;
		hf = CreateFontIndirect(&conf::Dlg.dlgFnts[0]);
		SendMessage(GetDlgItem(hDlg,IDC_COPY_STATIC_1),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_COPY_STATIC_2),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_COPY_STATIC_3),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_EXCEPTION_OR_SELECTION),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_EXCEPTION_OR_SELECTION1),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_CHANGE_DEFAULT),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_BUTTON_BROWSE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDOK),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_BUTTON_ADD_TO_QUEUE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDCANCEL),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_FILES_TO_COPY),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_DEST_PATH),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_FILES_EXCEPT),WM_SETFONT,(WPARAM)hf,TRUE);
		return 0;//GWLP_USERDATA
	case WM_USER+3://Dinamik o'zgartirish uchun, colorni:
		DeleteObject(br);DeleteObject(brHtBk);hfRef=1;
		br = CreateSolidBrush(conf::Dlg.dlgRGBs[0][0]);
		brHtBk = CreateSolidBrush(conf::Dlg.dlgRGBs[0][5]);
		RedrawWindow(hDlg,NULL,NULL,RDW_INVALIDATE|RDW_ALLCHILDREN);
		return 0;//GWLP_USERDATA
	case WM_COMMAND:
		switch(LOWORD(wParam))
		{	case IDC_COMBO_FILES_EXCEPT:
				break;
			case IDC_CHECK_EXCEPTION_OR_SELECTION1:
				if(!GetWindowLongPtr(hDlg,GWLP_USERDATA)) return TRUE;
				if(BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_EXCEPTION_OR_SELECTION1),BM_GETCHECK,0,0))
					SendMessage(GetDlgItem(hDlg,IDC_CHECK_EXCEPTION_OR_SELECTION),
						BM_SETCHECK,BST_UNCHECKED,0);
				break;
			case IDC_CHECK_EXCEPTION_OR_SELECTION:
				if(!GetWindowLongPtr(hDlg,GWLP_USERDATA)) return TRUE;
				if(BN_CLICKED==HIWORD(wParam))
				{	{	if(BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_EXCEPTION_OR_SELECTION),BM_GETCHECK,0,0))
							SendMessage(GetDlgItem(hDlg,IDC_CHECK_EXCEPTION_OR_SELECTION1),
								BM_SETCHECK,BST_UNCHECKED,0);
				}	}
				break;
			case IDC_COMBO_PANEL:
				if(!GetWindowLong(hDlg,GWLP_USERDATA)) return TRUE;
				if(CBN_SELCHANGE==HIWORD(wParam))
				{	iPanSel=(int)SendMessage(GetDlgItem(hDlg,IDC_COMBO_PANEL),CB_GETCURSEL,0,0);
					SendMessage(GetDlgItem(hDlg,IDC_COMBO_PANEL),CB_GETLBTEXT,/*iPan*/iPanSel,(LPARAM)s);
					//if(iPanSel==_wtoi(s)-1)break;
					SetDlgItemText(hDlg,IDC_EDIT_DEST_PATH,panel[_wtoi(s)-1].GetPath());
					if(2<conf::Dlg.iTotPanels)
					{	if(socketCl==panel[_wtoi(s)-1].GetEntry()->GetCrntRecType())
						{	EnableWindow(GetDlgItem(hDlg,IDC_BUTTON_ADD_TO_QUEUE),FALSE);
							EnableWindow(GetDlgItem(hDlg,IDC_BUTTON_BROWSE),FALSE);
							EnableWindow(GetDlgItem(hDlg,IDC_CHECK_EXCEPTION_OR_SELECTION),FALSE);
							EnableWindow(GetDlgItem(hDlg,IDC_CHECK_EXCEPTION_OR_SELECTION1),FALSE);
							EnableWindow(GetDlgItem(hDlg,IDC_COMBO_FILES_EXCEPT),FALSE);
						}
						else if(archElem==panel[_wtoi(s)-1].GetEntry()->GetCrntRecType())
						{	EndDialog(hDlg,0);
							archive::ToArjShowDlg(&panel[srcPanel],&panel[_wtoi(s)-1]);
						}
						else
						{	EnableWindow(GetDlgItem(hDlg,IDC_BUTTON_ADD_TO_QUEUE),TRUE);
							EnableWindow(GetDlgItem(hDlg,IDC_BUTTON_BROWSE),TRUE);
							EnableWindow(GetDlgItem(hDlg,IDC_CHECK_EXCEPTION_OR_SELECTION),TRUE);
							EnableWindow(GetDlgItem(hDlg,IDC_CHECK_EXCEPTION_OR_SELECTION1),TRUE);
							EnableWindow(GetDlgItem(hDlg,IDC_COMBO_FILES_EXCEPT),TRUE);
				}	}	}
				break;
			case IDC_BUTTON_BROWSE:
				BROWSEINFO bi; 
				bi.hwndOwner = hDlg;
				bi.pszDisplayName = s;
				bi.lpszTitle = L"Copy to folder ...";
				bi.ulFlags = BIF_NONEWFOLDERBUTTON|BIF_DONTGOBELOWDOMAIN|BIF_NEWDIALOGSTYLE|
					BIF_NOTRANSLATETARGETS|BIF_RETURNFSANCESTORS;
				bi.lpfn = NULL;
				LPITEMIDLIST pidlRoot;pidlRoot = NULL;
				bi.pidlRoot = pidlRoot;
				LPITEMIDLIST pidlSelected;pidlSelected = SHBrowseForFolder(&bi);
				if(pidlRoot)
					CoTaskMemFree(pidlRoot);
				if(pidlSelected)
				{	SHGetPathFromIDList(pidlSelected,s);
					MyStringCat(s,MAX_PATH-1,L"\\*");
					SetDlgItemText(hDlg,IDC_EDIT_DEST_PATH,s);
					CoTaskMemFree(pidlSelected);
				}
	   			return (INT_PTR)TRUE;
			case IDOK:
				if(!GetWindowLong(hDlg,GWLP_USERDATA)) return TRUE;
				if(BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_CHANGE_DEFAULT),BM_GETCHECK,0,0))
				{	SendMessage(GetDlgItem(hDlg,IDC_COMBO_FILES_EXCEPT),
													WM_GETTEXT,MAX_PATH-1,(LPARAM)s);
					conf::AddCopyDlgFiltrStr(s);
					conf::iCopyDlgBtnPlaces = 0;
					conf::bCopyDlgChkBtn[0] = (BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_EXCEPTION_OR_SELECTION),BM_GETCHECK,0,0));
					conf::bCopyDlgChkBtn[1] = (BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_EXCEPTION_OR_SELECTION1),BM_GETCHECK,0,0));
				}
				GetDlgItemText(hDlg,IDC_EDIT_DEST_PATH,destPath,MAX_PATH);
				if(MyStringRemoveLastCharCheckPre(destPath,MAX_PATH-1,'*','\\'))
				{	srcType = unchange;//use asterics('\'+'*'+'0') symbol at the end;
				}
				else
				{	if(1==srcCnt)
					{	//char ss[MAX_PATH];
						//GetDlgItemText(hDlg,IDC_COMBO_FILES_TO_COPY,ss,MAX_PATH);
						int l=MyStringCpy(s,MAX_PATH-1,panel[srcPanel].GetPath());
						if('*'==s[l-1])//MyStringRemoveLastChar(s,MAX_PATH-1,'*');
							s[--l]=0;
						GetDlgItemText(hDlg,IDC_COMBO_FILES_TO_COPY,&s[l],MAX_PATH-l);//MyStringCpy(&s[l],MAX_PATH-l,ss);//MyStringCat(s,MAX_PATH-1,ss);
						if(IsDirExist(s))
							srcType = rename1Folder;
						else
							srcType = rename1File;
					}
					else
					{	srcType = allToRenFolder;
				}	}
				copyType = single;
				//UnhookWindowsHookEx(copyDlgHook);
				EndDialog(hDlg, 1);
				return (INT_PTR)TRUE;
			case IDC_BUTTON_ADD_TO_QUEUE:
				if(!GetWindowLong(hDlg,GWLP_USERDATA)) return TRUE;
				if(BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_CHANGE_DEFAULT),BM_GETCHECK,0,0))
				{	SendMessage(GetDlgItem(hDlg,IDC_COMBO_FILES_EXCEPT),
													WM_GETTEXT,MAX_PATH-1,(LPARAM)s);
					conf::AddCopyDlgFiltrStr(s);
					conf::iCopyDlgBtnPlaces = 1;//if(BST_FOCUS==SendMessage(GetDlgItem(hDlg,IDCANCEL),BM_GETSTATE,0,0))
					conf::bCopyDlgChkBtn[0] = (BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_EXCEPTION_OR_SELECTION),BM_GETCHECK,0,0));
					conf::bCopyDlgChkBtn[1] = (BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_EXCEPTION_OR_SELECTION1),BM_GETCHECK,0,0));
				}
				GetDlgItemText(hDlg,IDC_EDIT_DEST_PATH,destPath,MAX_PATH);
				if(MyStringRemoveLastCharCheckPre(destPath,MAX_PATH-1,'*','\\'))
				{	srcType = unchange;//use asterics('\'+'*'+'0') symbol at the end;
				}
				else
				{	if(1==srcCnt)
					{	//char ss[MAX_PATH];
						//GetDlgItemText(hDlg,IDC_COMBO_FILES_TO_COPY,ss,MAX_PATH);
						int l=MyStringCpy(s,MAX_PATH-1,panel[srcPanel].GetPath());
						GetDlgItemText(hDlg,IDC_COMBO_FILES_TO_COPY,&s[l],MAX_PATH-l);//MyStringCat(s,MAX_PATH-1,ss);
						if(IsDirExist(s))
							srcType = rename1Folder;
						else
							srcType = rename1File;
					}
					else
					{	srcType = allToRenFolder;
				}	}
				copyType = addToBack;
				//UnhookWindowsHookEx(copyDlgHook);
				EndDialog(hDlg, 1);
				return (INT_PTR)TRUE;
			case IDCANCEL:
				if(!GetWindowLong(hDlg,GWLP_USERDATA)) return TRUE;
				if(BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_CHANGE_DEFAULT),BM_GETCHECK,0,0))
					conf::iCopyDlgBtnPlaces = 2;
				//UnhookWindowsHookEx(copyDlgHook);
				EndDialog(hDlg, 0);
				return (INT_PTR)TRUE;
		}
		break;
	}
	return (INT_PTR)FALSE;
}

//Rentrance procedure, WARN, do not use stat var, use all in stack space!!!!
/*VOID CopyOperation::AddFolder(char *path)
{
WIN32_FIND_DATA ff;
HANDLE			hf = INVALID_HANDLE_VALUE;

	hFind = MyFindFirstFileEx(p->path,FindExInfoStandard,&ff,FindExSearchLimitToDirectories,NULL,0);
	do
	{	if(INVALID_HANDLE_VALUE==hf) return;
		if(FILE_ATTRIBUTE_DIRECTORY & ff.dwFileAttributes)//if(IsDirectory(path, &ff, FALSE))
		{	if(IsCrntOrPrntDirAttrb(&ff))
				AddFolder(ff.cFileName);
		}
		else
		{	if(IsFileExtIncludeCopyFilterI(ff.cFileName))
			{	srcSz += (((U64)ff.nFileSizeHigh<<32) | ff.nFileSizeLow);
	}	}	}
	while(MyFindNextFile(hf, &ff));
	FindClose(hf);
}*/

/*BOOL IsFileExtIncludeCopyFilterIA(char *ffName)
{
char *pext;char s[MAX_PATH];
	if(conf::bCopyDlgChkBtn[0])
	{	for(int i=0; i<25; i++)
		{	if(0==conf::fileCopyDlgFiltrStrs[i][0])
				return FALSE;
			pext = strrchr(ffName,'.');
			if(!pext) continue;
			WideCharToMultiByte(AreFileApisANSI()?CP_ACP:CP_OEMCP,WC_COMPOSITECHECK,
							conf::fileCopyDlgFiltrStrs[i],-1,s,MAX_PATH-1,NULL,NULL);
			if(!strcmp(s,pext+1))
				return TRUE;
		}
		return FALSE;
	}
	else if(conf::bCopyDlgChkBtn[0])
	{	for(int i=0; i<25; i++)
		{	if(0==conf::fileCopyDlgFiltrStrs[i][0])
				return TRUE;
			pext = strrchr(ffName,'.');
			if(!pext) continue;
			WideCharToMultiByte(AreFileApisANSI()?CP_ACP:CP_OEMCP,WC_COMPOSITECHECK,conf::fileCopyDlgFiltrStrs[i],-1,s,MAX_PATH-1,NULL,NULL);
			if(!strcmp(s,pext+1))
				return FALSE;
		}
		return TRUE;
	}
	return TRUE;
}*/

BOOL IsFileExtIncludeCopyFilterI(wchar_t *ffName)
{
wchar_t *pext;
	if(conf::bCopyDlgChkBtn[0])
	{	for(int i=0; i<25; i++)
		{	if(0==conf::fileCopyDlgFiltrStrs[i][0])
				return FALSE;
			pext = wcsrchr(ffName,'.');
			if(!pext) continue;
			if(!wcscmp(conf::fileCopyDlgFiltrStrs[i],pext+1))
				return TRUE;
		}
		return FALSE;
	}
	else if(conf::bCopyDlgChkBtn[0])
	{	for(int i=0; i<25; i++)
		{	if(0==conf::fileCopyDlgFiltrStrs[i][0])
				return TRUE;
			pext = wcsrchr(ffName,'.');
			if(!pext) continue;
			if(!wcscmp(conf::fileCopyDlgFiltrStrs[i],pext+1))
				return FALSE;
		}
		return TRUE;
	}
	return TRUE;
}

//Rentrance procedure, WARN, do not use stat var, use all in stack space!!!!
/*VOID AddFolderSizeA(char *path)
{
	wchar_t s[MAX_PATH];
	MultiByteToWideChar(AreFileApisANSI()?CP_ACP:CP_OEMCP,MB_PRECOMPOSED,path,MAX_PATH-1,s,MAX_PATH);
	AddFolderSize(s);
}*/

VOID AddFolderSize(wchar_t *path)
{
WIN32_FIND_DATA ff;
HANDLE			hf = INVALID_HANDLE_VALUE;
wchar_t s[MAX_PATH];
	int l=MyStringCpy(s,MAX_PATH-1,path);
	if('*'==s[l-1])//MyStringRemoveLastCharCheckPre(s,MAX_PATH-1,'*','\\');
	if('\\'==s[l-2])
		s[--l]=0;
				
	hf = MyFindFirstFileEx(path,FindExInfoStandard,&ff,FindExSearchLimitToDirectories,NULL,0);
	do
	{	if(INVALID_HANDLE_VALUE==hf) return;
		if(FILE_ATTRIBUTE_DIRECTORY & ff.dwFileAttributes)//if(IsDirectory(path, &ff, FALSE))
		{	if(IsCrntOrPrntDirAttrb(ff.cFileName))
			{	int n=MyStringCpy(&s[l],MAX_PATH-l+1,ff.cFileName);//MyStringCat(s,MAX_PATH-1,ff.cFileName);
				s[l+n]='\\';++n;
				s[l+n]='*';++n;
				s[l+n]=0;
				AddFolderSize(s);
		}	}
		else
		{	if(IsFileExtIncludeCopyFilterI(ff.cFileName))
				srcSz += (((U64)ff.nFileSizeHigh<<32) | ff.nFileSizeLow);
	}	}
	while(FindNextFile(hf, &ff));
	FindClose(hf);
}

//Src panel,koneshno:
BOOL IsFileExtIncludeCopyFilter(int id)
{
	if(conf::bCopyDlgChkBtn[0])
	{	for(int i=0; i<25; i++)
		{	if(0==conf::fileCopyDlgFiltrStrs[i][0])
				return FALSE;
			if(!panel[srcPanel].GetItem(id)->ExtCharLen)
				continue;
			if(!wcscmp(conf::fileCopyDlgFiltrStrs[i],panel[srcPanel].GetItem(id)->GetExt()))
				return TRUE;
		}
		return FALSE;
	}
	else if(conf::bCopyDlgChkBtn[0])
	{	for(int i=0; i<25; i++)
		{	if(0==conf::fileCopyDlgFiltrStrs[i][0])
				return TRUE;
			if(!panel[srcPanel].GetItem(id)->ExtCharLen)
				continue;
			if(!wcscmp(conf::fileCopyDlgFiltrStrs[i],panel[srcPanel].GetItem(id)->GetExt()))
				return FALSE;
		}
		return TRUE;
	}
	return TRUE;
}

//Copy qilinadigan jami fayllar hajmini hisoblaydur;
VOID CalcSrcAndAvailableDestSize()
{
	srcSz = 0;
	int tot=panel[srcPanel].GetTotSelects();
	if(!tot)
	{	int ht=panel[srcPanel].GetHot();
		if(ht>0 && ht<panel[srcPanel].GetTotItems())
		{	if(file == panel[srcPanel].GetItem(ht)->attribute)
			{	if(IsFileExtIncludeCopyFilter(ht))
					srcSz += panel[srcPanel].GetItem(ht)->size;
			}
			else if(folder == panel[srcPanel].GetItem(ht)->attribute)
			{	wchar_t s[MAX_PATH];
				int l=panel[srcPanel].GetFullPathAndName(ht,s,MAX_PATH);
				s[l++]='\\';//MyStringCat(s,MAX_PATH-1,"\\*");
				s[l++]='*';
				s[l]=0;
				AddFolderSize(s);
	}	}	}//Destniyam hisoblab qo'yaylik:
	else
	{	for(int i=0; i<panel[srcPanel].GetTotItems(); i++)//srcCnt
		{	if(selected==panel[srcPanel].GetItem(i)->state  || (0==panel[srcPanel].GetTotSelects() && i==panel[srcPanel].GetHot()))
			{	if(file == panel[srcPanel].GetItem(i)->attribute)
				{	if(IsFileExtIncludeCopyFilter(i))
						srcSz += panel[srcPanel].GetItem(i)->size;
				}
				else if(folder == panel[srcPanel].GetItem(i)->attribute)
				{	wchar_t s[MAX_PATH];
					int l=panel[srcPanel].GetFullPathAndName(i,s,MAX_PATH);
					s[l++]='\\';//MyStringCat(s,MAX_PATH-1,"\\*");
					s[l++]='*';
					s[l++]=0;
					AddFolderSize(s);
	}	}	}	}//Destniyam hisoblab qo'yaylik:
	//avDstSz 
	int dr = myWMI::IsNameDrive(destPath);
	if(dr>-1)
	{	wchar_t p[4]={destPath[0],destPath[1],0,0};
		avDstSz = myWMI::GetLogicalDriveAvailableMem(p);
}	}

/*BOOL CutSelectedNamesA(CpyStackA *st, char *srcPth, int tot)
{
char src[MAX_PATH]; MyStringCpyA(src,MAX_PATH-1,srcPth);
	MyStringRemoveLastCharCheckPreA(src,MAX_PATH-1,'*','\\');
	for(int i=0; i<tot; i++)
	{	char *mismatchPtr = MyStringFindFirstUnmatchA(st[i].FullPathAndName,src,MAX_PATH);
		if(mismatchPtr)
			StringCchPrintfA(st[i].Name,MAX_PATH-1,mismatchPtr);
	}
	return TRUE;
}*/	

BOOL CutSelectedNames(CpyStack *st, wchar_t *srcPth, int tot)
{
wchar_t src[MAX_PATH]; MyStringCpy(src,MAX_PATH-1,srcPth);
	MyStringRemoveLastCharCheckPre(src,MAX_PATH-1,'*','\\');
	for(int i=0; i<tot; i++)
	{	wchar_t *mismatchPtr = MyStringFindFirstUnmatch(st[i].FullPathAndName,src,MAX_PATH);
		if(mismatchPtr)
			StringCchPrintf(st[i].Name,MAX_PATH-1,mismatchPtr);
	}
	return TRUE;
}	

/*int GetFilesInFolderA(char *path, CpyStackA *stack)//reentrance:
{
WIN32_FIND_DATAA ff;
HANDLE hf = INVALID_HANDLE_VALUE;

int tot = 0;

	hf = MyFindFirstFileExA(path,FindExInfoStandard,&ff,FindExSearchLimitToDirectories,NULL,0);
	do
	{	if(INVALID_HANDLE_VALUE==hf) return tot;
		if(FILE_ATTRIBUTE_DIRECTORY & ff.dwFileAttributes)//if(IsDirectory(path, &ff, FALSE))
		{	if(IsCrntOrPrntDirAttrbA(ff.cFileName))
			{	int l=MyStringCpyA(stack[tot].FullPathAndName,MAX_PATH-1,path);//char s[MAX_PATH]; MyStringCpy(s,MAX_PATH-1,path);
				if('*'==stack[tot].FullPathAndName[l-1])//MyStringRemoveLastCharCheckPre(s,MAX_PATH-1,'*','\\');
				if('\\'==stack[tot].FullPathAndName[l-2])
					stack[tot].FullPathAndName[--l]=0;
				l+=MyStringCpyA(&stack[tot].FullPathAndName[l],MAX_PATH-l+1,ff.cFileName);//MyStringCat(s,MAX_PATH-1,ff.cFileName);

				MyStringCpyA(stack[tot].Name,MAX_PATH-1,ff.cFileName);
				//MyStringCpy(stack[tot].FullPathAndName,MAX_PATH-1,s);
				stack[tot].attribute = folder;
				int saveTot=tot;
				++tot;//folderniyam;

				stack[saveTot].FullPathAndName[l]='\\';//MyStringCat(s,MAX_PATH-1,"\\*");
				stack[saveTot].FullPathAndName[l+1]='*';
				stack[saveTot].FullPathAndName[l+2]=0;
				tot += GetFilesInFolderA(stack[saveTot].FullPathAndName,&stack[tot]);//s
				stack[saveTot].FullPathAndName[l]=0;
		}	}
		else
		{	if(IsFileExtIncludeCopyFilterIA(ff.cFileName))
			{	MyStringCpyA(stack[tot].Name,MAX_PATH-1,ff.cFileName);
				int l=MyStringCpyA(stack[tot].FullPathAndName,MAX_PATH-1,path);
				if('*'==stack[tot].FullPathAndName[l-1])//MyStringRemoveLastCharCheckPre(stack[tot].FullPathAndName,MAX_PATH-1,'*','\\');
				if('\\'==stack[tot].FullPathAndName[l-2])
					stack[tot].FullPathAndName[--l]=0;

				l+=MyStringCpyA(&stack[tot].FullPathAndName[l],MAX_PATH-l,ff.cFileName);//MyStringCat(stack[tot].FullPathAndName,MAX_PATH-1,ff.cFileName);
				stack[tot].size = ((unsigned __int64)ff.nFileSizeHigh<<32) | ff.nFileSizeLow;
				stack[tot].attribute = file;
				++tot;
	}	}	}
	while(MyFindNextFileA(hf, &ff));
	MyFindClose(hf);
	return tot;
}*/

int GetFilesInFolder(wchar_t *path, CpyStack *stack)//reentrance:
{
WIN32_FIND_DATAW ff;
HANDLE hf = INVALID_HANDLE_VALUE;

int tot = 0;

	hf = MyFindFirstFileEx(path,FindExInfoStandard,&ff,FindExSearchLimitToDirectories,NULL,0);
	do
	{	if(INVALID_HANDLE_VALUE==hf) return tot;
		if(FILE_ATTRIBUTE_DIRECTORY & ff.dwFileAttributes)//if(IsDirectory(path, &ff, FALSE))
		{	if(IsCrntOrPrntDirAttrb(ff.cFileName))
			{	int l=MyStringCpy(stack[tot].FullPathAndName,MAX_PATH-1,path);//char s[MAX_PATH]; MyStringCpy(s,MAX_PATH-1,path);
				if('*'==stack[tot].FullPathAndName[l-1])//MyStringRemoveLastCharCheckPre(s,MAX_PATH-1,'*','\\');
				if('\\'==stack[tot].FullPathAndName[l-2])
					stack[tot].FullPathAndName[--l]=0;
				l+=MyStringCpy(&stack[tot].FullPathAndName[l],MAX_PATH-l+1,ff.cFileName);//MyStringCat(s,MAX_PATH-1,ff.cFileName);

				MyStringCpy(stack[tot].Name,MAX_PATH-1,ff.cFileName);
				//MyStringCpy(stack[tot].FullPathAndName,MAX_PATH-1,s);
				stack[tot].attribute = folder;
				int saveTot=tot;
				++tot;//folderniyam;

				stack[saveTot].FullPathAndName[l]='\\';//MyStringCat(s,MAX_PATH-1,"\\*");
				stack[saveTot].FullPathAndName[l+1]='*';
				stack[saveTot].FullPathAndName[l+2]=0;
				tot += GetFilesInFolder(stack[saveTot].FullPathAndName,&stack[tot]);//s
				stack[saveTot].FullPathAndName[l]=0;
		}	}
		else
		{	if(IsFileExtIncludeCopyFilterI(ff.cFileName))
			{	MyStringCpy(stack[tot].Name,MAX_PATH-1,ff.cFileName);
				int l=MyStringCpy(stack[tot].FullPathAndName,MAX_PATH-1,path);
				if('*'==stack[tot].FullPathAndName[l-1])//MyStringRemoveLastCharCheckPre(stack[tot].FullPathAndName,MAX_PATH-1,'*','\\');
				if('\\'==stack[tot].FullPathAndName[l-2])
					stack[tot].FullPathAndName[--l]=0;

				l+=MyStringCpy(&stack[tot].FullPathAndName[l],MAX_PATH-l,ff.cFileName);//MyStringCat(stack[tot].FullPathAndName,MAX_PATH-1,ff.cFileName);
				stack[tot].size = ((unsigned __int64)ff.nFileSizeHigh<<32) | ff.nFileSizeLow;
				stack[tot].attribute = file;
				++tot;
	}	}	}
	while(FindNextFile(hf, &ff));
	FindClose(hf);
	return tot;
}

/*int GetSelectedFilesA(CpyStackA *stack)
{
int tot=panel[srcPanel].GetTotSelects();
	if(!tot)
	{	int ht = panel[srcPanel].GetHot();
		if(ht>0 && ht<panel[srcPanel].GetTotItems())
		{	if(file == panel[srcPanel].GetItem(ht)->attribute)
			{	MyStringCpyA(stack[tot].Name,MAX_PATH-1,panel[srcPanel].GetItem(ht)->GetNameA());
				int l=MyStringCpyA(stack[tot].FullPathAndName,MAX_PATH-1,panel[srcPanel].GetPathA());

				if('*'==stack[tot].FullPathAndName[l-1])//MyStringRemoveLastCharCheckPre(stack[tot].FullPathAndName,MAX_PATH-1,'*','\\');
				if('\\'==stack[tot].FullPathAndName[l-2])
					stack[tot].FullPathAndName[--l]=0;
				MyStringCpyA(&stack[tot].FullPathAndName[l],MAX_PATH-l,panel[srcPanel].GetItem(ht)->GetNameA());//MyStringCat(stack[tot].FullPathAndName,MAX_PATH-1,panel[srcPanel].GetItem(ht)->Name);
				stack[tot].size = panel[srcPanel].GetItem(ht)->size;
				stack[tot].attribute = file;
				return 1;
			}
			else if(folder == panel[srcPanel].GetItem(ht)->attribute)
			{	int l=panel[srcPanel].GetFullPathAndNameA(ht,stack[tot].FullPathAndName,MAX_PATH);
				MyStringCpyA(stack[tot].Name,MAX_PATH-1,panel[srcPanel].GetItem(ht)->GetNameA());
				stack[tot].attribute = folder;
				int saveTot=tot;
				++tot;//folderniyam;

				if(mSHFileOperation!=copyMethod)
				{	stack[saveTot].FullPathAndName[l]='\\';//MyStringCat(pth,MAX_PATH-1,"\\*");
					stack[saveTot].FullPathAndName[l+1]='*';
					stack[saveTot].FullPathAndName[l+2]=0;
					tot += GetFilesInFolderA(stack[saveTot].FullPathAndName,&stack[tot]);
					stack[saveTot].FullPathAndName[l]=0;
	 		}	}
			return tot;
		}		
		else return 0;
	}
 tot=0;
 for(int i=0; i<panel[srcPanel].GetTotItems(); i++)
 {	if(selected==panel[srcPanel].GetItem(i)->state || (0==panel[srcPanel].GetTotSelects() && i==panel[srcPanel].GetHot()))
	{	if(file == panel[srcPanel].GetItem(i)->attribute)
		{	MyStringCpyA(stack[tot].Name,MAX_PATH-1,panel[srcPanel].GetItem(i)->GetNameA());
			int l=MyStringCpyA(stack[tot].FullPathAndName,MAX_PATH-1,panel[srcPanel].GetPathA());

			if('*'==stack[tot].FullPathAndName[l-1])//MyStringRemoveLastCharCheckPre(stack[tot].FullPathAndName,MAX_PATH-1,'*','\\');
			if('\\'==stack[tot].FullPathAndName[l-2])
				stack[tot].FullPathAndName[--l]=0;
			MyStringCpyA(&stack[tot].FullPathAndName[l],MAX_PATH-l,panel[srcPanel].GetItem(i)->GetNameA());//MyStringCat(stack[tot].FullPathAndName,MAX_PATH-1,panel[srcPanel].GetItem(i)->Name);
			stack[tot].size = panel[srcPanel].GetItem(i)->size;
			stack[tot].attribute = file;
			++tot;
		}
		else if(folder == panel[srcPanel].GetItem(i)->attribute)
		{	int l=panel[srcPanel].GetFullPathAndNameA(i,stack[tot].FullPathAndName,MAX_PATH);
			MyStringCpyA(stack[tot].Name,MAX_PATH-1,panel[srcPanel].GetItem(i)->GetNameA());
			stack[tot].attribute = folder;
			int saveTot=tot;
			++tot;//folderniyam;

			if(mSHFileOperation!=copyMethod)
			{	stack[saveTot].FullPathAndName[l]='\\';//MyStringCat(pth,MAX_PATH-1,"\\*");
				stack[saveTot].FullPathAndName[l+1]='*';
				stack[saveTot].FullPathAndName[l+2]=0;
				tot += GetFilesInFolderA(stack[saveTot].FullPathAndName,&stack[tot]);
				stack[saveTot].FullPathAndName[l]=0;
 }	}	}	}
 return tot;
}*/

int GetSelectedFiles(CpyStack *stack)
{
int tot=panel[srcPanel].GetTotSelects();
	if(!tot)
	{	int ht = panel[srcPanel].GetHot();
		if(ht>0 && ht<panel[srcPanel].GetTotItems())
		{	if(file == panel[srcPanel].GetItem(ht)->attribute)
			{	MyStringCpy(stack[tot].Name,MAX_PATH-1,panel[srcPanel].GetItem(ht)->Name);
				int l=MyStringCpy(stack[tot].FullPathAndName,MAX_PATH-1,panel[srcPanel].GetPath());

				if('*'==stack[tot].FullPathAndName[l-1])//MyStringRemoveLastCharCheckPre(stack[tot].FullPathAndName,MAX_PATH-1,'*','\\');
				if('\\'==stack[tot].FullPathAndName[l-2])
					stack[tot].FullPathAndName[--l]=0;
				MyStringCpy(&stack[tot].FullPathAndName[l],MAX_PATH-l,panel[srcPanel].GetItem(ht)->Name);//MyStringCat(stack[tot].FullPathAndName,MAX_PATH-1,panel[srcPanel].GetItem(ht)->Name);
				stack[tot].size = panel[srcPanel].GetItem(ht)->size;
				stack[tot].attribute = file;
				return 1;
			}
			else if(folder == panel[srcPanel].GetItem(ht)->attribute)
			{	int l=panel[srcPanel].GetFullPathAndName(ht,stack[tot].FullPathAndName,MAX_PATH);
				MyStringCpy(stack[tot].Name,MAX_PATH-1,panel[srcPanel].GetItem(ht)->Name);
				stack[tot].attribute = folder;
				int saveTot=tot;
				++tot;//folderniyam;

				if(mSHFileOperation!=copyMethod)
				{	stack[saveTot].FullPathAndName[l]='\\';//MyStringCat(pth,MAX_PATH-1,"\\*");
					stack[saveTot].FullPathAndName[l+1]='*';
					stack[saveTot].FullPathAndName[l+2]=0;
					tot += GetFilesInFolder(stack[saveTot].FullPathAndName,&stack[tot]);
					stack[saveTot].FullPathAndName[l]=0;
	 		}	}
			return tot;
		}		
		else return 0;
	}
 tot=0;
 for(int i=0; i<panel[srcPanel].GetTotItems(); i++)
 {	if(selected==panel[srcPanel].GetItem(i)->state || (0==panel[srcPanel].GetTotSelects() && i==panel[srcPanel].GetHot()))
	{	if(file == panel[srcPanel].GetItem(i)->attribute)
		{	MyStringCpy(stack[tot].Name,MAX_PATH-1,panel[srcPanel].GetItem(i)->Name);
			int l=MyStringCpy(stack[tot].FullPathAndName,MAX_PATH-1,panel[srcPanel].GetPath());

			if('*'==stack[tot].FullPathAndName[l-1])//MyStringRemoveLastCharCheckPre(stack[tot].FullPathAndName,MAX_PATH-1,'*','\\');
			if('\\'==stack[tot].FullPathAndName[l-2])
				stack[tot].FullPathAndName[--l]=0;
			MyStringCpy(&stack[tot].FullPathAndName[l],MAX_PATH-l,panel[srcPanel].GetItem(i)->Name);//MyStringCat(stack[tot].FullPathAndName,MAX_PATH-1,panel[srcPanel].GetItem(i)->Name);
			stack[tot].size = panel[srcPanel].GetItem(i)->size;
			stack[tot].attribute = file;
			++tot;
		}
		else if(folder == panel[srcPanel].GetItem(i)->attribute)
		{	int l=panel[srcPanel].GetFullPathAndName(i,stack[tot].FullPathAndName,MAX_PATH);
			MyStringCpy(stack[tot].Name,MAX_PATH-1,panel[srcPanel].GetItem(i)->Name);
			stack[tot].attribute = folder;
			int saveTot=tot;
			++tot;//folderniyam;

			if(mSHFileOperation!=copyMethod)
			{	stack[saveTot].FullPathAndName[l]='\\';//MyStringCat(pth,MAX_PATH-1,"\\*");
				stack[saveTot].FullPathAndName[l+1]='*';
				stack[saveTot].FullPathAndName[l+2]=0;
				tot += GetFilesInFolder(stack[saveTot].FullPathAndName,&stack[tot]);
				stack[saveTot].FullPathAndName[l]=0;
 }	}	}	}
 return tot;
}

/*int GetFilesCntInFolderA(char *path)
{
wchar_t s[MAX_PATH];
	MultiByteToWideChar(AreFileApisANSI()?CP_ACP:CP_OEMCP,MB_PRECOMPOSED,path,MAX_PATH-1,s,MAX_PATH);
	return GetFilesCntInFolder(s);
}*/

int GetFilesCntInFolder(wchar_t *path)//reentrance:
{
WIN32_FIND_DATA ff;
HANDLE hf = INVALID_HANDLE_VALUE;

int tot = 0;
wchar_t s[MAX_PATH];
	int l=MyStringCpy(s,MAX_PATH-1,path);
	if('*'==s[l-1])//MyStringRemoveLastCharCheckPre(s,MAX_PATH-1,'*','\\');
	if('\\'==s[l-2])
		s[--l]=0;
	
	hf = MyFindFirstFileEx(path,FindExInfoStandard,&ff,FindExSearchLimitToDirectories,NULL,0);
	do
	{	if(INVALID_HANDLE_VALUE==hf) return tot;
		if(FILE_ATTRIBUTE_DIRECTORY & ff.dwFileAttributes)//if(IsDirectory(path, &ff, FALSE))
		{	if(IsCrntOrPrntDirAttrb(ff.cFileName))
			{	int n=MyStringCpy(&s[l],MAX_PATH-l,ff.cFileName);//MyStringCat(s,MAX_PATH-1,ff.cFileName);
				++tot;//folderniyam;
				s[l+n]='\\';++n;//MyStringCat(s,MAX_PATH-1,"\\*");
				s[l+n]='*';++n;
				s[l+n]=0;
				tot += GetFilesCntInFolder(s);
		}	}
		else
		{	if(IsFileExtIncludeCopyFilterI(ff.cFileName))
				++tot;
	}	}
	while(FindNextFile(hf, &ff));
	FindClose(hf);
	return tot;
}

int GetSelectedFilesCnt()
{
	int tot=panel[srcPanel].GetTotSelects();
	if(!tot)
	{	int ht=panel[srcPanel].GetHot();
		if(ht>0 && ht<panel[srcPanel].GetTotItems())
		{	if(file == panel[srcPanel].GetItem(ht)->attribute)
				return 1;
			else if(folder == panel[srcPanel].GetItem(ht)->attribute)
			{	wchar_t pth[MAX_PATH]; 
				int l=panel[srcPanel].GetFullPathAndName(ht,pth,MAX_PATH);
				++tot;//folderniyam;
				if(mSHFileOperation!=copyMethod)
				{	pth[l++]='\\';//MyStringCat(pth,MAX_PATH-1,"\\*");
					pth[l++]='*';
					pth[l]=0;
					tot += GetFilesCntInFolder(pth);
			}	}
			return tot;
		}
		else return 0;
	}
	tot = 0;
	for(int i=0; i<panel[srcPanel].GetTotItems(); i++)
	{	if(selected==panel[srcPanel].GetItem(i)->state || (0==panel[srcPanel].GetTotSelects() && i==panel[srcPanel].GetHot()))
		{	if(file == panel[srcPanel].GetItem(i)->attribute)
				++tot;
			else if(folder == panel[srcPanel].GetItem(i)->attribute)
			{	wchar_t pth[MAX_PATH];
				int l=panel[srcPanel].GetFullPathAndName(i,pth,MAX_PATH);
				++tot;//folderniyam;
				if(mSHFileOperation!=copyMethod)
				{	pth[l++]='\\';//MyStringCat(pth,MAX_PATH-1,"\\*");
					pth[l++]='*';
					pth[l]=0;
					tot += GetFilesCntInFolder(pth);
	}	}	}	}
	return tot;
}

int GetFilesInFolderToDlg(wchar_t *path,int fromSrcStrPos,HWND hEdt1, HWND hEdt2)//reentrance:
{
static wchar_t RetCar[3] = { 0x0d, 0x0a, 0x00 };
WIN32_FIND_DATA ff;
HANDLE hf = INVALID_HANDLE_VALUE;
wchar_t Name[MAX_PATH],FullPathAndName[MAX_PATH];
int tot = 0;

	hf = MyFindFirstFileEx(path,FindExInfoStandard,&ff,FindExSearchLimitToDirectories,NULL,0);
	do
	{	if(INVALID_HANDLE_VALUE==hf) return tot;
		if(FILE_ATTRIBUTE_DIRECTORY & ff.dwFileAttributes)//if(IsDirectory(path, &ff, FALSE))
		{	if(IsCrntOrPrntDirAttrb(ff.cFileName))
			{	SendMessage(hEdt1,EM_REPLACESEL, (WPARAM)FALSE, (LPARAM)L"");
				SendMessage(hEdt1,EM_REPLACESEL, (WPARAM)FALSE, (LPARAM)(LPCSTR)RetCar);
				SendMessage(hEdt1,EM_SCROLLCARET,(WPARAM)0, (LPARAM)0);

				int l=MyStringCpy(Name,MAX_PATH-1,destPath);
				if(rename1Folder==srcType || allToRenFolder==srcType)
				{	Name[l++]='\\';//MyStringCat(Name,MAX_PATH-1,"\\");
					Name[l]=0;
				}
				if(fromSrcStrPos>-1)
				{	l+=MyStringCpy(&Name[l],MAX_PATH-l,path+fromSrcStrPos);//MyStringCat(Name,MAX_PATH-1,path+fromSrcStrPos);
					if('*'==Name[l-1])//if(!MyStringRemoveLastCharCheckPre(Name,MAX_PATH-1,'*','\\'))
					if('\\'==Name[l-1])
						Name[--l]=0;
					Name[l++]='\\';//	MyStringCat(Name,MAX_PATH-1,"\\");
					Name[l]=0;
				}
				MyStringCat(Name,MAX_PATH-1,ff.cFileName);

				SendMessage(hEdt2,EM_REPLACESEL,(WPARAM)FALSE,(LPARAM)(LPCSTR)Name);
				SendMessage(hEdt2,EM_REPLACESEL,(WPARAM)FALSE,(LPARAM)(LPCSTR)RetCar);
				SendMessage(hEdt2,EM_SCROLLCARET,(WPARAM)0, (LPARAM)0);

				wchar_t s[MAX_PATH]; l=MyStringCpy(s,MAX_PATH-1,path);
				if('*'==s[l-1])//MyStringRemoveLastCharCheckPre(s,MAX_PATH-1,'*','\\');
				if('\\'==s[l-2])
					s[--l]=0;
				wchar_t *pext=&s[l];
				l+=MyStringCpy(&s[l],MAX_PATH-l,ff.cFileName);//MyStringCat(s,MAX_PATH-1,ff.cFileName);
				//stack[tot].attribute = folder;
				++tot;//folderniyam;

				s[l++]='\\';//MyStringCat(s,MAX_PATH-1,"\\*");
				s[l]='*';
				tot += GetFilesInFolderToDlg(s,(int)(fromSrcStrPos>-1?fromSrcStrPos:pext-s),hEdt1,hEdt2);
		}	}
		else
		{	if(IsFileExtIncludeCopyFilterI(ff.cFileName))
			{	if(unchange==srcType)
				{
				}
				else if(rename1File==srcType)
				{
				}
				else if(rename1Folder==srcType)
				{
				}
				else if(allToRenFolder==srcType)
				{
				}
				
				int l=MyStringCpy(FullPathAndName,MAX_PATH-1,path);
				if('*'==FullPathAndName[l-1])//MyStringRemoveLastCharCheckPre(FullPathAndName,MAX_PATH-1,'*','\\');
				if('\\'==FullPathAndName[l-2])
					FullPathAndName[--l]=0;
				l+=MyStringCpy(&FullPathAndName[l],MAX_PATH-l,ff.cFileName);//MyStringCat(FullPathAndName,MAX_PATH-1,ff.cFileName);
				//stack[tot].size = ((unsigned __int64)ff.nFileSizeHigh<<32) | ff.nFileSizeLow;
				//stack[tot].attribute = file;
				++tot;
			
				SendMessage(hEdt1,EM_REPLACESEL, (WPARAM)FALSE, (LPARAM)FullPathAndName);
				SendMessage(hEdt1,EM_REPLACESEL, (WPARAM)FALSE, (LPARAM)(LPCSTR)RetCar);
				SendMessage(hEdt1,EM_SCROLLCARET,(WPARAM)0, (LPARAM)0);

				l=MyStringCpy(Name,MAX_PATH-1, destPath);
				if(rename1Folder==srcType || allToRenFolder==srcType)
				{	Name[l++]='\\';//MyStringCat(Name,MAX_PATH-1, "\\");
					Name[l]=0;
				}
				MyStringCpy(&Name[l],//MyStringCat(	Name,
							MAX_PATH-l,//MAX_PATH
							fromSrcStrPos>-1 ?
							FullPathAndName+fromSrcStrPos : ff.cFileName);										  	
				SendMessage(hEdt2,EM_REPLACESEL,(WPARAM)FALSE,(LPARAM)(LPCSTR)Name);
				SendMessage(hEdt2,EM_REPLACESEL,(WPARAM)FALSE,(LPARAM)(LPCSTR)RetCar);
				SendMessage(hEdt2,EM_SCROLLCARET,(WPARAM)0, (LPARAM)0);
	}	}	}
	while(FindNextFile(hf, &ff));
	FindClose(hf);
	return tot;
}

unsigned __int64 GetSelectedFilesToDlg(HWND dlgEdit1,HWND dlgEdit2)
{
static wchar_t RetCar[3] = { 0x0d, 0x0a, 0x00 };
wchar_t Name[MAX_PATH],FullPathAndName[MAX_PATH];
unsigned __int64 sz = 0;
size_t destPathLn; destPathLn = MyStringLength(destPath,MAX_PATH);//StringCchLength(destPath,MAX_PATH-1,&destPathLen);


	if(allToRenFolder==srcType)
	{	SendMessage(dlgEdit1,EM_REPLACESEL, (WPARAM)FALSE, (LPARAM)L"");
		SendMessage(dlgEdit1,EM_REPLACESEL, (WPARAM)FALSE, (LPARAM)(LPCSTR)RetCar);
		SendMessage(dlgEdit1,EM_SCROLLCARET,(WPARAM)0, (LPARAM)0);

		SendMessage(dlgEdit2,EM_REPLACESEL, (WPARAM)FALSE, (LPARAM)destPath);
		SendMessage(dlgEdit2,EM_REPLACESEL, (WPARAM)FALSE, (LPARAM)(LPCSTR)RetCar);
		SendMessage(dlgEdit2,EM_SCROLLCARET,(WPARAM)0, (LPARAM)0);
	}

int tot=panel[srcPanel].GetTotSelects();
	if(!tot)
	{	int ht=panel[srcPanel].GetHot();
		if(ht>0 && ht<panel[srcPanel].GetTotItems())
		{	if(file == panel[srcPanel].GetItem(ht)->attribute)
			{	MyStringCpy(Name,MAX_PATH-1,panel[srcPanel].GetItem(ht)->Name);
				int l=MyStringCpy(FullPathAndName,MAX_PATH-1,panel[srcPanel].GetPath());
				if('*'==FullPathAndName[l-1])//MyStringRemoveLastCharCheckPre(FullPathAndName,MAX_PATH-1,'*','\\');
				if('\\'==FullPathAndName[l-2])
					FullPathAndName[--l]=0;
				l+=MyStringCpy(&FullPathAndName[l],MAX_PATH-l,panel[srcPanel].GetItem(ht)->Name);//MyStringCat(FullPathAndName,MAX_PATH-1,panel[srcPanel].GetItem(ht)->Name);
				sz += panel[srcPanel].GetItem(ht)->size;

				SendMessage(dlgEdit1,EM_REPLACESEL, (WPARAM)FALSE, (LPARAM)(LPCSTR)FullPathAndName);
				SendMessage(dlgEdit1,EM_REPLACESEL, (WPARAM)FALSE, (LPARAM)(LPCSTR)RetCar);
				SendMessage(dlgEdit1,EM_SCROLLCARET,(WPARAM)0, (LPARAM)0);

				if(rename1File!=srcType)
				{	destPath[destPathLn]='\\';//MyStringCat(destPath,MAX_PATH-1,"\\");
					//destPath[destPathLn+1]=0;
					MyStringCpy(&destPath[destPathLn+1],(int)(MAX_PATH-destPathLn),panel[srcPanel].GetItem(ht)->Name);//MyStringCat(destPath,MAX_PATH-1,panel[srcPanel].GetItem(ht)->Name);
				}
				SendMessage(dlgEdit2,EM_REPLACESEL, (WPARAM)FALSE, (LPARAM)(LPCSTR)destPath);
				SendMessage(dlgEdit2,EM_REPLACESEL, (WPARAM)FALSE, (LPARAM)(LPCSTR)RetCar);
				SendMessage(dlgEdit2,EM_SCROLLCARET,(WPARAM)0, (LPARAM)0);
				destPath[destPathLn] = 0;
				return sz;
			}
			else if(folder == panel[srcPanel].GetItem(ht)->attribute)
			{	int fl=panel[srcPanel].GetFullPathAndName(ht,FullPathAndName,MAX_PATH);
 				SendMessage(dlgEdit1,EM_REPLACESEL, (WPARAM)FALSE, (LPARAM)L"");
				SendMessage(dlgEdit1,EM_REPLACESEL, (WPARAM)FALSE, (LPARAM)(LPCSTR)RetCar);
				SendMessage(dlgEdit1,EM_SCROLLCARET,(WPARAM)0, (LPARAM)0);

				if(unchange==srcType)
				{	int l=MyStringCpy(Name,MAX_PATH-1,destPath);
					MyStringCpy(&Name[l],MAX_PATH-l,panel[srcPanel].GetItem(ht)->Name);//MyStringCat(Name,MAX_PATH-1,panel[srcPanel].GetItem(ht)->Name);
				}
				else if(rename1Folder==srcType)
				{	MyStringCpy(Name,MAX_PATH-1,destPath);
				}
				else
				{	int l=MyStringCpy(Name,MAX_PATH-1,destPath);
					Name[l++]='\\';//MyStringCat(Name,MAX_PATH-1,"\\");
					//Name[l]=0;//MyStringCat(Name,MAX_PATH-1,"\\");
					MyStringCpy(&Name[l],MAX_PATH-l,panel[srcPanel].GetItem(ht)->Name);//MyStringCat(Name,MAX_PATH-1,panel[srcPanel].GetItem(ht)->Name);
				}

				SendMessage(dlgEdit2,EM_REPLACESEL,(WPARAM)FALSE,(LPARAM)(LPCSTR)Name);
				SendMessage(dlgEdit2,EM_REPLACESEL,(WPARAM)FALSE,(LPARAM)(LPCSTR)RetCar);
				SendMessage(dlgEdit2,EM_SCROLLCARET,(WPARAM)0, (LPARAM)0);
				++tot;//folderniyam;

				wchar_t *p=NULL;
				if(unchange==srcType || allToRenFolder==srcType)
					p = wcsrchr(FullPathAndName,'\\');

				FullPathAndName[fl++]='\\';//MyStringCat(FullPathAndName,MAX_PATH-1,"\\*");
				FullPathAndName[fl++]='*';
				FullPathAndName[fl]=0;
				tot += GetFilesInFolderToDlg(FullPathAndName,(int)(p?p-FullPathAndName+1:-1),dlgEdit1,dlgEdit2);
			}
			return sz;
		}
		else return 0;
	}

	tot=0;
	for(int i=0; i<panel[srcPanel].GetTotItems(); i++)
	{	if(selected==panel[srcPanel].GetItem(i)->state || (0==panel[srcPanel].GetTotSelects() && i==panel[srcPanel].GetHot()))
		{	if(file == panel[srcPanel].GetItem(i)->attribute)
			{	MyStringCpy(Name,MAX_PATH-1,panel[srcPanel].GetItem(i)->Name);
				int l=MyStringCpy(FullPathAndName,MAX_PATH-1,panel[srcPanel].GetPath());
				if('*'==FullPathAndName[l-1])//MyStringRemoveLastCharCheckPre(FullPathAndName,MAX_PATH-1,'*','\\');
				if('\\'==FullPathAndName[l-2])
					FullPathAndName[--l]=0;
				l+=MyStringCpy(&FullPathAndName[l],MAX_PATH-l,panel[srcPanel].GetItem(i)->Name);//MyStringCat(FullPathAndName,MAX_PATH-1,panel[srcPanel].GetItem(i)->Name);
				sz += panel[srcPanel].GetItem(i)->size;

				SendMessage(dlgEdit1,EM_REPLACESEL, (WPARAM)FALSE, (LPARAM)(LPCSTR)FullPathAndName);
				SendMessage(dlgEdit1,EM_REPLACESEL, (WPARAM)FALSE, (LPARAM)(LPCSTR)RetCar);
				SendMessage(dlgEdit1,EM_SCROLLCARET,(WPARAM)0, (LPARAM)0);

				if(rename1File!=srcType)
				{	destPath[destPathLn++]='\\';//MyStringCat(destPath,MAX_PATH-1,"\\");
					//destPath[destPathln]=0;
					MyStringCpy(&destPath[destPathLn],(int)(MAX_PATH-destPathLn),panel[srcPanel].GetItem(i)->Name);//MyStringCat(destPath,MAX_PATH-1,panel[srcPanel].GetItem(i)->Name);
				}
				SendMessage(dlgEdit2,EM_REPLACESEL, (WPARAM)FALSE, (LPARAM)(LPCSTR)destPath);
				SendMessage(dlgEdit2,EM_REPLACESEL, (WPARAM)FALSE, (LPARAM)(LPCSTR)RetCar);
				SendMessage(dlgEdit2,EM_SCROLLCARET,(WPARAM)0, (LPARAM)0);
				destPath[destPathLn] = 0;
				++tot;
			}
			else if(folder == panel[srcPanel].GetItem(i)->attribute)
			{	int fl=panel[srcPanel].GetFullPathAndName(i,FullPathAndName,MAX_PATH);
 				SendMessage(dlgEdit1,EM_REPLACESEL, (WPARAM)FALSE, (LPARAM)L"");
				SendMessage(dlgEdit1,EM_REPLACESEL, (WPARAM)FALSE, (LPARAM)(LPCSTR)RetCar);
				SendMessage(dlgEdit1,EM_SCROLLCARET,(WPARAM)0, (LPARAM)0);

				if(unchange==srcType)
				{	int l=MyStringCpy(Name,MAX_PATH-1,destPath);
					MyStringCpy(&Name[l],MAX_PATH-l,panel[srcPanel].GetItem(i)->Name);//MyStringCat(Name,MAX_PATH-1,panel[srcPanel].GetItem(i)->Name);
				}
				else if(rename1Folder==srcType)
				{	MyStringCpy(Name,MAX_PATH-1,destPath);
				}
				else
				{	int l=MyStringCpy(Name,MAX_PATH-1,destPath);
					Name[l++]='\\';//MyStringCat(Name,MAX_PATH-1,"\\");
					//Name[l]=0;
					MyStringCpy(&Name[l],MAX_PATH-l,panel[srcPanel].GetItem(i)->Name);//MyStringCat(Name,MAX_PATH-1,panel[srcPanel].GetItem(i)->Name);
				}

				SendMessage(dlgEdit2,EM_REPLACESEL,(WPARAM)FALSE,(LPARAM)(LPCSTR)Name);
				SendMessage(dlgEdit2,EM_REPLACESEL,(WPARAM)FALSE,(LPARAM)(LPCSTR)RetCar);
				SendMessage(dlgEdit2,EM_SCROLLCARET,(WPARAM)0, (LPARAM)0);
				++tot;//folderniyam;

				wchar_t *p=NULL;
				if(unchange==srcType || allToRenFolder==srcType)
					p = wcsrchr(FullPathAndName,'\\');

				FullPathAndName[fl++]='\\';//MyStringCat(FullPathAndName,MAX_PATH-1,"\\*");
				FullPathAndName[fl++]='*';
				FullPathAndName[fl]=0;
				tot += GetFilesInFolderToDlg(FullPathAndName,(int)(p?p-FullPathAndName+1:-1),dlgEdit1,dlgEdit2);
	}	}	}
	return sz;//tot;
}

INT_PTR CALLBACK CopyQueueDlgProc(HWND hDlg,UINT message,WPARAM wParam,LPARAM lParam)
{
static HFONT hf=0;static int hfRef=0;//obshiy hf, dinamik uchun emas:
static HBRUSH br=0;
static HBRUSH brHtBk=0;
	UNREFERENCED_PARAMETER(lParam);
	switch(message)
	{
	case WM_INITDIALOG:
		//OutputDebugString("\nCopyQueueDlgProc WM_INITDIALOG 0");

		//Adjust to center:
		RECT rc; GetWindowRect(hDlg, &rc);
		int width,left,height,top;

		width = rc.right - rc.left;
		left = conf::wndLeft + (conf::wndWidth - width)/2;

		height = rc.bottom - rc.top;
		top = conf::wndTop + (conf::wndHeight - height)/2;
		MoveWindow(hDlg, left, top+20, width, height, TRUE);

		//Load language strings:
		wchar_t s[MAX_PATH];
		LoadString(hInst,IDS_STRINGSW_46,s,MAX_PATH);
		SetWindowText(hDlg,s);
		LoadString(hInst,IDS_STRINGSW_47,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_STATIC,s);
		LoadString(hInst,IDS_STRINGSW_48,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_STATIC5,s);
		LoadString(hInst,IDS_STRINGSW_49,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_BUTTON_TO_BACKGROUND_COPY_QUEUE,s);
		LoadString(hInst,IDS_STRINGSW_50,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_BUTTON_STOP,s);
		LoadString(hInst,IDS_STRINGSW_13,s,MAX_PATH);
		SetDlgItemText(hDlg,IDCANCEL,s);

		PostMessage(GetDlgItem(hDlg,IDC_PROGRESS_COPY_SINGLE),PBM_SETRANGE,0,MAKELPARAM(0,1000));
		PostMessage(GetDlgItem(hDlg,IDC_PROGRESS_COPY_TOTAL ),PBM_SETRANGE,0,MAKELPARAM(0,1000));
		PostMessage(GetDlgItem(hDlg,IDC_PROGRESS_COPY_SINGLE),PBM_SETSTEP,1,0);
		PostMessage(GetDlgItem(hDlg,IDC_PROGRESS_COPY_TOTAL ),PBM_SETSTEP,1,0);

		SendMessage(hDlg,WM_USER+1,0,0);
		SetWindowLong(hDlg,GWLP_USERDATA,(LONG)lParam);
		if(!lParam) return TRUE;//Agar confDlg dan chaqirilgan b-sa,rang-shriftlarini o'zgartirish uchun;

		//OutputDebugString("\nCopyQueueDlgProc WM_INITDIALOG 1");

		CalcSrcAndAvailableDestSize();
		//OutputDebugString("\nCopyQueueDlgProc WM_INITDIALOG 2");
		if(avDstSz < srcSz)
		{	wchar_t txt[MAX_PATH];StringCchPrintf(txt,MAX_PATH-1,L"Available memory in destination is: %d, but needed %d. Start copy to available?",avDstSz,srcSz);
			if(IDCANCEL==MessageBox(NULL,txt,L"Warn:",MB_OKCANCEL|MB_ICONWARNING|MB_SYSTEMMODAL))
			{	EndDialog(hDlg,0);
				return TRUE;
		}	}
		copySrcSz = 0;

		//MyButtonFrRCBtn(hDlg,IDC_BUTTON_TO_BACKGROUND_COPY_QUEUE,conf::Dlg.iBtnsType);
		//MyButtonFrRCBtn(hDlg,IDC_BUTTON_STOP,conf::Dlg.iBtnsType);
		//MyButtonFrRCBtn(hDlg,IDCANCEL,conf::Dlg.iBtnsType);

		static DWORD cpyThrdId;
		//OutputDebugString("\nCopyQueueDlgProc WM_INITDIALOG 3");
		CreateThread(NULL,1024,(LPTHREAD_START_ROUTINE)cpyFileExThrdFnc,
					 hDlg,0,&cpyThrdId);
		return TRUE;
	case WM_CTLCOLORSTATIC:
	case WM_CTLCOLORDLG:
		if(2==conf::Dlg.iBtnsType)//ownedraw
		{	HDC dc;dc = (HDC)wParam;
			SetTextColor(dc,conf::Dlg.dlgRGBs[1][1]);
			SetBkColor(dc,conf::Dlg.dlgRGBs[1][2]);
			return (INT_PTR)br;
		}return 0;
	case WM_CTLCOLOREDIT:
		if(2==conf::Dlg.iBtnsType)//ownedraw
		{	HDC dc = (HDC)wParam;
			SetTextColor(dc,conf::Dlg.dlgRGBs[1][1]);
			SetBkColor(dc,conf::Dlg.dlgRGBs[1][2]);
			return (INT_PTR)br;
		}return 0;
	case WM_CTLCOLORBTN:
		if(2==conf::Dlg.iBtnsType)//ownedraw
		{	HDC dc=(HDC)wParam;
			SetTextColor(dc,conf::Dlg.dlgRGBs[1][4]);
			SetBkColor(dc,conf::Dlg.dlgRGBs[1][5]);
			return (INT_PTR)brHtBk;
		}return 0;
	case WM_DRAWITEM://WM_CTLCOLORBTN dagi knopkalar:
		if(2==conf::Dlg.iBtnsType)//ownedraw
		{	LPDRAWITEMSTRUCT lpdis;lpdis = (LPDRAWITEMSTRUCT)lParam;
			GetWindowText(lpdis->hwndItem,s,64);
			UINT uStyle;uStyle = DFCS_BUTTONPUSH;
			rc = lpdis->rcItem;
			if(lpdis->itemState & ODS_SELECTED)
			{	uStyle |= DFCS_PUSHED;
				rc.left+=2;rc.top+=2;
			}
			DrawFrameControl(lpdis->hDC, &lpdis->rcItem, DFC_BUTTON, uStyle);
			if(lpdis->itemState & ODS_SELECTED)
				{rc.left+=1;rc.top+=1;rc.bottom-=2;rc.right-=3;}
			else
				{rc.left+=1;rc.top+=2;rc.bottom-=3;rc.right-=3;}
			FillRect(lpdis->hDC,&rc,brHtBk);//DrawText(lpdis->hDC,"                                                  ",50,&rc,DT_SINGLELINE|DT_VCENTER|DT_INTERNAL|DT_LEFT);
			if(lpdis->itemState & ODS_SELECTED)
				{rc.left-=1;rc.top-=1;rc.bottom+=3;rc.right+=3;}
			else
				{rc.left-=1;rc.top-=2;rc.bottom+=2;rc.right+=3;}
			DrawText(lpdis->hDC,s,MyStringLength(s,64),&rc,DT_SINGLELINE|DT_VCENTER|DT_CENTER);
			return TRUE;
		}return 0;
	case WM_USER+1://hf obshiy uchun, dinamik o'zgartirish uchun emas:
		if(0==hfRef)
		{	hf = CreateFontIndirect(&conf::Dlg.dlgFnts[1]);
			br = CreateSolidBrush(conf::Dlg.dlgRGBs[1][0]);
			brHtBk = CreateSolidBrush(conf::Dlg.dlgRGBs[1][5]);
		}
		SendMessage(GetDlgItem(hDlg,IDC_STATIC),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_STATIC5),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_BUTTON_TO_BACKGROUND_COPY_QUEUE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_BUTTON_STOP),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDCANCEL),WM_SETFONT,(WPARAM)hf,TRUE);
		++hfRef;
		return 0;//GWLP_USERDATA
	case WM_DESTROY:
		if(--hfRef<1)
		{	DeleteObject(hf);
			DeleteObject(br);
			DeleteObject(brHtBk);
		}
		return 0;
	case WM_USER+2://Dinamik o'zgartirish uchun:
		DeleteObject(hf);hfRef=1;
		hf = CreateFontIndirect(&conf::Dlg.dlgFnts[1]);
		SendMessage(GetDlgItem(hDlg,IDC_STATIC),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_STATIC5),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_BUTTON_TO_BACKGROUND_COPY_QUEUE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_BUTTON_STOP),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDCANCEL),WM_SETFONT,(WPARAM)hf,TRUE);
		return 0;//GWLP_USERDATA
	case WM_USER+3://Dinamik o'zgartirish uchun, colorni:
		DeleteObject(br);DeleteObject(brHtBk);hfRef=1;
		br = CreateSolidBrush(conf::Dlg.dlgRGBs[1][0]);
		brHtBk = CreateSolidBrush(conf::Dlg.dlgRGBs[1][5]);
		RedrawWindow(hDlg,NULL,NULL,RDW_INVALIDATE|RDW_ALLCHILDREN);
		return 0;//GWLP_USERDATA
	case WM_COMMAND:
		switch(LOWORD(wParam))
		{	case IDC_BUTTON_TO_BACKGROUND_COPY_QUEUE:
				if(!GetWindowLong(hDlg,GWLP_USERDATA))return TRUE;
				PostThreadMessage(cpyThrdId,MYWM_GOTOBCKGRND,0,0);
				return (INT_PTR)TRUE;
			case IDC_BUTTON_STOP:
				if(!GetWindowLong(hDlg,GWLP_USERDATA))return TRUE;
				PostThreadMessage(cpyThrdId,MYWM_STOP,0,0);
				return (INT_PTR)TRUE;
			case IDCANCEL:
				if(!GetWindowLong(hDlg,GWLP_USERDATA))return TRUE;
				PostThreadMessage(cpyThrdId,MYWM_CANCEL,0,0);
				EndDialog(hDlg,0);
				return (INT_PTR)TRUE;
			//18.7.2014:
			case IDC_BUTTON1:// \/ To rolldown
				if(!GetWindowLongPtr(hDlg,GWLP_USERDATA)) return TRUE;
				PostThreadMessage(cpyThrdId,MYWM_ROLLDOWN,0,0);
				return (INT_PTR)TRUE;
			case IDC_BUTTON2:// Erase all copied items
				if(!GetWindowLongPtr(hDlg,GWLP_USERDATA)) return TRUE;
				PostThreadMessage(cpyThrdId,MYWM_ERASE_COPIED_AND_EXIT,0,0);
				return (INT_PTR)TRUE;
			case IDC_BUTTON3:// Erase checked copied items
				if(!GetWindowLongPtr(hDlg,GWLP_USERDATA)) return TRUE;
				PostThreadMessage(cpyThrdId,MYWM_ERASE_COPIED_AND_EXIT,1,0);
				return (INT_PTR)TRUE;
			case IDC_BUTTON4:// Set check all copied
				if(!GetWindowLongPtr(hDlg,GWLP_USERDATA)) return TRUE;
				PostThreadMessage(cpyThrdId,MYWM_SET_CHECK_COPIED,0,0);
				return (INT_PTR)TRUE;
			case IDC_BUTTON5:// Unset check all copied
				if(!GetWindowLongPtr(hDlg,GWLP_USERDATA)) return TRUE;
				PostThreadMessage(cpyThrdId,MYWM_SET_CHECK_COPIED,1,0);
				return (INT_PTR)TRUE;
		}
		break;
	}
	return (INT_PTR)FALSE;
}

BOOL ShowCopyDlg(Panel *frPanel)
{
	if(frPanel->GetTotSelects()==0)
	if(frPanel->GetHot()<1 || frPanel->GetHot()>frPanel->GetTotItems()-1)
		return TRUE;

	//if(conf::Dlg.iTotPanels<3)//2dan ko'p bo'lsa, copydlgdan ketadur;
	if(directFolder==frPanel->GetEntry()->GetCrntRecType() && archElem==frPanel->GetOpponent()->GetEntry()->GetCrntRecType())
		return archive::ToArjShowDlg(frPanel,frPanel->GetOpponent());

	if(archElem==frPanel->GetEntry()->GetCrntRecType() && archElem==frPanel->GetOpponent()->GetEntry()->GetCrntRecType())
		return archive::FrArjToArjShowDlg(frPanel,frPanel->GetOpponent());

	if(rndPathList==frPanel->GetOpponent()->GetEntry()->GetCrntRecType())
	{	MessageBox(hWnd,L"Do not copy to results list of searching.",L"Warn!!!",MB_OK|MB_ICONWARNING|MB_SYSTEMMODAL);
		return FALSE;
	}
	
	int r = 0; 
	switch(conf::iCopyDlgBtnPlaces)
	{	case 0:
			r = (int)DialogBoxParam(hInst,MAKEINTRESOURCE(IDD_DIALOG_COPY_MASTER),hWnd,CopyDlgProc,(LPARAM)frPanel);
			break;
		case 1:
			r = (int)DialogBoxParam(hInst,MAKEINTRESOURCE(IDD_DIALOG_COPY_MASTER1),hWnd,CopyDlgProc,(LPARAM)frPanel);
		case 2:
			r = (int)DialogBoxParam(hInst,MAKEINTRESOURCE(IDD_DIALOG_COPY_MASTER2),hWnd,CopyDlgProc,(LPARAM)frPanel);
			break;
	}

	//OutputDebugString("\nShowCopyDlg 1");

	if(r>0)
	{	//OutputDebugString("\nShowCopyDlg 2");

		if(socketCl==panel[frPanel->iThis].GetEntry()->GetCrntRecType() ||
		   socketCl==frPanel->GetOpponent()->GetEntry()->GetCrntRecType()  )
		{ //OutputDebugString("\nShowCopyDlg 3");
		  r=(int)DialogBoxParam(hInst,MAKEINTRESOURCE(IDD_DIALOG_COPY_QUEUE),hWnd,linkSock::CopyQueueDlgProc,1);
		}
		//archive element processing: **************************************************************************************************
		else if(archElem==panel[frPanel->iThis].GetEntry()->GetCrntRecType() && directFolder==frPanel->GetOpponent()->GetEntry()->GetCrntRecType()) //*
		{ //OutputDebugString("\nShowCopyDlg 3");																					 //*
		  r=(int)DialogBoxParam(hInst,MAKEINTRESOURCE(IDD_DIALOG_COPY_QUEUE),hWnd,archive::CopyQueueDlgProc,0);						 //*
		}																															 //*
		//{ //OutputDebugString("\nShowCopyDlg 3");	 yuqoriga qara																	 //*
		  //r = DialogBoxParam(hInst,MAKEINTRESOURCE(IDD_DIALOG_COPY_QUEUE),hWnd,archive::CopyQueueDlgProc,2);						 //*
		//}																															 //*		
		else if(archElem==panel[frPanel->iThis].GetEntry()->GetCrntRecType() && archElem==frPanel->GetOpponent()->GetEntry()->GetCrntRecType())	 //*
		{ //OutputDebugString("\nShowCopyDlg 3");																					 //*
		  //r = DialogBoxParam(hInst,MAKEINTRESOURCE(IDD_DIALOG_COPY_QUEUE),hWnd,archive::CopyFrToQueueDlgProc,1);					 //*
		}//exd of archive element processing: ******************************************************************************************
		else
		{	//OutputDebugString("\nShowCopyDlg 4");
			if(linkSock::sockDlg[frPanel->iOpponent])
				Err::FlipMsg(L"Can't copy to client socket...",2000);
			else if(linkSock::sockDlg[frPanel->iThis])
				Err::FlipMsg(L"Can't copy from client socket...",2000);
			else
			{	//OutputDebugString("\nShowCopyDlg 5");
				if(single==copyType)
					r=(int)DialogBoxParam(hInst,MAKEINTRESOURCE(IDD_DIALOG_COPY_QUEUE),hWnd,CopyQueueDlgProc,1);
				else if(addToBack==copyType)
					r = fBckgrndCopyOper::AddToQueueFrCopyOperation();
	}	}	}
	frPanel->FreeSelection();//frPanel->DeselectAllWithout(-1);
	frPanel->SetFocus();
	return FALSE;//(r>0?TRUE:FALSE);
}

static int iBckrndCpyWndCnt=-1;
INT_PTR CALLBACK CopyBckgrndDlgProc(HWND hDlg,UINT message,WPARAM wParam,LPARAM lParam)
{
static HFONT hf=0;static int hfRef=0;//obshiy hf, dinamik uchun emas:
static HBRUSH br=0;
static HBRUSH brHtBk=0;
	switch(message)
	{
	case WM_INITDIALOG:
		++iBckrndCpyWndCnt;

		SetWindowLongPtr(hDlg,GWLP_USERDATA,lParam);
		//Adjust to center:
		RECT rc; GetWindowRect(hDlg, &rc);
		int width,height,x,y;//left,top;

		width = rc.right - rc.left;
		//left = conf::wndLeft + (conf::wndWidth - width)/2;
		height = rc.bottom - rc.top;
		//top = conf::wndTop + (conf::wndHeight - height)/2;

		x = (width*iBckrndCpyWndCnt)%conf::wndWidth;
		if(x>conf::wndWidth)x=0;
		y = ((width*iBckrndCpyWndCnt)/conf::wndWidth)*height;
		if(y>conf::wndHeight)y=0;

		MoveWindow(hDlg,x,y,width,height,TRUE);

		//Load language strings:
		wchar_t s[MAX_PATH];
		LoadString(hInst,IDS_STRINGSW_46,s,MAX_PATH);
		SetWindowText(hDlg,s);
		LoadString(hInst,IDS_STRINGSW_47,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_STATIC,s);
		LoadString(hInst,IDS_STRINGSW_48,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_STATIC5,s);
		//LoadString(hInst,IDS_STRINGSW_49,s,MAX_PATH);
		//SetDlgItemText(hDlg,IDC_BUTTON_TO_BACKGROUND_COPY_QUEUE,s);
		ShowWindow(GetDlgItem(hDlg,IDC_BUTTON_TO_BACKGROUND_COPY_QUEUE),SW_HIDE);

		cpyTrdDat *pdat;pdat = (cpyTrdDat*)lParam;
		if(pdat && pdat->bStop)
			LoadString(hInst,IDS_STRINGSW_3,s,MAX_PATH);
		else
			LoadString(hInst,IDS_STRINGSW_50,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_BUTTON_STOP,s);
		LoadString(hInst,IDS_STRINGSW_13,s,MAX_PATH);
		SetDlgItemText(hDlg,IDCANCEL,s);

		PostMessage(GetDlgItem(hDlg,IDC_PROGRESS_COPY_SINGLE),PBM_SETRANGE,0,MAKELPARAM(0,1000));
		PostMessage(GetDlgItem(hDlg,IDC_PROGRESS_COPY_TOTAL ),PBM_SETRANGE,0,MAKELPARAM(0,1000));
		PostMessage(GetDlgItem(hDlg,IDC_PROGRESS_COPY_SINGLE),PBM_SETSTEP,1,0);
		PostMessage(GetDlgItem(hDlg,IDC_PROGRESS_COPY_TOTAL ),PBM_SETSTEP,1,0);
		
		//MyButtonFrRCBtn(hDlg,IDC_BUTTON_STOP,conf::Dlg.iBtnsType);
		//MyButtonFrRCBtn(hDlg,IDCANCEL,conf::Dlg.iBtnsType);

		SendMessage(hDlg,WM_USER+1,0,0);
		if(lParam) return TRUE;//Agar confDlg dan chaqirilgan b-sa,rang-shriftlarini o'zgartirish uchun;

		return TRUE;
	case WM_CTLCOLORSTATIC:
	case WM_CTLCOLORDLG:
		if(2==conf::Dlg.iBtnsType)
		{	HDC dc;dc = (HDC)wParam;
			SetTextColor(dc,conf::Dlg.dlgRGBs[1][1]);
			SetBkColor(dc,conf::Dlg.dlgRGBs[1][2]);
			return (INT_PTR)br;
		}return 0;
	case WM_CTLCOLOREDIT:
		if(2==conf::Dlg.iBtnsType)
		{	HDC dc = (HDC)wParam;
			SetTextColor(dc,conf::Dlg.dlgRGBs[1][1]);
			SetBkColor(dc,conf::Dlg.dlgRGBs[1][2]);
			return (INT_PTR)br;
		}
	case WM_CTLCOLORBTN:
		if(2==conf::Dlg.iBtnsType)
		{	HDC dc=(HDC)wParam;
			SetTextColor(dc,conf::Dlg.dlgRGBs[1][4]);
			SetBkColor(dc,conf::Dlg.dlgRGBs[1][5]);
			return (INT_PTR)brHtBk;
		}
	case WM_DRAWITEM://WM_CTLCOLORBTN dagi knopkalar:
		if(2==conf::Dlg.iBtnsType)
		{	LPDRAWITEMSTRUCT lpdis;lpdis = (LPDRAWITEMSTRUCT)lParam;
			GetWindowText(lpdis->hwndItem,s,64);
			UINT uStyle;uStyle = DFCS_BUTTONPUSH;
			rc = lpdis->rcItem;
			if(lpdis->itemState & ODS_SELECTED)
			{	uStyle |= DFCS_PUSHED;
				rc.left+=2;rc.top+=2;
			}
			DrawFrameControl(lpdis->hDC, &lpdis->rcItem, DFC_BUTTON, uStyle);
			if(lpdis->itemState & ODS_SELECTED)
				{rc.left+=1;rc.top+=1;rc.bottom-=2;rc.right-=3;}
			else
				{rc.left+=1;rc.top+=2;rc.bottom-=3;rc.right-=3;}
			FillRect(lpdis->hDC,&rc,brHtBk);//DrawText(lpdis->hDC,"                                                  ",50,&rc,DT_SINGLELINE|DT_VCENTER|DT_INTERNAL|DT_LEFT);
			if(lpdis->itemState & ODS_SELECTED)
				{rc.left-=1;rc.top-=1;rc.bottom+=3;rc.right+=3;}
			else
				{rc.left-=1;rc.top-=2;rc.bottom+=2;rc.right+=3;}
			DrawText(lpdis->hDC,s,MyStringLength(s,64),&rc,DT_SINGLELINE|DT_VCENTER|DT_CENTER);
			return TRUE;
		}return 0;
	case WM_USER+1://hf obshiy uchun, dinamik o'zgartirish uchun emas:
		if(0==hfRef)
		{	hf = CreateFontIndirect(&conf::Dlg.dlgFnts[1]);
			br = CreateSolidBrush(conf::Dlg.dlgRGBs[1][0]);
			brHtBk = CreateSolidBrush(conf::Dlg.dlgRGBs[1][5]);
		}
		SendMessage(GetDlgItem(hDlg,IDC_STATIC),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_STATIC5),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_BUTTON_TO_BACKGROUND_COPY_QUEUE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_BUTTON_STOP),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDCANCEL),WM_SETFONT,(WPARAM)hf,TRUE);
		++hfRef;
		return 0;//GWLP_USERDATA
	case WM_DESTROY:
		if(--hfRef<1)
		{	DeleteObject(hf);
			DeleteObject(br);
			DeleteObject(brHtBk);
		}
		--iBckrndCpyWndCnt;
		return 0;
	case WM_USER+2://Dinamik o'zgartirish uchun:
		DeleteObject(hf);hfRef=1;
		hf = CreateFontIndirect(&conf::Dlg.dlgFnts[1]);
		SendMessage(GetDlgItem(hDlg,IDC_STATIC),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_STATIC5),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_BUTTON_TO_BACKGROUND_COPY_QUEUE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_BUTTON_STOP),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDCANCEL),WM_SETFONT,(WPARAM)hf,TRUE);
		return 0;//GWLP_USERDATA
	case WM_USER+3://Dinamik o'zgartirish uchun, colorni:
		DeleteObject(br);DeleteObject(brHtBk);hfRef=1;
		br = CreateSolidBrush(conf::Dlg.dlgRGBs[1][0]);
		brHtBk = CreateSolidBrush(conf::Dlg.dlgRGBs[1][5]);
		RedrawWindow(hDlg,NULL,NULL,RDW_INVALIDATE|RDW_ALLCHILDREN);
		return 0;//GWLP_USERDATA
	case WM_COMMAND:
		switch(LOWORD(wParam))
		{	case IDC_BUTTON_STOP:
				PostThreadMessage(GetCurrentThreadId(),MYWM_STOP,0,0);
				return (INT_PTR)TRUE;
			case IDCANCEL:
				PostThreadMessage(GetCurrentThreadId(),MYWM_CANCEL,0,0);
				DestroyWindow(hDlg);
				return (INT_PTR)TRUE;
		}
		break;
	}
	return (INT_PTR)FALSE;
}

DWORD CALLBACK cpyPrgrssRout(LARGE_INTEGER	TotalFileSize,
							 LARGE_INTEGER	TotalBytesTransferred,
							 LARGE_INTEGER	StreamSize,
							 LARGE_INTEGER	StreamBytesTransferred,
							 DWORD			dwStreamNumber,
							 DWORD			dwCallbackReason,
							 HANDLE			hSourceFile,
							 HANDLE			hDestinationFile,
							 LPVOID			lpData)
{wchar_t s[MAX_PATH];
	cpyTrdDat *pdat = (cpyTrdDat*)lpData;	
if(!pdat->bStop)
{	__int64 tfs = ((__int64)TotalFileSize.HighPart << 32) | TotalFileSize.LowPart;
	__int64 tbt = ((__int64)TotalBytesTransferred.HighPart << 32) | TotalBytesTransferred.LowPart;
	double prgrsPos = tfs?(1000.0*tbt/tfs):1000.0;
	PostMessage(GetDlgItem(pdat->hDlg,IDC_PROGRESS_COPY_SINGLE),PBM_SETPOS,(int)prgrsPos,0);

	tbt += copySrcSz;
	double prgrsPosTot = srcSz?(1000.0*tbt/srcSz):1000.0;
	PostMessage(GetDlgItem(pdat->hDlg,IDC_PROGRESS_COPY_TOTAL),PBM_SETPOS,(int)prgrsPosTot,0);

	if(0==TotalBytesTransferred.QuadPart)
	{	int l=GetDlgItemText(pdat->hDlg,IDC_STATIC,s,MAX_PATH);
		wchar_t *p = wcschr(s,':');
		if(!p)
		{	p = &s[l];
			*p++ = ':';
		}
		else ++p;
		wchar_t *pp = wcsrchr(pdat->stack[pdat->iCrntFileCopy].Name,'\\');
		MyStringCpy(p,MAX_PATH-l,pp?(pp+1):pdat->stack[pdat->iCrntFileCopy].Name);
		SetDlgItemText(pdat->hDlg,IDC_STATIC,s);
	}
	// ***************** % calculating: ***********************
	StringCchPrintf(s,MAX_PATH-1,L"%.2f %s",0.1f*prgrsPos,L"%");
	SetDlgItemText(pdat->hDlg,IDC_STATIC1,s);
	StringCchPrintf(s,MAX_PATH-1,L"%.2f %s",100.0-0.1*prgrsPos,L"%");
	SetDlgItemText(pdat->hDlg,IDC_STATIC3,s);
	StringCchPrintf(s,MAX_PATH-1,L"%.2f %s",0.1f*prgrsPosTot,L"%");
	SetDlgItemText(pdat->hDlg,IDC_STATIC6,s);
	StringCchPrintf(s,MAX_PATH-1,L"%.2f %s",100.0-0.1*prgrsPosTot,L"%");
	SetDlgItemText(pdat->hDlg,IDC_STATIC8,s);

	// ***************** tick calculating: ********************
	DWORD tick = GetTickCount() - pdat->beginTick - pdat->stopTick[0];
	MyTimeToString(s, tick);
	SetDlgItemText(pdat->hDlg,IDC_STATIC2,s);
	if(prgrsPos>0.0f)
	{	MyTimeToString(s, (int)(tick*(1000.0f-prgrsPos)/prgrsPos));
		SetDlgItemText(pdat->hDlg,IDC_STATIC4,s);
	}
	
	tick = GetTickCount() - pdat->beginTickTot - pdat->stopTickTot[0];
	MyTimeToString(s, tick);
	SetDlgItemText(pdat->hDlg,IDC_STATIC7,s);
	if(prgrsPosTot>0.0f)
	{	MyTimeToString(s, (int)(tick*(1.0f-0.001f*prgrsPosTot)/(0.001f*prgrsPosTot)));
		SetDlgItemText(pdat->hDlg,IDC_STATIC9,s);
}	}
	
	if(pdat->bCancel)
		return PROGRESS_CANCEL;

	//Agar 1tagina fayl b-sa:
	MSG msg;//Only thread message:

Loop:
	if(pdat->bSwtchToBckgrnd)
	{	while(PeekMessage(&msg,pdat->hDlg,0,0,PM_REMOVE))
		{	
			//static int i=0;
			//char ss[32];sprintf(ss,"\n %d ",i++);
			//OutputDebugString(ss);
			//OutputDebugString(GetWinNotifyText(msg.message));
			
			DispatchMessage(&msg);//from bckgrnd queue:
	}	}

	//message from thread queue:
	if(PeekMessage(&msg,(HWND)-1,MYWM_CANCEL-1,MYWM_CANCEL+10,PM_REMOVE))
	{	
		//static int i=0;
		//char ss[32];sprintf(ss,"\n %d ",i++);
		//OutputDebugString(ss);
		//OutputDebugString(GetWinNotifyText(msg.message));

		switch(msg.message)
		{	case MYWM_CANCEL:
				return PROGRESS_CANCEL;
			case MYWM_STOP:
				if(pdat->bStop)
				{	LoadString(hInst,IDS_STRINGSW_50,s,MAX_PATH);
					SetDlgItemText(pdat->hDlg,IDC_BUTTON_STOP,s);
					pdat->stopTick[0] = GetTickCount() - pdat->stopTick[1];
					pdat->stopTickTot[0] = GetTickCount() - pdat->stopTickTot[1];
					pdat->bStop = FALSE;
				}
				else
				{	LoadString(hInst,IDS_STRINGSW_3,s,MAX_PATH);
					SetDlgItemText(pdat->hDlg,IDC_BUTTON_STOP,s);
					pdat->bStop = TRUE;
					pdat->stopTick[1] = pdat->stopTickTot[1] = GetTickCount();
					Sleep(250);
					goto Loop;
				}
				break;
			case MYWM_GOTOBCKGRND:
				EndDialog(pdat->hDlg,0);//DestroyWindow
				pdat->hDlg = CreateDialogParam(hInst,
								MAKEINTRESOURCE(IDD_DIALOG_COPY_QUEUE),
								hWnd,CopyBckgrndDlgProc,(LPARAM)pdat);
				ShowWindow(pdat->hDlg,SW_SHOW);
				pdat->bSwtchToBckgrnd = TRUE;
				break;
			//18.07.2014:
			case MYWM_ROLLDOWN:RECT rc;
				GetWindowRect(pdat->hDlg,&rc);
				if(rc.bottom-rc.top<500)//STOP qilamiz;
				{	MoveWindow(pdat->hDlg,rc.left,rc.top,rc.right-rc.left,rc.bottom-rc.top+400,TRUE);
					LoadString(hInst,IDS_STRINGSW_3,s,MAX_PATH);
					SetDlgItemText(pdat->hDlg,IDC_BUTTON_STOP,s);
					pdat->bStop = TRUE;
					pdat->stopTick[1] = pdat->stopTickTot[1] = GetTickCount();
					Sleep(250);
					goto Loop;
				}
				else//START qilmaymiz;
					MoveWindow(pdat->hDlg,rc.left,rc.top,rc.right-rc.left,rc.bottom-rc.top-400,TRUE);
				break;
			case MYWM_ERASE_COPIED_AND_EXIT://msg.wParam==0->Erase all copied items,else only checked
				EraseFilesFrLB(GetDlgItem(pdat->hDlg,IDC_TREE1),(int)msg.wParam);
				pdat->iRollDown=(int)msg.wParam;
				return PROGRESS_CANCEL;
			case MYWM_SET_CHECK_COPIED://msg.wParam==0->Set check for already copied,else for only checked
				SelectListBoxItems(GetDlgItem(pdat->hDlg,IDC_TREE1),(int)msg.wParam);
				goto Loop;
 	}	}
	else if(pdat->bStop)
	{	Sleep(250);
		goto Loop;
	}

	return PROGRESS_CONTINUE;
}

VOID cpyFileExThrdFnc(LPVOID lpar)
{
cpyTrdDat dat; dat.hDlg = (HWND)lpar;
	dat.stack=0;
	dat.bStop = FALSE;
	dat.bCancel = FALSE;
	dat.bSwtchToBckgrnd = FALSE;
	dat.thrId = GetCurrentThreadId();
	dat.beginTick = dat.beginTickTot = GetTickCount();
	dat.stopTick[0] = dat.stopTickTot[0] = 0;
	dat.iRollDown=-1;
	enCheckCopyFilesToExisting = showEach;

 wchar_t dst[MAX_PATH],buf[MAX_PATH];
 size_t dstPathLn;

 int totFiles = GetSelectedFilesCnt();
 if(!totFiles)goto End;
 dat.stack = (CpyStack*)malloc(totFiles*sizeof(CpyStack));
 GetSelectedFiles(dat.stack);
 CutSelectedNames(dat.stack,panel[srcPanel].GetPath(),totFiles);

 BOOL bSkipAll=FALSE;
 dstPathLn=MyStringCpy(dst,MAX_PATH-1,destPath);
 if(allToRenFolder==srcType)
 {	if('\\'!=dst[dstPathLn-1])
	{	if('*'!=dst[dstPathLn-1])
		{	dst[dstPathLn++]='\\';//MyStringCat(dst,MAX_PATH-1,"\\");//Yangi yo'l kiritsa;
 			dst[dstPathLn]=0;
		}
		else dst[--dstPathLn]=0;
	}
	int m=MessageBox(dat.hDlg,L"Create this directory?",dst,MB_YESNOCANCEL|MB_ICONWARNING|MB_SYSTEMMODAL);
	if(IDNO==m)
	{	srcType=unchange;
		wchar_t *p=wcsrchr(dst,'\\');
		if(p) *(p+1)=0;
	}
	else if(IDCANCEL==m)
		goto End;	
  	if(!MyCreateDirectory(dst,NULL))//yangi yo'lini avval yaratib olsun;
		goto End;
 }

 for(dat.iCrntFileCopy=0; dat.iCrntFileCopy<totFiles; dat.iCrntFileCopy++)
 {


 if(unchange==srcType || allToRenFolder==srcType)
	MyStringCpy(&dst[dstPathLn],(int)(MAX_PATH-dstPathLn),dat.stack[dat.iCrntFileCopy].Name);//MyStringCat(dst,MAX_PATH-1,dat.stack[dat.iCrntFileCopy].Name);
 else
 {	if(allToRenFolder==srcType)
	{	//char *p=NULL;
		//if(dat.iCrntFileCopy>0)
		//if(folder==dat.stack[dat.iCrntFileCopy].attribute)//o'zgartirsa:
		//	p = strchr(dat.stack[dat.iCrntFileCopy].Name,'\\');
		//MyStringCat(dst,MAX_PATH-1,dat.stack[dat.iCrntFileCopy].Name);
 	}
	else if(rename1Folder==srcType)
	{	if(dat.iCrntFileCopy>0)
		{	wchar_t *p=NULL;
			if(folder==dat.stack[0].attribute)//o'zgartirsa:
				p = wcschr(dat.stack[dat.iCrntFileCopy].Name,'\\');
			MyStringCpy(&dst[dstPathLn],(int)(MAX_PATH-dstPathLn),p?p:dat.stack[dat.iCrntFileCopy].Name);//MyStringCat(dst,MAX_PATH-1,p?p:dat.stack[dat.iCrntFileCopy].Name);
 }	}	}


 if(mCopyFileEx==copyMethod)
 {if(file==dat.stack[dat.iCrntFileCopy].attribute)
  { if(!wcscmp(dat.stack[dat.iCrntFileCopy].FullPathAndName,dst))
    {	LoadString(hInst,IDS_STRINGSW_51,buf,MAX_PATH);
		MessageBox(NULL,buf,L"Err.",MB_OK|MB_ICONWARNING|MB_SYSTEMMODAL);
    }
    else
	{int r=fBckgrndCopyOper::CheckCopyFilesToExisting(dat.hDlg,dat.stack[dat.iCrntFileCopy].FullPathAndName,dst);
	 if(r==overwrite || r==overwriteAll)
     {//if(!MyCopyFileEx(dat.stack[dat.iCrntFileCopy].FullPathAndName,dst,cpyPrgrssRout,&dat,FALSE,0))
	 	if(r==overwriteAll)
		 enCheckCopyFilesToExisting = (EnCheckCopyFilesToExisting)r;
LoopCopy:
      if(!CopyFileEx(dat.stack[dat.iCrntFileCopy].FullPathAndName,dst,cpyPrgrssRout,&dat,FALSE,0) && (!bSkipAll))
	  {	if(dat.iRollDown>-1)
			goto End;
		LPVOID* par[3]={(LPVOID*)GetLastError(),(LPVOID*)dat.stack[dat.iCrntFileCopy].FullPathAndName,(LPVOID*)dst};
		int r = (int)DialogBoxParam(hInst,MAKEINTRESOURCE(IDD_DIALOG_CHOISE_ACTION),dat.hDlg,fDelOper::actnDlgProc1,(LPARAM)par);
		if(0==r) goto End;//Cancel action;
		if(1==r) goto LoopCopy;
		if(3==r)
			bSkipAll=TRUE;//2-skip,3-skipAll;
	 }}
	 else if(r==skipAll || r==skip)
	 {	if(r==skipAll)
		 enCheckCopyFilesToExisting = (EnCheckCopyFilesToExisting)r;
     	goto skipOne;
	 }
	 else if(r==cancel)
     	goto End;
	 else if(r==rename1 || r==renameAll)
	 {	if(r==renameAll)
		 enCheckCopyFilesToExisting = (EnCheckCopyFilesToExisting)r;
LoopRename:
	  if(!MyCopyRenameFileEx(dat.stack[dat.iCrntFileCopy].FullPathAndName,dst,cpyPrgrssRout,&dat,FALSE,0) && (!bSkipAll))
	  {	if(dat.iRollDown>-1)
			goto End;		
		LPVOID* par[3]={(LPVOID*)GetLastError(),(LPVOID*)dat.stack[dat.iCrntFileCopy].FullPathAndName,(LPVOID*)dst};
		int r = (int)DialogBoxParam(hInst,MAKEINTRESOURCE(IDD_DIALOG_CHOISE_ACTION),dat.hDlg,fDelOper::actnDlgProc1,(LPARAM)par);
		if(0==r) goto End;//Cancel action;
		if(1==r) goto LoopRename;
		if(3==r)
			bSkipAll=TRUE;//2-skip,3-skipAll;
	 }}
     else if(r==overwriteOldest || r==overwriteOldestAll)
	 {	if(r==overwriteOldestAll)
		 enCheckCopyFilesToExisting = (EnCheckCopyFilesToExisting)r;
LoopOverOldest:
	  if(!MyCopyOverwriteOldestFileEx(dat.stack[dat.iCrntFileCopy].FullPathAndName,dst,cpyPrgrssRout,&dat,FALSE,0) && (!bSkipAll))
	  {	if(dat.iRollDown>-1)
			goto End;		
		LPVOID* par[3]={(LPVOID*)GetLastError(),(LPVOID*)dat.stack[dat.iCrntFileCopy].FullPathAndName,(LPVOID*)dst};
		int r = (int)DialogBoxParam(hInst,MAKEINTRESOURCE(IDD_DIALOG_CHOISE_ACTION),dat.hDlg,fDelOper::actnDlgProc1,(LPARAM)par);
		if(0==r) goto End;//Cancel action;
		if(1==r) goto LoopOverOldest;
		if(3==r)
			bSkipAll=TRUE;//2-skip,3-skipAll;
	 }}
     else if(r==overwriteLatest || r==overwriteLatestAll)
	 {	if(r==overwriteLatestAll)
		 enCheckCopyFilesToExisting = (EnCheckCopyFilesToExisting)r;
LoopOverLatest:
	  if(!MyCopyOverwriteLatestFileEx(dat.stack[dat.iCrntFileCopy].FullPathAndName,dst,cpyPrgrssRout,&dat,FALSE,0) && (!bSkipAll))
	  {	if(dat.iRollDown>-1)
			goto End;		
		LPVOID* par[3]={(LPVOID*)GetLastError(),(LPVOID*)dat.stack[dat.iCrntFileCopy].FullPathAndName,(LPVOID*)dst};
		int r = (int)DialogBoxParam(hInst,MAKEINTRESOURCE(IDD_DIALOG_CHOISE_ACTION),dat.hDlg,fDelOper::actnDlgProc1,(LPARAM)par);
		if(0==r) goto End;//Cancel action;
		if(1==r) goto LoopOverLatest;
		if(3==r)
			bSkipAll=TRUE;//2-skip,3-skipAll;
	 }}
     else if(r==overwriteBigest || r==overwriteBigestAll)
	 {	if(r==overwriteBigestAll)
		 enCheckCopyFilesToExisting = (EnCheckCopyFilesToExisting)r;
LoopOverBigest:
	  if(!MyCopyOverwriteBigestFileEx(dat.stack[dat.iCrntFileCopy].FullPathAndName,dst,cpyPrgrssRout,&dat,FALSE,0) && (!bSkipAll))
	  {	if(dat.iRollDown>-1)
			goto End;		
		LPVOID* par[3]={(LPVOID*)GetLastError(),(LPVOID*)dat.stack[dat.iCrntFileCopy].FullPathAndName,(LPVOID*)dst};
		int r = (int)DialogBoxParam(hInst,MAKEINTRESOURCE(IDD_DIALOG_CHOISE_ACTION),dat.hDlg,fDelOper::actnDlgProc1,(LPARAM)par);
		if(0==r) goto End;//Cancel action;
		if(1==r) goto LoopOverBigest;
		if(3==r)
			bSkipAll=TRUE;//2-skip,3-skipAll;
	 }}
     else if(r==overwriteLittlest || r==overwriteLittlestAll)
	 {	if(r==overwriteLittlestAll)
		 enCheckCopyFilesToExisting = (EnCheckCopyFilesToExisting)r;
LoopOverLittlest:
	  if(!MyCopyOverwriteLittlestFileEx(dat.stack[dat.iCrntFileCopy].FullPathAndName,dst,cpyPrgrssRout,&dat,FALSE,0) && (!bSkipAll))
	  {	if(dat.iRollDown>-1)
			goto End;		
		LPVOID* par[3]={(LPVOID*)GetLastError(),(LPVOID*)dat.stack[dat.iCrntFileCopy].FullPathAndName,(LPVOID*)dst};
		int r = (int)DialogBoxParam(hInst,MAKEINTRESOURCE(IDD_DIALOG_CHOISE_ACTION),dat.hDlg,fDelOper::actnDlgProc1,(LPARAM)par);
		if(0==r) goto End;//Cancel action;
		if(1==r) goto LoopOverLittlest;
		if(3==r)
			bSkipAll=TRUE;//2-skip,3-skipAll;
	}}}
skipOne:
	copySrcSz += dat.stack[dat.iCrntFileCopy].size;
	avDstSz -= dat.stack[dat.iCrntFileCopy].size;
	PostMessage(GetDlgItem(dat.hDlg,IDC_PROGRESS_COPY_SINGLE),PBM_SETPOS,1000,0);
	PostMessage(GetDlgItem(dat.hDlg,IDC_PROGRESS_COPY_TOTAL ),PBM_SETPOS,
    (int)(srcSz?(1000.0f*copySrcSz/srcSz):1000.0f),0);
	dat.stopTick[0] = 0;
	dat.beginTick = GetTickCount();
  }
  else
  {	
LoopCrea:
	if(!MyCreateDirectory(dst,NULL))
	{	LPVOID* par[2]={(LPVOID*)GetLastError(),(LPVOID*)dst};
		int r = (int)DialogBoxParam(hInst,MAKEINTRESOURCE(IDD_DIALOG_CHOISE_ACTION),dat.hDlg,fDelOper::actnDlgProc,(LPARAM)par);
		if(0==r) goto End;//Cancel action;
		if(1==r) goto LoopCrea;
		if(3==r)
			bSkipAll=TRUE;//2-skip,3-skipAll;
 }} }
 else if(mSHFileOperation==copyMethod)
 {	MySHFileOperation(FO_COPY,dat.stack[dat.iCrntFileCopy].FullPathAndName,NULL,
				FOF_SILENT|FOF_NOCONFIRMATION|FOF_NOCONFIRMMKDIR,FALSE);
 }

 SendDlgItemMessage(dat.hDlg,IDC_TREE1,LB_ADDSTRING,0,(LPARAM)dst);
 dst[dstPathLn]=0;
	
Loop:
	MSG msg;//Only thread message:
	if(PeekMessage(&msg,(HWND)-1,MYWM_CANCEL-1,MYWM_CANCEL+10,PM_REMOVE))
	{	
		//static int i=0;
		//char ss[32];sprintf(ss,"\n %d ",i++);
		//OutputDebugString(ss);
		//OutputDebugString(GetWinNotifyText(msg.message));
		
		switch(msg.message)
		{	case MYWM_CANCEL:
				dat.bCancel = TRUE;
				goto End;
			case MYWM_STOP:
				wchar_t s[MAX_PATH];
				if(dat.bStop)
				{	LoadString(hInst,IDS_STRINGSW_50,s,MAX_PATH);
					SetDlgItemText(dat.hDlg,IDC_BUTTON_STOP,s);
					dat.bStop = FALSE;
				}
				else
				{	LoadString(hInst,IDS_STRINGSW_3,s,MAX_PATH);
					SetDlgItemText(dat.hDlg,IDC_BUTTON_STOP,s);
					dat.bStop = TRUE;
					Sleep(250);
					goto Loop;
				}
				break;
			case MYWM_GOTOBCKGRND:
				EndDialog(dat.hDlg,0);//DestroyWindow
				dat.hDlg = CreateDialogParam(hInst,
								MAKEINTRESOURCE(IDD_DIALOG_COPY_QUEUE),
								hWnd,CopyBckgrndDlgProc,(LPARAM)&dat);
				ShowWindow(dat.hDlg,SW_SHOW);
				dat.bSwtchToBckgrnd = TRUE;
				return;
			//18.07.2014:
			case MYWM_ROLLDOWN:RECT rc;
				GetWindowRect(dat.hDlg,&rc);
				if(rc.bottom-rc.top<500)//STOP qilamiz;
				{	MoveWindow(dat.hDlg,rc.left,rc.top,rc.right-rc.left,rc.bottom-rc.top+400,TRUE);
					LoadString(hInst,IDS_STRINGSW_3,s,MAX_PATH);
					SetDlgItemText(dat.hDlg,IDC_BUTTON_STOP,s);
					dat.bStop = TRUE;
					dat.stopTick[1] = dat.stopTickTot[1] = GetTickCount();
					Sleep(250);
					goto Loop;
				}
				else//START qilmaymiz;
					MoveWindow(dat.hDlg,rc.left,rc.top,rc.right-rc.left,rc.bottom-rc.top-400,TRUE);
				break;
			case MYWM_ERASE_COPIED_AND_EXIT://msg.wParam==0->Erase all copied items,else only checked
				EraseFilesFrLB(GetDlgItem(dat.hDlg,IDC_TREE1),(int)msg.wParam);
				goto End;
			case MYWM_SET_CHECK_COPIED://msg.wParam==0->Set check for already copied,else for only checked
				SelectListBoxItems(GetDlgItem(dat.hDlg,IDC_TREE1),(int)msg.wParam);
				goto Loop;
 	}	}
	else if(dat.bStop)
	{	Sleep(250);
		goto Loop;
}	}
End:
 if(!dat.bSwtchToBckgrnd)
	EndDialog(dat.hDlg,0);//DestroyWindow
 if(dat.stack) free(dat.stack);
 ExitThread(0);
}

VOID cpyFileExBckQueueThrdFnc(LPVOID lpar)
{
cpyTrdDat dat; dat.hDlg = (HWND)lpar;
  	dat.stack = 0;
	dat.bStop = FALSE;
	dat.bCancel = FALSE;
	dat.bSwtchToBckgrnd = FALSE;
	dat.thrId = GetCurrentThreadId();
	dat.stack = NULL;

 wchar_t dst[MAX_PATH];
 size_t dstPathLn;

 dstPathLn=MyStringCpy(dst,MAX_PATH-1,destPath);

 dat.hDlg = CreateDialog(hInst,MAKEINTRESOURCE(IDD_DIALOG_COPY_BACKGROUND_QUEUE),hWnd,CopyBckgrndDlgProc);
 ShowWindow(dat.hDlg,SW_SHOW);//IDC_EDIT_COPY_BCKGRND_QUEUE

 /*for(int i=0; i<srcCnt; i++)
 {  int id = panel[srcPanel].pSelects[i];
	if(file == panel[srcPanel].GetItem(id)->attribute)
	{	if(IsFileExtIncludeCopyFilter(id))
		{	panel[srcPanel].GetFullPathAndName(id,s,MAX_PATH);
			char RetCar[3] = {0x0d, 0x0a, 0x00};
			SendMessage(GetDlgItem(dlg,IDC_EDIT_COPY_BCKGRND_QUEUE),EM_REPLACESEL,(WPARAM)FALSE,(LPARAM)(LPCSTR)s);
			SendMessage(GetDlgItem(dlg,IDC_EDIT_COPY_BCKGRND_QUEUE),EM_REPLACESEL, (WPARAM)FALSE, (LPARAM)(LPCSTR)RetCar);
			SendMessage(GetDlgItem(dlg,IDC_EDIT_COPY_BCKGRND_QUEUE),EM_SCROLLCARET, (WPARAM)0, (LPARAM)0);

			MyStringCat(dst,MAX_PATH-1,panel[srcPanel].GetItem(id)->Name);
			SendMessage(GetDlgItem(dlg,IDC_EDIT_COPY_BCKGRND_QUEUE2),EM_REPLACESEL,(WPARAM)FALSE,(LPARAM)(LPCSTR)dst);
			SendMessage(GetDlgItem(dlg,IDC_EDIT_COPY_BCKGRND_QUEUE2),EM_REPLACESEL, (WPARAM)FALSE, (LPARAM)(LPCSTR)RetCar);
			SendMessage(GetDlgItem(dlg,IDC_EDIT_COPY_BCKGRND_QUEUE2),EM_SCROLLCARET, (WPARAM)0, (LPARAM)0);
	}	}	
	else if(folder == panel[srcPanel].GetItem(id)->attribute)
		AddFolderToEdit(panel[srcPanel].GetItem(id)->Name);
  }*/
	
Loop:
	MSG msg;//Only thread message:
	//while(PeekMessage(&msg,pdat->hDlg,0,0,PM_REMOVE))
	//{	DispatchMessage(&msg);//from bckgrnd queue:
	//}
	if(PeekMessage(&msg,(HWND)-1,MYWM_CANCEL-1,MYWM_CANCEL+10,PM_REMOVE))
	{	
		//static int i=0;
		//char ss[32];sprintf(ss,"\n %d ",i++);
		//OutputDebugString(ss);
		//OutputDebugString(GetWinNotifyText(msg.message));
		
		switch(msg.message)
		{	case MYWM_CANCEL:
				//dat.bCancel = TRUE;
				DestroyWindow(dat.hDlg);
				if(dat.stack) free(dat.stack);
				ExitThread(0);
				return;
			case MYWM_STOP:
				wchar_t s[MAX_PATH];
				if(dat.bStop)
				{	LoadString(hInst,IDS_STRINGSW_50,s,MAX_PATH);
					SetDlgItemText(dat.hDlg,IDC_BUTTON_STOP,s);
					dat.bStop = FALSE;
				}
				else
				{	LoadString(hInst,IDS_STRINGSW_3,s,MAX_PATH);
					SetDlgItemText(dat.hDlg,IDC_BUTTON_STOP,s);
					dat.bStop = TRUE;
					Sleep(250);
					goto Loop;
				}
				break;
 	}	}
	else if(dat.bStop)
	{	Sleep(250);
		goto Loop;
}//	}

// DestroyWindow(dat.hDlg,0);
 //ExitThread(0);
}

} //end of namespace fCopyOper