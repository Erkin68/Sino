#ifndef _DRAGINTERFACE_H
#define _DRAGINTERFACE_H


#include "shlobj.h"
#include "..\Panel.h"


/*class DropSource : public IDropSource
{
private:
	ULONG	m_cRef;	// Reference count
public:
	DropSource() : IDropSource(),m_cRef(1){}
   ~DropSource() {}
	virtual HRESULT __stdcall QueryInterface(REFIID,void**);
	virtual ULONG   __stdcall AddRef(void);
	virtual ULONG   __stdcall Release(void);

	HRESULT __stdcall QueryContinueDrag(BOOL,DWORD);
    HRESULT __stdcall GiveFeedback(DWORD);
};*/

class DropTarget : public IDropTarget
{
private:
	ULONG				m_cRef;		// Reference count
	HWND				m_hWnd;
	int 				m_bCanAcceptDrop,iPan;
	//IDropTargetHelper*m_pDropTargetHelper;
	//HCURSOR			m_DefDragCursor;
	//HCURSOR			m_NotImplCursor;
	//HCURSOR			m_AddToFolderCursor;
	//HCURSOR			m_AddToCrntFolderCursor;
	DWORD	__stdcall DropEffect(DWORD,POINTL,DWORD);
	bool	__stdcall QueryDataObject(IDataObject *pDataObject);
	HRESULT __stdcall DropToDiskBtnToolbar(DROPFILES*,POINT*);
	HRESULT __stdcall DropToPanel(int,DROPFILES*,POINT*);
	HRESULT __stdcall DropToPathAndNameEdit(int,DROPFILES*,POINT*);
	HRESULT __stdcall DropToPanelArch(int,DROPFILES*,POINT*);
	HRESULT __stdcall DropToBtnsPnl(DROPFILES*,POINT*);
	HRESULT __stdcall DropToCmndCBEdit(DROPFILES*,POINT*);


public:
	DropTarget(HWND hWnd) :	m_cRef(1), m_bCanAcceptDrop(false), iPan(-1), m_hWnd(hWnd)
					//m_DefDragCursor(NULL),m_NotImplCursor(NULL),
					//m_AddToFolderCursor(NULL),m_AddToCrntFolderCursor(NULL)//,m_pDropTargetHelper(NULL)
					{}
	~DropTarget(){}
	virtual HRESULT __stdcall QueryInterface(REFIID iid, void ** ppvObject);
	virtual ULONG   __stdcall AddRef(void);
	virtual ULONG   __stdcall Release(void);

	// IUnknown methods not shown
	HRESULT __stdcall DragEnter(IDataObject *pDataObj, 
							DWORD grfKeyState, POINTL pt, DWORD *pdwEffect);
	HRESULT __stdcall DragOver(DWORD grfKeyState, POINTL pt,
							DWORD *pdwEffect);
	HRESULT __stdcall DragLeave();
	HRESULT __stdcall Drop(IDataObject *pDataObj, 
							DWORD grfKeyState, POINTL pt, DWORD *pdwEffect);
};

/*class DragDataObject : public IDataObject
{
private:
	DWORD       refs;
	Panel*		pan;
public:
	DragDataObject(Panel* p) : IDataObject(){pan=p;refs=1;}
	~DragDataObject(){}
	HRESULT __stdcall QueryInterface(REFIID riid,void __RPC_FAR *__RPC_FAR*);
	ULONG   __stdcall AddRef(void);
	ULONG   __stdcall Release(void);
	HRESULT __stdcall GetData(FORMATETC __RPC_FAR*,STGMEDIUM __RPC_FAR*);
	HRESULT __stdcall GetDataHere(FORMATETC __RPC_FAR*,STGMEDIUM __RPC_FAR*);
	HRESULT __stdcall QueryGetData(FORMATETC __RPC_FAR*);
	HRESULT __stdcall GetCanonicalFormatEtc(FORMATETC __RPC_FAR*,FORMATETC __RPC_FAR*);
	HRESULT __stdcall SetData(FORMATETC __RPC_FAR*,STGMEDIUM __RPC_FAR*,BOOL);
	HRESULT __stdcall EnumFormatEtc(DWORD,IEnumFORMATETC __RPC_FAR *__RPC_FAR*);
	HRESULT __stdcall DAdvise(FORMATETC __RPC_FAR*,DWORD,IAdviseSink __RPC_FAR*,DWORD __RPC_FAR*);
	HRESULT __stdcall DUnadvise(DWORD);
	HRESULT __stdcall EnumDAdvise(IEnumSTATDATA __RPC_FAR *__RPC_FAR*);
};

/*class CDataObject : public IDataObject
{
public:
	//
    // IUnknown members
	//
    HRESULT __stdcall QueryInterface (REFIID iid, void ** ppvObject);
    ULONG   __stdcall AddRef (void);
    ULONG   __stdcall Release (void);
		
    //
	// IDataObject members
	//
    HRESULT __stdcall GetData				(FORMATETC *pFormatEtc,  STGMEDIUM *pMedium);
    HRESULT __stdcall GetDataHere			(FORMATETC *pFormatEtc,  STGMEDIUM *pMedium);
    HRESULT __stdcall QueryGetData			(FORMATETC *pFormatEtc);
	HRESULT __stdcall GetCanonicalFormatEtc (FORMATETC *pFormatEct,  FORMATETC *pFormatEtcOut);
    HRESULT __stdcall SetData				(FORMATETC *pFormatEtc,  STGMEDIUM *pMedium,  BOOL fRelease);
	HRESULT __stdcall EnumFormatEtc			(DWORD      dwDirection, IEnumFORMATETC **ppEnumFormatEtc);
	HRESULT __stdcall DAdvise				(FORMATETC *pFormatEtc,  DWORD advf, IAdviseSink *pAdvSink, DWORD *pdwConnection);
	HRESULT __stdcall DUnadvise				(DWORD      dwConnection);
	HRESULT __stdcall EnumDAdvise			(IEnumSTATDATA **ppEnumAdvise);
	
	//
    // Constructor / Destructor
	//
    CDataObject(FORMATETC *fmt, STGMEDIUM *stgmed, int count);
    ~CDataObject();
	
private:

	int LookupFormatEtc(FORMATETC *pFormatEtc);

    //
	// any private members and functions
	//
    LONG	   m_lRefCount;

	FORMATETC *m_pFormatEtc;
	STGMEDIUM *m_pStgMedium;
	LONG	   m_nNumFormats;

};*/

#endif
