#include "stdio.h"
#include "shlobj.h"
#include "strsafe.h"
#include "RenMove.h"
#include "LinkSocket.h"
#include "MyErrors.h"
#include <mbstring.h>
#include "MyShell\MyShell.h"
//#include "MyShell\MyButtonC++.h"
#include "..\Sino.h"
#include "..\Config.h"
#include "DeleteOperation.h"
#include "Backgrnd thread copy operation.h"
#include "Backgrnd thread move operation.h"
#include "..\WindowsManagmentInstrumentation.h"


namespace fRenMove
{

int		srcPanel,destPanel,srcCnt,srcDirCnt;
unsigned __int64 srcSz,copySrcSz,avDstSz;
wchar_t	destPath[MAX_PATH];//agar 1- ning nomi o'zgartirilishi
SrcType srcType;
CopyType copyType;
CopyMethod copyMethod(mMoveFileWithProgress);


INT_PTR CALLBACK RMCopyDlgProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
static int iPanSel=0;
static HFONT hf=0;static int hfRef=0;//obshiy hf, dinamik uchun emas:
static HBRUSH br=0;
static HBRUSH brHtBk=0;
	UNREFERENCED_PARAMETER(lParam);
	//wchar_t s[128];sprintf(s,"\n%x %x %x",message,wParam,lParam);
	//OutputDebugString(s);

	switch (message)
	{
	case WM_INITDIALOG:
		//Adjust to center:
		RECT rc; GetWindowRect(hDlg, &rc);
		int width,left,height,top;

		width = rc.right - rc.left;
		left = conf::wndLeft + (conf::wndWidth - width)/2;

		height = rc.bottom - rc.top;
		top = conf::wndTop + (conf::wndHeight - height)/2;
		MoveWindow(hDlg, left, top+20, width, height, TRUE);


		//Load language strings:
		wchar_t s[MAX_PATH];
		LoadString(hInst,IDS_STRINGSW_36,s,MAX_PATH);
		SetWindowText(hDlg,s);
		LoadString(hInst,IDS_STRINGSW_37,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_COPY_STATIC_1,s);
		LoadString(hInst,IDS_STRINGSW_38,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_COPY_STATIC_2,s);
		LoadString(hInst,IDS_STRINGSW_39,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_CHECK_EXCEPTION_OR_SELECTION,s);
		LoadString(hInst,IDS_STRINGSW_40,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_CHECK_EXCEPTION_OR_SELECTION1,s);
		LoadString(hInst,IDS_STRINGSW_41,s,MAX_PATH);
		SetDlgItemText(hDlg,IDOK,s);
		LoadString(hInst,IDS_STRINGSW_42,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_BUTTON_ADD_TO_QUEUE,s);
		LoadString(hInst,IDS_STRINGSW_13,s,MAX_PATH);
		SetDlgItemText(hDlg,IDCANCEL,s);
		LoadString(hInst,IDS_STRINGSW_43,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_CHECK_CHANGE_DEFAULT,s);
		LoadString(hInst,IDS_STRINGSW_44,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_COPY_STATIC_3,s);
		LoadString(hInst,IDS_STRINGSW_45,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_BUTTON_BROWSE,s);

		//Copy file filters:
		conf::GetCopyDlgFiltrStr(hDlg,IDC_COMBO_FILES_EXCEPT);

		//Checks:
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_EXCEPTION_OR_SELECTION),
			BM_SETCHECK,conf::bCopyDlgChkBtn[0]?BST_CHECKED:BST_UNCHECKED,0);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_EXCEPTION_OR_SELECTION1),
			BM_SETCHECK,conf::bCopyDlgChkBtn[1]?BST_CHECKED:BST_UNCHECKED,0);
		if(!FillCopyFilesInfo(hDlg,lParam,iPanSel))
			EndDialog(hDlg,TRUE);

		if(socketCl==panel[srcPanel].GetEntry()->GetCrntRecType() ||
		  (socketCl==panel[destPanel].GetEntry()->GetCrntRecType() &&
		   2==conf::Dlg.iTotPanels))
		{	EnableWindow(GetDlgItem(hDlg,IDC_BUTTON_ADD_TO_QUEUE),FALSE);
			EnableWindow(GetDlgItem(hDlg,IDC_BUTTON_BROWSE),FALSE);
			EnableWindow(GetDlgItem(hDlg,IDC_CHECK_EXCEPTION_OR_SELECTION),FALSE);
			EnableWindow(GetDlgItem(hDlg,IDC_CHECK_EXCEPTION_OR_SELECTION1),FALSE);
			EnableWindow(GetDlgItem(hDlg,IDC_COMBO_FILES_EXCEPT),FALSE);
		}

		//MyButtonFrRCBtn(hDlg,IDC_BUTTON_BROWSE,conf::Dlg.iBtnsType);
		//MyButtonFrRCBtn(hDlg,IDOK,conf::Dlg.iBtnsType);
		//MyButtonFrRCBtn(hDlg,IDC_BUTTON_ADD_TO_QUEUE,conf::Dlg.iBtnsType);
		//MyButtonFrRCBtn(hDlg,IDCANCEL,conf::Dlg.iBtnsType);

		SendMessage(hDlg,WM_USER+1,0,0);
		SetFocus(GetDlgItem(hDlg,IDOK));//Ownedrawda defaultbutton bo'lmaydur;
		return TRUE;
	case WM_CTLCOLORSTATIC:
	case WM_CTLCOLORDLG:
		if(2==conf::Dlg.iBtnsType)//ownedraw
		{	HDC dc;dc = (HDC)wParam;
			SetTextColor(dc,conf::Dlg.dlgRGBs[0][1]);
			SetBkColor(dc,conf::Dlg.dlgRGBs[0][2]);
			return (INT_PTR)br;
		}return 0;
	case WM_CTLCOLOREDIT:
		if(2==conf::Dlg.iBtnsType)//ownedraw
		{	HDC dc = (HDC)wParam;
			SetTextColor(dc,conf::Dlg.dlgRGBs[0][1]);
			SetBkColor(dc,conf::Dlg.dlgRGBs[0][2]);
			return (INT_PTR)br;
		}return 0;
	case WM_CTLCOLORBTN:
		if(2==conf::Dlg.iBtnsType)//ownedraw
		{	HDC dc=(HDC)wParam;
			SetTextColor(dc,conf::Dlg.dlgRGBs[0][4]);
			SetBkColor(dc,conf::Dlg.dlgRGBs[0][5]);
			return (INT_PTR)brHtBk;
		}return 0;
	case WM_DRAWITEM://WM_CTLCOLORBTN dagi knopkalar:
		if(2==conf::Dlg.iBtnsType)//ownedraw
		{	LPDRAWITEMSTRUCT lpdis;lpdis = (LPDRAWITEMSTRUCT)lParam;
			GetWindowText(lpdis->hwndItem,s,64);
			UINT uStyle;uStyle = DFCS_BUTTONPUSH;
			rc = lpdis->rcItem;
			if(lpdis->itemState & ODS_SELECTED)
			{	uStyle |= DFCS_PUSHED;
				rc.left+=2;rc.top+=2;
			}
			DrawFrameControl(lpdis->hDC, &lpdis->rcItem, DFC_BUTTON, uStyle);
			if(lpdis->itemState & ODS_SELECTED)
				{rc.left+=1;rc.top+=1;rc.bottom-=2;rc.right-=3;}
			else
				{rc.left+=1;rc.top+=2;rc.bottom-=3;rc.right-=3;}
			FillRect(lpdis->hDC,&rc,brHtBk);//DrawText(lpdis->hDC,"                                                  ",50,&rc,DT_SINGLELINE|DT_VCENTER|DT_INTERNAL|DT_LEFT);
			if(lpdis->itemState & ODS_SELECTED)
				{rc.left-=1;rc.top-=1;rc.bottom+=3;rc.right+=3;}
			else
				{rc.left-=1;rc.top-=2;rc.bottom+=2;rc.right+=3;}
			DrawText(lpdis->hDC,s,MyStringLength(s,64),&rc,DT_SINGLELINE|DT_VCENTER|DT_CENTER);
			return TRUE;
		}return 0;
	case WM_USER+1://hf obshiy uchun, dinamik o'zgartirish uchun emas:
		if(0==hfRef)
		{	hf = CreateFontIndirect(&conf::Dlg.dlgFnts[0]);
			br = CreateSolidBrush(conf::Dlg.dlgRGBs[0][0]);
			brHtBk = CreateSolidBrush(conf::Dlg.dlgRGBs[0][5]);
		}
		SendMessage(GetDlgItem(hDlg,IDC_COPY_STATIC_1),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_COPY_STATIC_2),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_COPY_STATIC_3),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_EXCEPTION_OR_SELECTION),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_EXCEPTION_OR_SELECTION1),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_CHECK_CHANGE_DEFAULT),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_BUTTON_BROWSE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDOK),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_BUTTON_ADD_TO_QUEUE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDCANCEL),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_FILES_TO_COPY),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_EDIT_DEST_PATH),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_FILES_EXCEPT),WM_SETFONT,(WPARAM)hf,TRUE);
		++hfRef;
		return 0;//GWL_USERDATA
	case WM_DESTROY:
		if(--hfRef<1)
		{	DeleteObject(hf);
			DeleteObject(br);
			DeleteObject(brHtBk);
		}
		return 0;
	case WM_COMMAND:
		switch(LOWORD(wParam))
		{	case IDC_COMBO_PANEL:
				if(CBN_SELCHANGE==HIWORD(wParam))
				{	iPanSel=(int)SendMessage(GetDlgItem(hDlg,IDC_COMBO_PANEL),CB_GETCURSEL,0,0);
					SendMessage(GetDlgItem(hDlg,IDC_COMBO_PANEL),CB_GETLBTEXT,/*iPan*/iPanSel,(LPARAM)s);
					SetDlgItemText(hDlg,IDC_EDIT_DEST_PATH,panel[_wtoi(s)-1].GetPath());
					if(2<conf::Dlg.iTotPanels)
					{	if(socketCl==panel[_wtoi(s)-1].GetEntry()->GetCrntRecType())
						{	EnableWindow(GetDlgItem(hDlg,IDC_BUTTON_ADD_TO_QUEUE),FALSE);
							EnableWindow(GetDlgItem(hDlg,IDC_BUTTON_BROWSE),FALSE);
							EnableWindow(GetDlgItem(hDlg,IDC_CHECK_EXCEPTION_OR_SELECTION),FALSE);
							EnableWindow(GetDlgItem(hDlg,IDC_CHECK_EXCEPTION_OR_SELECTION1),FALSE);
							EnableWindow(GetDlgItem(hDlg,IDC_COMBO_FILES_EXCEPT),FALSE);
						}
						else
						{	EnableWindow(GetDlgItem(hDlg,IDC_BUTTON_ADD_TO_QUEUE),TRUE);
							EnableWindow(GetDlgItem(hDlg,IDC_BUTTON_BROWSE),TRUE);
							EnableWindow(GetDlgItem(hDlg,IDC_CHECK_EXCEPTION_OR_SELECTION),TRUE);
							EnableWindow(GetDlgItem(hDlg,IDC_CHECK_EXCEPTION_OR_SELECTION1),TRUE);
							EnableWindow(GetDlgItem(hDlg,IDC_COMBO_FILES_EXCEPT),TRUE);
				}	}	}
				break;
			case IDC_CHECK_EXCEPTION_OR_SELECTION:
				if(BN_CLICKED==HIWORD(wParam))
				{	if(BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_EXCEPTION_OR_SELECTION),BM_GETCHECK,0,0))
						SendMessage(GetDlgItem(hDlg,IDC_CHECK_EXCEPTION_OR_SELECTION1),
							BM_SETCHECK,BST_UNCHECKED,0);
				}
				break;
			case IDC_CHECK_EXCEPTION_OR_SELECTION1: 
				if(BN_CLICKED==HIWORD(wParam))
				{	if(BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_EXCEPTION_OR_SELECTION1),BM_GETCHECK,0,0))
						SendMessage(GetDlgItem(hDlg,IDC_CHECK_EXCEPTION_OR_SELECTION),
							BM_SETCHECK,BST_UNCHECKED,0);
				}
				break;
			case IDC_BUTTON_BROWSE:
				BROWSEINFO bi; 
				bi.hwndOwner = hDlg;
				bi.pszDisplayName = s;
				bi.lpszTitle = L"Copy to folder ...";
				bi.ulFlags = BIF_NONEWFOLDERBUTTON|BIF_DONTGOBELOWDOMAIN|BIF_NEWDIALOGSTYLE|
					BIF_NOTRANSLATETARGETS|BIF_RETURNFSANCESTORS;
				bi.lpfn = NULL;
				LPITEMIDLIST pidlRoot;pidlRoot = NULL;
				bi.pidlRoot = pidlRoot;
				LPITEMIDLIST pidlSelected;pidlSelected = SHBrowseForFolder(&bi);
				if(pidlRoot)
					CoTaskMemFree(pidlRoot);
				if(pidlSelected)
				{	SHGetPathFromIDList(pidlSelected,s);
					MyStringCat(s,MAX_PATH,L"\\*");
					SetDlgItemText(hDlg,IDC_EDIT_DEST_PATH,s);
					CoTaskMemFree(pidlSelected);
				}
	   			return (INT_PTR)TRUE;
			case IDOK:
				if(BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_CHANGE_DEFAULT),BM_GETCHECK,0,0))
				{	SendMessage(GetDlgItem(hDlg,IDC_COMBO_FILES_EXCEPT),
													WM_GETTEXT,MAX_PATH,(LPARAM)s);
					conf::AddCopyDlgFiltrStr(s);
					conf::iCopyDlgBtnPlaces = 0;
					conf::bCopyDlgChkBtn[0] = (BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_EXCEPTION_OR_SELECTION),BM_GETCHECK,0,0));
					conf::bCopyDlgChkBtn[1] = (BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_EXCEPTION_OR_SELECTION1),BM_GETCHECK,0,0));
				}
				GetDlgItemText(hDlg,IDC_EDIT_DEST_PATH,destPath,MAX_PATH);
				if(MyStringRemoveLastCharCheckPre(destPath,MAX_PATH,'*','\\'))
				{	srcType = unchange;//use asterics('\'+'*'+'0') symbol at the end;
				}
				else
				{	if(1==srcCnt)
					{	wchar_t ss[MAX_PATH];
						GetDlgItemText(hDlg,IDC_COMBO_FILES_TO_COPY,ss,MAX_PATH);
						MyStringCpy(s,MAX_PATH,panel[srcPanel].GetPath());
						MyStringRemoveLastCharCheckPre(s,MAX_PATH,'*','\\');
						MyStringCat(s,MAX_PATH,ss);
						if(IsDirExist(s))
							srcType = rename1Folder;
						else
							srcType = rename1File;
					}
					else
					{	srcType = allToRenFolder;
				}	}
				copyType = single;
				EndDialog(hDlg, 1);
				return (INT_PTR)TRUE;
			case IDC_BUTTON_ADD_TO_QUEUE:
				if(BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_CHANGE_DEFAULT),BM_GETCHECK,0,0))
				{	SendMessage(GetDlgItem(hDlg,IDC_COMBO_FILES_EXCEPT),
													WM_GETTEXT,MAX_PATH,(LPARAM)s);
					conf::AddCopyDlgFiltrStr(s);
					conf::iCopyDlgBtnPlaces = 1;//if(BST_FOCUS==SendMessage(GetDlgItem(hDlg,IDCANCEL),BM_GETSTATE,0,0))
					conf::bCopyDlgChkBtn[0] = (BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_EXCEPTION_OR_SELECTION),BM_GETCHECK,0,0));
					conf::bCopyDlgChkBtn[1] = (BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_EXCEPTION_OR_SELECTION1),BM_GETCHECK,0,0));
				}
				GetDlgItemText(hDlg,IDC_EDIT_DEST_PATH,destPath,MAX_PATH);
				if(MyStringRemoveLastCharCheckPre(destPath,MAX_PATH,'*','\\'))
				{	srcType = unchange;//use asterics('\'+'*'+'0') symbol at the end;
				}
				else
				{	if(1==srcCnt)
					{	//char ss[MAX_PATH];
						//GetDlgItemText(hDlg,IDC_COMBO_FILES_TO_COPY,ss,MAX_PATH);
						int l=MyStringCpy(s,MAX_PATH,panel[srcPanel].GetPath());
						GetDlgItemText(hDlg,IDC_COMBO_FILES_TO_COPY,&s[l],MAX_PATH);//MyStringCat(s,MAX_PATH,ss);
						if(IsDirExist(s))
							srcType = rename1Folder;
						else
							srcType = rename1File;
					}
					else
					{	srcType = allToRenFolder;
				}	}
				copyType = addToBack;
				EndDialog(hDlg, 1);
				return (INT_PTR)TRUE;
			case IDCANCEL:
				if(BST_CHECKED==SendMessage(GetDlgItem(hDlg,IDC_CHECK_CHANGE_DEFAULT),BM_GETCHECK,0,0))
					conf::iCopyDlgBtnPlaces = 2;
				EndDialog(hDlg, 0);
				return (INT_PTR)TRUE;
		}
		break;
	}
	return (INT_PTR)FALSE;
}

//Qaysi paneldan qaysisga, shuni aniqlab, yo'llarini to'g'rilaydi:
BOOL FillCopyFilesInfo(HWND hDlg, LPARAM lParam,int iPanSel)
{
wchar_t s[MAX_PATH];

	int numAllowedDestPanels = conf::Dlg.iTotPanels-1;
	destPanel = ((Panel*)lParam)->iOpponent;
	if(1==numAllowedDestPanels)
	{	ShowWindow(GetDlgItem(hDlg,IDC_COPY_STATIC_3),SW_HIDE);
		ShowWindow(GetDlgItem(hDlg,IDC_COMBO_PANEL),SW_HIDE);
		SetDlgItemText(hDlg,IDC_EDIT_DEST_PATH,panel[destPanel].GetPath());
	}
	else if(2==numAllowedDestPanels)
	{	for(int i=0; i<2; ++i)
		{	if(i!=((Panel*)lParam)->iThis)
			{	StringCchPrintf(s,4,L"%d",i+1);
				SendMessage(GetDlgItem(hDlg,IDC_COMBO_PANEL),CB_INSERTSTRING,(WPARAM)-1,(LPARAM)s);
		}	}
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_PANEL),CB_SETCURSEL,iPanSel,0);
		//SetDlgItemText(hDlg,IDC_EDIT_DEST_PATH,panel[destPanel].path);
		SendMessage(hDlg,WM_COMMAND,MAKELONG(IDC_COMBO_PANEL,CBN_SELCHANGE),0);
	}
	else if(3==numAllowedDestPanels)
	{	for(int i=0; i<4; ++i)
		{	if(i!=((Panel*)lParam)->iThis)
			{	StringCchPrintf(s,4,L"%d",i+1);
				SendMessage(GetDlgItem(hDlg,IDC_COMBO_PANEL),CB_INSERTSTRING,(WPARAM)-1,(LPARAM)s);
		}	}
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_PANEL),CB_SETCURSEL,iPanSel,0);
		//SetDlgItemText(hDlg,IDC_EDIT_DEST_PATH,panel[destPanel].path);
		SendMessage(hDlg,WM_COMMAND,MAKELONG(IDC_COMBO_PANEL,CBN_SELCHANGE),0);
	}
int r;
	srcPanel = ((Panel*)lParam)->iThis;
	srcCnt = panel[srcPanel].GetTotSelects();
	if(srcCnt<1)
	{	int id = panel[srcPanel].GetHot();
		if(id<0)
		{	MessageBox(NULL,L"Please, select any files for copy, then try to copy...", L"Warn.",MB_OK);
			return FALSE;
		}
		//SendMessage(GetDlgItem(hDlg,IDC_COMBO_FILES_TO_COPY),CB_INSERTSTRING,(WPARAM)-1,
		//	(LPARAM)panel[srcPanel].GetItem(id)->Name);
		//SendMessage(GetDlgItem(hDlg,IDC_COMBO_FILES_TO_COPY),WM_SETTEXT,0,(LPARAM)panel[srcPanel].GetItem(id)->Name);
		//r=SendMessage(GetDlgItem(hDlg,IDC_COMBO_FILES_TO_COPY),CB_SETEDITSEL,-1,(LPARAM)MAKELONG(0,-1));
		r=panel[destPanel].GetPath(s);
		if('*'==s[r-1] && '\\'==s[r-2])
			s[--r]=0;
		else if('\\'!=s[r-1])
			s[r++]='\\';
		MyStringCpy(&s[r],MAX_PATH-r,panel[srcPanel].GetItem(id)->Name);
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_FILES_TO_COPY),CB_INSERTSTRING,(WPARAM)-1,
			(LPARAM)&s[r]);//panel[srcPanel].GetItem(id)->Name);
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_FILES_TO_COPY),WM_SETTEXT,0,(LPARAM)&s[r+1]);//panel[srcPanel].GetItem(id)->Name);
		r=(int)SendMessage(GetDlgItem(hDlg,IDC_COMBO_FILES_TO_COPY),CB_SETEDITSEL,-1,(LPARAM)MAKELONG(0,-1));
		SetDlgItemText(hDlg,IDC_EDIT_DEST_PATH,s);//panel[destPanel].GetPath());
		srcCnt = 1;
	}
	else
	{	for(int i=0; i<panel[srcPanel].GetTotItems(); i++)
		{	if(selected==panel[srcPanel].GetItem(i)->state)
			{	SendMessage(GetDlgItem(hDlg,IDC_COMBO_FILES_TO_COPY),CB_INSERTSTRING,(WPARAM)-1,
					(LPARAM)panel[srcPanel].GetItem(i)->Name);
				if(!i)
				SendMessage(GetDlgItem(hDlg,IDC_COMBO_FILES_TO_COPY),WM_SETTEXT,0,(LPARAM)panel[srcPanel].GetItem(i)->Name);
		}	}
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_FILES_TO_COPY),CB_SETEDITSEL,0,(LPARAM)MAKELONG(0,-1));
	}
	SendMessage(GetDlgItem(hDlg,IDC_COMBO_FILES_TO_COPY),CB_SETCURSEL,0,0);
	SetFocus(GetDlgItem(hDlg,IDC_EDIT_DEST_PATH));
	SendMessage(GetDlgItem(hDlg,IDC_EDIT_DEST_PATH),EM_SETSEL,0,-1);
	return TRUE;
}

int GetSelectedFiles(CpyStack *stack)
{
int tot=panel[srcPanel].GetTotSelects();
	if(!tot)//hotni kavlaymiz;
	{	int ht=panel[srcPanel].GetHot();
		if(ht>0 && ht<panel[srcPanel].GetTotItems())
		{	if(file == panel[srcPanel].GetItem(ht)->attribute)
			{	MyStringCpy(stack[tot].Name,MAX_PATH,panel[srcPanel].GetItem(ht)->Name);
				int l=MyStringCpy(stack[tot].FullPathAndName,MAX_PATH,panel[srcPanel].GetPath());
				if('*'==stack[tot].FullPathAndName[l-1])//MyStringRemoveLastCharCheckPre(stack[tot].FullPathAndName,MAX_PATH,'*','\\');
				if('\\'==stack[tot].FullPathAndName[l-2])
					stack[tot].FullPathAndName[--l]=0;
				MyStringCpy(&stack[tot].FullPathAndName[l],MAX_PATH-l,panel[srcPanel].GetItem(ht)->Name);//MyStringCat(stack[tot].FullPathAndName,MAX_PATH,panel[srcPanel].GetItem(ht)->Name);
				stack[tot].size = panel[srcPanel].GetItem(ht)->size;
				stack[tot].attribute = file;
				return 1;
			}
			else if(folder == panel[srcPanel].GetItem(ht)->attribute)
			{	MyStringCpy(stack[tot].Name,MAX_PATH,panel[srcPanel].GetItem(ht)->Name);
				int l=panel[srcPanel].GetFullPathAndName(ht,stack[tot].FullPathAndName,MAX_PATH);
				stack[tot].attribute = folder;
				int saveTot=tot;
				++tot;//folderniyam;
				srcDirCnt = 0;
				if(mSHFileOperation != copyMethod)
				{	stack[saveTot].FullPathAndName[l]='\\';//MyStringCat(pth,MAX_PATH,"\\*");
					stack[saveTot].FullPathAndName[l+1]='*';
					stack[saveTot].FullPathAndName[l+2]=0;
					tot += fCopyOper::GetFilesInFolder(stack[saveTot].FullPathAndName,&stack[tot]);
					stack[saveTot].FullPathAndName[l]=0;
					++srcDirCnt;
	 		}	}
			return tot;
		}
		else return 0;
	}

 tot = srcDirCnt = 0;
 for(int i=0; i<panel[srcPanel].GetTotItems(); i++)
 {	if(selected==panel[srcPanel].GetItem(i)->state || (0==panel[srcPanel].GetTotSelects() && i==panel[srcPanel].GetHot()))
	{	if(file == panel[srcPanel].GetItem(i)->attribute)
		{	MyStringCpy(stack[tot].Name,MAX_PATH,panel[srcPanel].GetItem(i)->Name);
			int l=MyStringCpy(stack[tot].FullPathAndName,MAX_PATH,panel[srcPanel].GetPath());
			if('*'==stack[tot].FullPathAndName[l-1])//MyStringRemoveLastCharCheckPre(stack[tot].FullPathAndName,MAX_PATH,'*','\\');
			if('\\'==stack[tot].FullPathAndName[l-2])
				stack[tot].FullPathAndName[--l]=0;
			MyStringCpy(&stack[tot].FullPathAndName[l],MAX_PATH-l,panel[srcPanel].GetItem(i)->Name);//MyStringCat(stack[tot].FullPathAndName,MAX_PATH,panel[srcPanel].GetItem(i)->Name);
			stack[tot].size = panel[srcPanel].GetItem(i)->size;
			stack[tot].attribute = file;
			++tot;
		}
		else if(folder == panel[srcPanel].GetItem(i)->attribute)
		{	int l=panel[srcPanel].GetFullPathAndName(i,stack[tot].FullPathAndName,MAX_PATH);
			MyStringCpy(stack[tot].Name,MAX_PATH,panel[srcPanel].GetItem(i)->Name);
			stack[tot].attribute = folder;
			int saveTot=tot;
			++tot;//folderniyam;

			if(mSHFileOperation != copyMethod)
			{	stack[saveTot].FullPathAndName[l]='\\';//MyStringCat(pth,MAX_PATH,"\\*");
				stack[saveTot].FullPathAndName[l+1]='*';
				stack[saveTot].FullPathAndName[l+2]=0;
				tot += fCopyOper::GetFilesInFolder(stack[saveTot].FullPathAndName,&stack[tot]);
				stack[saveTot].FullPathAndName[l]=0;
				++srcDirCnt;
 }	}	}	}	
 return tot;
}

int GetSelectedFilesCnt()
{
int tot=panel[srcPanel].GetTotSelects();
	if(!tot)//hotni kavlaymiz;
	{	int ht=panel[srcPanel].GetHot();
		if(ht>0 &&ht<panel[srcPanel].GetTotItems())
		{	if(file == panel[srcPanel].GetItem(ht)->attribute)
				return 1;
			else if(folder == panel[srcPanel].GetItem(ht)->attribute)
			{	wchar_t pth[MAX_PATH]; 
				int l=panel[srcPanel].GetFullPathAndName(ht,pth,MAX_PATH);
				++tot;//folderniyam;
				if(mSHFileOperation != copyMethod)
				{	pth[l++]='\\';//MyStringCat(pth,MAX_PATH,"\\*");
					pth[l++]='*';
					pth[l]=0;
					tot += fCopyOper::GetFilesCntInFolder(pth);
			}	}
			return tot;
		}
		else return 0;
	}
	tot=0;
 	for(int i=0; i<panel[srcPanel].GetTotItems(); i++)
	{	if(selected==panel[srcPanel].GetItem(i)->state || (0==panel[srcPanel].GetTotSelects() && i==panel[srcPanel].GetHot()))
		{	if(file == panel[srcPanel].GetItem(i)->attribute)
				++tot;
			else if(folder == panel[srcPanel].GetItem(i)->attribute)
			{	wchar_t pth[MAX_PATH]; 
				int l=panel[srcPanel].GetFullPathAndName(i,pth,MAX_PATH);
				++tot;//folderniyam;
				if(mSHFileOperation != copyMethod)
				{	pth[l++]='\\';//MyStringCat(pth,MAX_PATH,"\\*");
					pth[l++]='*';
					pth[l]=0;
					tot += fCopyOper::GetFilesCntInFolder(pth);
	}	}	}	}
	return tot;
}

unsigned __int64 GetSelectedFilesToDlg(HWND dlgEdit1,HWND dlgEdit2)
{
static wchar_t RetCar[3] = { 0x0d, 0x0a, 0x00 };
wchar_t Name[MAX_PATH],FullPathAndName[MAX_PATH];
unsigned __int64 sz = 0;
size_t destPathLen; destPathLen = MyStringLength(destPath,MAX_PATH);//StringCchLength(destPath,MAX_PATH,&destPathLen);
int tot = panel[srcPanel].GetTotSelects();
	if(!tot)
	{	int ht = panel[srcPanel].GetHot();
		if(ht>0 && ht<panel[srcPanel].GetTotItems())
		{	if(file == panel[srcPanel].GetItem(ht)->attribute)
			{	MyStringCpy(Name,MAX_PATH,panel[srcPanel].GetItem(ht)->Name);
				int l=MyStringCpy(FullPathAndName,MAX_PATH,panel[srcPanel].GetPath());
				if('*'==FullPathAndName[l-1])//MyStringRemoveLastCharCheckPre(FullPathAndName,MAX_PATH,'*','\\');
				if('\\'==FullPathAndName[l-2])
					FullPathAndName[--l]=0;
				MyStringCpy(&FullPathAndName[l],MAX_PATH-l,panel[srcPanel].GetItem(ht)->Name);//MyStringCat(FullPathAndName,MAX_PATH,panel[srcPanel].GetItem(ht)->Name);
				sz += panel[srcPanel].GetItem(ht)->size;

				SendMessage(dlgEdit1,EM_REPLACESEL, (WPARAM)FALSE, (LPARAM)(LPCSTR)FullPathAndName);
				SendMessage(dlgEdit1,EM_REPLACESEL, (WPARAM)FALSE, (LPARAM)(LPCSTR)RetCar);
				SendMessage(dlgEdit1,EM_SCROLLCARET,(WPARAM)0, (LPARAM)0);

				MyStringCpy(&destPath[destPathLen],MAX_PATH-(int)destPathLen,panel[srcPanel].GetItem(ht)->Name);//MyStringCat(destPath,MAX_PATH,panel[srcPanel].GetItem(ht)->Name);
				SendMessage(dlgEdit2,EM_REPLACESEL, (WPARAM)FALSE, (LPARAM)(LPCSTR)destPath);
				SendMessage(dlgEdit2,EM_REPLACESEL, (WPARAM)FALSE, (LPARAM)(LPCSTR)RetCar);
				SendMessage(dlgEdit2,EM_SCROLLCARET,(WPARAM)0, (LPARAM)0);
				destPath[destPathLen] = 0;
				return sz;
			}
			else if(folder == panel[srcPanel].GetItem(ht)->attribute)
			{	int l=panel[srcPanel].GetFullPathAndName(ht,FullPathAndName,MAX_PATH);
				l+=MyStringCpy(&FullPathAndName[l],MAX_PATH-l,panel[srcPanel].GetItem(ht)->Name);//MyStringCat(FullPathAndName,MAX_PATH,panel[srcPanel].GetItem(ht)->Name);

				SendMessage(dlgEdit1,EM_REPLACESEL, (WPARAM)FALSE, (LPARAM)L"");
				SendMessage(dlgEdit1,EM_REPLACESEL, (WPARAM)FALSE, (LPARAM)(LPCSTR)RetCar);
				SendMessage(dlgEdit1,EM_SCROLLCARET,(WPARAM)0, (LPARAM)0);

				SendMessage(dlgEdit2,EM_REPLACESEL, (WPARAM)FALSE, (LPARAM)(LPCSTR)FullPathAndName);
				SendMessage(dlgEdit2,EM_REPLACESEL, (WPARAM)FALSE, (LPARAM)(LPCSTR)RetCar);
				SendMessage(dlgEdit2,EM_SCROLLCARET,(WPARAM)0, (LPARAM)0);
				++tot;//folderniyam;

				FullPathAndName[l++]='\\';//MyStringCat(FullPathAndName,MAX_PATH,"\\*");
				FullPathAndName[l++]='*';
				FullPathAndName[l]=0;
				tot += fCopyOper::GetFilesInFolderToDlg(FullPathAndName,4,dlgEdit1,dlgEdit2);
			}
			return sz;
		}
		else return 0;
	}

	tot=0;
	for(int i=0; i<panel[srcPanel].GetTotItems(); i++)
	{	if(selected==panel[srcPanel].GetItem(i)->state || (0==panel[srcPanel].GetTotSelects() && i==panel[srcPanel].GetHot()))
		{	if(file == panel[srcPanel].GetItem(i)->attribute)
			{	MyStringCpy(Name,MAX_PATH,panel[srcPanel].GetItem(i)->Name);
				int l=MyStringCpy(FullPathAndName,MAX_PATH,panel[srcPanel].GetPath());
				if('*'==FullPathAndName[l-1])//MyStringRemoveLastCharCheckPre(FullPathAndName,MAX_PATH,'*','\\');
				if('\\'==FullPathAndName[l-2])
					FullPathAndName[--l]=0;
				MyStringCpy(&FullPathAndName[l],MAX_PATH-l,panel[srcPanel].GetItem(i)->Name);//MyStringCat(FullPathAndName,MAX_PATH,panel[srcPanel].GetItem(i)->Name);
				sz += panel[srcPanel].GetItem(i)->size;

				SendMessage(dlgEdit1,EM_REPLACESEL, (WPARAM)FALSE, (LPARAM)(LPCSTR)FullPathAndName);
				SendMessage(dlgEdit1,EM_REPLACESEL, (WPARAM)FALSE, (LPARAM)(LPCSTR)RetCar);
				SendMessage(dlgEdit1,EM_SCROLLCARET,(WPARAM)0, (LPARAM)0);

				MyStringCpy(&destPath[destPathLen],MAX_PATH-(int)destPathLen,panel[srcPanel].GetItem(i)->Name);//MyStringCat(destPath,MAX_PATH,panel[srcPanel].GetItem(i)->Name);
				SendMessage(dlgEdit2,EM_REPLACESEL, (WPARAM)FALSE, (LPARAM)(LPCSTR)destPath);
				SendMessage(dlgEdit2,EM_REPLACESEL, (WPARAM)FALSE, (LPARAM)(LPCSTR)RetCar);
				SendMessage(dlgEdit2,EM_SCROLLCARET,(WPARAM)0, (LPARAM)0);
				destPath[destPathLen] = 0;
				++tot;
			}
			else if(folder == panel[srcPanel].GetItem(i)->attribute)
			{	int l=panel[srcPanel].GetFullPathAndName(i,FullPathAndName,MAX_PATH);
				l+=MyStringCpy(&FullPathAndName[l],MAX_PATH-l,panel[srcPanel].GetItem(i)->Name);//MyStringCat(FullPathAndName,MAX_PATH,panel[srcPanel].GetItem(i)->Name);

				SendMessage(dlgEdit1,EM_REPLACESEL, (WPARAM)FALSE, (LPARAM)"");
				SendMessage(dlgEdit1,EM_REPLACESEL, (WPARAM)FALSE, (LPARAM)(LPCSTR)RetCar);
				SendMessage(dlgEdit1,EM_SCROLLCARET,(WPARAM)0, (LPARAM)0);

				SendMessage(dlgEdit2,EM_REPLACESEL, (WPARAM)FALSE, (LPARAM)(LPCSTR)FullPathAndName);
				SendMessage(dlgEdit2,EM_REPLACESEL, (WPARAM)FALSE, (LPARAM)(LPCSTR)RetCar);
				SendMessage(dlgEdit2,EM_SCROLLCARET,(WPARAM)0, (LPARAM)0);
				++tot;//folderniyam;

				FullPathAndName[l++]='\\';//MyStringCat(FullPathAndName,MAX_PATH,"\\*");
				FullPathAndName[l++]='*';
				FullPathAndName[l]=0;
				tot += fCopyOper::GetFilesInFolderToDlg(FullPathAndName,4,dlgEdit1,dlgEdit2);
	}	}	}
	return sz;//tot;
}

//Src panel,koneshno:
static int iRMBckrndCpyWndCnt=-1;
INT_PTR CALLBACK RMCopyBckgrndDlgProc(HWND hDlg,UINT message,WPARAM wParam,LPARAM lParam)
{
	switch(message)
	{
	case WM_INITDIALOG:
		++iRMBckrndCpyWndCnt;
		//Adjust to center:
		RECT rc; GetWindowRect(hDlg, &rc);
		int width,height,x,y;//left,top;

		width = rc.right - rc.left;
		//left = conf::wndLeft + (conf::wndWidth - width)/2;
		height = rc.bottom - rc.top;
		//top = conf::wndTop + (conf::wndHeight - height)/2;

		x = (width*iRMBckrndCpyWndCnt)%conf::wndWidth;
		if(x>conf::wndWidth)x=0;
		y = ((width*iRMBckrndCpyWndCnt)/conf::wndWidth)*height;
		if(y>conf::wndHeight)y=0;

		MoveWindow(hDlg,x,y,width,height,TRUE);

		//Load language strings:
		wchar_t s[MAX_PATH];
		LoadString(hInst,IDS_STRINGSW_46,s,MAX_PATH);
		SetWindowText(hDlg,s);
		LoadString(hInst,IDS_STRINGSW_47,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_STATIC,s);
		LoadString(hInst,IDS_STRINGSW_48,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_STATIC5,s);
		//LoadString(hInst,IDS_STRINGSW_49,s,MAX_PATH);
		//SetDlgItemText(hDlg,IDC_BUTTON_TO_BACKGROUND_COPY_QUEUE,s);
		ShowWindow(GetDlgItem(hDlg,IDC_BUTTON_TO_BACKGROUND_COPY_QUEUE),SW_HIDE);
		LoadString(hInst,IDS_STRINGSW_50,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_BUTTON_STOP,s);
		LoadString(hInst,IDS_STRINGSW_13,s,MAX_PATH);
		SetDlgItemText(hDlg,IDCANCEL,s);

		PostMessage(GetDlgItem(hDlg,IDC_PROGRESS_COPY_SINGLE),PBM_SETRANGE,0,MAKELPARAM(0,1000));
		PostMessage(GetDlgItem(hDlg,IDC_PROGRESS_COPY_TOTAL ),PBM_SETRANGE,0,MAKELPARAM(0,1000));
		PostMessage(GetDlgItem(hDlg,IDC_PROGRESS_COPY_SINGLE),PBM_SETSTEP,1,0);
		PostMessage(GetDlgItem(hDlg,IDC_PROGRESS_COPY_TOTAL ),PBM_SETSTEP,1,0);

		//MyButtonFrRCBtn(hDlg,IDC_BUTTON_STOP,conf::Dlg.iBtnsType);
		//MyButtonFrRCBtn(hDlg,IDCANCEL,conf::Dlg.iBtnsType);

		return TRUE;
	case WM_DESTROY:
		--iRMBckrndCpyWndCnt;
		return TRUE;
	case WM_COMMAND:
		switch(LOWORD(wParam))
		{	case IDC_BUTTON_STOP:
				PostThreadMessage(GetCurrentThreadId(),MYWM_STOP,0,0);
				return (INT_PTR)TRUE;
			case IDCANCEL:
				PostThreadMessage(GetCurrentThreadId(),MYWM_CANCEL,0,0);
				DestroyWindow(hDlg);
				return (INT_PTR)TRUE;
		}
		break;
	}
	return (INT_PTR)FALSE;
}

DWORD CALLBACK RMcpyPrgrssRout(	LARGE_INTEGER	TotalFileSize,
								LARGE_INTEGER	TotalBytesTransferred,
								LARGE_INTEGER	StreamSize,
								LARGE_INTEGER	StreamBytesTransferred,
								DWORD			dwStreamNumber,
								DWORD			dwCallbackReason,
								HANDLE			hSourceFile,
								HANDLE			hDestinationFile,
								LPVOID			lpData)
{
	cpyTrdDat *pdat = (cpyTrdDat*)lpData;
	__int64 tfs = ((__int64)TotalFileSize.HighPart << 32) | TotalFileSize.LowPart;
	__int64 tbt = ((__int64)TotalBytesTransferred.HighPart << 32) | TotalBytesTransferred.LowPart;
	double prgrsPos = tfs?(1000.0*tbt/tfs):1000.0;
	PostMessage(GetDlgItem(pdat->hDlg,IDC_PROGRESS_COPY_SINGLE),PBM_SETPOS,(int)prgrsPos,0);

	tbt += copySrcSz;
	double prgrsPosTot = tfs?(1000.0*tbt/srcSz):1000.0;
	PostMessage(GetDlgItem(pdat->hDlg,IDC_PROGRESS_COPY_TOTAL),PBM_SETPOS,(int)prgrsPosTot,0);

	// ***************** % calculating: ***********************
	wchar_t s[MAX_PATH];StringCchPrintf(s,MAX_PATH,L"%.2f %s",0.1f*prgrsPos,L"%");
	SetDlgItemText(pdat->hDlg,IDC_STATIC1,s);
	StringCchPrintf(s,MAX_PATH,L"%.2f %s",100.0-0.1*prgrsPos,"%");
	SetDlgItemText(pdat->hDlg,IDC_STATIC3,s);
	StringCchPrintf(s,MAX_PATH,L"%.2f %s",tfs?(100.0*tbt/srcSz):100.0,L"%");
	SetDlgItemText(pdat->hDlg,IDC_STATIC6,s);
	StringCchPrintf(s,MAX_PATH,L"%.2f %s",tfs?(100.0-100.0*tbt/srcSz):100.0,L"%");
	SetDlgItemText(pdat->hDlg,IDC_STATIC8,s);

	// ***************** tick calculating: ********************
	DWORD tick = GetTickCount() - pdat->beginTick - pdat->stopTick[0];
	MyTimeToString(s, tick);
	SetDlgItemText(pdat->hDlg,IDC_STATIC2,s);
	if(prgrsPos>0.0f)
	{	MyTimeToString(s, (int)(tick*(1000.0f-prgrsPos)/prgrsPos));
		SetDlgItemText(pdat->hDlg,IDC_STATIC4,s);
	}
	
	tick = GetTickCount() - pdat->beginTickTot - pdat->stopTickTot[0];
	MyTimeToString(s, tick);
	SetDlgItemText(pdat->hDlg,IDC_STATIC7,s);
	if(prgrsPosTot>0.0f)
	{	MyTimeToString(s, (int)(tick*(1.0f-0.001f*prgrsPosTot)/(0.001f*prgrsPosTot)));
		SetDlgItemText(pdat->hDlg,IDC_STATIC9,s);
	}
	
	if(pdat->bCancel)
		return PROGRESS_CANCEL;

	//Agar 1tagina fayl b-sa:
	MSG msg;//Only thread message:

Loop:
	if(pdat->bSwtchToBckgrnd)
	{	while(PeekMessage(&msg,pdat->hDlg,0,0,PM_REMOVE))
		{			
			//static int i=0;
			//wchar_t ss[32];sprintf(ss,"\n %d ",i++);
			//OutputDebugString(ss);
			//OutputDebugString(GetWinNotifyText(msg.message));
			
			DispatchMessage(&msg);//from bckgrnd queue:
	}	}

	//message from thread queue:
	if(PeekMessage(&msg,(HWND)-1,MYWM_CANCEL-1,MYWM_CANCEL+10,PM_REMOVE))
	{	
		//static int i=0;
		//wchar_t ss[32];sprintf(ss,"\n %d ",i++);
		//OutputDebugString(ss);
		//OutputDebugString(GetWinNotifyText(msg.message));
		
		switch(msg.message)
		{	case MYWM_CANCEL:
				return PROGRESS_CANCEL;
			case MYWM_STOP:
				if(pdat->bStop)
				{	LoadString(hInst,IDS_STRINGSW_50,s,MAX_PATH);
					SetDlgItemText(pdat->hDlg,IDC_BUTTON_STOP,s);
					pdat->stopTick[0] = GetTickCount() - pdat->stopTick[1];
					pdat->stopTickTot[0] = GetTickCount() - pdat->stopTickTot[1];
					pdat->bStop = FALSE;
				}
				else
				{	LoadString(hInst,IDS_STRINGSW_3,s,MAX_PATH);
					SetDlgItemText(pdat->hDlg,IDC_BUTTON_STOP,s);
					pdat->bStop = TRUE;
					pdat->stopTick[1] = pdat->stopTickTot[1] = GetTickCount();
					Sleep(250);
					goto Loop;
				}
				break;
			case MYWM_GOTOBCKGRND:
				EndDialog(pdat->hDlg,0);
				pdat->hDlg = CreateDialog(hInst,
								MAKEINTRESOURCE(IDD_DIALOG_COPY_QUEUE),
								NULL/*hWnd*/,RMCopyBckgrndDlgProc);
				ShowWindow(pdat->hDlg,SW_SHOW);
				pdat->bSwtchToBckgrnd = TRUE;
				break;
 	}	}
	else if(pdat->bStop)
	{	Sleep(250);
		goto Loop;
	}

	return PROGRESS_CONTINUE;
}

VOID RMcpyFileExThrdFnc(LPVOID lpar)
{
cpyTrdDat dat; dat.hDlg = (HWND)lpar;
	dat.bStop = FALSE;
	dat.bCancel = FALSE;
	dat.bSwtchToBckgrnd = FALSE;
	dat.thrId = GetCurrentThreadId();
	dat.beginTick = dat.beginTickTot = GetTickCount();
	dat.stopTick[0] = dat.stopTickTot[0] = 0;
	enCheckCopyFilesToExisting = showEach;

 wchar_t dst[MAX_PATH],buf[MAX_PATH];
 size_t dstPathLn;

 int totFiles = GetSelectedFilesCnt();
 dat.stack = (CpyStack*)malloc(totFiles*sizeof(CpyStack));
 GetSelectedFiles(dat.stack);
 fCopyOper::CutSelectedNames(dat.stack,panel[srcPanel].GetPath(),totFiles);

 
 dstPathLn=MyStringCpy(dst,MAX_PATH,destPath);
 if(allToRenFolder==srcType)
 {	if('\\'!=dst[dstPathLn-1])
	{	if('*'!=dst[dstPathLn-1])
		{	dst[dstPathLn++]='\\';//MyStringCat(dst,MAX_PATH,"\\");//Yangi yo'l kiritsa;
 			dst[dstPathLn]=0;
		}
		else dst[--dstPathLn]=0;
	}
	int m=MessageBox(dat.hDlg,L"Create this directory?",dst,MB_YESNOCANCEL|MB_ICONWARNING|MB_SYSTEMMODAL);
	if(IDNO==m)
	{	srcType=unchange;
		wchar_t *p=wcsrchr(dst,'\\');
		if(p) *(p+1)=0;
	}
	else if(IDCANCEL==m)
		goto End;	
  	if(!MyCreateDirectory(dst,NULL))//yangi yo'lini avval yaratib olsun;
		goto End;
 }
  
 BOOL bSkipAll=FALSE;
 for(dat.iCrntFileCopy=0; dat.iCrntFileCopy<totFiles; dat.iCrntFileCopy++)
 {
 

 if(unchange==srcType || allToRenFolder==srcType)
	MyStringCpy(&dst[dstPathLn],MAX_PATH-(int)dstPathLn,dat.stack[dat.iCrntFileCopy].Name);//MyStringCat(dst,MAX_PATH,dat.stack[dat.iCrntFileCopy].Name);
 else
 {	if(allToRenFolder==srcType)
	{	//wchar_t *p=NULL;
		//if(dat.iCrntFileCopy>0)
		//if(folder==dat.stack[dat.iCrntFileCopy].attribute)//o'zgartirsa:
		//	p = strchr(dat.stack[dat.iCrntFileCopy].Name,'\\');
		MyStringCpy(&dst[dstPathLn],MAX_PATH-(int)dstPathLn,dat.stack[dat.iCrntFileCopy].Name);//MyStringCat(dst,MAX_PATH,dat.stack[dat.iCrntFileCopy].Name);
 	}
	else if(rename1Folder==srcType)
	{	if(dat.iCrntFileCopy>0)
		{	wchar_t *p=NULL;
			if(folder==dat.stack[0].attribute)//o'zgartirsa:
				p = wcschr(dat.stack[dat.iCrntFileCopy].Name,'\\');
			MyStringCpy(&dst[dstPathLn],MAX_PATH-(int)dstPathLn,p?p:dat.stack[dat.iCrntFileCopy].Name);//MyStringCat(dst,MAX_PATH,p?p:dat.stack[dat.iCrntFileCopy].Name);
 }	}	}


 if(mMoveFileWithProgress == copyMethod)
 {
 //if(dst[0]!=dat.stack[dat.iCrntFileCopy].FullPathAndName[0])	
 //Agar diski 1 xil b-masa tez bo'lmaydur:
  if(file==dat.stack[dat.iCrntFileCopy].attribute)
  { if(!wcscmp(dat.stack[dat.iCrntFileCopy].FullPathAndName,dst))
    {	LoadString(hInst,IDS_STRINGSW_51,buf,MAX_PATH);
		MessageBox(NULL,buf,L"Err.",MB_OK);
    }
    else
	{int r=fBckgrndCopyOper::CheckCopyFilesToExisting(dat.hDlg,dat.stack[dat.iCrntFileCopy].FullPathAndName,dst);
     if(r==overwrite || r==overwriteAll)
     { if(r==overwriteAll)
		enCheckCopyFilesToExisting = (EnCheckCopyFilesToExisting)r;
LoopMove:
	  if(!MyMoveFileWithProgress(dat.stack[dat.iCrntFileCopy].FullPathAndName,dst,RMcpyPrgrssRout,&dat,MOVEFILE_COPY_ALLOWED) && (!bSkipAll))
	  {	LPVOID* par[3]={(LPVOID*)GetLastError(),(LPVOID*)dat.stack[dat.iCrntFileCopy].FullPathAndName,(LPVOID*)dst};
		int r = (int)DialogBoxParam(hInst,MAKEINTRESOURCE(IDD_DIALOG_CHOISE_ACTION),dat.hDlg,fDelOper::actnDlgProc1,(LPARAM)par);
		if(0==r) goto End;//Cancel action;
		if(1==r) goto LoopMove;
		if(3==r)
			bSkipAll=TRUE;//2-skip,3-skipAll;
	 }}
	 else if(r==skipAll)
     { 	enCheckCopyFilesToExisting = (EnCheckCopyFilesToExisting)r;
     	goto End;
	 }
	 else if(r==cancel)
     	goto skipOne;
     else if(r==rename1 || r==renameAll)
     { if(r==renameAll)
		enCheckCopyFilesToExisting = (EnCheckCopyFilesToExisting)r;
LoopRename:
	  if(!MyMoveRenameFileWithProgress(dat.stack[dat.iCrntFileCopy].FullPathAndName,dst,RMcpyPrgrssRout,&dat,MOVEFILE_COPY_ALLOWED) && (!bSkipAll))
	  {	LPVOID* par[3]={(LPVOID*)GetLastError(),(LPVOID*)dat.stack[dat.iCrntFileCopy].FullPathAndName,(LPVOID*)dst};
		int r = (int)DialogBoxParam(hInst,MAKEINTRESOURCE(IDD_DIALOG_CHOISE_ACTION),dat.hDlg,fDelOper::actnDlgProc1,(LPARAM)par);
		if(0==r) goto End;//Cancel action;
		if(1==r) goto LoopRename;
		if(3==r)
			bSkipAll=TRUE;//2-skip,3-skipAll;
	 }}
     else if(r==overwriteOldest || r==overwriteOldestAll)
     { if(r==overwriteOldestAll)
		enCheckCopyFilesToExisting = (EnCheckCopyFilesToExisting)r;
LoopOverOldest:
	  if(!MyMoveOverwriteOldestFileWithProgress(dat.stack[dat.iCrntFileCopy].FullPathAndName,dst,RMcpyPrgrssRout,&dat,MOVEFILE_COPY_ALLOWED) && (!bSkipAll))
	  {	LPVOID* par[3]={(LPVOID*)GetLastError(),(LPVOID*)dat.stack[dat.iCrntFileCopy].FullPathAndName,(LPVOID*)dst};
		int r = (int)DialogBoxParam(hInst,MAKEINTRESOURCE(IDD_DIALOG_CHOISE_ACTION),dat.hDlg,fDelOper::actnDlgProc1,(LPARAM)par);
		if(0==r) goto End;//Cancel action;
		if(1==r) goto LoopOverOldest;
		if(3==r)
			bSkipAll=TRUE;//2-skip,3-skipAll;
	 }}
     else if(r==overwriteLatest || r==overwriteLatestAll)
     { if(r==overwriteLatestAll)
		enCheckCopyFilesToExisting = (EnCheckCopyFilesToExisting)r;
LoopOverLatest:
	  if(!MyMoveOverwriteLatestFileWithProgress(dat.stack[dat.iCrntFileCopy].FullPathAndName,dst,RMcpyPrgrssRout,&dat,MOVEFILE_COPY_ALLOWED) && (!bSkipAll))
	  {	LPVOID* par[3]={(LPVOID*)GetLastError(),(LPVOID*)dat.stack[dat.iCrntFileCopy].FullPathAndName,(LPVOID*)dst};
		int r = (int)DialogBoxParam(hInst,MAKEINTRESOURCE(IDD_DIALOG_CHOISE_ACTION),dat.hDlg,fDelOper::actnDlgProc1,(LPARAM)par);
		if(0==r) goto End;//Cancel action;
		if(1==r) goto LoopOverLatest;
		if(3==r)
			bSkipAll=TRUE;//2-skip,3-skipAll;
	 }}
     else if(r==overwriteBigest || r==overwriteBigestAll)
     { if(r==overwriteBigestAll)
		enCheckCopyFilesToExisting = (EnCheckCopyFilesToExisting)r;
LoopOverBigest:
	  if(!MyMoveOverwriteBigestFileWithProgress(dat.stack[dat.iCrntFileCopy].FullPathAndName,dst,RMcpyPrgrssRout,&dat,MOVEFILE_COPY_ALLOWED) && (!bSkipAll))
	  {	LPVOID* par[3]={(LPVOID*)GetLastError(),(LPVOID*)dat.stack[dat.iCrntFileCopy].FullPathAndName,(LPVOID*)dst};
		int r = (int)DialogBoxParam(hInst,MAKEINTRESOURCE(IDD_DIALOG_CHOISE_ACTION),dat.hDlg,fDelOper::actnDlgProc1,(LPARAM)par);
		if(0==r) goto End;//Cancel action;
		if(1==r) goto LoopOverBigest;
		if(3==r)
			bSkipAll=TRUE;//2-skip,3-skipAll;
	 }}
     else if(r==overwriteLittlest || r==overwriteLittlestAll)
     { if(r==overwriteLittlestAll)
		enCheckCopyFilesToExisting = (EnCheckCopyFilesToExisting)r;
LoopOverLittlest:
	  if(!MyMoveOverwriteLittlestFileWithProgress(dat.stack[dat.iCrntFileCopy].FullPathAndName,dst,RMcpyPrgrssRout,&dat,MOVEFILE_COPY_ALLOWED) && (!bSkipAll))
	  {	LPVOID* par[3]={(LPVOID*)GetLastError(),(LPVOID*)dat.stack[dat.iCrntFileCopy].FullPathAndName,(LPVOID*)dst};
		int r = (int)DialogBoxParam(hInst,MAKEINTRESOURCE(IDD_DIALOG_CHOISE_ACTION),dat.hDlg,fDelOper::actnDlgProc1,(LPARAM)par);
		if(0==r) goto End;//Cancel action;
		if(1==r) goto LoopOverLittlest;
		if(3==r)
			bSkipAll=TRUE;//2-skip,3-skipAll;
	}}}
skipOne:
	copySrcSz += dat.stack[dat.iCrntFileCopy].size;
	avDstSz -= dat.stack[dat.iCrntFileCopy].size;
	PostMessage(GetDlgItem(dat.hDlg,IDC_PROGRESS_COPY_SINGLE),PBM_SETPOS,1000,0);
	PostMessage(GetDlgItem(dat.hDlg,IDC_PROGRESS_COPY_TOTAL ),PBM_SETPOS,
    (int)(srcSz?(1000.0f*copySrcSz/srcSz):1000.0f),0);
	dat.stopTick[0] = 0;
	dat.beginTick = GetTickCount();
  }
  else
  {	if(!MyCreateDirectory(dst,NULL))
	{	LPVOID* par[2]={(LPVOID*)GetLastError(),(LPVOID*)dst};
		int r = (int)DialogBoxParam(hInst,MAKEINTRESOURCE(IDD_DIALOG_CHOISE_ACTION),dat.hDlg,fDelOper::actnDlgProc,(LPARAM)par);
		if(0==r) goto End;//Cancel action;
		if(1==r) goto LoopOverLittlest;
		if(3==r)
			bSkipAll=TRUE;//2-skip,3-skipAll;
 }} }
 else if(mSHFileOperation == copyMethod)
 {	MySHFileOperation(FO_MOVE,dat.stack[dat.iCrntFileCopy].FullPathAndName,dst,
				FOF_SILENT|FOF_NOCONFIRMATION|FOF_NOCONFIRMMKDIR,FALSE);
	copySrcSz += dat.stack[dat.iCrntFileCopy].size;
	avDstSz -= dat.stack[dat.iCrntFileCopy].size;
	PostMessage(GetDlgItem(dat.hDlg,IDC_PROGRESS_COPY_SINGLE),PBM_SETPOS,1000,0);
	PostMessage(GetDlgItem(dat.hDlg,IDC_PROGRESS_COPY_TOTAL ),PBM_SETPOS,
    (int)(srcSz?(1000.0f*copySrcSz/srcSz):1000.0f),0);
	dat.stopTick[0] = 0;
	dat.beginTick = GetTickCount();
 }



 dst[dstPathLn]=0;
	
Loop:
	MSG msg;//Only thread message:
	if(PeekMessage(&msg,(HWND)-1,MYWM_CANCEL-1,MYWM_CANCEL+10,PM_REMOVE))
	{	
		//static int i=0;
		//wchar_t ss[32];sprintf(ss,"\n %d ",i++);
		//OutputDebugString(ss);
		//OutputDebugString(GetWinNotifyText(msg.message));
		
		switch(msg.message)
		{	case MYWM_CANCEL:
				dat.bCancel = TRUE;
				goto End;
			case MYWM_STOP:
				wchar_t s[MAX_PATH];
				if(dat.bStop)
				{	LoadString(hInst,IDS_STRINGSW_50,s,MAX_PATH);
					SetDlgItemText(dat.hDlg,IDC_BUTTON_STOP,s);
					dat.bStop = FALSE;
				}
				else
				{	LoadString(hInst,IDS_STRINGSW_3,s,MAX_PATH);
					SetDlgItemText(dat.hDlg,IDC_BUTTON_STOP,s);
					dat.bStop = TRUE;
					Sleep(250);
					goto Loop;
				}
				break;
			case MYWM_GOTOBCKGRND:
				EndDialog(dat.hDlg,0);
				dat.hDlg = CreateDialog(hInst,
								MAKEINTRESOURCE(IDD_DIALOG_COPY_QUEUE),
								NULL/*hWnd*/,RMCopyBckgrndDlgProc);
				ShowWindow(dat.hDlg,SW_SHOW);
				dat.bSwtchToBckgrnd = TRUE;
				return;
 	}	}
	else if(dat.bStop)
	{	Sleep(250);
		goto Loop;
}	}
End:
 EndDialog(dat.hDlg,0);

 //Agar MoveFileWithProgress ni ishlatsak, delete qilishimiz kerak:
 if(mMoveFileWithProgress == copyMethod)
 {	//All files:
	for(dat.iCrntFileCopy=0; dat.iCrntFileCopy<totFiles; dat.iCrntFileCopy++)
	{	if(file==dat.stack[dat.iCrntFileCopy].attribute)
		{	
/*LoopDel:*/if(!MyDeleteFile(dat.stack[dat.iCrntFileCopy].FullPathAndName) && (!bSkipAll))
			{	//chunki move hammasini ko'chiradur;
				//LPVOID* par[2]={(LPVOID*)GetLastError(),(LPVOID*)dat.stack[dat.iCrntFileCopy].FullPathAndName};
				//int r = DialogBoxParam(hInst,MAKEINTRESOURCE(IDD_DIALOG_CHOISE_ACTION),::hWnd,fDelOper::actnDlgProc,(LPARAM)par);
				//if(0==r) goto Enddel;//Cancel action;
				//if(1==r) goto LoopDel;
				//if(3==r) bSkipAll=TRUE;//2-skip,3-skipAll;
	}	}	}

	//All directories:
	for(dat.iCrntFileCopy=0; dat.iCrntFileCopy<totFiles; dat.iCrntFileCopy++)
	{	if(folder==dat.stack[dat.iCrntFileCopy].attribute)
		{	
LoopRemDir:	if(!RemoveDirectory(dat.stack[dat.iCrntFileCopy].FullPathAndName) && (!bSkipAll))
			{	LPVOID* par[2]={(LPVOID*)GetLastError(),(LPVOID*)dat.stack[dat.iCrntFileCopy].FullPathAndName};
				int r = (int)DialogBoxParam(hInst,MAKEINTRESOURCE(IDD_DIALOG_CHOISE_ACTION),::hWnd,fDelOper::actnDlgProc,(LPARAM)par);
				if(0==r) goto Enddel;//Cancel action;
				if(1==r) goto LoopRemDir;
				if(3==r)
					bSkipAll=TRUE;//2-skip,3-skipAll;
 	} 	}	}
	/*for(dat.iCrntFileCopy=0; dat.iCrntFileCopy<totFiles; dat.iCrntFileCopy++)
	{	MySHFileOperation(FO_DELETE,
					dat.stack[dat.iCrntFileCopy].FullPathAndName,NULL,0);
 }*/}
Enddel:
 if(dat.stack) free(dat.stack);
 ExitThread(0);
}

INT_PTR CALLBACK RMCopyQueueDlgProc(HWND hDlg,UINT message,WPARAM wParam,LPARAM lParam)
{
static HFONT hf=0;static int hfRef=0;//obshiy hf, dinamik uchun emas:
static HBRUSH br=0;
static HBRUSH brHtBk=0;
	switch(message)
	{
	case WM_INITDIALOG:
		//Adjust to center:
		RECT rc; GetWindowRect(hDlg, &rc);
		int width,left,height,top;

		width = rc.right - rc.left;
		left = conf::wndLeft + (conf::wndWidth - width)/2;

		height = rc.bottom - rc.top;
		top = conf::wndTop + (conf::wndHeight - height)/2;
		MoveWindow(hDlg, left, top+20, width, height, TRUE);

		//Load language strings:
		wchar_t s[MAX_PATH];
		LoadString(hInst,IDS_STRINGSW_46,s,MAX_PATH);
		SetWindowText(hDlg,s);
		LoadString(hInst,IDS_STRINGSW_47,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_STATIC,s);
		LoadString(hInst,IDS_STRINGSW_48,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_STATIC5,s);
		LoadString(hInst,IDS_STRINGSW_49,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_BUTTON_TO_BACKGROUND_COPY_QUEUE,s);
		LoadString(hInst,IDS_STRINGSW_50,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_BUTTON_STOP,s);
		LoadString(hInst,IDS_STRINGSW_13,s,MAX_PATH);
		SetDlgItemText(hDlg,IDCANCEL,s);

		PostMessage(GetDlgItem(hDlg,IDC_PROGRESS_COPY_SINGLE),PBM_SETRANGE,0,MAKELPARAM(0,1000));
		PostMessage(GetDlgItem(hDlg,IDC_PROGRESS_COPY_TOTAL ),PBM_SETRANGE,0,MAKELPARAM(0,1000));
		PostMessage(GetDlgItem(hDlg,IDC_PROGRESS_COPY_SINGLE),PBM_SETSTEP,1,0);
		PostMessage(GetDlgItem(hDlg,IDC_PROGRESS_COPY_TOTAL ),PBM_SETSTEP,1,0);

		SendMessage(hDlg,WM_USER+1,0,0);

		fCopyOper::CalcSrcAndAvailableDestSize();
		if(avDstSz < srcSz)
		{	wchar_t txt[MAX_PATH];StringCchPrintf(txt,MAX_PATH,L"Available memory in dest is: %d, but needed %d. Start copy to available?",avDstSz,srcSz);
			if(IDCANCEL==MessageBox(NULL,txt,L"Warn:",MB_OKCANCEL))
			{	EndDialog(hDlg,0);
				return TRUE;
		}	}
		copySrcSz = 0;

		//MyButtonFrRCBtn(hDlg,IDC_BUTTON_TO_BACKGROUND_COPY_QUEUE,conf::Dlg.iBtnsType);
		//MyButtonFrRCBtn(hDlg,IDC_BUTTON_STOP,conf::Dlg.iBtnsType);
		//MyButtonFrRCBtn(hDlg,IDCANCEL,conf::Dlg.iBtnsType);

		static DWORD cpyThrdId;
		CreateThread(NULL,1024,(LPTHREAD_START_ROUTINE)RMcpyFileExThrdFnc,
					 hDlg,0,&cpyThrdId);
		return TRUE;
	case WM_CTLCOLORSTATIC:
	case WM_CTLCOLORDLG:
		if(2==conf::Dlg.iBtnsType)//ownedraw
		{	HDC dc;dc = (HDC)wParam;
			SetTextColor(dc,conf::Dlg.dlgRGBs[1][1]);
			SetBkColor(dc,conf::Dlg.dlgRGBs[1][2]);
			return (INT_PTR)br;
		}return 0;
	case WM_CTLCOLOREDIT:
		if(2==conf::Dlg.iBtnsType)//ownedraw
		{	HDC dc = (HDC)wParam;
			SetTextColor(dc,conf::Dlg.dlgRGBs[1][1]);
			SetBkColor(dc,conf::Dlg.dlgRGBs[1][2]);
			return (INT_PTR)br;
		}return 0;
	case WM_CTLCOLORBTN:
		if(2==conf::Dlg.iBtnsType)//ownedraw
		{	HDC dc=(HDC)wParam;
			SetTextColor(dc,conf::Dlg.dlgRGBs[1][4]);
			SetBkColor(dc,conf::Dlg.dlgRGBs[1][5]);
			return (INT_PTR)brHtBk;
		}return 0;
	case WM_DRAWITEM://WM_CTLCOLORBTN dagi knopkalar:
		if(2==conf::Dlg.iBtnsType)//ownedraw
		{	LPDRAWITEMSTRUCT lpdis;lpdis = (LPDRAWITEMSTRUCT)lParam;
			GetWindowText(lpdis->hwndItem,s,64);
			UINT uStyle;uStyle = DFCS_BUTTONPUSH;
			rc = lpdis->rcItem;
			if(lpdis->itemState & ODS_SELECTED)
			{	uStyle |= DFCS_PUSHED;
				rc.left+=2;rc.top+=2;
			}
			DrawFrameControl(lpdis->hDC, &lpdis->rcItem, DFC_BUTTON, uStyle);
			if(lpdis->itemState & ODS_SELECTED)
				{rc.left+=1;rc.top+=1;rc.bottom-=2;rc.right-=3;}
			else
				{rc.left+=1;rc.top+=2;rc.bottom-=3;rc.right-=3;}
			FillRect(lpdis->hDC,&rc,brHtBk);//DrawText(lpdis->hDC,"                                                  ",50,&rc,DT_SINGLELINE|DT_VCENTER|DT_INTERNAL|DT_LEFT);
			if(lpdis->itemState & ODS_SELECTED)
				{rc.left-=1;rc.top-=1;rc.bottom+=3;rc.right+=3;}
			else
				{rc.left-=1;rc.top-=2;rc.bottom+=2;rc.right+=3;}
			DrawText(lpdis->hDC,s,MyStringLength(s,64),&rc,DT_SINGLELINE|DT_VCENTER|DT_CENTER);
			return TRUE;
		}return 0;
	case WM_USER+1://hf obshiy uchun, dinamik o'zgartirish uchun emas:
		if(0==hfRef)
		{	hf = CreateFontIndirect(&conf::Dlg.dlgFnts[1]);
			br = CreateSolidBrush(conf::Dlg.dlgRGBs[1][0]);
			brHtBk = CreateSolidBrush(conf::Dlg.dlgRGBs[1][5]);
		}
		SendMessage(GetDlgItem(hDlg,IDC_STATIC),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_STATIC5),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_BUTTON_TO_BACKGROUND_COPY_QUEUE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_BUTTON_STOP),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDCANCEL),WM_SETFONT,(WPARAM)hf,TRUE);
		++hfRef;
		return 0;//GWL_USERDATA
	case WM_DESTROY:
		if(--hfRef<1)
		{	DeleteObject(hf);
			DeleteObject(br);
			DeleteObject(brHtBk);
		}
		return 0;
	case WM_COMMAND:
		switch(LOWORD(wParam))
		{	case IDC_BUTTON_TO_BACKGROUND_COPY_QUEUE:
				PostThreadMessage(cpyThrdId,MYWM_GOTOBCKGRND,0,0);
				return (INT_PTR)TRUE;
			case IDC_BUTTON_STOP:
				PostThreadMessage(cpyThrdId,MYWM_STOP,0,0);
				return (INT_PTR)TRUE;
			case IDCANCEL:
				PostThreadMessage(cpyThrdId,MYWM_CANCEL,0,0);
				EndDialog(hDlg,0);
				return (INT_PTR)TRUE;
		}
		break;
	}
	return (INT_PTR)FALSE;
}

BOOL ShowCopyDlg(Panel *frPanel)
{
	if(frPanel->GetTotSelects()==0)
	if(frPanel->GetHot()<1 || frPanel->GetHot()>frPanel->GetTotItems()-1)
		return TRUE;

	if(rndPathList==frPanel->GetOpponent()->GetEntry()->GetCrntRecType())
	{	MessageBox(hWnd,L"Do not move to results list of searching.",L"Warn!!!",MB_OK);
		return FALSE;
	}
	
	int r = 0;

	if(directFolder==frPanel->GetEntry()->GetCrntRecType() && archElem==frPanel->GetOpponent()->GetEntry()->GetCrntRecType())
	{	if(archive::ToArjShowDlg(frPanel,frPanel->GetOpponent()))
		return fDelOper::Delete(frPanel,FALSE);
	}

	if(archElem==frPanel->GetEntry()->GetCrntRecType() && archElem==frPanel->GetOpponent()->GetEntry()->GetCrntRecType())
	{	archive::FrArjToArjShowDlg(frPanel,frPanel->GetOpponent());
		return fDelOper::Delete(frPanel,FALSE);
	}

	switch(conf::iCopyDlgBtnPlaces)
	{	case 0:
			r = (int)DialogBoxParam(hInst,MAKEINTRESOURCE(IDD_DIALOG_COPY_MASTER),hWnd,RMCopyDlgProc,(LPARAM)frPanel);
			break;
		case 1:
			r = (int)DialogBoxParam(hInst,MAKEINTRESOURCE(IDD_DIALOG_COPY_MASTER1),hWnd,RMCopyDlgProc,(LPARAM)frPanel);
		case 2:
			r = (int)DialogBoxParam(hInst,MAKEINTRESOURCE(IDD_DIALOG_COPY_MASTER2),hWnd,RMCopyDlgProc,(LPARAM)frPanel);
			break;
	}
	if(r>0)
	{	if(socketCl==frPanel->GetEntry()->GetCrntRecType() ||
		socketCl==frPanel->GetOpponent()->GetEntry()->GetCrntRecType()  )
		{
		  r = (int)DialogBoxParam(hInst,MAKEINTRESOURCE(IDD_DIALOG_COPY_QUEUE),hWnd,linkSock::RMCopyQueueDlgProc,1);
		}
		//archive element processing: **************************************************************************************************
	else if(archElem==frPanel->GetEntry()->GetCrntRecType() && directFolder==frPanel->GetOpponent()->GetEntry()->GetCrntRecType()) //*
		{ //OutputDebugString("\nShowCopyDlg 3");																					 //*
		  r = (int)DialogBoxParam(hInst,MAKEINTRESOURCE(IDD_DIALOG_COPY_QUEUE),hWnd,archive::CopyQueueDlgProc,1);						 //*
		}																															 //*
		else if(directFolder==frPanel->GetEntry()->GetCrntRecType() && archElem==frPanel->GetOpponent()->GetEntry()->GetCrntRecType()) //*
		{ //OutputDebugString("\nShowCopyDlg 3");																					 //*
		  //r = DialogBoxParam(hInst,MAKEINTRESOURCE(IDD_DIALOG_COPY_QUEUE),hWnd,archive::CopyToQueueDlgProc,1);					 //*
		}																															 //*		
		else if(archElem==frPanel->GetEntry()->GetCrntRecType() && archElem==frPanel->GetOpponent()->GetEntry()->GetCrntRecType())	 //*
		{ //OutputDebugString("\nShowCopyDlg 3");																					 //*
		  //r = DialogBoxParam(hInst,MAKEINTRESOURCE(IDD_DIALOG_COPY_QUEUE),hWnd,archive::RMCopyToQueueDlgProc,1);					 //*
		}//exd of archive element processing: ******************************************************************************************
		else
		{	if(linkSock::sockDlg[frPanel->iOpponent])
				Err::FlipMsg(L"Can't copy to client socket...",2000);
			else if(linkSock::sockDlg[frPanel->iThis])
				Err::FlipMsg(L"Can't copy from client socket...",2000);
			else
			{	if(single==copyType)
					r = (int)DialogBoxParam(hInst,MAKEINTRESOURCE(IDD_DIALOG_COPY_QUEUE),hWnd,RMCopyQueueDlgProc,1);
				else if(addToBack==copyType)
					r = fBckgrndMoveOper::AddToQueueFrMoveOperation();
	}	}	}
	if(archElem==frPanel->GetEntry()->GetCrntRecType())//ChangeNotify qilishi kerak narsa:
		frPanel->GetArch()->DeleteSelections(frPanel);		
	frPanel->FreeSelection();
	return FALSE;//(r>0?TRUE:FALSE);
}

/*VOID RMcpyFileExBckQueueThrdFnc(LPVOID lpar)
{
cpyTrdDat dat; dat.hDlg = (HWND)lpar;
	dat.bStop = FALSE;
	dat.bCancel = FALSE;
	dat.bSwtchToBckgrnd = FALSE;
	dat.thrId = GetCurrentThreadId();
	dat.stack = NULL;

 wchar_t dst[MAX_PATH];
 size_t dstPathLn;

 StringCchPrintf(dst,MAX_PATH,destPath);
 dstPathLn = MyStringLength(destPath,MAX_PATH);//StringCchLength(fRenMove.destPath,MAX_PATH,&dstPathLn);

 dat.hDlg = CreateDialog(hInst,MAKEINTRESOURCE(IDD_DIALOG_COPY_BACKGROUND_QUEUE),NULL,RMCopyBckgrndDlgProc);
 ShowWindow(dat.hDlg,SW_SHOW);//IDC_EDIT_COPY_BCKGRND_QUEUE

 /*for(int i=0; i<fRenMove.srcCnt; i++)
 {  int id = panel[fRenMove.srcPanel].pSelects[i];
	if(file == panel[fRenMove.srcPanel].GetItem(id)->attribute)
	{	if(fRenMove.IsFileExtIncludeCopyFilter(id))
		{	panel[fRenMove.srcPanel].GetFullPathAndName(id,s,MAX_PATH);
			wchar_t RetCar[3] = {0x0d, 0x0a, 0x00};
			SendMessage(GetDlgItem(dlg,IDC_EDIT_COPY_BCKGRND_QUEUE),EM_REPLACESEL,(WPARAM)FALSE,(LPARAM)(LPCSTR)s);
			SendMessage(GetDlgItem(dlg,IDC_EDIT_COPY_BCKGRND_QUEUE),EM_REPLACESEL, (WPARAM)FALSE, (LPARAM)(LPCSTR)RetCar);
			SendMessage(GetDlgItem(dlg,IDC_EDIT_COPY_BCKGRND_QUEUE),EM_SCROLLCARET, (WPARAM)0, (LPARAM)0);

			MyStringCat(dst,MAX_PATH,panel[fRenMove.srcPanel].GetItem(id)->Name);
			SendMessage(GetDlgItem(dlg,IDC_EDIT_COPY_BCKGRND_QUEUE2),EM_REPLACESEL,(WPARAM)FALSE,(LPARAM)(LPCSTR)dst);
			SendMessage(GetDlgItem(dlg,IDC_EDIT_COPY_BCKGRND_QUEUE2),EM_REPLACESEL, (WPARAM)FALSE, (LPARAM)(LPCSTR)RetCar);
			SendMessage(GetDlgItem(dlg,IDC_EDIT_COPY_BCKGRND_QUEUE2),EM_SCROLLCARET, (WPARAM)0, (LPARAM)0);
	}	}	
	else if(folder == panel[fRenMove.srcPanel].GetItem(id)->attribute)
		fRenMove.AddFolderToEdit(panel[fRenMove.srcPanel].GetItem(id)->Name);
  }*/
	
/*Loop:
	MSG msg;//Only thread message:
	//while(PeekMessage(&msg,pdat->hDlg,0,0,PM_REMOVE))
	//{	DispatchMessage(&msg);//from bckgrnd queue:
	//}
	if(PeekMessage(&msg,(HWND)-1,MYWM_CANCEL-1,MYWM_CANCEL+10,PM_REMOVE))
	{	
		//static int i=0;
		//wchar_t ss[32];sprintf(ss,"\n %d ",i++);
		//OutputDebugString(ss);
		//OutputDebugString(GetWinNotifyText(msg.message));
		
		switch(msg.message)
		{	case MYWM_CANCEL:
				//dat.bCancel = TRUE;
				EndDialog(dat.hDlg,0);
				if(dat.stack) free(dat.stack);
				ExitThread(0);
				return;
			case MYWM_STOP:
				wchar_t s[MAX_PATH];
				if(dat.bStop)
				{	LoadString(hInst,IDS_STRINGSW_50,s,MAX_PATH);
					SetDlgItemText(dat.hDlg,IDC_BUTTON_STOP,s);
					dat.bStop = FALSE;
				}
				else
				{	LoadString(hInst,IDS_STRINGSW_3,s,MAX_PATH);
					SetDlgItemText(dat.hDlg,IDC_BUTTON_STOP,s);
					dat.bStop = TRUE;
					Sleep(250);
					goto Loop;
				}
				break;
 	}	}
	else if(dat.bStop)
	{	Sleep(250);
		goto Loop;
}//	}*/

// EndDialog(dat.hDlg,0);
 //ExitThread(0);
//}

}//end of namespace fRenMove