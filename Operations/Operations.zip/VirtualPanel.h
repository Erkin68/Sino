#ifndef __VIRTUAL_PANEL_H_
#define __VIRTUAL_PANEL_H_


#include "windows.h"
#include "..\config.h"


class CVirtPnlPlgn;
namespace vrtlPanels
{
	typedef const int (*GetPluginType_t)();
	typedef VOID (*SetCallbacks$4xxx_t)(LPVOID,...);
	typedef VOID (*SetId$4_t)(int);
	typedef const wchar_t* (*GetPluginDescription_t)();
	typedef const wchar_t* (*GetPluginName_t)();
	typedef VOID (*ShowOptionDialog_t)();

	typedef LPVOID (*AttachPanel$12_t)(HWND,LPVOID,wchar_t*);
	typedef LPVOID (*EnumDir$12_t)(HWND,LPVOID,wchar_t*);
	typedef LPVOID (*GetReadyForEnumDir$12_t)(HWND,LPVOID,wchar_t*);
	typedef VOID (*DetachPanel$8_t)(LPVOID,LPVOID);
	typedef BOOL (*GetItemPathAndName$16_t)(LPVOID,wchar_t*,int,DWORD);
	typedef BOOL (*GetStrForTooltip$20_t)(LPVOID,wchar_t*,int,DWORD,int*);

//ret value:
//0 - no change, no action in panel space;
//1 - panel path unchange, select items listed in buffer;
//2 - change panel path to first string in buffer and select items listed in buffer after path;
//3 - clear panel and add random items listed in buffer;
//buffer - dll allocated memory space. Dll module will destroy the memory in the process deattaching time.
// Buffer signature for ending strings is doubled NULL char, length of the buufer in bufferLen.
	typedef int (*ShowSearchDlg$20_t)(HWND,LPVOID,wchar_t*,LPVOID*,DWORD*);



	//Events:
	typedef BOOL (*EventPanelResizing$8_t)(HWND,LPVOID);
	//typedef BOOL (*EventPanelItemClick$16_t)(HWND,LPVOID,int,wchar_t*);
	//typedef VOID (*EventPanelReady$8_t)(HWND,LPVOID);

	extern BOOL AttachFromName(LPVOID,wchar_t*,wchar_t*);
	extern BOOL IsKeyExist(int);
	extern BOOL IsExistAny();
	extern VOID FreePlugins();
	extern VOID LoadPlugins(HWND);
	extern VOID TryLoadPlugin(wchar_t*,wchar_t*,int);
	extern BOOL CheckKeys(conf::STKey*,Panel*);
	extern BOOL CheckFromMenuId(HWND,WPARAM,Panel*);
	extern BOOL AttachPanel$12(LPVOID,int,wchar_t*);
	extern BOOL EnumDir$12(HWND,LPVOID,int,wchar_t*);
	extern BOOL GetReadyForEnumDir$12(HWND,LPVOID,int,wchar_t*);

	extern BOOL EventPanelResizing$8(HWND,int,LPVOID);
	//extern BOOL EventPanelItemClick$16(HWND,int,LPVOID,int,wchar_t*);
	//extern BOOL EventPanelReady$8(HWND,int,LPVOID);

	extern BOOL SetMenusInStartup(HWND);
	extern VOID ShowSearchDlg$20(Panel*);

	extern CVirtPnlPlgn *plgns;
	extern int numPlugins,numIP4Plgn;
}

class CVirtPnlPlgn
{
public:

//First public functns for calling from plugins:
static BOOL	CALLBACK saveOptions(int,VOID*,int);
static BOOL	CALLBACK readOptions(int,VOID*,int);
static int	CALLBACK addItemToPanelList(IN LPVOID,wchar_t*,HICON,WIN32_FIND_DATAW*,DWORD,BOOL bRedraw=FALSE);
static int  CALLBACK changeItemInPanelList(IN LPVOID,wchar_t*,wchar_t*,BOOL);
static BOOL	CALLBACK closeEvent(int,LPVOID);
static int  CALLBACK setPanelPath(IN LPVOID,wchar_t*,int);
//static int  CALLBACK render(IN LPVOID);
//static int  CALLBACK freePanel(IN LPVOID,BOOL);
//static int  CALLBACK selectItem(IN LPVOID,int,wchar_t*);


	CVirtPnlPlgn();
	~CVirtPnlPlgn();
	HMODULE hm;
	//int dllSize;
	wchar_t pathAndName[MAX_PATH],descrpn[MAX_PATH],name[MAX_PATH];
	int  type,idNum,mnuIdNum,mRef;
	//LPVOID plgObj; chalkashlashtiradi, har 1 panelga 1 tadan Obj, 1ta Pluginga emas, !!!!!!!!!
	BOOL bOpen;
	conf::TKey key;

	BOOL LoadPlugin();
	VOID FreePlugin();
	BOOL IsPluginLoaded();

	vrtlPanels::GetPluginType_t GetPluginType;
	vrtlPanels::SetCallbacks$4xxx_t SetCallbacks$4xxx;
	vrtlPanels::SetId$4_t SetId$4;
	vrtlPanels::GetPluginDescription_t GetPluginDescription;
	vrtlPanels::GetPluginName_t GetPluginName;
	vrtlPanels::ShowOptionDialog_t ShowOptionDialog;

	vrtlPanels::AttachPanel$12_t AttachPanel$12;
	vrtlPanels::EnumDir$12_t EnumDir$12;
	vrtlPanels::GetReadyForEnumDir$12_t GetReadyForEnumDir$12;
	vrtlPanels::DetachPanel$8_t DetachPanel$8;
	vrtlPanels::GetItemPathAndName$16_t GetItemPathAndName$16;
	vrtlPanels::GetStrForTooltip$20_t GetStrForTooltip$20;
	vrtlPanels::ShowSearchDlg$20_t ShowSearchDlg$20;

	//Events:
	vrtlPanels::EventPanelResizing$8_t EventPanelResizing$8;
	//vrtlPanels::EventPanelItemClick$16_t EventPanelItemClick$16;
	//vrtlPanels::EventPanelReady$8_t EventPanelReady$8;
};

inline BOOL CVirtPnlPlgn::IsPluginLoaded()
{
	return (hm==NULL?FALSE:TRUE);
}

#endif