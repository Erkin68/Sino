#include "Temporary.h"
#include "strsafe.h"
#include "MyShell\MyShell.h"
#include "..\Config.h"
#include "..\Panel.h"
#include "..\Sino.h"




#define MAX_HANDLE_BUF_SZ_STEP 32

extern BOOL MySHFileOperation(UINT,LPTSTR,LPCTSTR,FILEOP_FLAGS,BOOL);

int CTempDir::iCnt=0;

CTempDir::CTempDir(wchar_t* s):ffd(0),iffd(0),maxFfdBufSz(0),pthLn(0),oldId(0),plgNum(0)
{fName[0]=0;
 pthLn=MyStringCpy(path,MAX_PATH-1,s);
}

CTempDir::CTempDir():ffd(0)
{
}

CTempDir::CTempDir(int t):ffd(0),iffd(0),maxFfdBufSz(0),pthLn(0),oldId(0),plgNum(0)
{	fName[0]=0;
	if(FindRandomDir())
	{	++iCnt;
		type = (Type)t;
}	}

CTempDir::~CTempDir()
{
	Free();
}

BOOL CTempDir::FindRandomDir()
{
int i=0;pthLn=MyStringCpy(path,MAX_PATH-1,conf::tmpPath);
	if(path[pthLn-1]=='*' && path[pthLn-2]=='\\') path[--pthLn]=0;
	else if(path[pthLn-1]!='\\') {path[pthLn++]='\\';path[pthLn]=0;}
	pthLn += MyStringCpy(&path[pthLn],MAX_PATH-pthLn-1,L"Tmp");
	CreateAllDirs(path);
	CreateDirectory(path,NULL);
	AddToTempItemsLists(path);
	maxFfdBufSz=MAX_HANDLE_BUF_SZ_STEP;
	ffd=(WIN32_FIND_DATAW*)malloc(maxFfdBufSz*sizeof(WIN32_FIND_DATAW));
	return TRUE;
}

VOID CTempDir::AddSlashToPath()
{
	int l=MyStringLength(path,MAX_PATH-1);
	path[l++]='\\';
	path[l]=0;
}

HANDLE CTempDir::AddFile(WIN32_FIND_DATA *ff,BOOL bWrite)
{
/*	if(bWrite)
		h=CreateFile(ff->cFileName,GENERIC_READ,FILE_SHARE_READ,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);
	else
		h=CreateFile(ff->cFileName,GENERIC_WRITE,FILE_SHARE_WRITE,NULL,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,NULL);
	if(!h)return h;

	if(iffd<maxFfdBufSz)
	{	maxFfdBufSz+=MAX_HANDLE_BUF_SZ_STEP;
		ffd=(WIN32_FIND_DATA*)realloc(ffd,maxFfdBufSz*sizeof(HANDLE));
	}

	MyStringCpy(ffd[iffd].cFileName,MAX_PATH-1,path);
	++iffd;*/
	return 0;
}

VOID CTempDir::Free()
{	
	if(ffd)
	{	free(ffd);
		ffd=NULL;
	}
	maxFfdBufSz = 0;
	ffd=0;
	path[0]=0;
}

BOOL CTempDir::UnpackSelected(Panel *pnl)
{
int tot=pnl->GetTotSelects();
__int32 bools=0;wchar_t s[MAX_PATH];
BOOL r,bCancel=FALSE;
LPVOID plgObj=pnl->GetEntry()->GetCrntRecArjPlgObj();
int iPlgn=pnl->GetEntry()->GetCrntRecArjPlgNum();
if(!plgObj)
{ plgObj=pnl->GetArch()->GetPlgObj();
  iPlgn=pnl->GetArch()->GetPlgNum();
}
	if(tot<1)
	{	int id=pnl->GetHot();
		if(id<0)return FALSE;
		tot=pnl->GetTotItems();
		if(id>tot-1)return FALSE;
		path[pthLn]='\\';path[pthLn+1]=0;
	  BEGIN_TRY
	    MyStringCpy(s,MAX_PATH-1,pnl->GetArcItPathAndName(id));
		r=archive::plgns[iPlgn].Unpack$28(
						 pnl->GetHWND(),
						 plgObj,
						 path,
						 s,
						 &bCancel,
						 archive::UnpackCpyProgressRoutine,
						 &bools);
	  END_TRY
	  {	r=FALSE;
	  }
	  if(r)
	  {	//if(!IsFileExist(pFullPath))
		//	FullOpenIfArch(pFullPath,s);
	    //else
		{ wchar_t *pn = wcsrchr(s,'\\');
	 	  if(pn)
		  {	MyStringCpy(fName,MAX_PATH,pn+1);
		    *pn=0;
			path[pthLn++]='\\';
			pthLn+=MyStringCpy(&path[pthLn],MAX_PATH,s);
			AddToTempItemsLists(path);
		  }
		  else MyStringCpy(fName,MAX_PATH,s);
	  } }
	  path[pthLn]=0;
	  plgNum=pnl->GetArch()->GetPlgNum();
	  return r;
	}
	//else
	tot=pnl->GetTotSelects();
	if(tot<1)return FALSE;

	path[pthLn]='\\';path[pthLn+1]=0;
	for(int i=0; i<tot; i++)
	{	int id=pnl->GetSelectedItemNum(i);
		path[pthLn]='\\';path[pthLn+1]=0;
	    MyStringCpy(s,MAX_PATH-1,pnl->GetArcItPathAndName(id));
		BOOL r1=FALSE;
	   BEGIN_TRY
		r1=archive::plgns[iPlgn].Unpack$28(
							pnl->GetHWND(),
							plgObj,
							path,//pnl->GetEntry()->GetCrntTemporaryDir(),
							s,
							&bCancel,
							archive::UnpackCpyProgressRoutine,
							&bools);
	   END_TRY
	   { r1=FALSE;
       }
	   if(r1)
	   {wchar_t *pn = wcsrchr(s,'\\');
	 	if(pn)
		{	MyStringCpy(fName,MAX_PATH,pn+1);
			if(1==tot)
			{	*pn=0;
				path[pthLn++]='\\';
				pthLn+=MyStringCpy(&path[pthLn],MAX_PATH,s);
			}
			AddToTempItemsLists(path);
	    }else  MyStringCpy(fName,MAX_PATH,s);
	   }
	   if(!r1)r=FALSE;
	}
	path[pthLn]=0;
	plgNum=pnl->GetArch()->GetPlgNum();
	return r;
}

VOID CTempDir::Close()
{
	//RemoveDirectory(path);
	MySHFileOperation(FO_DELETE,path,NULL,FOF_ALLOWUNDO|FOF_SILENT|FOF_NOCONFIRMATION|FOF_NOCONFIRMMKDIR,FALSE);
	pthLn=0;
	path[0]=0;
}

static wchar_t s[MAX_PATH];
wchar_t* CTempDir::GetItem(int i)
{
WIN32_FIND_DATAW ff;
HANDLE hf = INVALID_HANDLE_VALUE;
int k=0;

	int l=MyStringCpy(s,MAX_PATH-1,path);
	if(s[l-1]=='\\'){s[l++]='*';s[l]=0;}				

	hf = MyFindFirstFileEx(s,FindExInfoStandard,&ff,FindExSearchLimitToDirectories,NULL,0);
	if(INVALID_HANDLE_VALUE==hf) return 0;
	while(FindNextFile(hf, &ff))
	{	if(!(FILE_ATTRIBUTE_DIRECTORY & ff.dwFileAttributes))//if(IsDirectory(path, &ff, FALSE))
		{	if(i==k++)
			{	MyStringCpy(&s[l-1],MAX_PATH-l-1,ff.cFileName);
	}	}	}
	FindClose(hf);
	return s;
}

wchar_t* CTempDir::GetItemPathAndName()
{	int l=MyStringCpy(s,MAX_PATH,path);
	s[l++]='\\';
	MyStringCpy(&s[l],MAX_PATH,fName);
	return s;
}

VOID CTempDir::Restore(Panel *p)
{
	if(arjStack==type)
	{	BEGIN_TRY
		archive::plgns[p->GetArch()->GetPlgNum()].Close$4(p->GetArch()->GetPlgObj());
		p->GetArch()->Open$12(GetItem(0),p->GetArch()->GetPlgNum(),2);

		archive::plgns[p->GetArch()->GetPlgNum()].Add$24(
					p->GetArch()->GetPlgObj(),
					archFilePath,
					archPath,
					L"",
					7,
					FALSE);
		archive::plgns[p->GetArch()->GetPlgNum()].Close$4(p->GetArch()->GetPlgObj());
		p->GetArch()->OpenForUnpacking$8(GetItem(0),p->GetArch()->GetPlgNum());
		END_TRY
		{	return;
		}
		//p->GetEntry()->PushToArch(p->GetEntry()->GetCrntTemporary()->GetItem(0),0);//id=0
		p->FreeMem();//p->FreeSelection();shartmas
		wchar_t *pp=wcsrchr(archPath,'\\');
		if(pp)pp=0;else archPath[0]=0;
		p->FillArchItems(archPath);
		p->ChangeSheetTabPath();
		p->AdjustScrollity();
		p->SetHot(oldId);
		p->ClrScr();
		p->Render(NULL);
	}
	Close();
}

BOOL CTempDir::TryRestore()
{
	if(arjStack==type)
	{	CArch arch;
		if(!arch.Open$12(GetItem(0),plgNum,2)) return FALSE;//conf::Dlg.crntArchvr
		BEGIN_C_TRY
		if(!archive::plgns[plgNum].Add$24(//conf::Dlg.crntArchvr
					arch.GetPlgObj(),
					archFilePath,
					archPath,
					L"",
					7,
					FALSE))return FALSE;
		archive::plgns[conf::Dlg.crntArchvr].Close$4(arch.GetPlgObj());
		END_C_TRY
		{
	}	}
	Close();
	return TRUE;
}

VOID CTempDir::AddToTempItemsLists(wchar_t *pathAndName)
{wchar_t s[MAX_PATH];
 FILE *ff = _wfopen(MyStringAddModulePath(L"Config\\tmpItems.txt"),L"r,ccs=UNICODE");
	if(ff)
	{	while(!feof(ff))
		{	fscanLineString1(ff,MAX_PATH,s);
			if(0==wcscmp(s,pathAndName))
			{	fclose(ff);
				return;
		}	}
		fclose(ff);
	}


 DWORD wrtd;DWORD RET=0x000a000d;
 HANDLE f = CreateFile(MyStringAddModulePath(L"Config\\tmpItems.txt"),GENERIC_READ|GENERIC_WRITE,
					  FILE_SHARE_READ|FILE_SHARE_WRITE,NULL,OPEN_ALWAYS,0,NULL);
	if(INVALID_HANDLE_VALUE==f)return;

	LARGE_INTEGER newFilePointer={0};
	SetFilePointerEx(f,newFilePointer,&newFilePointer,FILE_END);
	if(0==newFilePointer.QuadPart)
	{WORD unicodeFileExt=0xfeff;
	 WriteFile(f,&unicodeFileExt,2,&wrtd,NULL);
	}
	WriteFile(f,pathAndName,2*MyStringLength(pathAndName,MAX_PATH),&wrtd,NULL);
	WriteFile(f,&RET,4,&wrtd,NULL);
	CloseHandle(f);
}

VOID CTempDir::FreeTempItems()
{wchar_t s[MAX_PATH];
 FILE *f = _wfopen(MyStringAddModulePath(L"Config\\tmpItems.txt"),L"r,ccs=UNICODE");
	if(!f)return;
	while(!feof(f))
	{	fscanLineString1(f,MAX_PATH,s);
		if(0==wcscmp(s,conf::tmpPath))continue;
		if(0==s[0])continue;
		if(IsFileExist(s))
			DeleteFile(s);
	}
	fseek(f,2,SEEK_SET);int err;//fffe turibdi,unicode uchun;
	while(!feof(f))
	{	fscanLineString1(f,MAX_PATH,s);//&s[4]);
		if(0==s[0])continue;
		if(0==wcscmp(s,conf::tmpPath))continue;
		wcscat(s,L"\\");
		if(IsDirExist(s))
		{	if(!RemoveDirectory(s))
				err = GetLastError();
			//MySHFileOperation(FO_DELETE,s,NULL,FOF_SILENT|FOF_NOCONFIRMATION|FOF_NOCONFIRMMKDIR,FALSE);
			//SHFILEOPSTRUCT fo;ZeroMemory(&fo,sizeof(fo));
			//fo.wFunc = FO_DELETE;
			//int l=wcslen(s);s[l+1]=0;
			//fo.pFrom = s;
			//fo.fFlags = FOF_SILENT | FOF_NOCONFIRMATION | FOF_NOERRORUI | FOF_NOCONFIRMMKDIR;
			//err = SHFileOperation(&fo);
			//wcscat(s,L"\\");
	}	}
	fclose(f);
	DeleteFile(MyStringAddModulePath(L"Config\\tmpItems.txt"));
}