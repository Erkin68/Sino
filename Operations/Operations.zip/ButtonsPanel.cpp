#include "ButtonsPanel.h"
#include "Execution.h"
#include "CommCtrl.h"
#include "strsafe.h"
#include "shlobj.h"
#include "stdio.h"
#include "math.h"
#include "menuUtils.h"
#include "VirtualPanel.h"
#include "..\config.h"
#include "..\resource.h"
#include "MyShell\ComboToDisk.h"
#include "MyShell\Icons.h"
#include "MyShell\MyShell.h"


#define PANEL_HEIGHT			250
#define HOR_DELTA				4
#define VER_DELTA				4
#define MAX_CREATE_ANIM_TIME	3000.0f
#define MAX_HOTKEY				45//shunday kattasi boshqa buyruq;


extern HINSTANCE hInst;
extern HWND      hWnd;

extern CBToDisk btnPnlPropIconPthCB;


namespace BtnsPanel
{
ATOM BtnsPanelClass=0;
MyToolTip toolTip;
HWND    hBtnsPnlWnd=0;
DWORD   animTime,animTimeBegin;
HBRUSH  slctBrsh,bckBrsh;
POINT   cursPos;
BOOL    bNoHide=FALSE,bChangeConfig=FALSE;
HMENU   hMenu=NULL;
int		iOpenState=0,xScrll=0,yMove,scrlWidth=1000;
SCROLLINFO scrlInfo={sizeof(SCROLLINFO),0,0,0,0,0,0};

int Btn::iAllocNum=0;
int Btn::iBtns=0;
int Btn::iSelected=-1;
Btn* Btn::pBtns=NULL;
float Btn::kScl=1.0f;
float Btn::kHeight=0.46f;

int MAX_WIDTH=0;
wchar_t s[MAX_PATH];//Global o'zgaruvchi, return lar uchun;

VOID Free();
//VOID LoadBtns();
VOID Render(HDC,RECT*,int cursX=0,int cursY=0);
INT_PTR CALLBACK btnPropDlg(HWND,UINT,WPARAM,LPARAM);
BOOL AutoResetAllHotKeys(HWND);
BOOL Align(HWND,int);
BOOL CreateFolderBtn(HWND,int,int);
BOOL CreateLinkBtn(HWND,int,int);
//HWND CreateTooltip(HWND);
BOOL CreatePlgLinkBtn(HWND,int,int,int);


LRESULT CALLBACK BtnsPnlWndProc(HWND hDlg,UINT message,WPARAM wParam,LPARAM lParam)
{
	/*static int i=0;
	char ss[32];sprintf(ss,"\n %d ",i++);
	OutputDebugStringA(ss);
	OutputDebugStringA(GetWinNotifyText(message));*/
static POINT rBtnDwnMove={-1,-1};static int pbDwnMove=-1;
	switch(message)
	{
	case WM_CREATE:
		if(!Btn::pBtns)Btn::LoadAll(hDlg);
		animTimeBegin=GetTickCount();
		animTime=0;
		yMove=-PANEL_HEIGHT;//xScrll=0;
		Btn::iSelected = -1;
		SetTimer(hDlg,NULL,20,NULL);
		scrlInfo.fMask = SIF_RANGE|SIF_POS;
		scrlInfo.nMin = 0;
		scrlInfo.nMax = scrlWidth;
		if(scrlWidth>0)
			scrlInfo.nPos = -(int)(100.0f*((float)xScrll)/((float)scrlWidth));
		else scrlInfo.nPos = 0;
		SetScrollInfo(hDlg, SB_HORZ, &scrlInfo, TRUE);
		return 0;
	case WM_TIMER: RECT r;BOOL b;
		animTime+=GetTickCount()-animTimeBegin;
		b=GetWindowRect(::hWnd,&r);
		if(animTime>MAX_CREATE_ANIM_TIME)
		{	SetLayeredWindowAttributes(hDlg, 0, 238, LWA_ALPHA);
			MoveWindow(hDlg,r.left+8,r.top+30,r.right-r.left-16,(int)(PANEL_HEIGHT*Btn::kHeight),TRUE);
			yMove=0;
			KillTimer(hDlg,NULL);
			iOpenState=2;
		}
		else
		{	float k=Btn::kHeight*animTime/MAX_CREATE_ANIM_TIME;
			yMove = (int)((float)PANEL_HEIGHT*k)-PANEL_HEIGHT;
			SetLayeredWindowAttributes(hDlg, 0, (int)(140.0f*k), LWA_ALPHA);
			MoveWindow(hDlg,r.left+8,r.top+30,r.right-r.left-16,(int)((float)PANEL_HEIGHT*k),TRUE);
		}
		return 0;
	case WM_NCMOUSEMOVE: RECT rc;
		cursPos.x = (int)(short)LOWORD(lParam);
		cursPos.y = (int)(short)HIWORD(lParam);
		GetWindowRect(hDlg,&rc);
		if(cursPos.x<rc.left+4 || cursPos.x>rc.right-4 || cursPos.y>rc.bottom-3)
			Hide();//Free();
		return 0;
	case WM_SETCURSOR:
	case WM_MOUSEHOVER:
	case WM_NCMOUSELEAVE:
		GetCursorPos(&cursPos);
		GetWindowRect(hDlg,&rc);
		if(cursPos.x<rc.left+4 || cursPos.x>rc.right-4 || cursPos.y>rc.bottom-3)
			Hide();//Free();
		return 0;
	case WM_SYSKEYDOWN:
		return 0;
	case WM_MOUSEMOVE:
		cursPos.x = (int)(short)LOWORD(lParam);
		cursPos.y = (int)(short)HIWORD(lParam);
		if(pbDwnMove>-1)
		{	if(-1!=rBtnDwnMove.x && -1!=rBtnDwnMove.y)
			{	Btn::pBtns[pbDwnMove].x -= rBtnDwnMove.x - cursPos.x;
				Btn::pBtns[pbDwnMove].y -= rBtnDwnMove.y - cursPos.y;
				Render(0,0);
			}
			rBtnDwnMove=cursPos;
		}
		else Render(0,NULL,cursPos.x,cursPos.y);
		return 0;
	case WM_RBUTTONDOWN:int pb;
		cursPos.x = (int)(short)LOWORD(lParam);
		cursPos.y = (int)(short)HIWORD(lParam);
		pb=Btn::GetFromPosXY(cursPos.x,cursPos.y);
		if(pb>-1)pbDwnMove=pb;
		return 0;
	case WM_RBUTTONUP:
		rBtnDwnMove.x=rBtnDwnMove.y=-1;pbDwnMove=-1;
		bNoHide=TRUE;
		pb=Btn::GetFromPosXY(LOWORD(lParam),HIWORD(lParam));
		if(pb>-1)
			DialogBoxParam(hInst,MAKEINTRESOURCE(IDD_DIALOG_BTN_PANEL_PROP),hDlg,btnPropDlg,pb);
		else
		{	POINT pt;pt.x=LOWORD(lParam);pt.y=HIWORD(lParam);
			ClientToScreen(hDlg,&pt);
			pb=TrackPopupMenu(hMenu,TPM_RETURNCMD|TPM_LEFTALIGN|TPM_NONOTIFY,pt.x,pt.y,0,hDlg,0);
			if(IDM_BUTTONSPANELMENU_AUTORESET==pb)
			{	AutoResetAllHotKeys(hDlg);
			}
			else if(IDM_BUTTONSPANELMENU_ALIGN_HOR==pb)
				Align(hDlg,0);
			else if(IDM_BUTTONSPANELMENU_ALIGN_VER==pb)
				Align(hDlg,1);
			else if(IDM_BUTTONPANELMENU_CREATEFOLDERBUTTON==pb)
				CreateFolderBtn(hDlg,LOWORD(lParam)-16,HIWORD(lParam)-16);
			else if(IDM_BUTTONPANELMENU_CREATELINKBUTTON==pb)
				CreateLinkBtn(hDlg,LOWORD(lParam)-16,HIWORD(lParam)-16);
			else if(IDM_BUTTONPANELMENU_DELETEBUTTON==pb)
			{	Btn::DeleteAllBtns(hDlg);
				Render(0,0);
			}
			else if(IDM_BUTTONSPANELMENU_DELETEALLFOLDERBUTTONS==pb)
			{	Btn::DeleteAllFolderBtns(hDlg);
				Render(0,0);
			}
			else if(IDM_BUTTONSPANELMENU_DELETEALLLINKBUTTONS==pb)
			{	Btn::DeleteAllLinkBtns(hDlg);
				Render(0,0);
			}
			else if(IDM_CREATEPLUGINLINKBUTTON_ARCHIVE==pb)
				CreatePlgLinkBtn(hDlg,LOWORD(lParam)-16,HIWORD(lParam)-16,0);
			else if(IDM_CREATEPLUGINLINKBUTTON_IMAGEVIEW==pb)
				CreatePlgLinkBtn(hDlg,LOWORD(lParam)-16,HIWORD(lParam)-16,1);
			else if(IDM_CREATEPLUGINLINKBUTTON_MENUUTILITY==pb)
				CreatePlgLinkBtn(hDlg,LOWORD(lParam)-16,HIWORD(lParam)-16,2);
			else if(IDM_CREATEPLUGINLINKBUTTON_SEARCH==pb)
				CreatePlgLinkBtn(hDlg,LOWORD(lParam)-16,HIWORD(lParam)-16,3);
			else if(IDM_CREATEPLUGINLINKBUTTON_VIRTUALPANEL==pb)
				CreatePlgLinkBtn(hDlg,LOWORD(lParam)-16,HIWORD(lParam)-16,4);
		}
		bNoHide=FALSE;
		return 0;
	case WM_MOUSEWHEEL:SHORT shr,ctlr,shl,ctll;
		shl=GetKeyState(VK_LSHIFT);
		ctll=GetKeyState(VK_LCONTROL);
		shr=GetKeyState(VK_RSHIFT);
		ctlr=GetKeyState(VK_RCONTROL);
		short gcWheelDelta; gcWheelDelta = (short)HIWORD(wParam);
		if(abs(gcWheelDelta) >= WHEEL_DELTA)// && gucWheelScrollLines > 0)
		{	int cLineScroll = gcWheelDelta / WHEEL_DELTA;			
			if((shl & 0x8000) && (ctll & 0x8000))
			{	Btn::kScl += (cLineScroll/15.0f);
				if(Btn::kScl<0.3f)Btn::kScl=0.3f;
				else if(Btn::kScl>1.4f)Btn::kScl=1.4f;
				Render(0,NULL,0,0);
			}
			else if((shr & 0x8000) && (ctlr & 0x8000))
			{	Btn::kHeight += (cLineScroll/15.0f);
				if(Btn::kHeight<0.3f)Btn::kHeight=0.3f;
				else if(Btn::kHeight>1.4f)Btn::kHeight=1.4f;
				GetWindowRect(hWnd,&r);
				MoveWindow(hDlg,r.left+8,r.top+30,r.right-r.left-16,(int)(PANEL_HEIGHT*Btn::kHeight),TRUE);
			}
			else if(ctll & 0x8000)//control
			{	GetClientRect(hBtnsPnlWnd,&r);
				scrlWidth += (int)(cLineScroll*18.5f);
				if(scrlWidth<0)scrlWidth=0;
				else if(scrlWidth>r.right)scrlWidth = r.right;//max 2 barobar katta b-shi mumkin;

				scrlInfo.fMask = SIF_RANGE|SIF_POS;
				scrlInfo.nMin = 0;
				scrlInfo.nMax = scrlWidth;
				if(scrlWidth>0)
					scrlInfo.nPos = (int)((100.0f*xScrll)/((float)scrlWidth));
				else scrlInfo.nPos = 0;
				SetScrollInfo(hDlg, SB_HORZ, &scrlInfo, TRUE);
		}	}
		return 0;
	case WM_LBUTTONDOWN:
		cursPos.x = (int)(short)LOWORD(lParam);
		cursPos.y = (int)(short)HIWORD(lParam);
		pb=Btn::GetFromPosXY(cursPos.x,cursPos.y);
		if(pb>-1)Btn::pBtns[pb].Execute(hDlg);
		return 0;
	case WM_DESTROY:
		//ReleaseCapture();
		return 0;
	case WM_PAINT:PAINTSTRUCT ps;
		BeginPaint(hDlg,&ps);
			Render(ps.hdc,&ps.rcPaint);
		EndPaint(hDlg,&ps);
		return 0;
	case WM_HSCROLL:
		scrlInfo.fMask = SIF_ALL;
		GetScrollInfo(hDlg, SB_HORZ, &scrlInfo);
		int xOldScrlPos; xOldScrlPos = scrlInfo.nPos;
		switch (LOWORD (wParam))
		{	// user clicked left arrow
			case SB_LINELEFT: 
				scrlInfo.nPos -= 1;//lParam?lParam:1;//1
				break;
		 	// user clicked right arrow
			case SB_LINERIGHT: 
				scrlInfo.nPos += 1;//lParam?lParam:1;//1;
				break;
		 	// user clicked the scroll bar shaft left of the scroll box
			case SB_PAGELEFT:
				scrlInfo.nPos -= 1;//lParam?lParam:1;//1;
				break;
		 	// user clicked the scroll bar shaft right of the scroll box
			case SB_PAGERIGHT:
				scrlInfo.nPos += 1;//lParam?lParam:1;//1;
				break;
		 	// user dragged the scroll box
			case SB_THUMBTRACK: 
				scrlInfo.nPos = scrlInfo.nTrackPos;
				break;
		 	default :
				break;
		}
		// Set the position and then retrieve it.  Due to adjustments
		//   by Windows it may not be the same as the value set.
		scrlInfo.fMask = SIF_POS;//|SIF_RANGE;
		scrlInfo.nMax   = scrlWidth;//(nColumns>1)?nColumns:0;
		SetScrollInfo(hDlg, SB_HORZ, &scrlInfo, TRUE);
		if(scrlInfo.nMax>0)
			xScrll = - (int)(((float)scrlWidth) * ((float)scrlInfo.nPos) / ((float)scrlInfo.nMax));
		else xScrll = 0;
		Render(0,0);//InvalidateRect(wnd,NULL,TRUE);
		return 0;
	default:
		break;
	}
	return DefWindowProc(hDlg, message, wParam, lParam);
}

VOID RegisterPnlClass()
{
WNDCLASSEX wcex;
	if(!BtnsPanelClass)
	{	slctBrsh = CreateSolidBrush(RGB(0,0,255));
		bckBrsh = CreateSolidBrush(RGB(0x11,0x5e,0x71));

		wcex.cbSize = sizeof(WNDCLASSEX);
		wcex.style			= CS_HREDRAW | CS_VREDRAW | CS_DBLCLKS;
		wcex.lpfnWndProc	= BtnsPnlWndProc;
		wcex.cbClsExtra		= 0;
		wcex.cbWndExtra		= 0;
		wcex.hInstance		= hInst;
		wcex.hIcon			= NULL;
		wcex.hCursor		= LoadCursor(NULL, IDC_ARROW);
		wcex.hbrBackground	= bckBrsh;//(HBRUSH)GetStockObject(WHITE_BRUSH);
		wcex.lpszMenuName	= NULL;
		wcex.lpszClassName	= L"Sino buttons panel class #";//wchar_t btnsPanClassText[]
		wcex.hIconSm		= NULL;
		BtnsPanelClass = RegisterClassEx(&wcex);
}	}

BOOL Create()
{
	if(1!=conf::Dlg.bBtnsPanelType)
		return FALSE;

	RegisterPnlClass();

int R;RECT r;
	GetWindowRect(hWnd,&r);
	if(!hBtnsPnlWnd)
	{	hBtnsPnlWnd=CreateWindowEx(WS_EX_LAYERED,//WS_EX_TOOLWINDOW|  xarto WS_EX_TOPMOST
							(LPCWSTR)BtnsPanelClass,//btnsPanClassText,
							0,
							WS_POPUP|WS_BORDER|WS_HSCROLL,
							r.left+8,r.top+30,
							r.right-r.left-16,1,
							hWnd,
							NULL,
							hInst,
							0);
		R=GetLastError();
		SetLayeredWindowAttributes(hBtnsPnlWnd, 0, 0, LWA_ALPHA);//SetWindowLong(hWnd,GWLP_USERDATA,(LONG)this);
		R=ShowWindow(hBtnsPnlWnd,SW_SHOW);
		R=GetLastError();
		UpdateWindow(hBtnsPnlWnd);
		toolTip.Create(hInst,hBtnsPnlWnd,100,10,10,L"",1);//CreateTooltip(hBtnsPnlWnd);
		hMenu=GetSubMenu(LoadMenu(hInst,MAKEINTRESOURCE(IDM_MENU_BTN_PANEL)),0);
		MENUITEMINFO mi;mi.cbSize=sizeof(mi);mi.fMask=MIIM_STRING;mi.fType=MFT_STRING;

		//LoadString(hInst,IDS_STRINGSW_282,s,MAX_PATH-1);
		//mi.dwTypeData = s;SetMenuItemInfo(hMenu,0,TRUE,&mi);
		LoadString(hInst,IDS_STRINGSW_283,s,MAX_PATH-1);
		mi.dwTypeData = s;SetMenuItemInfo(hMenu,0,TRUE,&mi);
		LoadString(hInst,IDS_STRINGSW_284,s,MAX_PATH-1);
		mi.dwTypeData = s;SetMenuItemInfo(hMenu,1,TRUE,&mi);

		LoadString(hInst,IDS_STRINGSW_294,s,MAX_PATH-1);
		mi.dwTypeData = s;SetMenuItemInfo(hMenu,3,TRUE,&mi);

		LoadString(hInst,IDS_STRINGSW_285,s,MAX_PATH-1);
		mi.dwTypeData = s;SetMenuItemInfo(hMenu,5,TRUE,&mi);
		LoadString(hInst,IDS_STRINGSW_286,s,MAX_PATH-1);
		mi.dwTypeData = s;SetMenuItemInfo(hMenu,6,TRUE,&mi);
		LoadString(hInst,IDS_STRINGSW_287,s,MAX_PATH-1);
		mi.dwTypeData = s;SetMenuItemInfo(hMenu,7,TRUE,&mi);
		LoadString(hInst,IDS_STRINGSW_288,s,MAX_PATH-1);
		mi.dwTypeData = s;SetMenuItemInfo(hMenu,8,TRUE,&mi);
		LoadString(hInst,IDS_STRINGSW_289,s,MAX_PATH-1);
		mi.dwTypeData = s;SetMenuItemInfo(hMenu,11,TRUE,&mi);
		LoadString(hInst,IDS_STRINGSW_290,s,MAX_PATH-1);
		mi.dwTypeData = s;SetMenuItemInfo(hMenu,12,TRUE,&mi);

		HMENU hSubMenu = GetSubMenu(hMenu,3);
		LoadString(hInst,IDS_STRINGSW_158,s,MAX_PATH-1);
		mi.dwTypeData = s;SetMenuItemInfo(hSubMenu,0,TRUE,&mi);
		LoadString(hInst,IDS_STRINGSW_95,s,MAX_PATH-1);
		mi.dwTypeData = s;SetMenuItemInfo(hSubMenu,1,TRUE,&mi);
		LoadString(hInst,IDS_STRINGSW_19,s,MAX_PATH-1);
		mi.dwTypeData = s;SetMenuItemInfo(hSubMenu,2,TRUE,&mi);
		LoadString(hInst,IDS_STRINGSW_144,s,MAX_PATH-1);
		mi.dwTypeData = s;SetMenuItemInfo(hSubMenu,3,TRUE,&mi);
		LoadString(hInst,IDS_STRINGSW_292,s,MAX_PATH-1);
		mi.dwTypeData = s;SetMenuItemInfo(hSubMenu,4,TRUE,&mi);

		iOpenState = 1;
	}
	else if(0==iOpenState)
	{	animTimeBegin=GetTickCount();
		animTime=0;
		yMove=-PANEL_HEIGHT;//xScrll=0;
		SetTimer(hBtnsPnlWnd,NULL,20,NULL);
		MoveWindow(hBtnsPnlWnd,r.left+8,r.top+30,r.right-r.left-16,0,FALSE);
		iOpenState = 1;
	}
	SetFocus(hBtnsPnlWnd);
	return TRUE;
}

BOOL CreateFolderBtn(HWND hDlg,int x,int y)
{
	BROWSEINFO bi;
	bi.hwndOwner = hDlg?hDlg:hBtnsPnlWnd;
	bi.pszDisplayName = s;
	bi.lpszTitle = L"Create panel button for the link to folder ...";
	bi.ulFlags = BIF_NONEWFOLDERBUTTON|BIF_DONTGOBELOWDOMAIN|BIF_NEWDIALOGSTYLE|
		BIF_NOTRANSLATETARGETS|BIF_RETURNFSANCESTORS;
	bi.lpfn = NULL;
	LPITEMIDLIST pidlRoot;pidlRoot = NULL;
	bi.pidlRoot = pidlRoot;
	LPITEMIDLIST pidlSelected;pidlSelected = SHBrowseForFolder(&bi);
	if(pidlRoot)
		CoTaskMemFree(pidlRoot);
	if(pidlSelected)
	{	SHGetPathFromIDList(pidlSelected,s);
		CoTaskMemFree(pidlSelected);
		int numNewIt=Btn::Expand();
		if(numNewIt<0)
		{	MessageBox(hDlg,L"Err.allocating memory for:",L"Panel folder button",MB_OK);
			return FALSE;
		}
		Btn::pBtns[numNewIt].cmndType = Btn::extFolder;
		Btn::pBtns[numNewIt].x = x;
		Btn::pBtns[numNewIt].y = y;
		MyStringCpy(Btn::pBtns[numNewIt].pth,MAX_PATH-1,s);
		MyStringCpy(Btn::pBtns[numNewIt].icoPth,MAX_PATH-1,L"NULL");
		Btn::pBtns[numNewIt].hIcon=LoadIcon(hInst,MAKEINTRESOURCE(IDI_ICON_FOLDER));
		Btn::pBtns[numNewIt].resName=(LPWSTR)IDI_ICON_FOLDER;
		Btn::pBtns[numNewIt].resType=RT_ICON;
		Btn::pBtns[numNewIt].iconFileType=Btn::frExe;
		ICONINFO ii;GetIconInfo(Btn::pBtns[numNewIt].hIcon,&ii);
		Btn::pBtns[numNewIt].w = ii.xHotspot*2;
		Btn::pBtns[numNewIt].h = ii.yHotspot*2;
		Render(0,0);
	}
	bChangeConfig = TRUE;
	return TRUE;
}

BOOL CreateLinkBtn(HWND hDlg,int x,int y)
{
OPENFILENAME of;
	memset(&of,0,sizeof(OPENFILENAME));
	of.lStructSize      = sizeof(OPENFILENAME);
	of.Flags            = OFN_EXPLORER|OFN_FILEMUSTEXIST;
	of.nMaxFile			= MAX_PATH;
	of.hwndOwner        = hDlg?hDlg:hBtnsPnlWnd;
	of.lpstrFile        = s;s[0]=0;
	of.lpstrFilter = L"All files (*.*)\0*.*\0";
	of.lpstrTitle  = L"Create link button to ...";
	of.lpstrFileTitle   = L"Button configuration.";
	if(GetOpenFileName(&of))
	{	int numNewIt=Btn::Expand();
		if(numNewIt<0)
		{	MessageBox(hDlg,L"Err.allocating memory for:",L"Panel link button",MB_OK);
			return FALSE;
		}
		Btn::pBtns[numNewIt].cmndType = Btn::extLink;
		Btn::pBtns[numNewIt].x = x;
		Btn::pBtns[numNewIt].y = y;
		MyStringCpy(Btn::pBtns[numNewIt].pth,MAX_PATH-1,s);

		SHFILEINFO si;
		if(SUCCEEDED(SHGetFileInfo(of.lpstrFile,0,&si,sizeof(SHFILEINFO),SHGFI_ICONLOCATION|SHGFI_ICON|SHGFI_ICON)))
		{	MyStringCpy(Btn::pBtns[numNewIt].icoPth,MAX_PATH-1,of.lpstrFile);
			Btn::pBtns[numNewIt].hIcon=si.hIcon;
			Btn::pBtns[numNewIt].resName=(LPWSTR)si.iIcon;
			Btn::pBtns[numNewIt].resType=RT_ICON;
			ICONINFO ii;GetIconInfo(Btn::pBtns[numNewIt].hIcon,&ii);
			Btn::pBtns[numNewIt].w = ii.xHotspot*2;
			Btn::pBtns[numNewIt].h = ii.yHotspot*2;
			if(Execution::IsThisValidDllOrExeFile(of.lpstrFile))
			{	if(wcsstr(of.lpstrFile,L".exe"))
					Btn::pBtns[numNewIt].iconFileType=Btn::frExe;
				else
					Btn::pBtns[numNewIt].iconFileType=Btn::frDll;
			}
			else
			{	if(wcsstr(of.lpstrFile,L".ico"))
					Btn::pBtns[numNewIt].iconFileType=Btn::frIco;
				else if(wcsstr(of.lpstrFile,L".bmp"))
					Btn::pBtns[numNewIt].iconFileType=Btn::frBmp;
				else if(wcsstr(of.lpstrFile,L".cur"))
					Btn::pBtns[numNewIt].iconFileType=Btn::frCur;
		}	}
		else
		{	MyStringCpy(Btn::pBtns[numNewIt].icoPth,MAX_PATH-1,L"NULL");
			Btn::pBtns[numNewIt].hIcon=LoadIcon(hInst,MAKEINTRESOURCE(IDI_ICON_FILE));
			Btn::pBtns[numNewIt].resName=(LPWSTR)IDI_ICON_FILE;
			Btn::pBtns[numNewIt].resType=RT_ICON;
			Btn::pBtns[numNewIt].iconFileType=Btn::frExe;
			ICONINFO ii;GetIconInfo(Btn::pBtns[numNewIt].hIcon,&ii);
			Btn::pBtns[numNewIt].w = ii.xHotspot*2;
			Btn::pBtns[numNewIt].h = ii.yHotspot*2;
		}
		Render(0,0);
	}
	bChangeConfig = TRUE;
	return TRUE;
}

INT_PTR CALLBACK SelectDlgProc(HWND hDlg,UINT message,WPARAM wParam,LPARAM lParam)
{
	UNREFERENCED_PARAMETER(lParam);
	switch(message)
	{
	case WM_INITDIALOG:
		//Adjust to center:
		RECT rc,rcPrnt; GetWindowRect(hDlg, &rc);
		HWND prnt;prnt = GetParent(hDlg);if(!prnt)prnt=GetDesktopWindow();
		GetWindowRect(prnt,&rcPrnt);
		int width,left,height,top;

		width = rc.right - rc.left;
		left = rcPrnt.left + (rcPrnt.right-rcPrnt.left - width)/2;
		if(left>rcPrnt.right-rcPrnt.left-width)left=rcPrnt.left;

		height = rc.bottom - rc.top;
		top = rcPrnt.top + (rcPrnt.bottom-rcPrnt.top - height)/2;
		if(top>rcPrnt.bottom-rcPrnt.top-top)top=rcPrnt.top;
		MoveWindow(hDlg, left, top+20, width, height, TRUE);

		//Load language strings:
		switch(lParam)
		{	case 0:
				for(int p=0; p<archive::numPlugins; ++p)
					SendMessage(GetDlgItem(hDlg,IDC_LIST_SELECT),LB_ADDSTRING,0,(LPARAM)archive::plgns[p].extnsn);
				break;
			case 1:
				for(int p=0; p<image::numPlugins; ++p)
					SendMessage(GetDlgItem(hDlg,IDC_LIST_SELECT),LB_ADDSTRING,0,(LPARAM)image::plgns[p].descrpn);
				break;
			case 2:
				for(int p=0; p<menuUtils::numPlugins; ++p)
					SendMessage(GetDlgItem(hDlg,IDC_LIST_SELECT),LB_ADDSTRING,0,(LPARAM)menuUtils::plgns[p].descrpn);
				break;
			case 3:
				for(int p=0; p<fSearchViaF7::numPlugins; ++p)
					SendMessage(GetDlgItem(hDlg,IDC_LIST_SELECT),LB_ADDSTRING,0,(LPARAM)fSearchViaF7::plgns[p].pathAndName);
				break;
			case 4:
				for(int p=0; p<vrtlPanels::numPlugins; ++p)
					SendMessage(GetDlgItem(hDlg,IDC_LIST_SELECT),LB_ADDSTRING,0,(LPARAM)vrtlPanels::plgns[p].descrpn);
				break;
		}
		return TRUE;
	case WM_COMMAND:
		switch(LOWORD(wParam))
		{	case IDOK://overwrite
				int r;r=(int)SendMessage(GetDlgItem(hDlg,IDC_LIST_SELECT),LB_GETCURSEL,0,0);
				EndDialog(hDlg,LB_ERR==r?-1:r);
				return (INT_PTR)TRUE;
			case IDCANCEL:
				EndDialog(hDlg,-1);
				return (INT_PTR)TRUE;
		}
		break;
	}
	return (INT_PTR)FALSE;
}

BOOL CreatePlgLinkBtn(HWND hDlg,int x,int y, int plgnNum)
{
int r=(int)DialogBoxParam(hInst,MAKEINTRESOURCE(IDD_DIALOG_SELECT),hDlg,SelectDlgProc,plgnNum);
	if(r<0) return FALSE;

	OPENFILENAME of;
	memset(&of,0,sizeof(OPENFILENAME));
	of.lStructSize      = sizeof(OPENFILENAME);
	of.Flags            = OFN_EXPLORER|OFN_FILEMUSTEXIST;
	of.nMaxFile			= MAX_PATH;
	of.hwndOwner        = hDlg?hDlg:hBtnsPnlWnd;
	of.lpstrFile        = s;s[0]=0;
	of.lpstrFilter = L"(*.ico)\0*.ico\0(*.bmp)\0*.bmp\0(*.exe)\0*.exe\0(*.dll)\0*.dll\0All files\0*.*\0";
	of.lpstrTitle  = L"Get icon to plugin link ...";
	of.lpstrFileTitle   = L"Plugin link button configuration.";
	if(GetOpenFileName(&of))
	{	SHFILEINFO si;
		int numNewIt=Btn::Expand();
		if(numNewIt<0)
		{	MessageBox(hDlg,L"Err.allocating memory for:",L"Plugin link button",MB_OK);
			return FALSE;
		}
		Btn::pBtns[numNewIt].cmndType = (BtnsPanel::Btn::CmndType)(Btn::archPlgLnk+plgnNum);//imgViewPlgLnk=4,mnuUtilPlgLnk=5,schPlgLnk=6,vrtPnlPlgLnk=7
		Btn::pBtns[numNewIt].x = x;
		Btn::pBtns[numNewIt].y = y;
		Btn::pBtns[numNewIt].pth[0] = r;//number of plugin;
		if(SUCCEEDED(SHGetFileInfo(of.lpstrFile,0,&si,sizeof(SHFILEINFO),SHGFI_ICONLOCATION|SHGFI_ICON|SHGFI_ICON)))
		{	MyStringCpy(Btn::pBtns[numNewIt].icoPth,MAX_PATH-1,of.lpstrFile);
			Btn::pBtns[numNewIt].hIcon=si.hIcon;
			Btn::pBtns[numNewIt].resName=(LPWSTR)si.iIcon;
			Btn::pBtns[numNewIt].resType=RT_ICON;
			ICONINFO ii;GetIconInfo(Btn::pBtns[numNewIt].hIcon,&ii);
			Btn::pBtns[numNewIt].w = ii.xHotspot*2;
			Btn::pBtns[numNewIt].h = ii.yHotspot*2;
			if(Execution::IsThisValidDllOrExeFile(of.lpstrFile))
			{	if(wcsstr(of.lpstrFile,L".exe"))
					Btn::pBtns[numNewIt].iconFileType=Btn::frExe;
				else
					Btn::pBtns[numNewIt].iconFileType=Btn::frDll;
			}
			else
			{	if(wcsstr(of.lpstrFile,L".ico"))
					Btn::pBtns[numNewIt].iconFileType=Btn::frIco;
				else if(wcsstr(of.lpstrFile,L".bmp"))
					Btn::pBtns[numNewIt].iconFileType=Btn::frBmp;
				else if(wcsstr(of.lpstrFile,L".cur"))
					Btn::pBtns[numNewIt].iconFileType=Btn::frCur;
		}	}
		else
		{	MyStringCpy(Btn::pBtns[numNewIt].icoPth,MAX_PATH-1,L"NULL");
			Btn::pBtns[numNewIt].hIcon=LoadIcon(hInst,MAKEINTRESOURCE(IDI_ICON_FILE));
			Btn::pBtns[numNewIt].resName=(LPWSTR)IDI_ICON_FILE;
			Btn::pBtns[numNewIt].resType=RT_ICON;
			Btn::pBtns[numNewIt].iconFileType=Btn::frExe;
			ICONINFO ii;GetIconInfo(Btn::pBtns[numNewIt].hIcon,&ii);
			Btn::pBtns[numNewIt].w = ii.xHotspot*2;
			Btn::pBtns[numNewIt].h = ii.yHotspot*2;
		}
		Render(0,0);
	}
	bChangeConfig = TRUE;
	return TRUE;
}

VOID Free()
{
	if(1!=conf::Dlg.bBtnsPanelType)
		return;
	DestroyMenu(hMenu);
	toolTip.Destroy();
	if(bChangeConfig)
		Btn::SaveAll();
	if(Btn::pBtns)
	{	for(int b=0; b<Btn::iBtns; b++)
			Btn::pBtns[b].Free();
		free(Btn::pBtns);
		Btn::pBtns=NULL;
	}
	DeleteObject(slctBrsh);
	DeleteObject(bckBrsh);
	if(hBtnsPnlWnd)DestroyWindow(hBtnsPnlWnd);
	hBtnsPnlWnd=0;
}

BOOL IsPointInsideRect(POINT* pt)
{
RECT r;
	if(!iOpenState) return FALSE;
	GetWindowRect(hBtnsPnlWnd,&r);
	if(0==r.bottom-r.top)return FALSE;
	if(pt->x>r.left)
	if(pt->x<r.right)
	if(pt->y>r.top)
	if(pt->y<r.bottom)
		return TRUE;
	return FALSE;
}

VOID Hide()
{
	if(1!=conf::Dlg.bBtnsPanelType)
		return;
RECT r;
	if(!bNoHide && iOpenState)
	{	GetWindowRect(hBtnsPnlWnd,&r);
		SetLayeredWindowAttributes(hBtnsPnlWnd, 0, 0, LWA_ALPHA);
		MoveWindow(hBtnsPnlWnd,r.left,r.top,r.right-r.left,0,TRUE);
		KillTimer(hBtnsPnlWnd,NULL);
		toolTip.Hide();
		iOpenState=0;
		panel[Panel::iActivePanel].SetFocus();
}	}

/*VOID LoadBtns()
{
	Btn::iBtns=1;
	Btn::pBtns=(Btn*)malloc(sizeof(Btn)*Btn::iBtns);
	for(int i=0; i<Btn::iBtns; i++)
		Btn::pBtns[i].Btn::Btn();
	int x=0,y=0;
	Btn::pBtns[0].LoadFromResources(hInst,IDI_ICON_CD_DISK,0,&x,&y);	
	//int x=0,y=0;
	//Btn::pBtns[0].Load(&x,&y);	
}*/

VOID Render(HDC DC,RECT *RC,int cursX,int cursY)
{
	if(1!=conf::Dlg.bBtnsPanelType)
		return;
HDC dc = DC; RECT rc; 
	if(!dc)
		dc = GetDC(hBtnsPnlWnd);

	if((!cursX) && (!cursY))
	{	if(RC) rc = *RC;
		else GetClientRect(hBtnsPnlWnd,&rc);
		FillRect(dc,&rc,bckBrsh);
		for(int b=0; b<Btn::iBtns; b++)
			Btn::pBtns[b].Render(dc);
	}
	else
	{	int bSel=-1;
		for(int b=0; b<Btn::iBtns; ++b)
		{	bSel = Btn::GetFromPosXY(cursX,cursY);
			if(bSel>-1)
			if(bSel!=Btn::iSelected)
			{	Btn::pBtns[Btn::iSelected].Render(dc,-1);
				Btn::pBtns[bSel].Render(dc,TRUE);
				Btn::iSelected = bSel;
				break;
		}	}
		if(-1==bSel && Btn::iSelected>-1)
		{	Btn::pBtns[Btn::iSelected].Render(dc,-1);
			Btn::iSelected = -1;
	}	}

	if(!DC)ReleaseDC(hBtnsPnlWnd,dc);
}

Btn::Btn():cmndType(hotKey),iconFileType(frExe),iCmndNum(0),hIcon(0),
		   resType(RT_ICON),resName(&resNameW[0]),resChild(-1),dc(0)
{
	pth[0]=0;icoPth[0]=0;
	resNameW[0]=0;
}

Btn::~Btn()
{
}

wchar_t* Btn::GetHotKeyToolString(int iHotKey)
{
	int l=LoadString(hInst,IDS_STRINGSW_159,s,MAX_PATH-1);
	StringCchPrintf(&s[l],MAX_PATH-1,L"-%d:",iHotKey+1);//Hot key-%d
	l = MyStringLength(s,MAX_PATH-1);
	s[l++] = 0x0d; s[l++] = 0x0a;

	BOOL bPl=FALSE;
	if(conf::Dlg.keys[iHotKey].bAlt)
	{	l+=MyStringCpy(&s[l],MAX_PATH-1-l,L"Alt");
		bPl=TRUE;
	}
	if(conf::Dlg.keys[iHotKey].bCtrl)
	{	l+=MyStringCpy(&s[l],MAX_PATH-1-l,bPl?L" + Ctrl":L"Ctrl");
		bPl=TRUE;
	}
	if(conf::Dlg.keys[iHotKey].bShft)
	{	l+=MyStringCpy(&s[l],MAX_PATH-1-l,bPl?L" + Shft":L"Shft");
		bPl=TRUE;
	}
	if(bPl)
		l+=MyStringCpy(&s[l],MAX_PATH-1-l,L" +");
	l+=MyStringCpy(&s[l],MAX_PATH-1-l,conf::Dlg.GetCodeName(conf::Dlg.keys[iHotKey].key));
	s[l++] = 0x0d; s[l++] = 0x0a;

	switch(iHotKey)
	{	case 0:LoadString(hInst,IDS_STRINGSW_112,&s[l],MAX_PATH-1-l);break;//"Select all";break;
		case 1:LoadString(hInst,IDS_STRINGSW_168,&s[l],MAX_PATH-1-l);break;//"Create tab sheet" 168
		case 2:LoadString(hInst,IDS_STRINGSW_169,&s[l],MAX_PATH-1-l);break;//"Delete tab sheet" 169
		case 3:LoadString(hInst,IDS_STRINGSW_170,&s[l],MAX_PATH-1-l);break;//"Help"
		case 4:LoadString(hInst,IDS_STRINGSW_171,&s[l],MAX_PATH-1-l);break;//"Disk select panel 1"
		case 5:LoadString(hInst,IDS_STRINGSW_172,&s[l],MAX_PATH-1-l);break;//"Disk select panel 2"
		case 6:LoadString(hInst,IDS_STRINGSW_173,&s[l],MAX_PATH-1-l);break;//"Disk select panel 3"
		case 7:LoadString(hInst,IDS_STRINGSW_174,&s[l],MAX_PATH-1-l);break;//"Disk select panel 4"
		case 8:LoadString(hInst,IDS_STRINGSW_175,&s[l],MAX_PATH-1-l);break;//"Edit name"
		case 9:LoadString(hInst,IDS_STRINGSW_156,&s[l],MAX_PATH-1-l);break;//"View"
		case 10:LoadString(hInst,IDS_STRINGSW_157,&s[l],MAX_PATH-1-l);break;//"Edit"
		case 11:LoadString(hInst,IDS_STRINGSW_36,&s[l],MAX_PATH-1-l);break;//"Copy"
		case 12:LoadString(hInst,IDS_STRINGSW_176,&s[l],MAX_PATH-1-l);break;//"Rename-move"
		case 13:LoadString(hInst,IDS_STRINGSW_144,&s[l],MAX_PATH-1-l);break;//"Search via F7 "
		case 14:LoadString(hInst,IDS_STRINGSW_141,&s[l],MAX_PATH-1-l);break;//"Create folder"
		case 15:LoadString(hInst,IDS_STRINGSW_177,&s[l],MAX_PATH-1-l);break;//"Folder up"
		case 16:LoadString(hInst,IDS_STRINGSW_178,&s[l],MAX_PATH-1-l);break;//"Fast select"
		case 17:LoadString(hInst,IDS_STRINGSW_179,&s[l],MAX_PATH-1-l);break;//"Change hot selected"
		case 18:LoadString(hInst,IDS_STRINGSW_180,&s[l],MAX_PATH-1-l);break;//"Select items"
		case 19:LoadString(hInst,IDS_STRINGSW_181,&s[l],MAX_PATH-1-l);break;//"Page up" 2 ta knopka
		case 20:LoadString(hInst,IDS_STRINGSW_182,&s[l],MAX_PATH-1-l);break;//"Page down" 2 ta knopka
		case 21:LoadString(hInst,IDS_STRINGSW_183,&s[l],MAX_PATH-1-l);break;//"Goto end"
		case 22:LoadString(hInst,IDS_STRINGSW_184,&s[l],MAX_PATH-1-l);break;//"Goto begin"
		case 23:LoadString(hInst,IDS_STRINGSW_185,&s[l],MAX_PATH-1-l);break;//"Up"
		case 24:LoadString(hInst,IDS_STRINGSW_186,&s[l],MAX_PATH-1-l);break;//"Down"
		case 25:LoadString(hInst,IDS_STRINGSW_191,&s[l],MAX_PATH-1-l);break;//"Escape"
		case 26:LoadString(hInst,IDS_STRINGSW_2,&s[l],MAX_PATH-1-l);break;//"Exit Alt+F4"
		case 27:LoadString(hInst,IDS_STRINGSW_192,&s[l],MAX_PATH-1-l);break;//"PgUp 2-key"
		case 28:LoadString(hInst,IDS_STRINGSW_193,&s[l],MAX_PATH-1-l);break;//"PgDwn 2-key"
		case 29:LoadString(hInst,IDS_STRINGSW_67,&s[l],MAX_PATH-1-l);break;//"Properties"
		case 30:LoadString(hInst,IDS_STRINGSW_194,&s[l],MAX_PATH-1-l);break;//"Enter ���� Kirish"
		case 31:LoadString(hInst,IDS_STRINGSW_195,&s[l],MAX_PATH-1-l);break;//"Select Page Up"
		case 32:LoadString(hInst,IDS_STRINGSW_196,&s[l],MAX_PATH-1-l);break;//"Select Page Dwn"
		case 33:LoadString(hInst,IDS_STRINGSW_197,&s[l],MAX_PATH-1-l);break;//"Select Page Up,2-key"
		case 34:LoadString(hInst,IDS_STRINGSW_198,&s[l],MAX_PATH-1-l);break;//"Select Page Dwn,2-key"
		case 35:LoadString(hInst,IDS_STRINGSW_199,&s[l],MAX_PATH-1-l);break;//"Select Goto end"
		case 36:LoadString(hInst,IDS_STRINGSW_200,&s[l],MAX_PATH-1-l);break;//"Select Goto begin"
		case 37:LoadString(hInst,IDS_STRINGSW_201,&s[l],MAX_PATH-1-l);break;//"Select, Up"
		case 38:LoadString(hInst,IDS_STRINGSW_202,&s[l],MAX_PATH-1-l);break;//"Select, Down"
		case 39:LoadString(hInst,IDS_STRINGSW_203,&s[l],MAX_PATH-1-l);break;//"Delete"
		case 40:LoadString(hInst,IDS_STRINGSW_204,&s[l],MAX_PATH-1-l);break;//"Delete,2-key"
		case 41:LoadString(hInst,IDS_STRINGSW_205,&s[l],MAX_PATH-1-l);break;//"Unrestorable delete"
		case 42:LoadString(hInst,IDS_STRINGSW_206,&s[l],MAX_PATH-1-l);break;//"Unrestorable delete,2-key"
		case 43:LoadString(hInst,IDS_STRINGSW_208,&s[l],MAX_PATH-1-l);break;//"Insert to command line"
		case 44:LoadString(hInst,IDS_STRINGSW_235,&s[l],MAX_PATH-1-l);break;//"Add to archive"
		case 45:LoadString(hInst,IDS_STRINGSW_241,&s[l],MAX_PATH-1-l);break;//"Entrance to archive,&s[l]elect unpack plugin"
		case 46:LoadString(hInst,IDS_STRINGSW_361,&s[l],MAX_PATH-1-l);break;//"View with...(from plugins)"
		case 47:LoadString(hInst,IDS_STRINGSW_362,&s[l],MAX_PATH-1-l);break;//"View with...(open)"
		case 48:LoadString(hInst,IDS_STRINGSW_363,&s[l],MAX_PATH-1-l);break;//"View with...(browse)"
		case 49:LoadString(hInst,IDS_STRINGSW_364,&s[l],MAX_PATH-1-l);break;//"Edit with...(from plugins)"
		case 50:LoadString(hInst,IDS_STRINGSW_365,&s[l],MAX_PATH-1-l);break;//"Edit with...(open)"
		case 51:LoadString(hInst,IDS_STRINGSW_366,&s[l],MAX_PATH-1-l);break;//"Edit with...(browse)"
	}
	return &s[0];
}

wchar_t* Btn::GetToolString()
{
int l;s[0]=0;
	switch(cmndType)
	{	case hotKey:
			return GetHotKeyToolString(iCmndNum);
		case extFolder:
			l = MyStringCpy(s,MAX_PATH-1,L"Link to folder key:");
			s[l++] = 0x0d; s[l++] = 0x0a;
			l += MyStringCpy(&s[l],MAX_PATH-l-1,pth);
			break;
		case extLink:
			l = MyStringCpy(s,MAX_PATH-1,L"Link to file key:");
			s[l++] = 0x0d; s[l++] = 0x0a;
			l += MyStringCpy(&s[l],MAX_PATH-l-1,pth);
			break;
		case archPlgLnk:
			l = MyStringCpy(s,MAX_PATH-1,L"Link to archive plugin:");
			s[l++] = 0x0d; s[l++] = 0x0a;
			l += MyStringCpy(&s[l],MAX_PATH-l-1,archive::plgns[pth[0]].extnsn);
			break;
		case imgViewPlgLnk:
			l = MyStringCpy(s,MAX_PATH-1,L"Link to image view plugin:");
			s[l++] = 0x0d; s[l++] = 0x0a;
			l += MyStringCpy(&s[l],MAX_PATH-l-1,image::plgns[pth[0]].descrpn);
			break;
		case mnuUtilPlgLnk:
			l = MyStringCpy(s,MAX_PATH-1,L"Link to menu utility plugin:");
			s[l++] = 0x0d; s[l++] = 0x0a;
			l += MyStringCpy(&s[l],MAX_PATH-l-1,menuUtils::plgns[pth[0]].descrpn);
			break;
		case schPlgLnk:
			l = MyStringCpy(s,MAX_PATH-1,L"Link to search plugin :");
			s[l++] = 0x0d; s[l++] = 0x0a;
			l += MyStringCpy(&s[l],MAX_PATH-l-1,fSearchViaF7::plgns[pth[0]].pathAndName);
			break;
		case vrtPnlPlgLnk:
			l = MyStringCpy(s,MAX_PATH-1,L"Link to virtual panel plugin :");
			s[l++] = 0x0d; s[l++] = 0x0a;
			l += MyStringCpy(&s[l],MAX_PATH-l-1,vrtlPanels::plgns[pth[0]].descrpn);
			break;
	}
	return &s[0];
}	

int Btn::Expand()
{
	if(iBtns>iAllocNum-2)
	{	Btn *p;
		if(pBtns) p = (Btn*)realloc(pBtns,sizeof(Btn)*(iAllocNum+16));//32
		else p = (Btn*)malloc(sizeof(Btn)*(iAllocNum+16));//32
		if(p)
		{	pBtns = p;
			iAllocNum += 16;//32
			++iBtns;
			pBtns[iBtns-1].Btn::Btn();
			return iBtns-1;
		}
		else return -1;
	}
	//else
	++iBtns;
	pBtns[iBtns-1].Btn::Btn();
	return iBtns-1;
}

int Btn::GetFromPosXY(int x,int y)
{
	x -= xScrll;
	for(int b=0; b<iBtns; b++)
	{	if(x > Btn::pBtns[b].x-HOR_DELTA)
		if(x < Btn::pBtns[b].x+Btn::pBtns[b].w*kScl+HOR_DELTA)
		if(y > Btn::pBtns[b].y-VER_DELTA)
		if(y < Btn::pBtns[b].y+Btn::pBtns[b].h*kScl+VER_DELTA)
			return b;
	}
	return -1;
}	

BOOL Btn::Execute(HWND prnt)
{
int rd;
	switch(cmndType)
	{	case hotKey:
			return panel[Panel::iActivePanel].ExecuteHotKey(iCmndNum);
		case extFolder:
			return (32<(int)ShellExecute(prnt,L"explore",pth,NULL,pth,SW_SHOWNORMAL) ? TRUE:FALSE);
		case extLink:
			if(32>=(int)ShellExecute(prnt,L"open",pth,NULL,pth,SW_SHOWNORMAL))
			if(32>=(int)ShellExecute(prnt,L"edit",pth,NULL,pth,SW_SHOWNORMAL))
			{	wchar_t *p,s[MAX_PATH];MyStringCpy(s,MAX_PATH,pth);
				p=wcsrchr(s,'\\');
				if(p)
				{	*(p+1)=0;
					rd=(int)ShellExecute(prnt,L"explore",s,NULL,s,SW_SHOWNORMAL);
					return (32<rd ? TRUE:FALSE);
			}	}
			return TRUE;
		case archPlgLnk://pth[0]->Number of plg.
			conf::Dlg.crntArchvr = pth[0];
			return archive::ShowDlg(&panel[Panel::iActivePanel]);
		case imgViewPlgLnk:
			if(0<panel[Panel::iActivePanel].GetHot())
			{image::plgns[pth[0]].LoadPlugin();
			 image::plgns[pth[0]].ProcessView$4(
					panel[Panel::iActivePanel].GetFullPathAndName(panel[Panel::iActivePanel].GetHot())
											   );
			 image::plgns[pth[0]].FreePlugin();
			}
			return TRUE;
		case mnuUtilPlgLnk:
			menuUtils::Run$4(prnt,pth[0]);
			return TRUE;
		case schPlgLnk:
			if(archElem==panel[Panel::iActivePanel].GetEntry()->GetCrntRecType())
				archive::ShowSearchDlg$12(&panel[Panel::iActivePanel]);
			else if(virtualPanel==panel[Panel::iActivePanel].GetEntry()->GetCrntRecType() && 
				    vrtlPanels::plgns[panel[Panel::iActivePanel].GetiVPPlg()].ShowSearchDlg$20)
				vrtlPanels::ShowSearchDlg$20(&panel[Panel::iActivePanel]);
			else if(socketCl!=panel[Panel::iActivePanel].GetEntry()->GetCrntRecType())
				fSearchViaF7::ShowSearchDlg$8(&panel[Panel::iActivePanel]);
			return TRUE;
		case vrtPnlPlgLnk:
			vrtlPanels::AttachPanel$12(&panel[Panel::iActivePanel],pth[0],L"");//panel[Panel::iActivePanel].GetPath());
			return TRUE;
	}
	return FALSE;
}

VOID Btn::Free()
{
	if(RT_BITMAP==resType)
	{	DeleteObject(dc);
		DeleteObject(hBMP);
	} else if(RT_ICON==resType)
		DestroyIcon(hIcon);
	else if(RT_CURSOR==resType || RT_ANICURSOR==resType)
		DestroyIcon(hIcon);
}

BOOL Btn::LoadBMPFrPE(HWND prnt)
{
	HMODULE hm=NULL;
	if(!wcsstr(icoPth,L"NULL"))
	{	if(!Execution::IsThisValidDllOrExeFile(icoPth))
		{Er:MessageBox(prnt,L"This is invalid PE file for resource extracting...",icoPth,MB_OK);
			return FALSE;
		}
		hm=LoadLibrary(icoPth);
		if(!hm) goto Er;
	}
	hBMP=(HBITMAP)LoadImageW(hm?hm:hInst,resName,IMAGE_BITMAP,0,0,LR_CREATEDIBSECTION | LR_DEFAULTSIZE);
	BITMAP  bm;GetObject(hBMP, sizeof(BITMAP), &bm);
	dc = CreateCompatibleDC(NULL);
	SelectObject(dc,hBMP);
	if(hm)FreeLibrary(hm);
	return TRUE;
}

BOOL Btn::LoadFrBMP(HWND prnt)
{	hBMP=(HBITMAP)LoadImageW(0,icoPth,IMAGE_BITMAP,0,0,LR_CREATEDIBSECTION|LR_LOADFROMFILE);
	if(hBMP)
	{	BITMAP  bm;GetObject(hBMP, sizeof(BITMAP), &bm);
		dc = CreateCompatibleDC( NULL );
		SelectObject(dc,hBMP);
		return TRUE;
	}
	return FALSE;
}

BOOL Btn::LoadCursorFrPE(HWND prnt)
{	if(hIcon)DestroyIcon(hIcon);
	hIcon=NULL;
	HMODULE hm=NULL;
	if(!wcsstr(icoPth,L"NULL"))
	{	if(!Execution::IsThisValidDllOrExeFile(icoPth))
		{Er:MessageBox(prnt,L"This is invalid PE file for resource extracting...",icoPth,MB_OK);
			return FALSE;
		}		
		hm=LoadLibrary(icoPth);
		if(!hm) goto Er;
	}
	hIcon = (HICON)LoadImageW(hm?hm:hInst,resName,IMAGE_ICON,0,0,0);
	if(!hIcon)
	{	HRSRC res=FindResource(hm,(LPCWSTR)resName,RT_CURSOR);
		if(!res) res=FindResource(hm,(LPCWSTR)resName,RT_ANICURSOR);
		if(res)
		{	HGLOBAL hgl=LoadResource(hm,res);
			if(hgl)hIcon=CreateIconFromResource((PBYTE)hgl,SizeofResource(hm,res),FALSE,0x00030000);
			FreeResource(hgl);
	}	}
	if(hm)FreeLibrary(hm);
	return hIcon!=NULL;
}

BOOL Btn::LoadIconFrPE(HWND prnt)
{	if(hIcon)DestroyIcon(hIcon);
	hIcon=NULL;	
	HMODULE hm=NULL;
	if(!wcsstr(icoPth,L"NULL"))
	{	if(!Execution::IsThisValidDllOrExeFile(icoPth))
		{Er:MessageBox(prnt,L"This is invalid PE file for resource extracting...",icoPth,MB_OK);
			return FALSE;
		}		
		hm=LoadLibrary(icoPth);
		if(!hm) goto Er;
	}
	hIcon = (HICON)LoadImageW(hm?hm:hInst,resName,IMAGE_ICON,0,0,0);
	if(!hIcon)
	{	HRSRC res=FindResource(hm,resName,RT_ICON);
		if(!res) res=FindResource(hm,resName,RT_ANIICON);
		if(res)
		{	HGLOBAL hgl=LoadResource(hm,res);
			if(hgl)hIcon=CreateIconFromResource((PBYTE)hgl,SizeofResource(hm,res),TRUE,0x00030000);
			FreeResource(hgl);
		}
		else
		{	SHFILEINFO si;
			if(SUCCEEDED(SHGetFileInfo(icoPth,0,&si,sizeof(SHFILEINFO),SHGFI_ICONLOCATION|SHGFI_ICON|SHGFI_ICON)))
				hIcon=si.hIcon;
	}	}
	if(hm)FreeLibrary(hm);
	return (hIcon!=NULL);
}

BOOL Btn::LoadIconFrPECursResGroup(HWND prnt)
{	if(hIcon)DestroyIcon(hIcon);
	hIcon=NULL;
	HMODULE hm=NULL;
	if(!wcsstr(icoPth,L"NULL"))
	{	if(!Execution::IsThisValidDllOrExeFile(icoPth))
		{Er:MessageBox(prnt,L"This is invalid PE file for resource extracting...",icoPth,MB_OK);
			return FALSE;
		}
		hm=LoadLibrary(icoPth);
		if(!hm) goto Er;
	}
	HRSRC res = FindResourceW(hm,resName,RT_GROUP_CURSOR);
	HGLOBAL hgl = LoadResource(hm, res);
	LPMEMICONDIR lpGrpIconDir = (LPMEMICONDIR)LockResource(hgl);
	res = FindResource(hm,MAKEINTRESOURCE(lpGrpIconDir->idEntries[resChild].nID),RT_CURSOR);
	if(res)
	{	HGLOBAL hglchld = LoadResource(hm, res);
		if(hglchld)
		{	hIcon=CreateIconFromResource((PBYTE)hglchld,SizeofResource(hm,res),FALSE,0x00030000);
			FreeResource(hglchld);
	}	}
	FreeResource(hgl);
	if(hm)FreeLibrary(hm);
	return (hIcon!=NULL);
}

BOOL Btn::LoadIconFrPEIconResGroup(HWND prnt)
{	if(hIcon)DestroyIcon(hIcon);
	hIcon=NULL;
	HMODULE hm=NULL;
	if(!wcsstr(icoPth,L"NULL"))
	{	if(!Execution::IsThisValidDllOrExeFile(icoPth))
		{Er:MessageBox(prnt,L"This is invalid PE file for resource extracting...",icoPth,MB_OK);
			return FALSE;
		}
		hm=LoadLibrary(icoPth);
		if(!hm) goto Er;
	}
	HRSRC res = FindResourceW(hm,resName,RT_GROUP_ICON);
	HGLOBAL hgl = LoadResource(hm, res);
	LPMEMICONDIR lpGrpIconDir = (LPMEMICONDIR)LockResource(hgl);
	res = FindResource(hm,MAKEINTRESOURCE(lpGrpIconDir->idEntries[resChild].nID),RT_ICON);
	if(res)
	{	HGLOBAL hglchld = LoadResource(hm, res);
		if(hglchld)
		{	hIcon=CreateIconFromResource((PBYTE)hglchld,SizeofResource(hm,res),TRUE,0x00030000);
			FreeResource(hglchld);
	}	}
	FreeResource(hgl);
	if(hm)FreeLibrary(hm);
	return (hIcon!=NULL);
}

BOOL Btn::Load(HWND prnt)
{
	if(icoPth[0])
	{	if(RT_BITMAP==resType)
		{	if(iconFileType<frIco)
				return LoadBMPFrPE(prnt);
			else// if(iconFileType==frBmp)
				return LoadFrBMP(prnt);	
		} else if(RT_CURSOR==resType || RT_ANICURSOR==resType)
		{	if(iconFileType<frIco)
				return LoadCursorFrPE(prnt);
			else// if(iconFileType==frCur)
			{	hIcon=(HICON)LoadImageW(0,icoPth,IMAGE_ICON,0,0,LR_LOADFROMFILE);
				return (hIcon!=NULL);
		}	}
		else if(RT_ICON==resType || RT_ANIICON==resType)
		{	if(iconFileType<frIco)
				return LoadIconFrPE(prnt);
			else
			{	hIcon=(HICON)LoadImageW(0,icoPth,IMAGE_ICON,0,0,LR_LOADFROMFILE);
				return (hIcon!=NULL);
		}	}
		else if(RT_GROUP_CURSOR == resType)
			return LoadIconFrPECursResGroup(prnt);
		else if(RT_GROUP_ICON == resType)
			return LoadIconFrPEIconResGroup(prnt);
	}
	else hIcon=GetPanelEntryIcon(prnt,cmndType,iCmndNum);
	return TRUE;
}

BOOL Btn::LoadAll(HWND prnt)
{
	FILE *f=0;_wfopen_s(&f,MyStringAddModulePath(L"Config\\PnlBtns.cnf"),L"r,ccs=UNICODE");
	if(!f)return FALSE;
wchar_t st[512],*p;

	int l=fscanLineString1(f,512,st);
	p=wcsstr(st,L"Params:");
	if(!p)
	{Er0:MessageBox(prnt,L"Err.loading panel btn.conf.file",L"In \"Params:\" string reading.",MB_OK);
		fclose(f);
		return FALSE;
	}p=&p[7];if(' '!=*p) goto Er0;
	kScl = (float)_wtof(p+1);
	p = wcschr(p+1,' ');
	if(!p) goto Er0;
	kHeight = (float)_wtof(p+1);
	p = wcschr(p+1,' ');
	if(!p) goto Er0;
	scrlWidth = _wtoi(p+1);
	p = wcschr(p+1,' ');
	if(!p) goto Er0;
	xScrll = _wtoi(p+1);

	l=fscanLineString1(f,512,st);
	p=wcsstr(st,L"Total:");
	if(!p)
	{Er:MessageBox(prnt,L"Err.loading panel btn.conf.file",L"In \"Total:\" string reading.",MB_OK);
		fclose(f);
		return FALSE;
	}p=&p[6];if(' '!=*p) goto Er;
	int i=_wtoi(p+1);
	if(i>0)iBtns=i;
	if(pBtns) pBtns = (Btn*)realloc(pBtns,iBtns*sizeof(Btn));
	else pBtns = (Btn*)malloc(iBtns*sizeof(Btn));
	iAllocNum = iBtns;

	for(i=0; i<iBtns; i++)
	{	pBtns[i].Btn::Btn();		
		l=fscanLineString1(f,512,st);
		int ib=_wtoi(st)-1;
		if(ib!=i)
		{	MessageBox(prnt,L"Err.loading panel btn.conf.file",L"In counting button.",MB_OK);
			fclose(f);return FALSE;
		}
		p=wcsstr(st,L"type:");
		if(!p){Er1:MessageBox(prnt,L"Err.loading panel btn.conf.file",L"In \"type:\" string searching.",MB_OK);fclose(f);return FALSE;}
		if(' '!=*(p+5))goto Er1;
		pBtns[i].cmndType=(Btn::CmndType)_wtoi(p+6);

		if(pBtns[i].cmndType>2)
		{	p=wcsstr(st,L"plgn:");
			if(!p){Er11:MessageBox(prnt,L"Err.loading panel btn.conf.file",L"In \"plgn:\" string searching.",MB_OK);fclose(f);return FALSE;}
			if(' '!=*(p+5))goto Er11;
			pBtns[i].pth[0]=(Btn::CmndType)_wtoi(p+6);
		}

		p=wcsstr(st,L"cmndNum:");
		if(!p){Er2:MessageBox(prnt,L"Err.loading panel btn.conf.file",L"In \"cmndNum:\" string searching.",MB_OK);fclose(f);return FALSE;}
		if(' '!=*(p+8))goto Er2;
		pBtns[i].iCmndNum=_wtoi(p+9);

		p=wcsstr(st,L"pos:");//if(!p){Er3:MessageBox(prnt,L"Err.loading panel btn.conf.file",L"In \"pos:(x)\" string searching.",MB_OK);fclose(f);return FALSE;}
		if(p && ' '==*(p+4))
			pBtns[i].x=_wtoi(p+5);

		p=wcschr(p+6,' ');//if(!p){Er4:MessageBox(prnt,L"Err.loading panel btn.conf.file",L"In \"pos:(y)\" string searching.",MB_OK);fclose(f);return FALSE;}
		if(p && ' '==*p)
			pBtns[i].y=_wtoi(p+1);

		p=wcsstr(st,L"size:");//if(!p){Er7:MessageBox(prnt,L"Err.loading panel btn.conf.file",L"In \"size:(w)\" string searching.",MB_OK);fclose(f);return FALSE;}
		if(p && ' '==*(p+5))
			pBtns[i].w=_wtoi(p+6);

		p=wcschr(p+6,' ');//if(!p){Er8:MessageBox(prnt,L"Err.loading panel btn.conf.file",L"In \"size:(h)\" string searching.",MB_OK);fclose(f);return FALSE;}
		if(p && ' '==*p)
			pBtns[i].h=_wtoi(p+1);

		p=wcsstr(st,L"path:");
		if(p && ' '==*(p+5))
		{	MyStringCpy(pBtns[i].pth,MAX_PATH-1,p+6);
			p=wcsrchr(pBtns[i].pth,'\\');
			if(p)
			{	p=wcschr(p,' ');
				if(p)*p=0;
		}	}

		p=wcsstr(st,L"iconType:");
		if(p && ' '==*(p+9))
			pBtns[i].iconFileType=(Btn::IconFileType)_wtoi(p+10);

		p=wcsstr(st,L"iconPath:");
		if(p && ' '==*(p+9))
		{	MyStringCpy(pBtns[i].icoPth,MAX_PATH-1,p+10);
			p=wcsrchr(pBtns[i].icoPth,'\\');
			if(p)
			{	p=wcschr(p,' ');
				if(p)*p=0;
		}	}

		p=wcsstr(st,L"resType:");
		if(p && ' '==*(p+8))
			pBtns[i].resType=(LPTSTR)_wtoi(p+9);

		p=wcsstr(st,L"resName:");
		if(p && ' '==*(p+8))
		{	int iResName=_wtoi(p+9);
			if(!iResName)
			{	MyStringCpy(pBtns[i].resName,MAX_PATH-1,p+9);
				p=wcschr(pBtns[i].icoPth,' ');
				if(p)*p=0;
			}
			else pBtns[i].resName = (LPWSTR)iResName;
		}

		p=wcsstr(st,L"resChld:");
		if(p && ' '==*(p+8))
			pBtns[i].resChild=_wtoi(p+9);

		pBtns[i].Load(prnt);
	}
	fclose(f);
	return TRUE;
}

BOOL Btn::SaveAll()
{
	if(!iBtns) return FALSE;
	FILE *f=0;_wfopen_s(&f,MyStringAddModulePath(L"Config\\PnlBtns.cnf"),L"w,ccs=UNICODE");
	if(!f)return FALSE;

	fwprintf(f,L"Params: %.4f %.4f %d %d",kScl,kHeight,scrlWidth,xScrll);
	fwprintf(f,L"\nTotal: %d",iBtns);
	for(int b=0; b<iBtns; b++)
	{	fwprintf(f,L"\n%d type: %d ",b+1,pBtns[b].cmndType);
		if(pBtns[b].cmndType>2)
			fwprintf(f,L"plgn: %d ",pBtns[b].pth[0]);
		fwprintf(f,L"cmndNum: %d ",pBtns[b].iCmndNum);
		fwprintf(f,L" pos: %d %d size: %d %d",pBtns[b].x,pBtns[b].y,pBtns[b].w,pBtns[b].h);
		if(pBtns[b].cmndType<3 && pBtns[b].pth[0])
			fwprintf(f,L" path: %s",pBtns[b].pth);
		if(pBtns[b].icoPth[0])
		{	fwprintf(f,L" iconType: %d",pBtns[b].iconFileType);
			if(pBtns[b].icoPth[0])
				fwprintf(f,L" iconPath: %s", pBtns[b].icoPth);
			fwprintf(f,L" resType: %d", (int)pBtns[b].resType);
			if((UINT)pBtns[b].resName<65536)
				fwprintf(f,L" resName: %d",pBtns[b].resName);
			else
				fwprintf(f,L" resName: %s",pBtns[b].resName[0]?pBtns[b].resName:L"NULL");
			if(pBtns[b].resChild>-1)
				fwprintf(f,L" resChld: %d",pBtns[b].resChild);
	}	}
	fclose(f);
	return TRUE;
}

VOID Btn::Render(HDC d,int bRndrBck)
{
	if(RT_BITMAP==resType)
	{	if(0!=bRndrBck)
		{	RECT r={x+xScrll-HOR_DELTA,
					y+yMove-VER_DELTA,
					(LONG)(x+xScrll+w*kScl+HOR_DELTA),
					(LONG)(y+yMove+h*kScl+VER_DELTA)};
			FillRect(d,&r,bRndrBck==-1?bckBrsh:slctBrsh);
			StretchBlt(d,x+xScrll,y+yMove,(int)(kScl*w),(int)(kScl*h),dc,0,0,w,h,SRCCOPY);
			if(-1==bRndrBck) toolTip.Hide();
			else toolTip.TrackPosition(cursPos.x+20,cursPos.y-10,GetToolString());
		}
		else
		{	StretchBlt(d,x+xScrll,y+yMove,(int)(kScl*w),(int)(kScl*h),dc,0,0,w,h,SRCCOPY);
			toolTip.Hide();
	}	}
	else
	{	if(0!=bRndrBck)
		{	RECT r={x+xScrll-HOR_DELTA,
					y+yMove-VER_DELTA,
					(LONG)(x+xScrll+w*kScl+HOR_DELTA),
					(LONG)(y+yMove+h*kScl+VER_DELTA)};
			FillRect(d,&r,bRndrBck==-1?bckBrsh:slctBrsh);
			DrawIconEx(d,x+xScrll,y+yMove,hIcon,(int)(kScl*w),(int)(kScl*h),0,0,DI_NORMAL);
			if(-1==bRndrBck) toolTip.Hide();
			else toolTip.TrackPosition(cursPos.x+20,cursPos.y-10,GetToolString());
		}
		else
		{	DrawIconEx(d,x+xScrll,y+yMove,hIcon,(int)(kScl*w),(int)(kScl*h),0,0,DI_NORMAL);
			toolTip.Hide();
}	}	}

VOID Btn::Delete(HWND hDlg)
{
int iWithoutThis=0;
	Btn* pNewBtns = (Btn*)malloc(sizeof(Btn)*iAllocNum);
	for(int b=0; b<iBtns; b++)
	{	if(this!=&pBtns[b])
		{	pNewBtns[iWithoutThis] = pBtns[b];
			++iWithoutThis;
	}	}
	if(RT_BITMAP==resType)
	{	DeleteObject(dc);
		DeleteObject(hBMP);
	}else
		DestroyIcon(hIcon);
	free(pBtns);pBtns=pNewBtns;
	iBtns=iWithoutThis;
}

VOID Btn::DeleteAllBtns(HWND hDlg)
{
	for(int b=0; b<iBtns; b++)
	{	if(RT_BITMAP==pBtns[b].resType)
		{	DeleteObject(pBtns[b].dc);
			DeleteObject(pBtns[b].hBMP);
		}else
			DestroyIcon(pBtns[b].hIcon);		
	}
	free(pBtns);pBtns=NULL;
	iAllocNum=iBtns=0;
	bChangeConfig = TRUE;
}

VOID Btn::DeleteAllFolderBtns(HWND hDlg)
{
int iWithoutFldBtns=0;
	Btn* pNewBtns = (Btn*)malloc(sizeof(Btn)*iAllocNum);
	for(int b=0; b<iBtns; b++)
	{	if(extFolder!=pBtns[b].cmndType)
		{	pNewBtns[iWithoutFldBtns] = pBtns[b];
			++iWithoutFldBtns;
	}	}
	for(int b=0; b<iBtns; b++)
	{	if(RT_BITMAP==pBtns[b].resType)
		{	DeleteObject(pBtns[b].dc);
			DeleteObject(pBtns[b].hBMP);
		}else
			DestroyIcon(pBtns[b].hIcon);		
	}
	free(pBtns);pBtns=pNewBtns;
	iBtns=iWithoutFldBtns;
	bChangeConfig = TRUE;
}

VOID Btn::DeleteAllLinkBtns(HWND hDlg)
{
int iWithoutLnkBtns=0;
	Btn* pNewBtns = (Btn*)malloc(sizeof(Btn)*iAllocNum);
	for(int b=0; b<iBtns; b++)
	{	if(extFolder!=pBtns[b].cmndType)
		{	pNewBtns[iWithoutLnkBtns] = pBtns[b];
			++iWithoutLnkBtns;
	}	}
	for(int b=0; b<iBtns; b++)
	{	if(RT_BITMAP==pBtns[b].resType)
		{	DeleteObject(pBtns[b].dc);
			DeleteObject(pBtns[b].hBMP);
		}else
			DestroyIcon(pBtns[b].hIcon);		
	}
	free(pBtns);pBtns=pNewBtns;
	iBtns=iWithoutLnkBtns;
}

/*HWND CreateTooltip(HWND hwnd)
{
INITCOMMONCONTROLSEX icex;TOOLINFOW ti;int r;

    icex.dwSize = sizeof(icex);
    icex.dwICC  = ICC_BAR_CLASSES;
    if(!InitCommonControlsEx(&icex))return 0;
	HWND hwndTip=CreateWindowEx(0, TOOLTIPS_CLASS, NULL,
								TTS_ALWAYSTIP|TTS_BALLOON,
								CW_USEDEFAULT, CW_USEDEFAULT,
								CW_USEDEFAULT, CW_USEDEFAULT,
								hwnd, NULL, hInst,NULL);
	SetWindowPos(hwndTip,HWND_TOPMOST,0,0,0,0,SWP_NOMOVE|SWP_NOSIZE|SWP_NOACTIVATE);
	ZeroMemory(&ti, sizeof(TOOLINFOW) );
	ti.cbSize = sizeof(TOOLINFOW) - sizeof(void*);
	ti.uFlags =  TTF_ABSOLUTE|TTF_SUBCLASS|TTF_IDISHWND|TTF_TRANSPARENT;
	ti.hwnd = hwnd;
	ti.hinst = hInst;
	ti.uId = (UINT_PTR)hwnd;
	ti.lpszText = L"5454545";
	GetClientRect(hwnd, &ti.rect); 
	if(!SendMessage(hwndTip,TTM_ADDTOOL,0,(LPARAM)&ti))
		r=GetLastError();
	SendMessage(hwndTip,TTM_TRACKACTIVATE,TRUE,0);
	return hwndTip;
}*/

INT_PTR CALLBACK btnPropDlg(HWND hDlg,UINT message,WPARAM wParam,LPARAM lParam)
{
int t;
wchar_t str[MAX_PATH];
BROWSEINFO bi;
OPENFILENAMEW of;
static HFONT hf=0;//obshiy hf, dinamik uchun emas:
static HBRUSH br=0;
static HBRUSH brHtBk=0;

	UNREFERENCED_PARAMETER(lParam);
	switch(message)
	{
	case WM_INITDIALOG:
		//Adjust to center:
		RECT rc;GetWindowRect(hDlg, &rc);
		int width,height;
		width = rc.right - rc.left;
		height = rc.bottom - rc.top;
		rc.left = Btn::pBtns[((int)lParam)].x+Btn::pBtns[((int)lParam)].w/2;
		rc.top = Btn::pBtns[((int)lParam)].y;//+Btn::pBtns[((int)lParam)].h/2;
		ClientToScreen(hWnd,(LPPOINT)&rc);
		MoveWindow(hDlg, rc.left, rc.top, width, height, TRUE);
		SetWindowLongPtr(hDlg,GWLP_USERDATA,lParam);

		//Load language strings:
		LoadString(hInst,IDS_STRINGSW_277,s,MAX_PATH);
		SetWindowText(hDlg,s);
		LoadString(hInst,IDS_STRINGSW_155,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_STATIC1,s);
		LoadString(hInst,IDS_STRINGSW_45,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_BUTTON_BROWSE,s);
		LoadString(hInst,IDS_STRINGSW_278,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_STATIC2,s);
		LoadString(hInst,IDS_STRINGSW_279,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_STATIC3,s);
		LoadString(hInst,IDS_STRINGSW_280,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_BUTTON_ICON_FILE_BROWSE,s);
		LoadString(hInst,IDS_STRINGSW_281,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_STATIC4,s);
		LoadString(hInst,IDS_STRINGSW_203,s,MAX_PATH);
		SetDlgItemText(hDlg,IDC_BUTTON_DELETE,s);
		LoadString(hInst,IDS_STRINGSW_41,s,MAX_PATH);
		SetDlgItemText(hDlg,IDOK,s);
		
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_ICON_TYPE),CB_ADDSTRING,0,(LPARAM)L"icon resource from \"exe\"-module");
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_ICON_TYPE),CB_ADDSTRING,0,(LPARAM)L"icon resource from \"dll\"-module");
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_ICON_TYPE),CB_ADDSTRING,0,(LPARAM)L"icon(*.ico) file");
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_ICON_TYPE),CB_ADDSTRING,0,(LPARAM)L"bitmap(*.bmp) file");
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_ICON_TYPE),CB_SETCURSEL,0,0);
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_ICON_TYPE),CB_SETCURSEL,Btn::pBtns[lParam].iconFileType,0);

		SendMessage(GetDlgItem(hDlg,IDC_COMBO_CMND_TYPE),CB_ADDSTRING,0,(LPARAM)L"hot key");
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_CMND_TYPE),CB_ADDSTRING,0,(LPARAM)L"extern folder link");
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_CMND_TYPE),CB_ADDSTRING,0,(LPARAM)L"extern call link");
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_CMND_TYPE),CB_SETCURSEL,0,0);
	
		for(int i=0; i<MAX_HOTKEY; i++)
			SendMessage(GetDlgItem(hDlg,IDC_COMBO_HOT_KEY),CB_ADDSTRING,0,(LPARAM)Btn::GetHotKeyToolString(i));//"Select all";
		SendMessage(GetDlgItem(hDlg,IDC_COMBO_HOT_KEY),CB_SETCURSEL,0,0);

		StringCchPrintfW(str,MAX_PATH-1,L"%d-button.Position: %d-%d;Size: %d-%d.",1+lParam,Btn::pBtns[lParam].x,Btn::pBtns[lParam].y,Btn::pBtns[lParam].w,Btn::pBtns[lParam].h);
		SetDlgItemText(hDlg,IDC_EDIT_INFO,str);

		SetDlgItemText(hDlg,IDC_EDIT_OPERATION,Btn::pBtns[lParam].GetToolString());
		btnPnlPropIconPthCB.Read(btnPnlPropIconPthCBPATH,GetDlgItem(hDlg,IDC_COMBO_ICON_TYPE),40,128);
		btnPnlPropPthCB.Read(btnPnlPropPthCBPATH,GetDlgItem(hDlg,IDC_COMBO_BROWSE),40,128);
				
		SendMessage(hDlg,WM_USER+1,0,0);
		if(!lParam) return TRUE;//Agar confDlg dan chaqirilgan b-sa,rang-shriftlarini o'zgartirish uchun;
		return TRUE;
	case WM_CTLCOLORSTATIC:
	case WM_CTLCOLORDLG:HDC dc;dc = (HDC)wParam;
		//SetTextColor(dc,conf::Dlg.dlgRGBs[1][1]);
		//SetBkColor(dc,conf::Dlg.dlgRGBs[1][2]);
		return (INT_PTR)br;
	case WM_CTLCOLOREDIT:dc = (HDC)wParam;
		//SetTextColor(dc,conf::Dlg.dlgRGBs[1][1]);
		//SetBkColor(dc,conf::Dlg.dlgRGBs[1][2]);
		return (INT_PTR)br;
	case WM_CTLCOLORBTN:dc=(HDC)wParam;
		//SetTextColor(dc,conf::Dlg.dlgRGBs[1][4]);
		//SetBkColor(dc,conf::Dlg.dlgRGBs[1][5]);
		return (INT_PTR)brHtBk;
	case WM_DRAWITEM://WM_CTLCOLORBTN dagi knopkalar:
		LPDRAWITEMSTRUCT lpdis;lpdis = (LPDRAWITEMSTRUCT)lParam;
		GetWindowText(lpdis->hwndItem,str,64);
		UINT uStyle;uStyle = DFCS_BUTTONPUSH;
		rc = lpdis->rcItem;
		if(lpdis->itemState & ODS_SELECTED)
		{	uStyle |= DFCS_PUSHED;
			rc.left+=2;rc.top+=2;
		}
		DrawFrameControl(lpdis->hDC, &lpdis->rcItem, DFC_BUTTON, uStyle);
		if(lpdis->itemState & ODS_SELECTED)
			{rc.left+=1;rc.top+=1;rc.bottom-=2;rc.right-=3;}
		else
			{rc.left+=1;rc.top+=2;rc.bottom-=3;rc.right-=3;}
		FillRect(lpdis->hDC,&rc,brHtBk);//DrawText(lpdis->hDC,"                                                  ",50,&rc,DT_SINGLELINE|DT_VCENTER|DT_INTERNAL|DT_LEFT);
		if(lpdis->itemState & ODS_SELECTED)
			{rc.left-=1;rc.top-=1;rc.bottom+=3;rc.right+=3;}
		else
			{rc.left-=1;rc.top-=2;rc.bottom+=2;rc.right+=3;}
		DrawText(lpdis->hDC,s,MyStringLength(str,64),&rc,DT_SINGLELINE|DT_VCENTER|DT_CENTER);
		return TRUE;
	case WM_USER+1://hf obshiy uchun, dinamik o'zgartirish uchun emas:
		hf = CreateFontIndirect(&conf::Dlg.dlgFnts[1]);
		br = CreateSolidBrush(conf::Dlg.dlgRGBs[1][0]);
		brHtBk = CreateSolidBrush(conf::Dlg.dlgRGBs[1][5]);
		SendMessage(GetDlgItem(hDlg,IDC_STATIC),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_STATIC5),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_BUTTON_TO_BACKGROUND_COPY_QUEUE),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDC_BUTTON_STOP),WM_SETFONT,(WPARAM)hf,TRUE);
		SendMessage(GetDlgItem(hDlg,IDCANCEL),WM_SETFONT,(WPARAM)hf,TRUE);
		return 0;//GWLP_USERDATA
	case WM_DESTROY:
		DeleteObject(hf);
		DeleteObject(br);
		DeleteObject(brHtBk);
		btnPnlPropIconPthCB.Save(btnPnlPropIconPthCBPATH,GetDlgItem(hDlg,IDC_COMBO_ICON_TYPE),128);
		btnPnlPropPthCB.Save(btnPnlPropPthCBPATH,GetDlgItem(hDlg,IDC_COMBO_BROWSE),128);
		bChangeConfig = TRUE;
		return 0;
	case WM_COMMAND:
		switch(LOWORD(wParam))
		{	case IDOK:
			case IDCANCEL:
				EndDialog(hDlg,0);//DestroyWindow(hDlg);
				return 0;
			case IDC_COMBO_CMND_TYPE:
				t=(int)GetWindowLongPtr(hDlg,GWLP_USERDATA);
				Btn::pBtns[t].cmndType=(Btn::CmndType)SendMessage(GetDlgItem(hDlg,IDC_COMBO_CMND_TYPE),CB_GETCURSEL,0,0);
				return 0;
			case IDC_COMBO_ICON_TYPE:
				t=(int)GetWindowLongPtr(hDlg,GWLP_USERDATA);
				Btn::pBtns[t].iconFileType=(Btn::IconFileType)SendMessage(GetDlgItem(hDlg,IDC_COMBO_ICON_TYPE),CB_GETCURSEL,0,0);
				return 0;
			case IDC_COMBO_HOT_KEY:
				t=(int)GetWindowLongPtr(hDlg,GWLP_USERDATA);
				Btn::pBtns[t].iCmndNum=(int)SendMessage(GetDlgItem(hDlg,IDC_COMBO_HOT_KEY),CB_GETCURSEL,0,0);
				return 0;
			case IDC_BUTTON_BROWSE:
				t=(int)GetWindowLongPtr(hDlg,GWLP_USERDATA);
				if(0==Btn::pBtns[t].cmndType)//folder:
				{	bi.hwndOwner = hDlg;bi.lpfn = NULL;
					bi.pszDisplayName = str;bi.lpszTitle = L"Allocate folder location ...";
					bi.ulFlags = BIF_NONEWFOLDERBUTTON|BIF_DONTGOBELOWDOMAIN|BIF_NEWDIALOGSTYLE|
								 BIF_NOTRANSLATETARGETS|BIF_RETURNFSANCESTORS;
					LPITEMIDLIST pidlRoot;pidlRoot = NULL; bi.pidlRoot = pidlRoot;
					LPITEMIDLIST pidlSelected;pidlSelected = SHBrowseForFolder(&bi);
					if(pidlRoot)CoTaskMemFree(pidlRoot);
					if(pidlSelected)
					{	SHGetPathFromIDList(pidlSelected,str);
						MyStringCpy(Btn::pBtns[GetWindowLongPtr(hDlg,GWLP_USERDATA)].pth,MAX_PATH-1,str);
						CBToDisk::AddToCB(GetDlgItem(hDlg,IDC_COMBO_BROWSE),str,TRUE);
						CoTaskMemFree(pidlSelected);
				}	}
				else
				{	memset(&of,0,sizeof(OPENFILENAME));
					of.lStructSize      = sizeof(OPENFILENAME);
					of.Flags            = OFN_EXPLORER|OFN_FILEMUSTEXIST;
					of.nMaxFile			= MAX_PATH;
					of.hwndOwner        = hDlg;
					of.lpstrFilter = L"All files (*.*)\0*.*\0";
					of.lpstrTitle  = L"Allocate file.";
					of.lpstrFileTitle   = L"Button configuration.";
					if(GetOpenFileName(&of))
					{	CBToDisk::AddToCB(GetDlgItem(hDlg,IDC_COMBO_BROWSE),str);
						MyStringCpy(Btn::pBtns[GetWindowLongPtr(hDlg,GWLP_USERDATA)].pth,MAX_PATH-1,str);
				}	}
				return 0;
			case IDC_BUTTON_ICON_FILE_BROWSE:LPWSTR Name;
				t=(int)GetWindowLongPtr(hDlg,GWLP_USERDATA);
				Name=&Btn::pBtns[t].icoPth[0];
				if(GetImgResFrPE(hDlg,&Name,&Btn::pBtns[t].resType,&Btn::pBtns[t].resName,&Btn::pBtns[t].resChild))
				{	CBToDisk::AddToCB(GetDlgItem(hDlg,IDC_COMBO_ICON_BROWSE),Name,TRUE);
					str[0]=0;int l=0;
					if(Btn::pBtns[t].resType==RT_ANICURSOR)l+=MyStringCpy(str,MAX_PATH-1,L"RT_ANICURSOR ");
					else if(Btn::pBtns[t].resType==RT_ANIICON)l+=MyStringCpy(str,MAX_PATH-1,L"RT_ANIICON ");
					else if(Btn::pBtns[t].resType==RT_BITMAP)l+=MyStringCpy(str,MAX_PATH-1,L"RT_BITMAP ");
					else if(Btn::pBtns[t].resType==RT_CURSOR)l+=MyStringCpy(str,MAX_PATH-1,L"RT_CURSOR ");
					else if(Btn::pBtns[t].resType==RT_GROUP_CURSOR)l+=MyStringCpy(str,MAX_PATH-1,L"RT_GROUP_CURSOR ");
					else if(Btn::pBtns[t].resType==RT_GROUP_ICON)l+=MyStringCpy(str,MAX_PATH-1,L"RT_GROUP_ICON ");
					else if(Btn::pBtns[t].resType==RT_ICON)l+=MyStringCpy(str,MAX_PATH-1,L"RT_ICON ");
					if((UINT)Btn::pBtns[t].resName<65536)
					{	StringCchPrintfW(&str[l],MAX_PATH-1,L"%d",Btn::pBtns[t].resName);
						l=MyStringLength(str,MAX_PATH-1);
					}else l+=MyStringCpy(&str[l],MAX_PATH-1-l,Btn::pBtns[t].resName);
					if(Btn::pBtns[t].resType==RT_GROUP_CURSOR || Btn::pBtns[t].resType==RT_GROUP_ICON)
						StringCchPrintfW(&str[l],MAX_PATH-1,L" � in grp. %d",Btn::pBtns[t].resChild);
					SetDlgItemText(hDlg,IDC_EDIT_INFO,str);
					if(RT_BITMAP==Btn::pBtns[t].resType)
					{	DeleteObject(Btn::pBtns[t].dc);
						DeleteObject(Btn::pBtns[t].hBMP);
					} else if(Btn::pBtns[t].hIcon) DestroyIcon(Btn::pBtns[t].hIcon);
					Btn::pBtns[t].Load(hDlg);
				}
				return 0;
			case IDC_BUTTON_DELETE:
				t=(int)GetWindowLongPtr(hDlg,GWLP_USERDATA);
				Btn::pBtns[t].Delete(hDlg);
				Render(0,0);
				EndDialog(hDlg,0);
				return 0;
		}
		break;
	}
	return (INT_PTR)FALSE;
}

BOOL Align(HWND hDlg,int horVer)
{
RECT r;GetWindowRect(hWnd,&r);
	r.right=r.right-r.left-16;//r.left=0;
	r.bottom=(int)((float)PANEL_HEIGHT*Btn::kHeight);//r.top=0;
//1. Eng o'ngdagisini topamiz:
	int minW=HOR_DELTA,minH=HOR_DELTA;
	for(int i=0; i<Btn::iBtns; i++)
	{	if(Btn::pBtns[i].w>minW) minW=(int)(Btn::pBtns[i].w*Btn::kScl);
		if(Btn::pBtns[i].h>minH) minH=(int)(Btn::pBtns[i].h*Btn::kScl);
	}
//2.Qaysi btn bor-yo'qligiga qarab:
	int x=HOR_DELTA,y=VER_DELTA;
	for(int i=0; i<Btn::iBtns; i++)
	{	Btn::pBtns[i].x = x;
		Btn::pBtns[i].y = y;
		if(0==horVer)//hor
		{	x += minW+HOR_DELTA;
			if(x>r.right+scrlWidth-minW)
			{	x=0;
				y += minH+VER_DELTA;
		}	}
		else//ver
		{	y += minH+VER_DELTA;
			if(y>r.bottom-minH)
			{	y=0;
				x += minW+HOR_DELTA;
	}	}	}
	Render(0,0);
	bChangeConfig = TRUE;
	return TRUE;
}

BOOL AutoResetAllHotKeys(HWND hDlg)
{
//1. Eng o'ngdagisini topamiz:
	int minX=HOR_DELTA,width=48,y=0;
	for(int i=0; i<Btn::iBtns; i++)
	{	if(Btn::pBtns[i].x>minX) minX=Btn::pBtns[i].x;
		if(Btn::pBtns[i].w>width+HOR_DELTA) width=Btn::pBtns[i].w+HOR_DELTA;
	}
	if(minX>HOR_DELTA)
		minX += width;
//2.Qaysi btn bor-yo'qligiga qarab:
	for(int k=0; k<MAX_KEYS; k++)
	{	for(int i=0; i<Btn::iBtns; i++)
		{	if(Btn::hotKey==Btn::pBtns[i].cmndType)
			if(k==Btn::pBtns[i].iCmndNum)
				goto ToNextKey;
		}
		int numNewIt=Btn::Expand();
		if(numNewIt<0)
		{	MessageBox(hDlg,L"Err.allocating memory for:",L"Panel button",MB_OK);
			return FALSE;
		}
		Btn::pBtns[numNewIt].cmndType = Btn::hotKey;
		Btn::pBtns[numNewIt].iCmndNum = k;
		Btn::pBtns[numNewIt].x = minX;
		Btn::pBtns[numNewIt].y = y;
		ICONINFO ii;
		Btn::pBtns[numNewIt].hIcon=GetPanelEntryIcon(hDlg,0,k);
		GetIconInfo(Btn::pBtns[numNewIt].hIcon,&ii);
		Btn::pBtns[numNewIt].w = ii.xHotspot*2;
		Btn::pBtns[numNewIt].h = ii.yHotspot*2;
		y += Btn::pBtns[numNewIt].h+VER_DELTA;if(y>PANEL_HEIGHT*Btn::kHeight)
		{	y=0;minX += width;
			Btn::pBtns[numNewIt].x = minX;
			Btn::pBtns[numNewIt].y = 0;
		}
ToNextKey:
		;
	}
	Render(0,0);//RedrawWindow(hDlg,NULL,NULL,RDW_INVALIDATE);
	bChangeConfig = TRUE;
	return TRUE;
}

}//end of namespace:

#undef PANEL_HEIGHT
#undef MAX_CREATE_ANIM_TIME