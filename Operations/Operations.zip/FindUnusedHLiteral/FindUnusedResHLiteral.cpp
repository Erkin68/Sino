#include "stdio.h"
#include "Windows.h"
#include <string.h>


bool bStrIds[200];

bool IsStrFounded(FILE*,char*);
void enumResStrngs(char*);

int main(int argc, char* argv[])
{
	if(1==argc)
	{	int cnt=0;
		for(int i=0; i<200; i++)bStrIds[i]=false; 
		printf("Enum used IDS_STRINGSW_* strings:");
		char *p=strrchr(argv[0],'\\');
		if(p)
		{	*(p+1) = 0;
			//p=strrchr(argv[0],'\\');
			//if(p)
			//{	*p = 0;
			//	p=strrchr(argv[0],'\\');
				strcpy(p+1, "\*");
		}//	}
		enumResStrngs(argv[0]);//IDS_STRINGWS_larni qidirib topish:
		for(int i=0; i<200; i++)
		{	if(!bStrIds[i])//=false; 
			printf("\n%d Unsused string IDS_STRINGSW_%d founded",++cnt,i);
		}
		getchar();
		return 0;
	}

	if(argc<3)
	{	printf("Please, type header file and resource file name in command line.");
		getchar();
		return 0;
	}

FILE *hResH,*hRC;
char s[256];
	strcpy(s,argv[0]);
	char *p = strrchr(s,'\\');
	if(p) *(p+1)=0;
	strcat(s,argv[1]);

	hResH = fopen(s,"r");
	if(!hResH)
	{	printf("Header file name incorrect (1-st arg. in cmnd.line.");
		getchar();
		return 0;
	}

	if(p) *(p+1)=0;
	strcat(s,argv[2]);
	hRC = fopen(s,"r");
	if(!hRC)
	{	fclose(hResH);
		printf("Resorce file name incorrect (2-nd arg. in cmnd.line.");
		getchar();
		return 0;
	}

	printf("\nUnfounded string leterals in %s",argv[2]);

	while(!feof(hResH))
	{	char s[128];
		if(EOF==fscanf(hResH,"%s",s))
			break;
		if('#'==s[0])
		if('d'==s[1])
		if('e'==s[2])
		if('f'==s[3])
		if('i'==s[4])
		if('n'==s[5])
		if('e'==s[6])
		{	if(EOF==fscanf(hResH,"%s",s))
				break;
			if(!IsStrFounded(hRC,s))
				printf("\n%s",s);
	}	}

	fclose(hResH);
	fclose(hRC);
	printf("\nFInish searching!!!");
	getchar();
	return 0;
}

bool IsStrFounded(FILE *hRC, char *st)
{
	fseek(hRC,0,SEEK_SET);
	while(!feof(hRC))
	{	char s[128];
		if(EOF==fscanf(hRC,"%s",s))
			return false;
		//if(!strcmp(s,st))
		char *ps = strstr(s,st);
		if(ps)
		{	int l = strlen(s);
			int lt = strlen(st);
			if(lt==l)
				return true;
			if(lt<l)
			{	if(ps[lt]==',')
					return true;
				if(ps[lt]==')')
					return true;
				if(ps[lt]=='_')
					continue;
	}	}	}
	return false;
}

bool IsCrntOrPrntDirAttrb(char* fd)
{//see Naming Conventions in MSDN:
	if('.'==fd[0])
	{	if('\0'==fd[1])//"."
			return false;
		if('.'==fd[1])
			if('\0'==fd[2])//".."
				return false;
	}
	return true;//Hozircha;
}

void FindResStrs(char *fname)
{
	char *pn=strrchr(fname,'.');
	if(pn)
	{	if('c'!=*(pn+1))
			return;
		if(0!=*(pn+2) && 'p'!=*(pn+2))
			return;
		if(0!=*(pn+3) && 'p'!=*(pn+3))
			return;
	} else return;
	FILE *f=fopen(fname,"rb");
	if(!f) return;

	while(!feof(f))
	{	char ss[4096];
		if(EOF==fscanf(f,"%s",ss))
			break;

		//if(strstr(fname,"FileCompare.cpp"))
		//{	OutputDebugString("\n");
		//	OutputDebugString(ss);
		//}

		char *p=strstr(ss,"IDS_STRINGSW_");
		if(p)
		{	//printf("\n%s",ss);
			int i=atoi(&p[13]);
			bStrIds[i]=true;
	}	}
	fclose(f);
}

void enumResStrngs(char *pth)//reentrance
{
__int64 sz = 0;
WIN32_FIND_DATA ff;
HANDLE hf = INVALID_HANDLE_VALUE;

	hf = FindFirstFileEx(pth,FindExInfoStandard,&ff,FindExSearchLimitToDirectories,NULL,0);
	if(INVALID_HANDLE_VALUE==hf) return;

	if(FILE_ATTRIBUTE_DIRECTORY & ff.dwFileAttributes)//if(IsDirectory(path, &ff, TRUE))
	{	if(IsCrntOrPrntDirAttrb(ff.cFileName))
		{	char s[MAX_PATH];
			strcpy(s,pth);
			int l=strlen(s);
			if('*'==s[l-1])//MyStringRemoveLastCharCheckPre(s,MAX_PATH-1,'*','\\');
			if('\\'==s[l-2])
				s[--l]=0;
			strcpy(&s[l],ff.cFileName);
			l+=strlen(&s[l]);//MyStringCat(s,MAX_PATH-1,ff.cFileName);
			s[l++]='\\';//MyStringCat(s,MAX_PATH-1,"\\*");
			s[l++]='*';
			s[l]=0;
			enumResStrngs(s);
	}	}
	else
	{	char s[MAX_PATH];
		strcpy(s,pth);
		int l=strlen(s);
		if('*'==s[l-1])//MyStringRemoveLastCharCheckPre(s,MAX_PATH-1,'*','\\');
		if('\\'==s[l-2])
		s[--l]=0;
		strcpy(&s[l],ff.cFileName);
		FindResStrs(s);
	}

	while(FindNextFile(hf, &ff))
	{	if(FILE_ATTRIBUTE_DIRECTORY & ff.dwFileAttributes)//if(IsDirectory(path, &ff, FALSE))
		{	if(IsCrntOrPrntDirAttrb(ff.cFileName))
			{	char s[MAX_PATH];
				strcpy(s,pth);
				int l=strlen(s);
				if('*'==s[l-1])//MyStringRemoveLastCharCheckPre(s,MAX_PATH-1,'*','\\');
				if('\\'==s[l-2])
					s[--l]=0;
				strcpy(&s[l],ff.cFileName);
				l+=strlen(&s[l]);//MyStringCat(s,MAX_PATH-1,ff.cFileName);
				s[l++]='\\';//MyStringCat(s,MAX_PATH-1,"\\*");
				s[l++]='*';
				s[l]=0;
				enumResStrngs(s);
		}	}
		else
		{	char s[MAX_PATH];
			strcpy(s,pth);
			int l=strlen(s);
			if('*'==s[l-1])//MyStringRemoveLastCharCheckPre(s,MAX_PATH-1,'*','\\');
			if('\\'==s[l-2])
			s[--l]=0;
			strcpy(&s[l],ff.cFileName);
			OutputDebugString("\n");
			OutputDebugString(s);
			FindResStrs(s);
	}	}
	FindClose(hf);
}
