#ifndef __KernelInUserSpace_H__
#define __KernelInUserSpace_H__

#include <windows.h>
#include "..\\plugins\\Auxilary\\SinoSearchF7\\SchItem.h"


namespace NSKERNEL
{
typedef LONG NTSTATUS;
typedef NTSTATUS *PNTSTATUS;
typedef DWORD ULONG_PTR;
 
#define STATUS_SUCCESS (NTSTATUS)0x00000000L
#define NT_SUCCESS(Status) ((NTSTATUS)(Status) >= 0)
#define FILE_OPEN               0x00000001
#define OBJ_CASE_INSENSITIVE    0x00000040L
#define FILE_DIRECTORY_FILE     0x00000001
 
#define InitializeObjectAttributes( p, n, a, r, s ) {    \
    (p)->uLength = sizeof( OBJECT_ATTRIBUTES );          \
    (p)->hRootDirectory = r;                             \
    (p)->uAttributes = a;                                \
    (p)->pObjectName = n;                                \
    (p)->pSecurityDescriptor = s;                        \
    (p)->pSecurityQualityOfService = NULL;               \
}
 
typedef struct _UNICODE_STRING {
    USHORT Length;
    USHORT MaximumLength;
    PWSTR  Buffer;
} UNICODE_STRING;
 
typedef UNICODE_STRING *PUNICODE_STRING;
typedef const UNICODE_STRING *PCUNICODE_STRING;
typedef USHORT RTL_STRING_LENGTH_TYPE;
 
typedef struct _STRING {
    USHORT Length;
    USHORT MaximumLength;
    PCHAR Buffer;
} STRING;
typedef CONST char *PCSZ;

typedef STRING *PSTRING;
typedef STRING ANSI_STRING;
typedef PSTRING PANSI_STRING;
 
 
typedef struct _IO_STATUS_BLOCK {
    union {
        NTSTATUS Status;
        PVOID Pointer;
    };
    ULONG_PTR Information;
} IO_STATUS_BLOCK, *PIO_STATUS_BLOCK;
 
typedef VOID (NTAPI *PIO_APC_ROUTINE) (IN PVOID ApcContext, IN PIO_STATUS_BLOCK IoStatusBlock, IN ULONG Reserved);
 
typedef enum _FILE_INFORMATION_CLASS {
    FileDirectoryInformation         = 1,
	FileFullDirectoryInformation,   
    FileBothDirectoryInformation,   
    FileBasicInformation,          
    FileStandardInformation,        
    FileInternalInformation,        
    FileEaInformation,              
    FileAccessInformation,          
    FileNameInformation,            
    FileRenameInformation,          
    FileLinkInformation,            
    FileNamesInformation,           
    FileDispositionInformation,    
    FilePositionInformation,       
    FileFullEaInformation,         
    FileModeInformation,            
    FileAlignmentInformation,       
    FileAllInformation,             
    FileAllocationInformation,     
    FileEndOfFileInformation,      
    FileAlternateNameInformation,  
    FileStreamInformation,          
    FilePipeInformation,          
    FilePipeLocalInformation,       
    FilePipeRemoteInformation,     
    FileMailslotQueryInformation,   
    FileMailslotSetInformation,     
    FileCompressionInformation,    
    FileObjectIdInformation,        
    FileCompletionInformation,      
    FileMoveClusterInformation,     
    FileQuotaInformation,           
    FileReparsePointInformation,   
    FileNetworkOpenInformation,    
    FileAttributeTagInformation,   
    FileTrackingInformation,        
    FileIdBothDirectoryInformation, 
    FileIdFullDirectoryInformation, 
    FileValidDataLengthInformation, 
    FileShortNameInformation,       
    FileMaximumInformation
} FILE_INFORMATION_CLASS, *PFILE_INFORMATION_CLASS;
 
typedef enum _EVENT_TYPE {NotificationEvent, SynchronizationEvent} EVENT_TYPE;
typedef struct _FILE_BOTH_DIR_INFORMATION
{
    ULONG NextEntryOffset;
    ULONG FileIndex;
    LARGE_INTEGER CreationTime;
    LARGE_INTEGER LastAccessTime;
    LARGE_INTEGER LastWriteTime;
    LARGE_INTEGER ChangeTime;
    LARGE_INTEGER EndOfFile;
    LARGE_INTEGER AllocationSize;
    ULONG FileAttributes;
    ULONG FileNameLength;
    ULONG EaSize;
    CCHAR ShortNameLength;
    WCHAR ShortName[12];
    WCHAR FileName[1];
} FILE_BOTH_DIR_INFORMATION, *PFILE_BOTH_DIR_INFORMATION;

typedef struct _OBJECT_ATTRIBUTES {
    ULONG uLength;
    HANDLE hRootDirectory;
    PUNICODE_STRING pObjectName;
    ULONG uAttributes;
    PVOID pSecurityDescriptor;        
    PVOID pSecurityQualityOfService;  
} OBJECT_ATTRIBUTES;

typedef enum _KEY_INFORMATION_CLASS {
    KeyBasicInformation,
    KeyNodeInformation,
    KeyFullInformation
// end_wdm
    ,
    KeyNameInformation
// begin_wdm
} KEY_INFORMATION_CLASS;

typedef enum _KEY_VALUE_INFORMATION_CLASS {
    KeyValueBasicInformation,
    KeyValueFullInformation,
    KeyValuePartialInformation,
    KeyValueFullInformationAlign64,
    KeyValuePartialInformationAlign64
} KEY_VALUE_INFORMATION_CLASS;

typedef NTSTATUS (NTAPI * PRTL_QUERY_REGISTRY_ROUTINE)(
    IN PWSTR ValueName,
    IN ULONG ValueType,
    IN PVOID ValueData,
    IN ULONG ValueLength,
    IN PVOID Context,
    IN PVOID EntryContext);

typedef struct _RTL_QUERY_REGISTRY_TABLE {
    PRTL_QUERY_REGISTRY_ROUTINE QueryRoutine;
    ULONG Flags;
    PWSTR Name;
    PVOID EntryContext;
    ULONG DefaultType;
    PVOID DefaultData;
    ULONG DefaultLength;

} RTL_QUERY_REGISTRY_TABLE, *PRTL_QUERY_REGISTRY_TABLE;

#define InitializeObjectAttributes( p, n, a, r, s ) {    \
    (p)->uLength = sizeof( OBJECT_ATTRIBUTES );          \
    (p)->hRootDirectory = r;                             \
    (p)->uAttributes = a;                                \
    (p)->pObjectName = n;                                \
    (p)->pSecurityDescriptor = s;                        \
    (p)->pSecurityQualityOfService = NULL;               \
}
 
typedef OBJECT_ATTRIBUTES * POBJECT_ATTRIBUTES;


extern NTSTATUS (WINAPI * pZwCreateFile)(PHANDLE, ACCESS_MASK, POBJECT_ATTRIBUTES, PIO_STATUS_BLOCK, PLARGE_INTEGER, ULONG, ULONG, ULONG, ULONG, PVOID, ULONG);

extern void LoadFromNTDLL();
extern void EnumPanel(void*);
extern void EnumToDlgWithFiltr(SearchItem*,HWND,wchar_t*,wchar_t*,int,int,bool);
extern BOOL SearchForContainText(SearchItem*,wchar_t*,wchar_t*,PFILE_BOTH_DIR_INFORMATION);
extern BOOL SearchForContainTextW(SearchItem*,wchar_t*,wchar_t*,PFILE_BOTH_DIR_INFORMATION);
extern BOOL SearchForNotContainText(SearchItem*,wchar_t*,wchar_t*,PFILE_BOTH_DIR_INFORMATION);
extern BOOL SearchForNotContainTextW(SearchItem*,wchar_t*,wchar_t*,PFILE_BOTH_DIR_INFORMATION);
};

#endif
