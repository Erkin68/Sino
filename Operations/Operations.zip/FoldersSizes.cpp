#include "Windows.h"
#include "MyShell\MyShell.h"
#include "..\Sino.h"

namespace FolderSize
{

HANDLE hThrd = NULL;
DWORD thrdId=0;
wchar_t pth[MAX_PATH];

__int64 GetFolderSize(wchar_t* path,int p)
{
__int64 sz = 0;
WIN32_FIND_DATA ff;
HANDLE hf = INVALID_HANDLE_VALUE;
wchar_t s[MAX_PATH];
	int l=MyStringCpy(s,MAX_PATH-1,path);
	if('*'==s[l-1])//MyStringRemoveLastCharCheckPre(s,MAX_PATH-1,'*','\\');
	if('\\'==s[l-2])
		s[--l]=0;
	
	hf = MyFindFirstFileEx(path,FindExInfoStandard,&ff,FindExSearchLimitToDirectories,NULL,0);
	do
	{	if(forSizeUp!=panel[p].fileSortType)
		if(forSizeDwn!=panel[p].fileSortType)break;

		if(INVALID_HANDLE_VALUE==hf) return 0;
		if(FILE_ATTRIBUTE_DIRECTORY & ff.dwFileAttributes)//if(IsDirectory(path, &ff, FALSE))
		{	if(IsCrntOrPrntDirAttrb(ff.cFileName))
			{	int n=MyStringCpy(&s[l],MAX_PATH-l,ff.cFileName);//MyStringCat(s,MAX_PATH-1,ff.cFileName);
				s[l+n]='\\';++n;//MyStringCat(s,MAX_PATH-1,"\\*");
				s[l+n]='*';++n;
				s[l+n]=0;
				sz += GetFolderSize(s,p);
		}	}
		else
		{	sz += (((U64)ff.nFileSizeHigh<<32) | ff.nFileSizeLow);
	}	}
	while(FindNextFile(hf, &ff));
	FindClose(hf);
	return sz;
}

BOOL CalcFldrSize(int iPanel,int id)
{
	if(!hThrd) return FALSE;
	PostThreadMessage(thrdId,WM_USER,iPanel,id);
	return TRUE;
}

DWORD WINAPI mainThrd()
{	
	for(;;)
	{	MSG msg;
		if(!GetMessage(&msg, 0, 0, 0))continue;
		switch(msg.message)
		{	case WM_USER+1: break;
			case WM_USER://Calc panel folder size:
				if((int)msg.wParam<0) break;
				if((int)msg.wParam>MAX_PANELS-1) break;

				if(forSizeUp!=panel[msg.wParam].fileSortType)
				if(forSizeDwn!=panel[msg.wParam].fileSortType)break;

				MyStringCpy(pth,MAX_PATH-1,panel[msg.wParam].GetPath());
				wchar_t s[2*MAX_PATH];int l;l=MyStringCpy(s,MAX_PATH-1,panel[msg.wParam].GetFullPathAndName((int)msg.lParam));
				if('*'!=s[l-1] && '\\'!=s[l-2])
					{s[l]='\\';s[l+1]='*';s[l+2]=0;}
				else if('*'!=s[l-1] && '\\'==s[l-1])
					{s[l]='*';s[l+1]=0;}
				U64 sz = GetFolderSize(s,(int)msg.wParam);
				SendMessage(panel[msg.wParam].GetHWND(),
							WM_USER+3,
						   (WPARAM)msg.lParam,//Pastdagi qator xatolikka ehtimoli katta:
						   (LPARAM)&sz);//panel[msg.wParam].GetItem(msg.lParam)->size = sz;
				if(msg.lParam==panel[msg.wParam].GetTotItems()-1)
				{
				  Rndr:
					SendMessage(panel[msg.wParam].GetHWND(),WM_USER+2,0,0);
						//panel[msg.wParam].Sort(); degani;
						//panel[msg.wParam].Render();
					++panel[msg.wParam].FoldersSizes.crntItemFor;
					break;
				}
				//oxirigacha 1 tekshiraylikchi:
				for(int i=(int)msg.lParam+1; i<panel[msg.wParam].GetTotItems(); i++)
				{	if(panel[msg.wParam].GetItem(i)->attribute==folder)
						break;
					if(i==panel[msg.wParam].GetTotItems()-1)
						goto Rndr;
				}
				break;
	}	}
	//ExitThread(0);
	return 0;
}


}